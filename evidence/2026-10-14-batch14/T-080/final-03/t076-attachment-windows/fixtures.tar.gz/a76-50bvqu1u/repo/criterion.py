from pathlib import Path; assert Path('value.txt').read_text() == 'attachment fixture\n'
