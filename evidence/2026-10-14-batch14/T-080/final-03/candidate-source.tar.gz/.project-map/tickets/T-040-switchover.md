---
id: T-040
title: 切换到工作台并删除旧运行路径
type: build
status: closed
blocked_by: []
claimed_by:
supersedes:
---

## What to build

M1 第 1～5 项通过且用户认可界面后，主控与 worker 的日常分派改到 Synara；删除 a2a 仓库中 Muster 引擎与 `coop.py` 的运行路径，参考实现留在 git 历史与证据中。更新 AGENTS.md、README、CONTEXT.md 与地图。

## Acceptance

- [x] 用户确认界面外观与切换时机。
- [x] 删除后仓库内无 Muster/coop.py 运行入口；门禁 8/9/18 项经原生入口仍通过。
- [x] 一次日常分派经 Synara 完成并留证据。

## 用户决定（2026-10-08）

- 外观："还可以，外观先这样"（T-043）。
- Q1 = A：日常用 fork 构建的桌面版，专用数据目录（`~/Library/Application Support/a2a-workbench`），与可能已装的官方 Synara 分开；Codex 用用户自己的登录。
- Q2 = A：主控仍是终端中的 Claude Code，派发、查状态、回收改为调用门禁 CLI/MCP；worker 由 Synara 原生创建为 Codex 会话，用户在任务窗口看进度。以后再考虑把主控搬进 Synara。
- Q3：先推送（a2a `be59634`、fork `d3b5bcc` 已推送），再开始删除。

分两部分并行：A 删除旧运行路径（a2a 仓库，经 Herdr worker）；B 工作台启动器与专用数据目录（fork）。两者完成后，主控经 Synara 完成第一次日常派发。

## Resolution

### A 部分交付（2026-10-08）

**INCOMPLETE，需要主控决定；ticket 保持 open，删除后验收复选框未勾选。** 代码候选 `1279adb73c06308fc71eebf35002628730f320d5` 已删除 2,966 个退役受控文件，提升原生验收与边界替身，并更新 README；未 push、未修改 fork。删除前原生 8/9/18 通过；删除后交付 8/8、编排 18/18、恢复第二轮 9/9，指向已删除入口的反例明确失败。

恢复首轮 1 项失败：并发 verify/integrate 未在原有 2 秒时限内退出，两轮现场均保留。唯一一次 fresh-context 只读独立审查为 FAIL，恢复时限验收 NO_GO；同源重跑不能排除首轮业务红态。主控须定位失败边界并决定必要修正及真实入口复验，不放宽断言；AGENTS.md、CONTEXT.md、地图治理更新仍归主控，末次 status 报 CONTEXT.md stale。详见 [A 部分记录](../../evidence/2026-10-08-batch4/T-040-A/RESULTS.md) 与 [独立审查](../../evidence/2026-10-08-batch4/T-040-A/独立审查.md)。

### B 部分：启动器与主控入口（2026-10-08）

INCOMPLETE：最终真实隔离的启动、重复启动、HTTP gate status、0600/错误 token 反例、停止无监听、重启 token 轮换和数据保留均已 PASS；审查发现的就绪/构建判断问题已修正并取得旧提交红态、新提交绿态及限定复审 PASS。全仓测试有 5 项失败，未在父修订证明基线情况。fork `a2a` 分支最终提交 `28e2f1b4ca6634d4faba9bd921a55a51640407e4`，新增 `a2a/scripts/workbench`、`gate` 与中文使用说明。默认专用目录前后未创建，未登录、未调用 Synara provider、未 push。

完整结果、失败记录、隔离输入、原始命令和收尾归档见 [T-040-B RESULTS](../../evidence/2026-10-08-batch4/T-040-B/RESULTS.md)。T-040 继续 open；最终地图 0 problems / 0 stale。全仓失败的基线核对、专用目录首次启动和日常真实分派交回主控。

### B 主控决定 01：父修订对照追加（2026-10-08）

PASS，仅指有界对照完成：父 `d3b5bcc61cc212572f38e01139e1b9af2196b820` 与候选 `28e2f1b4ca6634d4faba9bd921a55a51640407e4` 的 4 个文件，各交替单跑 3 次，共 24 次全部通过；原 5 项在两边分别 3/3 通过，同文件没有候选独有失败，未触发回归修复。使用外置短 tmp、串行运行，在确认 A 计时结束且无活跃相关进程后按已授权方式切换共享 checkout；完成后恢复 `a2a` 分支/候选提交，源码和测试未修改。准备阶段安装中断与旧 INCOMPLETE/全仓失败记录均保留。

详见 [追加结果及边界](../../evidence/2026-10-08-batch4/T-040-B/RESULTS.md) 和 [24 次原始矩阵](../../evidence/2026-10-08-batch4/T-040-B/parent-comparison-01/summary.json)。本轮未复现不证明原全仓失败的根因，也不代表全仓通过；T-040 保持 open，首次日常分派与整体切换仍归主控。

### A 部分：主控决定 01 的有界计时（2026-10-08）

**PASS（仅授权的计时采样交付）；原失败根因 INCOMPLETE，A 部分恢复验收 NO_GO 保留。** 未修改 fork、验收或原 2 秒断言；空闲和 10 个自有 yes 负载两种条件下，verify/integrate 各 20 次分段样本，另有 80 次无钩子对照，合计 160 次均为真实 operation_busy，超过 2 秒均为 0。锁判定最大 0.185 毫秒；本轮未复现原失败，不能把它归为环境噪声或宣布修复。

原始阶段记录、真实 verify owner 的完成、子进程全部回收、版本绑定、首轮时钟试运行失败，以及最小选项见 [计时定位与主控交接](../../evidence/2026-10-08-batch4/T-040-A/timing-01/计时定位结果.md)。建议保留 NO_GO，由主控决定下一轮复现条件；收窄合同模块导入、标准构建 CLI 产物仅为未实施和未验证的选项。授权诊断到此结束，ticket 保持 open。

### A 部分：主控决定 02 复验与环境条件（2026-10-08）

**INCOMPLETE，需要主控决定，没有接受 A。** 同候选连续五轮恢复 9 项业务结果为 45/45，但第 4 轮结束、第 5 轮前后出现 Token Monitor / TokNotch 的重负载，不满足“没有其他重负载”条件。初步接受结论在提交前撤回，旧失败与独立审查 FAIL 不改判。

在随后空闲窗口另启动一组，首轮业务 9/9；结束快照 CPU idle 降至 15.88%，环境门控停止其余四轮，不再启动第三组。合计 54/54 业务通过、没有新业务失败，产品和原 2 秒断言不改。现有证据不能自行替代规定的运行条件；主控可明确接受这组含额外负载的通过证据，或安排获授权的空闲窗口再执行五轮。用户应用没有被停止。

两组顺序、输入、负载、信号、原现场及撤回的初步记录见 [完整复验交接](../../evidence/2026-10-08-batch4/T-040-A/recovery-repeat-01/RESULTS.md)。T-040 继续 open，A 的接受 checkbox 未勾选。

主控记录（2026-10-08）：A 部分按 [决定 03](../../evidence/2026-10-08-batch4/T-040-A/controller-decision-03.md) 接受：删除 2,966 个受控文件，8/8、18/18、9/9 经原生入口通过，恢复 9 项另在重负载下 6 轮 54/54；首轮一次 2 秒超时原因未明，记入 fog。B 部分接受：`a2a/scripts/workbench`、`a2a/scripts/gate`、`a2a/WORKBENCH.md`（fork `28e2f1b`），真实隔离启动、重复启动、鉴权反例、停止与重启通过；5 项全仓失败经父修订对照 24 次全通过，未检出 B 引入的回归。剩第 3 项：经 Synara 完成一次日常分派。

**主控关闭（2026-10-09）：PASS。** 第 3 项由 [T-046](T-046-workbench-locale-identity.md) 完成。AGENTS.md 中"切换前经 Herdr 分派"的条款待下次会话更新。
