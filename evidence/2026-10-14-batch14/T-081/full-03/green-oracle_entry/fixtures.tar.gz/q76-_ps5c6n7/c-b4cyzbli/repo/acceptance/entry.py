import runpy
runpy.run_path('acceptance/criterion.py')
