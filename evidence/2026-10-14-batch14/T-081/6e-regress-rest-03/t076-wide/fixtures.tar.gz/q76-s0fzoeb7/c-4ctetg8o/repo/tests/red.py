from pathlib import Path
assert Path("src/value.txt").read_text(encoding="utf-8") == "worker\n", "required behavior absent"
