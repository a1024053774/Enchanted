"""主控批准后单独运行：生成或删除固定夹具的隔离 CODEX_HOME；不启动 CLI。"""
import argparse
import json
import os
from pathlib import Path
import shutil


FIXTURE = Path('/private/tmp/t081-capability-01')
HOME_PATH = FIXTURE / 'codex-home'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'cleanup'])
    parser.add_argument('--approval-ref', required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    if not args.approval_ref.strip():
        raise RuntimeError('需要主控本次批准的位置引用。')
    if FIXTURE.is_symlink() or FIXTURE.resolve(strict=True) != FIXTURE:
        raise RuntimeError('夹具根不符合固定路径。')
    marker = json.loads((FIXTURE / 'PREPARED.json').read_text(encoding='utf-8'))
    if marker['task'] != 'T-081' or marker['root'] != str(FIXTURE):
        raise RuntimeError('夹具身份不符。')
    receipt = args.receipt.resolve()
    if receipt.exists() or FIXTURE == receipt or FIXTURE in receipt.parents:
        raise RuntimeError('收据必须是夹具之外的新文件，不可把凭据目录当证据。')
    record = {'task': 'T-081', 'action': args.action, 'approval_ref': args.approval_ref,
              'home': str(HOME_PATH), 'credential_contents_recorded': False,
              'hooks_installed': False, 'real_codex_turns_started_by_this_script': 0}
    if args.action == 'prepare':
        HOME_PATH.mkdir(mode=0o700, exist_ok=False)
        source = Path.home() / '.codex/auth.json'
        shutil.copyfile(source, HOME_PATH / 'auth.json')
        (HOME_PATH / 'auth.json').chmod(0o600)
        config = '[projects.' + json.dumps(str(FIXTURE)) + ']\ntrust_level = "trusted"\n'
        with (HOME_PATH / 'config.toml').open('x', encoding='utf-8') as stream:
            stream.write(config)
        (HOME_PATH / 'rules').mkdir(mode=0o700)
        rules = ('prefix_rule(pattern=["git", "add"], decision="allow")\n'
                 'prefix_rule(pattern=["git", "commit"], decision="allow")\n')
        with (HOME_PATH / 'rules/default.rules').open('x', encoding='utf-8') as stream:
            stream.write(rules)
        record.update(status='PASS', scope='仅隔离 home 准备', config=config, rules=rules,
                      copied_names=['auth.json'], generated_names=['config.toml', 'rules/default.rules'])
    else:
        if HOME_PATH.is_symlink() or HOME_PATH.resolve(strict=True) != HOME_PATH:
            raise RuntimeError('隔离 home 路径不符，拒绝删除。')
        state = FIXTURE / 'state'
        if (state / 'daemon.pid').exists() or (state / 'control.sock').exists():
            raise RuntimeError('后台端点仍存在，保留 home 等主控核对。')
        checked = []
        if state.exists():
            ownership = json.loads((FIXTURE / 'owned-pids.json').read_text(encoding='utf-8'))
            if ownership.get('root') != str(FIXTURE) or not ownership.get('pids'):
                raise RuntimeError('缺少本夹具的后台/PTY/CLI PID 记录，保留 home。')
            for pid in ownership['pids']:
                if type(pid) is not int or pid <= 1:
                    raise RuntimeError('PID 记录无效，保留 home。')
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    checked.append(pid)
                else:
                    raise RuntimeError('记录的 PID 尚存在，保留 home：' + str(pid))
        shutil.rmtree(HOME_PATH)
        record.update(status='PASS', scope='仅已确认停止的隔离 home 清理',
                      removed=not HOME_PATH.exists(), checked_exited_pids=checked)
    receipt.parent.mkdir(parents=True, exist_ok=True)
    with receipt.open('x', encoding='utf-8') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': record['status'], 'scope': record['scope'], 'receipt': str(receipt)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
