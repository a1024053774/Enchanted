from pathlib import Path
assert Path('src/value.txt').read_text() == 'worker\n'
