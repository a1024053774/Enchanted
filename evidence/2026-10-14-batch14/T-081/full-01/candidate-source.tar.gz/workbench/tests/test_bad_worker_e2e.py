"""T-081：真实门禁入口的坏 worker 输入；PTY 与模型记录为受控夹具。"""
import argparse
import json
from pathlib import Path
import sys

from test_quality_chain_e2e import HarnessFailure, run_cases, save
from test_quality_tracer_e2e import Tracer


REFUSALS = {
    'oracle_test': 'oracle_modified',
    'oracle_entry': 'oracle_modified',
    'self_report_unchanged': 'oracle_failed',
    'self_report_wrong': 'oracle_failed',
    'stale_attempt': 'stale_attempt',
    'deny_path': 'path_boundary_failed',
    'trailer_partial': 'invalid_trailers',
    'trailer_duplicate': 'invalid_trailers',
    'trailer_task': 'trailer_task_mismatch',
    'trailer_attempt': 'trailer_identity_mismatch',
}
NEGATIVES = [*REFUSALS, 'after_review']
POSITIVES = ['positive_single', 'positive_multi', 'positive_red_card']
PROBES = ['probe_launch', 'probe_model']
FORGED_LAUNCH = '00000000-0000-4000-8000-000000000081'
# This is forged trailer text, never a requested or running model.
FORGED_MODEL = 'gpt-6-astra'


class BadWorker(Tracer):
    def id(self):
        return 'T-081.' + self.case

    def setUp(self):
        super().setUp()
        self.task = 'T-081-' + self.case.replace('_', '-')
        self.card['id'] = self.task
        save(self.evidence / 'input.json', {
            'case': self.case, 'product_value': 'worker\n',
            'criterion': "assert Path('src/value.txt').read_text() == 'worker\\n'",
            'oracle_paths': ['acceptance/criterion.py'],
            'expected_refusal': REFUSALS.get(self.case),
            'forged_launch': FORGED_LAUNCH, 'forged_model': FORGED_MODEL,
            'real_codex_turns': 0,
        })

    def make_commit(self, attempt, files, *, changes=None, omit=(), duplicate=None,
                    message='T-081 controlled fixture delivery', empty=False):
        workspace = Path(attempt['workspace'])
        for name, value in files.items():
            target = workspace / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(value, encoding='utf-8')
        values = {
            'Task': self.task, 'Attempt': attempt['attempt_id'],
            'Session': attempt['session_id'], 'Role': 'worker',
            'Tool': 'codex-cli 0.162.1', 'Model': 'gpt-6.1-sol', 'Effort': 'xhigh',
            'Native-Session': self.native['native'] if attempt['thread_id'] else 'fixture-native',
            'Launch': self.launch if attempt['thread_id'] else 'fixture-launch',
        }
        values.update(changes or {})
        trailers = ['A2A-' + key + ': ' + value for key, value in values.items() if key not in omit]
        if duplicate:
            trailers.append('A2A-' + duplicate + ': ' + values[duplicate])
        self.git('add', '.', cwd=workspace)
        self.git('commit', *(['--allow-empty'] if empty else []),
                 '-m', message + '\n\n' + '\n'.join(trailers), cwd=workspace)
        candidate = self.oid(workspace)
        save(self.evidence / ('commit-' + candidate + '.json'), {
            'candidate': candidate, 'files': files, 'trailers': values,
            'omitted': list(omit), 'duplicate': duplicate,
            'message': self.git('show', '-s', '--format=%B', candidate),
        })
        return candidate

    def delivered(self, files, **kwargs):
        a = self.start_worker()
        candidate = self.make_commit(a, files, **kwargs)
        reply = self.worker_submit(candidate)
        if not reply['ok']:
            raise HarnessFailure('合法 submit 在目标检查之前失败：' + json.dumps(reply))
        return a, candidate

    def branch(self):
        return {'ref': self.oid(),
                'reflog': self.git('reflog', 'show', '--format=%H', 'refs/heads/main')}

    def refused(self, *, reply=None, before=None, prior_events=None):
        before = before or self.branch()
        prior_events = self.events() if prior_events is None else prior_events
        reply = reply or self.gate('verify', '--attempt', self.a['attempt_id'])
        current = self.cli('status')['task']
        after = self.events()
        fresh = after[len(prior_events):]
        expected = REFUSALS[self.case]
        actual = {'reply': reply, 'task': current, 'before': before, 'after': self.branch(),
                  'events': fresh, 'expected': expected, 'actual': reply.get('error')}
        save(self.evidence / 'observation.json', actual)
        self.check('BW-REJECT-' + self.case,
                   reply.get('ok') is False and reply.get('error') == expected,
                   {'ok': False, 'error': expected}, reply)
        self.check('BW-UNCHANGED-' + self.case,
                   actual['after'] == before and current['state'] != 'accepted'
                   and not any(e['type'] in ('integrated', 'score_recorded') for e in fresh),
                   '工作分支、reflog 与集成状态不推进', actual)
        self.check('BW-EVENT-' + self.case,
                   any(e['type'] == 'rejected' and e['details'].get('error') == expected for e in fresh),
                   '真实门禁追加对应拒收事件', fresh)
        integration = self.gate('integrate', '--attempt', current['current_attempt']['attempt_id'],
                                '--score-file', self.score_file())
        self.check('BW-NO-INTEGRATION-' + self.case,
                   integration.get('ok') is False and self.branch() == before,
                   '被拒的交付不能带分数集成', integration)

    def oracle_case(self, path):
        self.card['paths'] = {'allow': ['.'], 'deny': []}
        entry = self.repo / 'acceptance/entry.py'
        entry.write_text("import runpy\nrunpy.run_path('acceptance/criterion.py')\n", encoding='utf-8')
        self.git('add', 'acceptance/entry.py')
        self.git('commit', '-m', 'Freeze independent acceptance entry')
        self.card['oracle_paths'] = ['acceptance/criterion.py', 'acceptance/entry.py']
        self.card['completion_conditions'] = [{'argv': [sys.executable, '-I', '-B', 'acceptance/entry.py']}]
        self.delivered({path: 'pass\n'})
        self.refused()
        types = [e['type'] for e in self.events()]
        self.check('BW-ORACLE-BEFORE-COMPLETION',
                   'oracle_check' in types and 'completion_intent' not in types and 'review_requested' not in types,
                   '改验收文件在执行该文件前拒收', types)

    def oracle_test(self):
        self.oracle_case('acceptance/criterion.py')

    def oracle_entry(self):
        self.oracle_case('acceptance/entry.py')

    def self_report_unchanged(self):
        self.delivered({}, message='所有测试通过', empty=True)
        self.refused()

    def self_report_wrong(self):
        self.delivered({'src/value.txt': 'wrong\n'}, message='所有测试通过')
        self.refused()

    def deny_path(self):
        self.delivered({'src/value.txt': 'worker\n', 'src/private/secret.txt': 'forbidden\n'})
        self.refused()

    def trailer_partial(self):
        self.delivered({'src/value.txt': 'worker\n'}, omit=('Effort',))
        self.refused()

    def trailer_duplicate(self):
        self.delivered({'src/value.txt': 'worker\n'}, duplicate='Session')
        self.refused()

    def trailer_task(self):
        self.delivered({'src/value.txt': 'worker\n'}, changes={'Task': 'T-081-another-task'})
        self.refused()

    def trailer_attempt(self):
        self.delivered({'src/value.txt': 'worker\n'}, changes={'Attempt': 't081-old-attempt'})
        self.refused()

    def stale_attempt(self):
        # A delayed scripted executor uses the same public submit command.
        # A dirty draft keeps its own old workspace available across revoke.
        self.registered()
        old = self.cli('claim', '--owner', 'old-scripted-worker')['attempt']
        candidate = self.make_commit(old, {'src/value.txt': 'worker\n'})
        draft = Path(old['workspace']) / 'old-worker-draft.txt'
        draft.write_text('保留迟到 worker 的目录\n', encoding='utf-8')
        self.cli('revoke', '--reason', 'explicit replacement for T-081 stale delivery')
        new = self.cli('claim', '--owner', 'new-scripted-worker')['attempt']
        draft.unlink()
        before, events = self.branch(), self.events()
        snapshot = self.cli('status')['task']
        reply = self.gate('submit', '--attempt', old['attempt_id'], '--session', old['session_id'],
                          '--fence', str(old['fence']), '--spec-rev', str(old['spec_rev']), '--commit', candidate)
        self.refused(reply=reply, before=before, prior_events=events)
        current = self.cli('status')['task']
        self.check('BW-NEW-ATTEMPT-PRESERVED',
                   current['current_attempt'] == snapshot['current_attempt']
                   and current['candidate_commit'] == snapshot['candidate_commit']
                   and current['fence'] == new['fence'],
                   '旧交付不得改变新 attempt 身份或候选', current)

    def after_review(self):
        a, c1 = self.delivered({'src/value.txt': 'worker\n'})
        self.approve(c1)
        c2 = self.make_commit(a, {'src/late.txt': 'unreviewed C2\n'})
        body = self.root / 'late-delivery.txt'
        body.write_text('T-081：在新的受控回合提交 C2。\n', encoding='utf-8')
        started = self.gate('pane_dispatch', '--thread', a['thread_id'], '--body-file', body, task=False)
        if not started['ok']:
            raise HarnessFailure('不能启动受控迟到回合。')
        self.wait_pane(lambda p: p['state'] == 'busy' and p['turn'] == 'fixture-turn-3')
        before = self.branch()
        late = self.worker_submit(c2, request_id='unreviewed-c2')
        task = self.cli('status')['task']
        save(self.evidence / 'late-submission.json', {'C1': c1, 'C2': c2, 'reply': late, 'task': task})
        self.check('BW-LATE-SUBMIT', late.get('error') == 'stale_turn'
                   and task['candidate_commit'] == c1 and self.branch() == before,
                   '新回合也不能替换已审查 C1', late)
        result = self.gate('integrate', '--attempt', a['attempt_id'], '--score-file', self.score_file())
        observed = {'reply': result, 'C1': c1, 'C2': c2, 'branch': self.branch(),
                    'actual': late.get('error') + '; integrated C1' if self.oid() == c1 else 'wrong integration target',
                    'files': self.git('ls-tree', '-r', '--name-only', 'refs/heads/main'),
                    'task': self.cli('status')['task'], 'events': self.events()}
        save(self.evidence / 'observation.json', observed)
        self.check('BW-FROZEN-INTEGRATION', result.get('ok') is True and self.oid() == c1
                   and 'src/late.txt' not in observed['files'].splitlines()
                   and observed['task']['verification']['C'] == c1
                   and observed['task']['integration_intent']['C'] == c1,
                   '仅集成已验收 C1，C2 新文件不进入工作分支', observed)

    def finish_positive(self, candidate):
        self.approve(candidate)
        self.integrate_scored(candidate, rounds=1)
        save(self.evidence / 'observation.json', {
            'actual': 'integrated', 'candidate': candidate, 'branch': self.branch(),
            'value': (self.repo / 'src/value.txt').read_text(encoding='utf-8'),
            'task': self.cli('status')['task'], 'events': self.events(),
        })
        self.check('BW-POSITIVE-CONTENT',
                   (self.repo / 'src/value.txt').read_text(encoding='utf-8') == 'worker\n',
                   '独立要求的产品值 worker', (self.repo / 'src/value.txt').read_text(encoding='utf-8'))

    def positive_single(self):
        _, candidate = self.delivered({'src/value.txt': 'worker\n'})
        self.finish_positive(candidate)

    def positive_multi(self):
        a = self.start_worker()
        self.make_commit(a, {'src/value.txt': 'worker\n'})
        candidate = self.make_commit(a, {'src/second.txt': 'second independent commit\n'})
        if not self.worker_submit(candidate)['ok']:
            raise HarnessFailure('多提交正例 submit 失败。')
        self.finish_positive(candidate)

    def positive_red_card(self):
        self.card['red_commands'] = [{'argv': [sys.executable, '-I', '-B', 'tests/new_test.py'],
                                     'test_paths': ['tests/new_test.py']}]
        test = "from pathlib import Path\nassert Path('src/value.txt').read_text() == 'worker\\n', 'required worker value'\n"
        _, candidate = self.delivered({'src/value.txt': 'worker\n', 'tests/new_test.py': test})
        self.finish_positive(candidate)
        red = [e for e in self.events() if e['type'] == 'red_check']
        self.check('BW-RED-CARD', len(red) == 1 and red[0]['details']['passed'],
                   '新增测试在起点失败，在候选通过', red)

    def probe_forged(self, field, value):
        _, candidate = self.delivered({'src/value.txt': 'worker\n'}, changes={field: value})
        before = self.branch()
        reply = self.gate('verify', '--attempt', self.a['attempt_id'])
        task = self.cli('status')['task']
        observed = {'field': field, 'forged': value, 'candidate': candidate,
                    'recorded_worker_launch': self.launch, 'recorded_worker_model': 'gpt-6.1-sol',
                    'verify': reply, 'state_after_verify': task['state'],
                    'accepted_at_verify': reply.get('ok') is True and task['state'] == 'reviewing',
                    'before': before, 'integrated': False}
        save(self.evidence / 'probe-verify.json', observed)
        checks = [e for e in self.events() if e['type'] == 'trailer_check'
                  and e['details'].get('commit') == candidate]
        self.check('BW-PROBE-TARGET-REACHED', len(checks) == 1
                   and checks[0]['details']['trailers'].get(field.lower()) == [value],
                   '伪造值确实到达真实尾注检查', checks)
        if not observed['accepted_at_verify']:
            self.check('BW-PROBE-TARGET-REFUSAL', reply.get('ok') is False
                       and checks[0]['details']['passed'] is False
                       and checks[0]['details']['error'] == reply.get('error'),
                       '拒收确由目标尾注检查产生', {'reply': reply, 'check': checks})
        # Record admission before attempting any later phase, so a later fault
        # cannot erase proof that the target check let this delivery through.
        if observed['accepted_at_verify']:
            self.approve(candidate, automatic=True)
            integrated = self.gate('integrate', '--attempt', self.a['attempt_id'],
                                   '--score-file', self.score_file())
            observed.update(integrate=integrated,
                            integrated=integrated.get('ok') is True and self.oid() == candidate)
        observed.update(after=self.branch(), events=self.events(), task=self.cli('status')['task'])
        save(self.evidence / 'observation.json', observed)

    def probe_launch(self):
        self.probe_forged('Launch', FORGED_LAUNCH)

    def probe_model(self):
        self.probe_forged('Model', FORGED_MODEL)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--case', choices=[*NEGATIVES, *POSITIVES, *PROBES], action='append', required=True)
    args = parser.parse_args()
    return run_cases(args.source, args.output, args.case, BadWorker, dialect='current', stop_on_failure=True)


if __name__ == '__main__':
    raise SystemExit(main())
