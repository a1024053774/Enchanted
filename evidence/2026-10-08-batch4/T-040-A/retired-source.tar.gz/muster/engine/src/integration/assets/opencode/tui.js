// installed by muster
// MUSTER_INTEGRATION_ID=opencode-tui-v2
// MUSTER_INTEGRATION_VERSION=13
// V2 resolves the directory's tui entrypoint; V1 uses the original file.
export { default } from "../muster-tui-session.js";
