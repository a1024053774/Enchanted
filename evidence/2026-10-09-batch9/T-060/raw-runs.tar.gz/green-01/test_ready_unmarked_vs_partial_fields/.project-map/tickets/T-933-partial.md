---
id: T-933
title: partial
type: research
status: open
blocked_by: []
claimed_by:
ready_by: executor
ready_rev: 2
---
