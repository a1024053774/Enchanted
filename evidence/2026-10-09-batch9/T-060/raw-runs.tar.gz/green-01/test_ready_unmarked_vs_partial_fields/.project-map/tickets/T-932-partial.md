---
id: T-932
title: partial
type: research
status: open
blocked_by: []
claimed_by:
ready: yes
ready_by: ideation
---
