---
id: "receipt-user"
from: "worker:terminal"
to: "user"
kind: "ack"
reply_to: "original-user"
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
---

正文：独立夹具
