---
id: T-924
title: dependent
type: build
status: open
blocked_by: [T-921, T-922]
claimed_by:
ready: yes
ready_by: ideation
ready_rev: 1
---
