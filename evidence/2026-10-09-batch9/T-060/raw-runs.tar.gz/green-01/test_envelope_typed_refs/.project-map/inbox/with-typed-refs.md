---
from: "worker:sentinel"
to: "executor"
kind: "report"
reply_to: ""
refs: ["task:task-nonce", "thread:thread-nonce", "turn:turn-nonce", "message:message-nonce", "request:request-nonce", "input:input-nonce", "commit:abcdef123456"]
created_at: "2026-10-09T12:00:00Z"
schema: 1
id: "with-typed-refs"
---

正文：引号" / 多行
⟦⟧ café