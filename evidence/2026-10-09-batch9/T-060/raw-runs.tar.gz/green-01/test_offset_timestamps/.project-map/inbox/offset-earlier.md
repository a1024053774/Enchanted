---
id: "offset-earlier"
from: "worker:sentinel"
to: "executor"
kind: "report"
reply_to: ""
refs: []
created_at: "2026-10-09T07:59:00-04:00"
schema: 1
---

正文：独立夹具
