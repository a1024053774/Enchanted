---
id: "terminal-user-ack"
from: "worker:alpha"
to: "user"
kind: "ack"
reply_to: "terminal-user-target"
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
---

ack-user nonce
