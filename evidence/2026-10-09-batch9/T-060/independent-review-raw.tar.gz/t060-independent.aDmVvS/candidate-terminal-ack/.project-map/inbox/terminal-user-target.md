---
id: "terminal-user-target"
from: "user"
to: "worker:alpha"
kind: "report"
reply_to: ""
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
---

target-user nonce
