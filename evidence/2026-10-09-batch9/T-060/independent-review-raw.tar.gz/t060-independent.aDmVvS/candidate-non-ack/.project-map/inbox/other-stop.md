---
id: "other-stop"
from: "worker:omega"
to: "executor"
kind: "stop"
reply_to: ""
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
---

non-ack stop nonce
