---
id: "other-cancel"
from: "worker:omega"
to: "executor"
kind: "cancel"
reply_to: ""
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
---

non-ack cancel nonce
