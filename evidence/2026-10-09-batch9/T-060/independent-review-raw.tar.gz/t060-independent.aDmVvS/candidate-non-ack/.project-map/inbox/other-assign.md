---
id: "other-assign"
from: "worker:omega"
to: "executor"
kind: "assign"
reply_to: ""
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
---

non-ack assign nonce
