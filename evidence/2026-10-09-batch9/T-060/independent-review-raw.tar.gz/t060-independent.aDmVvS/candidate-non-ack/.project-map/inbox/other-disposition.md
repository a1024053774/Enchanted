---
id: "other-disposition"
from: "worker:omega"
to: "executor"
kind: "disposition"
reply_to: "other-issue"
refs: []
created_at: "2026-10-09T11:00:00Z"
schema: 1
action: "needs-user"
---

non-ack disposition nonce
