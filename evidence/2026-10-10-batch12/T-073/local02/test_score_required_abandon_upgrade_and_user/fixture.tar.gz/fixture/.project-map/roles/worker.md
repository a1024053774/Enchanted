独立 fixture worker 角色卡
