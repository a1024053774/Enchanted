# T-007：验收与集成中断恢复（2026-10-06）

依据：已接受 intent、T-007，以及首轮 G/M 集成意图设计。只扩展已有命令，不改变用户目标或权限。
本切片是 Tracer bullet 的故障恢复纵向扩展；沿用 Ubiquitous language；
Deep modules 仍由持久状态层拥有恢复与副作用核对，测试不调用内部恢复函数。

## 可观察契约（实现和验收共同冻结）

仍通过 `python3 coop.py --state ABS COMMAND --task ID` 操作。
允许在只针对本任务的真实 CLI 进程被终止后，重新调用原命令。没有后台盲重试和新 recover API。

1. verify / integrate 必须排除本任务的重叠执行。
   仍有真实执行者时，第二次 verify 或 integrate 立即以 exit 1、error=operation_busy 拒绝；
   不启动第二次 oracle、不重复更新 Git、不误把正常工作标为中断。
   不用 PID 存活作为唯一所有权凭据。优先使用操作系统自动释放的任务级锁，
   当前实验平台是 macOS/POSIX，Python 标准库即可；不扩展 Windows 保证。

2. verify 中断且操作锁已释放：新 verify 将旧 verification 保留并明确记作 interrupted，
   追加 verification_interrupted 事件，保留原候选、oracle、worktree、原始 command_intent。
   再为同一当前有效候选生成新 verification_id 和独立验证 worktree，重新执行冻结 oracle。
   不复用遗失的退出码或把孤儿 oracle 的结束当通过。只在新的完整 oracle 返回 0 后 verified。
   缺失的旧 stdout/exit 标为未知，不编造。当前 attempt 或 spec 已撤销/变化时，不能复活旧候选。

3. integrate 已持久 pending intent，在 Git 更新前中断：
   若真实引用仍为 G，重新核验当前 attempt/session/fence/spec、candidate、verification 和 intent 的一致性，
   然后继续同一个 intent 的 CAS（M,G），不是创建一份竞争意图。
   Git 已变成 M 而数据库尚未记账：核对同一意图后补记 accepted，不再次写 Git。
   引用为第三个值 X 或不存在：exit 1/error=needs_reconciliation，原 intent 与证据保留，
   不能改写引用或改为 accepted。当前合法意图不能靠 revoke/revise 绕过。

4. 重放 integrate 在成功之后仍幂等；未知状态不会因重复调用变成成功。
   恢复期间保留历史事件、旧工作区和候选；旧会话 submit 仍被同一身份门禁拒绝。

## 独立验收入口

新增 acceptance/test_recovery_e2e.py，以 CLI 子进程、真实 SQLite、真实 Git refs/reflog 为边界。
不 import 产品，不手工改 SQLite 伪造崩溃，不向生产代码加入测试开关或环境故障分支。
外部故障夹具可以在 PATH 上包装 git 或 oracle 启动边界：对非目标命令必须直接调用真实工具；
目标边界须记录真实 argv/result，并只终止该 fixture 创建的 CLI PID。
before-CAS 在副作用前终止；after-CAS 先执行真实 Git 更新再终止调用方；
验收中断使用可控 oracle barrier。屏障、退出信号、存活检查、原始输出都保存。

必须含：
- oracle 仍工作时重复 verify / integrate 返回 operation_busy，释放屏障后原执行可结束；
- kill verify 后新进程恢复，旧 verification 标中断，新 ID，结果和引用正确；
- kill integrate 在 CAS 前，恢复仍用原 intent，成功恰好一次；
- kill integrate 在 CAS 后，恢复不增加 reflog；
- CAS 后崩溃又有外部 X（或引用删除），恢复拒绝且历史/引用保持；
- 验收中断后撤销并重领，旧身份不能提交，恢复不复活旧候选。

先在父版本 aca370a 保留预期业务红态；已有可工作的恢复分支照实记录通过。
实现后重跑同一测试与 T-006 8 项既有套件。
为新恢复门禁做一个代表性 known-bad 反事实，要求业务断言失败；不以注入器故障充数。
产物在 evidence/2026-10-06-recovery-01/。测试每次新建隔离目录，保留失败现场。

## 运行边界

测试只终止自己创建且已记录 PID 的进程，不能 kill Herdr 主进程或用户其他 pane。
本轮验证本地 CLI / Git / SQLite 的真实恢复，不把假 Herdr 或模拟模型当新模型证据。
T-006 的已验收真实模型产物与原失败日志不可覆盖。
