// Test host for the existing controlled thread service. No provider execution.
import { appendFileSync, writeFileSync } from "node:fs";
import { resolve, join } from "node:path";
import { fileURLToPath } from "node:url";
import { serve } from "../src/daemon.ts";
import { A2AGates, type SubmitCaller } from "../src/gates/core.ts";
import { boundary, runtime } from "../../acceptance/entry/native-runtime.ts";

const [state, control, ready] = process.argv.slice(2);
if (!state || !control || !ready || process.argv.length !== 5) {
  throw new Error("usage: daemon_acceptance_host.ts ABS_STATE ABS_THREAD_CONTROL ABS_READY_FILE");
}
process.env.A2A_TEST_THREAD_CONTROL = resolve(control);
const audit = join(control, "submit-caller.jsonl");

class ControlledThreadGates extends A2AGates {
  async call(raw: unknown, caller?: SubmitCaller) {
    const input = raw as Record<string, unknown>;
    if (input?.command !== "submit" || caller) return await super.call(raw, caller);
    const status = await super.call({ command: "status", task: input.task });
    const attempt = status.task?.current_attempt;
    if (!attempt?.thread_id) return await super.call(raw, caller);
    const live = await boundary("submit-begin", { thread: attempt.thread_id });
    const supplied = { thread: attempt.thread_id, turn: live.turn, assertActive: async () => {} };
    appendFileSync(audit, JSON.stringify({ at: new Date().toISOString(), pid: process.pid,
      request: raw, thread: supplied.thread, turn: supplied.turn, phase: "begin" }) + "\n");
    try {
      // Pass the socket request unchanged to the real gate. Only the external
      // thread service and its active-turn caller are supplied by this fixture.
      const result = await super.call(raw, supplied);
      appendFileSync(audit, JSON.stringify({ at: new Date().toISOString(), pid: process.pid,
        request: raw, result, phase: "result" }) + "\n");
      return result;
    } finally {
      await boundary("submit-end", { thread: attempt.thread_id });
    }
  }
}

await serve(state, {}, (root) => new ControlledThreadGates(root, runtime));
writeFileSync(ready, JSON.stringify({ pid: process.pid, root: resolve(state),
  gate: fileURLToPath(new URL("../src/gates/core.ts", import.meta.url)),
  daemon: fileURLToPath(new URL("../src/daemon.ts", import.meta.url)),
  runtime: fileURLToPath(new URL("../../acceptance/entry/native-runtime.ts", import.meta.url)),
  control: resolve(control), argv: process.argv }) + "\n", { flag: "wx" });
