"""Lifecycle adapter for the original acceptance methods; no business overrides.

The probe stage exercises delivery, interrupted verification, and controlled
thread orchestration. Product requests always use the daemon-only CLI.
"""
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
ENTRY = ROOT / "acceptance/entry/a2a_gates.py"
CLI = ROOT / "workbench/src/gates/cli.ts"
DAEMON = ROOT / "workbench/src/daemon.ts"
HOST = ROOT / "workbench/tests/daemon_acceptance_host.ts"
os.environ["COOP_SCRIPT"] = str(ENTRY)
os.environ["COOP_NATIVE_ENTRY"] = str(CLI)
sys.path.insert(0, str(ROOT / "acceptance"))
import test_coop_e2e as delivery
import test_recovery_e2e as recovery
import test_run_e2e as orchestration


class DaemonLifecycle:
    def setUp(self):
        self.daemons = []
        self.active_daemon = None
        self.host_processes = {}
        allocate = tempfile.mkdtemp
        artifact_root = Path(os.environ["COOP_E2E_ARTIFACT_ROOT"])

        def short_root(*args, **kwargs):
            if kwargs.get("dir") == str(artifact_root):
                kwargs = dict(kwargs, prefix="t-")
            return allocate(*args, **kwargs)

        # Only the fixture root allocation changes. Test names and state/repo
        # relationships remain those of the inherited acceptance helpers.
        with patch.object(delivery.tempfile, "mkdtemp", short_root):
            super().setUp()
        self.artifact = delivery.ARTIFACTS[-1]
        self.artifact["daemons"] = self.daemons
        self.artifact["lifecycle_log"] = str(self.root / "daemon-lifecycle.jsonl")
        for key in list(self.env):
            if key.startswith("A2A_") and key != "A2A_TEST_THREAD_CONTROL":
                del self.env[key]
        self.controlled = isinstance(self, orchestration.RunCLI)
        self.artifact["evidence_layer"] = (
            "isolated-orchestration" if self.controlled else "default-production-daemon")
        if not isinstance(self, recovery.RecoveryCLI):
            self.addCleanup(self.stop_daemon)
        self.start_daemon()

    def lifecycle(self, event, **value):
        record = {"at": delivery.utc_now(), "test": self.id(), "event": event, **value}
        with (self.root / "daemon-lifecycle.jsonl").open("a", encoding="utf-8") as out:
            out.write(json.dumps(record, ensure_ascii=False) + "\n")
        return record

    def cli_argv(self, command, *args):
        if command == "create" and "--project" not in args:
            args = (*args, "--project", args[args.index("--task") + 1])
        return super().cli_argv(command, *args)

    def daemon_command(self, command):
        p = self.process([sys.executable, "-B", ENTRY, "--state", self.state, command],
                         label="fixture:" + command)
        if p.returncode != 0:
            raise recovery.FixtureError("Explicit daemon command failed: " +
                                        repr({"command": command, "exit": p.returncode,
                                              "stdout": p.stdout, "stderr": p.stderr}))
        return self.parse_cli(p)

    def start_daemon(self):
        if self.active_daemon is not None:
            raise recovery.FixtureError("Fixture already owns a live daemon")
        endpoint = str(self.state.resolve() / "control.sock")
        if len(endpoint.encode("utf-8")) > 103:
            raise recovery.FixtureError("Fixture socket path exceeds 103 bytes: " + endpoint)
        record = {"generation": len(self.daemons) + 1, "state": str(self.state.resolve()),
                  "controlled_thread_service": self.controlled, "started": delivery.utc_now()}
        self.daemons.append(record)
        if self.controlled:
            prefix = self.root / ("host-%02d" % record["generation"])
            ready = prefix.with_suffix(".ready.json")
            stdout = prefix.with_suffix(".stdout")
            stderr = prefix.with_suffix(".stderr")
            argv = ["node", str(HOST), str(self.state.resolve()), str(self.boundary.resolve()), str(ready)]
            record.update({"launch_argv": argv, "ready": str(ready),
                           "stdout_path": str(stdout), "stderr_path": str(stderr)})
            with stdout.open("xb") as out, stderr.open("xb") as err:
                process = subprocess.Popen(argv, cwd=self.root, env=self.env,
                                           stdout=out, stderr=err, start_new_session=True)
            record["pid"] = process.pid
            self.host_processes[process.pid] = process
            self.active_daemon = record
            self.lifecycle("test_host_launched", **record)
            deadline = time.monotonic() + 10
            while not ready.exists():
                if process.poll() is not None or time.monotonic() >= deadline:
                    record["launch_exit"] = process.poll()
                    raise recovery.FixtureError("Test host did not become ready: " +
                                                stdout.read_text(encoding="utf-8") +
                                                stderr.read_text(encoding="utf-8"))
                time.sleep(0.02)
            announced = json.loads(ready.read_text(encoding="utf-8"))
            if announced["pid"] != process.pid or announced["root"] != record["state"]:
                raise recovery.FixtureError("Test host ready identity does not match its launch")
            record["host_ready"] = announced
        else:
            record["launch_argv"] = [sys.executable, "-B", str(ENTRY), "--state", str(self.state), "daemon_start"]
            result = self.daemon_command("daemon_start")
            record.update({"pid": result["pid"], "start_result": result})
            self.active_daemon = record
        status, observation = self.inspect_owned(record)
        record.update({"status": status, "identity_check": observation,
                       "socket_bytes": len(endpoint.encode("utf-8"))})
        self.lifecycle("daemon_ready", **record)

    def inspect_owned(self, record):
        status = self.daemon_command("daemon_status")
        pid = record["pid"]
        pid_file = self.state / "daemon.pid"
        seen = self.process(["/bin/ps", "-p", str(pid), "-o", "pid=,ppid=,command="],
                            label="fixture:confirm-owned-daemon")
        script = HOST if record["controlled_thread_service"] else DAEMON
        if (status.get("pid") != pid or status.get("root") != record["state"] or
                not pid_file.is_file() or int(pid_file.read_text(encoding="utf-8")) != pid or
                seen.returncode != 0 or str(script) not in seen.stdout or
                record["state"] not in seen.stdout or
                (pid in self.host_processes and self.host_processes[pid].poll() is not None)):
            raise recovery.FixtureError("Owned daemon identity could not be confirmed: " +
                                        repr({"record": record, "status": status, "ps": seen.stdout}))
        return status, seen.stdout

    def wait_exit(self, record):
        pid = record["pid"]
        process = self.host_processes.get(pid)
        deadline = time.monotonic() + 10
        while True:
            if process is not None:
                code = process.poll()
                if code is not None:
                    record["process_exit"] = code
                    break
            else:
                seen = self.process(["/bin/ps", "-p", str(pid), "-o", "pid=,stat=,command="],
                                    label="fixture:wait-daemon-exit")
                if seen.returncode == 1 and not seen.stdout.strip():
                    break
                if seen.returncode not in (0, 1):
                    raise recovery.FixtureError("Daemon exit observation failed: " + seen.stderr)
            if time.monotonic() >= deadline:
                raise recovery.FixtureError("Owned daemon did not exit before fixture deadline")
            time.sleep(0.05)
        record["confirmed_exited"] = delivery.utc_now()
        self.lifecycle("daemon_exit_confirmed", **record)

    def stop_daemon(self):
        record = self.active_daemon
        if record is None:
            return
        self.inspect_owned(record)
        self.daemon_command("daemon_stop")
        self.wait_exit(record)
        if (self.state / "daemon.pid").exists() or (self.state / "control.sock").exists():
            raise recovery.FixtureError("Graceful daemon stop left its endpoint or PID file")
        record["stopped"] = delivery.utc_now()
        self.active_daemon = None
        self.lifecycle("daemon_stopped", **record)

    def cleanup_fixture(self):
        # RecoveryCLI registers this bound method before its own setup. Run its
        # unchanged barrier/client cleanup before stopping the owning daemon.
        try:
            super().cleanup_fixture()
        finally:
            self.stop_daemon()

    def start_cli(self, command, *args):
        handle = super().start_cli(command, *args)
        if self.active_daemon is None:
            raise recovery.FixtureError("Async CLI has no explicitly started fixture daemon")
        handle["daemon_generation"] = self.active_daemon["generation"]
        handle["daemon_pid"] = self.active_daemon["pid"]
        self.lifecycle("cli_started", argv=handle["argv"], client_pid=handle["process"].pid,
                       daemon_generation=handle["daemon_generation"], daemon_pid=handle["daemon_pid"])
        return handle

    def wait_barrier(self, control, handle, prior=(), required=True):
        record = self.active_daemon
        if (record is None or record["generation"] != handle["daemon_generation"] or
                record["pid"] != handle["daemon_pid"]):
            raise recovery.FixtureError("Barrier belongs to a different daemon generation")
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            matches = [(path, data) for path, data in self.entries(control)
                       if str(path) not in prior and data["ppid"] == record["pid"]]
            if matches:
                path, data = matches[0]
                if handle["process"].poll() is not None:
                    raise recovery.FixtureError("Client exited before the daemon barrier was reached")
                if Path(data["release"]).resolve().parent != control.resolve():
                    raise recovery.FixtureError("Barrier release escaped its fixture control directory")
                if "candidate_directory" in data:
                    workspace = Path(data["candidate_directory"]).resolve()
                    if (self.state.resolve() / "verification") not in workspace.parents:
                        raise recovery.FixtureError("Oracle barrier is outside this fixture's verification directory")
                self.artifact["barriers"].append({"entry": str(path), **data,
                                                 "daemon_generation": record["generation"]})
                handle["barrier"] = {"entry": str(path), **data}
                self.lifecycle("barrier_reached", client_pid=handle["process"].pid,
                               daemon_generation=record["generation"], entry=str(path), data=data)
                return path, data
            if handle["process"].poll() is not None:
                if not required:
                    return None
                result = self.complete(handle)
                raise recovery.FixtureError("Daemon did not reach the controlled barrier: " +
                                            result.stdout + result.stderr)
            time.sleep(0.02)
        raise recovery.FixtureError("Daemon barrier exceeded fixture deadline")

    def kill_owned_cli(self, handle, reason):
        if reason != "active independent oracle":
            # At this probe stage only V3 injects a daemon fault. Inherited
            # teardown may still stop its confirmed owned client after releasing
            # external barriers; that is not a gate interruption or a restart.
            if reason != "cleanup of owned timed-out CLI":
                raise recovery.FixtureError("Daemon fault window is outside the current probe stage: " + reason)
            return super().kill_owned_cli(handle, reason)
        record = self.active_daemon
        barrier = handle.get("barrier")
        if (record is None or record["generation"] != handle["daemon_generation"] or
                record["pid"] != handle["daemon_pid"] or handle["process"].poll() is not None or
                not barrier or barrier["ppid"] != record["pid"]):
            raise recovery.FixtureError("Fault target does not match the active daemon and barrier")
        status, observation = self.inspect_owned(record)
        endpoint = self.state / "control.sock"
        socket_stat = endpoint.lstat()
        if not stat.S_ISSOCK(socket_stat.st_mode):
            raise recovery.FixtureError("Owned endpoint is not a Unix socket")
        evidence = {"pid": record["pid"], "signal": "SIGKILL", "signal_number": signal.SIGKILL,
                    "reason": reason, "target": "owned-daemon", "identity_check": observation,
                    "daemon_generation": record["generation"], "client_pid": handle["process"].pid,
                    "status": status, "barrier": barrier, "at": delivery.utc_now()}
        self.artifact["signals"].append(evidence)
        self.lifecycle("daemon_sigkill_requested", **evidence)
        os.kill(record["pid"], signal.SIGKILL)
        result = self.complete(handle)
        value = self.parse_cli(result)
        evidence.update({"client_exit": result.returncode, "client_result": value})
        if result.returncode == 0 or value.get("error") != "daemon_call_failed":
            raise recovery.FixtureError("Disconnected client did not report the real daemon call failure")
        self.wait_exit(record)
        # Default daemon_start is detached: no parent wait status is available.
        # Record the signal request and independent disappearance, never invent -9.
        if (int((self.state / "daemon.pid").read_text(encoding="utf-8")) != record["pid"] or
                endpoint.lstat().st_ino != socket_stat.st_ino):
            raise recovery.FixtureError("Crashed daemon endpoint ownership changed before cleanup")
        endpoint.unlink()
        (self.state / "daemon.pid").unlink()
        evidence["endpoint_cleanup"] = ["control.sock", "daemon.pid"]
        self.active_daemon = None
        self.lifecycle("crashed_endpoint_removed", **evidence)
        # This is an explicit fixture restart, not a failed business-call retry.
        self.start_daemon()


class DaemonDelivery(DaemonLifecycle, delivery.ManagedDeliveryCLI):
    pass


class DaemonRecovery(DaemonLifecycle, recovery.RecoveryCLI):
    pass


class DaemonRun(DaemonLifecycle, orchestration.RunCLI):
    pass
