#!/bin/bash
# T-075-5：只跑批准的三个探针；首个失败后停下，原输出与夹具全留。
set -euo pipefail
task_card_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_repo="$(cd -- "${task_card_dir}/../../../.." && pwd)"
cd -- "$task_repo"
exec python3 -B workbench/tests/run_daemon_acceptance.py --probe all --label "${1:-outside-probes-01}"
