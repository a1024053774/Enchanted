#!/usr/bin/env python3
"""Run the approved T-075-5 probes and retain every isolated fixture.

Use --probe all for the controller's outside-sandbox handoff. Each child probe
has its own process, source snapshot, output directory, and temporary state.
"""
import argparse
import contextlib
import datetime
import io
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / "evidence/2026-10-10-batch12/T-075/card-5"
RUNNER = Path(__file__).resolve()
IDENTITY = {
    "task": "T-075-5", "attempt": "a1", "ready_rev": 4,
    "session": "f82c11a2-4410-42fc-b9f9-24b0ad037050",
    "launch": "launch-e2dfb51e50404371bb95e477b46bbac6",
    "worker": "s12-t075-5", "real_codex_turns": 0,
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_new(path, value):
    with path.open("x", encoding="utf-8") as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write("\n")


def observe(argv):
    result = subprocess.run([str(arg) for arg in argv], cwd=ROOT,
                            text=True, capture_output=True)
    return {"argv": [str(arg) for arg in argv], "cwd": str(ROOT),
            "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


def clean_fixture_environment():
    # Do not let this worker's launch capability or commit hook reach fixture
    # clients. Original helpers still set their isolated Git configuration.
    for key in list(os.environ):
        if key.startswith("A2A_") or key.startswith("GIT_CONFIG_"):
            del os.environ[key]


def preflight(out):
    observations = [observe(["node", "--version"]), observe(["git", "--version"])]
    assertions_diff = observe(["git", "diff", "7bcfe7d9", "--",
                               "acceptance/test_coop_e2e.py", "acceptance/test_recovery_e2e.py",
                               "acceptance/test_run_e2e.py"])
    problems = []
    if not os.path.ismount("/Volumes/WD-Elements"):
        problems.append("外置盘未挂载；不安装依赖、不回退缓存")
    node = observations[0]
    if node["exit_code"] != 0 or not node["stdout"].strip().startswith("v26.5."):
        problems.append("本轮要求已核对的 Node 26.5 系列")
    if assertions_diff["exit_code"] != 0 or assertions_diff["stdout"]:
        problems.append("三份验收断言文件相对 7bcfe7d9 的 diff 必须为空")
    if not problems:
        observations.append(observe(["node", "--input-type=module", "-e",
            "import { spawnHelper } from './workbench/src/panes.ts'; console.log(spawnHelper());"]))
        if observations[-1]["exit_code"] != 0:
            problems.append("已有 node-pty helper 无法加载或执行；不自动修复依赖")
    record = {"observed_at": now(), "volume": "/Volumes/WD-Elements",
              "is_mount": os.path.ismount("/Volumes/WD-Elements"),
              "node_modules": str(ROOT / "workbench/node_modules"),
              "observations": observations, "acceptance_diff": assertions_diff,
              "problems": problems}
    write_new(out / "preflight.json", record)
    return record


def snapshot_sources(out):
    paths = sorted((ROOT / "workbench/src").rglob("*.ts"))
    paths += [ROOT / "workbench/tests" / name for name in
              ("daemon_acceptance_adapter.py", "daemon_acceptance_host.ts", "run_daemon_acceptance.py")]
    paths += [ROOT / name for name in
              ("workbench/package.json", "workbench/package-lock.json", "workbench/.npmrc",
               "acceptance/test_coop_e2e.py", "acceptance/test_recovery_e2e.py", "acceptance/test_run_e2e.py",
               "acceptance/pagination_oracle.py", "acceptance/reference/pager.py",
               "acceptance/entry/a2a_gates.py", "acceptance/entry/native-runtime.ts",
               "acceptance/entry/thread-boundary.py", "fixtures/pagination/CONTRACT.md",
               "fixtures/pagination/pager.py", ".project-map/specs/recovery-2026-10-06.md",
               ".project-map/specs/managed-delivery-2026-10-06.md",
               ".project-map/specs/supervised-run-2026-10-06.md",
               "evidence/2026-10-10-batch12/T-075/card-5/controller-decision-01.md")]
    captured = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    with tarfile.open(out / "sources.tar.gz", "x:gz") as archive:
        for name, data in captured.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            archive.addfile(entry, io.BytesIO(data))
    write_new(out / "source-manifest.json", {"paths": list(captured),
              "head": observe(["git", "rev-parse", "HEAD"]),
              "diff": observe(["git", "diff", "--", "workbench/src/daemon.ts"]),
              "skills": ["project-map", "reality-first-engineering", "evidence-first-testing", "document-writing"]})
    return captured


def read_state(artifacts):
    observations = []
    for artifact in artifacts:
        database = Path(artifact["state"]) / "state.sqlite3"
        if not database.is_file():
            observations.append({"test": artifact["test"], "database": str(database), "exists": False})
            continue
        with sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True) as db:
            db.row_factory = sqlite3.Row
            tables = {}
            for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
                name = row[0]
                quoted = '"' + name.replace('"', '""') + '"'
                tables[name] = [dict(item) for item in db.execute("SELECT * FROM " + quoted)]
        observations.append({"test": artifact["test"], "database": str(database), "tables": tables})
    return observations


def run_probe(probe, out):
    record = {**IDENTITY, "status": "INCOMPLETE", "probe": probe,
              "started": now(), "argv": sys.argv, "cwd": str(ROOT), "python": sys.version}
    check = preflight(out)
    if check["problems"]:
        record.update({"classification": "preflight-error", "problems": check["problems"], "exit_code": 2})
        write_new(out / "run.json", record)
        print(json.dumps(record, ensure_ascii=False))
        return 2
    sources = snapshot_sources(out)
    artifact_root = Path(tempfile.mkdtemp(prefix="a5-", dir="/tmp"))
    os.environ["COOP_E2E_ARTIFACT_ROOT"] = str(artifact_root)
    os.environ["COOP_E2E_TRACE"] = str(artifact_root / "subprocess-trace.json")
    import daemon_acceptance_adapter as adapter

    if probe == "delivery":
        cls = adapter.DaemonDelivery
        names = ["test_good_candidate_uses_oracle_snapshot_and_integrates_once"]
        original = adapter.delivery.ManagedDeliveryCLI
        result_class = unittest.TextTestResult
    elif probe == "recovery":
        cls = adapter.DaemonRecovery
        names = ["test_interrupted_verify_gets_new_id_worktree_and_full_oracle"]
        original = adapter.recovery.RecoveryCLI
        result_class = adapter.recovery.EvidenceResult
    else:
        cls = adapter.DaemonRun
        names = ["test_fixture_existing_dispatch_submit_oracle_integration_and_reclaim",
                 "test_run_entry_point_completes_registered_task"]
        original = adapter.orchestration.RunCLI
        result_class = adapter.orchestration.EvidenceResult
    for name in names:
        if getattr(cls, name) is not getattr(original, name):
            raise RuntimeError("Probe replaced an original business method: " + name)
    suite = unittest.TestSuite(cls(name) for name in names)
    with (out / "stdout.txt").open("x", encoding="utf-8") as stdout, \
            (out / "stderr.txt").open("x", encoding="utf-8") as stderr:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            result = unittest.TextTestRunner(verbosity=2, resultclass=result_class).run(suite)
    original_results = (adapter.orchestration.TEST_RESULTS if probe == "run" else
                        adapter.recovery.TEST_RESULTS if probe == "recovery" else [])
    record.update({"finished": now(), "tests_run": result.testsRun,
                   "failures": len(result.failures), "errors": len(result.errors),
                   "skipped": len(result.skipped), "original_results": original_results,
                   "failure_text": [{"test": test.id(), "traceback": text} for test, text in result.failures],
                   "error_text": [{"test": test.id(), "traceback": text} for test, text in result.errors],
                   "selected_original_methods": names,
                   "original_source": str(Path(sys.modules[original.__module__].__file__).relative_to(ROOT)),
                   "entry": str(adapter.ENTRY), "cli": str(adapter.CLI),
                   "evidence_layer": "isolated-orchestration" if probe == "run" else "default-production-daemon",
                   "artifact_root": str(artifact_root), "commands": adapter.delivery.COMMANDS,
                   "assertions": adapter.recovery.ASSERTIONS, "artifacts": adapter.delivery.ARTIFACTS,
                   "head_after": observe(["git", "rev-parse", "HEAD"]),
                   "limitations": ["本轮只验证三个探针，未跑 8/9/18 全量或三个变异体。",
                                    "run 两项为隔离线程服务，不证明真实 PTY、Codex 或 B 转交通道。"]})
    changed = [name for name, data in sources.items()
               if not (ROOT / name).is_file() or (ROOT / name).read_bytes() != data]
    record["changed_source_paths"] = changed
    passed = result.wasSuccessful() and not changed and result.testsRun == len(names) and not result.skipped
    record["status"] = "PASS" if passed else "INCOMPLETE"
    record["exit_code"] = 0 if passed else 1
    write_new(out / "state-readback.json", read_state(adapter.delivery.ARTIFACTS))
    with tarfile.open(out / "artifacts.tar.gz", "x:gz") as archive:
        archive.add(artifact_root, arcname=artifact_root.name)
    write_new(out / "run.json", record)
    print(json.dumps({key: record[key] for key in
                     ("task", "probe", "status", "tests_run", "failures", "errors", "exit_code", "artifact_root")},
                     ensure_ascii=False))
    return record["exit_code"]


def run_all(label, out):
    record = {**IDENTITY, "status": "INCOMPLETE", "started": now(),
              "argv": sys.argv, "cwd": str(ROOT), "probes": []}
    code = 0
    for probe in ("delivery", "recovery", "run"):
        child_label = label + "-" + probe
        argv = [sys.executable, "-B", str(RUNNER), "--probe", probe, "--label", child_label]
        result = observe(argv)
        (out / (probe + ".stdout.txt")).write_text(result["stdout"], encoding="utf-8")
        (out / (probe + ".stderr.txt")).write_text(result["stderr"], encoding="utf-8")
        result.update({"probe": probe, "output": str(BASE / child_label)})
        record["probes"].append(result)
        write_new(out / (probe + ".command.json"), result)
        print(result["stdout"], end="")
        if result["exit_code"] != 0:
            code = result["exit_code"]
            break
    record.update({"finished": now(), "status": "PASS" if code == 0 else "INCOMPLETE",
                   "exit_code": code, "stopped_after_failure": code != 0,
                   "scope": "三个探针、四个原测试方法；不是全量验收"})
    write_new(out / "run.json", record)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", choices=("all", "delivery", "recovery", "run"), required=True)
    parser.add_argument("--label", required=True, help="card-5 下尚未存在的证据目录名")
    args = parser.parse_args()
    if (not args.label or args.label in (".", "..") or
            any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_." for char in args.label)):
        parser.error("label 只能包含字母、数字、点、短横线和下划线")
    out = BASE / args.label
    out.mkdir(exist_ok=False)
    clean_fixture_environment()
    return run_all(args.label, out) if args.probe == "all" else run_probe(args.probe, out)


if __name__ == "__main__":
    raise SystemExit(main())
