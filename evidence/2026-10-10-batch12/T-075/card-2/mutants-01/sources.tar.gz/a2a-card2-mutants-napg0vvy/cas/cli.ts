// Derived from Synara, MIT License.
// Copyright (c) 2026 T3 Tools Inc.
// Copyright (c) 2026 Emanuele Di Pietro
// See ../../LICENSE.synara for the full permission notice.

import { parseArgs } from "node:util";
import { A2AGates, Refusal, type GateRuntime } from "./core.ts";

const commands: Record<string, { required: string[]; optional?: string[] }> = {
  card_template: { required: ["repo"], optional: ["ticket", "project"] },
  card_validate: { required: ["card"] },
  card_save: { required: ["card", "expected-version"] },
  card_show: { required: ["card-version"] },
  create: { required: ["repo", "branch", "card-version"], optional: ["project", "title"] },
  dispatch: { required: ["runtime-mode"] },
  attach: {
    required: ["role", "model-selection", "instructions", "runtime-mode"],
    optional: ["preset"],
  },
  run: { required: ["runtime-mode", "wait-seconds"] },
  claim: { required: ["owner"] },
  revoke: { required: ["reason"] },
  revise: { required: ["spec-rev"], optional: ["card-version"] },
  submit: { required: ["attempt", "session", "fence", "spec-rev", "commit"] },
  verify: { required: [], optional: ["attempt"] },
  integrate: { required: [], optional: ["attempt"] },
  status: { required: [] },
  events: { required: [] },
  issues: { required: [], optional: ["thread"] },
  answer_issue: { required: ["issue", "answer"] },
  answer_issues: { required: ["answers"], optional: ["mode"] },
  disposition: { required: ["issue", "action"], optional: ["reason", "basis"] },
  reclaim: { required: [], optional: ["attempt", "thread"] },
  inbox_send: {
    required: ["from", "to", "kind", "body"],
    optional: ["reply-to", "refs", "title", "blocking", "action", "reason", "basis", "bundle-id"],
  },
  inbox_list: { required: ["role"] },
  inbox_ack: { required: ["role", "id"], optional: ["body"] },
  stop: { required: ["thread", "stop-id"] },
};

async function emit(result: unknown) {
  await new Promise<void>((resolve, reject) => {
    process.stdout.write(JSON.stringify(result) + "\n", (error) =>
      error ? reject(error) : resolve(),
    );
  });
}

export async function main(argv = process.argv.slice(2), runtime?: GateRuntime) {
  let root: string;
  let request: Record<string, unknown>;
  try {
    const keys = [
      "state",
      "task",
      "repo",
      "project",
      "title",
      "thread",
      "role",
      "model-selection",
      "runtime-mode",
      "wait-seconds",
      "branch", "card", "ticket", "card-version", "expected-version",
      "instructions",
      "owner",
      "reason",
      "attempt",
      "session",
      "fence",
      "spec-rev",
      "commit",
      "issue",
      "answer",
      "answers",
      "mode",
      "action",
      "basis",
      "preset",
      "from",
      "to",
      "kind",
      "body",
      "reply-to",
      "refs",
      "blocking",
      "id",
      "bundle-id",
      "stop-id",
    ];
    const { values, positionals } = parseArgs({
      args: argv,
      options: Object.fromEntries(keys.map((key) => [key, { type: "string" as const }])),
      allowPositionals: true,
    });
    const command = positionals[0] ?? "";
    const contract = commands[command];
    const inbox = command.startsWith("inbox_") || command === "stop";
    if (!contract || positionals.length !== 1 || !values.state || (!inbox && !values.task))
      throw new Error("state, command and task required");
    const allowed = [
      "state",
      ...(!inbox ? ["task"] : []),
      ...contract.required,
      ...(contract.optional ?? []),
    ];
    if (
      Object.keys(values).some((key) => !allowed.includes(key)) ||
      contract.required.some((key) => values[key] === undefined)
    )
      throw new Error("invalid command arguments");
    root = values.state;
    request = { command };
    for (const [key, value] of Object.entries(values)) {
      if (key === "state") continue;
      if (["fence", "spec-rev", "wait-seconds", "card-version", "expected-version"].includes(key)) {
        if (
          typeof value !== "string" ||
          !/^[+-]?\d+$/.test(value) ||
          !Number.isSafeInteger(Number(value))
        )
          throw new Error("integer required: " + key);
        request[key.replaceAll("-", "_")] = Number(value);
      } else if (key === "model-selection") request.modelSelection = JSON.parse(value!);
      else if (key === "answers") request.answers = JSON.parse(value!);
      else if (key === "refs") request.refs = JSON.parse(value!);
      else if (key === "blocking") {
        if (value !== "true" && value !== "false") throw new Error("boolean required: blocking");
        request.blocking = value === "true";
      } else if (["reply-to", "bundle-id", "stop-id"].includes(key))
        request[key.replaceAll("-", "_")] = value;
      else request[key === "runtime-mode" ? "runtimeMode" : key] = value;
    }
  } catch (error) {
    console.error("usage: --state ABS_DIR COMMAND --task ID ...\n" + String(error));
    return 2;
  }
  let gates: A2AGates;
  try {
    gates = new A2AGates(root, runtime);
  } catch (error) {
    await emit({
      ok: false,
      error: error instanceof Refusal ? error.code : "local_io_failed",
      details: String(error),
    });
    return 1;
  }
  try {
    const result = await gates.call(request);
    await emit(result);
    return result.ok ? 0 : 1;
  } finally {
    gates.close();
  }
}
if (import.meta.main) process.exitCode = await main();
