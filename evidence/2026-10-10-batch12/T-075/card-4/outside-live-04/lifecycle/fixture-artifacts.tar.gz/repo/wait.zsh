#!/bin/zsh
set -eu
/bin/sleep 90
