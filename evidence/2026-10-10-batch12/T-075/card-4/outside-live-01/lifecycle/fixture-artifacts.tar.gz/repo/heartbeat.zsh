#!/bin/zsh
set -eu
for ((n=1; n<=1200; n++)); do
  printf "A2A-LIVE-dcb83be72f55 %06d 中文 ✓ done accepted idle\n" "$n"
  print -r -- "$n" >> heartbeat.progress
  sleep 0.25
done
