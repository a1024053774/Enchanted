// Test process only. It loads the built product and observes its actual IPC replies.
import { app, ipcMain } from 'electron';
import { appendFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';

const { values } = parseArgs({ args: process.argv.slice(2), options: Object.fromEntries(
  ['build', 'state', 'task', 'launch', 'user-data', 'output'].map((key) => [key, { type: 'string' }])) });
const output = values.output;
mkdirSync(output);
const build = JSON.parse(readFileSync(join(values.build, 'build.json'), 'utf8'));
const originalHandle = ipcMain.handle.bind(ipcMain);
ipcMain.handle = (channel, handler) => originalHandle(channel, async (...args) => {
  const value = await handler(...args);
  if (channel === 'a2a:output') appendFileSync(join(output, 'received.ndjson'), JSON.stringify(value) + '\n');
  if (channel === 'a2a:snapshot') appendFileSync(join(output, 'snapshots.ndjson'), JSON.stringify(value) + '\n');
  return value;
});
const { run } = await import(pathToFileURL(build.main).href);
const window = await run({ state: values.state, task: values.task, launch: values.launch, userData: values['user-data'] });
window.webContents.on('console-message', (_event, ...details) => appendFileSync(join(output, 'console.ndjson'), JSON.stringify(details) + '\n'));
const inspect = () => window.webContents.executeJavaScript(`({
  text: document.body.innerText,
  offset: Number(document.querySelector('[data-output-offset]')?.dataset.outputOffset ?? 0),
  state: document.querySelector('[data-state]')?.dataset.state,
  lifecycle: document.querySelector('[data-lifecycle]')?.dataset.lifecycle,
  gate: document.querySelector('[data-gate-state]')?.dataset.gateState,
  terminal: [...document.querySelectorAll('.xterm-accessibility-tree [role="listitem"]')].map(x => x.textContent).join('\\n'),
  bridge: Object.keys(window.a2a),
  node: typeof window.require
})`);
const reply = (value) => process.stdout.write(JSON.stringify(value) + '\n');
reply({ ready: true, pid: process.pid });
let pending = Promise.resolve();
createInterface({ input: process.stdin }).on('line', (line) => {
  pending = pending.then(async () => {
    const request = JSON.parse(line);
    let value;
    if (request.command === 'inspect') value = await inspect();
    else if (request.command === 'capture') {
      if (!/^[a-zA-Z0-9_-]+$/.test(request.name)) throw new Error('Invalid capture name');
      await window.webContents.executeJavaScript('new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))');
      const picture = await window.webContents.capturePage();
      writeFileSync(join(output, request.name + '.png'), picture.toPNG(), { flag: 'wx' });
      value = await inspect();
      writeFileSync(join(output, request.name + '.json'), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
    } else if (request.command === 'readonly-input') {
      window.focus();
      await window.webContents.executeJavaScript("document.querySelector('.xterm-helper-textarea').focus()");
      window.webContents.sendInputEvent({ type: 'char', keyCode: 'Z' });
      window.webContents.sendInputEvent({ type: 'keyDown', keyCode: 'Enter' });
      window.webContents.sendInputEvent({ type: 'keyUp', keyCode: 'Enter' });
      // Use a local synthetic ClipboardEvent; never replace the user's clipboard.
      await window.webContents.executeJavaScript(`(() => { const data = new DataTransfer(); data.setData('text/plain', 'READ_ONLY_SENTINEL');
        document.querySelector('.xterm-helper-textarea').dispatchEvent(new ClipboardEvent('paste', { clipboardData: data, bubbles: true })); })()`);
      value = { sent: true };
    } else if (request.command === 'reconnect') {
      await window.webContents.executeJavaScript("[...document.querySelectorAll('button')].find(x => x.textContent === '重新连接').click()");
      value = { clicked: true };
    } else if (request.command === 'close') {
      reply({ id: request.id, ok: true }); window.close(); return;
    } else throw new Error('Unknown driver command');
    reply({ id: request.id, ok: true, value });
  }).catch((error) => { reply({ ok: false, error: String(error) }); app.exit(1); });
});
