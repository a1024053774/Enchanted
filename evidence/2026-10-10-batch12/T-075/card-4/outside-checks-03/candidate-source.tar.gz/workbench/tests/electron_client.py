"""A bounded driver client; all UI operations occur in this probe's Electron process."""
import json
from pathlib import Path
import selectors
import subprocess
import time


class ElectronClient:
    def __init__(self, source, build, state, task, user_data, output, env, launch=None):
        self.output = output
        self.output.parent.mkdir(parents=True, exist_ok=True)
        relative = (source / 'workbench/node_modules/electron/path.txt').read_text().strip()
        # macOS rejected the app bundle reached through the source fixture's
        # node_modules link (checks-01/02). Launch the installed bundle itself.
        binary = (source / 'workbench/node_modules/electron/dist' / relative).resolve(strict=True)
        argv = [str(binary), str(source / 'workbench/tests/electron_driver.mjs'),
                '--build', str(build), '--state', str(state), '--task', task,
                '--user-data', str(user_data), '--output', str(output)]
        if launch:
            argv += ['--launch', launch]
        self.log = output.parent / (output.name + '-driver.jsonl')
        self.stderr = (output.parent / (output.name + '-stderr.txt')).open('x', encoding='utf-8')
        self.process = subprocess.Popen(argv, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=self.stderr, text=True, bufsize=1, start_new_session=True)
        self.sequence = 0
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.process.stdout, selectors.EVENT_READ)
        self.record({'argv': argv, 'pid': self.process.pid})
        try:
            ready = self.receive(30)
            assert ready.get('ready') is True, ready
        except Exception as error:
            self.record({'startup_error': repr(error), 'owned_pid': self.process.pid})
            try:
                if self.process.poll() is None:
                    self.process.terminate()
                    self.process.wait(timeout=10)
            finally:
                self.selector.close()
                self.stderr.close()
            raise

    def record(self, value):
        with self.log.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(value, ensure_ascii=False) + '\n')

    def receive(self, timeout):
        if not self.selector.select(timeout):
            raise TimeoutError('Electron response deadline')
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError('Electron exited before responding')
        self.record({'response': line})
        return json.loads(line)

    def call(self, command, **values):
        self.sequence += 1
        request = dict(id=self.sequence, command=command, **values)
        self.record({'request': request})
        self.process.stdin.write(json.dumps(request) + '\n')
        self.process.stdin.flush()
        result = self.receive(30)
        assert result.get('id') == self.sequence and result.get('ok') is True, result
        return result.get('value')

    def wait(self, predicate, timeout=30):
        end = time.monotonic() + timeout
        while True:
            value = self.call('inspect')
            if predicate(value):
                return value
            if time.monotonic() >= end:
                raise AssertionError({'electron_observation_deadline': value})
            time.sleep(0.1)

    def close(self):
        try:
            if self.process.poll() is None:
                self.call('close')
                self.process.wait(timeout=10)
            assert self.process.returncode == 0, self.process.returncode
        finally:
            self.selector.close()
            self.stderr.close()
