def normalize(rows):
    if not isinstance(rows, list):
        raise ValueError("invalid_name")

    totals = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("invalid_name")

        name = row.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("invalid_name")
        name = name.strip()

        minutes = row.get("minutes")
        if isinstance(minutes, bool) or not isinstance(minutes, int) or minutes < 0:
            raise ValueError("invalid_minutes")

        totals[name] = totals.get(name, 0) + minutes

    entries = []
    for name in sorted(totals):
        minutes = totals[name]
        hours, remainder = divmod(minutes, 60)
        entries.append({
            "name": name,
            "minutes": minutes,
            "duration": f"{hours}:{remainder:02d}",
        })

    return {"entries": entries, "total_minutes": sum(totals.values())}
