#!/usr/bin/env python3
"""One real interactive Codex turn. The controller runs this outside the sandbox."""
import argparse
import datetime
import fcntl
import json
import os
from pathlib import Path
import shlex
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import uuid


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    args.output.mkdir(parents=True, exist_ok=False)
    output = args.output.resolve()
    temp = Path(tempfile.mkdtemp(prefix='a2a-t0753-', dir='/tmp')).resolve()
    repo, state, isolated = temp / 'fixture', temp / 'state', temp / 'codex-home'
    repo.mkdir(); isolated.mkdir(mode=0o700)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('A2A_', 'GIT_', 'CODEX_'))}
    env.update(GIT_AUTHOR_NAME='T0753 fixture', GIT_AUTHOR_EMAIL='fixture@example.invalid',
               GIT_COMMITTER_NAME='T0753 fixture', GIT_COMMITTER_EMAIL='fixture@example.invalid')
    commands = []
    started = False
    cleanup_pids = set()
    verdict = {'status': 'INCOMPLETE', 'root': str(temp), 'real_turns_reserved': 0, 'stage': 'setup'}

    def save(name, value):
        (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def run(argv, *, check=True, command_env=None, timeout=30):
        p = subprocess.run([str(x) for x in argv], cwd=root, env=command_env or env,
                           text=True, capture_output=True, timeout=timeout)
        commands.append({'argv': [str(x) for x in argv], 'cwd': str(root), 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
        save('commands.json', commands)
        if check and p.returncode:
            raise RuntimeError(f'Command failed: {argv!r}: {p.stderr or p.stdout}')
        return p

    cli = ['node', root / 'workbench/src/gates/cli.ts', '--state', state]

    def call(command, *values, check=True):
        p = run([*cli, command, *values], check=check)
        return json.loads(p.stdout)

    try:
        if not Path('/Volumes/WD-Elements').is_mount():
            raise RuntimeError('外置盘未挂载；不回退缓存')
        git_env = dict(env, GIT_CONFIG_COUNT='2', GIT_CONFIG_KEY_0='core.hooksPath', GIT_CONFIG_VALUE_0='/dev/null',
                       GIT_CONFIG_KEY_1='commit.gpgsign', GIT_CONFIG_VALUE_1='false')
        run(['git', 'init', '-b', 'main', repo], command_env=git_env)
        (repo / 'input.txt').write_text('socket probe baseline\n', encoding='utf-8')
        run(['git', '-C', repo, 'add', 'input.txt'], command_env=git_env)
        run(['git', '-C', repo, 'commit', '-m', 'Probe baseline'], command_env=git_env)
        baseline = run(['git', '-C', repo, 'rev-parse', 'HEAD']).stdout.strip()
        # Auth is the only copied file. Do not print it or include this directory in evidence.
        shutil.copyfile(Path.home() / '.codex/auth.json', isolated / 'auth.json')
        (isolated / 'auth.json').chmod(0o600)
        (isolated / 'config.toml').write_text(f'[projects.{json.dumps(str(repo))}]\ntrust_level="trusted"\n', encoding='utf-8')
        (isolated / 'rules').mkdir()
        (isolated / 'rules/default.rules').write_text('prefix_rule(pattern=["git", "add"], decision="allow")\nprefix_rule(pattern=["git", "commit"], decision="allow")\n', encoding='utf-8')
        codex = Path(shutil.which('codex')).resolve()
        config = {'codex_bin': str(codex), 'codex_home': str(isolated),
                  'role_card': str(root / '.project-map/roles/worker.md'),
                  'role_card_revision': run(['git', 'log', '-1', '--format=%H', '--', '.project-map/roles/worker.md']).stdout.strip(),
                  'code_revision': run(['git', 'rev-parse', 'HEAD']).stdout.strip(),
                  'source_snapshot': str(output.parent / 'workbench-source.tar.gz'),
                  'hook_authorization': 'T-075-3 controller-decision-01 sections 3 and 4', 'turn_limit': 1}
        save('launch-config.json', config)
        # Save all changed source, including untracked production files, beside the exact revision.
        run(['git', 'diff', '--', 'workbench/'])
        save('setup.json', {'root': str(temp), 'fixture': str(repo), 'state': str(state), 'codex_home': str(isolated),
                            'baseline': baseline, 'controller_initial_release': True,
                            'hooks': ['UserPromptSubmit', 'Stop', 'PermissionRequest'], 'main_turn_limit': 1})
        start = call('daemon_start', '--launch-config', output / 'launch-config.json')
        if not start['ok']:
            raise RuntimeError(start)
        started = True
        cleanup_pids.add(start['pid'])
        run(['/bin/ps', '-o', 'pid=,ppid=,pgid=,sess=', '-p', str(start['pid'])])
        challenge = 't0753-' + uuid.uuid4().hex
        command = shlex.join([str(shutil.which('node')), str(root / 'workbench/src/gates/cli.ts'), '--state', str(state), 'probe', '--challenge', challenge])
        task = 'T0753-socket-1'
        card = {'id': task, 'source': None,
                'goal': '先执行且只执行一次这条普通沙箱命令：\n' + command +
                        '\n不要使用 require_escalated。若连接失败，立即停止，不重试、不换传输、不修改权限、不提交。'
                        '若成功，将该命令的 stdout JSON 原样保存为 probe-result.json，然后 git add、git commit，并使用派发末尾的后台 submit 命令交付。'
                        '只用一轮完成。不要启动子 agent，不运行任何其他探针。',
                'non_goals': ['不改 input.txt，不改验收，不读凭据，不访问真实项目数据'],
                'paths': {'allow': ['probe-result.json'], 'deny': ['input.txt']},
                'completion_conditions': [{'argv': [sys.executable, '-I', '-B', '-c',
                    "import json; from pathlib import Path; x=json.loads(Path('probe-result.json').read_text()); assert x['ok'] is True; assert x['challenge']==" + repr(challenge)]}],
                'red_commands': [], 'task_type': '后端逻辑', 'repair_target': None, 'complexity': 'M',
                'executor': {'cli': 'Codex', 'model': 'gpt-6-astra', 'effort': 'xhigh'}, 'base_commit': None, 'writer': None}
        save('probe-card.json', card)
        call('card_save', '--task', task, '--card', output / 'probe-card.json', '--expected-version', '0')
        call('create', '--task', task, '--repo', repo, '--branch', 'refs/heads/main', '--card-version', '1', '--project', 'T0753-probe')
        result = call('dispatch', '--task', task, '--runtime-mode', 'workspace-write')
        attempt = result['attempt']; thread = attempt['thread_id']
        save('attempt.json', attempt)
        pane = call('pane_status', '--thread', thread)
        save('launch-record.json', call('launch_show', '--launch', pane['launch']))
        # Waiting for an OS fact is not an idle inference. There is no blind Enter.
        deadline = time.monotonic() + 30
        while True:
            info = call('pane_process_info', '--thread', thread)
            if info.get('leader') and not info.get('failed'):
                break
            if info.get('failed') or time.monotonic() >= deadline:
                raise RuntimeError({'foreground_codex_unconfirmed': info})
            time.sleep(0.25)
        save('before-release.json', info)
        cleanup_pids.update(row['pid'] for row in info['processes'])
        # Reservations survive failed/interrupted runs and new labels. Never
        # reset the card's total by creating a fresh CODEX_HOME or database.
        with (output.parents[1] / 'turn-budget.jsonl').open('a+', encoding='utf-8') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            stream.seek(0)
            previous = [json.loads(line) for line in stream if line.strip()]
            if sum(row['reserved'] for row in previous) >= 10:
                raise RuntimeError('T-075-3 已到 10 个真实主 turn 的保守上限')
            reservation = {'reserved': 1, 'output': str(output), 'launch': pane['launch'],
                           'at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            stream.seek(0, 2); stream.write(json.dumps(reservation) + '\n'); stream.flush(); os.fsync(stream.fileno())
        verdict['real_turns_reserved'] = 1
        verdict['stage'] = 'one-real-turn'
        save('verdict.json', verdict)
        call('pane_release', '--thread', thread, '--reason', '执行主控按决定 01 核对前台领导进程后首次放行')
        deadline = time.monotonic() + 300
        while True:
            pane = call('pane_status', '--thread', thread)
            if pane.get('failed'):
                raise RuntimeError({'pane_failed': pane})
            if pane.get('state') == 'idle':
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('主回合期限已到，结果未知；不追加输入、不重试')
            time.sleep(1)
        status = call('status', '--task', task)
        events = call('orchestration_events', '--task', task)
        save('orchestration-events.json', events)
        receipts = [r for r in events['events'] if r['type'] == 'sandbox_probe' and r['data']['challenge'] == challenge]
        if len(receipts) != 1:
            raise RuntimeError('沙箱入口未得到唯一回执；需要主控决定，不能绕路')
        if status['task']['state'] != 'submitted':
            raise RuntimeError({'probe_reached_but_delivery_incomplete': status})
        call('verify', '--task', task, '--attempt', attempt['attempt_id'])
        before = run(['git', '-C', repo, 'rev-parse', 'refs/heads/main']).stdout.strip()
        integration = call('integrate', '--task', task, '--attempt', attempt['attempt_id'])
        after = run(['git', '-C', repo, 'rev-parse', 'refs/heads/main']).stdout.strip()
        if before != baseline or after != integration['task']['verification']['M'] or before == after:
            raise RuntimeError('独立 Git 引用不匹配')
        save('git-readback.json', {'G': before, 'M': after})
        save('gate-events.json', call('events', '--task', task))
        verdict.update(status='PASS', stage='sandbox-probe-and-thin-delivery', G=before, M=after)
        # This probe is not the later medium-complexity, divergent-G acceptance.
    except (OSError, ValueError, KeyError, AssertionError, RuntimeError, subprocess.TimeoutExpired) as error:
        verdict.update(status='BLOCKED', error=str(error))
    finally:
        if started:
            try:
                if 'thread' in locals():
                    final_info = call('pane_process_info', '--thread', thread)
                    cleanup_pids.update(row['pid'] for row in final_info['processes'])
                    save('before-stop-processes.json', final_info)
                save('all-events-before-stop.json', call('orchestration_events'))
                stopped = call('daemon_stop', check=False)
                save('stop.json', stopped)
                if not stopped.get('ok'):
                    verdict.update(status='BLOCKED', cleanup_error=stopped)
            except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
                verdict.update(status='BLOCKED', cleanup_error=str(error))
            deadline = time.monotonic() + 10
            while (state / 'daemon.pid').exists() and time.monotonic() < deadline:
                time.sleep(0.1)
        # The isolated home is never copied. Archive only recorded runtime facts.
        if state.exists():
            for name in ('daemon.stdout.log', 'daemon.stderr.log'):
                if (state / name).exists():
                    shutil.copyfile(state / name, output / name)
            if (state / 'state.sqlite3').exists():
                source = sqlite3.connect(f'file:{state / "state.sqlite3"}?mode=ro', uri=True)
                dest = sqlite3.connect(output / 'state.sqlite3')
                source.backup(dest); dest.close(); source.close()
        remaining = run(['/bin/ps', '-o', 'pid=,ppid=,pgid=,command=', '-p', ','.join(map(str, sorted(cleanup_pids)))], check=False) if cleanup_pids else None
        if (state / 'daemon.pid').exists() or (remaining and remaining.stdout.strip()):
            verdict.update(status='BLOCKED', cleanup_error='后台或观测过的进程尚未确认退出，保留隔离 home 等主控核对')
        else:
            shutil.rmtree(isolated)
        save('verdict.json', verdict)
    print(json.dumps(verdict, ensure_ascii=False, indent=2))
    return 0 if verdict['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
