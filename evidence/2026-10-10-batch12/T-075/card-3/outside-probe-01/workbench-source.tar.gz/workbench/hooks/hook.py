#!/usr/bin/env python3
"""Read the bound launch from the daemon and add the nine specified trailers."""
import json
import os
from pathlib import Path
import subprocess
import sys


def add_trailers():
    env = os.environ
    reply = subprocess.run([env['A2A_NODE'], env['A2A_CLI'], '--state', env['A2A_STATE'],
                            'launch_show', '--launch', env['A2A_LAUNCH']], check=True,
                           capture_output=True, text=True)
    value = json.loads(reply.stdout)
    if not value.get('ok'):
        raise ValueError('启动记录不可用')
    launch = value['launch']
    for field in ('project', 'task', 'attempt', 'session', 'role'):
        if launch[field] != env['A2A_' + field.upper()]:
            raise ValueError('环境身份不匹配：' + field)
    native = env['CODEX_THREAD_ID']
    if not native or native != value['native_session']:
        raise ValueError('原生会话不匹配')
    trailers = {'A2A-Task': launch['task'], 'A2A-Attempt': launch['attempt'],
                'A2A-Session': launch['session'], 'A2A-Role': launch['role'],
                'A2A-Tool': launch['cli_version'], 'A2A-Model': value['model'],
                'A2A-Effort': value['effort'], 'A2A-Native-Session': native,
                'A2A-Launch': launch['id']}
    message = sys.argv[1]
    parsed = subprocess.check_output(['git', 'interpret-trailers', '--parse', '--no-divider', message], text=True)
    counts = {key.lower(): 0 for key in trailers}
    for line in parsed.splitlines():
        key = line.partition(':')[0].strip().lower()
        if key in counts:
            counts[key] += 1
    for _ in range(max(counts.values(), default=0)):
        clear = ['git', 'interpret-trailers', '--in-place', '--no-divider', '--trim-empty',
                 '--if-exists', 'replace', '--if-missing', 'doNothing']
        for key in trailers:
            clear += ['--trailer', key + ': ']
        subprocess.run([*clear, message], check=True)
    argv = ['git', 'interpret-trailers', '--in-place', '--no-divider', '--if-exists', 'replace']
    for key, content in trailers.items():
        if not content or '\n' in content or '\r' in content:
            raise ValueError('尾注值不合法：' + key)
        argv += ['--trailer', key + ': ' + content]
    subprocess.run([*argv, message], check=True)


def forward():
    # Run the repository's existing hook without writing its config.
    name = Path(sys.argv[0]).name
    original_env = dict(os.environ)
    if original_env.get('GIT_CONFIG_COUNT') != '1' or original_env.get('GIT_CONFIG_KEY_0') != 'core.hooksPath':
        raise ValueError('会话 Git 配置改变')
    for key in ('GIT_CONFIG_COUNT', 'GIT_CONFIG_KEY_0', 'GIT_CONFIG_VALUE_0'):
        original_env.pop(key)
    original = Path(subprocess.check_output(['git', 'rev-parse', '--git-path', 'hooks/' + name],
                                          env=original_env, text=True).strip()).resolve()
    if original == Path(__file__).resolve():
        raise ValueError('原钩子递归')
    if original.is_file() and os.access(original, os.X_OK):
        subprocess.run([str(original), *sys.argv[1:]], check=True)


if __name__ == '__main__':
    try:
        if Path(sys.argv[0]).name == 'prepare-commit-msg':
            add_trailers()
        forward()
    except (OSError, KeyError, ValueError, subprocess.CalledProcessError) as error:
        print('a2a 提交钩子拒绝：' + str(error), file=sys.stderr)
        sys.exit(1)
