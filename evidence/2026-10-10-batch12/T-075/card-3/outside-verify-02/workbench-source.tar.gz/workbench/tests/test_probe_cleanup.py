#!/usr/bin/env python3
"""Run the probe's actual finally body without launching a model or a daemon.

Failure cases: an existing backup is overwritten; backup failure prevents home
cleanup; an unconfirmed live daemon's home is deleted. Existing output and
failure evidence must survive each case.
"""
import argparse
import ast
import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    source = Path(__file__).with_name('probe_worker_socket.py')
    module = ast.parse(source.read_text(encoding='utf-8'))
    body = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    final = next(node.finalbody for node in body.body if isinstance(node, ast.Try) and node.finalbody)
    spec = importlib.util.spec_from_file_location('probe', source)
    probe = importlib.util.module_from_spec(spec); spec.loader.exec_module(probe)
    evidence = []
    for case in ('backup-error', 'existing-backup', 'live-daemon'):
        root = Path(tempfile.mkdtemp(prefix='a2a-cleanup-', dir='/tmp'))
        state = root / 'state'; output = root / 'output'; isolated = root / 'codex-home'
        for p in (state, output, isolated): p.mkdir()
        (isolated / 'fixture-marker').write_text('isolated data', encoding='utf-8')
        with sqlite3.connect(state / 'state.sqlite3') as db:
            db.execute('CREATE TABLE fixture(value TEXT)'); db.execute("INSERT INTO fixture VALUES ('source')")
        dest = output / 'state.sqlite3'
        if case == 'backup-error': dest.mkdir()
        if case == 'existing-backup':
            with sqlite3.connect(dest) as db:
                db.execute('CREATE TABLE sentinel(value TEXT)'); db.execute("INSERT INTO sentinel VALUES ('original')")
        if case == 'live-daemon': (state / 'daemon.pid').write_text('fixture-live\n')
        namespace = dict(vars(probe), started=False, state=state, output=output, isolated=isolated,
                         cleanup_pids=set(), listeners=[], verdict={'status': 'BLOCKED', 'fixture': case},
                         save=lambda name, value: (output / name).write_text(json.dumps(value), encoding='utf-8'))
        exception = None
        try:
            exec(compile(ast.Module(body=final, type_ignores=[]), str(source), 'exec'), namespace)
        except Exception as error:  # Test records the actual failure; it never turns an exception into PASS.
            exception = repr(error)
        failures = []
        if exception: failures.append('finally escaped: ' + exception)
        if isolated.exists() != (case == 'live-daemon'): failures.append('wrong home retention')
        if case == 'existing-backup':
            try:
                with sqlite3.connect(dest) as db:
                    if db.execute('SELECT value FROM sentinel').fetchall() != [('original',)]: failures.append('backup changed')
            except sqlite3.Error: failures.append('existing backup overwritten')
        if not (output / 'verdict.json').exists(): failures.append('final verdict missing')
        evidence.append({'case': case, 'root': str(root), 'failures': failures, 'exception': exception})
    record = {'status': 'PASS' if all(not item['failures'] for item in evidence) else 'INCOMPLETE', 'cases': evidence}
    (args.output / 'results.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False, indent=2))
    return 0 if record['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
