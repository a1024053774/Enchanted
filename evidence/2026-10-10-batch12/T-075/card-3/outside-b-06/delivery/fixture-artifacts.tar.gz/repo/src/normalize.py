def normalize(rows):
    if not isinstance(rows, list):
        raise ValueError("invalid_name")

    totals = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("invalid_name")

        name = row.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("invalid_name")
        name = name.strip()

        minutes = row.get("minutes")
        if (
            not isinstance(minutes, int)
            or isinstance(minutes, bool)
            or minutes < 0
        ):
            raise ValueError("invalid_minutes")

        totals[name] = totals.get(name, 0) + minutes

    entries = [
        {
            "name": name,
            "minutes": totals[name],
            "duration": f"{totals[name] // 60}:{totals[name] % 60:02d}",
        }
        for name in sorted(totals)
    ]
    return {"entries": entries, "total_minutes": sum(totals.values())}
