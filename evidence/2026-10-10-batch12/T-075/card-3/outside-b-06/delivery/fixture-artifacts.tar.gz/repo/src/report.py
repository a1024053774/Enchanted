import json
import sys

from normalize import normalize


def main():
    rows = json.load(sys.stdin)
    try:
        result = normalize(rows)
    except ValueError as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False))
        return 2

    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
