#!/usr/bin/env python3
"""One A2 turn under T-075 rev 4. The controller runs this outside the sandbox."""
import argparse
from contextlib import closing
import datetime
import difflib
import errno
import fcntl
import json
import os
from pathlib import Path
import shlex
import shutil
import sqlite3
import socketserver
import subprocess
import sys
import tempfile
import time
import threading
import uuid


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    args.output.mkdir(parents=True, exist_ok=False)
    output = args.output.resolve()
    temp = Path(tempfile.mkdtemp(prefix='a2a-t0753-', dir='/tmp')).resolve()
    repo, state, isolated = temp / 'fixture', temp / 'state', temp / 'codex-home'
    repo.mkdir(); isolated.mkdir(mode=0o700)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('A2A_', 'GIT_', 'CODEX_'))}
    env.update(GIT_AUTHOR_NAME='T0753 fixture', GIT_AUTHOR_EMAIL='fixture@example.invalid',
               GIT_COMMITTER_NAME='T0753 fixture', GIT_COMMITTER_EMAIL='fixture@example.invalid')
    commands = []
    started = False
    cleanup_pids = set()
    listeners = []
    proxy_snapshots = []
    verdict = {'status': 'INCOMPLETE', 'root': str(temp), 'real_turns_reserved': 0, 'stage': 'setup'}

    def save(name, value):
        (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def run(argv, *, check=True, command_env=None, timeout=30):
        p = subprocess.run([str(x) for x in argv], cwd=root, env=command_env or env,
                           text=True, capture_output=True, timeout=timeout)
        commands.append({'argv': [str(x) for x in argv], 'cwd': str(root), 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
        save('commands.json', commands)
        if check and p.returncode:
            raise RuntimeError(f'Command failed: {argv!r}: {p.stderr or p.stdout}')
        return p

    cli = ['node', root / 'workbench/src/gates/cli.ts', '--state', state]

    def call(command, *values, check=True):
        p = run([*cli, command, *values], check=check)
        return json.loads(p.stdout)

    try:
        if not Path('/Volumes/WD-Elements').is_mount():
            raise RuntimeError('外置盘未挂载；不回退缓存')
        git_env = dict(env, GIT_CONFIG_COUNT='2', GIT_CONFIG_KEY_0='core.hooksPath', GIT_CONFIG_VALUE_0='/dev/null',
                       GIT_CONFIG_KEY_1='commit.gpgsign', GIT_CONFIG_VALUE_1='false')
        run(['git', 'init', '-b', 'main', repo], command_env=git_env)
        (repo / 'input.txt').write_text('socket probe baseline\n', encoding='utf-8')
        run(['git', '-C', repo, 'add', 'input.txt'], command_env=git_env)
        run(['git', '-C', repo, 'commit', '-m', 'Probe baseline'], command_env=git_env)
        baseline = run(['git', '-C', repo, 'rev-parse', 'HEAD']).stdout.strip()
        # Evidence-only copy: permission changes do not enter product defaults
        # until this probe meets T-075 rev 3's positive and negative contract.
        probe_root = temp / 'probe-source/workbench'
        probe_root.mkdir(parents=True)
        shutil.copytree(root / 'workbench/src', probe_root / 'src')
        shutil.copytree(root / 'workbench/hooks', probe_root / 'hooks', symlinks=True)
        shutil.copyfile(root / 'workbench/package.json', probe_root / 'package.json')
        (probe_root / 'node_modules').symlink_to(root / 'workbench/node_modules', target_is_directory=True)
        source = probe_root / 'src/panes.ts'
        original = source.read_text(encoding='utf-8')
        anchor = '    for (const event of ["UserPromptSubmit", "Stop", "PermissionRequest"])'
        if original.count(anchor) != 1: raise RuntimeError('Probe-only argv anchor changed')
        # A2 delegates network enforcement to the managed proxy. Network access
        # must be enabled for that proxy to start; its domain policy is empty.
        # The table form is the documented equivalent of features.network_proxy=true.
        socket_overrides = ['network.allow_unix_sockets=' + json.dumps([str(state / 'control.sock')]),
                            'sandbox_workspace_write.network_access=true',
                            'features.network_proxy.enabled=true', 'features.network_proxy.domains={}']
        extra = '    argv.push(' + ', '.join(json.dumps(x) for setting in socket_overrides for x in ('-c', setting)) + ');\n'
        patched = original.replace(anchor, extra + anchor)
        source.write_text(patched, encoding='utf-8')
        (output / 'probe-only.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), patched.splitlines(True),
                    fromfile='product/workbench/src/panes.ts', tofile='probe-only/workbench/src/panes.ts')), encoding='utf-8')
        cli = ['node', probe_root / 'src/gates/cli.ts', '--state', state]
        # Auth is the only copied file. Do not print it or include this directory in evidence.
        shutil.copyfile(Path.home() / '.codex/auth.json', isolated / 'auth.json')
        (isolated / 'auth.json').chmod(0o600)
        (isolated / 'config.toml').write_text(f'[projects.{json.dumps(str(repo))}]\ntrust_level="trusted"\n', encoding='utf-8')
        (isolated / 'rules').mkdir()
        (isolated / 'rules/default.rules').write_text('prefix_rule(pattern=["git", "add"], decision="allow")\nprefix_rule(pattern=["git", "commit"], decision="allow")\n', encoding='utf-8')
        codex = Path(shutil.which('codex')).resolve()
        config = {'codex_bin': str(codex), 'codex_home': str(isolated),
                  'role_card': str(root / '.project-map/roles/worker.md'),
                  'role_card_revision': run(['git', 'log', '-1', '--format=%H', '--', '.project-map/roles/worker.md']).stdout.strip(),
                  'code_revision': run(['git', 'rev-parse', 'HEAD']).stdout.strip(),
                  'source_snapshot': str(output.parent / 'workbench-source.tar.gz'),
                  'hook_authorization': 'T-075-3 controller-decision-01 sections 3 and 4; network probe decision-04', 'turn_limit': 1}
        save('launch-config.json', config)
        # Save all changed source, including untracked production files, beside the exact revision.
        run(['git', 'diff', '--', 'workbench/'])
        save('setup.json', {'root': str(temp), 'fixture': str(repo), 'state': str(state), 'codex_home': str(isolated),
                            'baseline': baseline, 'controller_initial_release': True,
                            'hooks': ['UserPromptSubmit', 'Stop', 'PermissionRequest'], 'main_turn_limit': 1,
                            'ready_rev': 4, 'channel': 'A2', 'model': 'gpt-6.1-sol'})
        start = call('daemon_start', '--launch-config', output / 'launch-config.json')
        if not start['ok']:
            raise RuntimeError(start)
        started = True
        cleanup_pids.add(start['pid'])
        run(['/bin/ps', '-o', 'pid=,ppid=,pgid=,sess=', '-p', str(start['pid'])])
        challenge = 't0753-' + uuid.uuid4().hex
        control_receipts = []
        class ControlHandler(socketserver.BaseRequestHandler):
            def handle(self):
                data = self.request.recv(256)
                control_receipts.append({'endpoint': str(self.server.server_address), 'data': data.decode('utf-8'),
                                         'at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
                self.request.sendall(b'fixture-control-ready\n')
        unix = socketserver.ThreadingUnixStreamServer(str(state / 'control.sock-other'), ControlHandler)
        tcp = socketserver.ThreadingTCPServer(('127.0.0.1', 0), ControlHandler)
        for listener in (unix, tcp):
            listeners.append(listener)
            threading.Thread(target=listener.serve_forever, daemon=True).start()
        from socket_boundary_probe import connect_once
        import socket
        preflight = {'other_socket': connect_once(socket.AF_UNIX, str(state / 'control.sock-other')),
                     'tcp': connect_once(socket.AF_INET, tcp.server_address), 'daemon': call('daemon_status')}
        save('control-preflight.json', preflight)
        if not preflight['other_socket']['connected'] or not preflight['tcp']['connected']:
            raise RuntimeError('Control listener unreachable before the sandbox probe')
        hooks = temp / 'probe-hooks'; hooks.mkdir()
        probe_config = {'node': shutil.which('node'), 'cli': str(probe_root / 'src/gates/cli.ts'), 'state': str(state),
                        'challenge': challenge, 'other_socket': str(state / 'control.sock-other'),
                        'tcp_port': tcp.server_address[1], 'hook_dir': str(hooks), 'config_overrides': socket_overrides}
        save('socket-probe-config.json', probe_config)
        probe_command = [sys.executable, str(root / 'workbench/tests/socket_boundary_probe.py'), '--config', str(output / 'socket-probe-config.json')]
        hook = hooks / 'prepare-commit-msg'
        hook.write_text('#!/bin/sh\nexec ' + shlex.join([*probe_command, '--hook']) + '\n', encoding='utf-8'); hook.chmod(0o755)
        command = shlex.join(probe_command)
        task = 'T0753-socket-1'
        card = {'id': task, 'source': None,
                'goal': '先执行且只执行一次这条普通沙箱命令：\n' + command +
                        '\n不要使用 require_escalated。脚本会各测一次后台socket、对照socket、TCP、外部域名、Git hook；拒绝也是需要保存的结果。'
                        '命令结束后立即报告并停止，不重试、不编辑任何脚本、不换传输、不改权限、不commit、不submit。'
                        '只用一轮完成。不要启动子 agent，不运行任何其他探针。',
                'non_goals': ['不改 input.txt，不改验收，不读凭据，不访问真实项目数据'],
                'paths': {'allow': ['probe-results.json', 'hook-result.json', 'hook-message.txt'], 'deny': ['input.txt']},
                'completion_conditions': [{'argv': [sys.executable, '-I', '-B', '-c',
                    "from pathlib import Path; assert Path('probe-results.json').is_file()"]}],
                'red_commands': [], 'task_type': '后端逻辑', 'repair_target': None, 'complexity': 'M',
                'executor': {'cli': 'Codex', 'model': 'gpt-6.1-sol', 'effort': 'xhigh'}, 'base_commit': None, 'writer': None}
        save('probe-card.json', card)
        call('card_save', '--task', task, '--card', output / 'probe-card.json', '--expected-version', '0')
        call('create', '--task', task, '--repo', repo, '--branch', 'refs/heads/main', '--card-version', '1', '--project', 'T0753-probe')
        result = call('dispatch', '--task', task, '--runtime-mode', 'workspace-write')
        attempt = result['attempt']; thread = attempt['thread_id']
        save('attempt.json', attempt)
        pane = call('pane_status', '--thread', thread)
        save('launch-record.json', call('launch_show', '--launch', pane['launch']))
        # Waiting for an OS fact is not an idle inference. There is no blind Enter.
        deadline = time.monotonic() + 30
        while True:
            info = call('pane_process_info', '--thread', thread)
            if info.get('leader') and not info.get('failed'):
                break
            if info.get('failed') or time.monotonic() >= deadline:
                raise RuntimeError({'foreground_codex_unconfirmed': info})
            time.sleep(0.25)
        save('before-release.json', info)
        cleanup_pids.update(row['pid'] for row in info['processes'])
        def proxy_snapshot(phase, info):
            pids = sorted({row['pid'] for row in info['processes']})
            cleanup_pids.update(pids)
            if not pids: return
            selected = ','.join(map(str, pids))
            processes = run(['/bin/ps', '-o', 'pid=,ppid=,pgid=,command=', '-p', selected], check=False)
            ports = run(['/usr/sbin/lsof', '-nP', '-a', '-p', selected, '-iTCP', '-sTCP:LISTEN', '-Fpcn'], check=False)
            proxy_snapshots.append({'phase': phase, 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                    'pids': pids, 'process_argv': processes.stdout, 'listeners': ports.stdout,
                                    'lsof_exit': ports.returncode, 'lsof_stderr': ports.stderr})
            save('proxy-process-snapshots.json', proxy_snapshots)
        proxy_snapshot('before-release', info)
        # Reservations survive failed/interrupted runs and new labels. Never
        # reset the card's total by creating a fresh CODEX_HOME or database.
        with (output.parents[1] / 'turn-budget.jsonl').open('a+', encoding='utf-8') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            stream.seek(0)
            previous = [json.loads(line) for line in stream if line.strip()]
            if sum(row['reserved'] for row in previous) >= 10:
                raise RuntimeError('T-075-3 已到 10 个真实主 turn 的保守上限')
            reservation = {'reserved': 1, 'output': str(output), 'launch': pane['launch'],
                           'at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            stream.seek(0, 2); stream.write(json.dumps(reservation) + '\n'); stream.flush(); os.fsync(stream.fileno())
        verdict['real_turns_reserved'] = 1
        verdict['stage'] = 'one-real-turn'
        save('verdict.json', verdict)
        call('pane_release', '--thread', thread, '--reason', '执行主控按决定 01 核对前台领导进程后首次放行')
        deadline = time.monotonic() + 300
        while True:
            pane = call('pane_status', '--thread', thread)
            info = call('pane_process_info', '--thread', thread)
            proxy_snapshot('turn-observation', info)
            if pane.get('failed'):
                raise RuntimeError({'pane_failed': pane})
            if pane.get('state') == 'idle':
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('主回合期限已到，结果未知；不追加输入、不重试')
            time.sleep(1)
        events = call('orchestration_events', '--task', task)
        save('orchestration-events.json', events)
        observations = json.loads((Path(attempt['workspace']) / 'probe-results.json').read_text(encoding='utf-8'))
        save('socket-observations.json', observations)
        save('control-receipts.json', control_receipts)
        proxy_endpoints = [item for item in observations['proxy_environment'].values() if item['host'] in ('127.0.0.1', 'localhost', '::1') and item['port']]
        proxy_owners = []
        for snapshot in proxy_snapshots:
            owner = None
            for field in snapshot['listeners'].splitlines():
                if field.startswith('p'): owner = int(field[1:])
                if owner is not None and field.startswith('n'):
                    for endpoint in proxy_endpoints:
                        if field.endswith(':' + str(endpoint['port'])):
                            argv_lines = [line.strip() for line in snapshot['process_argv'].splitlines() if line.split() and line.split()[0] == str(owner)]
                            proxy_owners.append({'pid': owner, 'listener': field[1:], 'process_argv': argv_lines,
                                                 'phase': snapshot['phase'], 'at': snapshot['at']})
        save('proxy-process-identity.json', {'observations': proxy_owners,
             'lifecycle': 'Observed during the Codex session. The final ps readback verifies exit after daemon_stop. The proxy may run inside Codex.'})
        primary_records = [e['data']['record'] for e in events['events'] if e['type'] == 'native_record'
                           and e['data']['file'].endswith(pane['native_session'] + '.jsonl')]
        contexts = [e['payload'] for e in primary_records if e['type'] == 'turn_context']
        turns = {e['payload']['turn_id'] for e in primary_records if e['type'] == 'event_msg' and e['payload']['type'] == 'task_started'}
        verdict['observed_main_turns'] = len(turns)
        if len(turns) != 1: raise RuntimeError('A2主会话回合数不是1，不能把辅助会话或缺失记录当作通过')
        if not contexts or any(c['approval_policy'] != 'never' or c['model'] != 'gpt-6.1-sol' for c in contexts):
            raise RuntimeError('原生记录不能证明不问模式与指定模型；A2不通过，后续走B')
        if any(e['type'] == 'permission_wait' for e in events['events']):
            raise RuntimeError('出现权限请求；A2不通过，后续走B')
        for suffix in ('-command', '-hook'):
            receipts = [r for r in events['events'] if r['type'] == 'sandbox_probe' and r['data']['challenge'] == challenge + suffix]
            if len(receipts) != 1: raise RuntimeError('A2后台socket未生效：' + suffix + '；按决定04后续走B，不重试A2')
        for key in ('other_socket', 'tcp'):
            observation = observations[key]
            if observation['connected'] or observation.get('errno') not in (errno.EPERM, errno.EACCES):
                raise RuntimeError('A2对照连接未取得明确拒绝：' + key + '；后续走B')
        external = observations['external_domain']
        transport = external.get('transport') or {}
        if external['exit_code'] == 0 or transport.get('proxy_connect_code') != '403' or transport.get('http_code') != '000':
            raise RuntimeError('外部域名未取得代理CONNECT拒绝；A2不通过，后续走B')
        if not proxy_owners or any(not owner['process_argv'] for owner in proxy_owners):
            raise RuntimeError('没有把实际代理地址匹配到本会话进程PID/监听端口；A2不通过，后续走B')
        if len(control_receipts) != 2: raise RuntimeError('对照监听器收到额外连接；A2不通过，后续走B')
        verdict.update(status='PASS', stage='A2-boundary', proxy_enabled=True, selected_channel='A2',
                       scope='probe-only argv; not product delivery acceptance')
    except (OSError, ValueError, KeyError, AssertionError, RuntimeError, subprocess.TimeoutExpired) as error:
        verdict.update(status='INCOMPLETE', error=str(error))
        if verdict['real_turns_reserved']:
            verdict.update(selected_channel='B', next_action='按决定04实现并验证B，不再重试A2或询问通道选择')
        else:
            verdict.update(selected_channel=None, next_action='尚未消耗真实回合；修正启动前的夹具错误后再执行A2')
    finally:
        for listener in listeners:
            listener.shutdown(); listener.server_close()
        if started:
            try:
                if 'thread' in locals():
                    final_info = call('pane_process_info', '--thread', thread)
                    if 'proxy_snapshot' in locals(): proxy_snapshot('before-stop', final_info)
                    cleanup_pids.update(row['pid'] for row in final_info['processes'])
                    save('before-stop-processes.json', final_info)
                save('all-events-before-stop.json', call('orchestration_events'))
                stopped = call('daemon_stop', check=False)
                save('stop.json', stopped)
                if not stopped.get('ok'):
                    verdict.update(status='BLOCKED', cleanup_error=stopped)
            except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
                verdict.update(status='BLOCKED', cleanup_error=str(error))
            deadline = time.monotonic() + 10
            while (state / 'daemon.pid').exists() and time.monotonic() < deadline:
                time.sleep(0.1)
        # A file snapshot is coherent only after this probe's writers have exited.
        stopped_for_archive = False
        try:
            remaining = run(['/bin/ps', '-o', 'pid=,ppid=,pgid=,command=', '-p', ','.join(map(str, sorted(cleanup_pids)))], check=False) if cleanup_pids else None
            if (state / 'daemon.pid').exists() or (remaining and remaining.stdout.strip()):
                verdict.update(status='BLOCKED', cleanup_error='后台或观测过的进程尚未确认退出，保留隔离 home 等主控核对')
            else:
                stopped_for_archive = True
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as error:
            verdict.update(status='BLOCKED', cleanup_error=str(error))
        # Never open the original WAL database for writing. Normalize only the
        # copied archive to DELETE mode, so it does not need -wal/-shm sidecars.
        try:
            if state.exists():
                for name in ('daemon.stdout.log', 'daemon.stderr.log'):
                    if (state / name).exists():
                        with (output / name).open('xb') as stream:
                            stream.write((state / name).read_bytes())
                if (state / 'state.sqlite3').exists():
                    if not stopped_for_archive:
                        raise RuntimeError('Database archive requires confirmed daemon stop')
                    destination = output / 'state.sqlite3'
                    with destination.open('xb') as stream:
                        stream.write((state / 'state.sqlite3').read_bytes())
                    wal = state / 'state.sqlite3-wal'
                    if wal.exists():
                        with (output / 'state.sqlite3-wal').open('xb') as stream:
                            stream.write(wal.read_bytes())
                    with closing(sqlite3.connect(destination)) as dest:
                        if dest.execute('PRAGMA journal_mode=DELETE').fetchone() != ('delete',):
                            raise RuntimeError('Archive journal mode did not become DELETE')
                        if dest.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
                            raise RuntimeError('Archive integrity check failed')
                    verdict['database_archive'] = {'path': str(destination), 'journal_mode': 'delete', 'integrity': 'ok'}
        except (OSError, RuntimeError, sqlite3.Error) as error:
            verdict.update(status='BLOCKED', archive_error=str(error))
        finally:
            try:
                if stopped_for_archive:
                    shutil.rmtree(isolated)
                    verdict['isolated_home_removed'] = True
            except (OSError, RuntimeError, subprocess.TimeoutExpired) as error:
                verdict.update(status='BLOCKED', cleanup_error=str(error))
            finally:
                save('verdict.json', verdict)
    print(json.dumps(verdict, ensure_ascii=False, indent=2))
    return 0 if verdict['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
