#!/usr/bin/env python3
"""Run A2 once inside the command sandbox, including proxy denial evidence."""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
from urllib.parse import urlsplit


def connect_once(family, address):
    try:
        with socket.socket(family, socket.SOCK_STREAM) as client:
            client.settimeout(3)
            client.connect(address)
            client.sendall(b'fixture-control\n')
            reply = client.recv(256)
        return {'connected': True, 'reply': reply.decode('utf-8')}
    except OSError as error:
        return {'connected': False, 'errno': error.errno, 'error': str(error)}


def daemon_once(config, suffix):
    argv = [config['node'], config['cli'], '--state', config['state'], 'probe', '--challenge', config['challenge'] + suffix]
    p = subprocess.run(argv, capture_output=True, text=True, timeout=15)
    return {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--hook', action='store_true')
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    if args.hook:
        result = {'context': 'git-hook-run', 'daemon': daemon_once(config, '-hook'),
                  'pid': os.getpid(), 'ppid': os.getppid(), 'cwd': os.getcwd()}
        Path('hook-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False))
        return 0
    observations = {
        'daemon': daemon_once(config, '-command'),
        'other_socket': connect_once(socket.AF_UNIX, config['other_socket']),
        'tcp': connect_once(socket.AF_INET, ('127.0.0.1', config['tcp_port'])),
    }
    # Record endpoint identity without credentials. curl's http_connect is the
    # proxy CONNECT status, independent of the destination site's HTTP status.
    observations['proxy_environment'] = {}
    for name in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy'):
        if os.environ.get(name):
            endpoint = urlsplit(os.environ[name])
            observations['proxy_environment'][name] = {'scheme': endpoint.scheme, 'host': endpoint.hostname, 'port': endpoint.port}
    argv = ['curl', '--head', '--silent', '--show-error', '--fail', '--max-time', '10', '--output', '/dev/null',
            '--write-out', '{"proxy_connect_code":"%{http_connect}","http_code":"%{http_code}","remote_ip":"%{remote_ip}"}\n',
            'https://example.com']
    p = subprocess.run(argv, capture_output=True, text=True, timeout=15)
    observations['external_domain'] = {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    try:
        observations['external_domain']['transport'] = json.loads(p.stdout)
    except json.JSONDecodeError:
        observations['external_domain']['transport'] = None
    Path('hook-message.txt').write_text('Probe hook invocation\n', encoding='utf-8')
    argv = ['git', '-c', 'core.hooksPath=' + config['hook_dir'], 'hook', 'run', 'prepare-commit-msg', '--', 'hook-message.txt']
    p = subprocess.run(argv, capture_output=True, text=True, timeout=20)
    observations['hook_command'] = {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    if Path('hook-result.json').exists(): observations['hook'] = json.loads(Path('hook-result.json').read_text(encoding='utf-8'))
    Path('probe-results.json').write_text(json.dumps(observations, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(observations, ensure_ascii=False))
    # Expected denials are evidence. The driver decides A2 versus B from facts.
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
