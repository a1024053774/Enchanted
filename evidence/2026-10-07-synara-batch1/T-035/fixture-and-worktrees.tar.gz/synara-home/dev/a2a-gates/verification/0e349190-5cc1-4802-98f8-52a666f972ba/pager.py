"""Read one request and return a page ordered by timestamp and record ID."""
import json
import sys


def paginate(request):
    limit = request.get("limit")
    if type(limit) is not int or not 1 <= limit <= 100:
        return {"error": "invalid_limit"}

    after = request.get("after")
    if after is not None:
        if (
            not isinstance(after, list)
            or len(after) != 2
            or type(after[0]) is not int
            or not isinstance(after[1], str)
        ):
            return {"error": "invalid_cursor"}
        after = tuple(after)

    eligible = sorted(
        (
            item for item in request["items"]
            if after is None or (item["ts"], item["id"]) > after
        ),
        key=lambda item: (item["ts"], item["id"]),
    )
    page = eligible[:limit]
    next_cursor = (
        [page[-1]["ts"], page[-1]["id"]] if len(eligible) > limit else None
    )
    return {"items": page, "next_cursor": next_cursor}


if __name__ == "__main__":
    print(json.dumps(paginate(json.load(sys.stdin))))
