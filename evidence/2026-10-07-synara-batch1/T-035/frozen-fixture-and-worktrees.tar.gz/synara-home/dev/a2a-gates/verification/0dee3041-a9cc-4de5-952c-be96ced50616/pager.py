"""Read a JSON request and return a page ordered by timestamp and id."""
import json
import sys


def main():
    request = json.load(sys.stdin)
    limit = request.get("limit")
    if type(limit) is not int or not 1 <= limit <= 100:
        print(json.dumps({"error": "invalid_limit"}))
        return

    after = request.get("after")
    if after is not None and (
        not isinstance(after, list)
        or len(after) != 2
        or type(after[0]) is not int
        or not isinstance(after[1], str)
    ):
        print(json.dumps({"error": "invalid_cursor"}))
        return

    eligible = sorted(request["items"], key=lambda item: (item["ts"], item["id"]))
    if after is not None:
        cursor = tuple(after)
        eligible = [item for item in eligible if (item["ts"], item["id"]) > cursor]

    page = eligible[:limit]
    next_cursor = [page[-1]["ts"], page[-1]["id"]] if len(eligible) > limit else None
    print(json.dumps({"items": page, "next_cursor": next_cursor}))


if __name__ == "__main__":
    main()
