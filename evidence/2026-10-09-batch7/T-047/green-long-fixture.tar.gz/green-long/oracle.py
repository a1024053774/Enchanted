from pathlib import Path
import sys
assert Path(sys.argv[1], 'delivery.txt').read_text() == 'T047 independently specified delivery\n'
sys.stdout.buffer.write(b'control: \x00\x01\x1b\t\r\n')
