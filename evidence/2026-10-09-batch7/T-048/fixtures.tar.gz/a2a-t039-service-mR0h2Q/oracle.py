from pathlib import Path
Path("/Volumes/WD-Elements/dev-cache/synara/tmp/t048/a2a-t039-service-mR0h2Q/oracle-ran").touch()
