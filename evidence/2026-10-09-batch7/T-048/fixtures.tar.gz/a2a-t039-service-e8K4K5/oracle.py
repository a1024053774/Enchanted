from pathlib import Path
Path("/Volumes/WD-Elements/dev-cache/synara/tmp/t048/a2a-t039-service-e8K4K5/oracle-ran").touch()
