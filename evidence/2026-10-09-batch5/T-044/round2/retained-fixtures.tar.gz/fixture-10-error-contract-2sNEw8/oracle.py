from pathlib import Path
Path("/Volumes/WD-Elements/dev-cache/synara/instances/t044/fixtures/error-contract-2sNEw8/oracle-called").touch()
