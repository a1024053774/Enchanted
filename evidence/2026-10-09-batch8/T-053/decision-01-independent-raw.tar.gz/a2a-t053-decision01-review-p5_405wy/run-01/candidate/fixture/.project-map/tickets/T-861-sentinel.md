---
id: T-861
title: 已结束闭合 sentinel 雪
type: task
status: closed
blocked_by: []
claimed_by:
ready_by: executor
---
