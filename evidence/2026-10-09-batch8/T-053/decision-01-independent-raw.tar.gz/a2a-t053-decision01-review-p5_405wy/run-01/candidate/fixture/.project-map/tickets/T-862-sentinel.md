---
id: T-862
title: 已结束取代 sentinel 海
type: research
status: superseded
blocked_by: []
claimed_by:
ready: alien
ready_by: alien
ready_rev: invalid
---
