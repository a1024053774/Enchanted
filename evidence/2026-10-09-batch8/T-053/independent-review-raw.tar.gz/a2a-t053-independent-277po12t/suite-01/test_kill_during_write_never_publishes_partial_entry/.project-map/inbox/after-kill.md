---
from: "worker:sentinel"
to: "executor"
kind: "report"
reply_to: ""
refs: []
created_at: "2026-10-09T12:00:00Z"
schema: 1
id: "after-kill"
---

正文：引号" / 多行
⟦⟧ café