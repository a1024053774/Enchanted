---
id: T-012
title: sentinel-T-012
type: task
status: open
blocked_by: []
claimed_by: 
ready: yes
ready_by: ideation
ready_rev: 1
---
