---
id: T-014
title: sentinel-T-014
type: build
status: open
blocked_by: ["T-007", "T-008"]
claimed_by: 
ready: yes
ready_by: ideation
ready_rev: 1
---
