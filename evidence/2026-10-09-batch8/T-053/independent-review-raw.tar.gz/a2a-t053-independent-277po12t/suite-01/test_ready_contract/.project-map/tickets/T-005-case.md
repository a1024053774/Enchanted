---
id: T-005
title: sentinel-T-005
type: build
status: open
blocked_by: ["T-001"]
claimed_by: 
ready: yes
ready_by: ideation
ready_rev: 1
---
