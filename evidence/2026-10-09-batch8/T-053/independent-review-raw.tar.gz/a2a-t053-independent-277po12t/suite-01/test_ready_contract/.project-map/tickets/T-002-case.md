---
id: T-002
title: sentinel-T-002
type: build
status: open
blocked_by: []
claimed_by: 
ready: no
ready_by: ideation
ready_rev: 1
---
