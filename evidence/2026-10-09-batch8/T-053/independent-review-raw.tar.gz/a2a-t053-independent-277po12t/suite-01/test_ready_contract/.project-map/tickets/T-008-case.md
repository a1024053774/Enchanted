---
id: T-008
title: sentinel-T-008
type: build
status: superseded
blocked_by: []
claimed_by: 
ready: yes
ready_by: ideation
ready_rev: 1
---
