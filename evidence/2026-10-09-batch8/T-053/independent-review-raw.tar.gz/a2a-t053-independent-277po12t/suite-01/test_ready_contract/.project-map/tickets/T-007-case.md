---
id: T-007
title: sentinel-T-007
type: build
status: closed
blocked_by: []
claimed_by: 
ready: yes
ready_by: ideation
ready_rev: 1
---
