角色卡 sentinel ideation
