角色卡 sentinel executor
