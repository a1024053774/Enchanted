---
id: "blocking"
from: "worker:sentinel"
to: "triage"
kind: "issue"
reply_to: ""
refs: []
created_at: "2026-10-09T11:46:00Z"
schema: 1
title: "标题-blocking"
blocking: true
---

正文：独立夹具
