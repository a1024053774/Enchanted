---
id: T-987
title: Ω-T-987
type: research
status: open
blocked_by: [T-985]
claimed_by:
ready: yes
ready_by: executor
ready_rev: 9
---
