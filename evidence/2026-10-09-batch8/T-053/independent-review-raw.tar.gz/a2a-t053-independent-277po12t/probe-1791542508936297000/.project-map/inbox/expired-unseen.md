---
id: "expired-unseen"
kind: "issue"
from: "worker:unseen"
to: "triage"
reply_to: ""
refs: []
created_at: "2026-10-09T18:44:59Z"
schema: 1
title: "过期 Ω"
blocking: false
---

夹具正文 Ω expired-unseen
