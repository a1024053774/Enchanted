---
id: "blocking-unseen"
kind: "issue"
from: "worker:unseen"
to: "triage"
reply_to: ""
refs: []
created_at: "2026-10-09T18:59:59Z"
schema: 1
title: "阻塞 Ω"
blocking: true
---

夹具正文 Ω blocking-unseen
