---
id: "pending-unseen"
kind: "issue"
from: "worker:unseen"
to: "triage"
reply_to: ""
refs: []
created_at: "2026-10-09T18:45:01Z"
schema: 1
title: "非模板 Ω"
blocking: false
---

夹具正文 Ω pending-unseen
