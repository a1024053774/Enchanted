"""Read one JSON request and return a page ordered by timestamp and ID."""
import json
import sys


def paginate(request):
    limit = request.get("limit")
    if type(limit) is not int or not 1 <= limit <= 100:
        return {"error": "invalid_limit"}

    after = request.get("after")
    if after is not None and (
        not isinstance(after, list)
        or len(after) != 2
        or type(after[0]) is not int
        or not isinstance(after[1], str)
    ):
        return {"error": "invalid_cursor"}

    ordered = sorted(request["items"], key=lambda item: (item["ts"], item["id"]))
    if after is not None:
        cursor = tuple(after)
        ordered = [item for item in ordered if (item["ts"], item["id"]) > cursor]

    page = ordered[:limit]
    next_cursor = None
    if len(ordered) > limit:
        next_cursor = [page[-1]["ts"], page[-1]["id"]]
    return {"items": page, "next_cursor": next_cursor}


if __name__ == "__main__":
    print(json.dumps(paginate(json.load(sys.stdin))))
