raise RuntimeError('Oracle must not run after identity refusal')
