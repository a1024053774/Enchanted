import pathlib,time
pathlib.Path("/Volumes/WD-Elements/dev-cache/synara/tmp/t037/a2a-t037-inflight-observer-9ZyD1o/oracle-entry").write_text('entered')
while not pathlib.Path("/Volumes/WD-Elements/dev-cache/synara/tmp/t037/a2a-t037-inflight-observer-9ZyD1o/oracle-release").exists(): time.sleep(0.01)
raise SystemExit(0)
