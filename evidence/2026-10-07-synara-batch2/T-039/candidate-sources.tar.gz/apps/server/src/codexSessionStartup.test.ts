import type { ChildProcessWithoutNullStreams } from "node:child_process";
import { EventEmitter } from "node:events";
import { PassThrough } from "node:stream";
import { ThreadId } from "@synara/contracts";
import { spawnProcess } from "@synara/shared/processRuntime";
import * as NodeServices from "@effect/platform-node/NodeServices";
import { Effect, Exit, Layer } from "effect";
import { afterEach, describe, expect, it, vi } from "vitest";

import { CodexAppServerManager } from "./codexAppServerManager.ts";
import { CodexSessionStartError } from "./codexErrorClassification.ts";
import { ServerConfig } from "./config.ts";
import { AGENT_GATEWAY_NO_CAPABILITIES } from "./agentGateway/sessionLease.ts";
import { classifyProviderAttemptOutcome } from "./orchestration/Layers/ProviderCommandReactor.ts";
import { makeCodexAdapterLive } from "./provider/Layers/CodexAdapter.ts";
import { CodexAdapter } from "./provider/Services/CodexAdapter.ts";

vi.mock("@synara/shared/processRuntime", async (importOriginal) => ({
  ...(await importOriginal<typeof import("@synara/shared/processRuntime")>()),
  spawnProcess: vi.fn(),
}));

class FakeCodexChild extends EventEmitter {
  readonly pid = 42424;
  exitCode: number | null = null;
  signalCode: NodeJS.Signals | null = null;
  readonly stdin = new PassThrough();
  readonly stdout = new PassThrough();
  readonly stderr = new PassThrough();

  exit() {
    this.exitCode = 0;
    this.emit("exit", 0, null);
  }
}

function createStartupHarness(
  failingMethod?: string,
  failure: "error" | "exit" | "delayed-response" = "error",
  resumeExistingThread = true,
) {
  const child = new FakeCodexChild();
  const requests: string[] = [];
  const transportError = new Error("Codex pipe failed during startup: ECONNRESET");
  child.stdin.on("data", (chunk: Buffer) => {
    const request = JSON.parse(chunk.toString()) as { id?: number; method: string };
    requests.push(request.method);
    if (request.method === failingMethod) {
      if (failure === "delayed-response" && request.id !== undefined) {
        setTimeout(() => {
          child.stdout.write(
            `${JSON.stringify({ id: request.id, result: { thread: { id: "native-thread" } } })}\n`,
          );
        }, 25_000);
      } else {
        queueMicrotask(() => {
          if (failure === "exit") child.exit();
          else child.emit("error", transportError);
        });
      }
    } else if (request.id !== undefined) {
      queueMicrotask(() => {
        const result =
          request.method === "thread/resume" ? { thread: { id: "native-thread" } } : {};
        child.stdout.write(`${JSON.stringify({ id: request.id, result })}\n`);
      });
    }
  });
  vi.mocked(spawnProcess)
    .mockReset()
    .mockReturnValue(child as unknown as ChildProcessWithoutNullStreams);
  const teardownProcessTree = vi.fn(async () => {
    const capturedBeforeRootExit = child.exitCode === null;
    child.exit();
    return { escalated: false, signalErrors: [], capturedBeforeRootExit };
  });
  const manager = new CodexAppServerManager(undefined, { teardownProcessTree });
  const errorMethods: string[] = [];
  manager.on("event", (event) => {
    if (event.kind === "error") errorMethods.push(event.method);
  });
  const internals = manager as unknown as {
    assertSupportedCodexCliVersion: () => Promise<void>;
    buildSessionProcessEnv: () => Promise<{ env: NodeJS.ProcessEnv }>;
  };
  vi.spyOn(internals, "assertSupportedCodexCliVersion").mockResolvedValue(undefined);
  vi.spyOn(internals, "buildSessionProcessEnv").mockResolvedValue({
    env: { CODEX_SQLITE_HOME: process.cwd() },
  });
  const input = {
    threadId: ThreadId.makeUnsafe("thread-startup-failed"),
    cwd: process.cwd(),
    runtimeMode: "full-access" as const,
    ...(resumeExistingThread
      ? {
          resumeCursor: { threadId: "codex-existing-thread" },
          // Process-env construction is stubbed, so a pinned generation is accepted
          // without the overlay files a real launch would verify.
          expectedCodexContinuationGeneration: "00000000-0000-4000-8000-000000000002",
        }
      : {}),
    agentGatewayCapabilityInput: AGENT_GATEWAY_NO_CAPABILITIES,
  };
  const expectedErrorMessage =
    failure === "exit" ? "codex app-server exited (code=0, signal=null)." : transportError.message;
  const expectedThrownMessage =
    failure === "error" && failingMethod
      ? `Codex app-server transport failed: ${transportError.message} Operation: ${failingMethod}.`
      : expectedErrorMessage;
  return {
    manager,
    child,
    input,
    requests,
    teardownProcessTree,
    errorMethods,
    expectedErrorMessage,
    expectedThrownMessage,
  };
}

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe("Codex session startup failures", () => {
  it("fails fast when the gateway capability input is omitted", async () => {
    const { manager, input } = createStartupHarness();
    await expect(
      manager.startSession({ ...input, agentGatewayCapabilityInput: undefined as never }),
    ).rejects.toThrow(/agentGatewayCapabilityInput/);
    expect(manager.listSessions()).toEqual([]);
  });
  it.each(["thread/start", "thread/resume", "thread/fork"])(
    "keeps %s on the existing request deadline",
    async (method) => {
      vi.useFakeTimers();
      const { manager, input, requests } = createStartupHarness(
        method,
        "delayed-response",
        method === "thread/resume",
      );
      const result = manager
        .startSession({
          ...input,
          ...(method === "thread/fork"
            ? { forkSourceResumeCursor: { threadId: "codex-source-thread" } }
            : {}),
        })
        .catch((error: unknown) => error);
      let settled = false;
      void result.then(() => {
        settled = true;
      });

      await vi.waitFor(() => expect(requests).toContain(method));
      // vi.waitFor advances fake time while the async startup reaches the open request.
      // Stay comfortably below the ordinary deadline before crossing it.
      await vi.advanceTimersByTimeAsync(19_000);
      expect(settled).toBe(false);
      await vi.advanceTimersByTimeAsync(1_000);

      await expect(result).resolves.toMatchObject({ message: `Timed out waiting for ${method}.` });
      expect(settled).toBe(true);
      expect(manager.listSessions()).toEqual([]);
    },
  );

  it.each([
    ["initialize", "error"],
    ["thread/resume", "error"],
    ["initialize", "exit"],
    ["thread/resume", "exit"],
  ] as const)(
    "preserves the cause during %s/%s and requires pre-exit capture for a safe rejection",
    async (method, failure) => {
      const {
        manager,
        child,
        input,
        requests,
        teardownProcessTree,
        errorMethods,
        expectedErrorMessage,
        expectedThrownMessage,
      } = createStartupHarness(method, failure);
      let proveExit: (() => void) | undefined;
      const exitProof = new Promise<void>((resolve) => {
        proveExit = resolve;
      });
      teardownProcessTree.mockImplementation(async () => {
        const capturedBeforeRootExit = child.exitCode === null;
        await exitProof;
        child.exit();
        return { escalated: false, signalErrors: [], capturedBeforeRootExit };
      });
      let settled = false;
      const result = manager.startSession(input).catch((error: unknown) => error);
      void result.then(() => {
        settled = true;
      });
      try {
        await vi.waitFor(() => expect(teardownProcessTree).toHaveBeenCalledTimes(1));
        expect(settled).toBe(false);
        expect(manager.hasSession(input.threadId)).toBe(false);
      } finally {
        proveExit?.();
      }
      const error = await result;
      expect(error).toBeInstanceOf(Error);
      expect(error instanceof CodexSessionStartError).toBe(failure === "error");
      expect(error).toMatchObject({
        message: expectedThrownMessage,
        cause: { message: expectedErrorMessage },
      });
      expect(errorMethods).toEqual(
        failure === "error"
          ? ["protocol/transportError"]
          : method === "thread/resume"
            ? ["session/threadResumeFailed", "session/startFailed"]
            : ["session/startFailed"],
      );
      expect(requests).not.toContain("turn/start");
      expect(requests).not.toContain("thread/start");
      expect(manager.listSessions()).toEqual([]);
    },
  );

  it.each(["error", "exit"] as const)(
    "keeps failed cleanup and failed replacement barriers uncertain after %s",
    async (failure) => {
      const { manager, child, input, teardownProcessTree, errorMethods } = createStartupHarness(
        "initialize",
        failure,
      );
      teardownProcessTree.mockRejectedValue(
        new Error(`rootExited=${failure === "exit"}; surviving descendant remains`),
      );
      try {
        for (let attempt = 0; attempt < 2; attempt += 1) {
          const error = await manager.startSession(input).catch((error: unknown) => error);
          expect(error).toBeInstanceOf(Error);
          expect(error).not.toBeInstanceOf(CodexSessionStartError);
          expect(error).toMatchObject({
            message: expect.stringContaining("Failed to prove Codex app-server process-tree exit"),
          });
        }
        expect(spawnProcess).toHaveBeenCalledTimes(1);
        expect(errorMethods.filter((method) => method === "protocol/transportError")).toHaveLength(
          failure === "error" ? 1 : 0,
        );
        if (failure === "error") {
          const sessions = (
            manager as unknown as {
              sessions: Map<ThreadId, { terminalFailure?: { message: string } }>;
            }
          ).sessions;
          expect(sessions.get(input.threadId)?.terminalFailure?.message).toBe(
            "Codex app-server transport failed: Codex pipe failed during startup: ECONNRESET Operation: initialize.",
          );
        }
      } finally {
        teardownProcessTree.mockImplementation(async () => {
          child.exit();
          return { escalated: false, signalErrors: [], capturedBeforeRootExit: false };
        });
        await manager.stopAll();
      }
    },
  );

  it("retires an idle session after spontaneous exit only when teardown completes", async () => {
    const { manager, child, input, teardownProcessTree } = createStartupHarness();
    await manager.startSession(input);
    const sessions = (manager as unknown as { sessions: Map<ThreadId, unknown> }).sessions;
    let finishTeardown: (() => void) | undefined;
    teardownProcessTree.mockImplementation(
      () =>
        new Promise((resolve) => {
          finishTeardown = () =>
            resolve({
              escalated: false,
              signalErrors: [],
              capturedBeforeRootExit: false,
            });
        }),
    );

    child.exit();
    expect(teardownProcessTree).toHaveBeenCalledOnce();
    expect(manager.hasSession(input.threadId)).toBe(false);
    expect(sessions.has(input.threadId)).toBe(true);
    finishTeardown?.();
    await vi.waitFor(() => expect(sessions.has(input.threadId)).toBe(false));
  });

  it("keeps a turn uncertain when stdin closes after accepting its frame", async () => {
    const { manager, child, input } = createStartupHarness();
    await manager.startSession(input);
    let acceptedFrame: unknown;
    vi.spyOn(child.stdin, "write").mockImplementation((frame) => {
      acceptedFrame = JSON.parse(String(frame));
      // The provider can receive the frame before the stream's write callback
      // confirms it. Closing here loses acknowledgement, not proof of delivery.
      queueMicrotask(() => child.stdin.emit("close"));
      return true;
    });
    const layer = makeCodexAdapterLive({ manager }).pipe(
      Layer.provide(ServerConfig.layerTest(process.cwd(), { prefix: "codex-write-uncertain-" })),
      Layer.provide(NodeServices.layer),
    );
    const result = await Effect.runPromise(
      Effect.gen(function* () {
        const adapter = yield* CodexAdapter;
        return yield* adapter
          .sendTurn({ threadId: input.threadId, input: "Apply the change", attachments: [] })
          .pipe(Effect.result);
      }).pipe(Effect.provide(layer)),
    );
    expect(acceptedFrame).toMatchObject({ method: "turn/start" });
    if (result._tag !== "Failure") throw new Error("Expected lost acknowledgement");
    expect(result.failure._tag).toBe("ProviderAdapterRequestError");
    expect(classifyProviderAttemptOutcome(Exit.fail(result.failure))._tag).toBe("uncertain");
  });
});
