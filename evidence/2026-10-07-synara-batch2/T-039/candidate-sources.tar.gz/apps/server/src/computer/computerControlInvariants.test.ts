import { GatewayToolError } from "../agentGateway/toolRuntime.ts";
import { Effect } from "effect";
import { describe, expect, it, vi } from "vitest";
import { ComputerManager } from "./ComputerManager.ts";
import { FakeComputerBackend } from "./FakeComputerBackend.ts";
import { makeAgentGatewayComputerTools } from "../agentGateway/computerTools.ts";
import type { ToolContext } from "../agentGateway/toolRuntime.ts";

function deferred() {
  let resolve!: () => void;
  const promise = new Promise<void>((r) => {
    resolve = r;
  });
  return { promise, resolve };
}
function context(): ToolContext {
  return {
    principal: {
      kind: "provider-session",
      sessionKey: "audit",
      threadId: "audit",
      provider: "claudeAgent",
      turnId: "turn",
    },
    callerThreadId: "audit",
    callerThreadLabel: "Audit",
    callerSessionKey: "audit",
    callerProvider: "claudeAgent",
    callerCapabilities: new Set(["computer:control"]),
    callerTurnId: "turn",
    assertCallerTurnActive: () => Effect.void,
    jsonRpcRequestId: 1,
  };
}
function setup(backend = new FakeComputerBackend()) {
  const manager = new ComputerManager({ backend, actionSettleMs: 0 });
  const tools = new Map(
    makeAgentGatewayComputerTools({ manager }).map((t) => [t.definition.name, t]),
  );
  const call = (name: string, args: Record<string, unknown> = {}) =>
    Effect.runPromise(tools.get(name)!.handler(args, context()));
  return { manager, tools, call };
}
const PNG =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
describe("Production audit: desired invariants", () => {
  it("concurrent keyboard calls must preserve each named target", async () => {
    const entered = deferred(),
      release = deferred();
    const backend = new FakeComputerBackend();
    let aim = "";
    const deliveries: { text: string; aim: string }[] = [];
    backend.focusWindow = async (id) => {
      aim = id;
      if (id === "fake-calculator") {
        entered.resolve();
        await release.promise;
      }
    };
    backend.typeText = async (text) => {
      deliveries.push({ text, aim });
      return { value: text };
    };
    const { manager } = setup(backend);
    await manager.listWindows();
    const first = manager.typeText("audit", "calculator text", "fake-calculator");
    await entered.promise;
    const second = manager.typeText("audit", "browser text", "fake-terminal");
    await Promise.resolve();
    expect(deliveries).toEqual([]);
    release.resolve();
    await Promise.all([first, second]);
    await manager.dispose();
    expect(deliveries.find((d) => d.text === "calculator text")?.aim).toBe("fake-calculator");
  });

  it("aborting a tool during targeting must prevent its later click", async () => {
    const entered = deferred(),
      release = deferred();
    const backend = new FakeComputerBackend();
    const getState = backend.getState.bind(backend);
    backend.getState = async (options) => {
      entered.resolve();
      await release.promise;
      return getState(options);
    };
    const { manager, tools } = setup(backend);
    const abort = new AbortController();
    const result = Effect.runPromise(
      tools
        .get("computer_click")!
        .handler({ label: "Calculate", role: "button", include_screenshot: false }, context()),
      { signal: abort.signal },
    ).catch(() => undefined);
    await entered.promise;
    abort.abort();
    await result;
    release.resolve();
    await new Promise((r) => setTimeout(r, 20));
    await manager.dispose();
    expect(backend.calls.filter((c) => c.method === "click")).toEqual([]);
  });
});

describe("Provider authority invariants", () => {
  it("a fresh invocation re-arms Stop but an older queued invocation cannot", async () => {
    const { manager } = setup();
    try {
      const stopped = await manager.setControlEnabled("audit", false);
      expect((await manager.getThreadState("audit")).controlGeneration).toBe(stopped.generation);
      expect(await manager.admitControl("audit", "request", 0, true)).toBe(false);
      expect(await manager.admitControl("audit", "request", stopped.generation, true)).toBe(true);
      // Re-arming this explicit request never authorizes later turns or goals.
      expect(manager.canContinueChatControl("audit")).toBe(false);
    } finally {
      await manager.dispose();
    }
  });
  it("routes every provider's routine mutations through the same task gate", async () => {
    const { manager } = setup();
    const authorizeAction = vi.fn(async (_name: string) => true);
    const tools = makeAgentGatewayComputerTools({ manager, authorizeAction });
    const type = tools.find((tool) => tool.definition.name === "computer_type_text")!;
    try {
      for (const provider of [
        "codex",
        "claudeAgent",
        "cursor",
        "grok",
        "droid",
        "devin",
        "opencode",
        "pi",
        "antigravity",
      ] as const) {
        // A distinct text per provider keeps every call's repeat-guard key
        // distinct — the guard would refuse a third identical unverified
        // send before the approval gate this test measures.
        await Effect.runPromise(
          type.handler(
            { text: `check-${provider}`, window_id: "fake-terminal", include_screenshot: false },
            {
              ...context(),
              callerProvider: provider,
              principal: { ...context().principal, provider },
            },
          ),
        );
        expect(authorizeAction.mock.calls.at(-1)?.[0]).toBe("computer_type_text");
      }
      expect(authorizeAction).toHaveBeenCalledTimes(9);
    } finally {
      await manager.dispose();
    }
  });
  it.each(["pi"] as const)("lets Synara approve or deny %s actions", async (provider) => {
    const backend = new FakeComputerBackend();
    const manager = new ComputerManager({ backend, actionSettleMs: 0 });
    let allowed = false;
    const authorizeAction = vi.fn(async () => allowed);
    const tool = makeAgentGatewayComputerTools({ manager, authorizeAction }).find(
      (tool) => tool.definition.name === "computer_type_text",
    )!;
    const caller = {
      ...context(),
      callerProvider: provider,
      principal: { ...context().principal, provider },
    };
    const denied = await Effect.runPromise(
      tool.handler({ text: "denied", include_screenshot: false }, caller),
    );
    expect(denied.isError).toBe(true);
    expect(backend.calls.filter((call) => call.method === "typeText")).toHaveLength(0);
    allowed = true;
    const accepted = await Effect.runPromise(
      tool.handler({ text: "approved", include_screenshot: false }, caller),
    );
    expect(accepted.isError).not.toBe(true);
    expect(backend.calls.filter((call) => call.method === "typeText")).toHaveLength(1);
    expect(authorizeAction).toHaveBeenCalledTimes(2);
    await manager.dispose();
  });

  it("rechecks original turn authority after waiting for the desktop", async () => {
    const backend = new FakeComputerBackend();
    const { manager, tools } = setup(backend);
    const entered = deferred(),
      release = deferred();
    const first = manager.withAgentActivity("audit", async () => {
      entered.resolve();
      await release.promise;
    });
    await entered.promise;
    let active = true;
    const caller = {
      ...context(),
      assertCallerTurnActive: () =>
        active
          ? Effect.void
          : Effect.fail(new GatewayToolError("caller_turn_inactive", "original turn ended")),
    };
    const second = Effect.runPromise(
      tools
        .get("computer_type_text")!
        .handler({ text: "never", include_screenshot: false }, caller),
    );
    await Promise.resolve();
    active = false;
    release.resolve();
    await first;
    expect((await second).isError).toBe(true);
    expect(backend.calls.filter((call) => call.method === "typeText")).toHaveLength(0);
    await manager.dispose();
  });
});
