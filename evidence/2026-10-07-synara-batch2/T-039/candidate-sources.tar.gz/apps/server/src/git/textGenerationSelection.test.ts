import { describe, expect, it } from "vitest";

import { resolveTextGenerationInputForSelection } from "./textGenerationSelection.ts";

describe("resolveTextGenerationInputForSelection", () => {
  it("routes Claude provider instances directly to text generation", () => {
    expect(
      resolveTextGenerationInputForSelection(
        {
          provider: "claudeAgent",
          instanceId: "claude_work",
          model: "claude-opus-4-6",
        },
        {
          claudeAgent: {
            homePath: "/tmp/claude-work",
            environment: { ANTHROPIC_AUTH_TOKEN: "token" },
          },
        },
      ),
    ).toEqual({
      modelSelection: {
        provider: "claudeAgent",
        instanceId: "claude_work",
        model: "claude-opus-4-6",
      },
      providerOptions: {
        claudeAgent: {
          homePath: "/tmp/claude-work",
          environment: { ANTHROPIC_AUTH_TOKEN: "token" },
        },
      },
    });
  });

  it("uses the resolved instance driver as the routing authority", () => {
    expect(
      resolveTextGenerationInputForSelection(
        {
          provider: "codex",
          instanceId: "work",
          model: "claude-opus-4-6",
          options: { reasoningEffort: "high" },
        },
        { claudeAgent: { homePath: "/tmp/claude-work" } },
        "claudeAgent",
      ),
    ).toEqual({
      modelSelection: {
        provider: "claudeAgent",
        instanceId: "work",
        model: "claude-opus-4-6",
      },
      providerOptions: { claudeAgent: { homePath: "/tmp/claude-work" } },
    });
  });
});
