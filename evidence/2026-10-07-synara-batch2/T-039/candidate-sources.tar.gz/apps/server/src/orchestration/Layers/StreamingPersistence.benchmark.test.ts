import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { tmpdir, platform, release, totalmem, cpus } from "node:os";
import { join } from "node:path";
import { monitorEventLoopDelay } from "node:perf_hooks";
import { setImmediate } from "node:timers/promises";
import * as NodeServices from "@effect/platform-node/NodeServices";
import {
  CommandId,
  DEFAULT_PROVIDER_INTERACTION_MODE,
  MessageId,
  ProjectId,
  ThreadId,
} from "@synara/contracts";
import { Effect, Layer, ManagedRuntime } from "effect";
import * as SqlClient from "effect/unstable/sql/SqlClient";
import { expect, it } from "vitest";

import { ServerConfig } from "../../config.ts";
import { makeSqlitePersistenceLive } from "../../persistence/Layers/Sqlite.ts";
import { OrchestrationEventStoreLive } from "../../persistence/Layers/OrchestrationEventStore.ts";
import { OrchestrationCommandReceiptRepositoryLive } from "../../persistence/Layers/OrchestrationCommandReceipts.ts";
import { ProjectionSnapshotQuery } from "../Services/ProjectionSnapshotQuery.ts";
import { OrchestrationEngineService } from "../Services/OrchestrationEngine.ts";
import { OrchestrationEngineLive } from "./OrchestrationEngine.ts";
import { OrchestrationProjectionPipelineLive } from "./ProjectionPipeline.ts";
import { OrchestrationProjectionSnapshotQueryLive as OrchestrationProjectionSnapshotQueryBase } from "./ProjectionSnapshotQuery.ts";
import { ServerSettingsService } from "../../serverSettings.ts";

const OrchestrationProjectionSnapshotQueryLive = OrchestrationProjectionSnapshotQueryBase.pipe(
  Layer.provide(ServerSettingsService.layerTest()),
);

// Opt-in only. Each invocation uses a fresh process and a disposable database.
it.skipIf(!process.env.SYNARA_STREAMING_BENCHMARK_OUTPUT)(
  "measures the production streaming engine",
  async () => {
    const output = process.env.SYNARA_STREAMING_BENCHMARK_OUTPUT!;
    const messageBytes = Number(process.env.SYNARA_STREAMING_BENCHMARK_BYTES ?? 200_000);
    const chunkBytes = 40;
    const threadCount = Number(process.env.SYNARA_STREAMING_BENCHMARK_THREADS ?? 1);
    const dir = await mkdtemp(join(tmpdir(), "synara-streaming-benchmark-"));
    const dbPath = join(dir, "state.sqlite");
    const runtime = ManagedRuntime.make(
      OrchestrationEngineLive.pipe(
        Layer.provide(OrchestrationProjectionPipelineLive),
        Layer.provideMerge(OrchestrationProjectionSnapshotQueryLive),
        Layer.provide(OrchestrationEventStoreLive),
        Layer.provide(OrchestrationCommandReceiptRepositoryLive),
        Layer.provideMerge(makeSqlitePersistenceLive(dbPath)),
        Layer.provideMerge(ServerConfig.layerTest(process.cwd(), dir)),
        Layer.provideMerge(NodeServices.layer),
      ),
    );
    const delay = monitorEventLoopDelay({ resolution: 10 });
    try {
      const engine = await runtime.runPromise(Effect.service(OrchestrationEngineService));
      const snapshots = await runtime.runPromise(Effect.service(ProjectionSnapshotQuery));
      const sql = await runtime.runPromise(Effect.service(SqlClient.SqlClient));
      const createdAt = "2026-09-10T12:00:00.000Z";
      const projectId = ProjectId.makeUnsafe("benchmark-project");
      await runtime.runPromise(
        engine.dispatch({
          type: "project.create",
          commandId: CommandId.makeUnsafe("project"),
          projectId,
          title: "Benchmark",
          workspaceRoot: dir,
          defaultModelSelection: null,
          createdAt,
        }),
      );
      const threads = Array.from({ length: threadCount }, (_, index) =>
        ThreadId.makeUnsafe(`benchmark-thread-${index}`),
      );
      for (const threadId of threads) {
        await runtime.runPromise(
          engine.dispatch({
            type: "thread.create",
            commandId: CommandId.makeUnsafe(threadId),
            threadId,
            projectId,
            title: "Benchmark",
            modelSelection: { provider: "codex", model: "gpt-5-codex" },
            interactionMode: DEFAULT_PROVIDER_INTERACTION_MODE,
            runtimeMode: "approval-required",
            branch: null,
            worktreePath: null,
            createdAt,
          }),
        );
      }
      await runtime.runPromise(sql`PRAGMA wal_autocheckpoint = 0`);
      await runtime.runPromise(sql`PRAGMA wal_checkpoint(TRUNCATE)`);
      const memoryBefore = process.memoryUsage();
      let peakRss = memoryBefore.rss;
      let peakHeapUsed = memoryBefore.heapUsed;
      delay.enable();
      await setImmediate();
      const started = performance.now();
      for (let offset = 0; offset < messageBytes; offset += chunkBytes) {
        for (const threadId of threads) {
          await runtime.runPromise(
            engine.dispatch({
              type: "thread.message.assistant.delta",
              commandId: CommandId.makeUnsafe(`${threadId}-${offset}`),
              threadId,
              messageId: MessageId.makeUnsafe("benchmark-message"),
              delta: "x".repeat(Math.min(chunkBytes, messageBytes - offset)),
              createdAt,
            }),
          );
        }
        if ((offset / chunkBytes) % 100 === 0) {
          const memory = process.memoryUsage();
          peakRss = Math.max(peakRss, memory.rss);
          peakHeapUsed = Math.max(peakHeapUsed, memory.heapUsed);
          // Yield every 100 chunks so timer delay has a reproducible sampling window.
          await setImmediate();
        }
      }
      await setImmediate();
      const streamMs = performance.now() - started;
      delay.disable();
      const streamingWalBytes = (await stat(`${dbPath}-wal`)).size;
      const readStarted = performance.now();
      const streaming = await runtime.runPromise(snapshots.getSnapshot());
      const streamingReadMs = performance.now() - readStarted;
      expect(streaming.threads).toHaveLength(threadCount);
      for (const thread of streaming.threads)
        expect(thread.messages[0]?.text).toBe("x".repeat(messageBytes));
      const completionStarted = performance.now();
      for (const threadId of threads) {
        await runtime.runPromise(
          engine.dispatch({
            type: "thread.message.assistant.complete",
            commandId: CommandId.makeUnsafe(`${threadId}-complete`),
            threadId,
            messageId: MessageId.makeUnsafe("benchmark-message"),
            createdAt,
          }),
        );
      }
      const completionMs = performance.now() - completionStarted;
      const completed = await runtime.runPromise(snapshots.getSnapshot());
      expect(completed.threads).toHaveLength(threadCount);
      for (const thread of completed.threads)
        expect(thread.messages[0]?.text).toBe("x".repeat(messageBytes));
      const finalWalBytes = (await stat(`${dbPath}-wal`)).size;
      const hashes: Record<string, string> = {};
      for (const path of [
        "src/orchestration/Layers/ProjectionPipeline.ts",
        "src/persistence/Layers/ProjectionThreadMessages.ts",
        "src/persistence/Migrations.ts",
        "src/orchestration/Layers/OrchestrationEngine.ts",
        "src/persistence/messageTextChunks.ts",
      ])
        hashes[path] = createHash("sha256")
          .update(await readFile(path))
          .digest("hex");
      await writeFile(
        output,
        JSON.stringify(
          {
            environment: {
              node: process.version,
              os: `${platform()} ${release()}`,
              cpu: cpus()[0]?.model,
              totalMemoryBytes: totalmem(),
              sqlite: await runtime.runPromise(sql`SELECT sqlite_version() AS version`),
            },
            workload: {
              messageBytes,
              chunkBytes,
              threadCount,
              transactions: Math.ceil(messageBytes / chunkBytes) * threadCount,
              checkpoint: "disabled during measurement; setup WAL truncated",
              timerYieldEveryChunks: 100,
            },
            streamingWalBytes,
            finalWalBytes,
            streamMs,
            streamingReadMs,
            completionMs,
            eventLoopDelayMs: { max: delay.max / 1e6, p99: delay.percentile(99) / 1e6 },
            memoryBefore,
            memoryAfter: process.memoryUsage(),
            sampledPeakRss: peakRss,
            sampledPeakHeapUsed: peakHeapUsed,
            hashes,
          },
          null,
          2,
        ),
      );
    } finally {
      delay.disable();
      await runtime.dispose();
      await rm(dir, { recursive: true, force: true });
    }
  },
  180_000,
);
