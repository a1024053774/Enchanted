from pathlib import Path
Path("/Volumes/WD-Elements/dev-cache/synara/tmp/t039-repair03/a2a-t039-service-T2HxHG/oracle-ran").touch()
