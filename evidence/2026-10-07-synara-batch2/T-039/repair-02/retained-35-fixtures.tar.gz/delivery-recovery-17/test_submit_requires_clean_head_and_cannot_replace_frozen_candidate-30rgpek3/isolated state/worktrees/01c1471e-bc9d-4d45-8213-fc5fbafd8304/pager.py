"""Deliberately faulty starter: ignores ordering and cursor; used to preserve red evidence."""
import json
import sys

request = json.load(sys.stdin)
print(json.dumps({"items": request["items"][:request["limit"]], "next_cursor": None}))

# Independent candidate c6b3fd0eefeb44d9a4be22664af5a3b2
