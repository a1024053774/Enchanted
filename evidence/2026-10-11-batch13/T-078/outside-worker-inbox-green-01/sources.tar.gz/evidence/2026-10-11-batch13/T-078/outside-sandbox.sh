#!/bin/bash
set -eu
# Controller-run runtime checkpoint. No vendor CLI or Claude fixture is started.
# Worker inbox green contracts and four single-rule counterexamples. No Claude.
python3 /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_runtime.py --scope worker-inbox --phase green --rule-mutants --label "${1:-outside-worker-inbox-green-01}"
