# a2a 门禁、编排后台与工作台

T-078-2 P1 已接入 `controller_start --task ID --manifest /绝对路径/manifest.json`。
当前仅支持隔离 HOME／CLAUDE_CONFIG_DIR、公开假 key、loopback Messages API 的单提交探针，
不支持真登录或多回合主控。启动需逐次批准；完整材料及静态检查见
[P1 引导与退出核对材料](../evidence/2026-10-11-batch13/T-078/P1-APPROVAL-05.md)。
当前材料仅在隔离 settings.json 设置 `theme: dark`，并加入 `IS_DEMO=1`；
启动仍待单独审批。遇到 API key 批准或目录信任提示，保存终端原文并停下，不输入或选默认。
cleanup 绑定 CLI 的 PID、启动时间和命令，确认退出前不报告 PASS 或删除隔离根。
角色卡经固定 CLI 帮助列出的 `--append-system-prompt` 传完整文本；启动记录仍保留来源路径。
P1 API 在启动时绑定 loopback 的端口 0，由操作系统分配端口并先记录实际 manifest；
主控运行入口拒绝未分配的端口 0。旧实例材料已过期。
真实 CLI 曾停在首次使用的主题引导；本次配置尚未运行，hook 与主控协议仍未验证。
旧 T-078-1 的通过结果不替它背书。

用 Node 26.5 及其原生 TypeScript 类型剥离直接运行，无 Bun、打包或编译步骤：

```sh
node workbench/src/gates/cli.ts --state /绝对路径/隔离状态目录 status --task 任务编号
```

先对同一隔离目录调用 `daemon_start`，结束时调用 `daemon_stop`。客户端只通过
`control.sock` 访问常驻后台，不再直接打开门禁库。后台未启动时命令明确失败，不自动拉起或重试。
`daemon_start` 使用 detached 子进程和独立日志。
普通请求的传输期限为 120 秒；`run` 的有效显式等待参数另加 120 秒收尾余量，
避免长任务被短客户端期限截断。传输超时仍报告结果未知，不重放请求。
`daemon_stop` 显式进入关闭流程，返回 `stopping: true` 是受理确认；以 PID/端点消失确认退出。
关闭时拒收新请求，自动 run 在等待及门禁边界停止推进；已开始的门禁操作与回执写入先收尾，
随后停止自建窗格、保存退出事件、关闭数据库。停止不替代 reclaim，也不把失败或未知结果改成通过。

启动前显式设置 `A2A_OPERATOR_CREDENTIAL`，指向本次启动专用、尚不存在的绝对文件路径。
启动者创建 0600 凭据文件，后续管理 CLI 与 Electron 从同一环境变量读取；后台按凭据
认定执行主控身份，不按 `--from` 或 `--role` 自报。每次后台启动使用新凭据，旧文件不覆盖。
不要把凭据内容放进 argv、证据或 Git；后台停止后由创建者清理。只读查询仍可匿名调用。
这条凭据路径与交互输入的首个候选已通过四项真实入口合同；库客户端通过八项检查。
8/9/18 复验曾在 coop 的 submit 出现身份回归；分开管理凭据与原生身份后，
outside-inbox-02 的 8/9/18 全部通过。后续窗格运行时变更尚待真实入口复验。
这些局部结果不代表 T-078 整票完成。

后台把认证后的角色作为 GateActor 传给门禁；只有真实原生会话才提供 SubmitCaller
的 thread/turn。管理凭据不虚构线程，不能替代受管 worker 的原生身份。
后台常驻与一次真实窗格派发已验证；工具沙箱的 socket 连接曾被 EPERM 拒绝。
T-075 rev 4 的 A2 探针在工具层被拒，未验证成；按用户决定改用 B 文件转交。
B 已通过隔离真实 Codex 的显式交付、机械检查与 CAS 集成；本卡一次独立审查 PASS。
该结论限卡 3 的本地夹具；Electron 与重启恢复的实现和验证进度另见文末卡 4 记录，完整工作台尚未切换。

受管派发提示要求 `git add <路径>` 与 `git commit …` 各自独立执行，
检查命令另行运行，以便两个已授权的 Git 前缀规则分别匹配。
若独立命令仍被拒，worker 上报并结束，不自行重试或调整沙箱。

`acceptance/entry/a2a_gates.py` 将参数原样交给这里的 CLI。门禁核心仍由后台中的
`A2AGates.call` 独占写入；保留操作锁、fence、CAS、attempt 绑定和中断恢复。
受管任务通过 JSON 任务卡注册；交付按卡检查路径、完成条件与提交尾注，
通过后以 CAS 推进项目工作分支。普通会话的 `attach --instructions` 仍是提示文本，
不参与受管任务注册。
旧 HTTP 转接经本次对话确认后删除；本入口只接受本地门禁命令。

## 任务卡与交付

使用同一个 CLI 生成模板，填写目标、非目标、路径、argv 完成条件等字段后校验并保存：

```sh
export A2A_OPERATOR_CREDENTIAL=/绝对路径/隔离目录/operator-本次启动.json
node workbench/src/gates/cli.ts --state /绝对路径/state daemon_start
node workbench/src/gates/cli.ts --state /绝对路径/state card_template --task T-080-1 --repo /绝对路径/repo --ticket /绝对路径/T-080.md
node workbench/src/gates/cli.ts --state /绝对路径/state card_validate --task T-080-1 --card /绝对路径/card.json
node workbench/src/gates/cli.ts --state /绝对路径/state card_save --task T-080-1 --card /绝对路径/card.json --expected-version 0
node workbench/src/gates/cli.ts --state /绝对路径/state create --task T-080-1 --repo /绝对路径/repo --branch refs/heads/main --card-version 1
```

模板含 13 个字段。CLI 值精确为 `Claude Code` 或 `Codex`；任务类型为规格中的八个值。
完成条件格式为 `{"argv":["python3","acceptance/check.py","{worktree}"]}`，
`{worktree}` 只能占据完整的一个参数，在独立 M worktree 中运行。完成条件非零退出仍
返回 `oracle_failed`，这个名字只为保持已有公开错误预期，不存在旧 oracle 注册入口。
create 不再接受 `--base`、`--oracle` 或 `--instructions`。

版本与快照存入同一 SQLite 库，旧记录不修改；`card_show --card-version N` 读指定版本。
注册冻结选定版本，认领时再追加包含当时工作分支起点和唯一写入者的绑定快照。
源文件或后续卡版本不会改变已注册合同。显式采用新卡用
`revise --spec-rev N --card-version V`，会使旧 attempt 与候选失效。

路径用仓库相对文件名、末尾 `/` 的目录或 `.`，禁止项优先，不解释 glob。
门禁检查候选相对起点的净改动，以及 M 相对 G 的净改动。
尾注归属按 Task、Attempt、Session、Role 四项核对；外来任务或坏尾注被拒。
完全无 A2A 尾注的提交产生来源为“推断：缺尾注”的 action 用户输入和派生人工介入，
不阻止集成，同 attempt 同 commit 重验不重复记录。

工作分支必须是已存在的 `refs/heads/*`。门禁不再读写 `refs/a2a/integration`，历史引用保留。
Git 事务先锁住 G，在实际检出目录用双树快进保护本地修改，再 CAS 到 M；覆盖型修改被拒，
无冲突修改保留。未知副作用保留原 integration intent 待核对。没有 push、stash 或用户目录 reset。
验收仍由 verify 完成，integrate 只接受与该 attempt、卡快照和候选绑定的通过记录。

## 安装

```sh
cd workbench
python3 -c 'import os; assert os.path.ismount("/Volumes/WD-Elements"), "外置盘未挂载"'
electron_config_cache=/Volumes/WD-Elements/a2a-electron-cache npm ci --cache /Volumes/WD-Elements/a2a-t075-npm-cache
npm ls --depth=0
```

缓存由本目录 `.npmrc` 指向外置盘；安装前检查挂载与缓存位置，失败就退出。
`node_modules` 是本目录中的普通目录。依赖锁定 `effect@4.0.0-beta.25`；来源预览包
改为 npm 官方包是执行主控的决定，记录见本批证据 `controller-decision-01.md`。

另锁定官方 `node-pty@1.1.0`。本次 darwin-arm64 预编译包使用 `--ignore-scripts` 安装时，
`prebuilds/darwin-arm64/spawn-helper` 曾缺执行位，已由执行主控手工改为 755。
后台启动核对 node-pty 实际选择的 helper 是否可执行；失败直接报错，不自动 chmod 或重装。

## 运行时边界

`GateRuntime` 由 `panes.ts` 实现一个 Codex worker 窗格；没有 Claude 或普通 attach
会话。生产 CLI 没有直接开库的运行时替代入口。
旧 `native-runtime.ts` 是隔离测试边界；它的旧证据不能证明新后台或真实窗格可用。

真实启动需在 `daemon_start --launch-config /绝对路径/launch.json` 中给出固定 Codex
路径、隔离 `codex_home`、角色卡及版本、代码版本、hook 授权引用和回合上限。
`dispatch --runtime-mode workspace-write` 始终启动交互 zsh 中的 Codex：`-a never`、
workspace-write、任务卡指定的 gpt-6-astra 或 gpt-6.1-sol、xhigh、Fast 请求、关闭更新检查。
网络及托管网络代理关闭，不设置 socket 放行名单。三个 hook 向同一 CLI 的 `signal`
送原始 stdin；Stop 另外读取显式请求文件。启动参数、环境白名单、请求模型与实际回合模型分开记录。

初态为“未知”。`pane_process_info --thread ID` 从 ps 核对前台领导进程；按本卡决定，
执行主控再用 `pane_release --thread ID --reason 原因` 首次放行，记 executor action，
不当作用户输入或人工介入。派发先登记、空闲时 bracketed paste 后单独 CR；CR 写出即忙，
只有匹配主回合的 Stop 才返回空闲。不读屏，Esc 或缺 Stop 不自动放行。
Esc 后由窗口的“放行排队消息”按钮解除中断占用。后台校验窗口凭据、固定 attempt
和中断状态，先记录用户 action，再尝试发送队首；受管 worker 同时记人工介入。
该入口已通过 outside-runtime-green-01 的真实窗口检查；主控排队仍待后续验证。

`daemon.ts` 导出 `serve(root, config, createGates?)`。第三个参数只供测试在代码里注入门禁对象（受控线程运行时或变异体），默认是 `new A2AGates(root, panes)`。产品的 `daemon_start` 不传这个参数，CLI 和环境变量也都没有对应的开关。交付 8、恢复 9、编排 18 这三套旧场景，经 `workbench/tests/run_daemon_acceptance.py` 在本后台入口上运行（T-075-5）。这个运行器为每个测试在短路径上显式启动并停止一个隔离后台，不改 `acceptance/` 中的任何断言。

## 主控启动记录（静态准备）

主控启动的静态准备入口为 `controller_prepare --task ID --preset ideation|executor`，
使用后台的管理凭据。启动配置的 `controllers` 按这两个 preset 分别提供
`executable`（绝对路径）、`model`、`effort`、`settings`、`role_card`、
`role_card_revision`，并提供公共 `code_revision`。settings 当前只收 hooks 与
permissions；认证环境另待用户决定，不能把凭据放入 settings。

此命令只构造 argv 和追加启动记录：包含 `--session-id`、`--model`、`--effort`、
`--settings` 及角色卡正文，attempt 为 null，execution_state 为 prepared。
它不创建进程、不读取 CLI 版本、不签发会话凭据；CLI 版本记 unknown，生命周期为
“未启动”，明确标记“待真实 Claude 复核”。静态构造／存储红绿已通过，真实 CLI
和主控多窗格继续等待用户的认证与额度决定。

## Electron 窗口

窗口经同一个 Unix socket 查询后台，不加载 node-pty 或 SQLite。显示一个项目、任务、
窗格和门禁状态；终端网格固定为 160×45。当前输入候选在固定的活动 launch 上启用
键盘、IME 和粘贴入口，历史窗格保持只读；全部输入由后台写入 node-pty，renderer
没有后台凭据、PTY 或数据库权限。窗口凭据绑定一个 launch，关闭时撤销，不随
current_attempt 更换目标。后台在等待前占用窗口序号和 request_id，重用请求号会被拒绝；
输入调用失败时停止后续发送，不自动重投。

输入在写入 PTY 前进入 user_inputs；受管 worker 的人工介入在同一事务里派生，带
input_id。粘贴去掉协议包裹后保存文本；终端控制键记 action。长度为零的 onData
只记带窗口、序号和时间的 terminal_input_empty，不写 PTY、不生成用户输入或介入。
组合输入开始时先登记草稿占用；结束或取消组合输入不代表 CLI 输入行为空，
占用由用户提交或 Esc 后明确放行清除。二进制终端输入按原始单字节写入，保存
带 base64 原始字节的 action，不把其中的控制字节当成用户提交。上述三项修复
已通过 outside-input-green-01；主控多窗格和主控凭据运行路径仍待真实 Claude 复核。

设备查询应答由后台处理，前端用公开 parser 接管查询，避免自动应答混入用户输入。
按 T-078 执行主控决定 03，前端拦截 DECSET/DECRST 1004；混合序列中的其他模式
保持顺序交给 xterm。每次拦截记原始序列。CLI 因此收不到工作台窗口的焦点变化。
P1 与首个候选的四项输入合同已经通过；其余失败方式和当前扩展后的候选仍待复验。

构建必须在外置盘真实挂载后进行，每次使用一个尚未存在的构建槽：

```sh
npm --prefix workbench run build -- --slot local-01
node workbench/app/start.mjs --build /Volumes/WD-Elements/a2a-workbench/local-01/dist --state /绝对路径/state --task 任务编号 --user-data /绝对路径/ui
```

Electron 的启动环境须带该后台对应的 `A2A_OPERATOR_CREDENTIAL`；它只在 main
进程中读取，并用于领取窄的窗口输入凭据，不传给 preload 或 renderer。

缓存、构建临时目录和 dist 都在外置盘；没有内置盘回退。`A2A_BUILD_VOLUME` 可指定
验收用的检查路径，普通目录和符号链接不能通过挂载检查。已有构建槽不会覆盖；不要在
输出目录中放源码或依赖链接。启动只读取已有构建产物，不自动构建、装包或启动后台。

默认后台目录为 `~/Library/Application Support/a2a-orchestrator`，默认 Electron 数据位于其
`ui/` 子目录。验证时同时显式指定后台与 UI 的 `/tmp` 隔离目录。

## 库版收件箱客户端（当前只在夹具项目验证）

`workbench/bin/inbox` 复用同一门禁 CLI 与后台，不打开数据库、不读写文件版收件箱。
必须显式传 state（或本会话 A2A_STATE）。管理端提供对应的管理凭据；worker 的
send/list/ack/ready 沿既有 B 请求文件通路，由本会话 Stop 携带实际 launch 凭据
转交，结果以门禁回执写回。queued 只表示本地请求已排队，不是后台执行成功。
转交时及门禁内的身份检查同时核对原生进程和当前 attempt，撤销后不能继续写入。
`--from`、`--role` 只是沿用命令格式，不能改变实际身份；worker 只能发 issue、
读取本人的条目、ack 本人的条目；ready 按权限拒绝 worker。
worker 入口已通过 outside-worker-inbox-green-01 的 14 项检查；四项单规则变异体
分别产生了可读回的越权结果，且只触发对应断言失败。最终变基候选仍须重新验证。

```sh
workbench/bin/inbox --state /绝对路径/state ready --project 项目编号
workbench/bin/inbox --state /绝对路径/state list
workbench/bin/inbox --state /绝对路径/state send --to ideation --kind report --body-file /绝对路径/report.txt
workbench/bin/inbox --state /绝对路径/state ack --id 收件箱条目号
```

ready 只读取该后台已绑定项目的 ticket，返回可执行且依赖已关闭的就绪项；字段
不合规时返回诊断和失败状态。它不标记就绪、不写项目地图，也不接受任意仓库路径。

收件箱、ack 和投递收据都只追加。`queued` 是已排队，`delivered` 才是运行时确认写入；
重复 ack 复用原条目及投递结果，不重发。读取 queued 收据时可追加运行时后来确认的状态。
没有实际接收者时，条目和未送达原因保留，命令不能报告投递成功。

当前只完成收件箱领域逻辑与客户端接线；Panes 的主控唤醒和中断、角色会话凭据、
worker 收件箱命令的 Stop 转交仍待 T-078 后续步骤，因而不能作日常派发入口。
本仓库的 `scripts/inbox` 保持原样，切换前不双写。领域测试没有启动任何 CLI，不能
替代真实窗格验证。库客户端 8/8 已通过；coop 的 7 项身份回归修正后，8/9/18
仍待重新验证，业务断言没有改动。

```sh
node workbench/src/gates/cli.ts --state /绝对路径/state workbench_snapshot --task 任务编号
node workbench/src/gates/cli.ts --state /绝对路径/state pane_output --launch 启动记录号 --offset 0 --max-bytes 65536
```

`workbench_snapshot` 可加 `--launch` 查看本任务的历史窗格。窗口第一次选定 launch 后固定
该身份，不随 current_attempt 改变而切换。`pane_output` 返回 base64 原始字节和
start_offset、next_offset、total_bytes；每块最多 65536 字节，从同一追加 trace 读取。
新窗口从 0 补回，已有窗口收到 xterm 的解析完成回调才推进游标；缺失、缩短或错序
明确报错，不跳过字节。关掉 Electron 只断开视图，后台和窗格由独立进程托管。

后台重启会追加 `pane_recovered`，原窗格只作历史查询，不重建 PTY、令牌、队列或
worker。已有 pane_exit 可证明停止时执行显示“已中断”；没有结束证据显示“未知”。
窗格退出回调会最后增量读取已绑定的原生会话文件，再记录 pane_exit；主动停止和后台
停止也经过这条路径，不依赖 Stop hook。完整记录追加进库和 native.jsonl；文件缺失、
截断、解析失败或未完成的一行记为 native_final_read_failed，保留读到的位置，窗格
仍显示未知／中断，不补造完成事件。停止后的查询不继续采集新的原生字节。
测试的最终 SQLite 读回统一使用 `fixture_artifacts.archive_stopped_database`：确认 writer 退出，
复制主库与残留 WAL，只在归档副本上改为独立 DELETE 文件，再以只读方式检查。
`test_probe_cleanup.py` 检查关闭后的 WAL、未遗漏的已提交行、原文件保留和未确认退出时保留现场；
`test_stopped_readback.py` 重放三个停止后直读原库失败的夹具。
门禁状态原值保留，因此“门禁已认领”和“执行已中断”可以同时出现。原 verify/integrate
命令显式重放才执行恢复，启动或读取窗口不能把未知结果改成通过。
崩溃残留的 socket/PID 文件阻止启动；产品不会按 PID 猜测所有者并自动接管。

默认产品路径为 `~/Library/Application Support/a2a-orchestrator`；本卡测试只用显式
`--state /tmp/...`，不创建默认路径，不接触正式 `a2a-workbench` 目录。
新增 launch_records、dispatch_records、orchestration_events、relay_requests、relay_results
都在 state.sqlite3，触发器禁止
UPDATE/DELETE。按 T-075 rev 3，原门禁状态表保留为由事件推出的当前视图，历史以事件为准；
membership.sqlite3 和锁库保留。`stateConsistency.ts` 提供只读事件重建与逐表比较；
不补事件、改表或修存储。对静止的夹具库运行，报告一致、不一致或无法从现有事件重建：

```sh
node workbench/src/stateConsistency.ts --state /绝对路径/state --output /绝对路径/新报告.json
```

报告包含 tasks、历史 attempts/verifications、runs、attachments 与另库的 memberships/
session_presets，列出差异、缺历史来源和未覆盖表。attachment creating 缺事件、active 行与
attached 事件不同事务，以及成员/预设另库覆盖写都不能用最终行相等掩盖；诊断不一致或
不可重建返回 INCOMPLETE。两库分别有读事务，不宣称跨库同事务。

受管 worker 仍使用同一 CLI 显式 `submit`；`status`、`issue` 也走同一条转交路径。
CLI 将带 task、attempt、session、fence、spec_rev 的请求写入 `A2A_REQUEST_DIR`，返回
`queued=true, delivered=false`；这仅表示文件已落盘。每个 attempt 使用独立的
`/tmp/a2a-requests-*` 目录，位于 Git 工作树外，不污染候选提交。Stop hook 读取文件后，
经同一 CLI 向后台转交；没有文件就没有交付。后台仍检查当前 attempt、回合身份及原门禁条件。

请求用 `request_id` 去重：相同内容返回原结果，不重复执行；同一编号换内容明确拒绝。
身份不符、字段不完整及重复转交都有追加事件。旧 Stop 不消费尚未处理的请求，
处理结果未知时保留意图，不自动重试。一次 Stop 的新结果合成一条 `⟦门禁 #序号⟧`
回执，先登记，再在空闲窗格里 bracketed paste 并单独回车。回执会启动新的原生回合，
计入启动记录里的回合上限；本卡已获准一个交付回合和一个只确认回执的回合。
Git 尾注钩子从隔离 CODEX_HOME 中读取 CODEX_THREAD_ID 绑定的唯一根 CLI JSONL，
以最新 task_started 对应的 turn_context 取实际模型与强度；辅助会话不提供取值。
当前回合缺上下文时写 unknown，不沿用上一回合或请求值。启动请求另存
A2A_MODEL_REQUESTED/A2A_EFFORT_REQUESTED；实际沙箱读取与提交时序还须通过真实回合验收。

运行时 agent 身份与交付回合分开：attempt 绑定 launch/thread、shell、原生会话和 Codex 领导者；
首次输入前原生日志可以尚未出现，执行者核对有效前台领导者后通过 pane_release 放行首次派发；
门禁只补首次可观测的原生会话，不用请求值补身份。
run/reclaim 核对该身份，回执回合改变不会覆盖已提交的 turn_id。submit 仍要求当前活动
caller/turn 和受管 session/fence/spec/attempt 一致。换领导者、换原生会话或缺已绑定事实
拒收；停止后只沿用已核对的身份及确认的生命周期，不按新 PID 接管。

`run_daemon_acceptance.py --suite <coop|recovery|run> --output-root /绝对路径/证据根 --label 新标签`
可把本轮三套验收写到独立证据目录；默认输出根沿用原 T-075/card-5。旧 validation 模式
包含冻结的基线运行器，保留原输出根；新切片使用 suite/probe，不混写旧证据。

## 来源与改动

来源固定为 Synara 提交 `49cae984f22924de006e0f8358cb447eb881aaf6`。
迁入 `core`、`cli`、`membership`、`rolePermissions`；MIT 版权与完整许可保留在源码及
[LICENSE.synara](LICENSE.synara)。只提取门禁及其请求校验实际需要的 schema、类型与依赖，
其中模型选择的已有解码规则保持原样，不代表本工作台支持这些模型运行时。

进程执行直接使用 Node 的 `child_process.execFile`；本卡面向 macOS，不带原平台适配层。
本地 import 补 `.ts` 后缀，构造器参数属性展开为等价字段与赋值。
验收入口只调用本仓库门禁；旧 fork 的实现不再由这些入口加载。

重现命令与完整证据见
[T-075-1 迁移记录](../evidence/2026-10-10-batch12/T-075/RESULTS.md) 和
[T-075-2 当前结果](../evidence/2026-10-10-batch12/T-075/card-2/RESULTS.md)；
后台与 B 的进度见 [T-075-3 运行记录](../evidence/2026-10-10-batch12/T-075/card-3/RESULTS.md)。

只读窗口与重启查询见 [T-075-4 运行记录](../evidence/2026-10-10-batch12/T-075/card-4/RESULTS.md)。
界面迁入片段来自已推送的 `49cae984f22924de006e0f8358cb447eb881aaf6`：
`apps/web/src/components/TerminalScrollToBottom.tsx`、`apps/web/src/index.css` 与
`apps/web/src/theme/theme.seed.generated.ts`。保留 MIT 声明，未迁入 provider 或 MCP 网关。
