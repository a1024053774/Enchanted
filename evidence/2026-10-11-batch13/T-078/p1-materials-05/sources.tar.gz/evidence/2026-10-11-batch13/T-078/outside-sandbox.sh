#!/bin/bash
set -eu
case "${1:-p1-launch-05}" in
  p1-launch-05) phase=launch ;;
  p1-continue-05) phase=continue ;;
  p1-cleanup-05) phase=cleanup ;;
  *) echo 'Unknown P1 stage; no process started' >&2; exit 2 ;;
esac
/usr/bin/python3 -B /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_p1.py --materials /Users/luckye/Documents/Code/a2a-wt-t078/evidence/2026-10-11-batch13/T-078/p1-materials-05 --phase "$phase"
