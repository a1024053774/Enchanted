#!/bin/bash
set -eu
# Controller-run runtime checkpoint. No vendor CLI or Claude fixture is started.
# Actual worker inbox client red contracts; no Claude CLI or fixture starts.
python3 /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_runtime.py --scope worker-inbox --phase red --label "${1:-outside-worker-inbox-red-01}"
