// Codex dark theme seed from Synara 49cae984f, apps/web/src/theme/theme.seed.generated.ts.
// Copyright (c) 2026 T3 Tools Inc. and Emanuele Di Pietro. MIT; see ../LICENSE.synara.
import { createRoot } from 'react-dom/client';
import { useEffect, useRef, useState } from 'react';
import { Terminal } from '@xterm/xterm';
import '@xterm/xterm/css/xterm.css';
import './style.css';
import { TerminalScrollToBottom } from './TerminalScrollToBottom';
import { createFocusSafeWriter, ownTerminalQueries } from './terminalOutput.mjs';

type Snapshot = {
  daemon: string;
  input_enabled: boolean;
  task: { task_id: string; title: string; project_id: string; repo: string; state: string;
    current_attempt: { attempt_id: string; state: string } | null; candidate_commit: string | null;
    verification: { state: string } | null; integration_intent: { state: string } | null };
  launch: { id: string; attempt: string; role: string; cli_version: string; model_requested: string } | null;
  pane: { launch: string; state: string; lifecycle: string; state_source: string; historical?: boolean; failed: string | null;
    interrupted?: boolean } | null;
};
type Chunk = { launch: string; start_offset: number; next_offset: number; total_bytes: number; data_base64: string };
declare global { interface Window { a2a: { snapshot(): Promise<Snapshot>; output(offset: number): Promise<Chunk>;
  input(data: string): Promise<void>; releaseQueue(): Promise<void>; observeFocus(rawSequence: string): Promise<void> } } }
const gateNames: Record<string, string> = { ready: '待认领', preparing: '准备中', claimed: '已认领', submitted: '已交付',
  verifying: '验收中', verified: '验收通过', integrating: '集成中', accepted: '已集成', paused: '已暂停', revoked: '已撤销' };
const activityNames: Record<string, string> = { unknown: '未知', idle: '空闲', busy: '忙' };
const lifecycleNames: Record<string, string> = { running: '运行中', interrupted: '已中断', unknown: '未知', ended: '已结束' };

function Workbench() {
  const mount = useRef<HTMLDivElement>(null);
  const reconnect = useRef<() => void>(() => {});
  const releaseQueue = useRef<() => void>(() => {});
  const [terminal, setTerminal] = useState<Terminal | null>(null);
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(true);
  const [offset, setOffset] = useState(0);
  const [inputError, setInputError] = useState<string | null>(null);
  const [releasing, setReleasing] = useState(false);

  useEffect(() => {
    let mounted = true, running = false, cursor = 0, total = 0;
    let boundLaunch: string | null = null;
    let inputFailed = false, releasePending = false;
    const term = new Terminal({ cols: 160, rows: 45, disableStdin: true, cursorBlink: true,
      cursorInactiveStyle: 'none', screenReaderMode: true, scrollback: 10000, fontSize: 11, lineHeight: 1,
      fontFamily: '"SF Mono", "SFMono-Regular", Menlo, monospace',
      theme: { background: '#111111', foreground: '#fcfcfc', selectionBackground: '#0169cc66' } });
    term.open(mount.current!);
    const failInput = (failure: unknown) => {
      inputFailed = true; term.options.disableStdin = true;
      if (mounted) setInputError(`输入尚未确认，已停止发送：${String(failure)}`);
    };
    releaseQueue.current = () => {
      if (releasePending || inputFailed) return;
      releasePending = true; setReleasing(true);
      void window.a2a.releaseQueue().then(() => window.a2a.snapshot()).then(value => {
        if (mounted) setSnapshot(value);
      }).catch(failInput).finally(() => {
        releasePending = false;
        if (mounted) setReleasing(false);
      });
    };
    const writeOutput = createFocusSafeWriter(term, (type: string, detail: { raw_sequence: string }) => {
      if (type === 'focus-mode-intercept') void window.a2a.observeFocus(detail.raw_sequence).catch(failInput);
    });
    ownTerminalQueries(term, () => {});
    const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
    term.onData(data => { void window.a2a.input(data).catch(failInput); });
    // Binary mouse encodings need a byte-preserving transport. This slice
    // records the missing capability as an explicit input failure.
    term.onBinary(() => failInput('尚未接通二进制终端输入'));
    setTerminal(term);
    const delay = () => new Promise((resolve) => setTimeout(resolve, 100));
    async function read() {
      if (running || !mounted) return;
      running = true; setConnecting(true); setError(null);
      let nextSnapshot = 0;
      try {
        while (mounted) {
          if (Date.now() >= nextSnapshot) {
            const value = await window.a2a.snapshot();
            if (!mounted) break;
            if (boundLaunch && value.launch?.id !== boundLaunch) throw new Error('窗格身份改变，已停止读取');
            if (value.launch) boundLaunch = value.launch.id;
            term.options.disableStdin = inputFailed || !value.input_enabled;
            setSnapshot(value); setConnecting(false);
            nextSnapshot = Date.now() + 1000;
          }
          if (!boundLaunch) { await delay(); continue; }
          const chunk = await window.a2a.output(cursor);
          if (!mounted) break;
          const bytes = Uint8Array.from(atob(chunk.data_base64), (char) => char.charCodeAt(0));
          if (chunk.launch !== boundLaunch || chunk.start_offset !== cursor || chunk.next_offset !== cursor + bytes.length ||
              chunk.total_bytes < total || chunk.next_offset > chunk.total_bytes) throw new Error('输出不完整，已停止读取');
          total = chunk.total_bytes;
          if (bytes.length) {
            await writeOutput(decoder.decode(bytes, { stream: true }));
            cursor = chunk.next_offset;
            if (mounted) setOffset(cursor);
          }
          if (cursor === total) await delay();
        }
      } catch (failure) {
        if (mounted) { setError(String(failure)); setConnecting(false); }
      } finally { running = false; }
    }
    reconnect.current = () => { void read(); };
    void read();
    return () => { mounted = false; term.dispose(); };
  }, []);
  const task = snapshot?.task;
  const pane = snapshot?.pane;
  const historical = Boolean(snapshot?.launch && task?.current_attempt?.attempt_id !== snapshot.launch.attempt);
  return <div className="workbench">
    <aside className="sidebar">
      <div className="brand">a2a <span>工作台</span></div>
      <div className="nav-label">项目</div>
      <div className="project-name">{task?.project_id ?? '读取中'}</div>
      <div className="task-row" aria-current="page"><span className="nav-dot" /><span>{task?.title ?? '正在连接后台'}</span></div>
      <div className="sidebar-footer">原生 CLI · 本地编排</div>
    </aside>
    <main>
      <header className="task-header">
        <div><div className="eyebrow">{task?.task_id ?? '任务'}</div><h1>{task?.title ?? '正在读取任务'}</h1></div>
        <span className={'connection ' + (error ? 'warning' : '')}>{error ? '后台未连接 · 上次记录' : connecting ? '正在连接' : '后台已连接'}</span>
      </header>
      {error && <div className="connection-error" role="alert"><span>{error}</span><button onClick={() => reconnect.current()}>重新连接</button></div>}
      {inputError && <div className="connection-error" role="alert">{inputError}</div>}
      <section className="pane" aria-label="交互终端">
        <div className="pane-header"><strong>{snapshot?.launch?.cli_version ?? '窗格'}</strong>
          <span className="readonly">{snapshot?.input_enabled && !inputError ? '可输入' : '只读'}</span><span className="pane-identity">{snapshot?.launch ? `worker · ${snapshot.launch.id.slice(0, 8)}` : '尚未启动窗格'}</span>
          <span className="pane-state" data-state={error ? 'unknown' : pane?.state ?? 'unknown'}>{error ? '未知' : activityNames[pane?.state ?? 'unknown'] ?? '未知'}</span>
          <button disabled={!snapshot?.input_enabled || !pane?.interrupted || releasing || Boolean(inputError || error)}
            onClick={() => releaseQueue.current()}>放行排队消息</button>
        </div>
        <div className="terminal-scroll" data-output-offset={offset}><div className="terminal-mount" ref={mount} /></div>
        <TerminalScrollToBottom terminal={terminal} />
        <div className="pane-footer"><span>在受管 worker 中输入会记录为人工介入</span><span data-lifecycle={pane?.lifecycle ?? 'unknown'}>执行：{lifecycleNames[pane?.lifecycle ?? 'unknown'] ?? '未知'}</span></div>
      </section>
      <section className="gate" aria-label="门禁状态">
        <div><span className="eyebrow">{historical ? '当前任务门禁 · 所看窗格属于历史 attempt' : '任务门禁'}</span><strong data-gate-state={task?.state ?? 'unknown'}>{gateNames[task?.state ?? ''] ?? '未知'}</strong></div>
        <dl><div><dt>执行尝试</dt><dd>{snapshot?.launch?.attempt.slice(0, 8) ?? task?.current_attempt?.attempt_id.slice(0, 8) ?? '尚未认领'}</dd></div>
          <div><dt>候选提交</dt><dd>{task?.candidate_commit?.slice(0, 10) ?? '尚未交付'}</dd></div>
          <div><dt>验收</dt><dd>{task?.verification?.state ?? '尚未开始'}</dd></div>
          <div><dt>集成</dt><dd>{task?.integration_intent?.state ?? '尚未开始'}</dd></div></dl>
      </section>
    </main>
  </div>;
}
createRoot(document.getElementById('root')!).render(<Workbench />);
