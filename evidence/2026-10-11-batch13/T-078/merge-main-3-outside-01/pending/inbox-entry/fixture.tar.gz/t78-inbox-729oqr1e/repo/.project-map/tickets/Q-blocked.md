---
id: Q-blocked
title: Q-blocked
type: build
status: open
claimed_by: 
blocked_by: [Q-missing]
ready: yes
ready_by: ideation
ready_rev: 1
---
