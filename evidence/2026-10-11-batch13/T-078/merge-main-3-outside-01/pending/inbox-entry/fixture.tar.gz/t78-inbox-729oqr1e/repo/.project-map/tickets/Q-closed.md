---
id: Q-closed
title: Q-closed
type: build
status: closed
claimed_by: 
blocked_by: []
ready: yes
ready_by: ideation
ready_rev: 1
---
