---
id: Q-claimed
title: Q-claimed
type: build
status: open
claimed_by: someone
blocked_by: []
ready: yes
ready_by: ideation
ready_rev: 1
---
