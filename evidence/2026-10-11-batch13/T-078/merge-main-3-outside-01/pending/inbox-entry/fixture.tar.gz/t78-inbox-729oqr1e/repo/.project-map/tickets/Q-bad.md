---
id: Q-bad
type: build
status: open
ready: yes
ready_by: ideation
blocked_by: []
---
