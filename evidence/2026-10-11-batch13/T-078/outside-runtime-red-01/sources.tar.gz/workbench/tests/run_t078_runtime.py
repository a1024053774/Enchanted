#!/usr/bin/env python3
"""Controller-run runtime checkpoint. No vendor CLI or Claude fixture runs."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

from command_evidence import CommandLog

ROOT=Path('/Users/luckye/Documents/Code/a2a-wt-t078')
BASE=ROOT/'evidence/2026-10-11-batch13/T-078'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--label',default='outside-runtime-red-01')
    parser.add_argument('--phase',choices=['red','green'],default='red')
    args=parser.parse_args()
    if not args.label or args.label in ('.','..') or any(char not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for char in args.label):
        parser.error('A new single-directory label is required')
    out=BASE/args.label;out.mkdir(exist_ok=False)
    env={key:value for key,value in os.environ.items() if not key.startswith(('A2A_','GIT_','CODEX_','CLAUDE_','ANTHROPIC_'))}
    log=CommandLog(out)
    record={'status':'INCOMPLETE','checkpoint_status':'INCOMPLETE','task':'T-078-1','ready_rev':1,
            'worker':'s13-t078','attempt':None,'session':None,'fence':None,'argv':sys.argv,
            'phase':args.phase,'real_model_turns':0,'claude_started':False,'claude_fixture_started':False,
            'expected_contract_failure':['window_user_release_available'] if args.phase=='red' else [],
            'limitations':['逻辑入站 inbox 行由测试预置，不证明主控发送凭据。',
                           '原生接收器只生成最小 Codex 形状日志，不是供应商 CLI 验收。',
                           '真实两分钟与主控凭据路径、Claude 启动、多窗格、二进制输入及最终回归仍待完成。']}

    def save():
        (out/'checkpoint.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    def run(argv,name,expected=0,timeout=60):
        command=log.run(argv,cwd=ROOT,env=env,timeout=timeout,
                        stdout_file=out/(name+'.stdout.txt'),stderr_file=out/(name+'.stderr.txt'))
        if command.returncode!=expected:
            raise RuntimeError({'unexpected_exit':command.evidence,'expected':expected})

    try:
        if not os.path.ismount('/Volumes/WD-Elements'):raise RuntimeError('External volume is not mounted; no fallback')
        record['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
        if subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()!='exec/t078':
            raise RuntimeError('Wrong worktree branch')
        record['diff']=subprocess.check_output(['git','diff','--','workbench'],cwd=ROOT,text=True)
        names=['run_t078_runtime.py','test_t078_input_entry.py','t078_runtime_scenario.py','t078_native_receiver.c',
               'test_t078_pane_runtime.ts','test_t078_inbox_domain.ts','archive_t078_evidence.py',
               'command_evidence.py','electron_client.py','electron_driver.mjs']
        files=[*sorted((ROOT/'workbench/src').rglob('*.ts')),*sorted((ROOT/'workbench/app').glob('*')),
               ROOT/'workbench/bin/inbox',ROOT/'workbench/package.json',ROOT/'workbench/package-lock.json',
               *[ROOT/'workbench/tests'/name for name in names],BASE/'outside-sandbox.sh']
        with tarfile.open(out/'sources.tar.gz','x:gz') as archive:
            for path in files:
                if path.is_file():archive.add(path,arcname=str(path.relative_to(ROOT)))
        save()
        # Preserve original large bytes externally before deleting local copies.
        run([sys.executable,'-B',ROOT/'workbench/tests/archive_t078_evidence.py','--labels','outside-inbox-01','outside-inbox-02'],'archive-prior',timeout=120)
        run(['node',ROOT/'workbench/tests/test_t078_inbox_domain.ts',out/'domain'],'domain')
        run(['node',ROOT/'workbench/tests/test_t078_pane_runtime.ts',out/'pane-state'],'pane-state')
        run([sys.executable,'-B',ROOT/'workbench/tests/test_t078_input_entry.py','--source',ROOT,
             '--output',out/'runtime-entry','--runtime-probe'],'runtime-entry',expected=1 if args.phase=='red' else 0,timeout=240)
        observed=json.loads((out/'runtime-entry/results.json').read_text(encoding='utf-8'))
        failures=[item['name'] for item in observed['checks'] if item['status']!='PASS']
        if len(observed['checks'])!=12 or failures!=record['expected_contract_failure'] or not observed['setup_complete'] or not observed['cleanup_complete']:
            raise RuntimeError({'unexpected_contract_result':failures,'checks':len(observed['checks']),
                                'setup':observed['setup_complete'],'cleanup':observed['cleanup_complete']})
        if observed.get('setup_or_probe_error') or observed.get('cleanup_error'):
            raise RuntimeError('Probe or cleanup error is not product red evidence')
        record['runtime_checks']=[{'name':item['name'],'status':item['status']} for item in observed['checks']]
        record['red_evidence_confirmed' if args.phase=='red' else 'green_evidence_confirmed']=True
        run([sys.executable,'-B',ROOT/'workbench/tests/archive_t078_evidence.py','--labels',args.label],'archive-current',timeout=120)
        record['checkpoint_status']='PASS';save()
        print(json.dumps({'status':'INCOMPLETE','checkpoint_status':'PASS','phase':args.phase,'output':str(out)},ensure_ascii=False))
        return 0
    except Exception as error:
        record['error']=repr(error);save()
        print(json.dumps({'status':'INCOMPLETE','error':repr(error),'output':str(out)},ensure_ascii=False))
        return 1


if __name__=='__main__':raise SystemExit(main())
