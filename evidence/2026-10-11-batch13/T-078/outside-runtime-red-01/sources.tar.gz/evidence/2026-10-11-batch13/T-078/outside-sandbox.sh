#!/bin/bash
set -eu
# Controller-run runtime checkpoint. No vendor CLI or Claude fixture is started.
# Includes the #37 external archive operation; refuses existing run labels.
python3 /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_runtime.py --phase red --label "${1:-outside-runtime-red-01}"
