import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('a2a', Object.freeze({
  snapshot: () => ipcRenderer.invoke('a2a:snapshot'),
  output: (offset: number) => ipcRenderer.invoke('a2a:output', offset),
  input: (data: string) => ipcRenderer.invoke('a2a:input', data),
  observeFocus: (rawSequence: string) => ipcRenderer.invoke('a2a:focus-observation', rawSequence),
}));
