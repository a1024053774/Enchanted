#!/bin/bash
set -eu
# P1 only; launch sends no CLI input and pauses for initial-readiness approval.
case "${1:-p1-launch-01}" in
  p1-launch-01) phase=launch ;;
  p1-continue-01) phase=continue ;;
  p1-cleanup-01) phase=cleanup ;;
  *) echo 'Unknown P1 stage; no process started' >&2; exit 2 ;;
esac
/usr/bin/python3 -B /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_p1.py --materials /Users/luckye/Documents/Code/a2a-wt-t078/evidence/2026-10-11-batch13/T-078/p1-materials-01 --phase "$phase"
