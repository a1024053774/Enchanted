import { readFileSync,writeFileSync } from "node:fs";
import { join } from "node:path";
import { claudeLaunch } from "../src/claudeLaunch.ts";
const root=process.argv[2]!;
const input=JSON.parse(readFileSync(join(root,"input.json"),"utf8"));
const task:any={task_id:input.task,project_id:"t078-p1-project",repo:join(root,"repo"),spec_rev:1,base_commit:input.code_revision};
const launch=claudeLaunch(task,input);
writeFileSync(join(root,"approval.json"),JSON.stringify({status:"INCOMPLETE",phase:"static launch material only",input,launch,
  preflight_argv:[[input.executable,"--version"],[input.executable,"--help"]],
  permission:"P1 must separately approve these two preflights and the interactive CLI start",
  secrets:"The backend will add a fresh private A2A_CAPABILITY; no user credential is read or copied."},null,2));
