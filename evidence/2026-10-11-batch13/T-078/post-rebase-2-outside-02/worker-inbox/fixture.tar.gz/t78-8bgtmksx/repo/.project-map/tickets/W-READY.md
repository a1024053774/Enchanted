---
id: W-READY
title: Worker must not list this ready ticket
type: build
status: open
claimed_by:
blocked_by: []
ready: yes
ready_by: executor
ready_rev: 1
---
