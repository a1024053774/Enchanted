静态角色卡：executor。待真实 Claude 复核。
