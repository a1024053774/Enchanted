静态角色卡：ideation。待真实 Claude 复核。
