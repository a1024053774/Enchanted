Deterministic executor boundary spy
