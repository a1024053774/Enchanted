#!/bin/bash
set -eu
extra=()
case "${1:-p1-continue-05b}" in
  p1-continue-05b)
    phase=continue
    label=continue-05b
    extra=(--readiness-file /Users/luckye/Documents/Code/a2a-wt-t078/evidence/2026-10-11-batch13/T-078/p1-resume-materials-05b/readiness.json) ;;
  p1-cleanup-05b) phase=cleanup; label=cleanup-05b ;;
  *) echo 'Unknown P1 stage; no process started' >&2; exit 2 ;;
esac
/usr/bin/python3 -B /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_p1.py --materials /Users/luckye/Documents/Code/a2a-wt-t078/evidence/2026-10-11-batch13/T-078/p1-materials-05 --phase "$phase" --label "$label" --source-materials /Users/luckye/Documents/Code/a2a-wt-t078/evidence/2026-10-11-batch13/T-078/p1-resume-materials-05b "${extra[@]}"
