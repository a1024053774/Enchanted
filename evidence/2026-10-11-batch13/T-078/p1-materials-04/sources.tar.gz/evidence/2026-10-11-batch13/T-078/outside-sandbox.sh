#!/bin/bash
set -eu
case "${1:-p1-launch-04}" in
  p1-launch-04|p1-continue-04)
    echo 'BLOCKED: documented fake-key/trust bootstrap unresolved; issue 20261013T154915Z-worker:s13-t078s-issue-001. No process started.' >&2
    exit 2 ;;
  p1-cleanup-04) phase=cleanup ;;
  *) echo 'Unknown P1 stage; no process started' >&2; exit 2 ;;
esac
/usr/bin/python3 -B /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_p1.py --materials /Users/luckye/Documents/Code/a2a-wt-t078/evidence/2026-10-11-batch13/T-078/p1-materials-04 --phase "$phase"
