#!/bin/bash
set -eu
# Controller-run runtime checkpoint. No vendor CLI or Claude fixture is started.
# Only remaining input failure contracts; refuses existing run labels.
python3 /Users/luckye/Documents/Code/a2a-wt-t078/workbench/tests/run_t078_runtime.py --scope input-failures --phase green --label "${1:-outside-input-green-01}"
