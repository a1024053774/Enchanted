// Test-only PTY and process observations. The daemon, CLI, relay, gates,
// registration queue, Git and SQLite remain the selected product source.
// This host never runs Codex or supplies a review verdict.
import { appendFileSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

const [source, root, control, ready] = process.argv.slice(2);
if (process.argv.length !== 6) throw new Error("Expected source, state, control and ready paths.");
const load = (name: string) => import(pathToFileURL(join(source, "workbench/src", name)).href);
const { serve } = await load("daemon.ts");
const { A2AGates } = await load("gates/core.ts");
const require = createRequire(join(source, "workbench/src/panes.ts"));
const ptyModule = require.resolve("node-pty");
const original = require(ptyModule);
const terminals: any[] = [];
const config = JSON.parse(readFileSync(join(control, "config.json"), "utf8"));
let panes: any;
const audit = (name: string, data: unknown) => appendFileSync(join(control, name), JSON.stringify(data) + "\n");

require.cache[ptyModule]!.exports = {
  ...original,
  spawn(shell: string, argv: string[], options: any) {
    const homes = [config.codex_home, ...(config.reviewers ?? []).map((item: any) => item.codex_home)];
    if (shell !== "/bin/zsh" || !homes.includes(options.env.CODEX_HOME)) {
      throw new Error("Controlled terminal received an unexpected shell or home.");
    }
    const env = options.env;
    const facts = JSON.parse(readFileSync(join(control, "process-facts.json"), "utf8"));
    const native = env.A2A_ROLE === "reviewer" && facts.next_reviewer_native
      ? facts.next_reviewer_native : "fixture-native-" + env.A2A_LAUNCH;
    const log = join(env.CODEX_HOME, "sessions", "rollout-" + native + ".jsonl");
    mkdirSync(join(env.CODEX_HOME, "sessions"), { recursive: true });
    writeFileSync(log, JSON.stringify({ type: "session_meta", payload: { source: "cli", id: native } }) + "\n", { flag: "wx" });
    const terminal = { pid: 31000 + terminals.length * 10, callbacks: [] as Function[], turns: 0,
      exited: false, launch: env.A2A_LAUNCH, native, log, env };
    terminals.push(terminal);
    // All credentials here are newly generated test capabilities. There is no
    // copied auth file, user home, native model session or provider credential.
    writeFileSync(join(control, env.A2A_LAUNCH + ".json"), JSON.stringify({
      evidence_layer: "controlled-PTY-and-process-observations", pid: terminal.pid,
      launch: terminal.launch, native, log, env, shell, argv,
    }) + "\n", { flag: "wx", mode: 0o600 });
    audit("runtime.jsonl", { method: "spawn", launch: terminal.launch, native, real_codex_turns: 0 });
    return {
      pid: terminal.pid,
      onData: () => {},
      onExit(callback: Function) { terminal.callbacks.push(callback); },
      write(data: string) {
        if (terminal.exited) throw new Error("Write after controlled terminal exit.");
        const registered = panes.store.db.prepare("SELECT seq,id,launch,data FROM dispatch_records ORDER BY seq").all();
        const intents = panes.store.db.prepare("SELECT seq,launch,data FROM orchestration_events WHERE type='turn_submit_intent' ORDER BY seq").all();
        audit("writes.jsonl", { launch: terminal.launch, data, registered, intents });
        if (data === "\r") {
          const turn = `fixture-turn-${++terminal.turns}`;
          appendFileSync(log, JSON.stringify({ type: "event_msg", payload: { type: "task_started", turn_id: turn } }) + "\n");
          const current = JSON.parse(readFileSync(join(control, "process-facts.json"), "utf8"));
          if (!(env.A2A_ROLE === "worker" && current.omit_worker_context)) {
            appendFileSync(log, JSON.stringify({ type: "turn_context", payload: { turn_id: turn, model: "gpt-6.1-sol", effort: "xhigh" } }) + "\n");
          }
        }
      },
      kill(signal: string) {
        if (terminal.exited) throw new Error("Duplicate controlled terminal kill.");
        terminal.exited = true;
        audit("runtime.jsonl", { method: "kill", launch: terminal.launch, signal });
        for (const callback of terminal.callbacks) callback({ exitCode: 0, signal: 1 });
      },
    };
  },
};

await serve(root, config, (state: string, runtime: any) => {
  panes = runtime;
  // Only the external process observation is supplied. No gate method, caller
  // assertion, native scan, queue, store or acceptance result is replaced.
  panes.processInfo = async (thread: string) => {
    const pane = panes.get(thread);
    const terminal = terminals.find((item) => item.launch === pane.record.id);
    if (!terminal) throw new Error("No controlled terminal for this launch.");
    const override = JSON.parse(readFileSync(join(control, "process-facts.json"), "utf8"))[pane.record.id] ?? {};
    pane.leader = override.leader ?? terminal.pid + 1;
    panes.scan(pane);
    return { shell_pid: terminal.pid, leader: pane.leader, native_session: pane.native,
      processes: [], failed: pane.failed, evidence_layer: "controlled-process-observation" };
  };
  return new A2AGates(state, panes);
});
writeFileSync(ready, JSON.stringify({ pid: process.pid, source, root, control, argv: process.argv,
  evidence_layer: "real-CLI-daemon-relay-gates-Git-SQLite; controlled-PTY-process-native-inputs",
  real_codex_turns: 0, replaces: ["node-pty.spawn", "Panes.processInfo"] }) + "\n", { flag: "wx" });
