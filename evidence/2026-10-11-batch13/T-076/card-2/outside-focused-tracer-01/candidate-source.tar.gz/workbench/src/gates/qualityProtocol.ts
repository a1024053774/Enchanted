import type { A2AReviewFinding } from "../contracts/a2aGates.ts";

// Validation of explicit wire data only. No inference from prose or tool output.
export class QualityProtocolError extends Error {
  readonly field: string;
  constructor(field: string) { super(field); this.field = field; }
}
function requireValue(value: unknown, field: string): asserts value {
  if (!value) throw new QualityProtocolError(field);
}
function exact(value: any, keys: string[], field: string) {
  requireValue(value && typeof value === "object" && !Array.isArray(value) &&
    Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key)), field);
}
const nonempty = (value: unknown) => typeof value === "string" && value.trim().length > 0 && !value.includes("\0");

export function reviewVerdict(verdict: unknown, findings: unknown): { verdict: "可合并" | "需修复"; findings: A2AReviewFinding[] } {
  requireValue(verdict === "可合并" || verdict === "需修复", "verdict");
  requireValue(Array.isArray(findings) && (verdict === "可合并" ? findings.length === 0 : findings.length > 0), "findings");
  for (const finding of findings) {
    exact(finding, ["location", "failure_scenario", "suggestion"], "finding");
    exact(finding.location, ["path", "line"], "location");
    requireValue(nonempty(finding.location.path) && !finding.location.path.startsWith("/") &&
      !finding.location.path.includes("\\") && finding.location.path.split("/").every((part: string) => part && part !== "." && part !== ".."), "location.path");
    requireValue(Number.isSafeInteger(finding.location.line) && finding.location.line > 0, "location.line");
    requireValue(nonempty(finding.failure_scenario) && nonempty(finding.suggestion), "finding.text");
  }
  return { verdict, findings: structuredClone(findings) };
}

export function reviewRequest(raw: unknown): Record<string, any> {
  requireValue(typeof raw === "string", "last_assistant_message");
  let value: any;
  try { value = JSON.parse(raw); }
  catch (error) { if (error instanceof SyntaxError) throw new QualityProtocolError("review_json"); throw error; }
  exact(value, ["schema", "request_id", "command", "task", "attempt", "session", "fence", "spec_rev",
    "review_id", "candidate_commit", "verdict", "findings"], "review_request");
  requireValue(value.schema === 1 && value.command === "review_submit", "review_command");
  for (const key of ["task", "attempt", "session", "review_id", "request_id"]) {
    requireValue(typeof value[key] === "string" && /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/.test(value[key]), key);
  }
  requireValue(value.request_id === "review-" + value.review_id, "request_id");
  requireValue(Number.isSafeInteger(value.fence) && value.fence > 0 && Number.isSafeInteger(value.spec_rev) && value.spec_rev > 0, "review_version");
  requireValue(typeof value.candidate_commit === "string" && /^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(value.candidate_commit), "candidate_commit");
  reviewVerdict(value.verdict, value.findings);
  return value;
}

export function executorScore(value: unknown): Record<string, unknown> {
  exact(value, ["result", "boundary_discipline", "boundary_reason", "engineering_taste", "engineering_reason", "notes"], "score");
  const data = value as Record<string, unknown>;
  requireValue(data.result === "通过", "score.result");
  for (const key of ["boundary_discipline", "engineering_taste"]) {
    requireValue(Number.isInteger(data[key]) && Number(data[key]) >= 0 && Number(data[key]) <= 3, "score." + key);
  }
  requireValue(nonempty(data.boundary_reason) && nonempty(data.engineering_reason) && typeof data.notes === "string", "score.text");
  // Stable field order makes exact replay comparisons independent of JSON key order.
  return { result: data.result, boundary_discipline: data.boundary_discipline, boundary_reason: data.boundary_reason,
    engineering_taste: data.engineering_taste, engineering_reason: data.engineering_reason, notes: data.notes };
}
