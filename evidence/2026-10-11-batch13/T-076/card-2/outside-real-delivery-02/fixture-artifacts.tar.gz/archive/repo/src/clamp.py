def clamp(value):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("not_int")
    return max(0, min(100, value))
