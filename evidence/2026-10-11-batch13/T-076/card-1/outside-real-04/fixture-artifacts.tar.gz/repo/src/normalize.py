def normalize(rows):
    totals = {}
    for row in rows:
        name = row.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("invalid_name")
        name = name.strip()

        minutes = row.get("minutes")
        if isinstance(minutes, bool) or not isinstance(minutes, int) or minutes < 0:
            raise ValueError("invalid_minutes")

        totals[name] = totals.get(name, 0) + minutes

    return {
        "entries": [
            {"name": name, "minutes": totals[name]} for name in sorted(totals)
        ],
        "total_minutes": sum(totals.values()),
    }
