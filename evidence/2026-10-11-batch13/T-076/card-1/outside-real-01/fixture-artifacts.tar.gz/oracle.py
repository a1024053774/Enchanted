import json, runpy, subprocess, sys
from pathlib import Path
root=Path(sys.argv[1])
cases=[
 ([{"name":" Alice ","minutes":70},{"name":"张三","minutes":59},{"name":"Alice","minutes":55},{"name":"Bob","minutes":0}],0,
  {"entries":[{"name":"Alice","minutes":125,"duration":"2:05"},{"name":"Bob","minutes":0,"duration":"0:00"},{"name":"张三","minutes":59,"duration":"0:59"}],"total_minutes":184}),
 ([],0,{"entries":[],"total_minutes":0}),
 ([{"name":"A","minutes":-1}],2,{"error":"invalid_minutes"}),
 ([{"name":"A","minutes":True}],2,{"error":"invalid_minutes"}),
 ([{"name":"  ","minutes":1}],2,{"error":"invalid_name"})]
normalize=runpy.run_path(str(root/"src/normalize.py"))["normalize"]
for payload,code,expected in cases:
 if code==0:
  assert normalize(payload)==expected
 else:
  try: normalize(payload)
  except ValueError as error: assert str(error)==expected["error"]
  else: raise AssertionError("invalid input must raise ValueError")
 p=subprocess.run([sys.executable,"-B",str(root/"src/report.py")],input=json.dumps(payload,ensure_ascii=False),text=True,capture_output=True)
 assert p.returncode==code,(payload,p.returncode,p.stdout,p.stderr)
 assert json.loads(p.stdout)==expected,(payload,p.stdout,expected)
print("independent normalization oracle: 5 cases passed")
