def normalize(rows):
    return {}
