import json
print(json.dumps({"stub": True}))
