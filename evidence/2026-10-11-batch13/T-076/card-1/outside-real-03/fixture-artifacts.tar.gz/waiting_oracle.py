import pathlib,runpy,sys,time
signal=pathlib.Path('/private/tmp/t76-real-lq0_q8jw/receipt-complete')
deadline=time.monotonic()+60
while not signal.exists():
 if time.monotonic()>deadline: raise RuntimeError("receipt boundary was not confirmed")
 time.sleep(0.05)
sys.argv=['/private/tmp/t76-real-lq0_q8jw/oracle.py',sys.argv[1]]
runpy.run_path('/private/tmp/t76-real-lq0_q8jw/oracle.py',run_name="__main__")
