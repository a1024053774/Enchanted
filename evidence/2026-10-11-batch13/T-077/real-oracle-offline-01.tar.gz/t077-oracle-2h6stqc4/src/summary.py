def summarize(values):
    total=sum(values)
    return {"count":len(values),"total_ms":total,"mean_ms":total/len(values) if values else None}
