import importlib.util,json,pathlib,sys
root=pathlib.Path(sys.argv[1])
spec=importlib.util.spec_from_file_location("independent_summary",root/"src/summary.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
for values,expected in [([], {"count":0,"total_ms":0,"mean_ms":None}),
                        ([2,5,8], {"count":3,"total_ms":15,"mean_ms":5.0}),
                        ([-4,1], {"count":2,"total_ms":-3,"mean_ms":-1.5}),
                        ([0], {"count":1,"total_ms":0,"mean_ms":0.0})]:
    actual=module.summarize(values)
    print(json.dumps({"values":values,"actual":actual,"expected":expected}),flush=True)
    for key,value in expected.items(): assert actual[key]==value,(values,expected,actual)
    if sys.argv[2]=="integrated": assert actual==dict(expected,unit="ms"),(values,actual)
if sys.argv[2]=="integrated":
    assert (root/"host-policy.txt").read_text()=="unit=ms; source=host\n"
print("independent summary oracle PASS")
