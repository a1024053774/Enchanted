#!/usr/bin/env python3
"""T-077 S3 contracts through the daemon CLI and independent Git/SQLite reads.

The initial batch uses manual claims and the existing controlled thread boundary.
It does not launch Codex. A business-red receipt never means product acceptance.
"""
import argparse
from contextlib import closing
import gzip
import io
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import unittest

import test_task_cards_e2e as cards
from test_daemon_gates_e2e import DaemonCards
import daemon_acceptance_adapter as old


ROOT = Path(__file__).resolve().parents[2]
BASE = '14b57d22a84bcaebfa91c5051b9909b53a570fac'
CONTRACTS = []


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def write_gzip(path, value):
    with gzip.open(path, 'xb') as handle:
        handle.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


class ContractChecks:
    def contract(self, name, condition, expected, actual):
        CONTRACTS.append({'test': self.id(), 'claim': name, 'pass': bool(condition),
                          'expected': expected, 'actual': actual})
        self.assertTrue(condition, 'S3 contract: ' + name + '\n' + repr(CONTRACTS[-1]))


class WorktreeContracts(ContractChecks, DaemonCards):
    def setUp(self):
        super().setUp()
        # Registered last, so SQLite is read while the owning daemon is alive.
        self.addCleanup(self.capture_readback)

    def capture_readback(self):
        with closing(sqlite3.connect(self.state.resolve().joinpath('state.sqlite3').as_uri() + '?mode=ro', uri=True)) as db:
            db.row_factory = sqlite3.Row
            tables = {}
            for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
                name = row[0]
                quoted = '"' + name.replace('"', '""') + '"'
                tables[name] = [dict(item) for item in db.execute('SELECT * FROM ' + quoted)]
        write_gzip(self.root / 's3-state-readback.json.gz', {'task': self.task, 'tables': tables})

    def ref_or_none(self, ref):
        p = self.process(['git', '-C', self.repo, 'rev-parse', '--verify', '--quiet', ref])
        self.assertIn(p.returncode, (0, 1), p.stderr)
        return p.stdout.strip() if p.returncode == 0 else None

    def request(self, command, *args):
        p = self.process(['node', cards.GATE, '--state', self.state, command, '--task', self.task, *args])
        self.assertIn(p.returncode, (0, 1), 'Entry/setup failure: ' + p.stderr)
        reply = json.loads(p.stdout)
        self.assertIs(type(reply.get('ok')), bool)
        self.assertEqual(reply['ok'], p.returncode == 0)
        return reply

    def system_issues(self, attempt):
        result = self.cli('issues')
        return [view['issue'] for view in result['issues']
                if view['issue']['from'] == 'system' and
                view['issue']['attempt_id'] == attempt['attempt_id']]

    def test_worker_name(self):
        a = self.create()
        expected = str((self.state / 'worktrees' / 'fixture' / (self.task + '-a1')).resolve())
        branch = self.process(['git', '-C', a['workspace'], 'symbolic-ref', '--quiet', 'HEAD'])
        with self.subTest(field='workspace'):
            self.contract('W16 worker project/task/ordinal path', a['workspace'] == expected, expected, a['workspace'])
        with self.subTest(field='branch'):
            expected_ref = 'refs/heads/a2a/' + self.task + '-a1'
            self.contract('W16 named worker branch', branch.returncode == 0 and branch.stdout.strip() == expected_ref,
                          expected_ref, {'exit': branch.returncode, 'stdout': branch.stdout})

    def test_clean_revoke(self):
        a = self.create()
        c = self.commit(a)
        self.submit(a, c)
        self.cli('verify')
        self.cli('revoke', '--reason', 'S3 independent clean revoke')
        self.assertEqual(self.oid(), self.base)
        with self.subTest(field='directory'):
            self.contract('W02 clean revoked directory removed', not Path(a['workspace']).exists(), False,
                          Path(a['workspace']).exists())
        with self.subTest(field='reference'):
            actual = self.ref_or_none('refs/a2a/attempts/' + self.task + '/a1')
            self.contract('W02 revoked candidate hidden reference', actual == c, c, actual)

    def test_clean_revise(self):
        a = self.create()
        c = self.commit(a)
        self.submit(a, c)
        self.cli('revise', '--spec-rev', '2')
        self.submit(a, c, ok=False, error='stale_attempt')
        with self.subTest(field='directory'):
            self.contract('W10 revised clean directory removed', not Path(a['workspace']).exists(), False,
                          Path(a['workspace']).exists())
        with self.subTest(field='reference'):
            actual = self.ref_or_none('refs/a2a/attempts/' + self.task + '/a1')
            self.contract('W10 revised candidate remains readable', actual == c, c, actual)

    def test_verification_name(self):
        marker = self.root / 'verification-observation.json'
        source = ('import json,os,subprocess\n'
                  'p=subprocess.run(["git","symbolic-ref","--quiet","HEAD"],capture_output=True,text=True)\n'
                  'with open(' + repr(str(marker)) + ',"x",encoding="utf-8") as f:\n'
                  ' json.dump({"cwd":os.getcwd(),"ref_exit":p.returncode,"ref":p.stdout},f)\n')
        self.card['completion_conditions'].append({'argv': [sys.executable, '-I', '-B', '-c', source]})
        a = self.create()
        self.submit(a, self.commit(a))
        self.cli('verify')
        observed = json.loads(marker.read_text(encoding='utf-8'))
        self.assertEqual(observed['ref_exit'], 1, 'Verification must be detached while the oracle runs')
        expected = str((self.state / 'worktrees' / 'fixture' / (self.task + '-a1-verify-1')).resolve())
        self.contract('W14 verification project/task/purpose/ordinal path', observed['cwd'] == expected, expected, observed)

    def test_completed_verification_cleanup(self):
        a = self.create()
        c = self.commit(a)
        self.submit(a, c)
        v = self.cli('verify')['verification']
        self.assertEqual(v['state'], 'passed')
        self.assertEqual(self.oid(), self.base, 'verify does not integrate')
        with sqlite3.connect(self.state / 'state.sqlite3') as db:
            stored = json.loads(db.execute('SELECT data FROM verifications WHERE id=?', (v['verification_id'],)).fetchone()[0])
        self.assertEqual(stored, v)
        with self.subTest(field='directory'):
            self.contract('W08 completed verification directory removed', not Path(v['workspace']).exists(), False,
                          Path(v['workspace']).exists())
        with self.subTest(field='reference'):
            actual = self.ref_or_none('refs/a2a/verifications/' + self.task + '/a1/v1')
            self.contract('W08 verified M retained independently of worktree', actual == c, c, actual)

    def test_overlap_without_reason(self):
        first = self.create()
        other = self.task + '-other'
        self.task = other
        self.card = {**self.card, 'id': other}
        self.save_card()
        self.cli('create', '--repo', self.repo, '--branch', 'refs/heads/main', '--card-version', '1', '--project', 'fixture')
        reply = self.request('claim', '--owner', 'second-writer')
        self.contract('W12/W13 overlapping active attempts require explicit reason', reply['ok'] is False,
                      {'ok': False, 'first_attempt': first['attempt_id']}, reply)
        status = self.cli('status')['task']
        self.assertIsNone(status['current_attempt'], 'Rejected overlap cannot reserve a second writer')

    def test_dirty_revoke_keeps_scene_and_reports(self):
        a = self.create()
        c = self.commit(a)
        path = Path(a['workspace']) / 'src/value.txt'
        path.write_bytes(b'Uncommitted work must remain exactly as written.\n')
        before = path.read_bytes()
        self.cli('revoke', '--reason', 'Independent dirty cleanup probe')
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(self.oid(Path(a['workspace'])), c)
        issues = self.system_issues(a)
        self.contract('dirty cleanup appends system issue for original attempt', bool(issues), 'at least one bound system issue', issues)

    def test_unknown_cleanup_keeps_scene_and_reports(self):
        a = self.create()
        c = self.commit(a)
        # This router is owned by the pre-existing fixture, not a product branch.
        fault = self.root / 'wrapped-git'
        fault.mkdir()
        git = shutil.which('git', path=self.env['PATH'])
        wrapper = fault / 'git'
        wrapper.write_text('#!' + sys.executable + '\nimport os,sys\n'
                           'if "status" in sys.argv[1:]:\n'
                           ' sys.stderr.write("fixture: worktree status unavailable\\n"); sys.exit(73)\n'
                           'os.execv(' + repr(git) + ',[' + repr(git) + ']+sys.argv[1:])\n', encoding='utf-8')
        wrapper.chmod(0o755)
        reply = self.request('revoke', '--reason', 'Independent unknown cleanup probe')
        self.assertTrue(Path(a['workspace']).is_dir(), reply)
        self.assertEqual(self.oid(Path(a['workspace'])), c)
        issues = self.system_issues(a)
        self.contract('unknown cleanup appends system issue without deleting scene', bool(issues), 'bound system issue', issues)

    def test_dirty_integration_reports_without_mutation(self):
        a = self.create()
        self.submit(a, self.commit(a))
        self.cli('verify')
        path = self.repo / 'src/value.txt'
        path.write_bytes(b'User staged value\n')
        self.git('add', 'src/value.txt')
        path.write_bytes(b'User unstaged value\n')
        before = path.read_bytes()
        index = Path(self.git('rev-parse', '--git-path', 'index'))
        if not index.is_absolute():
            index = self.repo / index
        index_before = index.read_bytes()
        self.cli('integrate', ok=False, error='dirty_integration_worktree')
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(index.read_bytes(), index_before)
        self.assertEqual(self.oid(), self.base)
        issues = self.system_issues(a)
        self.contract('dirty integration appends system issue', bool(issues), 'bound system issue', issues)

    def test_r8_revalidates_on_new_head(self):
        marker = self.root / 'oracle-runs.jsonl'
        source = ('from pathlib import Path\nimport json,os\n'
                  'assert Path("src/value.txt").read_text()=="worker\\n"\n'
                  'with open(' + repr(str(marker)) + ',"a",encoding="utf-8") as f:\n'
                  ' f.write(json.dumps({"cwd":os.getcwd(),"host":Path("host.txt").read_text()})+"\\n")\n')
        self.card['completion_conditions'] = [{'argv': [sys.executable, '-I', '-B', '-c', source]}]
        a = self.create()
        c = self.commit(a)
        self.submit(a, c)
        original = self.cli('verify')['verification']
        (self.repo / 'host.txt').write_text('External G1 must survive.\n', encoding='utf-8')
        self.git('add', 'host.txt')
        self.git('commit', '-m', 'Independent external G1')
        g1 = self.oid()
        reply = self.request('integrate')
        self.contract('W01 R8 retries verification after one known head change', reply['ok'] is True, True, reply)
        v = self.cli('status')['task']['verification']
        self.assertNotEqual(v['verification_id'], original['verification_id'])
        self.assertEqual(v['G'], g1)
        self.assertEqual(v['C'], c)
        self.assertEqual(self.oid(), v['M'])
        for ancestor in (g1, c):
            self.git('merge-base', '--is-ancestor', ancestor, self.oid())
        rows = [json.loads(line) for line in marker.read_text(encoding='utf-8').splitlines()]
        self.assertEqual([row['host'] for row in rows], ['base host\n', 'External G1 must survive.\n'])
        self.assertEqual((self.repo / 'host.txt').read_text(encoding='utf-8'), 'External G1 must survive.\n')


class RunCleanupContracts(ContractChecks, old.DaemonRun):
    def ref_or_none(self, ref):
        result = self.process(['git', '-C', self.repo, 'rev-parse', '--verify', '--quiet', ref])
        self.assertIn(result.returncode, (0, 1), result.stderr)
        return result.stdout.strip() if result.returncode == 0 else None

    def test_integrated_run_cleanup(self):
        self.create()
        handle = self.start_run(seconds=20)
        thread = self.wait_prompt(handle)
        attempt = self.current_attempt()
        candidate = self.candidate(attempt, good=True)
        expected = Path(attempt['workspace'], 'pager.py').read_bytes()
        self.submit(attempt, candidate)
        self.new_result(self.complete(handle), 'run')
        self.assertEqual(self.ref(), candidate)
        self.assertEqual((self.repo / 'pager.py').read_bytes(), expected)
        self.only_own_close(thread)
        self.finish_checks()
        with self.subTest(field='directory'):
            self.contract('W03 integrated run removes clean worker worktree', not Path(attempt['workspace']).exists(), False,
                          Path(attempt['workspace']).exists())
        with self.subTest(field='reference'):
            actual = self.ref_or_none('refs/a2a/attempts/' + self.task + '/a1')
            self.contract('W03 integrated run retains candidate hidden reference', actual == candidate, candidate, actual)

    def test_timeout_cleanup_retains_unsubmitted_commit(self):
        self.create()
        handle = self.start_run(seconds=5)
        thread = self.wait_prompt(handle)
        attempt = self.current_attempt()
        candidate = self.candidate(attempt, good=True)
        self.failed_run(self.complete(handle), error='run_deadline')
        self.assertIsNone(self.status()['candidate_commit'])
        self.assertEqual(self.ref(), self.base)
        self.only_own_close(thread)
        self.finish_checks()
        with self.subTest(field='directory'):
            self.contract('W04 timeout removes ended clean worker directory', not Path(attempt['workspace']).exists(), False,
                          Path(attempt['workspace']).exists())
        with self.subTest(field='reference'):
            actual = self.ref_or_none('refs/a2a/attempts/' + self.task + '/a1')
            self.contract('W04 unsubmitted commit survives under hidden reference', actual == candidate, candidate, actual)

    def test_rejected_run_cleanup(self):
        self.create()
        handle = self.start_run(seconds=20)
        thread = self.wait_prompt(handle)
        attempt = self.current_attempt()
        candidate = self.candidate(attempt, good=False)
        self.submit(attempt, candidate)
        self.failed_run(self.complete(handle))
        self.only_own_close(thread)
        self.finish_checks()
        with self.subTest(field='directory'):
            self.contract('W06 rejected and ended clean attempt directory removed', not Path(attempt['workspace']).exists(), False,
                          Path(attempt['workspace']).exists())
        with self.subTest(field='reference'):
            actual = self.ref_or_none('refs/a2a/attempts/' + self.task + '/a1')
            self.contract('W06 rejected candidate retained under hidden reference', actual == candidate, candidate, actual)


CASES = [(WorktreeContracts, name) for name in (
    'test_worker_name', 'test_clean_revoke', 'test_clean_revise', 'test_verification_name',
    'test_completed_verification_cleanup', 'test_overlap_without_reason',
    'test_dirty_revoke_keeps_scene_and_reports', 'test_unknown_cleanup_keeps_scene_and_reports',
    'test_dirty_integration_reports_without_mutation', 'test_r8_revalidates_on_new_head',
)] + [(RunCleanupContracts, name) for name in (
    'test_integrated_run_cleanup', 'test_timeout_cleanup_retains_unsubmitted_commit', 'test_rejected_run_cleanup',
)]


def observe(argv):
    p = subprocess.run([str(arg) for arg in argv], cwd=ROOT, capture_output=True, text=True)
    return {'argv': [str(arg) for arg in argv], 'cwd': str(ROOT), 'exit_code': p.returncode,
            'stdout': p.stdout, 'stderr': p.stderr}


def snapshot_source(out):
    names = sorted(str(p.relative_to(ROOT)) for p in (ROOT / 'workbench/src').rglob('*.ts'))
    names += [str(p.relative_to(ROOT)) for p in (ROOT / 'workbench/tests').glob('*.py')]
    names += [str(p.relative_to(ROOT)) for p in (ROOT / 'workbench/tests').glob('*.ts')]
    names += ['workbench/package.json', 'workbench/package-lock.json',
              '.project-map/tickets/T-077-worktree-lifecycle-conflicts.md',
              '.project-map/specs/native-cli-orchestration-2026-10-10.md',
              'evidence/2026-10-11-batch13/T-077/PLAN.md',
              'evidence/2026-10-11-batch13/T-077/controller-decision-01.md',
              'evidence/2026-10-11-batch13/T-077/controller-decision-02.md',
              'evidence/2026-10-11-batch13/T-077/outside-sandbox.sh']
    for folder in ('acceptance', 'fixtures/pagination'):
        names += [str(p.relative_to(ROOT)) for p in (ROOT / folder).rglob('*')
                  if p.is_file() and p.suffix in ('.py', '.ts', '.md') and '__pycache__' not in p.parts]
    with tarfile.open(out / 'sources.tar.gz', 'x:gz') as archive:
        for name in sorted(set(names)):
            archive.add(ROOT / name, arcname=name, recursive=False)
    write_new(out / 'source-files.json', sorted(set(names)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=('baseline', 'candidate'), required=True)
    parser.add_argument('--case', action='append', choices=[name for _, name in CASES])
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    out = args.output.resolve()
    # Never let this worker's capability, hook configuration or CODEX_HOME leak
    # into the fixture clients. No auth file or real CLI is needed in this batch.
    for key in list(os.environ):
        if key.startswith(('A2A_', 'CODEX_', 'GIT_')):
            del os.environ[key]
    preflight = {'head': observe(['git', 'rev-parse', 'HEAD']),
                 'source_diff': observe(['git', 'diff', 'HEAD', '--', 'workbench/src']),
                 'node': observe(['node', '--version']), 'git': observe(['git', '--version']),
                 'volume_mounted': os.path.ismount('/Volumes/WD-Elements')}
    write_new(out / 'preflight.json', preflight)
    if not preflight['volume_mounted'] or not preflight['node']['stdout'].startswith('v26.5.'):
        raise RuntimeError('Required external volume or Node 26.5 is unavailable')
    if args.phase == 'baseline' and (preflight['head']['stdout'].strip() != BASE or preflight['source_diff']['stdout']):
        raise RuntimeError('Baseline must run unchanged product source at the assigned starting commit')
    if any(v.get('exit_code') != 0 for v in preflight.values() if isinstance(v, dict)):
        raise RuntimeError('Preflight command failed')
    snapshot_source(out)
    fixture_root = Path(tempfile.mkdtemp(prefix='s3-', dir='/tmp'))
    cards.ARTIFACT_ROOT = fixture_root
    os.environ['COOP_E2E_ARTIFACT_ROOT'] = str(fixture_root)
    os.environ['COOP_E2E_READBACK_ROOT'] = str(out / 'readbacks')
    (out / 'readbacks').mkdir()
    selected = [(cls, name) for cls, name in CASES if not args.case or name in args.case]
    receipts = []
    for number, (cls, name) in enumerate(selected, 1):
        target = out / f'{number:02d}-{name}'
        target.mkdir()
        start = (len(cards.COMMANDS), len(old.delivery.COMMANDS), len(CONTRACTS), len(old.recovery.ASSERTIONS))
        stream = io.StringIO()
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.TestSuite([cls(name)]))
        with (target / 'unittest.txt').open('x', encoding='utf-8') as handle:
            handle.write(stream.getvalue())
        contracts = CONTRACTS[start[2]:]
        record = {'case': name, 'phase': args.phase, 'tests_run': result.testsRun,
                  'exit_code': 0 if result.wasSuccessful() else 1,
                  'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
                  'business_red': bool(result.failures and not result.errors and any(not c['pass'] for c in contracts)),
                  'contracts': contracts, 'inherited_assertions': old.recovery.ASSERTIONS[start[3]:],
                  'evidence_layer': 'controlled-thread' if cls is RunCleanupContracts else 'default-daemon-manual-claim'}
        write_new(target / 'result.json', record)
        write_gzip(target / 'commands.json.gz', cards.COMMANDS[start[0]:] + old.delivery.COMMANDS[start[1]:])
        receipts.append(record)
        print(json.dumps({'case': name, 'failures': record['failures'], 'errors': record['errors'],
                          'business_red': record['business_red']}, ensure_ascii=False), flush=True)
    with tarfile.open(out / 'fixtures.tar.gz', 'x:gz') as archive:
        archive.add(fixture_root, arcname=fixture_root.name)
    red_confirmed = bool(receipts) and all(r['business_red'] and not r['skipped'] for r in receipts)
    green = bool(receipts) and all(r['exit_code'] == 0 and not r['skipped'] for r in receipts)
    record = {'status': 'PASS' if args.phase == 'candidate' and green else 'INCOMPLETE',
              'scope': 'S3 initial focused contracts only; not full T-077 acceptance',
              'phase': args.phase, 'red_confirmed': red_confirmed if args.phase == 'baseline' else None,
              'argv': sys.argv, 'cwd': str(ROOT), 'fixture_root': str(fixture_root),
              'real_codex_turns': 0, 'cases': receipts}
    write_new(out / 'run.json', record)
    print(json.dumps({k: record[k] for k in ('status', 'phase', 'red_confirmed', 'real_codex_turns')}, ensure_ascii=False))
    return 0 if (red_confirmed if args.phase == 'baseline' else green) else 1


if __name__ == '__main__':
    raise SystemExit(main())
