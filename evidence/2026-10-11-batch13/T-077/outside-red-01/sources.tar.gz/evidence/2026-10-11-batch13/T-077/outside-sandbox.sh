#!/bin/bash
set -euo pipefail

# 执行主控运行。当前只交付首批红态；不启动真实 Codex，不安装 hook。
# 运行命令：
# bash /Users/luckye/Documents/Code/a2a-wt-t077/evidence/2026-10-11-batch13/T-077/outside-sandbox.sh red-01
# 同名输出已存在时拒绝，不能覆盖原始失败。后续阶段另行批准/交回。
if [[ "$#" != 1 || "$1" != "red-01" ]]; then
  echo 'usage: outside-sandbox.sh red-01' >&2
  exit 2
fi
cd /Users/luckye/Documents/Code/a2a-wt-t077
python3 -B /Users/luckye/Documents/Code/a2a-wt-t077/workbench/tests/test_worktree_lifecycle_e2e.py \
  --phase baseline \
  --output /Users/luckye/Documents/Code/a2a-wt-t077/evidence/2026-10-11-batch13/T-077/outside-red-01

# 真实场景尚未准备，不在本轮执行。准备时按决定 01 使用产品生成的完整 argv
# （实际路径/launch 参数在真实运行前固定并再次交回）：
# Codex 0.162.1；--no-daemon --no-alt-screen -C <本次隔离worktree>
# -a never --sandbox workspace-write -m gpt-6.1-sol
# -c model_reasoning_effort="xhigh" -c service_tier="fast"
# -c check_for_update_on_startup=false -c tui.notifications=false
# -c sandbox_workspace_write.network_access=false -c features.network_proxy=false
# -c hooks.UserPromptSubmit=<该launch的signal命令>
# -c hooks.Stop=<该launch的signal命令>
# -c hooks.PermissionRequest=<该launch的signal命令>
# --dangerously-bypass-hook-trust
# Git prepare-commit-msg 仅经 GIT_CONFIG_* 每会话环境指定现有目录。
# 上述占位记录不是可执行真实入口；完整 argv 未填定前不运行真实 Codex。
