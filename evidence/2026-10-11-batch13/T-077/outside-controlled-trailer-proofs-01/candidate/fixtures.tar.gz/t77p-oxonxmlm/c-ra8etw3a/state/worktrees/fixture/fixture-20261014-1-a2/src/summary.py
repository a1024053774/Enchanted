def summarize(values):
    total = sum(values)
    count = len(values)
    return {
        "count": count,
        "total_ms": total,
        "unit": "ms",
        "mean_ms": total / count if count else None,
    }
