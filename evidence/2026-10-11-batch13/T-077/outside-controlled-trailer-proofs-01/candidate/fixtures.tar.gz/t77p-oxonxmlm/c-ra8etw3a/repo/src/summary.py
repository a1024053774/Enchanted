def summarize(values):
    total = sum(values)
    return {"count": len(values), "total_ms": total, "unit": "ms"}
