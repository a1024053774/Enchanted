/Users/luckye/Documents/Code/a2a/evidence/2026-10-06-m1-batch1/T-026/red-path-check-artifacts/poisoned-internal-cache/debug/deps/t026_path_contract-0d332e8a84772bbb.d: src/main.rs

/Users/luckye/Documents/Code/a2a/evidence/2026-10-06-m1-batch1/T-026/red-path-check-artifacts/poisoned-internal-cache/debug/deps/t026_path_contract-0d332e8a84772bbb: src/main.rs

src/main.rs:
