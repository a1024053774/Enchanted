fn main() { println!("mount contract"); }
