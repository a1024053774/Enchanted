from pathlib import Path
import sys
assert Path(sys.argv[1],"fixture.txt").read_text()=="T058 external boundary Ω\n"
