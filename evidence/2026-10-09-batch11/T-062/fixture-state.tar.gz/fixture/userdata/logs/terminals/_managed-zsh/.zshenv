# Synara zsh env wrapper
_synara_home="${SYNARA_ORIGINAL_ZDOTDIR:-$HOME}"
export ZDOTDIR="$_synara_home"
[[ -f "$_synara_home/.zshenv" ]] && source "$_synara_home/.zshenv"
export ZDOTDIR='/Volumes/WD-Elements/dev-cache/synara/instances/t062-probe01/userdata/logs/terminals/_managed-zsh'
