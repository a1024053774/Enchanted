from pathlib import Path
import sys
assert Path(sys.argv[1], "fixture.txt").read_text(encoding="utf-8")=="T059 original Ω\n"
