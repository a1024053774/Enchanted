import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { t as require_react_dom } from "./react-dom.js";
import { C as useIsoLayoutEffect, h as isHTMLElement, i as getComputedStyle, m as isElement, n as useStableCallback, u as getOverflowAncestors } from "./useId-Cfrl5XdH.js";
import { H as isIndexOutOfListBounds, R as getGridNavigatedIndex, T as DROPDOWN_COLLISION_AVOIDANCE, _t as android, a as triggerOpenStateMapping, ht as stopEvent, i as pressableTriggerOpenStateMapping, l as Store, n as popupStateMapping, t as inertValue, u as useStore, vt as ios, y as FloatingPortal } from "./inertValue-C-bH78NQ.js";
import { t as gecko } from "./engine-Bi_mNBBm.js";
import { r as isInteractiveElement } from "./element-du8in3y-.js";
import { t as ownerDocument } from "./owner-BmKt4Bpq.js";
import { a as useMergedRefs, c as NOOP, l as useRefWithInit, o as EMPTY_ARRAY, s as EMPTY_OBJECT, t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { n as useTimeout } from "./useTimeout-CHZlR9Tr.js";
import { a as FloatingFocusManager, i as useClick, r as InternalBackdrop, t as useOpenInteractionType } from "./useOpenInteractionType-DLEJ1445.js";
import { n as contains, r as getTarget } from "./shadowDom-CQZHMuh3.js";
import { _ as listNavigation, a as clearPress, b as pointer, f as inputChange, g as keyboard, h as itemPress, l as escapeKey, m as inputPress, n as createGenericEventDetails, o as closePress, p as inputClear, r as cancelOpen, t as createChangeEventDetails, v as none } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { t as useValueAsRef } from "./useValueAsRef-B26tI_FQ.js";
import { n as visuallyHiddenInput, t as visuallyHidden } from "./visuallyHidden-Xbj0ZvZT.js";
import { h as useDismiss, t as FOCUSABLE_POPUP_PROPS } from "./popupStoreUtils-ULj3E1ul.js";
import { r as mergeProps } from "./merge-props-BSY6QP_a.js";
import { n as transitionStatusMapping, r as useOpenChangeComplete } from "./stateAttributesMapping-DKWbKMwM.js";
import { n as getDisabledMountTransitionStyles, r as useAnchorPositioning, t as usePositioner } from "./usePositioner-CXpcG81q.js";
import { t as useTransitionStatus } from "./useTransitionStatus-DmfddCng.js";
import { t as useFloatingRootContext } from "./useFloatingRootContext-WJnXvW5K.js";
import { n as useTypeahead, r as useListNavigation, t as isMouseWithinBounds } from "./getPseudoElementBounds-B3v2X0x7.js";
import { t as useButton } from "./useButton-vy-VFWTJ.js";
import { t as useBaseUiId } from "./useBaseUiId-BBG3KkG2.js";
import { t as useValueChanged } from "./useValueChanged-D0QUycMP.js";
import { t as useControlled } from "./useControlled-tPZe1TD5.js";
import { c as compareItemEquality, d as findSelectionIndex, f as removeItem, l as defaultItemEquality, m as useOnFirstRender, n as hasNullItemLabel, o as stringifyAsLabel, p as selectedValueIncludes, r as isGroupedItems, s as stringifyAsValue, u as findItemIndex } from "./ListboxSeparator-BERMPiEO.js";
import { a as DEFAULT_FIELD_ROOT_CONTEXT, c as DEFAULT_FIELD_STATE_ATTRIBUTES, i as useRegisterFieldControl, n as useLabelableContext, o as FieldRootContext, r as useFormContext, s as useFieldRootContext, u as fieldValidityMapping } from "./LabelableContext-CdYnDOEr.js";
import { t as useLabelableId } from "./useLabelableId-DmWnMHl6.js";
import { t as stringifyLocale } from "./stringifyLocale-DrRqoF2T.js";
import { n as resolveAriaLabelledBy, r as areArraysEqual } from "./resolveAriaLabelledBy-D9b8XvNL.js";
import { t as useDirection } from "./DirectionContext-DRel_lZA.js";
import { t as useCompositeListItem } from "./useCompositeListItem-BYy-x-0E.js";
import { t as CompositeList } from "./CompositeList-BS4gmjlB.js";
import { t as useAnchoredPopupScrollLock } from "./useAnchoredPopupScrollLock-CtJbgIPm.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/floating-ui-react/hooks/gridNavigation.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Positional arguments are deliberate: property names of an options object
* don't minify, and the signature is locked to the caller via `typeof` on the
* `grid` option of `useListNavigation`.
*
* The injected grid navigator only ever operates on a uniform 1x1 grid (sizes are
* always `1x1` and packing is never dense), so the cell-map machinery that supports
* multi-cell items collapses to an identity transform over the item list. Calling
* `getGridNavigatedIndex` directly keeps the cell-map helpers
* (`createGridCellMap`/`getGridCellIndexOfCorner`/`getGridCellIndices`) out of
* grid-combobox bundles.
*/
function gridNavigation(event, prevIndex, listRef, orientation, loopFocus, rtl, disabledIndices, minIndex, maxIndex, cols = 2) {
	const nextIndex = getGridNavigatedIndex(listRef.current, {
		event,
		orientation,
		loopFocus,
		rtl,
		cols,
		disabledIndices,
		minIndex,
		maxIndex,
		prevIndex: prevIndex > maxIndex ? minIndex : prevIndex,
		stopEvent: true
	});
	return isIndexOutOfListBounds(listRef.current, nextIndex) ? void 0 : nextIndex;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/ComboboxRootContext.mjs
var ComboboxRootContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxRootContext.displayName = "ComboboxRootContext";
var ComboboxFloatingContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxFloatingContext.displayName = "ComboboxFloatingContext";
var ComboboxDerivedItemsContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxDerivedItemsContext.displayName = "ComboboxDerivedItemsContext";
var ComboboxHasItemsContext = /*#__PURE__*/ import_react.createContext(false);
ComboboxHasItemsContext.displayName = "ComboboxHasItemsContext";
var ComboboxInputValueContext = /*#__PURE__*/ import_react.createContext("");
ComboboxInputValueContext.displayName = "ComboboxInputValueContext";
function useComboboxRootContext() {
	const context = import_react.useContext(ComboboxRootContext);
	if (!context) throw new Error("Base UI: ComboboxRootContext is missing. Combobox parts must be placed within <Combobox.Root>.");
	return context;
}
function useComboboxFloatingContext() {
	const context = import_react.useContext(ComboboxFloatingContext);
	if (!context) throw new Error("Base UI: ComboboxFloatingContext is missing. Combobox parts must be placed within <Combobox.Root>.");
	return context;
}
function useComboboxDerivedItemsContext() {
	const context = import_react.useContext(ComboboxDerivedItemsContext);
	if (!context) throw new Error("Base UI: ComboboxItemsContext is missing. Combobox parts must be placed within <Combobox.Root>.");
	return context;
}
function useComboboxInputValueContext() {
	return import_react.useContext(ComboboxInputValueContext);
}
function useComboboxHasItemsContext() {
	return import_react.useContext(ComboboxHasItemsContext);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/store.mjs
var selectors = {
	id: (state) => state.id,
	labelId: (state) => state.labelId,
	items: (state) => state.items,
	selectedValue: (state) => state.selectedValue,
	hasSelectionChips: (state) => {
		const selectedValue = state.selectedValue;
		return Array.isArray(selectedValue) && selectedValue.length > 0;
	},
	hasSelectedValue: (state) => {
		const { selectedValue, selectionMode } = state;
		if (selectedValue == null) return false;
		if (selectionMode === "multiple" && Array.isArray(selectedValue)) return selectedValue.length > 0;
		return true;
	},
	hasNullItemLabel: (state, enabled) => {
		return enabled ? hasNullItemLabel(state.items) : false;
	},
	open: (state) => state.open,
	mounted: (state) => state.mounted,
	forceMounted: (state) => state.forceMounted,
	inline: (state) => state.inline,
	activeIndex: (state) => state.activeIndex,
	selectedIndex: (state) => state.selectedIndex,
	isActive: (state, index) => state.activeIndex === index,
	isSelected: (state, itemValue) => {
		const comparer = state.isItemEqualToValue;
		const selectedValue = state.selectedValue;
		if (Array.isArray(selectedValue)) return selectedValue.some((selectedItem) => compareItemEquality(itemValue, selectedItem, comparer));
		return compareItemEquality(itemValue, selectedValue, comparer);
	},
	transitionStatus: (state) => state.transitionStatus,
	popupProps: (state) => state.popupProps,
	listProps: (state) => state.listProps,
	inputProps: (state) => state.inputProps,
	triggerProps: (state) => state.triggerProps,
	itemProps: (state) => state.itemProps,
	positionerElement: (state) => state.positionerElement,
	listElement: (state) => state.listElement,
	popupId: (state) => state.popupId,
	triggerElement: (state) => state.triggerElement,
	inputElement: (state) => state.inputElement,
	inputGroupElement: (state) => state.inputGroupElement,
	popupSide: (state) => state.popupSide,
	openMethod: (state) => state.openMethod,
	inputInsidePopup: (state) => state.inputInsidePopup,
	inputOwnsFormValue: (state) => state.inputOwnsFormValue,
	selectionMode: (state) => state.selectionMode,
	name: (state) => state.name,
	form: (state) => state.form,
	disabled: (state) => state.disabled,
	readOnly: (state) => state.readOnly,
	required: (state) => state.required,
	grid: (state) => state.grid,
	virtualized: (state) => state.virtualized,
	itemToStringLabel: (state) => state.itemToStringLabel,
	isItemEqualToValue: (state) => state.isItemEqualToValue,
	modal: (state) => state.modal,
	autoHighlight: (state) => state.autoHighlight
};
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/utils/index.mjs
/**
* Derives the default id assigned to `Combobox.Popup` when the input is rendered inside it.
* Shared by the popup (which applies it) and the trigger (which references it via `aria-controls`)
* so the convention only lives in one place.
*/
function getComboboxPopupId(rootId) {
	return rootId == null ? void 0 : `${rootId}-popup`;
}
/**
* Enhanced filter using Intl.Collator for more robust string matching.
* Uses the provided `itemToStringLabel` function if available, otherwise falls back to:
* • When `item` is an object with a `value` property, that property is used.
* • When `item` is a primitive (e.g. `string`), it is used directly.
*/
function createCollatorItemFilter(collatorFilter, itemToStringLabel) {
	return (item, query) => {
		if (item == null) return false;
		return collatorFilter.contains(item, query, itemToStringLabel);
	};
}
/**
* Enhanced filter for single selection mode using Intl.Collator that shows all items
* when query is empty or matches the current selection, making it easier to browse options.
*/
function createSingleSelectionCollatorFilter(collatorFilter, itemToStringLabel, selectedValue) {
	return (item, query) => {
		if (item == null) return false;
		if (!query) return true;
		const selectedString = selectedValue != null ? stringifyAsLabel(selectedValue, itemToStringLabel) : "";
		if (selectedString && collatorFilter.contains(selectedString, query) && selectedString.length === query.length) return true;
		return collatorFilter.contains(item, query, itemToStringLabel);
	};
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/filter.mjs
var filterCache = /* @__PURE__ */ new Map();
function getFilter(options = {}) {
	const mergedOptions = {
		usage: "search",
		sensitivity: "base",
		ignorePunctuation: true,
		...options
	};
	const cacheKey = `${stringifyLocale(options.locale)}|${JSON.stringify(mergedOptions)}`;
	const cachedFilter = filterCache.get(cacheKey);
	if (cachedFilter) return cachedFilter;
	const collator = new Intl.Collator(options.locale, mergedOptions);
	const filter = {
		contains(item, query, itemToString) {
			if (!query) return true;
			const itemString = stringifyAsLabel(item, itemToString);
			for (let i = 0; i <= itemString.length - query.length; i += 1) if (collator.compare(itemString.slice(i, i + query.length), query) === 0) return true;
			return false;
		},
		startsWith(item, query, itemToString) {
			if (!query) return true;
			const itemString = stringifyAsLabel(item, itemToString);
			return collator.compare(itemString.slice(0, query.length), query) === 0;
		},
		endsWith(item, query, itemToString) {
			if (!query) return true;
			const itemString = stringifyAsLabel(item, itemToString);
			const queryLength = query.length;
			return itemString.length >= queryLength && collator.compare(itemString.slice(itemString.length - queryLength), query) === 0;
		}
	};
	filterCache.set(cacheKey, filter);
	return filter;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/utils/useFilter.mjs
/**
* Matches items against a query using `Intl.Collator` for robust string matching.
*/
var useCoreFilter = getFilter;
/**
* Matches items against a query using `Intl.Collator` for robust string matching.
*/
function useComboboxFilter(options = {}) {
	const { multiple = false, value, ...collatorOptions } = options;
	const coreFilter = getFilter(collatorOptions);
	const contains = import_react.useCallback((item, query, itemToString) => {
		if (multiple) return createCollatorItemFilter(coreFilter, itemToString)(item, query);
		return createSingleSelectionCollatorFilter(coreFilter, itemToString, value)(item, query);
	}, [
		coreFilter,
		value,
		multiple
	]);
	return import_react.useMemo(() => ({
		...coreFilter,
		contains
	}), [contains, coreFilter]);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/scrollable.mjs
function isScrollableY(element, allowOverflowIntent = false) {
	const { overflowY } = getComputedStyle(element);
	if (overflowY !== "auto" && overflowY !== "scroll") return false;
	return allowOverflowIntent ? element.clientHeight > 0 : element.scrollHeight > element.clientHeight;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/utils/constants.mjs
var NO_ACTIVE_VALUE = Symbol("none");
var INITIAL_LAST_HIGHLIGHT = {
	value: NO_ACTIVE_VALUE,
	index: -1
};
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/AriaCombobox.mjs
var import_jsx_runtime = require_jsx_runtime();
function AriaCombobox(props) {
	const { id: idProp, onOpenChangeComplete: onOpenChangeCompleteProp, defaultSelectedValue = null, selectedValue: selectedValueProp, onSelectedValueChange, defaultInputValue: defaultInputValueProp, inputValue: inputValueProp, open: openProp, defaultOpen = false, selectionMode, onItemHighlighted: onItemHighlightedProp, name: nameProp, form, disabled: disabledProp = false, readOnly = false, required = false, inputRef: inputRefProp, grid = false, items, filteredItems: filteredItemsProp, filter: filterProp, openOnInputClick = true, autoHighlight = false, keepHighlight = false, highlightItemOnHover = true, loopFocus = true, itemToStringLabel, itemToStringValue, isItemEqualToValue = defaultItemEquality, virtualized = false, inline: inlineProp = false, fillInputOnItemPress = true, modal = false, limit = -1, autoComplete = "list", formAutoComplete, locale, submitOnItemClick = false } = props;
	const { clearErrors } = useFormContext();
	const { setDirty, validityData, setFilled, name: fieldName, disabled: fieldDisabled, setTouched, setFocused, validationMode, validation } = useFieldRootContext();
	const direction = useDirection();
	const id = useLabelableId({ id: idProp });
	const collatorFilter = useCoreFilter({ locale });
	const [queryChangedAfterOpen, setQueryChangedAfterOpen] = import_react.useState(false);
	const [closeQuery, setCloseQuery] = import_react.useState(null);
	const listRef = import_react.useRef([]);
	const labelsRef = import_react.useRef([]);
	const popupRef = import_react.useRef(null);
	const inputRef = import_react.useRef(null);
	const startDismissRef = import_react.useRef(null);
	const endDismissRef = import_react.useRef(null);
	const emptyRef = import_react.useRef(null);
	const keyboardActiveRef = import_react.useRef(true);
	const hadInputClearRef = import_react.useRef(false);
	const chipsContainerRef = import_react.useRef(null);
	const clearRef = import_react.useRef(null);
	const selectionEventRef = import_react.useRef(null);
	const lastHighlightRef = import_react.useRef(INITIAL_LAST_HIGHLIGHT);
	const pendingQueryHighlightRef = import_react.useRef(null);
	/**
	* Contains the currently visible list of item values post-filtering.
	*/
	const valuesRef = import_react.useRef([]);
	/**
	* The item element that received the last `pointerdown`, used to detect whether a
	* `mouseup` on an item belongs to a drag-select gesture that started elsewhere.
	*/
	const pointerDownItemRef = import_react.useRef(null);
	const disabled = fieldDisabled || disabledProp;
	const name = fieldName ?? nameProp;
	const multiple = selectionMode === "multiple";
	const single = selectionMode === "single";
	const hasInputValue = inputValueProp !== void 0 || defaultInputValueProp !== void 0;
	const hasItems = items !== void 0;
	const hasFilteredItemsProp = filteredItemsProp !== void 0;
	let autoHighlightMode;
	if (autoHighlight === "always") autoHighlightMode = "always";
	else autoHighlightMode = autoHighlight ? "input-change" : false;
	const [selectedValue, setSelectedValueUnwrapped] = useControlled({
		controlled: selectedValueProp,
		default: multiple ? defaultSelectedValue ?? EMPTY_ARRAY : defaultSelectedValue,
		name: "Combobox",
		state: "selectedValue"
	});
	const filter = import_react.useMemo(() => {
		if (filterProp === null) return () => true;
		if (filterProp !== void 0) return filterProp;
		return createCollatorItemFilter(collatorFilter, itemToStringLabel);
	}, [
		filterProp,
		collatorFilter,
		itemToStringLabel
	]);
	const initialDefaultInputValue = useRefWithInit(() => {
		if (hasInputValue) return defaultInputValueProp ?? "";
		if (single) return stringifyAsLabel(selectedValue, itemToStringLabel);
		return "";
	}).current;
	const [inputValue, setInputValueUnwrapped] = useControlled({
		controlled: inputValueProp,
		default: initialDefaultInputValue,
		name: "Combobox",
		state: "inputValue"
	});
	const [open, setOpenUnwrapped] = useControlled({
		controlled: openProp,
		default: defaultOpen,
		name: "Combobox",
		state: "open"
	});
	const isGrouped = isGroupedItems(items);
	const query = closeQuery ?? String(inputValue).trim();
	const selectedLabelString = single ? stringifyAsLabel(selectedValue, itemToStringLabel) : "";
	const shouldBypassFiltering = single && !queryChangedAfterOpen && query !== "" && selectedLabelString.length === query.length && collatorFilter.contains(selectedLabelString, query);
	const filterQuery = shouldBypassFiltering ? "" : query;
	const shouldIgnoreExternalFiltering = hasItems && hasFilteredItemsProp && shouldBypassFiltering;
	const flatItems = import_react.useMemo(() => {
		if (!items) return EMPTY_ARRAY;
		if (isGrouped) return items.flatMap((group) => group.items);
		return items;
	}, [items, isGrouped]);
	const filteredItems = import_react.useMemo(() => {
		if (filteredItemsProp && !shouldIgnoreExternalFiltering) return filteredItemsProp;
		if (!items) return EMPTY_ARRAY;
		if (isGrouped) {
			const groupedItems = items;
			const resultingGroups = [];
			let currentCount = 0;
			for (const group of groupedItems) {
				if (limit > -1 && currentCount >= limit) break;
				const remainingLimit = limit > -1 ? limit - currentCount : Infinity;
				const itemsToTake = filterQuery === "" ? group.items.slice(0, remainingLimit) : [];
				if (filterQuery !== "") for (const item of group.items) {
					if (itemsToTake.length >= remainingLimit) break;
					if (filter(item, filterQuery, itemToStringLabel)) itemsToTake.push(item);
				}
				if (itemsToTake.length > 0) {
					const newGroup = {
						...group,
						items: itemsToTake
					};
					resultingGroups.push(newGroup);
					currentCount += itemsToTake.length;
				}
			}
			return resultingGroups;
		}
		if (filterQuery === "") return limit > -1 ? flatItems.slice(0, limit) : flatItems;
		const limitedItems = [];
		for (const item of flatItems) {
			if (limit > -1 && limitedItems.length >= limit) break;
			if (filter(item, filterQuery, itemToStringLabel)) limitedItems.push(item);
		}
		return limitedItems;
	}, [
		filteredItemsProp,
		shouldIgnoreExternalFiltering,
		items,
		isGrouped,
		filterQuery,
		limit,
		filter,
		itemToStringLabel,
		flatItems
	]);
	const flatFilteredItems = import_react.useMemo(() => {
		if (isGrouped) return filteredItems.flatMap((g) => g.items);
		return filteredItems;
	}, [filteredItems, isGrouped]);
	const store = useRefWithInit(() => {
		let initialSelectedIndex = null;
		if (inlineProp && open && hasItems && selectionMode !== "none") initialSelectedIndex = findSelectionIndex(flatFilteredItems, selectedValue, isItemEqualToValue, multiple);
		return new Store({
			id,
			labelId: void 0,
			selectedValue,
			open,
			items,
			selectionMode,
			listRef,
			labelsRef,
			popupRef,
			emptyRef,
			inputRef,
			startDismissRef,
			endDismissRef,
			keyboardActiveRef,
			chipsContainerRef,
			clearRef,
			valuesRef,
			pointerDownItemRef,
			selectionEventRef,
			name,
			form,
			disabled,
			readOnly,
			required,
			grid,
			virtualized,
			openOnInputClick,
			itemToStringLabel,
			isItemEqualToValue,
			modal,
			autoHighlight: autoHighlightMode,
			submitOnItemClick,
			hasInputValue,
			mounted: false,
			forceMounted: false,
			transitionStatus: "idle",
			inline: inlineProp,
			activeIndex: null,
			selectedIndex: initialSelectedIndex,
			popupProps: {},
			listProps: {},
			inputProps: {},
			triggerProps: {},
			itemProps: EMPTY_OBJECT,
			positionerElement: null,
			listElement: null,
			popupId: void 0,
			triggerElement: null,
			inputElement: null,
			inputGroupElement: null,
			popupSide: null,
			openMethod: null,
			inputInsidePopup: true,
			inputOwnsFormValue: selectionMode === "none",
			onOpenChangeComplete: NOOP,
			setOpen: NOOP,
			setInputValue: NOOP,
			setSelectedValue: NOOP,
			setIndices: NOOP,
			handleSelection: NOOP,
			forceMount: NOOP,
			requestSubmit: NOOP
		});
	}).current;
	const fieldRawValue = selectionMode === "none" ? inputValue : selectedValue;
	const fieldStringValue = import_react.useMemo(() => {
		if (selectionMode === "none") return fieldRawValue;
		if (Array.isArray(selectedValue)) return selectedValue.map((value) => stringifyAsValue(value, itemToStringValue));
		return stringifyAsValue(selectedValue, itemToStringValue);
	}, [
		fieldRawValue,
		itemToStringValue,
		selectionMode,
		selectedValue
	]);
	const onItemHighlighted = useStableCallback(onItemHighlightedProp);
	const onOpenChangeComplete = useStableCallback(onOpenChangeCompleteProp);
	const activeIndex = useStore(store, selectors.activeIndex);
	const selectedIndex = useStore(store, selectors.selectedIndex);
	const positionerElement = useStore(store, selectors.positionerElement);
	const listElement = useStore(store, selectors.listElement);
	const triggerElement = useStore(store, selectors.triggerElement);
	const inputElement = useStore(store, selectors.inputElement);
	const inputGroupElement = useStore(store, selectors.inputGroupElement);
	const inline = useStore(store, selectors.inline);
	const inputInsidePopup = useStore(store, selectors.inputInsidePopup);
	const inputOwnsFormValue = useStore(store, selectors.inputOwnsFormValue);
	const triggerRef = useValueAsRef(triggerElement);
	const { mounted, setMounted, transitionStatus } = useTransitionStatus(open);
	const { openMethod, triggerProps } = useOpenInteractionType(open);
	const getStringifiedValueForForm = useStableCallback(() => fieldStringValue);
	useRegisterFieldControl(inputInsidePopup ? triggerRef : inputRef, id, fieldRawValue, getStringifiedValueForForm, !disabled, nameProp);
	const forceMount = useStableCallback(() => {
		if (items) labelsRef.current = flatFilteredItems.map((item) => stringifyAsLabel(item, itemToStringLabel));
		else store.set("forceMounted", true);
	});
	/**
	* Emits `onItemHighlighted` for the item at `index`, or clears the highlight when `index` is `-1`
	* (a no-op if nothing was highlighted). Keeps `lastHighlightRef` in sync with what was emitted.
	*/
	const emitHighlight = useStableCallback((value, index, type) => {
		if (index === -1) {
			if (lastHighlightRef.current === INITIAL_LAST_HIGHLIGHT) return;
			lastHighlightRef.current = INITIAL_LAST_HIGHLIGHT;
		} else lastHighlightRef.current = {
			value,
			index
		};
		onItemHighlighted(value, createGenericEventDetails(type, void 0, { index }));
	});
	const setIndices = useStableCallback((options) => {
		store.update(options);
		const activeIndexOption = options.activeIndex;
		if (activeIndexOption === void 0) return;
		const type = options.type || "none";
		if (activeIndexOption === null) emitHighlight(void 0, -1, type);
		else emitHighlight(valuesRef.current[activeIndexOption], activeIndexOption, type);
	});
	const setInputValue = useStableCallback((next, eventDetails) => {
		hadInputClearRef.current = eventDetails.reason === inputClear;
		props.onInputValueChange?.(next, eventDetails);
		if (eventDetails.isCanceled) return;
		if (eventDetails.reason === "input-change") {
			if (open && closeQuery !== null) setCloseQuery(null);
			const event = eventDetails.event;
			const inputType = event.inputType;
			if (event.type === "compositionend" || inputType != null && inputType !== "" && inputType !== "insertReplacementText") {
				const hasQuery = next.trim() !== "";
				if (hasQuery) setQueryChangedAfterOpen(true);
				pendingQueryHighlightRef.current = { hasQuery };
				const list = store.state.listElement;
				if (!store.state.virtualized && list) {
					const popup = popupRef.current;
					for (const ancestor of getOverflowAncestors(list.firstElementChild ?? list)) {
						if (!isHTMLElement(ancestor) || (popup ? !contains(popup, ancestor) : ancestor.getAttribute("role") === "dialog")) break;
						if (isScrollableY(ancestor)) {
							ancestor.scrollTop = 0;
							break;
						}
					}
				}
				if (hasQuery && autoHighlightMode && store.state.activeIndex == null && (open || inline)) store.set("activeIndex", 0);
			}
		} else if (eventDetails.reason === "input-clear" && next === "" && store.state.inputInsidePopup) pendingQueryHighlightRef.current = {
			hasQuery: false,
			selection: true
		};
		setInputValueUnwrapped(next);
	});
	const setOpen = useStableCallback((nextOpen, eventDetails) => {
		if (open === nextOpen) return;
		if (eventDetails.reason === "escape-key" && hasItems && flatFilteredItems.length === 0 && !emptyRef.current) eventDetails.allowPropagation();
		props.onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		if (nextOpen && inputInsidePopup && !inline && closeQuery !== null) {
			setQueryChangedAfterOpen(false);
			setCloseQuery(null);
			if (inputValue !== "" && eventDetails.reason !== "input-change") setInputValue("", createChangeEventDetails(inputClear, eventDetails.event));
		}
		if (!nextOpen && queryChangedAfterOpen) {
			if (single) {
				if (!inline) setCloseQuery(query);
				if (query === "") setQueryChangedAfterOpen(false);
			} else if (multiple) {
				if (!inline) setCloseQuery(query);
				if (inputInsidePopup) setIndices({ activeIndex: null });
				if (!inputInsidePopup || inline) setInputValue("", createChangeEventDetails(inputClear, eventDetails.event));
			}
		}
		setOpenUnwrapped(nextOpen);
		if (!nextOpen && inputInsidePopup && (eventDetails.reason === "focus-out" || eventDetails.reason === "outside-press")) {
			setTouched(true);
			setFocused(false);
			if (validationMode === "onBlur") {
				const valueToValidate = selectionMode === "none" ? inputValue : selectedValue;
				validation.commit(valueToValidate);
			}
		}
	});
	const setSelectedValue = useStableCallback((nextValue, eventDetails) => {
		onSelectedValueChange?.(nextValue, eventDetails);
		if (eventDetails.isCanceled) return;
		setSelectedValueUnwrapped(nextValue);
		if (selectionMode === "none" && popupRef.current && fillInputOnItemPress || single && !store.state.inputInsidePopup) setInputValue(stringifyAsLabel(nextValue, itemToStringLabel), createChangeEventDetails(eventDetails.reason, eventDetails.event));
	});
	const handleSelection = useStableCallback((event, itemValue) => {
		const targetEl = getTarget(event);
		const overrideEvent = selectionEventRef.current ?? event;
		selectionEventRef.current = null;
		const eventDetails = createChangeEventDetails(itemPress, overrideEvent);
		const href = targetEl?.closest("a")?.getAttribute("href");
		if (href) {
			if (href.startsWith("#")) setOpen(false, eventDetails);
			return;
		}
		if (multiple) {
			const currentSelectedValue = Array.isArray(selectedValue) ? selectedValue : [];
			const nextValue = selectedValueIncludes(currentSelectedValue, itemValue, isItemEqualToValue) ? removeItem(currentSelectedValue, itemValue, isItemEqualToValue) : [...currentSelectedValue, itemValue];
			setSelectedValue(nextValue, eventDetails);
			if (eventDetails.isCanceled) return;
			if (!(inputRef.current ? inputRef.current.value.trim() !== "" : false)) return;
			if (store.state.inputInsidePopup) setInputValue("", createChangeEventDetails(inputClear, eventDetails.event));
			else setOpen(false, eventDetails);
		} else {
			setSelectedValue(itemValue, eventDetails);
			if (eventDetails.isCanceled) return;
			setOpen(false, eventDetails);
		}
	});
	const requestSubmit = useStableCallback(() => {
		const formElement = validation.inputRef.current?.form ?? store.state.inputElement?.form;
		if (formElement && typeof formElement.requestSubmit === "function") formElement.requestSubmit();
	});
	const handleUnmount = useStableCallback(() => {
		setMounted(false);
		onOpenChangeComplete?.(false);
		setQueryChangedAfterOpen(false);
		setCloseQuery(null);
		if (selectionMode === "none") setIndices({
			activeIndex: null,
			selectedIndex: null
		});
		else setIndices({ activeIndex: null });
		if (multiple && inputRef.current && inputRef.current.value !== "" && !hadInputClearRef.current) setInputValue("", createChangeEventDetails(inputClear));
		if (single) if (store.state.inputInsidePopup) {
			if (inputRef.current && inputRef.current.value !== "") setInputValue("", createChangeEventDetails(inputClear));
		} else {
			const stringVal = stringifyAsLabel(selectedValue, itemToStringLabel);
			if (inputRef.current && inputRef.current.value !== stringVal) setInputValue(stringVal, createChangeEventDetails(stringVal === "" ? inputClear : none));
		}
	});
	const resolvedPopupRef = import_react.useMemo(() => {
		if (inline && positionerElement) return { current: positionerElement.closest("[role=\"dialog\"]") };
		return popupRef;
	}, [inline, positionerElement]);
	useOpenChangeComplete({
		enabled: !props.actionsRef,
		open,
		ref: resolvedPopupRef,
		onComplete() {
			if (!open) handleUnmount();
		}
	});
	import_react.useImperativeHandle(props.actionsRef, () => ({ unmount: handleUnmount }), [handleUnmount]);
	useIsoLayoutEffect(function syncClosedState() {
		if (open) return;
		pointerDownItemRef.current = null;
		if (selectionMode === "none") return;
		const registry = hasItems ? flatItems : valuesRef.current;
		setIndices({ selectedIndex: findSelectionIndex(registry, selectedValue, isItemEqualToValue, multiple) });
	}, [
		open,
		selectedValue,
		selectionMode,
		multiple,
		hasItems,
		flatItems,
		isItemEqualToValue,
		setIndices
	]);
	useIsoLayoutEffect(() => {
		if (items) {
			valuesRef.current = flatFilteredItems;
			listRef.current.length = flatFilteredItems.length;
		}
	}, [items, flatFilteredItems]);
	useIsoLayoutEffect(() => {
		const pendingHighlight = pendingQueryHighlightRef.current;
		if (pendingHighlight) {
			const listIsNavigable = open || inline || store.state.positionerElement?.hidden === false;
			if (pendingHighlight.hasQuery) {
				if (autoHighlightMode && listIsNavigable) store.set("activeIndex", 0);
				pendingQueryHighlightRef.current = null;
			} else if (String(inputValue).trim() === "") {
				pendingQueryHighlightRef.current = null;
				if (listIsNavigable) {
					const clearedBySelection = pendingHighlight.selection;
					if (autoHighlightMode === "always" && !clearedBySelection && store.state.selectionMode === "none") store.set("activeIndex", 0);
					queueMicrotask(() => {
						if (!store.state.open && !store.state.inline || inputRef.current && inputRef.current.value.trim() !== "") return;
						const currentSelectedValue = store.state.selectedValue;
						const isMultiple = store.state.selectionMode === "multiple";
						const lastSelectedValue = isMultiple && Array.isArray(currentSelectedValue) ? currentSelectedValue[currentSelectedValue.length - 1] : currentSelectedValue;
						const hasSelection = store.state.selectionMode !== "none" && lastSelectedValue != null;
						if (hasSelection || clearedBySelection) {
							const registry = hasItems || hasFilteredItemsProp ? flatFilteredItems : valuesRef.current;
							store.set("activeIndex", hasSelection ? findSelectionIndex(registry, currentSelectedValue, store.state.isItemEqualToValue, isMultiple) : null);
						} else if (autoHighlightMode === "always") store.set("activeIndex", 0);
					});
				}
			}
		}
		if (!open && !inline) return;
		const candidateItems = hasItems || hasFilteredItemsProp ? flatFilteredItems : valuesRef.current;
		const storeActiveIndex = store.state.activeIndex;
		if (storeActiveIndex == null) {
			if (autoHighlightMode === "always" && candidateItems.length > 0) {
				store.set("activeIndex", 0);
				return;
			}
			emitHighlight(void 0, -1, none);
			return;
		}
		if (storeActiveIndex >= candidateItems.length) {
			emitHighlight(void 0, -1, none);
			store.set("activeIndex", null);
			return;
		}
		const itemValue = candidateItems[storeActiveIndex];
		const previouslyHighlightedItemValue = lastHighlightRef.current.value;
		const isSameItem = previouslyHighlightedItemValue !== NO_ACTIVE_VALUE && compareItemEquality(itemValue, previouslyHighlightedItemValue, store.state.isItemEqualToValue);
		if (lastHighlightRef.current.index !== storeActiveIndex || !isSameItem) emitHighlight(itemValue, storeActiveIndex, none);
	}, [
		activeIndex,
		autoHighlightMode,
		emitHighlight,
		hasFilteredItemsProp,
		hasItems,
		flatFilteredItems,
		inline,
		open,
		store,
		inputValue
	]);
	useIsoLayoutEffect(() => {
		if (selectionMode === "none") {
			setFilled(String(inputValue) !== "");
			return;
		}
		setFilled(multiple ? Array.isArray(selectedValue) && selectedValue.length > 0 : selectedValue != null);
	}, [
		setFilled,
		selectionMode,
		inputValue,
		selectedValue,
		multiple
	]);
	import_react.useEffect(() => {
		if (hasItems && autoHighlightMode && flatFilteredItems.length === 0) setIndices({ activeIndex: null });
	}, [
		hasItems,
		autoHighlightMode,
		flatFilteredItems.length,
		setIndices
	]);
	function isSelectedValueDirty(value) {
		const initialValue = validityData.initialValue;
		if (Array.isArray(value) && Array.isArray(initialValue)) return !areArraysEqual(value, initialValue, (itemValue, initialItemValue) => compareItemEquality(itemValue, initialItemValue, isItemEqualToValue));
		return value !== initialValue;
	}
	useValueChanged(query, () => {
		if (!open || query === "" || query === String(initialDefaultInputValue)) return;
		setQueryChangedAfterOpen(true);
	});
	function syncInputToSelectedLabel() {
		const nextInputValue = stringifyAsLabel(selectedValue, itemToStringLabel);
		if (inputValue !== nextInputValue) setInputValue(nextInputValue, createChangeEventDetails(none));
	}
	useValueChanged(selectedValue, () => {
		if (selectionMode === "none") return;
		clearErrors(name);
		setDirty(isSelectedValueDirty(selectedValue));
		validation.change(selectedValue);
		if (single && !hasInputValue && !inputInsidePopup) syncInputToSelectedLabel();
	});
	useValueChanged(inputValue, () => {
		if (selectionMode !== "none") return;
		clearErrors(name);
		setDirty(inputValue !== validityData.initialValue);
		validation.change(inputValue);
	});
	useValueChanged(items, () => {
		if (!single || hasInputValue || inputInsidePopup || queryChangedAfterOpen) return;
		syncInputToSelectedLabel();
	});
	const floatingRootContext = useFloatingRootContext({
		open: inline ? true : open,
		onOpenChange: setOpen,
		elements: {
			reference: inputInsidePopup ? triggerElement : inputElement,
			floating: positionerElement
		}
	});
	const ariaHasPopup = grid ? "grid" : "listbox";
	const expanded = open || inline;
	const ariaExpanded = expanded ? "true" : "false";
	const role = import_react.useMemo(() => {
		const isPlainInput = inputElement?.tagName === "INPUT";
		const shouldTreatAsInput = inputElement == null || isPlainInput;
		const shouldApplyAria = shouldTreatAsInput || expanded;
		const reference = shouldTreatAsInput ? {
			autoComplete: "off",
			spellCheck: "false",
			autoCorrect: "off",
			autoCapitalize: "none"
		} : {};
		if (shouldApplyAria) {
			reference.role = "combobox";
			reference["aria-expanded"] = ariaExpanded;
			reference["aria-haspopup"] = ariaHasPopup;
			reference["aria-controls"] = expanded ? listElement?.id : void 0;
			reference["aria-autocomplete"] = autoComplete;
		}
		return {
			reference,
			floating: { role: "presentation" }
		};
	}, [
		inputElement,
		expanded,
		ariaExpanded,
		ariaHasPopup,
		listElement?.id,
		autoComplete
	]);
	const click = useClick(floatingRootContext, {
		enabled: !readOnly && !disabled && openOnInputClick,
		event: "mousedown-only",
		toggle: false,
		touchOpenDelay: inputInsidePopup ? 0 : 100,
		reason: inputPress
	});
	const dismiss = useDismiss(floatingRootContext, {
		enabled: !readOnly && !disabled && !inline,
		outsidePressEvent: {
			mouse: "sloppy",
			touch: "intentional"
		},
		bubbles: inline ? true : void 0,
		outsidePress(event) {
			const target = getTarget(event);
			return !contains(triggerElement, target) && !contains(clearRef.current, target) && !contains(chipsContainerRef.current, target) && !contains(inputGroupElement, target);
		}
	});
	const listNavigation = useListNavigation(floatingRootContext, {
		enabled: !readOnly && !disabled,
		id,
		listRef,
		activeIndex,
		selectedIndex,
		virtual: true,
		loopFocus,
		allowEscape: loopFocus && !autoHighlightMode,
		focusItemOnOpen: queryChangedAfterOpen || selectionMode === "none" && !autoHighlightMode ? false : "auto",
		focusItemOnHover: highlightItemOnHover,
		resetOnPointerLeave: !keepHighlight,
		orientation: grid ? "horizontal" : void 0,
		rtl: direction === "rtl",
		disabledIndices: EMPTY_ARRAY,
		grid: grid ? gridNavigation : void 0,
		onNavigate(nextActiveIndex, event) {
			if (!event && !open || transitionStatus === "ending") return;
			if (!event) setIndices({ activeIndex: nextActiveIndex });
			else setIndices({
				activeIndex: nextActiveIndex,
				type: keyboardActiveRef.current ? keyboard : pointer
			});
		}
	});
	const inputProps = import_react.useMemo(() => mergeProps(listNavigation.reference, { onKeyDown(event) {
		if (grid && store.state.activeIndex == null && (event.key === "ArrowLeft" || event.key === "ArrowRight")) event.preventBaseUIHandler();
	} }, dismiss.reference, click.reference, role.reference), [
		listNavigation.reference,
		dismiss.reference,
		click.reference,
		role.reference,
		grid,
		store
	]);
	const popupProps = import_react.useMemo(() => mergeProps(FOCUSABLE_POPUP_PROPS, dismiss.floating), [dismiss.floating]);
	const listProps = import_react.useMemo(() => mergeProps(listNavigation.floating, role.floating), [listNavigation.floating, role.floating]);
	const itemProps = import_react.useMemo(() => {
		const listNavigationItemProps = listNavigation.item;
		if (!listNavigationItemProps) return EMPTY_OBJECT;
		return {
			...listNavigationItemProps,
			onFocus: void 0
		};
	}, [listNavigation.item]);
	useOnFirstRender(() => {
		store.update({
			inline: inlineProp,
			popupProps,
			listProps,
			inputProps,
			triggerProps,
			itemProps,
			setOpen,
			setInputValue,
			setSelectedValue,
			setIndices,
			handleSelection,
			forceMount,
			requestSubmit,
			onOpenChangeComplete
		});
	});
	useIsoLayoutEffect(() => {
		store.update({
			id,
			selectedValue,
			open,
			mounted,
			transitionStatus,
			items,
			inline: inlineProp,
			popupProps,
			listProps,
			inputProps,
			triggerProps,
			openMethod,
			itemProps,
			selectionMode,
			name,
			form,
			disabled,
			readOnly,
			required,
			grid,
			virtualized,
			openOnInputClick,
			itemToStringLabel,
			modal,
			autoHighlight: autoHighlightMode,
			isItemEqualToValue,
			submitOnItemClick,
			hasInputValue,
			inputOwnsFormValue: selectionMode === "none" && (inlineProp || !store.state.inputInsidePopup)
		});
	}, [
		store,
		id,
		selectedValue,
		open,
		mounted,
		transitionStatus,
		items,
		popupProps,
		listProps,
		inputProps,
		itemProps,
		openMethod,
		triggerProps,
		selectionMode,
		name,
		disabled,
		readOnly,
		required,
		grid,
		virtualized,
		openOnInputClick,
		itemToStringLabel,
		modal,
		isItemEqualToValue,
		submitOnItemClick,
		hasInputValue,
		inlineProp,
		autoHighlightMode,
		form
	]);
	const hiddenInputRef = useMergedRefs(inputRefProp, validation.inputRef);
	const itemsContextValue = import_react.useMemo(() => ({
		query,
		hasItems,
		filteredItems,
		flatFilteredItems
	}), [
		query,
		hasItems,
		filteredItems,
		flatFilteredItems
	]);
	const serializedValue = import_react.useMemo(() => {
		if (Array.isArray(fieldRawValue)) return "";
		return stringifyAsValue(fieldRawValue, itemToStringValue);
	}, [fieldRawValue, itemToStringValue]);
	const hasMultipleSelection = multiple && Array.isArray(selectedValue) && selectedValue.length > 0;
	const hiddenInputName = multiple || selectionMode === "none" && inputOwnsFormValue ? void 0 : name;
	const hiddenInputs = import_react.useMemo(() => {
		if (!multiple || !Array.isArray(selectedValue) || !name) return null;
		return selectedValue.map((value) => {
			const currentSerializedValue = stringifyAsValue(value, itemToStringValue);
			return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
				type: "hidden",
				form,
				name,
				value: currentSerializedValue,
				disabled
			}, currentSerializedValue);
		});
	}, [
		multiple,
		selectedValue,
		form,
		name,
		itemToStringValue,
		disabled
	]);
	const children = /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		props.children,
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
			...validation.getValidationProps(disabled, {
				onFocus() {
					if (inputInsidePopup) {
						triggerElement?.focus();
						return;
					}
					(inputRef.current || triggerElement)?.focus();
				},
				onChange(event) {
					if (event.nativeEvent.defaultPrevented || disabled || readOnly) return;
					const nextValue = event.currentTarget.value;
					const nextValueLower = nextValue.toLowerCase();
					const details = createChangeEventDetails(none, event.nativeEvent);
					const findSerializedMatchIndex = () => valuesRef.current.findIndex((candidate) => stringifyAsValue(candidate, itemToStringValue).toLowerCase() === nextValueLower || stringifyAsLabel(candidate, itemToStringLabel).toLowerCase() === nextValueLower);
					function handleChange() {
						if (multiple) return;
						if (selectionMode === "none") {
							setInputValue(nextValue, details);
							return;
						}
						let matchingIndex = findSerializedMatchIndex();
						if (matchingIndex === -1) matchingIndex = valuesRef.current.findIndex((_, index) => {
							const renderedLabel = labelsRef.current[index];
							return renderedLabel != null && renderedLabel.toLowerCase() === nextValueLower;
						});
						const matchingValue = matchingIndex === -1 ? void 0 : valuesRef.current[matchingIndex];
						if (matchingValue != null) setSelectedValue?.(matchingValue, details);
					}
					if (single) {
						forceMount();
						if (items && findSerializedMatchIndex() === -1) store.set("forceMounted", true);
					}
					queueMicrotask(handleChange);
				}
			}),
			id: id && hiddenInputName == null ? `${id}-hidden-input` : void 0,
			form,
			name: hiddenInputName,
			autoComplete: formAutoComplete,
			disabled,
			required: required && !hasMultipleSelection,
			readOnly,
			value: serializedValue,
			ref: hiddenInputRef,
			style: hiddenInputName ? visuallyHiddenInput : visuallyHidden,
			tabIndex: -1,
			"aria-hidden": true,
			suppressHydrationWarning: true
		}),
		hiddenInputs
	] });
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxRootContext.Provider, {
		value: store,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxFloatingContext.Provider, {
			value: floatingRootContext,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxHasItemsContext.Provider, {
				value: hasItems,
				children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxDerivedItemsContext.Provider, {
					value: itemsContextValue,
					children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxInputValueContext.Provider, {
						value: inputValue,
						children
					})
				})
			})
		})
	});
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/utils/stateAttributesMapping.mjs
var triggerStateAttributesMapping = {
	...pressableTriggerOpenStateMapping,
	...fieldValidityMapping,
	popupSide: (side) => side ? { "data-popup-side": side } : null,
	listEmpty: (empty) => empty ? { "data-list-empty": "" } : null
};
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/utils/parts.mjs
/**
* The popup side is only meaningful while the positioner is mounted, as the store retains the
* last resolved side after the popup unmounts.
*/
function usePopupSide(store) {
	const mounted = useStore(store, selectors.mounted);
	const popupSide = useStore(store, selectors.popupSide);
	const positionerElement = useStore(store, selectors.positionerElement);
	return mounted && positionerElement ? popupSide : null;
}
/**
* Whether the filtered list has no items to show.
*/
function useListEmpty() {
	return useComboboxDerivedItemsContext().filteredItems.length === 0;
}
/**
* The arrow keys that move the chip highlight backwards and forwards, in that order.
*/
function getChipNavigationKeys(direction) {
	return direction === "rtl" ? ["ArrowRight", "ArrowLeft"] : ["ArrowLeft", "ArrowRight"];
}
/**
* Where the highlight lands once the chip at `index` is removed, or `undefined` for no highlight.
*/
function getIndexAfterChipRemoval(index, chipCount) {
	const nextIndex = index >= chipCount - 1 ? chipCount - 2 : index;
	return nextIndex >= 0 ? nextIndex : void 0;
}
/**
* Commits the highlighted item by clicking it, tagging the originating event so the item's
* handler can attribute the selection to it.
*/
function clickHighlightedItem(store, activeIndex, nativeEvent) {
	const listItem = store.state.listRef.current[activeIndex];
	if (listItem) {
		store.state.selectionEventRef.current = nativeEvent;
		listItem.click();
		store.state.selectionEventRef.current = null;
	}
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/trigger/ComboboxTrigger.mjs
/**
* A button that opens the popup.
* Renders a `<button>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxTrigger = /*#__PURE__*/ import_react.forwardRef(function ComboboxTrigger(componentProps, forwardedRef) {
	const { render, className, nativeButton = true, disabled: disabledProp = false, id: idProp, style, ...elementProps } = componentProps;
	const { state: fieldState, disabled: fieldDisabled, setTouched, setFocused, validationMode, validation } = useFieldRootContext();
	const { labelId: fieldLabelId } = useLabelableContext();
	const store = useComboboxRootContext();
	const selectionMode = useStore(store, selectors.selectionMode);
	const comboboxDisabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const required = useStore(store, selectors.required);
	const positionerElement = useStore(store, selectors.positionerElement);
	const listElement = useStore(store, selectors.listElement);
	const storedPopupId = useStore(store, selectors.popupId);
	const triggerProps = useStore(store, selectors.triggerProps);
	const inputInsidePopup = useStore(store, selectors.inputInsidePopup);
	const rootId = useStore(store, selectors.id);
	const comboboxLabelId = useStore(store, selectors.labelId);
	const open = useStore(store, selectors.open);
	const selectedValue = useStore(store, selectors.selectedValue);
	const activeIndex = useStore(store, selectors.activeIndex);
	const selectedIndex = useStore(store, selectors.selectedIndex);
	const hasSelectedValue = useStore(store, selectors.hasSelectedValue);
	const floatingRootContext = useComboboxFloatingContext();
	const inputValue = useComboboxInputValueContext();
	const focusTimeout = useTimeout();
	const disabled = fieldDisabled || comboboxDisabled || disabledProp;
	const listEmpty = useListEmpty();
	const popupSide = usePopupSide(store);
	useLabelableId({ id: inputInsidePopup ? idProp : void 0 });
	const id = inputInsidePopup ? idProp ?? rootId : idProp;
	const ariaLabelledBy = resolveAriaLabelledBy(fieldLabelId, comboboxLabelId);
	let ariaControls;
	if (open && inputInsidePopup) ariaControls = storedPopupId ?? getComboboxPopupId(rootId);
	else if (open) ariaControls = listElement?.id;
	const currentPointerTypeRef = import_react.useRef("");
	function trackPointerType(event) {
		currentPointerTypeRef.current = event.pointerType;
	}
	const { reference: triggerTypeaheadProps } = useTypeahead(floatingRootContext, {
		enabled: !open && !readOnly && !comboboxDisabled && selectionMode === "single",
		listRef: store.state.labelsRef,
		activeIndex,
		selectedIndex,
		onMatch(index) {
			const nextSelectedValue = store.state.valuesRef.current[index];
			if (nextSelectedValue !== void 0) store.state.setSelectedValue(nextSelectedValue, createChangeEventDetails(none));
		}
	});
	const { reference: triggerClickProps } = useClick(floatingRootContext, {
		enabled: !readOnly && !comboboxDisabled,
		event: "mousedown"
	});
	const { buttonRef, getButtonProps } = useButton({
		native: nativeButton,
		disabled
	});
	const state = {
		...fieldState,
		open,
		disabled,
		popupSide,
		listEmpty,
		placeholder: selectionMode === "none" ? false : !hasSelectedValue
	};
	return useRenderElement("button", componentProps, {
		ref: [
			forwardedRef,
			buttonRef,
			useStableCallback((element) => {
				store.set("triggerElement", element);
			})
		],
		state,
		props: [
			triggerProps,
			triggerClickProps,
			triggerTypeaheadProps,
			{
				id,
				tabIndex: inputInsidePopup ? 0 : -1,
				role: inputInsidePopup ? "combobox" : void 0,
				"aria-expanded": open,
				"aria-haspopup": inputInsidePopup ? "dialog" : "listbox",
				"aria-controls": ariaControls,
				"aria-required": inputInsidePopup ? required || void 0 : void 0,
				"aria-labelledby": ariaLabelledBy,
				onPointerDown: trackPointerType,
				onPointerEnter: trackPointerType,
				onFocus() {
					setFocused(true);
					if (disabled || readOnly) return;
					focusTimeout.start(0, store.state.forceMount);
				},
				onBlur(event) {
					if (contains(positionerElement, event.relatedTarget)) return;
					setTouched(true);
					setFocused(false);
					if (validationMode === "onBlur") {
						const valueToValidate = selectionMode === "none" ? inputValue : selectedValue;
						validation.commit(valueToValidate);
					}
				},
				onMouseDown(event) {
					if (disabled || readOnly) return;
					if (!inputInsidePopup) floatingRootContext.set("domReferenceElement", event.currentTarget);
					store.state.forceMount();
					if (currentPointerTypeRef.current !== "touch") {
						store.state.inputRef.current?.focus();
						if (!inputInsidePopup) event.preventDefault();
					}
					if (open) return;
					const doc = ownerDocument(event.currentTarget);
					function handleMouseUp(mouseEvent) {
						const currentTriggerElement = store.state.triggerElement;
						if (!currentTriggerElement) return;
						const mouseUpTarget = getTarget(mouseEvent);
						const positioner = store.state.positionerElement;
						const list = store.state.listElement;
						if (contains(currentTriggerElement, mouseUpTarget) || contains(positioner, mouseUpTarget) || contains(list, mouseUpTarget)) return;
						if (isMouseWithinBounds(mouseEvent, currentTriggerElement)) return;
						store.state.setOpen(false, createChangeEventDetails(cancelOpen, mouseEvent));
					}
					if (inputInsidePopup) doc.addEventListener("mouseup", handleMouseUp, { once: true });
				},
				onKeyDown(event) {
					if (readOnly) return;
					if (event.key === "ArrowDown" || event.key === "ArrowUp") {
						stopEvent(event);
						store.state.setOpen(true, createChangeEventDetails(listNavigation, event.nativeEvent));
						store.state.inputRef.current?.focus();
					}
				}
			},
			validation.getValidationProps(disabled, elementProps),
			getButtonProps
		],
		stateAttributesMapping: triggerStateAttributesMapping
	});
});
ComboboxTrigger.displayName = "ComboboxTrigger";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/chips/ComboboxChipsContext.mjs
var ComboboxChipsContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxChipsContext.displayName = "ComboboxChipsContext";
function useComboboxChipsContext() {
	return import_react.useContext(ComboboxChipsContext);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/positioner/ComboboxPositionerContext.mjs
var ComboboxPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxPositionerContext.displayName = "ComboboxPositionerContext";
function useComboboxPositionerContext(optional) {
	const context = import_react.useContext(ComboboxPositionerContext);
	if (context === void 0 && !optional) throw new Error("Base UI: <Combobox.Popup> and <Combobox.Arrow> must be used within the <Combobox.Positioner> component");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/utils/ComboboxInternalDismissButton.mjs
/**
* @internal
*/
var ComboboxInternalDismissButton = /*#__PURE__*/ import_react.forwardRef(function ComboboxInternalDismissButton(_, forwardedRef) {
	const store = useComboboxRootContext();
	const { buttonRef, getButtonProps } = useButton({ native: false });
	const mergedRef = useMergedRefs(forwardedRef, buttonRef);
	function handleDismiss(event) {
		store.state.setOpen(false, createChangeEventDetails(closePress, event.nativeEvent, event.currentTarget));
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
		ref: mergedRef,
		...getButtonProps({ onClick: handleDismiss }),
		"aria-label": "Dismiss",
		tabIndex: void 0,
		style: visuallyHiddenInput
	});
});
ComboboxInternalDismissButton.displayName = "ComboboxInternalDismissButton";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/input/ComboboxInput.mjs
/**
* A text input to search for items in the list.
* Renders an `<input>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxInput = /*#__PURE__*/ import_react.forwardRef(function ComboboxInput(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp = false, id: idProp, style, ...elementProps } = componentProps;
	const { state: fieldState, disabled: fieldDisabled, setTouched, setFocused, validationMode, validation } = useFieldRootContext();
	const { labelId: fieldLabelId } = useLabelableContext();
	const comboboxChipsContext = useComboboxChipsContext();
	const positioning = useComboboxPositionerContext(true);
	const hasPositionerParent = Boolean(positioning);
	const store = useComboboxRootContext();
	const inputValue = useComboboxInputValueContext();
	const direction = useDirection();
	const required = useStore(store, selectors.required);
	const comboboxDisabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const name = useStore(store, selectors.name);
	const form = useStore(store, selectors.form);
	const selectionMode = useStore(store, selectors.selectionMode);
	const autoHighlightMode = useStore(store, selectors.autoHighlight);
	const inputProps = useStore(store, selectors.inputProps);
	const triggerProps = useStore(store, selectors.triggerProps);
	const open = useStore(store, selectors.open);
	const mounted = useStore(store, selectors.mounted);
	const selectedValue = useStore(store, selectors.selectedValue);
	const rootId = useStore(store, selectors.id);
	const inline = useStore(store, selectors.inline);
	const modal = useStore(store, selectors.modal);
	const autoHighlightEnabled = Boolean(autoHighlightMode);
	const popupSide = usePopupSide(store);
	const disabled = fieldDisabled || comboboxDisabled || disabledProp;
	const listEmpty = useListEmpty();
	const isInsidePopup = hasPositionerParent || inline;
	const focusManagerModal = !isInsidePopup || modal;
	const id = useBaseUiId(idProp ?? (!isInsidePopup ? rootId : void 0));
	const fieldStateForInput = hasPositionerParent ? DEFAULT_FIELD_STATE_ATTRIBUTES : fieldState;
	const [composingValue, setComposingValue] = import_react.useState(null);
	const isComposingRef = import_react.useRef(false);
	const lastActiveIndexRef = import_react.useRef(null);
	const shouldRestoreActiveIndexRef = import_react.useRef(false);
	const inputOwnsFormValue = selectionMode === "none" && !hasPositionerParent;
	const setInputElement = useStableCallback((element) => {
		const nextIsInsidePopup = hasPositionerParent || store.state.inline;
		if (nextIsInsidePopup && !store.state.hasInputValue) store.state.setInputValue("", createChangeEventDetails(none));
		store.update({
			inputElement: element,
			inputInsidePopup: nextIsInsidePopup,
			inputOwnsFormValue
		});
	});
	const validationProps = hasPositionerParent ? elementProps : validation.getValidationProps(disabled, elementProps);
	function clearHighlight() {
		store.state.setIndices({
			activeIndex: null,
			selectedIndex: null,
			type: store.state.keyboardActiveRef.current ? keyboard : pointer
		});
	}
	function markPointerActive() {
		store.state.keyboardActiveRef.current = false;
	}
	const state = {
		...fieldStateForInput,
		open,
		disabled,
		readOnly,
		popupSide,
		listEmpty
	};
	function handleKeyDown(event) {
		if (!comboboxChipsContext) return;
		let nextIndex;
		const { highlightedChipIndex } = comboboxChipsContext;
		const renderedChipsCount = comboboxChipsContext.chipsRef.current.length;
		const [previousChipKey, nextChipKey] = getChipNavigationKeys(direction);
		if (highlightedChipIndex !== void 0) {
			if (event.key === previousChipKey) {
				event.preventDefault();
				if (highlightedChipIndex > 0) nextIndex = highlightedChipIndex - 1;
				else nextIndex = void 0;
			} else if (event.key === nextChipKey) {
				event.preventDefault();
				if (highlightedChipIndex < renderedChipsCount - 1) nextIndex = highlightedChipIndex + 1;
				else nextIndex = void 0;
			} else if (event.key === "Backspace" || event.key === "Delete") {
				event.preventDefault();
				nextIndex = getIndexAfterChipRemoval(highlightedChipIndex, selectedValue.length);
				clearHighlight();
			}
			return nextIndex;
		}
		if (event.key === previousChipKey && (event.currentTarget.selectionStart ?? 0) === 0 && selectedValue.length > 0) {
			event.preventDefault();
			nextIndex = renderedChipsCount > 0 ? renderedChipsCount - 1 : void 0;
		}
		return nextIndex;
	}
	const element = useRenderElement("input", componentProps, {
		state,
		ref: [
			forwardedRef,
			store.state.inputRef,
			setInputElement
		],
		props: [
			inputProps,
			triggerProps,
			{
				value: composingValue ?? inputValue,
				"aria-readonly": readOnly || void 0,
				"aria-required": required || void 0,
				"aria-labelledby": fieldLabelId,
				disabled,
				readOnly,
				required: selectionMode === "none" ? required : void 0,
				form,
				...inputOwnsFormValue && name && { name },
				id,
				onFocus() {
					setFocused(true);
					if (!inline || !shouldRestoreActiveIndexRef.current) return;
					shouldRestoreActiveIndexRef.current = false;
					const nextActiveIndex = lastActiveIndexRef.current;
					if (nextActiveIndex == null || !Object.hasOwn(store.state.valuesRef.current, nextActiveIndex)) return;
					store.state.setIndices({ activeIndex: nextActiveIndex });
				},
				onBlur() {
					setTouched(true);
					setFocused(false);
					const activeIndex = store.state.activeIndex;
					if (inline && activeIndex !== null && autoHighlightMode !== "always") {
						lastActiveIndexRef.current = activeIndex;
						shouldRestoreActiveIndexRef.current = true;
						store.state.setIndices({ activeIndex: null });
					}
					if (validationMode === "onBlur") {
						const valueToValidate = selectionMode === "none" ? inputValue : selectedValue;
						validation.commit(valueToValidate);
					}
				},
				onCompositionStart(event) {
					if (android) return;
					isComposingRef.current = true;
					setComposingValue(event.currentTarget.value);
				},
				onCompositionEnd(event) {
					isComposingRef.current = false;
					const next = event.currentTarget.value;
					setComposingValue(null);
					store.state.setInputValue(next, createChangeEventDetails(inputChange, event.nativeEvent));
				},
				onChange(event) {
					const nativeEvent = event.nativeEvent;
					const inputType = nativeEvent.inputType;
					const autofillLikeInput = !inputType || inputType === "insertReplacementText";
					const shouldOpenOnInput = isComposingRef.current || !autofillLikeInput;
					function maybeOpenOnInput(trimmed) {
						if (readOnly || disabled || !trimmed || !shouldOpenOnInput) return;
						store.state.setOpen(true, createChangeEventDetails(inputChange, nativeEvent));
						if (!autoHighlightEnabled) clearHighlight();
					}
					if (isComposingRef.current) {
						const nextVal = event.currentTarget.value;
						setComposingValue(nextVal);
						if (nextVal === "" && !store.state.openOnInputClick && !store.state.inputInsidePopup) store.state.setOpen(false, createChangeEventDetails(inputClear, nativeEvent));
						const trimmed = nextVal.trim();
						const shouldMaintainHighlight = autoHighlightEnabled && trimmed !== "";
						maybeOpenOnInput(trimmed);
						if (open && store.state.activeIndex !== null && !shouldMaintainHighlight) clearHighlight();
						return;
					}
					const inputChangeDetails = createChangeEventDetails(inputChange, nativeEvent);
					store.state.setInputValue(event.currentTarget.value, inputChangeDetails);
					if (inputChangeDetails.isCanceled) return;
					const empty = event.currentTarget.value === "";
					const clearDetails = createChangeEventDetails(inputClear, nativeEvent);
					if (empty && !store.state.inputInsidePopup) {
						if (selectionMode === "single") store.state.setSelectedValue(null, clearDetails);
						if (!store.state.openOnInputClick) store.state.setOpen(false, clearDetails);
					}
					maybeOpenOnInput(event.currentTarget.value.trim());
					if (open && store.state.activeIndex !== null && !autoHighlightEnabled) clearHighlight();
				},
				onKeyDown(event) {
					if (disabled || readOnly) return;
					if (event.ctrlKey || event.shiftKey || event.altKey || event.metaKey) return;
					store.state.keyboardActiveRef.current = true;
					const input = event.currentTarget;
					const scrollAmount = input.scrollWidth - input.clientWidth;
					const isRTL = direction === "rtl";
					if (event.key === "Home") {
						stopEvent(event);
						const cursor = gecko && isRTL ? input.value.length : 0;
						input.setSelectionRange(cursor, cursor);
						input.scrollLeft = 0;
						return;
					}
					if (event.key === "End") {
						stopEvent(event);
						const cursor = gecko && isRTL ? 0 : input.value.length;
						input.setSelectionRange(cursor, cursor);
						input.scrollLeft = isRTL ? -scrollAmount : scrollAmount;
						return;
					}
					if (!mounted && event.key === "Escape") {
						const isClear = selectionMode === "multiple" && Array.isArray(selectedValue) ? selectedValue.length === 0 : selectedValue === null;
						const details = createChangeEventDetails(escapeKey, event.nativeEvent);
						const value = selectionMode === "multiple" ? [] : null;
						store.state.setInputValue("", details);
						store.state.setSelectedValue(value, details);
						if (!isClear && !store.state.inline && !details.isPropagationAllowed) event.stopPropagation();
						return;
					}
					if (comboboxChipsContext && event.key === "Backspace" && input.value === "" && comboboxChipsContext.highlightedChipIndex === void 0 && Array.isArray(selectedValue) && selectedValue.length > 0) {
						const renderedChipsCount = comboboxChipsContext.chipsRef.current.length;
						const removalIndex = renderedChipsCount > 0 ? renderedChipsCount - 1 : selectedValue.length - 1;
						const newValue = selectedValue.filter((_, index) => index !== removalIndex);
						clearHighlight();
						store.state.setSelectedValue(newValue, createChangeEventDetails(none, event.nativeEvent));
						return;
					}
					const hadHighlightedChip = comboboxChipsContext?.highlightedChipIndex !== void 0;
					const nextIndex = handleKeyDown(event);
					comboboxChipsContext?.setHighlightedChipIndex(nextIndex);
					if (nextIndex !== void 0) comboboxChipsContext?.chipsRef.current[nextIndex]?.focus();
					else if (hadHighlightedChip) store.state.inputRef.current?.focus();
					if (event.which === 229) return;
					if (event.key === "Enter" && open) {
						const activeIndex = store.state.activeIndex;
						const nativeEvent = event.nativeEvent;
						if (activeIndex === null) {
							if (inline) return;
							store.state.setOpen(false, createChangeEventDetails(none, nativeEvent));
							return;
						}
						stopEvent(event);
						clickHighlightedItem(store, activeIndex, nativeEvent);
					}
				},
				onPointerMove: markPointerActive,
				onPointerDown: markPointerActive
			},
			validationProps
		],
		stateAttributesMapping: triggerStateAttributesMapping
	});
	const renderedInput = hasPositionerParent ? /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FieldRootContext.Provider, {
		value: DEFAULT_FIELD_ROOT_CONTEXT,
		children: element
	}) : element;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [open && focusManagerModal && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxInternalDismissButton, { ref: store.state.startDismissRef }), renderedInput] });
});
ComboboxInput.displayName = "ComboboxInput";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/utils/handleInputPress.mjs
function handleInputPress(event, store, disabled, readOnly, shouldIgnoreTarget) {
	if (event.baseUIHandlerPrevented || readOnly) return;
	const target = getTarget(event.nativeEvent);
	const targetElement = isElement(target) ? target : null;
	if (targetElement !== event.currentTarget && (shouldIgnoreTarget?.(targetElement) || isInteractiveElement(targetElement))) return;
	event.preventDefault();
	if (disabled) return;
	store.state.inputRef.current?.focus();
	if (store.state.openOnInputClick) store.state.setOpen(true, createChangeEventDetails(inputPress, event.nativeEvent));
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/input-group/ComboboxInputGroup.mjs
/**
* A wrapper for the input and its associated controls.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxInputGroup = /*#__PURE__*/ import_react.forwardRef(function ComboboxInputGroup(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { state: fieldState } = useFieldRootContext();
	const store = useComboboxRootContext();
	const open = useStore(store, selectors.open);
	const comboboxDisabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const hasSelectedValue = useStore(store, selectors.hasSelectedValue);
	const selectionMode = useStore(store, selectors.selectionMode);
	const popupSide = usePopupSide(store);
	const disabled = comboboxDisabled;
	const listEmpty = useListEmpty();
	const placeholder = selectionMode === "none" ? false : !hasSelectedValue;
	const state = {
		...fieldState,
		open,
		disabled,
		readOnly,
		popupSide,
		listEmpty,
		placeholder
	};
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, useStableCallback((element) => {
			store.set("inputGroupElement", element);
		})],
		props: [{
			role: "group",
			onMouseDown(event) {
				handleInputPress(event, store, disabled, readOnly, (target) => {
					return contains(store.state.chipsContainerRef.current, target);
				});
			}
		}, elementProps],
		state,
		stateAttributesMapping: triggerStateAttributesMapping
	});
});
ComboboxInputGroup.displayName = "ComboboxInputGroup";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/icon/ComboboxIcon.mjs
/**
* An icon that indicates that the trigger button opens the popup.
* Renders a `<span>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxIcon = /*#__PURE__*/ import_react.forwardRef(function ComboboxIcon(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	return useRenderElement("span", componentProps, {
		ref: forwardedRef,
		props: [{
			"aria-hidden": true,
			children: "▼"
		}, elementProps]
	});
});
ComboboxIcon.displayName = "ComboboxIcon";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/clear/ComboboxClear.mjs
var stateAttributesMapping$2 = {
	...transitionStatusMapping,
	...triggerOpenStateMapping
};
/**
* Clears the value when clicked.
* Renders a `<button>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxClear = /*#__PURE__*/ import_react.forwardRef(function ComboboxClear(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp = false, nativeButton = true, keepMounted = false, style, ...elementProps } = componentProps;
	const { disabled: fieldDisabled } = useFieldRootContext();
	const store = useComboboxRootContext();
	const selectionMode = useStore(store, selectors.selectionMode);
	const comboboxDisabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const open = useStore(store, selectors.open);
	const selectedValue = useStore(store, selectors.selectedValue);
	const hasSelectionChips = useStore(store, selectors.hasSelectionChips);
	const inputValue = useComboboxInputValueContext();
	let visible = false;
	if (selectionMode === "none") visible = inputValue !== "";
	else if (selectionMode === "single") visible = selectedValue != null;
	else visible = hasSelectionChips;
	const disabled = fieldDisabled || comboboxDisabled || disabledProp;
	const { buttonRef, getButtonProps } = useButton({
		native: nativeButton,
		disabled
	});
	const { mounted, transitionStatus, setMounted } = useTransitionStatus(visible);
	const state = {
		disabled,
		visible,
		open,
		transitionStatus
	};
	useOpenChangeComplete({
		open: visible,
		ref: store.state.clearRef,
		onComplete() {
			if (!visible) setMounted(false);
		}
	});
	const element = useRenderElement("button", componentProps, {
		state,
		ref: [
			forwardedRef,
			buttonRef,
			store.state.clearRef
		],
		props: [
			{
				tabIndex: -1,
				children: "x",
				onMouseDown(event) {
					event.preventDefault();
				},
				onClick(event) {
					if (disabled || readOnly) return;
					const type = store.state.keyboardActiveRef.current ? keyboard : pointer;
					store.state.setInputValue("", createChangeEventDetails(clearPress, event.nativeEvent));
					if (selectionMode !== "none") {
						store.state.setSelectedValue(Array.isArray(selectedValue) ? [] : null, createChangeEventDetails(clearPress, event.nativeEvent));
						store.state.setIndices({
							activeIndex: null,
							selectedIndex: null,
							type
						});
					} else store.state.setIndices({
						activeIndex: null,
						type
					});
					store.state.inputRef.current?.focus();
				}
			},
			elementProps,
			getButtonProps
		],
		stateAttributesMapping: stateAttributesMapping$2
	});
	if (!(keepMounted || mounted)) return null;
	return element;
});
ComboboxClear.displayName = "ComboboxClear";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/collection/GroupCollectionContext.mjs
var GroupCollectionContext = /*#__PURE__*/ import_react.createContext(null);
GroupCollectionContext.displayName = "GroupCollectionContext";
function useGroupCollectionContext() {
	return import_react.useContext(GroupCollectionContext);
}
function GroupCollectionProvider(props) {
	const { children, items } = props;
	const contextValue = import_react.useMemo(() => ({ items }), [items]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(GroupCollectionContext.Provider, {
		value: contextValue,
		children
	});
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/collection/ComboboxCollection.mjs
/**
* Renders filtered list items.
* Doesn't render its own HTML element.
*
* If rendering a flat list, pass a function child to the `List` component instead, which implicitly wraps it.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
function ComboboxCollection(props) {
	const { children } = props;
	const { filteredItems } = useComboboxDerivedItemsContext();
	const groupContext = useGroupCollectionContext();
	const itemsToRender = groupContext ? groupContext.items : filteredItems;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: itemsToRender.map(children) });
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/list/ComboboxList.mjs
/**
* A list container for the items.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxList = /*#__PURE__*/ import_react.forwardRef(function ComboboxList(componentProps, forwardedRef) {
	var _ComboboxCollection;
	const { render, className, style, children, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const floatingRootContext = useComboboxFloatingContext();
	const hasPositionerContext = Boolean(useComboboxPositionerContext(true));
	const { filteredItems, hasItems } = useComboboxDerivedItemsContext();
	const selectionMode = useStore(store, selectors.selectionMode);
	const grid = useStore(store, selectors.grid);
	const listProps = useStore(store, selectors.listProps);
	const virtualized = useStore(store, selectors.virtualized);
	const forceMounted = useStore(store, selectors.forceMounted);
	const multiple = selectionMode === "multiple";
	const empty = filteredItems.length === 0;
	const setPositionerElement = useStableCallback((element) => {
		store.set("positionerElement", element);
	});
	const setListElement = useStableCallback((element) => {
		store.set("listElement", element);
	});
	const resolvedChildren = import_react.useMemo(() => {
		if (typeof children === "function") return _ComboboxCollection || (_ComboboxCollection = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxCollection, { children }));
		return children;
	}, [children]);
	const state = { empty };
	const floatingId = floatingRootContext.useState("floatingId");
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [
			forwardedRef,
			setListElement,
			hasPositionerContext ? null : setPositionerElement
		],
		props: [
			listProps,
			{
				children: resolvedChildren,
				tabIndex: -1,
				id: floatingId,
				role: grid ? "grid" : "listbox",
				"aria-multiselectable": multiple ? "true" : void 0,
				onKeyDown(event) {
					if (store.state.disabled || store.state.readOnly) return;
					if (event.key === "Enter") {
						const activeIndex = store.state.activeIndex;
						if (activeIndex == null) return;
						stopEvent(event);
						clickHighlightedItem(store, activeIndex, event.nativeEvent);
					}
				},
				onKeyDownCapture() {
					store.state.keyboardActiveRef.current = true;
				},
				onPointerMoveCapture() {
					store.state.keyboardActiveRef.current = false;
				}
			},
			elementProps
		]
	});
	if (virtualized) return element;
	const labelsRef = hasItems && !forceMounted ? void 0 : store.state.labelsRef;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
		elementsRef: store.state.listRef,
		labelsRef,
		children: element
	});
});
ComboboxList.displayName = "ComboboxList";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/utils/useInitialLiveRegionTextMutation.mjs
var LIVE_REGION_MARKER = "⁠";
function findLastTextNode(root) {
	const walker = root.ownerDocument.createTreeWalker(root, NodeFilter.SHOW_TEXT);
	let lastTextNode = null;
	while (walker.nextNode()) {
		const textNode = walker.currentNode;
		if (textNode.nodeValue !== "") lastTextNode = textNode;
	}
	return lastTextNode;
}
function useInitialLiveRegionTextMutation() {
	const timeout = useTimeout();
	const rootRef = import_react.useRef(null);
	import_react.useEffect(() => {
		if (ios) return;
		const root = rootRef.current;
		if (root == null) return;
		const textNode = findLastTextNode(root);
		if (textNode == null) return;
		const originalValue = textNode.data;
		const markedValue = `${originalValue}${LIVE_REGION_MARKER}`;
		textNode.nodeValue = markedValue;
		timeout.start(200, () => {
			if (textNode.nodeValue === markedValue) textNode.nodeValue = originalValue;
		});
		return () => {
			timeout.clear();
			if (textNode.nodeValue === markedValue) textNode.nodeValue = originalValue;
		};
	}, [rootRef, timeout]);
	return rootRef;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/status/ComboboxStatus.mjs
/**
* Displays a status message whose content changes are announced politely to screen readers.
* Useful for conveying the status of an asynchronously loaded list.
* This component's root element must remain mounted in the DOM to announce
* changes consistently across screen readers. Avoid hiding or removing the
* component itself with `display: none`, `hidden`, `aria-hidden`, or conditional
* rendering. Prefer updating or conditionally rendering its children instead.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxStatus = /*#__PURE__*/ import_react.forwardRef(function ComboboxStatus(componentProps, forwardedRef) {
	const { render, className, style, children: childrenProp, ...elementProps } = componentProps;
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, useInitialLiveRegionTextMutation()],
		props: [{
			children: childrenProp,
			role: "status",
			"aria-live": "polite",
			"aria-atomic": true
		}, elementProps]
	});
});
ComboboxStatus.displayName = "ComboboxStatus";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/portal/ComboboxPortalContext.mjs
var ComboboxPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxPortalContext.displayName = "ComboboxPortalContext";
function useComboboxPortalContext() {
	const context = import_react.useContext(ComboboxPortalContext);
	if (context === void 0) throw new Error("Base UI: <Combobox.Portal> is missing.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/portal/ComboboxPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxPortal = /*#__PURE__*/ import_react.forwardRef(function ComboboxPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	const store = useComboboxRootContext();
	const mounted = useStore(store, selectors.mounted);
	const forceMounted = useStore(store, selectors.forceMounted);
	if (!(mounted || keepMounted || forceMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps
		})
	});
});
ComboboxPortal.displayName = "ComboboxPortal";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/backdrop/ComboboxBackdrop.mjs
var stateAttributesMapping$1 = {
	...popupStateMapping,
	...transitionStatusMapping
};
/**
* An overlay displayed beneath the popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxBackdrop = /*#__PURE__*/ import_react.forwardRef(function ComboboxBackdrop(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const open = useStore(store, selectors.open);
	const mounted = useStore(store, selectors.mounted);
	return useRenderElement("div", componentProps, {
		state: {
			open,
			transitionStatus: useStore(store, selectors.transitionStatus)
		},
		ref: forwardedRef,
		stateAttributesMapping: stateAttributesMapping$1,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps]
	});
});
ComboboxBackdrop.displayName = "ComboboxBackdrop";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/positioner/ComboboxPositioner.mjs
/**
* Positions the popup against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxPositioner = /*#__PURE__*/ import_react.forwardRef(function ComboboxPositioner(componentProps, forwardedRef) {
	const { render, className, anchor, positionMethod, side, align, sideOffset, alignOffset, collisionBoundary = "clipping-ancestors", collisionPadding, arrowPadding, sticky, disableAnchorTracking = false, collisionAvoidance = DROPDOWN_COLLISION_AVOIDANCE, style: styleProp, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const floatingRootContext = useComboboxFloatingContext();
	const keepMounted = useComboboxPortalContext();
	const modal = useStore(store, selectors.modal);
	const open = useStore(store, selectors.open);
	const mounted = useStore(store, selectors.mounted);
	const openMethod = useStore(store, selectors.openMethod);
	const positionerElement = useStore(store, selectors.positionerElement);
	const triggerElement = useStore(store, selectors.triggerElement);
	const inputElement = useStore(store, selectors.inputElement);
	const inputGroupElement = useStore(store, selectors.inputGroupElement);
	const inputInsidePopup = useStore(store, selectors.inputInsidePopup);
	const transitionStatus = useStore(store, selectors.transitionStatus);
	const empty = useListEmpty();
	const positioning = useAnchorPositioning({
		anchor: anchor ?? (inputInsidePopup ? triggerElement : inputGroupElement ?? inputElement),
		floatingRootContext,
		positionMethod,
		mounted,
		side,
		sideOffset,
		align,
		alignOffset,
		arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		disableAnchorTracking,
		keepMounted,
		collisionAvoidance,
		lazyFlip: true
	});
	useAnchoredPopupScrollLock(open && modal, openMethod === "touch", positionerElement, triggerElement);
	const state = {
		open,
		side: positioning.side,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden,
		empty
	};
	useIsoLayoutEffect(() => {
		store.set("popupSide", positioning.side);
	}, [store, positioning.side]);
	const setPositionerElement = useStableCallback((element) => {
		store.set("positionerElement", element);
	});
	const element = usePositioner(componentProps, state, {
		styles: positioning.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, setPositionerElement],
		hidden: !mounted,
		inert: !open
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(ComboboxPositionerContext.Provider, {
		value: positioning,
		children: [mounted && modal && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
			inert: inertValue(!open),
			cutout: inputGroupElement ?? inputElement ?? triggerElement
		}), element]
	});
});
ComboboxPositioner.displayName = "ComboboxPositioner";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/popup/ComboboxPopup.mjs
var stateAttributesMapping = {
	...popupStateMapping,
	...transitionStatusMapping
};
/**
* A container for the list.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxPopup = /*#__PURE__*/ import_react.forwardRef(function ComboboxPopup(componentProps, forwardedRef) {
	const { render, className, style, initialFocus, finalFocus, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const positioning = useComboboxPositionerContext();
	const floatingRootContext = useComboboxFloatingContext();
	const mounted = useStore(store, selectors.mounted);
	const open = useStore(store, selectors.open);
	const openMethod = useStore(store, selectors.openMethod);
	const popupProps = useStore(store, selectors.popupProps);
	const transitionStatus = useStore(store, selectors.transitionStatus);
	const inputInsidePopup = useStore(store, selectors.inputInsidePopup);
	const inputElement = useStore(store, selectors.inputElement);
	const modal = useStore(store, selectors.modal);
	const rootId = useStore(store, selectors.id);
	const empty = useListEmpty();
	const popupId = elementProps.id ?? (inputInsidePopup ? getComboboxPopupId(rootId) : void 0);
	useIsoLayoutEffect(() => {
		store.set("popupId", store.state.popupRef.current?.id || popupId);
		return () => {
			store.set("popupId", void 0);
		};
	}, [store, popupId]);
	useOpenChangeComplete({
		open,
		ref: store.state.popupRef,
		onComplete() {
			if (open) store.state.onOpenChangeComplete(true);
		}
	});
	const element = useRenderElement("div", componentProps, {
		state: {
			open,
			side: positioning.side,
			align: positioning.align,
			anchorHidden: positioning.anchorHidden,
			transitionStatus,
			empty
		},
		ref: [forwardedRef, store.state.popupRef],
		props: [
			popupProps,
			{
				id: popupId,
				role: inputInsidePopup ? "dialog" : "presentation",
				onFocus(event) {
					const target = getTarget(event.nativeEvent);
					if (openMethod !== "touch" && (contains(store.state.listElement, target) || target === event.currentTarget)) store.state.inputRef.current?.focus();
				}
			},
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps
		],
		stateAttributesMapping
	});
	const resolvedInitialFocus = initialFocus === void 0 ? inputInsidePopup ? (interactionType) => interactionType === "touch" ? store.state.popupRef.current : inputElement : false : initialFocus;
	let resolvedFinalFocus;
	if (finalFocus != null) resolvedFinalFocus = finalFocus;
	else resolvedFinalFocus = inputInsidePopup ? void 0 : false;
	const focusManagerModal = !inputInsidePopup || modal;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingRootContext,
		disabled: !mounted,
		modal: focusManagerModal,
		openInteractionType: openMethod,
		initialFocus: resolvedInitialFocus,
		returnFocus: resolvedFinalFocus,
		getInsideElements: () => [store.state.startDismissRef.current, store.state.endDismissRef.current],
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [element, focusManagerModal && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxInternalDismissButton, { ref: store.state.endDismissRef })] })
	});
});
ComboboxPopup.displayName = "ComboboxPopup";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/arrow/ComboboxArrow.mjs
/**
* Displays an element positioned against the anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxArrow = /*#__PURE__*/ import_react.forwardRef(function ComboboxArrow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const { arrowRef, side, align, arrowUncentered, arrowStyles } = useComboboxPositionerContext();
	const state = {
		open: useStore(store, selectors.open),
		side,
		align,
		uncentered: arrowUncentered
	};
	return useRenderElement("div", componentProps, {
		ref: [arrowRef, forwardedRef],
		stateAttributesMapping: popupStateMapping,
		state,
		props: {
			style: arrowStyles,
			"aria-hidden": true,
			...elementProps
		}
	});
});
ComboboxArrow.displayName = "ComboboxArrow";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/group/ComboboxGroupContext.mjs
var ComboboxGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxGroupContext.displayName = "ComboboxGroupContext";
function useComboboxGroupContext() {
	const context = import_react.useContext(ComboboxGroupContext);
	if (context === void 0) throw new Error("Base UI: ComboboxGroupContext is missing. ComboboxGroup parts must be placed within <Combobox.Group>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/group/ComboboxGroup.mjs
/**
* Groups related items with the corresponding label.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxGroup = /*#__PURE__*/ import_react.forwardRef(function ComboboxGroup(componentProps, forwardedRef) {
	const { render, className, style, items, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState();
	const contextValue = import_react.useMemo(() => ({
		labelId,
		setLabelId,
		items
	}), [
		labelId,
		setLabelId,
		items
	]);
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: [{
			role: "group",
			"aria-labelledby": labelId
		}, elementProps]
	});
	const wrappedElement = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxGroupContext.Provider, {
		value: contextValue,
		children: element
	});
	if (items) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(GroupCollectionProvider, {
		items,
		children: wrappedElement
	});
	return wrappedElement;
});
ComboboxGroup.displayName = "ComboboxGroup";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/group-label/ComboboxGroupLabel.mjs
/**
* An accessible label that is automatically associated with its parent group.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxGroupLabel = /*#__PURE__*/ import_react.forwardRef(function ComboboxGroupLabel(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const { setLabelId } = useComboboxGroupContext();
	const id = useBaseUiId(idProp);
	useIsoLayoutEffect(() => {
		setLabelId(id);
		return () => {
			setLabelId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [id, setLabelId]);
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
ComboboxGroupLabel.displayName = "ComboboxGroupLabel";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/item/ComboboxItemContext.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var ComboboxItemContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxItemContext.displayName = "ComboboxItemContext";
function useComboboxItemContext() {
	const context = import_react.useContext(ComboboxItemContext);
	if (!context) throw new Error("Base UI: ComboboxItemContext is missing. ComboboxItem parts must be placed within <Combobox.Item>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/row/ComboboxRowContext.mjs
var ComboboxRowContext = /*#__PURE__*/ import_react.createContext(false);
ComboboxRowContext.displayName = "ComboboxRowContext";
function useComboboxRowContext() {
	return import_react.useContext(ComboboxRowContext);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/item/ComboboxItem.mjs
function ComboboxItemInner(props) {
	const { componentProps, forwardedRef, virtualized, indexFromFilter } = props;
	const { render, className, style, value: itemValue = null, index: indexProp, disabled: disabledProp = false, nativeButton = false, ...elementProps } = componentProps;
	const textRef = import_react.useRef(null);
	const listItem = useCompositeListItem({
		guess: true,
		index: indexProp,
		textRef
	});
	const store = useComboboxRootContext();
	const isRow = useComboboxRowContext();
	const hasItems = useComboboxHasItemsContext();
	const selectionMode = useStore(store, selectors.selectionMode);
	const rootDisabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const isItemEqualToValue = useStore(store, selectors.isItemEqualToValue);
	const disabled = rootDisabled || disabledProp;
	const selectable = selectionMode !== "none";
	const index = indexProp ?? indexFromFilter ?? listItem.index;
	const hasRegistered = index !== -1;
	const rootId = useStore(store, selectors.id);
	const highlighted = useStore(store, selectors.isActive, index);
	const matchesSelectedValue = useStore(store, selectors.isSelected, itemValue);
	const itemProps = useStore(store, selectors.itemProps);
	const itemRef = import_react.useRef(null);
	const id = rootId != null && hasRegistered ? `${rootId}-${index}` : void 0;
	const selected = matchesSelectedValue && selectable;
	useIsoLayoutEffect(() => {
		if (!(hasRegistered && (virtualized || indexProp != null))) return;
		const list = store.state.listRef.current;
		list[index] = itemRef.current;
		return () => {
			delete list[index];
		};
	}, [
		hasRegistered,
		virtualized,
		index,
		indexProp,
		store
	]);
	useIsoLayoutEffect(() => {
		if (!hasRegistered || hasItems) return;
		const visibleMap = store.state.valuesRef.current;
		visibleMap[index] = itemValue;
		return () => {
			delete visibleMap[index];
		};
	}, [
		hasRegistered,
		hasItems,
		index,
		itemValue,
		store
	]);
	useIsoLayoutEffect(() => {
		if (!hasRegistered || hasItems) return;
		const selectedValue = store.state.selectedValue;
		const lastSelectedValue = Array.isArray(selectedValue) ? selectedValue[selectedValue.length - 1] : selectedValue;
		if (compareItemEquality(itemValue, lastSelectedValue, isItemEqualToValue)) store.set("selectedIndex", index);
	}, [
		hasRegistered,
		hasItems,
		store,
		index,
		itemValue,
		isItemEqualToValue
	]);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		focusableWhenDisabled: true,
		native: nativeButton,
		composite: true
	});
	const state = {
		disabled,
		selected,
		highlighted
	};
	function commitSelection(nativeEvent) {
		function selectItem() {
			store.state.handleSelection(nativeEvent, itemValue);
		}
		if (store.state.submitOnItemClick) {
			import_react_dom.flushSync(selectItem);
			store.state.requestSubmit();
		} else selectItem();
	}
	const defaultProps = {
		id,
		role: isRow ? "gridcell" : "option",
		"aria-selected": selectable ? selected : void 0,
		tabIndex: void 0,
		onPointerDownCapture(event) {
			if (event.isPrimary) store.state.pointerDownItemRef.current = event.currentTarget;
			event.preventDefault();
		},
		onMouseDown(event) {
			event.preventDefault();
		},
		onClick(event) {
			if (disabled || readOnly) return;
			commitSelection(event.nativeEvent);
		},
		onMouseUp(event) {
			const pointerStartedOnItem = store.state.pointerDownItemRef.current === event.currentTarget;
			store.state.pointerDownItemRef.current = null;
			if (disabled || readOnly || event.button !== 0 || pointerStartedOnItem || !highlighted) return;
			commitSelection(event.nativeEvent);
		}
	};
	const element = useRenderElement("div", componentProps, {
		ref: [
			buttonRef,
			forwardedRef,
			listItem.ref,
			itemRef
		],
		state,
		props: [
			itemProps,
			defaultProps,
			elementProps,
			getButtonProps
		]
	});
	const contextValue = import_react.useMemo(() => ({
		selected,
		textRef
	}), [selected, textRef]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxItemContext.Provider, {
		value: contextValue,
		children: element
	});
}
/**
* Resolves the index from the filtered items for the virtualized fallback (no `index` prop).
* Isolated here so that this per-keystroke subscription to the derived-items context is only
* paid by virtualized items. Those re-render on every input change anyway — the parent
* virtualizer re-windows the list as the filtered set changes — so the extra subscription costs
* them nothing, while it keeps every non-virtualized item off that context.
*/
function ComboboxItemVirtualizedIndex(props) {
	const { componentProps, forwardedRef } = props;
	const isItemEqualToValue = useStore(useComboboxRootContext(), selectors.isItemEqualToValue);
	const { flatFilteredItems } = useComboboxDerivedItemsContext();
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxItemInner, {
		componentProps,
		forwardedRef,
		virtualized: true,
		indexFromFilter: findItemIndex(flatFilteredItems, componentProps.value ?? null, isItemEqualToValue)
	});
}
/**
* An individual item in the list.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxItem = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(function ComboboxItem(componentProps, forwardedRef) {
	const virtualized = useStore(useComboboxRootContext(), selectors.virtualized);
	if (virtualized && componentProps.index == null) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxItemVirtualizedIndex, {
		componentProps,
		forwardedRef
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxItemInner, {
		componentProps,
		forwardedRef,
		virtualized,
		indexFromFilter: void 0
	});
}));
ComboboxItem.displayName = "ComboboxItem";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/row/ComboboxRow.mjs
/**
* Displays a single row of items in a grid list.
* Enable `grid` on the root component to turn the listbox into a grid.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxRow = /*#__PURE__*/ import_react.forwardRef(function ComboboxRow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: [{ role: "row" }, elementProps]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxRowContext.Provider, {
		value: true,
		children: element
	});
});
ComboboxRow.displayName = "ComboboxRow";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/empty/ComboboxEmpty.mjs
/**
* Renders its children only when the list is empty.
* Requires the `items` prop on the root component.
* Announces changes politely to screen readers.
* This component's root element must remain mounted in the DOM to announce
* changes consistently across screen readers. Avoid hiding or removing the
* component itself with `display: none`, `hidden`, `aria-hidden`, or conditional
* rendering. Prefer updating or conditionally rendering its children instead.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxEmpty = /*#__PURE__*/ import_react.forwardRef(function ComboboxEmpty(componentProps, forwardedRef) {
	const { render, className, style, children: childrenProp, ...elementProps } = componentProps;
	const { filteredItems } = useComboboxDerivedItemsContext();
	const store = useComboboxRootContext();
	const emptyRef = useInitialLiveRegionTextMutation();
	const children = filteredItems.length === 0 ? childrenProp : null;
	return useRenderElement("div", componentProps, {
		ref: [
			forwardedRef,
			store.state.emptyRef,
			emptyRef
		],
		props: [{
			children,
			role: "status",
			"aria-live": "polite",
			"aria-atomic": true
		}, elementProps]
	});
});
ComboboxEmpty.displayName = "ComboboxEmpty";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/utils/useFilteredItems.mjs
/**
* Returns the internally filtered items.
*/
function useFilteredItems() {
	return useComboboxDerivedItemsContext().filteredItems;
}
//#endregion
export { useComboboxInputValueContext as A, ComboboxTrigger as C, useComboboxFilter as D, AriaCombobox as E, useCoreFilter as O, useComboboxChipsContext as S, getIndexAfterChipRemoval as T, ComboboxIcon as _, useComboboxItemContext as a, ComboboxInput as b, ComboboxArrow as c, ComboboxBackdrop as d, ComboboxPortal as f, ComboboxClear as g, ComboboxCollection as h, ComboboxItem as i, useComboboxRootContext as j, selectors as k, ComboboxPopup as l, ComboboxList as m, ComboboxEmpty as n, ComboboxGroupLabel as o, ComboboxStatus as p, ComboboxRow as r, ComboboxGroup as s, useFilteredItems as t, ComboboxPositioner as u, ComboboxInputGroup as v, getChipNavigationKeys as w, ComboboxChipsContext as x, handleInputPress as y };
