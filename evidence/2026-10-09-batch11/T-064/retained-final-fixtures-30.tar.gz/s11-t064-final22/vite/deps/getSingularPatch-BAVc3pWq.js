import { $ as UNSAFE_CSS_ATTRIBUTE, A as DEFAULT_TOKENIZE_MAX_LENGTH, B as GIT_DIFF_FILE_BREAK_REGEX, C as DEFAULT_CODE_VIEW_FILE_METRICS, D as DEFAULT_RENDER_RANGE, E as DEFAULT_EXPANDED_REGION, F as DIFFS_TAG_NAME, G as INDEX_LINE_METADATA, H as HEADER_METADATA_SLOT_ID, I as EMPTY_RENDER_RANGE, L as FILENAME_HEADER_REGEX, M as DIFFS_DEVELOPMENT_BUILD, N as DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY, O as DEFAULT_SMOOTH_SCROLL_SETTINGS, P as DIFFS_SCROLLBAR_MEASURE_ATTRIBUTE, R as FILENAME_HEADER_REGEX_GIT, S as CUSTOM_HEADER_SLOT_ID, U as HEADER_PREFIX_SLOT_ID, V as HEADER_FILENAME_SUFFIX_SLOT_ID, X as SPLIT_WITH_NEWLINES, Z as THEME_CSS_ATTRIBUTE, _ as ALTERNATE_FILE_NAMES_GIT, a as linesFromFileContents, b as COMMIT_METADATA_SPLIT, g as queueRender, h as dequeueRender, j as DEFAULT_VIRTUAL_FILE_METRICS, k as DEFAULT_THEMES, n as isSafari, o as getLineAnnotationName, p as isGutterUtilityPath, u as getFiletypeFromFileName, v as CODE_VIEW_FOOTER_ATTRIBUTE, w as DEFAULT_CODE_VIEW_LAYOUT, y as CODE_VIEW_HEADER_ATTRIBUTE } from "./platform-vkp1Dvjb.js";
import { C as diffWordsWithSpace, S as createTwoFilesPatch, _ as createOnigurumaEngine, a as unwrapDefault, b as __reExport, c as createBundledHighlighter, d as createSingletonShorthands, g as engine_oniguruma_exports, h as normalizeTheme, i as createThemeResolver, n as transformerStyleToClass, o as createJavaScriptRegexEngine, p as guessEmbeddedLanguages, s as defaultJavaScriptRegexConstructor, t as normalizeThemeColors, v as loadWasm, w as diffChars, x as toHtml, y as __exportAll } from "./normalizeThemeColors-CKb5-BNW.js";
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areObjectsEqual.js
function areObjectsEqual(objA, objB, omitKeys) {
	if (objA === objB || objA == null || objB == null) return objA === objB;
	const omitSet = new Set(omitKeys);
	const keysA = Object.keys(objA);
	const keysBSet = new Set(Object.keys(objB));
	for (const key of keysA) {
		keysBSet.delete(key);
		if (omitSet.has(key)) continue;
		if (!(key in objB) || objA[key] !== objB[key]) return false;
	}
	for (const key of Array.from(keysBSet)) if (!omitSet.has(key)) return false;
	return true;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areThemesEqual.js
function areThemesEqual(themeA, themeB) {
	if (themeA == null || themeB == null || typeof themeA === "string" || typeof themeB === "string") return themeA === themeB;
	return themeA.dark === themeB.dark && themeA.light === themeB.light;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areOptionsEqual.js
function areOptionsEqual(optionsA, optionsB) {
	const themeA = optionsA?.theme ?? DEFAULT_THEMES;
	const themeB = optionsB?.theme ?? DEFAULT_THEMES;
	const diffOptsA = getParseDiffOptions(optionsA);
	const diffOptsB = getParseDiffOptions(optionsB);
	return areThemesEqual(themeA, themeB) && areObjectsEqual(optionsA, optionsB, ["theme", "parseDiffOptions"]) && areObjectsEqual(diffOptsA, diffOptsB);
}
function getParseDiffOptions(options) {
	if (options != null && "parseDiffOptions" in options) return options.parseDiffOptions;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areSelectionsEqual.js
function areSelectionsEqual(selectionA, selectionB) {
	return selectionA?.start === selectionB?.start && selectionA?.end === selectionB?.end && selectionA?.side === selectionB?.side && selectionA?.endSide === selectionB?.endSide;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createWindowFromScrollPosition.js
function createWindowFromScrollPosition({ scrollTop, scrollHeight, height, fitPerfectly = false, fitPerfectlyOverscroll = 0, overscrollSize }) {
	const windowHeight = height + overscrollSize * 2;
	const effectiveHeight = fitPerfectly ? height + fitPerfectlyOverscroll * 2 : windowHeight;
	scrollHeight = Math.max(scrollHeight, effectiveHeight);
	if (windowHeight >= scrollHeight || fitPerfectly) {
		const top = Math.max(scrollTop - fitPerfectlyOverscroll, 0);
		const bottom = Math.min(scrollTop + effectiveHeight, scrollHeight);
		return {
			top,
			bottom: Math.max(bottom, top)
		};
	}
	let top = scrollTop + height / 2 - windowHeight / 2;
	let bottom = top + windowHeight;
	if (top < 0) top = 0;
	if (bottom > scrollHeight) bottom = scrollHeight;
	top = Math.floor(Math.max(top, 0));
	return {
		top,
		bottom: Math.ceil(Math.max(Math.min(bottom, scrollHeight), top))
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/cleanLastNewline.js
function cleanLastNewline(contents) {
	let end = contents.length;
	if (contents.charCodeAt(end - 1) === 10) {
		end--;
		if (contents.charCodeAt(end - 1) === 13) end--;
	}
	return contents.slice(0, end);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/detachString.js
var stringDetachEncoder = new TextEncoder();
var stringDetachDecoder = new TextDecoder("utf-8", { ignoreBOM: true });
var SURROGATE_CODE_UNIT_PATTERN = /[\uD800-\uDFFF]/;
var STRING_DETACH_INITIAL_BUFFER_SIZE = 1024;
var stringDetachBuffer = new Uint8Array(STRING_DETACH_INITIAL_BUFFER_SIZE);
function releaseStringDetachBuffer() {
	if (stringDetachBuffer.length !== STRING_DETACH_INITIAL_BUFFER_SIZE) stringDetachBuffer = new Uint8Array(STRING_DETACH_INITIAL_BUFFER_SIZE);
}
function detachString(value) {
	if (value.length === 0) return value;
	if (SURROGATE_CODE_UNIT_PATTERN.test(value)) return JSON.parse(JSON.stringify(value));
	const requiredByteLength = value.length * 3;
	if (stringDetachBuffer.length < requiredByteLength) stringDetachBuffer = new Uint8Array(requiredByteLength);
	const { written } = stringDetachEncoder.encodeInto(value, stringDetachBuffer);
	return stringDetachDecoder.decode(stringDetachBuffer.subarray(0, written));
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getHunkSideBoundaries.js
/** Converts a unified hunk side's start/count into its consumed-file range. */
function getHunkSideStartBoundary(start, count) {
	return start - (count === 0 ? 0 : 1);
}
function getHunkSideEndBoundary(start, count) {
	return getHunkSideStartBoundary(start, count) + count;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/realignChangeContent.js
var MAX_ALIGNMENT_COMPARISONS = 4096;
var MIN_IMPROVEMENT_PER_PAIR = .5;
/**
* Re-split count-mismatched change blocks in every hunk so paired lines are
* chosen by content similarity instead of position, then slide blank-line
* insert/delete blocks to the top of their blank run. Mutates `hunks` in
* place; rendered row counts are unchanged (a split block covers the same
* split/unified rows as the original).
*/
function realignChangeContentBySimilarity(diff) {
	for (const hunk of diff.hunks) {
		for (let index = 0; index < hunk.hunkContent.length; index++) {
			const content = hunk.hunkContent[index];
			if (content.type !== "change") continue;
			const replacement = realignChangeBlock(diff, content);
			if (replacement != null) {
				hunk.hunkContent.splice(index, 1, ...replacement);
				index += replacement.length - 1;
			}
		}
		slideBlankBoundaryBlocksUp(hunk, diff);
	}
}
/**
* Slide pure insert/delete blocks made entirely of blank lines to the top of
* the blank run they sit in. Adding or removing a blank line next to
* existing blanks is ambiguous, and the diff library reports the change at
* the run's bottom — so pressing Enter at the end of a line marks a blank
* *below* the caret as inserted while the caret's own new line renders as
* context. Sliding up anchors the change to the content above it (the caret
* line after an Enter) instead.
*
* The slide is all-or-nothing: it only applies when the block comes to rest
* directly beneath remaining in-hunk content. A slide that would consume the
* hunk's entire leading context was stopped by the hunk's edge — a context
* window cut, not the top of the blank run — and that landing spot is
* arbitrary, so the block keeps the library's bottom-of-run anchor (which
* sits against the content below the run). Non-blank blocks never slide, so
* code that merely ends like its neighbor (an added function before an
* identical `}`) keeps the library's canonical position.
*/
function slideBlankBoundaryBlocksUp(hunk, diff) {
	const { hunkContent } = hunk;
	for (let index = 1; index < hunkContent.length; index++) {
		const block = hunkContent[index];
		const previous = hunkContent[index - 1];
		if (block.type !== "change" || block.additions > 0 && block.deletions > 0 || previous.type !== "context") continue;
		const isInsert = block.additions > 0;
		const lines = isInsert ? diff.additionLines : diff.deletionLines;
		const blockStart = isInsert ? block.additionLineIndex : block.deletionLineIndex;
		const blockLength = isInsert ? block.additions : block.deletions;
		const unit = lines[blockStart] ?? "";
		if (unit.trim() !== "") continue;
		let uniform = true;
		for (let offset = 1; offset < blockLength; offset++) if (lines[blockStart + offset] !== unit) {
			uniform = false;
			break;
		}
		if (!uniform) continue;
		let slide = 0;
		while (slide < previous.lines && diff.additionLines[previous.additionLineIndex + previous.lines - 1 - slide] === unit) slide++;
		if (slide === 0) continue;
		if (index === 1 && slide === previous.lines) continue;
		block.additionLineIndex -= slide;
		block.deletionLineIndex -= slide;
		const blockAdditionEnd = block.additionLineIndex + block.additions;
		const blockDeletionEnd = block.deletionLineIndex + block.deletions;
		const next = hunkContent[index + 1];
		if (next?.type === "context") {
			next.lines += slide;
			next.additionLineIndex = blockAdditionEnd;
			next.deletionLineIndex = blockDeletionEnd;
		} else hunkContent.splice(index + 1, 0, {
			type: "context",
			lines: slide,
			additionLineIndex: blockAdditionEnd,
			deletionLineIndex: blockDeletionEnd
		});
		previous.lines -= slide;
		if (previous.lines === 0) {
			hunkContent.splice(index - 1, 1);
			index--;
		}
	}
}
function realignChangeBlock(diff, content) {
	const { deletions, additions, deletionLineIndex, additionLineIndex } = content;
	const pairCount = Math.min(deletions, additions);
	const surplus = Math.abs(additions - deletions);
	if (pairCount === 0 || surplus === 0 || pairCount * (surplus + 1) > MAX_ALIGNMENT_COMPARISONS) return null;
	const strippedDeletions = [];
	for (let line = 0; line < deletions; line++) strippedDeletions.push(stripWhitespace(diff.deletionLines[deletionLineIndex + line] ?? ""));
	const strippedAdditions = [];
	for (let line = 0; line < additions; line++) strippedAdditions.push(stripWhitespace(diff.additionLines[additionLineIndex + line] ?? ""));
	const additionsAreLonger = additions > deletions;
	let bestOffset = 0;
	let bestScore = -1;
	for (let offset = 0; offset <= surplus; offset++) {
		let score = 0;
		for (let pair = 0; pair < pairCount; pair++) score += lineSimilarity(strippedDeletions[pair + (additionsAreLonger ? 0 : offset)], strippedAdditions[pair + (additionsAreLonger ? offset : 0)]);
		if (offset === 0) bestScore = score + pairCount * MIN_IMPROVEMENT_PER_PAIR;
		else if (score > bestScore) {
			bestScore = score;
			bestOffset = offset;
		}
	}
	if (bestOffset === 0) return null;
	const blocks = [];
	const pushBlock = (blockDeletions, blockAdditions, blockDeletionIndex, blockAdditionIndex) => {
		if (blockDeletions > 0 || blockAdditions > 0) blocks.push({
			type: "change",
			deletions: blockDeletions,
			additions: blockAdditions,
			deletionLineIndex: blockDeletionIndex,
			additionLineIndex: blockAdditionIndex
		});
	};
	if (additionsAreLonger) {
		pushBlock(0, bestOffset, deletionLineIndex, additionLineIndex);
		pushBlock(pairCount, pairCount, deletionLineIndex, additionLineIndex + bestOffset);
		pushBlock(0, additions - pairCount - bestOffset, deletionLineIndex + pairCount, additionLineIndex + bestOffset + pairCount);
	} else {
		pushBlock(bestOffset, 0, deletionLineIndex, additionLineIndex);
		pushBlock(pairCount, pairCount, deletionLineIndex + bestOffset, additionLineIndex);
		pushBlock(deletions - pairCount - bestOffset, 0, deletionLineIndex + bestOffset + pairCount, additionLineIndex + pairCount);
	}
	return blocks;
}
var WHITESPACE = /\s+/g;
function stripWhitespace(line) {
	return line.replace(WHITESPACE, "");
}
function lineSimilarity(a, b) {
	if (a === b) return 1;
	const maxLength = Math.max(a.length, b.length);
	const minLength = Math.min(a.length, b.length);
	if (minLength === 0) return 0;
	let prefix = 0;
	while (prefix < minLength && a[prefix] === b[prefix]) prefix++;
	let suffix = 0;
	while (suffix < minLength - prefix && a[a.length - 1 - suffix] === b[b.length - 1 - suffix]) suffix++;
	return (prefix + suffix) / maxLength;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/parsePatchFiles.js
function processPatch(data, cacheKeyPrefix, throwOnError) {
	try {
		return _processPatch(data, cacheKeyPrefix, throwOnError);
	} finally {
		releaseStringDetachBuffer();
	}
}
function _processPatch(data, cacheKeyPrefix, throwOnError = false) {
	const isGitDiff = isGitDiffPatch(data);
	const rawFiles = isGitDiff ? splitGitDiffFiles(data) : splitUnifiedDiffFiles(data);
	let patchMetadata;
	const files = [];
	for (const fileOrPatchMetadata of rawFiles) {
		if (isGitDiff && !GIT_DIFF_FILE_BREAK_REGEX.test(fileOrPatchMetadata)) {
			if (patchMetadata == null) patchMetadata = detachString(fileOrPatchMetadata);
			else if (throwOnError) throw Error("parsePatchContent: unknown file blob");
			else console.error("parsePatchContent: unknown file blob:", fileOrPatchMetadata);
			continue;
		} else if (!isGitDiff && !startsWithUnifiedDiffFileHeader(fileOrPatchMetadata)) {
			if (patchMetadata == null) patchMetadata = detachString(fileOrPatchMetadata);
			else if (throwOnError) throw Error("parsePatchContent: unknown file blob");
			else console.error("parsePatchContent: unknown file blob:", fileOrPatchMetadata);
			continue;
		}
		const currentFile = _processFile(fileOrPatchMetadata, {
			cacheKey: cacheKeyPrefix != null ? `${cacheKeyPrefix}-${files.length}` : void 0,
			isGitDiff,
			throwOnError
		});
		if (currentFile != null) files.push(currentFile);
	}
	return {
		patchMetadata,
		files
	};
}
function processFile(fileDiffString, options) {
	try {
		return _processFile(fileDiffString, options);
	} finally {
		releaseStringDetachBuffer();
	}
}
function _processFile(fileDiffString, { cacheKey, isGitDiff = GIT_DIFF_FILE_BREAK_REGEX.test(fileDiffString), oldFile, newFile, throwOnError = false } = {}) {
	let lastHunkEnd = 0;
	const hunks = splitAtLinePrefix(fileDiffString, "@@ ");
	let currentFile;
	const isPartial = oldFile == null || newFile == null;
	let deletionLineIndex = 0;
	let additionLineIndex = 0;
	for (const hunk of hunks) {
		const lines = splitWithNewlines(hunk);
		const firstLine = lines[0];
		if (firstLine == null) {
			if (throwOnError) throw Error("parsePatchContent: invalid hunk");
			else console.error("parsePatchContent: invalid hunk", hunk);
			continue;
		}
		const fileHeader = parseHunkHeader(firstLine);
		let additionLines = 0;
		let deletionLines = 0;
		if (fileHeader == null || currentFile == null) {
			if (currentFile != null) {
				if (throwOnError) throw Error("parsePatchContent: Invalid hunk");
				else console.error("parsePatchContent: Invalid hunk", hunk);
				continue;
			}
			currentFile = {
				name: "",
				type: "change",
				hunks: [],
				splitLineCount: 0,
				unifiedLineCount: 0,
				isPartial,
				additionLines: !isPartial && oldFile != null && newFile != null ? splitFileContents$1(newFile.contents) : [],
				deletionLines: !isPartial && oldFile != null && newFile != null ? splitFileContents$1(oldFile.contents) : [],
				cacheKey: maybeDetachOptionalString(cacheKey)
			};
			if (currentFile.additionLines.length === 1 && newFile?.contents === "") currentFile.additionLines.length = 0;
			if (currentFile.deletionLines.length === 1 && oldFile?.contents === "") currentFile.deletionLines.length = 0;
			for (const line of lines) {
				if (line.startsWith("diff --git")) {
					const filenameMatch = line.trim().match(ALTERNATE_FILE_NAMES_GIT);
					const prevName = filenameMatch?.[1] ?? filenameMatch?.[2];
					const name = filenameMatch?.[3] ?? filenameMatch?.[4];
					if (prevName == null || name == null) {
						if (throwOnError) throw Error("parsePatchContent: invalid git diff header");
						else console.error("parsePatchContent: invalid git diff header", line);
						continue;
					}
					currentFile.name = detachString(name.trim());
					if (prevName !== name) currentFile.prevName = detachString(prevName.trim());
					continue;
				}
				const filenameMatch = line.startsWith("---") || line.startsWith("+++") ? line.match(isGitDiff ? FILENAME_HEADER_REGEX_GIT : FILENAME_HEADER_REGEX) : null;
				if (filenameMatch != null) {
					const [, type, fileName] = filenameMatch;
					if (type === "---" && fileName !== "/dev/null") {
						const detachedFileName = detachString(fileName.trim());
						currentFile.prevName = detachedFileName;
						currentFile.name = detachedFileName;
					} else if (type === "+++" && fileName !== "/dev/null") currentFile.name = detachString(fileName.trim());
				} else if (isGitDiff) {
					if (line.startsWith("new mode ")) currentFile.mode = detachString(line.slice(8).trim());
					if (line.startsWith("old mode ")) currentFile.prevMode = detachString(line.slice(8).trim());
					if (line.startsWith("new file mode")) {
						currentFile.type = "new";
						currentFile.mode = detachString(line.slice(13).trim());
					}
					if (line.startsWith("deleted file mode")) {
						currentFile.type = "deleted";
						currentFile.mode = detachString(line.slice(17).trim());
					}
					if (line.startsWith("similarity index")) if (line.startsWith("similarity index 100%")) currentFile.type = "rename-pure";
					else currentFile.type = "rename-changed";
					if (line.startsWith("index ")) {
						const [, prevObjectId, newObjectId, mode] = line.trim().match(INDEX_LINE_METADATA) ?? [];
						if (prevObjectId != null) currentFile.prevObjectId = detachString(prevObjectId);
						if (newObjectId != null) currentFile.newObjectId = detachString(newObjectId);
						if (mode != null) currentFile.mode = detachString(mode);
					}
					if (line.startsWith("rename from ")) currentFile.prevName = detachString(line.slice(12).trim());
					if (line.startsWith("rename to ")) currentFile.name = detachString(line.slice(10).trim());
				}
			}
			continue;
		}
		let currentContent;
		let lastLineType;
		while (lines.length > 0 && (lines[lines.length - 1] === "\n" || lines[lines.length - 1] === "\r" || lines[lines.length - 1] === "\r\n" || lines[lines.length - 1] === "")) lines.pop();
		const { additionStart, deletionStart } = fileHeader;
		deletionLineIndex = isPartial ? deletionLineIndex : deletionStart - 1;
		additionLineIndex = isPartial ? additionLineIndex : additionStart - 1;
		const hunkData = {
			collapsedBefore: 0,
			splitLineCount: 0,
			splitLineStart: 0,
			unifiedLineCount: 0,
			unifiedLineStart: 0,
			additionCount: fileHeader.additionCount,
			additionStart,
			additionLines,
			deletionCount: fileHeader.deletionCount,
			deletionStart,
			deletionLines,
			deletionLineIndex,
			additionLineIndex,
			hunkContent: [],
			hunkContext: maybeDetachOptionalString(fileHeader.hunkContext),
			hunkSpecs: detachString(firstLine),
			noEOFCRAdditions: false,
			noEOFCRDeletions: false
		};
		let parsedAdditionLines = 0;
		let parsedDeletionLines = 0;
		for (let lineIndex = 1; lineIndex < lines.length; lineIndex++) {
			const rawLine = lines[lineIndex];
			if (parsedAdditionLines >= hunkData.additionCount && parsedDeletionLines >= hunkData.deletionCount && !rawLine.startsWith("\\")) {
				if (throwOnError && isHunkBodyLine(rawLine) && !isFormatPatchVersionSeparator(rawLine)) throw Error("parsePatchContent: hunk has more lines than expected");
				break;
			}
			const firstChar = rawLine[0];
			if (firstChar !== "+" && firstChar !== "-" && firstChar !== " " && firstChar !== "\\") {
				if (throwOnError) throw Error("parsePatchContent: invalid hunk line");
				console.error(`parseLineType: Invalid firstChar: "${firstChar}", full line: "${rawLine}"`);
				console.error("processFile: invalid rawLine:", rawLine);
				continue;
			}
			const type = parseRawLineType(firstChar);
			if (type === "addition") {
				if (throwOnError && parsedAdditionLines >= hunkData.additionCount) throw Error("parsePatchContent: hunk has too many addition lines");
				const line = getParsedLineContent(rawLine);
				if (currentContent == null || currentContent.type !== "change") {
					currentContent = createContentGroup("change", deletionLineIndex, additionLineIndex);
					hunkData.hunkContent.push(currentContent);
				}
				additionLineIndex++;
				parsedAdditionLines++;
				if (isPartial) currentFile.additionLines.push(line);
				currentContent.additions++;
				additionLines++;
				lastLineType = "addition";
			} else if (type === "deletion") {
				if (throwOnError && parsedDeletionLines >= hunkData.deletionCount) throw Error("parsePatchContent: hunk has too many deletion lines");
				const line = getParsedLineContent(rawLine);
				if (currentContent == null || currentContent.type !== "change") {
					currentContent = createContentGroup("change", deletionLineIndex, additionLineIndex);
					hunkData.hunkContent.push(currentContent);
				}
				deletionLineIndex++;
				parsedDeletionLines++;
				if (isPartial) currentFile.deletionLines.push(line);
				currentContent.deletions++;
				deletionLines++;
				lastLineType = "deletion";
			} else if (type === "context") {
				if (throwOnError && (parsedDeletionLines >= hunkData.deletionCount || parsedAdditionLines >= hunkData.additionCount)) throw Error("parsePatchContent: hunk has too many context lines");
				const line = getParsedLineContent(rawLine);
				if (currentContent == null || currentContent.type !== "context") {
					currentContent = createContentGroup("context", deletionLineIndex, additionLineIndex);
					hunkData.hunkContent.push(currentContent);
				}
				additionLineIndex++;
				deletionLineIndex++;
				parsedAdditionLines++;
				parsedDeletionLines++;
				if (isPartial) {
					currentFile.deletionLines.push(line);
					currentFile.additionLines.push(line);
				}
				currentContent.lines++;
				lastLineType = "context";
			} else if (type === "metadata" && currentContent != null) {
				if (currentContent.type === "context") {
					hunkData.noEOFCRAdditions = true;
					hunkData.noEOFCRDeletions = true;
				} else if (lastLineType === "deletion") hunkData.noEOFCRDeletions = true;
				else if (lastLineType === "addition") hunkData.noEOFCRAdditions = true;
				if (isPartial && (lastLineType === "addition" || lastLineType === "context")) {
					const lastIndex = currentFile.additionLines.length - 1;
					if (lastIndex >= 0) currentFile.additionLines[lastIndex] = cleanLastNewline(currentFile.additionLines[lastIndex]);
				}
				if (isPartial && (lastLineType === "deletion" || lastLineType === "context")) {
					const lastIndex = currentFile.deletionLines.length - 1;
					if (lastIndex >= 0) currentFile.deletionLines[lastIndex] = cleanLastNewline(currentFile.deletionLines[lastIndex]);
				}
			}
		}
		if (throwOnError && (parsedAdditionLines !== hunkData.additionCount || parsedDeletionLines !== hunkData.deletionCount)) throw Error("parsePatchContent: hunk line count mismatch");
		hunkData.additionLines = additionLines;
		hunkData.deletionLines = deletionLines;
		hunkData.collapsedBefore = Math.max(getHunkSideStartBoundary(hunkData.additionStart, hunkData.additionCount) - lastHunkEnd, 0);
		currentFile.hunks.push(hunkData);
		lastHunkEnd = getHunkSideEndBoundary(hunkData.additionStart, hunkData.additionCount);
		for (const content of hunkData.hunkContent) if (content.type === "context") {
			hunkData.splitLineCount += content.lines;
			hunkData.unifiedLineCount += content.lines;
		} else {
			hunkData.splitLineCount += Math.max(content.additions, content.deletions);
			hunkData.unifiedLineCount += content.deletions + content.additions;
		}
		hunkData.splitLineStart = currentFile.splitLineCount + hunkData.collapsedBefore;
		hunkData.unifiedLineStart = currentFile.unifiedLineCount + hunkData.collapsedBefore;
		currentFile.splitLineCount += hunkData.collapsedBefore + hunkData.splitLineCount;
		currentFile.unifiedLineCount += hunkData.collapsedBefore + hunkData.unifiedLineCount;
	}
	if (currentFile == null) return;
	if (throwOnError && isPartial && !isGitDiff && currentFile.hunks.length === 0) throw Error("parsePatchContent: unified file has no hunks");
	if (currentFile.hunks.length > 0 && !isPartial && currentFile.additionLines.length > 0 && currentFile.deletionLines.length > 0) {
		const lastHunk = currentFile.hunks[currentFile.hunks.length - 1];
		const lastHunkEnd = getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount);
		const totalFileLines = currentFile.additionLines.length;
		const collapsedAfter = Math.max(totalFileLines - lastHunkEnd, 0);
		currentFile.splitLineCount += collapsedAfter;
		currentFile.unifiedLineCount += collapsedAfter;
	}
	if (!isGitDiff) {
		if (currentFile.prevName != null && currentFile.name !== currentFile.prevName) if (currentFile.hunks.length > 0) currentFile.type = "rename-changed";
		else currentFile.type = "rename-pure";
		else if ((oldFile == null || oldFile.contents === "") && newFile != null && newFile.contents !== "") currentFile.type = "new";
		else if (oldFile != null && oldFile.contents !== "" && (newFile == null || newFile.contents === "")) currentFile.type = "deleted";
	}
	if (currentFile.type !== "rename-pure" && currentFile.type !== "rename-changed") currentFile.prevName = void 0;
	realignChangeContentBySimilarity(currentFile);
	return currentFile;
}
/**
* Parses a patch file string into an array of parsed patches.
*
* @param data - The raw patch file content (supports multi-commit patches)
* @param cacheKeyPrefix - Optional prefix for generating cache keys. When provided,
*   each file in the patch will get a cache key in the format `prefix-patchIndex-fileIndex`.
*   This enables caching of rendered diff results in the worker pool.
*/
function parsePatchFiles(data, cacheKeyPrefix, throwOnError = false) {
	const patches = [];
	const rawPatches = hasCommitMetadataBoundary(data) ? data.split(COMMIT_METADATA_SPLIT) : [data];
	for (const patch of rawPatches) try {
		patches.push(processPatch(patch, cacheKeyPrefix != null ? `${cacheKeyPrefix}-${patches.length}` : void 0, throwOnError));
	} catch (error) {
		if (throwOnError) throw error;
		else console.error(error);
	}
	return patches;
}
function hasCommitMetadataBoundary(data) {
	return data.startsWith("From ") || data.includes("\nFrom ");
}
function splitFileContents$1(contents) {
	const lines = splitWithNewlines(contents);
	for (let index = 0; index < lines.length; index++) lines[index] = detachString(lines[index]);
	return lines;
}
function splitWithNewlines(contents) {
	if (contents.length === 0) return [""];
	const lines = [];
	let startIndex = 0;
	for (;;) {
		const newlineIndex = contents.indexOf("\n", startIndex);
		if (newlineIndex === -1) break;
		lines.push(contents.slice(startIndex, newlineIndex + 1));
		startIndex = newlineIndex + 1;
	}
	if (startIndex < contents.length) lines.push(contents.slice(startIndex));
	return lines;
}
function splitGitDiffFiles(contents) {
	return splitAtLinePrefix(contents, "diff --git");
}
function splitUnifiedDiffFiles(contents) {
	if (contents.length === 0) return [""];
	const parts = [];
	let partStartIndex = 0;
	let lineStartIndex = 0;
	let remainingDeletionLines = 0;
	let remainingAdditionLines = 0;
	let hasOpenedUnifiedFile = false;
	while (lineStartIndex < contents.length) {
		const nextLineStartIndex = getNextLineStartIndex(contents, lineStartIndex);
		if (remainingDeletionLines <= 0 && remainingAdditionLines <= 0) {
			if (isUnifiedDiffFileHeaderAt(contents, lineStartIndex)) {
				if (lineStartIndex > partStartIndex) parts.push(contents.slice(partStartIndex, lineStartIndex));
				partStartIndex = lineStartIndex;
				hasOpenedUnifiedFile = true;
				lineStartIndex = getNextLineStartIndex(contents, nextLineStartIndex);
				continue;
			}
			if (hasOpenedUnifiedFile && contents.startsWith("@@ -", lineStartIndex)) {
				const fileHeader = parseHunkHeader(contents.slice(lineStartIndex, nextLineStartIndex));
				if (fileHeader != null) {
					remainingDeletionLines = fileHeader.deletionCount;
					remainingAdditionLines = fileHeader.additionCount;
				}
			}
			lineStartIndex = nextLineStartIndex;
			continue;
		}
		const firstChar = contents[lineStartIndex];
		if (firstChar === "\\") {
			lineStartIndex = nextLineStartIndex;
			continue;
		}
		if (firstChar === " ") {
			remainingDeletionLines = Math.max(remainingDeletionLines - 1, 0);
			remainingAdditionLines = Math.max(remainingAdditionLines - 1, 0);
		} else if (firstChar === "-") remainingDeletionLines = Math.max(remainingDeletionLines - 1, 0);
		else if (firstChar === "+") remainingAdditionLines = Math.max(remainingAdditionLines - 1, 0);
		lineStartIndex = nextLineStartIndex;
	}
	parts.push(contents.slice(partStartIndex));
	return parts;
}
function startsWithUnifiedDiffFileHeader(contents) {
	return isUnifiedDiffFileHeaderAt(contents, 0);
}
function isUnifiedDiffFileHeaderAt(contents, lineStartIndex) {
	const nextLineStartIndex = getNextLineStartIndex(contents, lineStartIndex);
	return isUnifiedDiffHeaderLineAt(contents, lineStartIndex, "---") && isUnifiedDiffHeaderLineAt(contents, nextLineStartIndex, "+++");
}
function isUnifiedDiffHeaderLineAt(contents, lineStartIndex, prefix) {
	if (!contents.startsWith(prefix, lineStartIndex)) return false;
	const separator = contents[lineStartIndex + prefix.length];
	if (separator !== " " && separator !== "	") return false;
	for (let index = lineStartIndex + prefix.length + 1; index < contents.length; index++) {
		const char = contents[index];
		if (char === "\n" || char === "\r") break;
		if (char !== " " && char !== "	") return true;
	}
	return false;
}
function getNextLineStartIndex(contents, lineStartIndex) {
	const newlineIndex = contents.indexOf("\n", lineStartIndex);
	return newlineIndex === -1 ? contents.length : newlineIndex + 1;
}
function isHunkBodyLine(line) {
	const firstChar = line[0];
	return firstChar === "+" || firstChar === "-" || firstChar === " ";
}
function isFormatPatchVersionSeparator(line) {
	if (!line.startsWith("--")) return false;
	for (let index = 2; index < line.length; index++) {
		const char = line[index];
		if (char !== " " && char !== "	" && char !== "\n" && char !== "\r") return false;
	}
	return true;
}
function parseHunkHeader(line) {
	if (!line.startsWith("@@ -")) return;
	let index = 4;
	const deletionStartResult = readPositiveInteger(line, index);
	if (deletionStartResult == null) return;
	const deletionStart = deletionStartResult.value;
	index = deletionStartResult.endIndex;
	let deletionCount = 1;
	if (line[index] === ",") {
		const deletionCountResult = readPositiveInteger(line, index + 1);
		if (deletionCountResult == null) return;
		deletionCount = deletionCountResult.value;
		index = deletionCountResult.endIndex;
	}
	if (line[index] !== " " || line[index + 1] !== "+") return;
	index += 2;
	const additionStartResult = readPositiveInteger(line, index);
	if (additionStartResult == null) return;
	const additionStart = additionStartResult.value;
	index = additionStartResult.endIndex;
	let additionCount = 1;
	if (line[index] === ",") {
		const additionCountResult = readPositiveInteger(line, index + 1);
		if (additionCountResult == null) return;
		additionCount = additionCountResult.value;
		index = additionCountResult.endIndex;
	}
	if (line[index] !== " " || line[index + 1] !== "@" || line[index + 2] !== "@") return;
	let hunkContext;
	const contextStartIndex = index + 3;
	if (line[contextStartIndex] === " ") hunkContext = trimLineEnd(line.slice(contextStartIndex + 1));
	return {
		additionCount,
		additionStart,
		deletionCount,
		deletionStart,
		hunkContext
	};
}
function readPositiveInteger(value, startIndex) {
	let index = startIndex;
	let parsedValue = 0;
	for (; index < value.length; index++) {
		const digit = value.charCodeAt(index) - 48;
		if (digit < 0 || digit > 9) break;
		parsedValue = parsedValue * 10 + digit;
	}
	if (index === startIndex) return;
	return {
		value: parsedValue,
		endIndex: index
	};
}
function trimLineEnd(value) {
	if (value.endsWith("\r\n")) return value.slice(0, -2);
	if (value.endsWith("\n")) return value.slice(0, -1);
	return value;
}
function isGitDiffPatch(data) {
	return data.startsWith("diff --git") || data.includes("\ndiff --git");
}
function splitAtLinePrefix(contents, prefix) {
	if (contents.length === 0) return [""];
	const newlinePrefix = `\n${prefix}`;
	const firstBoundaryIndex = contents.startsWith(prefix) ? 0 : findLinePrefixIndex(contents, newlinePrefix, 0);
	if (firstBoundaryIndex === -1) return [contents];
	const parts = [];
	if (firstBoundaryIndex > 0) parts.push(contents.slice(0, firstBoundaryIndex));
	let startIndex = firstBoundaryIndex;
	for (;;) {
		const nextBoundaryIndex = findLinePrefixIndex(contents, newlinePrefix, startIndex + 1);
		if (nextBoundaryIndex === -1) break;
		parts.push(contents.slice(startIndex, nextBoundaryIndex));
		startIndex = nextBoundaryIndex;
	}
	parts.push(contents.slice(startIndex));
	return parts;
}
function findLinePrefixIndex(contents, newlinePrefix, fromIndex) {
	const index = contents.indexOf(newlinePrefix, fromIndex);
	return index === -1 ? -1 : index + 1;
}
function maybeDetachOptionalString(value) {
	return value == null ? value : detachString(value);
}
function parseRawLineType(firstChar) {
	return firstChar === " " ? "context" : firstChar === "\\" ? "metadata" : firstChar === "+" ? "addition" : "deletion";
}
function getParsedLineContent(rawLine) {
	const processedLine = rawLine.slice(1);
	return detachString(processedLine === "" ? "\n" : processedLine);
}
function createContentGroup(type, deletionLineIndex, additionLineIndex) {
	if (type === "change") return {
		type: "change",
		additions: 0,
		deletions: 0,
		additionLineIndex,
		deletionLineIndex
	};
	return {
		type: "context",
		lines: 0,
		additionLineIndex,
		deletionLineIndex
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/parseDiffFromFile.js
var MISSING_FILE_NAME = "/dev/null";
/**
* Parses a diff from two file contents objects.
*
* If both `oldFile` and `newFile` have a `cacheKey`, the resulting diff will
* automatically get a combined cache key in the format `oldKey:newKey`.
*/
function parseDiffFromFile(oldFile, newFile, options, throwOnError = false) {
	if (oldFile === null && newFile === null) throw new Error("parseDiffFromFile: You must pass oldFile, newFile, or both");
	const resolvedOldFile = oldFile ?? createMissingFile();
	const resolvedNewFile = newFile ?? createMissingFile();
	const fileData = processFile(createTwoFilesPatch(resolvedOldFile.name, resolvedNewFile.name, resolvedOldFile.contents, resolvedNewFile.contents, resolvedOldFile.header, resolvedNewFile.header, options), {
		cacheKey: (() => {
			const oldCacheKey = oldFile?.cacheKey ?? oldFile?.name;
			const newCacheKey = newFile?.cacheKey ?? newFile?.name;
			if (oldCacheKey != null && newCacheKey != null) return oldCacheKey + ":" + newCacheKey;
			return oldCacheKey ?? newCacheKey;
		})(),
		oldFile: resolvedOldFile,
		newFile: resolvedNewFile,
		throwOnError
	});
	if (fileData == null) throw new Error("parseDiffFrom: FileInvalid diff -- probably need to fix something -- if the files are the same maybe?");
	if (oldFile === null) {
		fileData.type = "new";
		fileData.prevName = void 0;
	} else if (newFile === null) {
		fileData.type = "deleted";
		fileData.prevName = void 0;
	}
	const language = newFile?.lang ?? (newFile === null ? oldFile?.lang : void 0);
	if (language != null) fileData.lang = language;
	return fileData;
}
function createMissingFile() {
	return {
		name: MISSING_FILE_NAME,
		contents: ""
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/prefersReducedMotion.js
function prefersReducedMotion() {
	if (typeof window === "undefined" || typeof window.matchMedia !== "function") return false;
	return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areFilesEqual.js
function areFilesEqual(fileA, fileB) {
	return fileA?.cacheKey === fileB?.cacheKey && fileA?.contents === fileB?.contents && fileA?.name === fileB?.name && fileA?.lang === fileB?.lang;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/hast_utils.js
function createTextNodeElement(value) {
	return {
		type: "text",
		value
	};
}
function createHastElement({ tagName, children = [], properties = {} }) {
	return {
		type: "element",
		tagName,
		properties,
		children
	};
}
function createIconElement({ name, width = 16, height = 16, properties }) {
	return createHastElement({
		tagName: "svg",
		properties: {
			width,
			height,
			viewBox: "0 0 16 16",
			...properties
		},
		children: [createHastElement({
			tagName: "use",
			properties: { href: `#${name.replace(/^#/, "")}` }
		})]
	});
}
function findCodeElement(nodes) {
	let firstChild = nodes.children[0];
	while (firstChild != null) {
		if (firstChild.type === "element" && firstChild.tagName === "code") return firstChild;
		if ("children" in firstChild) firstChild = firstChild.children[0];
		else firstChild = null;
	}
}
function createGutterWrapper(children) {
	return createHastElement({
		tagName: "div",
		properties: { "data-gutter": "" },
		children
	});
}
function createGutterItem(lineType, lineNumber, lineIndex, properties = {}) {
	return createHastElement({
		tagName: "div",
		properties: {
			"data-line-type": lineType,
			"data-column-number": lineNumber,
			"data-line-index": lineIndex,
			...properties
		},
		children: lineNumber != null ? [createHastElement({
			tagName: "span",
			properties: { "data-line-number-content": "" },
			children: [createTextNodeElement(`${lineNumber}`)]
		})] : void 0
	});
}
function createGutterGap(type, bufferType, size) {
	return createHastElement({
		tagName: "div",
		properties: {
			"data-gutter-buffer": bufferType,
			"data-buffer-size": size,
			"data-line-type": bufferType === "annotation" ? void 0 : type,
			style: bufferType === "annotation" ? `grid-row: span ${size};` : `grid-row: span ${size};min-height:calc(${size} * 1lh);`
		}
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createGutterUtilityElement.js
function createGutterUtilityElement() {
	return createHastElement({
		tagName: "button",
		properties: {
			"data-utility-button": "",
			type: "button"
		},
		children: [createIconElement({
			name: "diffs-icon-plus",
			properties: { "data-icon": "" }
		})]
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areSelectionPointsEqual.js
function areSelectionPointsEqual(a, b) {
	return a.lineNumber === b.lineNumber && a.side === b.side;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/managers/InteractionManager.js
var InteractionManager = class {
	mode;
	options;
	hoveredLine;
	hoveredToken;
	pre;
	gutterUtilityLine;
	gutterUtilityContainer;
	gutterUtilityButton;
	gutterUtilitySlot;
	interactiveLinesAttr = false;
	interactiveLineNumbersAttr = false;
	hasPointerListeners = false;
	hasDocumentPointerListeners = false;
	selectedRange = null;
	selectedRangeHighlightSide;
	selectedRangeLineNumberOnly = false;
	editorActiveLine = null;
	editorActiveLineSide;
	editorLineNumberOnly = false;
	proposedSelectedRange;
	renderedSelectedLinesState;
	renderedEditorActiveLineState;
	selectionAnchor;
	pointerSession = { mode: "idle" };
	constructor(mode, options) {
		this.mode = mode;
		this.options = options;
	}
	setOptions(options) {
		this.options = options;
	}
	cleanUp() {
		this.pre?.removeEventListener("click", this.handlePointerClick);
		this.pre?.removeEventListener("pointerdown", this.handlePointerDown);
		this.pre?.removeEventListener("pointermove", this.handlePointerMove);
		this.pre?.removeEventListener("pointerleave", this.handlePointerLeave);
		this.pre?.removeAttribute("data-interactive-lines");
		this.pre?.removeAttribute("data-interactive-line-numbers");
		this.pre = void 0;
		this.gutterUtilityContainer?.remove();
		this.gutterUtilityLine = void 0;
		this.gutterUtilityContainer = void 0;
		this.gutterUtilityButton = void 0;
		this.gutterUtilitySlot = void 0;
		this.clearHoveredLine();
		this.clearHoveredToken();
		this.detachDocumentPointerListeners();
		this.clearPointerSession();
		dequeueRender(this.renderSelection);
		this.interactiveLinesAttr = false;
		this.interactiveLineNumbersAttr = false;
		this.hasPointerListeners = false;
		this.setSelectionDirty();
	}
	setup(pre) {
		this.setSelectionDirty();
		const { usesCustomGutterUtility = false, enableGutterUtility = false } = this.options;
		if (this.pre !== pre) {
			this.cleanUp();
			this.pre = pre;
		}
		if (enableGutterUtility) this.ensureGutterUtilityNode(usesCustomGutterUtility);
		else if (this.gutterUtilityContainer != null) {
			this.gutterUtilityContainer.remove();
			this.gutterUtilityLine = void 0;
			this.gutterUtilityContainer = void 0;
			this.gutterUtilityButton = void 0;
			this.gutterUtilitySlot = void 0;
			if (this.pointerSession.mode === "gutterSelecting") {
				this.clearPointerSession();
				this.detachDocumentPointerListeners();
			}
		}
		this.syncPointerListeners(pre);
		this.updateInteractiveLineAttributes();
		this.renderSelection();
		this.placeUtility();
	}
	setSelectionDirty() {
		this.renderedSelectedLinesState = void 0;
		this.renderedEditorActiveLineState = void 0;
	}
	isSelectionDirty() {
		return this.renderedSelectedLinesState === void 0 || this.renderedEditorActiveLineState === void 0;
	}
	setSelection(range, options) {
		const isRangeChange = !(range === this.selectedRange || areSelectionsEqual(range ?? void 0, this.selectedRange ?? void 0));
		const lineNumberOnly = options?.lineNumberOnly ?? false;
		const isStyleChange = options?.activeLineSide !== this.selectedRangeHighlightSide || lineNumberOnly !== this.selectedRangeLineNumberOnly;
		if (!this.isSelectionDirty() && !isRangeChange && !isStyleChange) return;
		this.proposedSelectedRange = void 0;
		this.selectedRange = range;
		this.selectedRangeHighlightSide = options?.activeLineSide;
		this.selectedRangeLineNumberOnly = lineNumberOnly;
		this.renderSelection();
		this.placeUtility();
		if (isRangeChange && options?.notify !== false) this.notifySelectionCommitted(range);
	}
	setEditorActiveLine(lineNumber, { lineNumberOnly = false, side } = {}) {
		const isLineChange = lineNumber !== this.editorActiveLine;
		const isStyleChange = side !== this.editorActiveLineSide || lineNumberOnly !== this.editorLineNumberOnly;
		if (!this.isSelectionDirty() && !isLineChange && !isStyleChange) return;
		this.editorActiveLine = lineNumber;
		this.editorActiveLineSide = side;
		this.editorLineNumberOnly = lineNumberOnly;
		this.renderSelection();
	}
	getSelection() {
		return this.selectedRange;
	}
	getHoveredLine = () => {
		const gutterUtilityLine = this.gutterUtilityLine ?? this.hoveredLine;
		if (gutterUtilityLine != null) {
			if (this.mode === "diff" && gutterUtilityLine.type === "diff-line") return {
				lineNumber: gutterUtilityLine.lineNumber,
				side: gutterUtilityLine.annotationSide
			};
			if (this.mode === "file" && gutterUtilityLine.type === "line") return { lineNumber: gutterUtilityLine.lineNumber };
		}
	};
	handlePointerClick = (event) => {
		const { onHunkExpand, onLineClick, onLineNumberClick, onTokenClick, onMergeConflictActionClick } = this.options;
		if (onHunkExpand == null && onLineClick == null && onLineNumberClick == null && onMergeConflictActionClick == null && onTokenClick == null) return;
		if (this.options.onGutterUtilityClick != null && isGutterUtilityPath(event.composedPath())) return;
		debugLogIfEnabled(this.options.__debugPointerEvents, "click", "FileDiff.DEBUG.handlePointerClick:", event);
		this.handlePointerEvent({
			eventType: "click",
			event
		});
	};
	handlePointerMove = (event) => {
		if (event.pointerType !== "mouse") return;
		const { lineHoverHighlight = "disabled", onLineEnter, onLineLeave, onTokenEnter, onTokenLeave, enableGutterUtility = false } = this.options;
		if (lineHoverHighlight === "disabled" && !enableGutterUtility && onLineEnter == null && onLineLeave == null && onTokenEnter == null && onTokenLeave == null) return;
		debugLogIfEnabled(this.options.__debugPointerEvents, "move", "FileDiff.DEBUG.handlePointerMove:", event);
		this.handlePointerEvent({
			eventType: "move",
			event
		});
	};
	handlePointerLeave = (event) => {
		const { __debugPointerEvents } = this.options;
		debugLogIfEnabled(__debugPointerEvents, "move", "FileDiff.DEBUG.handlePointerLeave: no event");
		if (this.hoveredLine == null && this.hoveredToken == null) {
			debugLogIfEnabled(__debugPointerEvents, "move", "FileDiff.DEBUG.handlePointerLeave: returned early, no hovered line or token");
			return;
		}
		if (this.hoveredToken != null) {
			this.options.onTokenLeave?.(this.hoveredToken, event);
			this.clearHoveredToken();
		}
		if (this.hoveredLine != null) {
			this.options.onLineLeave?.({
				...this.hoveredLine,
				event
			});
			this.clearHoveredLine();
		}
		this.placeUtility();
	};
	handlePointerEvent({ eventType, event }) {
		const { __debugPointerEvents } = this.options;
		const composedPath = event.composedPath();
		debugLogIfEnabled(__debugPointerEvents, eventType, "FileDiff.DEBUG.handlePointerEvent:", {
			eventType,
			composedPath
		});
		const target = this.resolvePointerTarget(composedPath);
		debugLogIfEnabled(__debugPointerEvents, eventType, "FileDiff.DEBUG.handlePointerEvent: resolvePointerTarget result:", target);
		const { onLineClick, onLineNumberClick, onLineEnter, onLineLeave, onTokenClick, onTokenEnter, onTokenLeave, onHunkExpand, onMergeConflictActionClick } = this.options;
		switch (eventType) {
			case "move": {
				const sameLine = isHoverableLinePointerTarget(target) && this.hoveredLine?.lineElement === target.lineElement;
				if (!(isTokenPointerTarget(target) && this.hoveredToken?.tokenElement === target.tokenElement)) {
					if (this.hoveredToken != null) {
						onTokenLeave?.(this.hoveredToken, event);
						this.clearHoveredToken();
					}
					if (isTokenPointerTarget(target)) {
						this.setHoveredToken(this.toTokenEventBaseProps(target));
						onTokenEnter?.(this.hoveredToken, event);
					}
				}
				if (!sameLine) {
					if (this.hoveredLine != null) {
						onLineLeave?.({
							...this.hoveredLine,
							event
						});
						this.clearHoveredLine();
					}
					if (isHoverableLinePointerTarget(target)) {
						this.setHoveredLine(this.toEventBaseProps(target));
						this.placeUtility();
						onLineEnter?.({
							...this.hoveredLine,
							event
						});
					} else this.placeUtility();
				}
				break;
			}
			case "click": {
				if (target == null) break;
				if (isMergeConflictActionPointerTarget(target) && onMergeConflictActionClick != null) {
					onMergeConflictActionClick(target);
					break;
				}
				if (isExpandoPointerTarget(target) && onHunkExpand != null) {
					onHunkExpand(target.hunkIndex, target.all || event.shiftKey ? "both" : target.direction, target.all || event.shiftKey ? Number.POSITIVE_INFINITY : void 0);
					break;
				}
				if (!isHoverableLinePointerTarget(target)) break;
				if (isTokenPointerTarget(target) && onTokenClick != null) onTokenClick(this.toTokenEventBaseProps(target), event);
				const eventBase = this.toEventBaseProps(target);
				if (onLineNumberClick != null && target.numberColumn) onLineNumberClick({
					...eventBase,
					event
				});
				else if (onLineClick != null) onLineClick({
					...eventBase,
					event
				});
				break;
			}
		}
	}
	syncPointerListeners(pre) {
		const { __debugPointerEvents, lineHoverHighlight = "disabled", onLineClick, onLineNumberClick, onLineEnter, onLineLeave, onTokenClick, onTokenEnter, onTokenLeave, onHunkExpand, onMergeConflictActionClick, enableGutterUtility = false, enableLineSelection = false, onGutterUtilityClick } = this.options;
		const enableGutterSelection = onGutterUtilityClick != null;
		const shouldAttachPointerListeners = lineHoverHighlight !== "disabled" || onLineClick != null || onLineNumberClick != null || onLineEnter != null || onLineLeave != null || onTokenClick != null || onTokenEnter != null || onTokenLeave != null || onHunkExpand != null || onMergeConflictActionClick != null || enableGutterUtility || enableLineSelection || enableGutterSelection;
		if (shouldAttachPointerListeners && !this.hasPointerListeners) {
			pre.addEventListener("click", this.handlePointerClick);
			pre.addEventListener("pointerdown", this.handlePointerDown);
			pre.addEventListener("pointermove", this.handlePointerMove);
			pre.addEventListener("pointerleave", this.handlePointerLeave);
			this.hasPointerListeners = true;
			debugLogIfEnabled(__debugPointerEvents, "click", "FileDiff.DEBUG.attachEventListeners: Attaching click events for:", (() => {
				const reasons = [];
				if (__debugPointerEvents === "both" || __debugPointerEvents === "click") {
					if (onLineClick != null) reasons.push("onLineClick");
					if (onLineNumberClick != null) reasons.push("onLineNumberClick");
					if (onHunkExpand != null) reasons.push("expandable hunk separators");
					if (onMergeConflictActionClick != null) reasons.push("merge conflict actions");
				}
				return reasons;
			})());
			debugLogIfEnabled(__debugPointerEvents, "move", "FileDiff.DEBUG.attachEventListeners: Attaching pointer move event");
			debugLogIfEnabled(__debugPointerEvents, "move", "FileDiff.DEBUG.attachEventListeners: Attaching pointer leave event");
		} else if (!shouldAttachPointerListeners && this.hasPointerListeners) {
			pre.removeEventListener("click", this.handlePointerClick);
			pre.removeEventListener("pointerdown", this.handlePointerDown);
			pre.removeEventListener("pointermove", this.handlePointerMove);
			pre.removeEventListener("pointerleave", this.handlePointerLeave);
			this.hasPointerListeners = false;
		}
		const hasActiveLineSelectionSession = this.pointerSession.mode === "selecting" || this.pointerSession.mode === "pendingSingleLineUnselect";
		const hasActiveGutterSelectionSession = this.pointerSession.mode === "gutterSelecting";
		if (!enableLineSelection && hasActiveLineSelectionSession || !enableGutterSelection && hasActiveGutterSelectionSession) {
			this.clearPointerSession();
			this.detachDocumentPointerListeners();
			this.selectionAnchor = void 0;
			this.clearPendingSingleLineState();
		}
	}
	updateInteractiveLineAttributes() {
		if (this.pre == null) return;
		const { onLineClick, onLineNumberClick, enableLineSelection = false } = this.options;
		const shouldHaveInteractiveLines = onLineClick != null;
		const shouldHaveInteractiveLineNumbers = onLineNumberClick != null || enableLineSelection;
		if (shouldHaveInteractiveLines && !this.interactiveLinesAttr) {
			this.pre.setAttribute("data-interactive-lines", "");
			this.interactiveLinesAttr = true;
		} else if (!shouldHaveInteractiveLines && this.interactiveLinesAttr) {
			this.pre.removeAttribute("data-interactive-lines");
			this.interactiveLinesAttr = false;
		}
		if (shouldHaveInteractiveLineNumbers && !this.interactiveLineNumbersAttr) {
			this.pre.setAttribute("data-interactive-line-numbers", "");
			this.interactiveLineNumbersAttr = true;
		} else if (!shouldHaveInteractiveLineNumbers && this.interactiveLineNumbersAttr) {
			this.pre.removeAttribute("data-interactive-line-numbers");
			this.interactiveLineNumbersAttr = false;
		}
	}
	handlePointerDown = (event) => {
		if (event.pointerType === "mouse" && event.button !== 0 || this.pre == null || this.pointerSession.mode !== "idle") return;
		const path = event.composedPath();
		if (isGutterUtilityPath(path) && this.options.onGutterUtilityClick != null) this.startGutterSelectionFromPointerDown(event);
		else {
			if (event.pointerType !== "mouse") this.revealUtilityFromGutterPath(path);
			this.startLineSelectionFromPointerDown(event);
		}
	};
	startLineSelectionFromPointerDown(event) {
		const { enableLineSelection = false } = this.options;
		if (!enableLineSelection) return;
		const pointerInfo = this.resolveSelectionInfo(event, {
			source: "event-path",
			requireNumberColumn: true
		});
		if (pointerInfo == null) return;
		const { pre } = this;
		if (pre == null) return;
		const { lineNumber, eventSide, lineIndex } = pointerInfo;
		if (event.shiftKey && this.selectedRange != null) {
			const rowRange = this.getIndexesFromSelection(this.selectedRange, pre.getAttribute("data-diff-type") === "split");
			if (rowRange == null) return;
			const useStart = rowRange.start <= rowRange.end ? lineIndex >= rowRange.start : lineIndex <= rowRange.end;
			this.selectionAnchor = {
				lineNumber: useStart ? this.selectedRange.start : this.selectedRange.end,
				side: useStart ? this.selectedRange.side : this.selectedRange.endSide ?? this.selectedRange.side
			};
			this.updateSelection(lineNumber, eventSide, false);
			this.notifySelectionStart(this.getCurrentSelectionRange());
			this.pointerSession = {
				mode: "selecting",
				pointerId: event.pointerId
			};
			this.attachDocumentPointerListeners();
			return;
		}
		if (this.selectedRange?.start === lineNumber && this.selectedRange?.end === lineNumber) {
			const point = {
				lineNumber,
				side: eventSide
			};
			this.selectionAnchor = point;
			this.pointerSession = {
				mode: "pendingSingleLineUnselect",
				pointerId: event.pointerId,
				anchor: point,
				pending: point
			};
			this.attachDocumentPointerListeners();
			return;
		}
		if (this.options.controlledSelection === true) this.proposedSelectedRange = null;
		else this.selectedRange = null;
		this.placeUtility();
		this.selectionAnchor = {
			lineNumber,
			side: eventSide
		};
		this.updateSelection(lineNumber, eventSide, false);
		this.notifySelectionStart(this.getCurrentSelectionRange());
		this.pointerSession = {
			mode: "selecting",
			pointerId: event.pointerId
		};
		this.attachDocumentPointerListeners();
	}
	startGutterSelectionFromPointerDown(event) {
		const { onGutterUtilityClick } = this.options;
		if (onGutterUtilityClick == null) return;
		const selectedEndpoints = this.currentSelectionEnds();
		const point = selectedEndpoints?.bottom ?? this.resolveSelectionPoint(event, {
			source: "event-path",
			excludeUtility: false
		});
		const anchor = selectedEndpoints?.top ?? point;
		if (point == null || anchor == null) return;
		event.preventDefault();
		event.stopPropagation();
		this.pointerSession = {
			mode: "gutterSelecting",
			pointerId: event.pointerId,
			anchor,
			current: point
		};
		this.selectionAnchor = {
			lineNumber: anchor.lineNumber,
			side: anchor.side
		};
		this.updateSelection(point.lineNumber, point.side, false);
		this.notifySelectionStart(this.getCurrentSelectionRange());
		this.attachDocumentPointerListeners();
	}
	handleDocumentPointerMove = (event) => {
		switch (this.pointerSession.mode) {
			case "idle": return;
			case "gutterSelecting": {
				if (event.pointerId !== this.pointerSession.pointerId) return;
				event.preventDefault();
				const point = this.resolveSelectionPoint(event, { source: "coordinates-first" });
				if (point == null) return;
				this.pointerSession.current = point;
				this.updateSelection(point.lineNumber, point.side);
				return;
			}
			case "selecting": {
				if (event.pointerId !== this.pointerSession.pointerId) return;
				event.preventDefault();
				const pointerInfo = this.resolveSelectionInfo(event, {
					source: "coordinates-first",
					requireNumberColumn: false
				});
				if (pointerInfo == null || this.selectionAnchor == null) return;
				this.updateSelection(pointerInfo.lineNumber, pointerInfo.eventSide);
				return;
			}
			case "pendingSingleLineUnselect": {
				if (event.pointerId !== this.pointerSession.pointerId) return;
				event.preventDefault();
				const pointerInfo = this.resolveSelectionInfo(event, {
					source: "coordinates-first",
					requireNumberColumn: false
				});
				if (pointerInfo == null || this.selectionAnchor == null) return;
				const point = {
					lineNumber: pointerInfo.lineNumber,
					side: pointerInfo.eventSide
				};
				if (areSelectionPointsEqual(this.pointerSession.pending, point)) return;
				this.updateSelection(pointerInfo.lineNumber, pointerInfo.eventSide, false);
				this.notifySelectionStart(this.getCurrentSelectionRange());
				this.notifySelectionChangeDelta();
				this.pointerSession = {
					mode: "selecting",
					pointerId: event.pointerId
				};
				return;
			}
		}
	};
	handleDocumentPointerUp = (event) => {
		const { onGutterUtilityClick } = this.options;
		switch (this.pointerSession.mode) {
			case "idle": return;
			case "gutterSelecting": {
				const { pointerSession: session } = this;
				if (event.pointerId !== session.pointerId) return;
				event.preventDefault();
				const point = this.resolveSelectionPoint(event, { source: "coordinates-first" });
				if (point != null) {
					session.current = point;
					this.updateSelection(point.lineNumber, point.side);
				}
				const completedRange = this.buildSelectedLineRange(session.anchor, session.current);
				onGutterUtilityClick?.({ ...completedRange });
				this.selectionAnchor = void 0;
				this.notifySelectionEnd(completedRange);
				this.notifySelectionCommitted(completedRange);
				this.clearProposedSelection();
				this.clearPointerSession();
				this.detachDocumentPointerListeners();
				return;
			}
			case "pendingSingleLineUnselect":
				if (event.pointerId !== this.pointerSession.pointerId) return;
				event.preventDefault();
				this.updateSelection(null, void 0, false);
				this.selectionAnchor = void 0;
				this.clearPendingSingleLineState();
				this.detachDocumentPointerListeners();
				this.notifySelectionEnd(this.getCurrentSelectionRange());
				this.notifySelectionCommitted(this.getCurrentSelectionRange());
				this.clearProposedSelection();
				return;
			case "selecting":
				if (event.pointerId !== this.pointerSession.pointerId) return;
				event.preventDefault();
				this.selectionAnchor = void 0;
				this.detachDocumentPointerListeners();
				this.clearPointerSession();
				this.notifySelectionEnd(this.getCurrentSelectionRange());
				this.notifySelectionCommitted(this.getCurrentSelectionRange());
				this.clearProposedSelection();
		}
	};
	handleDocumentPointerCancel = (event) => {
		switch (this.pointerSession.mode) {
			case "idle": return;
			case "gutterSelecting":
			case "selecting":
			case "pendingSingleLineUnselect":
				if ("pointerId" in this.pointerSession) {
					if (event.pointerId !== this.pointerSession.pointerId) return;
				}
				this.selectionAnchor = void 0;
				this.clearProposedSelection();
				this.clearPendingSingleLineState();
				this.clearPointerSession();
				this.detachDocumentPointerListeners();
		}
	};
	clearHoveredLine() {
		if (this.hoveredLine == null) return;
		this.hoveredLine.lineElement.removeAttribute("data-hovered");
		this.hoveredLine.numberElement.removeAttribute("data-hovered");
		this.hoveredLine = void 0;
	}
	setHoveredLine(hoveredLine) {
		const { lineHoverHighlight = "disabled" } = this.options;
		if (this.hoveredLine != null) this.clearHoveredLine();
		this.hoveredLine = hoveredLine;
		if (lineHoverHighlight !== "disabled") {
			if (lineHoverHighlight === "both" || lineHoverHighlight === "line") this.hoveredLine.lineElement.setAttribute("data-hovered", "");
			if (lineHoverHighlight === "both" || lineHoverHighlight === "number") this.hoveredLine.numberElement.setAttribute("data-hovered", "");
		}
	}
	clearHoveredToken() {
		if (this.hoveredToken == null) return;
		this.hoveredToken = void 0;
	}
	setHoveredToken(hoveredToken) {
		if (this.hoveredToken != null) this.clearHoveredToken();
		this.hoveredToken = hoveredToken;
	}
	ensureGutterUtilityNode(useCustomGutterUtility) {
		if (this.gutterUtilityContainer == null) {
			this.gutterUtilityContainer = document.createElement("div");
			this.gutterUtilityContainer.setAttribute("data-gutter-utility-slot", "");
		}
		if (useCustomGutterUtility) {
			if (this.gutterUtilityButton != null) {
				this.gutterUtilityButton.remove();
				this.gutterUtilityButton = void 0;
			}
			if (this.gutterUtilitySlot == null) {
				this.gutterUtilitySlot = document.createElement("slot");
				this.gutterUtilitySlot.name = "gutter-utility-slot";
			}
			if (this.gutterUtilitySlot.parentNode !== this.gutterUtilityContainer) this.gutterUtilityContainer.replaceChildren(this.gutterUtilitySlot);
		} else {
			this.gutterUtilitySlot?.remove();
			this.gutterUtilitySlot = void 0;
			if (this.gutterUtilityButton == null) {
				const tempDiv = document.createElement("div");
				tempDiv.innerHTML = toHtml(createGutterUtilityElement());
				const utilityButton = tempDiv.firstElementChild;
				if (!(utilityButton instanceof HTMLButtonElement)) throw new Error("InteractionManager.ensureGutterUtilityNode: Node element should be a button");
				utilityButton.remove();
				this.gutterUtilityButton = utilityButton;
			}
			if (this.gutterUtilityButton.parentNode !== this.gutterUtilityContainer) this.gutterUtilityContainer.replaceChildren(this.gutterUtilityButton);
		}
	}
	revealUtilityFromGutterPath(path) {
		if (this.placeUtilityFromSelection()) return;
		const target = this.resolvePointerTarget(path);
		if (isLinePointerTarget(target) && target.numberColumn) this.showUtilityOnLine(this.toEventBaseProps(target));
	}
	placeUtility() {
		if (this.placeUtilityFromSelection()) return;
		if (this.hoveredLine != null) {
			this.showUtilityOnLine(this.hoveredLine);
			return;
		}
		this.hideUtility();
	}
	placeUtilityFromSelection() {
		const endpoints = this.currentSelectionEnds();
		if (endpoints == null) return false;
		const target = this.targetForSelectionPoint(endpoints.bottom);
		if (target == null) this.hideUtility();
		else this.showUtilityOnLine(this.toEventBaseProps(target));
		return true;
	}
	showUtilityOnLine(line) {
		if (this.gutterUtilityContainer == null) return;
		this.gutterUtilityLine = line;
		line.numberElement.appendChild(this.gutterUtilityContainer);
	}
	hideUtility() {
		this.gutterUtilityContainer?.remove();
		this.gutterUtilityLine = void 0;
	}
	currentSelectionEnds() {
		const range = this.getCurrentSelectionRange();
		return range == null ? void 0 : this.selectionEnds(range);
	}
	selectionEnds(range) {
		const start = {
			lineNumber: range.start,
			side: range.side
		};
		const end = {
			lineNumber: range.end,
			side: range.endSide ?? range.side
		};
		const startIndex = this.selectionPointRowIndex(start);
		const endIndex = this.selectionPointRowIndex(end);
		if (startIndex == null || endIndex == null) return;
		return startIndex > endIndex ? {
			top: end,
			bottom: start
		} : {
			top: start,
			bottom: end
		};
	}
	selectionPointRowIndex(point) {
		const indexes = this.getLineIndex(point.lineNumber, point.side);
		if (indexes == null) return;
		return this.isSplitDiff() ? indexes[1] : indexes[0];
	}
	targetForSelectionPoint(point) {
		if (this.pre == null) return;
		const indexes = this.getLineIndex(point.lineNumber, point.side);
		if (indexes == null) return;
		const lineIndex = this.mode === "diff" ? `${indexes[0]},${indexes[1]}` : `${indexes[0]}`;
		const candidates = this.pre.querySelectorAll(`[data-column-number="${point.lineNumber}"][data-line-index="${lineIndex}"]`);
		for (const element of candidates) {
			if (!(element instanceof HTMLElement)) continue;
			const target = this.resolvePointerTarget(getElementPath(element));
			if (!isLinePointerTarget(target)) continue;
			if (this.mode === "diff" && point.side != null && target.side !== point.side) continue;
			return target;
		}
	}
	attachDocumentPointerListeners() {
		if (this.hasDocumentPointerListeners) return;
		document.addEventListener("pointermove", this.handleDocumentPointerMove);
		document.addEventListener("pointerup", this.handleDocumentPointerUp);
		document.addEventListener("pointercancel", this.handleDocumentPointerCancel);
		this.hasDocumentPointerListeners = true;
	}
	detachDocumentPointerListeners() {
		if (!this.hasDocumentPointerListeners) return;
		document.removeEventListener("pointermove", this.handleDocumentPointerMove);
		document.removeEventListener("pointerup", this.handleDocumentPointerUp);
		document.removeEventListener("pointercancel", this.handleDocumentPointerCancel);
		this.hasDocumentPointerListeners = false;
	}
	clearPointerSession() {
		this.pointerSession = { mode: "idle" };
	}
	clearPendingSingleLineState() {
		if (this.pointerSession.mode === "pendingSingleLineUnselect") this.pointerSession = { mode: "idle" };
	}
	selectionInfoFromPath(path, requireNumberColumn) {
		const target = this.resolvePointerTarget(path);
		if (!isLinePointerTarget(target)) return;
		if (requireNumberColumn && !target.numberColumn) return;
		if (target.splitLineIndex == null) return;
		return {
			lineIndex: target.splitLineIndex,
			lineNumber: target.lineNumber,
			eventSide: this.mode === "diff" ? target.side : void 0
		};
	}
	resolveSelectionInfo(event, options) {
		const path = this.resolveSelectionPath(event, options);
		return path != null ? this.selectionInfoFromPath(path, options.requireNumberColumn) : void 0;
	}
	selectionPointFromPath(path) {
		const target = this.resolvePointerTarget(path);
		if (!isLinePointerTarget(target)) return;
		return {
			lineNumber: target.lineNumber,
			side: this.mode === "diff" ? target.side : void 0
		};
	}
	resolveSelectionPoint(event, options) {
		const path = this.resolveSelectionPath(event, options);
		return path != null ? this.selectionPointFromPath(path) : void 0;
	}
	resolveSelectionPath(event, options) {
		const excludeUtility = options.excludeUtility !== false;
		switch (options.source) {
			case "event-path": return this.pathFromEventPath(event.composedPath(), excludeUtility);
			case "coordinates-first": {
				const coordinatePath = this.pathFromCoordinates(event, excludeUtility);
				if (coordinatePath !== void 0) return coordinatePath ?? void 0;
				return this.pathFromEventPath(event.composedPath(), excludeUtility);
			}
		}
	}
	pathFromCoordinates(event, excludeUtility) {
		const coordinateTarget = this.hitTest(event);
		if (coordinateTarget === void 0) return;
		if (coordinateTarget === null) return null;
		return this.pathFromElement(coordinateTarget, excludeUtility) ?? null;
	}
	pathFromEventPath(path, excludeUtility) {
		if (excludeUtility && isGutterUtilityPath(path)) return;
		for (const element of path) if (element instanceof Element) return this.pathFromElement(element, excludeUtility);
	}
	pathFromElement(element, excludeUtility) {
		const path = getElementPath(element);
		if (excludeUtility && isGutterUtilityPath(path)) return;
		const row = closestSelectableRow(element);
		if (row != null) return getElementPath(row);
		return this.pathFromAnnotationSlot(element);
	}
	pathFromAnnotationSlot(element) {
		const point = selectionPointFromAnnotationSlotName(getAnnotationSlotName(element));
		if (point == null) return;
		const target = this.targetForSelectionPoint(point);
		return target != null ? getElementPath(target.lineElement) : void 0;
	}
	hitTest(event) {
		if (!Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return;
		const root = this.pre?.getRootNode();
		const elementFromPointRoot = hasElementFromPoint(root) ? root : hasElementFromPoint(document) ? document : void 0;
		if (elementFromPointRoot == null) return;
		return elementFromPointRoot.elementFromPoint(event.clientX, event.clientY);
	}
	getLineIndex(lineNumber, side) {
		const { getLineIndex } = this.options;
		return getLineIndex != null ? getLineIndex(lineNumber, side) : [lineNumber - 1, lineNumber - 1];
	}
	getCurrentSelectionRange() {
		return this.proposedSelectedRange !== void 0 ? this.proposedSelectedRange : this.selectedRange;
	}
	clearProposedSelection() {
		this.proposedSelectedRange = void 0;
	}
	updateSelection(currentLine, side, emitChange = true) {
		const previousRange = this.getCurrentSelectionRange();
		let nextRange;
		if (currentLine == null) nextRange = null;
		else {
			const anchorSide = this.selectionAnchor?.side ?? side;
			const anchorLine = this.selectionAnchor?.lineNumber ?? currentLine;
			nextRange = this.buildSelectionRange(anchorLine, currentLine, anchorSide, side);
		}
		if (areSelectionsEqual(previousRange ?? void 0, nextRange ?? void 0)) return;
		this.selectedRangeHighlightSide = void 0;
		this.selectedRangeLineNumberOnly = false;
		if (this.options.controlledSelection === true) this.proposedSelectedRange = nextRange;
		else {
			this.selectedRange = nextRange;
			queueRender(this.renderSelection);
		}
		this.placeUtility();
		if (emitChange) this.notifySelectionChangeDelta();
	}
	getIndexesFromSelection(selectedRange, split) {
		if (this.pre == null) return;
		const startIndexes = this.getLineIndex(selectedRange.start, selectedRange.side);
		const finalIndexes = this.getLineIndex(selectedRange.end, selectedRange.endSide ?? selectedRange.side);
		return startIndexes != null && finalIndexes != null ? {
			start: split ? startIndexes[1] : startIndexes[0],
			end: split ? finalIndexes[1] : finalIndexes[0]
		} : void 0;
	}
	getSelectionRenderState() {
		return {
			selectedLines: {
				range: this.selectedRange,
				highlightSide: this.selectedRangeHighlightSide,
				lineNumberOnly: this.selectedRangeLineNumberOnly
			},
			editorActiveLine: {
				range: this.editorActiveLine == null ? null : {
					start: this.editorActiveLine,
					end: this.editorActiveLine,
					side: this.editorActiveLineSide
				},
				highlightSide: this.editorActiveLineSide,
				lineNumberOnly: this.editorLineNumberOnly
			}
		};
	}
	resolveLineRenderRange(state, split, source) {
		if (state.range == null) return;
		const rowRange = this.getIndexesFromSelection(state.range, split);
		if (rowRange == null) {
			console.error({
				rowRange,
				range: state.range
			});
			throw new Error(`InteractionManager.renderSelection: No valid ${source} rowRange`);
		}
		return rowRange;
	}
	getLineRenderColumns(selectedLines, selectedRowRange, editorActiveLine, editorRowRange) {
		if (this.pre == null || selectedRowRange == null && editorRowRange == null) return [];
		const { children: codeElements } = this.pre;
		if (codeElements.length > 2) {
			console.error(codeElements);
			throw new Error("InteractionManager.renderSelection: Somehow there are more than 2 code elements...");
		}
		const columns = [];
		for (const code of codeElements) {
			const side = code.hasAttribute("data-deletions") ? "deletions" : code.hasAttribute("data-additions") ? "additions" : void 0;
			const renderSelectedLines = selectedLines != null && selectedRowRange != null && (selectedLines.highlightSide == null || side == null || selectedLines.highlightSide === side);
			const renderEditorActiveLine = editorActiveLine != null && editorRowRange != null && (editorActiveLine.highlightSide == null || side == null || editorActiveLine.highlightSide === side);
			if (!renderSelectedLines && !renderEditorActiveLine) continue;
			const [gutter, content] = code.children;
			if (!(gutter instanceof HTMLElement) || !(content instanceof HTMLElement)) throw new Error("InteractionManager.renderSelection: missing gutter or content element");
			if (content.children.length !== gutter.children.length) throw new Error("InteractionManager.renderSelection: gutter and content children dont match, something is wrong");
			columns.push({
				content,
				gutter,
				renderEditorActiveLine,
				renderSelectedLines
			});
		}
		return columns;
	}
	renderSelection = () => {
		dequeueRender(this.renderSelection);
		const renderState = this.getSelectionRenderState();
		if (this.pre == null) return;
		const { editorActiveLine, selectedLines } = renderState;
		const selectedLinesChanged = !areLineRenderStatesEqual(this.renderedSelectedLinesState, selectedLines);
		const editorActiveLineChanged = !areLineRenderStatesEqual(this.renderedEditorActiveLineState, editorActiveLine);
		if (!selectedLinesChanged && !editorActiveLineChanged) return;
		if (selectedLinesChanged) this.renderedSelectedLinesState = void 0;
		if (editorActiveLineChanged) this.renderedEditorActiveLineState = void 0;
		const split = this.pre.getAttribute("data-diff-type") === "split";
		const selectedRowRange = !selectedLinesChanged ? void 0 : this.resolveLineRenderRange(selectedLines, split, "selected-lines");
		const editorRowRange = !editorActiveLineChanged ? void 0 : this.resolveLineRenderRange(editorActiveLine, split, "editor-active-line");
		const columns = this.getLineRenderColumns(selectedLinesChanged ? selectedLines : void 0, selectedRowRange, editorActiveLineChanged ? editorActiveLine : void 0, editorRowRange);
		const selectedLinesComplete = selectedLines.range == null || columns.some((column) => column.renderSelectedLines);
		const editorActiveLineComplete = editorActiveLine.range == null || columns.some((column) => column.renderEditorActiveLine);
		if (selectedLinesChanged) for (const element of this.pre.querySelectorAll("[data-selected-line]")) element.removeAttribute("data-selected-line");
		if (editorActiveLineChanged) for (const element of this.pre.querySelectorAll("[data-editor-active-line]")) element.removeAttribute("data-editor-active-line");
		const selectedFirst = selectedRowRange == null ? void 0 : Math.min(selectedRowRange.start, selectedRowRange.end);
		const selectedLast = selectedRowRange == null ? void 0 : Math.max(selectedRowRange.start, selectedRowRange.end);
		const selectedIsSingle = selectedFirst === selectedLast;
		const editorLineIndex = editorRowRange?.start;
		for (const column of columns) {
			const { content, gutter, renderEditorActiveLine, renderSelectedLines } = column;
			const finalLineIndex = Math.max(renderSelectedLines ? selectedLast ?? -Infinity : -Infinity, renderEditorActiveLine ? editorLineIndex ?? -Infinity : -Infinity);
			const len = content.children.length;
			for (let i = 0; i < len; i++) {
				const contentElement = content.children[i];
				const gutterElement = gutter.children[i];
				if (!(contentElement instanceof HTMLElement) || !(gutterElement instanceof HTMLElement)) continue;
				const lineIndex = this.parseLineIndex(contentElement, split);
				if ((lineIndex ?? 0) > finalLineIndex) break;
				if (lineIndex == null) continue;
				if (renderSelectedLines && selectedFirst != null && selectedLast != null && lineIndex >= selectedFirst && lineIndex <= selectedLast) {
					let attributeValue = selectedIsSingle ? "single" : lineIndex === selectedFirst ? "first" : lineIndex === selectedLast ? "last" : "";
					gutterElement.setAttribute("data-selected-line", attributeValue);
					if (!selectedLines.lineNumberOnly) {
						contentElement.setAttribute("data-selected-line", attributeValue);
						if (gutterElement.nextSibling instanceof HTMLElement && contentElement.nextSibling instanceof HTMLElement && (contentElement.nextSibling.hasAttribute("data-line-annotation") || contentElement.nextSibling.hasAttribute("data-merge-conflict-actions"))) {
							if (selectedIsSingle) {
								attributeValue = "last";
								contentElement.setAttribute("data-selected-line", "first");
							} else if (lineIndex === selectedFirst) attributeValue = "";
							else if (lineIndex === selectedLast) contentElement.setAttribute("data-selected-line", "");
							contentElement.nextSibling.setAttribute("data-selected-line", attributeValue);
							gutterElement.nextSibling.setAttribute("data-selected-line", attributeValue);
						}
					}
				}
				if (renderEditorActiveLine && lineIndex === editorLineIndex) {
					gutterElement.setAttribute("data-editor-active-line", "");
					if (!editorActiveLine.lineNumberOnly) contentElement.setAttribute("data-editor-active-line", "");
				}
			}
		}
		if (selectedLinesChanged && selectedLinesComplete) this.renderedSelectedLinesState = selectedLines;
		if (editorActiveLineChanged && editorActiveLineComplete) this.renderedEditorActiveLineState = editorActiveLine;
	};
	notifySelectionCommitted(range) {
		this.options.onLineSelected?.(range);
	}
	notifySelectionChangeDelta() {
		this.options.onLineSelectionChange?.(this.getCurrentSelectionRange() ?? null);
	}
	notifySelectionStart(range) {
		this.options.onLineSelectionStart?.(range);
	}
	notifySelectionEnd(range) {
		this.options.onLineSelectionEnd?.(range);
	}
	toEventBaseProps(target) {
		if (this.mode === "file") return {
			type: "line",
			lineElement: target.lineElement,
			lineNumber: target.lineNumber,
			numberColumn: target.numberColumn,
			numberElement: target.numberElement
		};
		return {
			type: "diff-line",
			annotationSide: target.side,
			lineType: target.lineType,
			lineElement: target.lineElement,
			numberElement: target.numberElement,
			lineNumber: target.lineNumber,
			numberColumn: target.numberColumn
		};
	}
	toTokenEventBaseProps({ lineCharEnd, lineCharStart, lineNumber, side, tokenElement, tokenText }) {
		if (this.mode === "file") return {
			type: "token",
			lineCharEnd,
			lineCharStart,
			lineNumber,
			tokenElement,
			tokenText
		};
		return {
			type: "token",
			lineCharEnd,
			lineCharStart,
			lineNumber,
			side,
			tokenElement,
			tokenText
		};
	}
	buildSelectedLineRange(anchor, current) {
		return this.buildSelectionRange(anchor.lineNumber, current.lineNumber, anchor.side, current.side);
	}
	buildSelectionRange(start, end, side, endSide) {
		return {
			start,
			end,
			...side != null ? { side } : {},
			...side !== endSide && endSide != null ? { endSide } : {}
		};
	}
	resolvePointerTarget(path) {
		let numberColumn = false;
		let lineType;
		let codeElement;
		let lineElement;
		let lineIndexValue;
		let numberElement;
		let tokenElement;
		let tokenInfo;
		let expandInfo;
		let lineNumber;
		let mergeConflictActionTarget;
		for (const element of path) {
			if (!(element instanceof HTMLElement)) continue;
			if (mergeConflictActionTarget == null && element.hasAttribute("data-merge-conflict-action")) {
				const resolutionValue = element.getAttribute("data-merge-conflict-action") ?? void 0;
				const conflictIndexValue = element.getAttribute("data-merge-conflict-conflict-index") ?? void 0;
				const conflictIndex = conflictIndexValue != null ? Number.parseInt(conflictIndexValue, 10) : NaN;
				if (isMergeConflictResolution(resolutionValue) && Number.isFinite(conflictIndex)) mergeConflictActionTarget = {
					kind: "merge-conflict-action",
					resolution: resolutionValue,
					conflictIndex
				};
			}
			if (tokenElement == null && element.hasAttribute("data-char")) {
				tokenElement = element;
				const startAttr = element.getAttribute("data-char");
				if (startAttr != null) {
					const lineCharStart = Number.parseInt(startAttr, 10);
					if (!Number.isNaN(lineCharStart)) {
						const tokenText = element.textContent ?? "";
						const lineCharEnd = lineCharStart + tokenText.length;
						if (tokenText.trim() !== "" || this.options.enableTokenInteractionsOnWhitespace === true) tokenInfo = {
							tokenElement,
							lineCharStart,
							lineCharEnd,
							tokenText
						};
						continue;
					}
				}
			}
			const columnNumber = numberElement == null ? element.getAttribute("data-column-number") ?? void 0 : void 0;
			if (columnNumber != null) {
				numberElement = element;
				lineNumber = Number.parseInt(columnNumber, 10);
				numberColumn = true;
				lineType = getLineTypeFromElement(element);
				lineIndexValue = element.getAttribute("data-line-index") ?? void 0;
				continue;
			}
			const lineAttr = lineElement == null ? element.getAttribute("data-line") ?? void 0 : void 0;
			if (lineAttr != null) {
				lineElement = element;
				lineNumber = Number.parseInt(lineAttr, 10);
				lineType = getLineTypeFromElement(element);
				lineIndexValue = element.getAttribute("data-line-index") ?? void 0;
				continue;
			}
			if (expandInfo == null && (element.hasAttribute("data-expand-button") || element.hasAttribute("data-unmodified-lines"))) {
				expandInfo = {
					hunkIndex: void 0,
					direction: (() => {
						if (element.hasAttribute("data-expand-up")) return "up";
						if (element.hasAttribute("data-expand-down")) return "down";
						return "both";
					})(),
					all: element.hasAttribute("data-expand-all-button")
				};
				continue;
			}
			const expandIndexValue = expandInfo != null ? element.getAttribute("data-expand-index") ?? void 0 : void 0;
			if (expandInfo != null && expandIndexValue != null) {
				const expandIndex = Number.parseInt(expandIndexValue, 10);
				if (!Number.isNaN(expandIndex)) expandInfo.hunkIndex = expandIndex;
				continue;
			}
			if (codeElement == null && element.hasAttribute("data-code")) {
				codeElement = element;
				break;
			}
		}
		if (mergeConflictActionTarget != null) return mergeConflictActionTarget;
		if (expandInfo?.hunkIndex != null) return {
			type: "line-info",
			hunkIndex: expandInfo.hunkIndex,
			direction: expandInfo.direction,
			all: expandInfo.all
		};
		lineElement ??= lineIndexValue != null ? queryHTMLElement(codeElement, `[data-line][data-line-index="${lineIndexValue}"]`) : void 0;
		numberElement ??= lineIndexValue != null ? queryHTMLElement(codeElement, `[data-column-number][data-line-index="${lineIndexValue}"]`) : void 0;
		if (codeElement == null || lineElement == null || numberElement == null || lineType == null || lineNumber == null || Number.isNaN(lineNumber)) return;
		const splitLineIndex = this.parseLineIndex(lineElement, this.isSplitDiff());
		if (tokenInfo != null) {
			if (this.mode === "file") return {
				kind: "token",
				lineType,
				lineElement,
				lineNumber,
				numberColumn,
				numberElement,
				side: void 0,
				splitLineIndex,
				...tokenInfo
			};
			return {
				kind: "token",
				lineType,
				lineElement,
				lineNumber,
				numberColumn,
				numberElement,
				side: getAnnotationSide(lineType, codeElement),
				splitLineIndex,
				...tokenInfo
			};
		}
		if (this.mode === "file") return {
			kind: "line",
			lineType,
			lineElement,
			lineNumber,
			numberColumn,
			numberElement,
			side: void 0,
			splitLineIndex
		};
		return {
			kind: "line",
			lineType,
			lineElement,
			lineNumber,
			numberColumn,
			numberElement,
			side: getAnnotationSide(lineType, codeElement),
			splitLineIndex
		};
	}
	isSplitDiff() {
		return this.pre?.getAttribute("data-diff-type") === "split";
	}
	parseLineIndex(element, split) {
		const lineIndexes = (element.getAttribute("data-line-index") ?? "").split(",").map((value) => Number.parseInt(value, 10)).filter((value) => !Number.isNaN(value));
		if (split && lineIndexes.length === 2) return lineIndexes[1];
		if (!split) return lineIndexes[0];
	}
};
function pluckInteractionOptions({ enableTokenInteractionsOnWhitespace, enableGutterUtility, lineHoverHighlight, onGutterUtilityClick, onLineClick, onLineEnter, onLineLeave, onLineNumberClick, onTokenClick, onTokenEnter, onTokenLeave, renderGutterUtility, __debugPointerEvents, enableLineSelection, controlledSelection, onLineSelected, onLineSelectionStart, onLineSelectionChange, onLineSelectionEnd }, onHunkExpand, getLineIndex, onMergeConflictActionClick) {
	return {
		enableTokenInteractionsOnWhitespace,
		enableGutterUtility: resolveEnableGutterUtilityOption({
			enableGutterUtility,
			renderGutterUtility,
			onGutterUtilityClick
		}),
		usesCustomGutterUtility: renderGutterUtility != null,
		lineHoverHighlight,
		onGutterUtilityClick,
		onHunkExpand,
		onMergeConflictActionClick,
		onLineClick,
		onLineEnter,
		onLineLeave,
		onLineNumberClick,
		onTokenClick,
		onTokenEnter,
		onTokenLeave,
		__debugPointerEvents,
		enableLineSelection,
		controlledSelection,
		onLineSelected,
		onLineSelectionStart,
		onLineSelectionChange,
		onLineSelectionEnd,
		getLineIndex
	};
}
function resolveEnableGutterUtilityOption({ enableGutterUtility, renderGutterUtility, onGutterUtilityClick }) {
	if (onGutterUtilityClick != null && renderGutterUtility != null) throw new Error("Cannot use both 'onGutterUtilityClick' and 'renderGutterUtility'. Use only one gutter utility API.");
	return enableGutterUtility ?? false;
}
function isLinePointerTarget(target) {
	return target != null && "kind" in target && target.kind === "line";
}
function isTokenPointerTarget(target) {
	return target != null && "kind" in target && target.kind === "token";
}
function isHoverableLinePointerTarget(target) {
	return isLinePointerTarget(target) || isTokenPointerTarget(target);
}
function isExpandoPointerTarget(target) {
	return "type" in target && target.type === "line-info";
}
function isMergeConflictActionPointerTarget(target) {
	return "kind" in target && target.kind === "merge-conflict-action";
}
function isMergeConflictResolution(value) {
	return value === "current" || value === "incoming" || value === "both";
}
function queryHTMLElement(parent, query) {
	const element = parent?.querySelector(query);
	return element instanceof HTMLElement ? element : void 0;
}
function getElementPath(element) {
	const path = [];
	let current = element;
	while (current != null) {
		path.push(current);
		current = current.parentNode;
	}
	return path;
}
function closestSelectableRow(element) {
	const row = element.closest("[data-line], [data-column-number]");
	if (row instanceof HTMLElement) return row;
	const annotationRow = element.closest("[data-line-annotation], [data-gutter-buffer=\"annotation\"]");
	if (!(annotationRow instanceof HTMLElement)) return;
	const previousRow = annotationRow.previousElementSibling;
	return previousRow instanceof HTMLElement && (previousRow.hasAttribute("data-line") || previousRow.hasAttribute("data-column-number")) ? previousRow : void 0;
}
function getAnnotationSlotName(element) {
	const slottedElement = element.closest("[slot^=\"annotation-\"]");
	if (slottedElement instanceof HTMLElement) return slottedElement.getAttribute("slot") ?? void 0;
	if (element instanceof HTMLElement) {
		const slotName = element.getAttribute("name") ?? void 0;
		return slotName != null && slotName.startsWith("annotation-") ? slotName : void 0;
	}
}
function selectionPointFromAnnotationSlotName(slotName) {
	if (slotName == null) return;
	const match = /^annotation-(?:(additions|deletions)-)?(\d+)$/.exec(slotName);
	if (match == null) return;
	const lineNumber = Number.parseInt(match[2], 10);
	if (!Number.isFinite(lineNumber) || lineNumber <= 0) return;
	return {
		lineNumber,
		side: match[1]
	};
}
function hasElementFromPoint(value) {
	return value != null && typeof value.elementFromPoint === "function";
}
function areSelectionRangesEqual(first, second) {
	return first === second || areSelectionsEqual(first ?? void 0, second ?? void 0);
}
function areLineRenderStatesEqual(first, second) {
	return first?.highlightSide === second.highlightSide && first?.lineNumberOnly === second.lineNumberOnly && areSelectionRangesEqual(first?.range ?? null, second.range);
}
function getAnnotationSide(lineType, codeElement) {
	switch (lineType) {
		case "change-deletion": return "deletions";
		case "change-addition": return "additions";
		default: return codeElement.hasAttribute("data-deletions") ? "deletions" : "additions";
	}
}
function getLineTypeFromElement(element) {
	const lineType = element.getAttribute("data-line-type");
	if (lineType == null) return;
	switch (lineType) {
		case "change-deletion":
		case "change-addition":
		case "context":
		case "context-expanded": return lineType;
		default: return;
	}
}
function debugLogIfEnabled(debugLogType = "none", logIfType, ...args) {
	switch (debugLogType) {
		case "none": return;
		case "both": break;
		case "click":
			if (logIfType !== "click") return;
			break;
		case "move":
			if (logIfType !== "move") return;
			break;
	}
	console.log(...args);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/managers/ResizeManager.js
var ResizeManager = class ResizeManager {
	static resizeObserver;
	static managersByElement = /* @__PURE__ */ new Map();
	static getResizeObserver() {
		const resizeObserver = ResizeManager.resizeObserver ?? new ResizeObserver(ResizeManager.handleSharedResizeEntries);
		ResizeManager.resizeObserver = resizeObserver;
		return resizeObserver;
	}
	static handleSharedResizeEntries(entries) {
		const entriesByManager = /* @__PURE__ */ new Map();
		for (const entry of entries) {
			const manager = ResizeManager.managersByElement.get(entry.target);
			if (manager == null) continue;
			const managerEntries = entriesByManager.get(manager);
			if (managerEntries == null) entriesByManager.set(manager, [entry]);
			else managerEntries.push(entry);
		}
		for (const [manager, managerEntries] of entriesByManager) manager.handleResizeEntries(managerEntries);
	}
	observedNodes = /* @__PURE__ */ new Map();
	setup(pre, { disableAnnotations, columnVariables = "apply" }) {
		const annotationUpdates = /* @__PURE__ */ new Set();
		const applyColumnVariables = columnVariables === "apply";
		let columnCount = 0;
		const observedNodes = new Map(this.observedNodes);
		this.observedNodes.clear();
		for (const element of pre.children) {
			if (columnCount === 2) break;
			const codeElement = (() => {
				if (element instanceof HTMLElement && element.tagName === "CODE") return element;
			})();
			if (codeElement == null) continue;
			columnCount++;
			let item = observedNodes.get(codeElement);
			if (item != null && item.type !== "code") throw new Error("ResizeManager.setup: somehow a code node is being used for an annotation, should be impossible");
			let numberElement = codeElement.firstElementChild;
			if (!(numberElement instanceof HTMLElement)) numberElement = null;
			if (item != null) {
				this.observedNodes.set(codeElement, item);
				observedNodes.delete(codeElement);
				if (item.numberElement !== numberElement) {
					if (item.numberElement != null) {
						this.unobserve(item.numberElement);
						observedNodes.delete(item.numberElement);
					}
					if (numberElement != null) {
						this.observe(numberElement);
						observedNodes.delete(numberElement);
						this.observedNodes.set(numberElement, item);
					}
					item.numberElement = numberElement;
					item.numberWidth = 0;
				} else if (item.numberElement != null) {
					observedNodes.delete(item.numberElement);
					this.observedNodes.set(item.numberElement, item);
				} else item.numberWidth = 0;
				syncColumnVariableMode(item, applyColumnVariables);
			} else {
				item = {
					type: "code",
					codeElement,
					numberElement,
					codeWidth: "auto",
					numberWidth: 0,
					applyColumnVariables
				};
				this.observedNodes.set(codeElement, item);
				this.observe(codeElement);
				if (numberElement != null) {
					this.observedNodes.set(numberElement, item);
					this.observe(numberElement);
				}
			}
		}
		if (columnCount > 1 && !disableAnnotations) {
			const annotationElements = pre.querySelectorAll("[data-line-annotation*=\",\"]");
			const elementMap = /* @__PURE__ */ new Map();
			for (const element of annotationElements) {
				if (!(element instanceof HTMLElement)) continue;
				const lineAnnotation = element.getAttribute("data-line-annotation") ?? "";
				if (!/^-?\d+,-?\d+$/.test(lineAnnotation)) {
					console.error("DiffFileRenderer.setupResizeObserver: Invalid element or annotation", {
						lineAnnotation,
						element
					});
					continue;
				}
				let pairs = elementMap.get(lineAnnotation);
				if (pairs == null) {
					pairs = [];
					elementMap.set(lineAnnotation, pairs);
				}
				pairs.push(element);
			}
			for (const [key, pair] of elementMap) {
				if (pair.length !== 2) {
					console.error("DiffFileRenderer.setupResizeObserver: Bad Pair", key, pair);
					continue;
				}
				const [container1, container2] = pair;
				const child1 = container1.firstElementChild;
				const child2 = container2.firstElementChild;
				if (!(container1 instanceof HTMLElement) || !(container2 instanceof HTMLElement) || !(child1 instanceof HTMLElement) || !(child2 instanceof HTMLElement)) continue;
				let item = observedNodes.get(child1);
				if (item != null) {
					this.observedNodes.set(child1, item);
					this.observedNodes.set(child2, item);
					observedNodes.delete(child1);
					observedNodes.delete(child2);
					continue;
				}
				const child1Height = child1.getBoundingClientRect().height;
				const child2Height = child2.getBoundingClientRect().height;
				item = {
					type: "annotations",
					column1: {
						container: container1,
						child: child1,
						childHeight: child1Height
					},
					column2: {
						container: container2,
						child: child2,
						childHeight: child2Height
					},
					currentHeight: "auto"
				};
				annotationUpdates.add({
					child1,
					child2,
					item,
					newHeight: Math.max(child1Height, child2Height)
				});
			}
			for (const pendingUpdate of annotationUpdates) {
				this.applyNewHeight(pendingUpdate.item, pendingUpdate.newHeight);
				this.observedNodes.set(pendingUpdate.child1, pendingUpdate.item);
				this.observedNodes.set(pendingUpdate.child2, pendingUpdate.item);
				this.observe(pendingUpdate.child1);
				this.observe(pendingUpdate.child2);
			}
			annotationUpdates.clear();
		}
		for (const [element, item] of observedNodes) {
			this.unobserve(element);
			if (item.type === "code") cleanupStaleCodeItem(item);
			else cleanupStaleAnnotationItem(item);
		}
		observedNodes.clear();
	}
	cleanUp() {
		for (const element of this.observedNodes.keys()) this.unobserve(element);
		this.observedNodes.clear();
	}
	observe(element) {
		const { managersByElement } = ResizeManager;
		const owner = managersByElement.get(element);
		if (owner === this) return;
		else if (owner != null && owner !== this) throw new Error("ResizeManager.observe: element is already owned by another ResizeManager");
		managersByElement.set(element, this);
		ResizeManager.getResizeObserver().observe(element);
	}
	unobserve(element) {
		const { managersByElement, resizeObserver } = ResizeManager;
		const owner = managersByElement.get(element);
		if (owner == null) return;
		else if (owner !== this) throw new Error("ResizeManager.unobserve: element is owned by another ResizeManager");
		managersByElement.delete(element);
		resizeObserver?.unobserve(element);
		if (resizeObserver != null && managersByElement.size === 0) {
			resizeObserver.disconnect();
			ResizeManager.resizeObserver = void 0;
		}
	}
	handleResizeEntries(entries) {
		const codeUpdates = /* @__PURE__ */ new Map();
		const annotationUpdates = /* @__PURE__ */ new Set();
		for (const entry of entries) {
			const { target, borderBoxSize, contentBoxSize } = entry;
			if (!(target instanceof HTMLElement)) {
				console.error("ResizeManager.handleResizeEntries: Invalid element for ResizeObserver", entry);
				continue;
			}
			const item = this.observedNodes.get(target);
			if (item == null) {
				console.error("ResizeManager.handleResizeEntries: Not a valid observed node", entry);
				continue;
			}
			if (item.type === "annotations") {
				const column = (() => {
					if (target === item.column1.child) return item.column1;
					if (target === item.column2.child) return item.column2;
				})();
				if (column == null) {
					console.error(`ResizeManager.handleResizeEntries: Couldn't find a column for`, {
						item,
						target
					});
					continue;
				}
				column.childHeight = borderBoxSize[0].blockSize;
				annotationUpdates.add(item);
			} else if (item.type === "code") {
				const update = codeUpdates.get(item) ?? {};
				const inlineSize = contentBoxSize[0].inlineSize;
				if (target === item.codeElement) update.codeInlineSize = inlineSize;
				else if (target === item.numberElement) update.numberInlineSize = inlineSize;
				codeUpdates.set(item, update);
			}
		}
		this.applyAnnotationUpdates(annotationUpdates);
		annotationUpdates.clear();
		this.applyColumnUpdates(codeUpdates);
		codeUpdates.clear();
	}
	applyAnnotationUpdates(annotationUpdates) {
		for (const item of annotationUpdates) this.applyNewHeight(item, Math.max(item.column1.childHeight, item.column2.childHeight));
	}
	applyColumnUpdates = (queuedUpdates) => {
		for (const [item, update] of queuedUpdates) {
			const nextCodeWidth = update.codeInlineSize != null ? resolveCodeWidth(update.codeInlineSize) : item.codeWidth;
			const nextNumberWidth = update.numberInlineSize != null ? resolveNumberWidth(update.numberInlineSize) : item.numberWidth;
			const codeWidthChanged = nextCodeWidth !== item.codeWidth;
			const numberWidthChanged = nextNumberWidth !== item.numberWidth;
			if (!codeWidthChanged && !numberWidthChanged) continue;
			item.codeWidth = nextCodeWidth;
			item.numberWidth = nextNumberWidth;
			if (item.applyColumnVariables) applyCodeColumnVariables(item, {
				codeWidthChanged,
				numberWidthChanged
			});
		}
	};
	applyNewHeight(item, newHeight) {
		if (newHeight !== item.currentHeight) {
			item.currentHeight = Math.max(newHeight, 0);
			item.column1.container.style.setProperty("--diffs-annotation-min-height", `${item.currentHeight}px`);
			item.column2.container.style.setProperty("--diffs-annotation-min-height", `${item.currentHeight}px`);
		}
	}
};
function resolveCodeWidth(inlineSize) {
	const width = Math.max(Math.floor(inlineSize), 0);
	return width === 0 ? "auto" : width;
}
function resolveNumberWidth(inlineSize) {
	return Math.max(Math.ceil(inlineSize), 0);
}
function syncColumnVariableMode(item, applyColumnVariables) {
	if (item.applyColumnVariables === applyColumnVariables) return;
	item.applyColumnVariables = applyColumnVariables;
	if (applyColumnVariables) applyCodeColumnVariables(item, {
		codeWidthChanged: true,
		numberWidthChanged: true
	});
	else removeCodeColumnVariables(item);
}
function applyCodeColumnVariables(item, { codeWidthChanged, numberWidthChanged }) {
	const { codeElement, codeWidth, numberWidth } = item;
	if (codeWidthChanged) codeElement.style.setProperty("--diffs-column-width", `${typeof codeWidth === "number" ? `${codeWidth}px` : "auto"}`);
	if (numberWidthChanged) codeElement.style.setProperty("--diffs-column-number-width", `${numberWidth === 0 ? "auto" : `${numberWidth}px`}`);
	if (codeWidthChanged || numberWidthChanged && codeWidth !== "auto") {
		const targetWidth = typeof codeWidth === "number" ? Math.max(codeWidth - numberWidth, 0) : 0;
		codeElement.style.setProperty("--diffs-column-content-width", `${targetWidth > 0 ? `${targetWidth}px` : "auto"}`);
	}
}
function removeCodeColumnVariables(item) {
	item.codeElement.style.removeProperty("--diffs-column-content-width");
	item.codeElement.style.removeProperty("--diffs-column-number-width");
	item.codeElement.style.removeProperty("--diffs-column-width");
}
function cleanupStaleCodeItem(item) {
	if (item.codeElement.isConnected) removeCodeColumnVariables(item);
}
function cleanupStaleAnnotationItem(item) {
	if (item.column1.container.isConnected) item.column1.container.style.removeProperty("--diffs-annotation-min-height");
	if (item.column2.container.isConnected) item.column2.container.style.removeProperty("--diffs-annotation-min-height");
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/constants.js
var ResolvedLanguages = /* @__PURE__ */ new Map();
var ResolvingLanguages = /* @__PURE__ */ new Map();
var RegisteredCustomLanguages = /* @__PURE__ */ new Map();
var AttachedLanguages = /* @__PURE__ */ new Set();
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/areLanguagesAttached.js
function areLanguagesAttached(languages) {
	for (const language of Array.isArray(languages) ? languages : [languages]) {
		if (language === "text" || language === "ansi") continue;
		if (!AttachedLanguages.has(language)) return false;
	}
	return true;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/attachResolvedLanguages.js
function attachResolvedLanguages(resolvedLanguages, highlighter) {
	resolvedLanguages = Array.isArray(resolvedLanguages) ? resolvedLanguages : [resolvedLanguages];
	for (const resolvedLang of resolvedLanguages) {
		if (AttachedLanguages.has(resolvedLang.name)) continue;
		let lang = ResolvedLanguages.get(resolvedLang.name);
		if (lang == null) {
			lang = resolvedLang;
			ResolvedLanguages.set(resolvedLang.name, lang);
		}
		AttachedLanguages.add(lang.name);
		highlighter.loadLanguageSync(lang.data);
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/cleanUpResolvedLanguages.js
function cleanUpResolvedLanguages() {
	ResolvedLanguages.clear();
	AttachedLanguages.clear();
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/isWorkerContext.js
function isWorkerContext() {
	return typeof WorkerGlobalScope !== "undefined" && typeof self !== "undefined" && self instanceof WorkerGlobalScope;
}
//#endregion
//#region node_modules/.bun/shiki@4.0.2/node_modules/shiki/dist/langs-bundle-full-DfKZStlK.mjs
var bundledLanguagesInfo = [
	{
		"id": "abap",
		"name": "ABAP",
		"import": (() => import("./abap-LtYK6g-v.js"))
	},
	{
		"id": "actionscript-3",
		"name": "ActionScript",
		"import": (() => import("./actionscript-3-Czo0lKSf.js"))
	},
	{
		"id": "ada",
		"name": "Ada",
		"import": (() => import("./ada-twHwrVWN.js"))
	},
	{
		"id": "angular-html",
		"name": "Angular HTML",
		"import": (() => import("./angular-html-eeGaMN-6.js").then((n) => n.n))
	},
	{
		"id": "angular-ts",
		"name": "Angular TypeScript",
		"import": (() => import("./angular-ts-BY9gSsEJ.js"))
	},
	{
		"id": "apache",
		"name": "Apache Conf",
		"import": (() => import("./apache-BIl2qPOf.js"))
	},
	{
		"id": "apex",
		"name": "Apex",
		"import": (() => import("./apex-DV3SR8IZ.js"))
	},
	{
		"id": "apl",
		"name": "APL",
		"import": (() => import("./apl-CmCqy_p8.js"))
	},
	{
		"id": "applescript",
		"name": "AppleScript",
		"import": (() => import("./applescript-CJ80B5XJ.js"))
	},
	{
		"id": "ara",
		"name": "Ara",
		"import": (() => import("./ara-IxnQjO6j.js"))
	},
	{
		"id": "asciidoc",
		"name": "AsciiDoc",
		"aliases": ["adoc"],
		"import": (() => import("./asciidoc-Dsw6zvwf.js"))
	},
	{
		"id": "asm",
		"name": "Assembly",
		"import": (() => import("./asm-wBDSgBbA.js"))
	},
	{
		"id": "astro",
		"name": "Astro",
		"import": (() => import("./astro-B8P1yKRa.js"))
	},
	{
		"id": "awk",
		"name": "AWK",
		"import": (() => import("./awk-D6dA05Ye.js"))
	},
	{
		"id": "ballerina",
		"name": "Ballerina",
		"import": (() => import("./ballerina-DIdXD2KH.js"))
	},
	{
		"id": "bat",
		"name": "Batch File",
		"aliases": ["batch"],
		"import": (() => import("./bat-hQslfzu-.js"))
	},
	{
		"id": "beancount",
		"name": "Beancount",
		"import": (() => import("./beancount-CXtOQ8oS.js"))
	},
	{
		"id": "berry",
		"name": "Berry",
		"aliases": ["be"],
		"import": (() => import("./berry-CgA2ea0_.js"))
	},
	{
		"id": "bibtex",
		"name": "BibTeX",
		"import": (() => import("./bibtex-BzgdqG3s.js"))
	},
	{
		"id": "bicep",
		"name": "Bicep",
		"import": (() => import("./bicep-CZ338dSk.js"))
	},
	{
		"id": "bird2",
		"name": "BIRD2 Configuration",
		"aliases": ["bird"],
		"import": (() => import("./bird2-GLyzhwkD.js"))
	},
	{
		"id": "blade",
		"name": "Blade",
		"import": (() => import("./blade-Dqv5chsr.js"))
	},
	{
		"id": "bsl",
		"name": "1C (Enterprise)",
		"aliases": ["1c"],
		"import": (() => import("./bsl-xEqat1pv.js"))
	},
	{
		"id": "c",
		"name": "C",
		"import": (() => import("./c-B0VlJNKn.js").then((n) => n.n))
	},
	{
		"id": "c3",
		"name": "C3",
		"import": (() => import("./c3-C3l2uuWJ.js"))
	},
	{
		"id": "cadence",
		"name": "Cadence",
		"aliases": ["cdc"],
		"import": (() => import("./cadence-B1ELWULD.js"))
	},
	{
		"id": "cairo",
		"name": "Cairo",
		"import": (() => import("./cairo-Bt8yBCu3.js"))
	},
	{
		"id": "clarity",
		"name": "Clarity",
		"import": (() => import("./clarity-2iIoRiLx.js"))
	},
	{
		"id": "clojure",
		"name": "Clojure",
		"aliases": ["clj"],
		"import": (() => import("./clojure-DDsQ0FaV.js"))
	},
	{
		"id": "cmake",
		"name": "CMake",
		"import": (() => import("./cmake-DPsCB_V6.js"))
	},
	{
		"id": "cobol",
		"name": "COBOL",
		"import": (() => import("./cobol-BIdxI0uK.js"))
	},
	{
		"id": "codeowners",
		"name": "CODEOWNERS",
		"import": (() => import("./codeowners-CxEKPWu0.js"))
	},
	{
		"id": "codeql",
		"name": "CodeQL",
		"aliases": ["ql"],
		"import": (() => import("./codeql-BwdvwJnv.js"))
	},
	{
		"id": "coffee",
		"name": "CoffeeScript",
		"aliases": ["coffeescript"],
		"import": (() => import("./coffee-DLEQN9FO.js"))
	},
	{
		"id": "common-lisp",
		"name": "Common Lisp",
		"aliases": ["lisp"],
		"import": (() => import("./common-lisp-DJtwvW4V.js"))
	},
	{
		"id": "coq",
		"name": "Coq",
		"import": (() => import("./coq-Ds6Ye5el.js"))
	},
	{
		"id": "cpp",
		"name": "C++",
		"aliases": ["c++"],
		"import": (() => import("./cpp-B4bkbMQS.js").then((n) => n.n))
	},
	{
		"id": "crystal",
		"name": "Crystal",
		"import": (() => import("./crystal-DxHipJnh.js"))
	},
	{
		"id": "csharp",
		"name": "C#",
		"aliases": ["c#", "cs"],
		"import": (() => import("./csharp-C31LYC1j.js"))
	},
	{
		"id": "css",
		"name": "CSS",
		"import": (() => import("./css-D4uT_0IZ.js").then((n) => n.n))
	},
	{
		"id": "csv",
		"name": "CSV",
		"import": (() => import("./csv-DqIVFkK7.js"))
	},
	{
		"id": "cue",
		"name": "CUE",
		"import": (() => import("./cue-B5KneM5p.js"))
	},
	{
		"id": "cypher",
		"name": "Cypher",
		"aliases": ["cql"],
		"import": (() => import("./cypher-D8Bb8Cq2.js"))
	},
	{
		"id": "d",
		"name": "D",
		"import": (() => import("./d-BQY8TDgQ.js"))
	},
	{
		"id": "dart",
		"name": "Dart",
		"import": (() => import("./dart-C6DUdjib.js"))
	},
	{
		"id": "dax",
		"name": "DAX",
		"import": (() => import("./dax-S-Noo-ku.js"))
	},
	{
		"id": "desktop",
		"name": "Desktop",
		"import": (() => import("./desktop-BgOb7Aj4.js"))
	},
	{
		"id": "diff",
		"name": "Diff",
		"import": (() => import("./diff-Blb4MjsC.js"))
	},
	{
		"id": "docker",
		"name": "Dockerfile",
		"aliases": ["dockerfile"],
		"import": (() => import("./docker-PC1tuYpa.js"))
	},
	{
		"id": "dotenv",
		"name": "dotEnv",
		"import": (() => import("./dotenv-Dkdv7Sm2.js"))
	},
	{
		"id": "dream-maker",
		"name": "Dream Maker",
		"import": (() => import("./dream-maker-CngiPd8U.js"))
	},
	{
		"id": "edge",
		"name": "Edge",
		"import": (() => import("./edge-D4z9vVW8.js"))
	},
	{
		"id": "elixir",
		"name": "Elixir",
		"import": (() => import("./elixir-Cgi1OnsE.js"))
	},
	{
		"id": "elm",
		"name": "Elm",
		"import": (() => import("./elm-Bpgseq1o.js"))
	},
	{
		"id": "emacs-lisp",
		"name": "Emacs Lisp",
		"aliases": ["elisp"],
		"import": (() => import("./emacs-lisp-DxhFFVu_.js"))
	},
	{
		"id": "erb",
		"name": "ERB",
		"import": (() => import("./erb-BZtEN-pn.js"))
	},
	{
		"id": "erlang",
		"name": "Erlang",
		"aliases": ["erl"],
		"import": (() => import("./erlang-D87a8obB.js"))
	},
	{
		"id": "fennel",
		"name": "Fennel",
		"import": (() => import("./fennel-B3wtZRne.js"))
	},
	{
		"id": "fish",
		"name": "Fish",
		"import": (() => import("./fish-D7qAeWQz.js"))
	},
	{
		"id": "fluent",
		"name": "Fluent",
		"aliases": ["ftl"],
		"import": (() => import("./fluent-BjfpB34g.js"))
	},
	{
		"id": "fortran-fixed-form",
		"name": "Fortran (Fixed Form)",
		"aliases": [
			"f",
			"for",
			"f77"
		],
		"import": (() => import("./fortran-fixed-form-DG_7vWXV.js"))
	},
	{
		"id": "fortran-free-form",
		"name": "Fortran (Free Form)",
		"aliases": [
			"f90",
			"f95",
			"f03",
			"f08",
			"f18"
		],
		"import": (() => import("./fortran-free-form-yxJ7igsv.js"))
	},
	{
		"id": "fsharp",
		"name": "F#",
		"aliases": ["f#", "fs"],
		"import": (() => import("./fsharp-Du1jBMjq.js"))
	},
	{
		"id": "gdresource",
		"name": "GDResource",
		"aliases": ["tscn", "tres"],
		"import": (() => import("./gdresource-DKdnT47h.js"))
	},
	{
		"id": "gdscript",
		"name": "GDScript",
		"aliases": ["gd"],
		"import": (() => import("./gdscript-jjgTGGzd.js"))
	},
	{
		"id": "gdshader",
		"name": "GDShader",
		"import": (() => import("./gdshader-D7JfdFV3.js"))
	},
	{
		"id": "genie",
		"name": "Genie",
		"import": (() => import("./genie-DnK2KWIP.js"))
	},
	{
		"id": "gherkin",
		"name": "Gherkin",
		"import": (() => import("./gherkin-D6Lr12YQ.js"))
	},
	{
		"id": "git-commit",
		"name": "Git Commit Message",
		"import": (() => import("./git-commit-D88k455_.js"))
	},
	{
		"id": "git-rebase",
		"name": "Git Rebase Message",
		"import": (() => import("./git-rebase-DT8J2Vdz.js"))
	},
	{
		"id": "gleam",
		"name": "Gleam",
		"import": (() => import("./gleam-CTllUdfC.js"))
	},
	{
		"id": "glimmer-js",
		"name": "Glimmer JS",
		"aliases": ["gjs"],
		"import": (() => import("./glimmer-js-B6J9Xcdm.js"))
	},
	{
		"id": "glimmer-ts",
		"name": "Glimmer TS",
		"aliases": ["gts"],
		"import": (() => import("./glimmer-ts-DhNCE2Yk.js"))
	},
	{
		"id": "glsl",
		"name": "GLSL",
		"import": (() => import("./glsl-BToet4qX.js").then((n) => n.n))
	},
	{
		"id": "gn",
		"name": "GN",
		"import": (() => import("./gn-DDjbVPF4.js"))
	},
	{
		"id": "gnuplot",
		"name": "Gnuplot",
		"import": (() => import("./gnuplot-DgWvVXI8.js"))
	},
	{
		"id": "go",
		"name": "Go",
		"import": (() => import("./go-aXtTCanQ.js"))
	},
	{
		"id": "graphql",
		"name": "GraphQL",
		"aliases": ["gql"],
		"import": (() => import("./graphql-nZAmCb4q.js").then((n) => n.n))
	},
	{
		"id": "groovy",
		"name": "Groovy",
		"import": (() => import("./groovy-Bw2Ku4bU.js"))
	},
	{
		"id": "hack",
		"name": "Hack",
		"import": (() => import("./hack-BvOedzfq.js"))
	},
	{
		"id": "haml",
		"name": "Ruby Haml",
		"import": (() => import("./haml-Bl-4FW4c.js").then((n) => n.n))
	},
	{
		"id": "handlebars",
		"name": "Handlebars",
		"aliases": ["hbs"],
		"import": (() => import("./handlebars-JBNnoTMo.js"))
	},
	{
		"id": "haskell",
		"name": "Haskell",
		"aliases": ["hs"],
		"import": (() => import("./haskell-CfGsE1Cf.js"))
	},
	{
		"id": "haxe",
		"name": "Haxe",
		"import": (() => import("./haxe-B0odltAZ.js"))
	},
	{
		"id": "hcl",
		"name": "HashiCorp HCL",
		"import": (() => import("./hcl-DHg_Osgo.js"))
	},
	{
		"id": "hjson",
		"name": "Hjson",
		"import": (() => import("./hjson-Cuaphql8.js"))
	},
	{
		"id": "hlsl",
		"name": "HLSL",
		"import": (() => import("./hlsl-BJLUNfne.js"))
	},
	{
		"id": "html",
		"name": "HTML",
		"import": (() => import("./html-BLtIlua0.js").then((n) => n.n))
	},
	{
		"id": "html-derivative",
		"name": "HTML (Derivative)",
		"import": (() => import("./html-derivative-X5J2kJvk.js"))
	},
	{
		"id": "http",
		"name": "HTTP",
		"import": (() => import("./http-l26Pcd2l.js"))
	},
	{
		"id": "hurl",
		"name": "Hurl",
		"import": (() => import("./hurl-DbqSGfDY.js"))
	},
	{
		"id": "hxml",
		"name": "HXML",
		"import": (() => import("./hxml-CnIWmbc5.js"))
	},
	{
		"id": "hy",
		"name": "Hy",
		"import": (() => import("./hy-CJKxDzbh.js"))
	},
	{
		"id": "imba",
		"name": "Imba",
		"import": (() => import("./imba-96qKoJCa.js"))
	},
	{
		"id": "ini",
		"name": "INI",
		"aliases": ["properties"],
		"import": (() => import("./ini-C24lZfdM.js"))
	},
	{
		"id": "java",
		"name": "Java",
		"import": (() => import("./java-BL7sNt1z.js").then((n) => n.n))
	},
	{
		"id": "javascript",
		"name": "JavaScript",
		"aliases": [
			"js",
			"cjs",
			"mjs"
		],
		"import": (() => import("./javascript-D0Bzk3cs.js").then((n) => n.n))
	},
	{
		"id": "jinja",
		"name": "Jinja",
		"import": (() => import("./jinja-CPpSVi9B.js"))
	},
	{
		"id": "jison",
		"name": "Jison",
		"import": (() => import("./jison--W-UKaX5.js"))
	},
	{
		"id": "json",
		"name": "JSON",
		"import": (() => import("./json-BbO7flaK.js").then((n) => n.n))
	},
	{
		"id": "json5",
		"name": "JSON5",
		"import": (() => import("./json5-xULSgPQI.js"))
	},
	{
		"id": "jsonc",
		"name": "JSON with Comments",
		"import": (() => import("./jsonc-Cu6rqcrJ.js"))
	},
	{
		"id": "jsonl",
		"name": "JSON Lines",
		"import": (() => import("./jsonl-Bp0qqr10.js"))
	},
	{
		"id": "jsonnet",
		"name": "Jsonnet",
		"import": (() => import("./jsonnet-BafgE6cE.js"))
	},
	{
		"id": "jssm",
		"name": "JSSM",
		"aliases": ["fsl"],
		"import": (() => import("./jssm-Dx5A5sBR.js"))
	},
	{
		"id": "jsx",
		"name": "JSX",
		"import": (() => import("./jsx-CCf_uD-s.js").then((n) => n.n))
	},
	{
		"id": "julia",
		"name": "Julia",
		"aliases": ["jl"],
		"import": (() => import("./julia-Bt0PljJf.js"))
	},
	{
		"id": "just",
		"name": "Just",
		"import": (() => import("./just-BwpDN4uo.js"))
	},
	{
		"id": "kdl",
		"name": "KDL",
		"import": (() => import("./kdl-DkTyxPcj.js"))
	},
	{
		"id": "kotlin",
		"name": "Kotlin",
		"aliases": ["kt", "kts"],
		"import": (() => import("./kotlin-BHE8CoV9.js"))
	},
	{
		"id": "kusto",
		"name": "Kusto",
		"aliases": ["kql"],
		"import": (() => import("./kusto-6FdaWTzR.js"))
	},
	{
		"id": "latex",
		"name": "LaTeX",
		"import": (() => import("./latex-kkZd9Q7W.js"))
	},
	{
		"id": "lean",
		"name": "Lean 4",
		"aliases": ["lean4"],
		"import": (() => import("./lean-BwOKScIt.js"))
	},
	{
		"id": "less",
		"name": "Less",
		"import": (() => import("./less-BzbdhFUi.js"))
	},
	{
		"id": "liquid",
		"name": "Liquid",
		"import": (() => import("./liquid-Bpo5E3KP.js"))
	},
	{
		"id": "llvm",
		"name": "LLVM IR",
		"import": (() => import("./llvm-uY68ROGz.js"))
	},
	{
		"id": "log",
		"name": "Log file",
		"import": (() => import("./log-Dad54gsi.js"))
	},
	{
		"id": "logo",
		"name": "Logo",
		"import": (() => import("./logo-DTXV8SKw.js"))
	},
	{
		"id": "lua",
		"name": "Lua",
		"import": (() => import("./lua-BnmjQboa.js").then((n) => n.n))
	},
	{
		"id": "luau",
		"name": "Luau",
		"import": (() => import("./luau-BrEqC1G7.js"))
	},
	{
		"id": "make",
		"name": "Makefile",
		"aliases": ["makefile"],
		"import": (() => import("./make-B2ukzWs3.js"))
	},
	{
		"id": "markdown",
		"name": "Markdown",
		"aliases": ["md"],
		"import": (() => import("./markdown-CkmxmzqY.js"))
	},
	{
		"id": "marko",
		"name": "Marko",
		"import": (() => import("./marko-CJufSVky.js"))
	},
	{
		"id": "matlab",
		"name": "MATLAB",
		"import": (() => import("./matlab-CfRK6IMC.js"))
	},
	{
		"id": "mdc",
		"name": "MDC",
		"import": (() => import("./mdc-DRIITFRS.js"))
	},
	{
		"id": "mdx",
		"name": "MDX",
		"import": (() => import("./mdx-BK9ZufRc.js"))
	},
	{
		"id": "mermaid",
		"name": "Mermaid",
		"aliases": ["mmd"],
		"import": (() => import("./mermaid-r7OoIYpE.js"))
	},
	{
		"id": "mipsasm",
		"name": "MIPS Assembly",
		"aliases": ["mips"],
		"import": (() => import("./mipsasm-EL46Y4Xg.js"))
	},
	{
		"id": "mojo",
		"name": "Mojo",
		"import": (() => import("./mojo-YCzvCoMT.js"))
	},
	{
		"id": "moonbit",
		"name": "MoonBit",
		"aliases": ["mbt", "mbti"],
		"import": (() => import("./moonbit-B_9L5rST.js"))
	},
	{
		"id": "move",
		"name": "Move",
		"import": (() => import("./move-Dqi5fhOb.js"))
	},
	{
		"id": "narrat",
		"name": "Narrat Language",
		"aliases": ["nar"],
		"import": (() => import("./narrat-D9rrR0H5.js"))
	},
	{
		"id": "nextflow",
		"name": "Nextflow",
		"aliases": ["nf"],
		"import": (() => import("./nextflow-eDoQgxi-.js"))
	},
	{
		"id": "nextflow-groovy",
		"name": "Nextflow Groovy",
		"import": (() => import("./nextflow-groovy-CdFFX-gF.js"))
	},
	{
		"id": "nginx",
		"name": "Nginx",
		"import": (() => import("./nginx-CLJQb9Gm.js"))
	},
	{
		"id": "nim",
		"name": "Nim",
		"import": (() => import("./nim-CLo_EUPP.js"))
	},
	{
		"id": "nix",
		"name": "Nix",
		"import": (() => import("./nix-DQDPwSZw.js"))
	},
	{
		"id": "nushell",
		"name": "nushell",
		"aliases": ["nu"],
		"import": (() => import("./nushell-r7hBzeS_.js"))
	},
	{
		"id": "objective-c",
		"name": "Objective-C",
		"aliases": ["objc"],
		"import": (() => import("./objective-c-6dJF64Dt.js"))
	},
	{
		"id": "objective-cpp",
		"name": "Objective-C++",
		"import": (() => import("./objective-cpp-_ooRQ-PY.js"))
	},
	{
		"id": "ocaml",
		"name": "OCaml",
		"import": (() => import("./ocaml-vm1Y8An6.js"))
	},
	{
		"id": "odin",
		"name": "Odin",
		"import": (() => import("./odin-vjOJSyfV.js"))
	},
	{
		"id": "openscad",
		"name": "OpenSCAD",
		"aliases": ["scad"],
		"import": (() => import("./openscad-jn-f1Ocl.js"))
	},
	{
		"id": "pascal",
		"name": "Pascal",
		"import": (() => import("./pascal-D8-gNZ2I.js"))
	},
	{
		"id": "perl",
		"name": "Perl",
		"import": (() => import("./perl-zF6uSqnO.js"))
	},
	{
		"id": "php",
		"name": "PHP",
		"import": (() => import("./php-D3bLep6o.js"))
	},
	{
		"id": "pkl",
		"name": "Pkl",
		"import": (() => import("./pkl-C7lWzykI.js"))
	},
	{
		"id": "plsql",
		"name": "PL/SQL",
		"import": (() => import("./plsql-DCNXypXO.js"))
	},
	{
		"id": "po",
		"name": "Gettext PO",
		"aliases": ["pot", "potx"],
		"import": (() => import("./po-IjpR1yHO.js"))
	},
	{
		"id": "polar",
		"name": "Polar",
		"import": (() => import("./polar-4pN1JrJ8.js"))
	},
	{
		"id": "postcss",
		"name": "PostCSS",
		"import": (() => import("./postcss-D1gKt4z_.js"))
	},
	{
		"id": "powerquery",
		"name": "PowerQuery",
		"import": (() => import("./powerquery-SrvS_NBM.js"))
	},
	{
		"id": "powershell",
		"name": "PowerShell",
		"aliases": ["ps", "ps1"],
		"import": (() => import("./powershell-CpTLv_ai.js"))
	},
	{
		"id": "prisma",
		"name": "Prisma",
		"import": (() => import("./prisma-BWfa4-tI.js"))
	},
	{
		"id": "prolog",
		"name": "Prolog",
		"import": (() => import("./prolog-Bacii3Ue.js"))
	},
	{
		"id": "proto",
		"name": "Protocol Buffer 3",
		"aliases": ["protobuf"],
		"import": (() => import("./proto-ClkOcAW0.js"))
	},
	{
		"id": "pug",
		"name": "Pug",
		"aliases": ["jade"],
		"import": (() => import("./pug-cF8c5GFB.js"))
	},
	{
		"id": "puppet",
		"name": "Puppet",
		"import": (() => import("./puppet-CQlPp728.js"))
	},
	{
		"id": "purescript",
		"name": "PureScript",
		"import": (() => import("./purescript-CLpaGMbw.js"))
	},
	{
		"id": "python",
		"name": "Python",
		"aliases": ["py"],
		"import": (() => import("./python-BjnOIxPe.js"))
	},
	{
		"id": "qml",
		"name": "QML",
		"import": (() => import("./qml-DQos8yu_.js"))
	},
	{
		"id": "qmldir",
		"name": "QML Directory",
		"import": (() => import("./qmldir-Dz8ttxjf.js"))
	},
	{
		"id": "qss",
		"name": "Qt Style Sheets",
		"import": (() => import("./qss-Iltvkn1C.js"))
	},
	{
		"id": "r",
		"name": "R",
		"import": (() => import("./r-W0OHscH9.js").then((n) => n.n))
	},
	{
		"id": "racket",
		"name": "Racket",
		"import": (() => import("./racket-DRv7j6nv.js"))
	},
	{
		"id": "raku",
		"name": "Raku",
		"aliases": ["perl6"],
		"import": (() => import("./raku-DI9yGpeW.js"))
	},
	{
		"id": "razor",
		"name": "ASP.NET Razor",
		"import": (() => import("./razor-BxRr1fRw.js"))
	},
	{
		"id": "reg",
		"name": "Windows Registry Script",
		"import": (() => import("./reg-DpJf71oO.js"))
	},
	{
		"id": "regexp",
		"name": "RegExp",
		"aliases": ["regex"],
		"import": (() => import("./regexp-DO8jxeDX.js").then((n) => n.n))
	},
	{
		"id": "rel",
		"name": "Rel",
		"import": (() => import("./rel-BT0iIKKw.js"))
	},
	{
		"id": "riscv",
		"name": "RISC-V",
		"import": (() => import("./riscv-CvzikGLb.js"))
	},
	{
		"id": "ron",
		"name": "RON",
		"import": (() => import("./ron-DzAo6FTJ.js"))
	},
	{
		"id": "rosmsg",
		"name": "ROS Interface",
		"import": (() => import("./rosmsg-CyYq6XdT.js"))
	},
	{
		"id": "rst",
		"name": "reStructuredText",
		"import": (() => import("./rst-TeQmDft0.js"))
	},
	{
		"id": "ruby",
		"name": "Ruby",
		"aliases": ["rb"],
		"import": (() => import("./ruby-CdcN8Ow8.js"))
	},
	{
		"id": "rust",
		"name": "Rust",
		"aliases": ["rs"],
		"import": (() => import("./rust-COBzcmTx.js"))
	},
	{
		"id": "sas",
		"name": "SAS",
		"import": (() => import("./sas-D7Q4tyLk.js"))
	},
	{
		"id": "sass",
		"name": "Sass",
		"import": (() => import("./sass-DI2zJwx7.js"))
	},
	{
		"id": "scala",
		"name": "Scala",
		"import": (() => import("./scala-CtSYTRYT.js"))
	},
	{
		"id": "scheme",
		"name": "Scheme",
		"import": (() => import("./scheme-D3A2QBtM.js"))
	},
	{
		"id": "scss",
		"name": "SCSS",
		"import": (() => import("./scss-BuCi93WJ.js").then((n) => n.n))
	},
	{
		"id": "sdbl",
		"name": "1C (Query)",
		"aliases": ["1c-query"],
		"import": (() => import("./sdbl-CdQg5gu1.js"))
	},
	{
		"id": "shaderlab",
		"name": "ShaderLab",
		"aliases": ["shader"],
		"import": (() => import("./shaderlab-YlyQlIui.js"))
	},
	{
		"id": "shellscript",
		"name": "Shell",
		"aliases": [
			"bash",
			"sh",
			"shell",
			"zsh"
		],
		"import": (() => import("./shellscript-NoAtg_mI.js").then((n) => n.n))
	},
	{
		"id": "shellsession",
		"name": "Shell Session",
		"aliases": ["console"],
		"import": (() => import("./shellsession-_AXhxiOY.js"))
	},
	{
		"id": "smalltalk",
		"name": "Smalltalk",
		"import": (() => import("./smalltalk-BEQkVl4K.js"))
	},
	{
		"id": "solidity",
		"name": "Solidity",
		"import": (() => import("./solidity-lB9VjfB9.js"))
	},
	{
		"id": "soy",
		"name": "Closure Templates",
		"aliases": ["closure-templates"],
		"import": (() => import("./soy-_WhnK1Gf.js"))
	},
	{
		"id": "sparql",
		"name": "SPARQL",
		"import": (() => import("./sparql-BV7hRZ62.js"))
	},
	{
		"id": "splunk",
		"name": "Splunk Query Language",
		"aliases": ["spl"],
		"import": (() => import("./splunk-xP_ZjUH2.js"))
	},
	{
		"id": "sql",
		"name": "SQL",
		"import": (() => import("./sql-TdwymhW2.js").then((n) => n.n))
	},
	{
		"id": "ssh-config",
		"name": "SSH Config",
		"import": (() => import("./ssh-config-DXFPABYp.js"))
	},
	{
		"id": "stata",
		"name": "Stata",
		"import": (() => import("./stata-DD9PS1VL.js"))
	},
	{
		"id": "stylus",
		"name": "Stylus",
		"aliases": ["styl"],
		"import": (() => import("./stylus-ZZDn1yUO.js"))
	},
	{
		"id": "surrealql",
		"name": "SurrealQL",
		"aliases": ["surql"],
		"import": (() => import("./surrealql-CLBDD9VO.js"))
	},
	{
		"id": "svelte",
		"name": "Svelte",
		"import": (() => import("./svelte-DkS87o2v.js"))
	},
	{
		"id": "swift",
		"name": "Swift",
		"import": (() => import("./swift-BTPQlRLK.js"))
	},
	{
		"id": "system-verilog",
		"name": "SystemVerilog",
		"import": (() => import("./system-verilog-BEoxaBuU.js"))
	},
	{
		"id": "systemd",
		"name": "Systemd Units",
		"import": (() => import("./systemd-DFbUltlW.js"))
	},
	{
		"id": "talonscript",
		"name": "TalonScript",
		"aliases": ["talon"],
		"import": (() => import("./talonscript-CLxaFu-b.js"))
	},
	{
		"id": "tasl",
		"name": "Tasl",
		"import": (() => import("./tasl-_AAbKiWM.js"))
	},
	{
		"id": "tcl",
		"name": "Tcl",
		"import": (() => import("./tcl-DLe0Tsfm.js"))
	},
	{
		"id": "templ",
		"name": "Templ",
		"import": (() => import("./templ-DYxk4BBl.js"))
	},
	{
		"id": "terraform",
		"name": "Terraform",
		"aliases": ["tf", "tfvars"],
		"import": (() => import("./terraform-v0KN9QQh.js"))
	},
	{
		"id": "tex",
		"name": "TeX",
		"import": (() => import("./tex-CBFAcJ2m.js"))
	},
	{
		"id": "toml",
		"name": "TOML",
		"import": (() => import("./toml-B7BHZIqX.js"))
	},
	{
		"id": "ts-tags",
		"name": "TypeScript with Tags",
		"aliases": ["lit"],
		"import": (() => import("./ts-tags-CQvuZ53l.js"))
	},
	{
		"id": "tsv",
		"name": "TSV",
		"import": (() => import("./tsv-BorGVq2Z.js"))
	},
	{
		"id": "tsx",
		"name": "TSX",
		"import": (() => import("./tsx-BjZoayfS.js").then((n) => n.n))
	},
	{
		"id": "turtle",
		"name": "Turtle",
		"import": (() => import("./turtle-BEG5g_eT.js"))
	},
	{
		"id": "twig",
		"name": "Twig",
		"import": (() => import("./twig-jc1wN5Fn.js"))
	},
	{
		"id": "typescript",
		"name": "TypeScript",
		"aliases": [
			"ts",
			"cts",
			"mts"
		],
		"import": (() => import("./typescript-BQL6uD4x.js").then((n) => n.n))
	},
	{
		"id": "typespec",
		"name": "TypeSpec",
		"aliases": ["tsp"],
		"import": (() => import("./typespec-C_R5TbvO.js"))
	},
	{
		"id": "typst",
		"name": "Typst",
		"aliases": ["typ"],
		"import": (() => import("./typst-BV9w0z8-.js"))
	},
	{
		"id": "v",
		"name": "V",
		"import": (() => import("./v-DfbeXLo8.js"))
	},
	{
		"id": "vala",
		"name": "Vala",
		"import": (() => import("./vala-BnnASFsX.js"))
	},
	{
		"id": "vb",
		"name": "Visual Basic",
		"aliases": ["cmd"],
		"import": (() => import("./vb-DU29mvss.js"))
	},
	{
		"id": "verilog",
		"name": "Verilog",
		"import": (() => import("./verilog-BW5U03XW.js"))
	},
	{
		"id": "vhdl",
		"name": "VHDL",
		"import": (() => import("./vhdl-Co2XFKY7.js"))
	},
	{
		"id": "viml",
		"name": "Vim Script",
		"aliases": ["vim", "vimscript"],
		"import": (() => import("./viml-BReTXeDA.js"))
	},
	{
		"id": "vue",
		"name": "Vue",
		"import": (() => import("./vue-AaCZjOvl.js"))
	},
	{
		"id": "vue-html",
		"name": "Vue HTML",
		"import": (() => import("./vue-html-D-UxHfp3.js"))
	},
	{
		"id": "vue-vine",
		"name": "Vue Vine",
		"import": (() => import("./vue-vine-CJyo2i-R.js"))
	},
	{
		"id": "vyper",
		"name": "Vyper",
		"aliases": ["vy"],
		"import": (() => import("./vyper-C6KGx0YU.js"))
	},
	{
		"id": "wasm",
		"name": "WebAssembly",
		"import": (() => import("./wasm-gNIKwGlD.js"))
	},
	{
		"id": "wenyan",
		"name": "Wenyan",
		"aliases": ["文言"],
		"import": (() => import("./wenyan-BeysbCrW.js"))
	},
	{
		"id": "wgsl",
		"name": "WGSL",
		"import": (() => import("./wgsl-1s5rV5xS.js"))
	},
	{
		"id": "wikitext",
		"name": "Wikitext",
		"aliases": ["mediawiki", "wiki"],
		"import": (() => import("./wikitext-wjhjmmzD.js"))
	},
	{
		"id": "wit",
		"name": "WebAssembly Interface Types",
		"import": (() => import("./wit-CeQiCbz_.js"))
	},
	{
		"id": "wolfram",
		"name": "Wolfram",
		"aliases": ["wl"],
		"import": (() => import("./wolfram-CcZPfnLd.js"))
	},
	{
		"id": "xml",
		"name": "XML",
		"import": (() => import("./xml-BbZPXfGY.js").then((n) => n.n))
	},
	{
		"id": "xsl",
		"name": "XSL",
		"import": (() => import("./xsl-C5LpbIgP.js"))
	},
	{
		"id": "yaml",
		"name": "YAML",
		"aliases": ["yml"],
		"import": (() => import("./yaml-ChLQGD_1.js").then((n) => n.n))
	},
	{
		"id": "zenscript",
		"name": "ZenScript",
		"import": (() => import("./zenscript-BoijL7rl.js"))
	},
	{
		"id": "zig",
		"name": "Zig",
		"import": (() => import("./zig-lTQvxhLD.js"))
	}
];
var bundledLanguagesBase = Object.fromEntries(bundledLanguagesInfo.map((i) => [i.id, i.import]));
var bundledLanguagesAlias = Object.fromEntries(bundledLanguagesInfo.flatMap((i) => i.aliases?.map((a) => [a, i.import]) || []));
var bundledLanguages = {
	...bundledLanguagesBase,
	...bundledLanguagesAlias
};
//#endregion
//#region node_modules/.bun/shiki@4.0.2/node_modules/shiki/dist/themes.mjs
var bundledThemesInfo = [
	{
		"id": "andromeeda",
		"displayName": "Andromeeda",
		"type": "dark",
		"import": (() => import("./andromeeda-B4yjpELI.js"))
	},
	{
		"id": "aurora-x",
		"displayName": "Aurora X",
		"type": "dark",
		"import": (() => import("./aurora-x-B_F-UzD2.js"))
	},
	{
		"id": "ayu-dark",
		"displayName": "Ayu Dark",
		"type": "dark",
		"import": (() => import("./ayu-dark-DhFxACK4.js"))
	},
	{
		"id": "ayu-light",
		"displayName": "Ayu Light",
		"type": "light",
		"import": (() => import("./ayu-light-BzdOiRwE.js"))
	},
	{
		"id": "ayu-mirage",
		"displayName": "Ayu Mirage",
		"type": "dark",
		"import": (() => import("./ayu-mirage-CqSXQORW.js"))
	},
	{
		"id": "catppuccin-frappe",
		"displayName": "Catppuccin Frappé",
		"type": "dark",
		"import": (() => import("./catppuccin-frappe-DXr1U2q8.js"))
	},
	{
		"id": "catppuccin-latte",
		"displayName": "Catppuccin Latte",
		"type": "light",
		"import": (() => import("./catppuccin-latte-Cp9hXquB.js"))
	},
	{
		"id": "catppuccin-macchiato",
		"displayName": "Catppuccin Macchiato",
		"type": "dark",
		"import": (() => import("./catppuccin-macchiato-BRVMiK3O.js"))
	},
	{
		"id": "catppuccin-mocha",
		"displayName": "Catppuccin Mocha",
		"type": "dark",
		"import": (() => import("./catppuccin-mocha-x5M_hn20.js"))
	},
	{
		"id": "dark-plus",
		"displayName": "Dark Plus",
		"type": "dark",
		"import": (() => import("./dark-plus-B9qaWiZb.js"))
	},
	{
		"id": "dracula",
		"displayName": "Dracula Theme",
		"type": "dark",
		"import": (() => import("./dracula-CZiVqHIP.js"))
	},
	{
		"id": "dracula-soft",
		"displayName": "Dracula Theme Soft",
		"type": "dark",
		"import": (() => import("./dracula-soft-DfMOK6qU.js"))
	},
	{
		"id": "everforest-dark",
		"displayName": "Everforest Dark",
		"type": "dark",
		"import": (() => import("./everforest-dark-CQi4Sf3Z.js"))
	},
	{
		"id": "everforest-light",
		"displayName": "Everforest Light",
		"type": "light",
		"import": (() => import("./everforest-light-CbDm8oo5.js"))
	},
	{
		"id": "github-dark",
		"displayName": "GitHub Dark",
		"type": "dark",
		"import": (() => import("./github-dark-rJU4-y2l.js"))
	},
	{
		"id": "github-dark-default",
		"displayName": "GitHub Dark Default",
		"type": "dark",
		"import": (() => import("./github-dark-default-_9HYf0jh.js"))
	},
	{
		"id": "github-dark-dimmed",
		"displayName": "GitHub Dark Dimmed",
		"type": "dark",
		"import": (() => import("./github-dark-dimmed-DwF3tvSu.js"))
	},
	{
		"id": "github-dark-high-contrast",
		"displayName": "GitHub Dark High Contrast",
		"type": "dark",
		"import": (() => import("./github-dark-high-contrast-BrxRtZ3T.js"))
	},
	{
		"id": "github-light",
		"displayName": "GitHub Light",
		"type": "light",
		"import": (() => import("./github-light-CzHckFmF.js"))
	},
	{
		"id": "github-light-default",
		"displayName": "GitHub Light Default",
		"type": "light",
		"import": (() => import("./github-light-default-DFXPSyyu.js"))
	},
	{
		"id": "github-light-high-contrast",
		"displayName": "GitHub Light High Contrast",
		"type": "light",
		"import": (() => import("./github-light-high-contrast-4bgsxumj.js"))
	},
	{
		"id": "gruvbox-dark-hard",
		"displayName": "Gruvbox Dark Hard",
		"type": "dark",
		"import": (() => import("./gruvbox-dark-hard-D0WIQjpk.js"))
	},
	{
		"id": "gruvbox-dark-medium",
		"displayName": "Gruvbox Dark Medium",
		"type": "dark",
		"import": (() => import("./gruvbox-dark-medium-9sb68oF5.js"))
	},
	{
		"id": "gruvbox-dark-soft",
		"displayName": "Gruvbox Dark Soft",
		"type": "dark",
		"import": (() => import("./gruvbox-dark-soft-C4oRj0MJ.js"))
	},
	{
		"id": "gruvbox-light-hard",
		"displayName": "Gruvbox Light Hard",
		"type": "light",
		"import": (() => import("./gruvbox-light-hard-3LdREJ4f.js"))
	},
	{
		"id": "gruvbox-light-medium",
		"displayName": "Gruvbox Light Medium",
		"type": "light",
		"import": (() => import("./gruvbox-light-medium-DuzIw1pS.js"))
	},
	{
		"id": "gruvbox-light-soft",
		"displayName": "Gruvbox Light Soft",
		"type": "light",
		"import": (() => import("./gruvbox-light-soft-DaKo8A8e.js"))
	},
	{
		"id": "horizon",
		"displayName": "Horizon",
		"type": "dark",
		"import": (() => import("./horizon-BICEid2Q.js"))
	},
	{
		"id": "horizon-bright",
		"displayName": "Horizon Bright",
		"type": "light",
		"import": (() => import("./horizon-bright-_vFu7yW_.js"))
	},
	{
		"id": "houston",
		"displayName": "Houston",
		"type": "dark",
		"import": (() => import("./houston-ByvWzx_D.js"))
	},
	{
		"id": "kanagawa-dragon",
		"displayName": "Kanagawa Dragon",
		"type": "dark",
		"import": (() => import("./kanagawa-dragon-BnOhqXgj.js"))
	},
	{
		"id": "kanagawa-lotus",
		"displayName": "Kanagawa Lotus",
		"type": "light",
		"import": (() => import("./kanagawa-lotus-C-cPK0RC.js"))
	},
	{
		"id": "kanagawa-wave",
		"displayName": "Kanagawa Wave",
		"type": "dark",
		"import": (() => import("./kanagawa-wave-CI4l_biU.js"))
	},
	{
		"id": "laserwave",
		"displayName": "LaserWave",
		"type": "dark",
		"import": (() => import("./laserwave-BXG4fD_6.js"))
	},
	{
		"id": "light-plus",
		"displayName": "Light Plus",
		"type": "light",
		"import": (() => import("./light-plus-BSRdLiCo.js"))
	},
	{
		"id": "material-theme",
		"displayName": "Material Theme",
		"type": "dark",
		"import": (() => import("./material-theme-1RPYImuI.js"))
	},
	{
		"id": "material-theme-darker",
		"displayName": "Material Theme Darker",
		"type": "dark",
		"import": (() => import("./material-theme-darker-DI3OEnG-.js"))
	},
	{
		"id": "material-theme-lighter",
		"displayName": "Material Theme Lighter",
		"type": "light",
		"import": (() => import("./material-theme-lighter-DsI9ER_j.js"))
	},
	{
		"id": "material-theme-ocean",
		"displayName": "Material Theme Ocean",
		"type": "dark",
		"import": (() => import("./material-theme-ocean-BCOyKQ2E.js"))
	},
	{
		"id": "material-theme-palenight",
		"displayName": "Material Theme Palenight",
		"type": "dark",
		"import": (() => import("./material-theme-palenight-dgby2lcV.js"))
	},
	{
		"id": "min-dark",
		"displayName": "Min Dark",
		"type": "dark",
		"import": (() => import("./min-dark-DmYL5urg.js"))
	},
	{
		"id": "min-light",
		"displayName": "Min Light",
		"type": "light",
		"import": (() => import("./min-light-CXkAmn1I.js"))
	},
	{
		"id": "monokai",
		"displayName": "Monokai",
		"type": "dark",
		"import": (() => import("./monokai-Bodz_vhc.js"))
	},
	{
		"id": "night-owl",
		"displayName": "Night Owl",
		"type": "dark",
		"import": (() => import("./night-owl-DSzeI7Qw.js"))
	},
	{
		"id": "night-owl-light",
		"displayName": "Night Owl Light",
		"type": "light",
		"import": (() => import("./night-owl-light-QGMTqVgc.js"))
	},
	{
		"id": "nord",
		"displayName": "Nord",
		"type": "dark",
		"import": (() => import("./nord-XYO6PRDD.js"))
	},
	{
		"id": "one-dark-pro",
		"displayName": "One Dark Pro",
		"type": "dark",
		"import": (() => import("./one-dark-pro-CqgI9EVt.js"))
	},
	{
		"id": "one-light",
		"displayName": "One Light",
		"type": "light",
		"import": (() => import("./one-light-p9STbcy8.js"))
	},
	{
		"id": "plastic",
		"displayName": "Plastic",
		"type": "dark",
		"import": (() => import("./plastic-D1DEGRtk.js"))
	},
	{
		"id": "poimandres",
		"displayName": "Poimandres",
		"type": "dark",
		"import": (() => import("./poimandres-Cp0cHf71.js"))
	},
	{
		"id": "red",
		"displayName": "Red",
		"type": "dark",
		"import": (() => import("./red-CBm5xWbS.js"))
	},
	{
		"id": "rose-pine",
		"displayName": "Rosé Pine",
		"type": "dark",
		"import": (() => import("./rose-pine-CsMXEpAA.js"))
	},
	{
		"id": "rose-pine-dawn",
		"displayName": "Rosé Pine Dawn",
		"type": "light",
		"import": (() => import("./rose-pine-dawn-MM3_pymF.js"))
	},
	{
		"id": "rose-pine-moon",
		"displayName": "Rosé Pine Moon",
		"type": "dark",
		"import": (() => import("./rose-pine-moon-B6FzoeyJ.js"))
	},
	{
		"id": "slack-dark",
		"displayName": "Slack Dark",
		"type": "dark",
		"import": (() => import("./slack-dark-BJyO7e1p.js"))
	},
	{
		"id": "slack-ochin",
		"displayName": "Slack Ochin",
		"type": "light",
		"import": (() => import("./slack-ochin-DLW0gE0H.js"))
	},
	{
		"id": "snazzy-light",
		"displayName": "Snazzy Light",
		"type": "light",
		"import": (() => import("./snazzy-light-J5lQlWJ8.js"))
	},
	{
		"id": "solarized-dark",
		"displayName": "Solarized Dark",
		"type": "dark",
		"import": (() => import("./solarized-dark-ByJ8Ofyf.js"))
	},
	{
		"id": "solarized-light",
		"displayName": "Solarized Light",
		"type": "light",
		"import": (() => import("./solarized-light-CwFsPqEQ.js"))
	},
	{
		"id": "synthwave-84",
		"displayName": "Synthwave '84",
		"type": "dark",
		"import": (() => import("./synthwave-84-UKLz-M7f.js"))
	},
	{
		"id": "tokyo-night",
		"displayName": "Tokyo Night",
		"type": "dark",
		"import": (() => import("./tokyo-night-BuOKl8Iy.js"))
	},
	{
		"id": "vesper",
		"displayName": "Vesper",
		"type": "dark",
		"import": (() => import("./vesper-Ct77WwbS.js"))
	},
	{
		"id": "vitesse-black",
		"displayName": "Vitesse Black",
		"type": "dark",
		"import": (() => import("./vitesse-black-DSvPBaHF.js"))
	},
	{
		"id": "vitesse-dark",
		"displayName": "Vitesse Dark",
		"type": "dark",
		"import": (() => import("./vitesse-dark-C75oTFRA.js"))
	},
	{
		"id": "vitesse-light",
		"displayName": "Vitesse Light",
		"type": "light",
		"import": (() => import("./vitesse-light-DHo4bJRH.js"))
	}
];
var bundledThemes = Object.fromEntries(bundledThemesInfo.map((i) => [i.id, i.import]));
//#endregion
//#region node_modules/.bun/shiki@4.0.2/node_modules/shiki/dist/bundle-full.mjs
var bundle_full_exports = /* @__PURE__ */ __exportAll({
	bundledLanguages: () => bundledLanguages,
	bundledLanguagesAlias: () => bundledLanguagesAlias,
	bundledLanguagesBase: () => bundledLanguagesBase,
	bundledLanguagesInfo: () => bundledLanguagesInfo,
	bundledThemes: () => bundledThemes,
	bundledThemesInfo: () => bundledThemesInfo,
	codeToHast: () => codeToHast,
	codeToHtml: () => codeToHtml,
	codeToTokens: () => codeToTokens,
	codeToTokensBase: () => codeToTokensBase,
	codeToTokensWithThemes: () => codeToTokensWithThemes,
	createHighlighter: () => createHighlighter,
	getLastGrammarState: () => getLastGrammarState,
	getSingletonHighlighter: () => getSingletonHighlighter
});
/**
* Initiate a highlighter instance and load the specified languages and themes.
* Later it can be used synchronously to highlight code.
*
* Importing this function will bundle all languages and themes.
* @see https://shiki.style/guide/bundles#shiki-bundle-full
*
* For granular control over the bundle, check:
* @see https://shiki.style/guide/bundles#fine-grained-bundle
*/
var createHighlighter = /* @__PURE__ */ createBundledHighlighter({
	langs: bundledLanguages,
	themes: bundledThemes,
	engine: () => (0, engine_oniguruma_exports.createOnigurumaEngine)(import("./wasm-CpKQF51l.js"))
});
var { codeToHtml, codeToHast, codeToTokens, codeToTokensBase, codeToTokensWithThemes, getSingletonHighlighter, getLastGrammarState } = /* @__PURE__ */ createSingletonShorthands(createHighlighter, { guessEmbeddedLanguages });
//#endregion
//#region node_modules/.bun/shiki@4.0.2/node_modules/shiki/dist/index.mjs
__reExport(/* @__PURE__ */ __exportAll({
	bundledLanguages: () => bundledLanguages,
	bundledLanguagesAlias: () => bundledLanguagesAlias,
	bundledLanguagesBase: () => bundledLanguagesBase,
	bundledLanguagesInfo: () => bundledLanguagesInfo,
	bundledThemes: () => bundledThemes,
	bundledThemesInfo: () => bundledThemesInfo,
	codeToHast: () => codeToHast,
	codeToHtml: () => codeToHtml,
	codeToTokens: () => codeToTokens,
	codeToTokensBase: () => codeToTokensBase,
	codeToTokensWithThemes: () => codeToTokensWithThemes,
	createHighlighter: () => createHighlighter,
	createJavaScriptRegexEngine: () => createJavaScriptRegexEngine,
	createOnigurumaEngine: () => createOnigurumaEngine,
	defaultJavaScriptRegexConstructor: () => defaultJavaScriptRegexConstructor,
	getLastGrammarState: () => getLastGrammarState,
	getSingletonHighlighter: () => getSingletonHighlighter,
	loadWasm: () => loadWasm
}), bundle_full_exports);
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/resolveLanguage.js
async function resolveLanguage(lang) {
	if (isWorkerContext()) throw new Error(`resolveLanguage("${lang}") cannot be called from a worker context. Languages must be pre-resolved on the main thread and passed to the worker via the resolvedLanguages parameter.`);
	const resolver = ResolvingLanguages.get(lang);
	if (resolver != null) return resolver;
	try {
		let loader = RegisteredCustomLanguages.get(lang);
		if (loader == null && Object.prototype.hasOwnProperty.call(bundledLanguages, lang)) loader = bundledLanguages[lang];
		if (loader == null) throw new Error(`resolveLanguage: "${lang}" not found in bundled or custom languages`);
		const resolver = loader().then(({ default: data }) => {
			const resolvedLang = {
				name: lang,
				data
			};
			if (!ResolvedLanguages.has(lang)) ResolvedLanguages.set(lang, resolvedLang);
			return resolvedLang;
		});
		ResolvingLanguages.set(lang, resolver);
		return await resolver;
	} finally {
		ResolvingLanguages.delete(lang);
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/getResolvedOrResolveLanguage.js
function getResolvedOrResolveLanguage(language) {
	return ResolvedLanguages.get(language) ?? resolveLanguage(language);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/constants.js
var AttachedThemes = /* @__PURE__ */ new Set();
//#endregion
//#region node_modules/.bun/@pierre+theming@1.0.1+f76cb534c11da2ac/node_modules/@pierre/theming/dist/modules/createThemeCollection.js
function createThemeCollection(options) {
	const descriptors = [];
	const seen = /* @__PURE__ */ new Set();
	for (const entry of getCollectionEntries(options.themes)) {
		const themes = isThemeCollectionSource(entry) ? entry.getThemes() : [entry];
		for (const descriptor of themes) {
			if (seen.has(descriptor.name)) throw new Error(`Theme collection already contains theme "${descriptor.name}"`);
			seen.add(descriptor.name);
			descriptors.push(descriptor);
		}
	}
	const allThemes = Object.freeze([...descriptors]);
	const lightThemes = Object.freeze(allThemes.filter((descriptor) => descriptor.colorScheme === "light"));
	const darkThemes = Object.freeze(allThemes.filter((descriptor) => descriptor.colorScheme === "dark"));
	const themesByName = new Map(allThemes.map((descriptor) => [descriptor.name, descriptor]));
	const allNames = Object.freeze(allThemes.map((descriptor) => descriptor.name));
	const lightNames = Object.freeze(lightThemes.map((descriptor) => descriptor.name));
	const darkNames = Object.freeze(darkThemes.map((descriptor) => descriptor.name));
	function filteredThemes(filterOptions) {
		if (filterOptions == null) return allThemes;
		const { colorScheme, collection } = filterOptions;
		if (collection == null) {
			if (colorScheme === "light") return lightThemes;
			if (colorScheme === "dark") return darkThemes;
			return allThemes;
		}
		return allThemes.filter((descriptor) => {
			if (descriptor.collection !== collection) return false;
			return colorScheme == null || descriptor.colorScheme === colorScheme;
		});
	}
	return {
		getTheme(name) {
			return themesByName.get(name);
		},
		getThemes(themeOptions) {
			return filteredThemes(themeOptions);
		},
		getThemeNames(namesOptions) {
			if (namesOptions?.collection == null) {
				if (namesOptions?.colorScheme === "light") return lightNames;
				if (namesOptions?.colorScheme === "dark") return darkNames;
				return allNames;
			}
			return filteredThemes(namesOptions).map((descriptor) => descriptor.name);
		},
		hasTheme(name) {
			return themesByName.has(name);
		},
		orderBy(compare) {
			return createThemeCollection({ themes: allThemes.map((descriptor, index) => ({
				descriptor,
				index
			})).sort((a, b) => {
				const result = compare(a.descriptor, b.descriptor);
				if (result !== 0) return result;
				return a.index - b.index;
			}).map((entry) => entry.descriptor) });
		},
		pick(names) {
			const picked = [];
			const pickedNames = /* @__PURE__ */ new Set();
			for (const name of names) {
				if (pickedNames.has(name)) throw new Error(`Theme collection pick already includes theme "${name}"`);
				pickedNames.add(name);
				const descriptor = themesByName.get(name);
				if (descriptor == null) throw new Error(`Theme collection does not contain theme "${name}"`);
				picked.push(descriptor);
			}
			return createThemeCollection({ themes: picked });
		},
		registerInto(resolver) {
			for (const descriptor of allThemes) resolver.registerThemeIfAbsent(descriptor.name, descriptor.load);
		}
	};
}
function getCollectionEntries(input) {
	if (isThemeCollectionEntry(input)) return [input];
	return input;
}
function isThemeCollectionEntry(input) {
	return isThemeCollectionSource(input) || isThemeDescriptor(input);
}
function isThemeDescriptor(input) {
	return typeof input.name === "string" && typeof input.load === "function";
}
function isThemeCollectionSource(entry) {
	return typeof entry.getThemes === "function";
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/themeResolver.js
var themeResolver = createThemeResolver();
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/attachResolvedThemes.js
function attachResolvedThemes(themes, highlighter) {
	themes = Array.isArray(themes) ? themes : [themes];
	for (let themeRef of themes) {
		let resolvedTheme;
		if (typeof themeRef === "string") {
			resolvedTheme = themeResolver.getResolvedTheme(themeRef);
			if (resolvedTheme == null) throw new Error(`loadResolvedThemes: ${themeRef} is not resolved, you must resolve it before calling loadResolvedThemes`);
		} else {
			resolvedTheme = themeRef;
			themeRef = themeRef.name;
			if (themeResolver.getResolvedTheme(themeRef) == null) themeResolver.seedResolvedTheme(themeRef, resolvedTheme);
		}
		if (AttachedThemes.has(themeRef)) continue;
		AttachedThemes.add(themeRef);
		highlighter.loadThemeSync(resolvedTheme);
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/cleanUpResolvedThemes.js
function cleanUpResolvedThemes() {
	themeResolver.clearResolvedThemes();
	AttachedThemes.clear();
}
//#endregion
//#region node_modules/.bun/@pierre+theming@1.0.1+f76cb534c11da2ac/node_modules/@pierre/theming/dist/modules/createTheme.js
function createTheme({ name, load, colorScheme, collection, displayName }) {
	return {
		name,
		colorScheme,
		collection,
		displayName,
		load: normalizingLoader(load)
	};
}
function normalizingLoader(loader) {
	return async () => {
		return normalizeTheme(unwrapDefault(await loader()));
	};
}
//#endregion
//#region node_modules/.bun/@pierre+theming@1.0.1+f76cb534c11da2ac/node_modules/@pierre/theming/dist/collections/pierre.js
var PIERRE_COLLECTION = "pierre";
var DARK_PIERRE_THEMES = [
	"pierre-dark",
	"pierre-dark-soft",
	"pierre-dark-vibrant",
	"pierre-dark-protanopia-deuteranopia",
	"pierre-dark-tritanopia"
];
var LIGHT_PIERRE_THEMES = [
	"pierre-light",
	"pierre-light-soft",
	"pierre-light-vibrant",
	"pierre-light-protanopia-deuteranopia",
	"pierre-light-tritanopia"
];
var PIERRE_THEMES = [...LIGHT_PIERRE_THEMES, ...DARK_PIERRE_THEMES];
var LIGHT_PIERRE_THEME_NAMES = new Set(LIGHT_PIERRE_THEMES);
function pierreColorScheme(name) {
	if (LIGHT_PIERRE_THEME_NAMES.has(name)) return "light";
	return "dark";
}
var PIERRE_THEME_DISPLAY_NAMES = {
	"pierre-dark": "Pierre Dark",
	"pierre-dark-soft": "Pierre Dark Soft",
	"pierre-dark-vibrant": "Pierre Dark Vibrant",
	"pierre-dark-protanopia-deuteranopia": "Pierre Dark Protanopia & Deuteranopia",
	"pierre-dark-tritanopia": "Pierre Dark Tritanopia",
	"pierre-light": "Pierre Light",
	"pierre-light-soft": "Pierre Light Soft",
	"pierre-light-vibrant": "Pierre Light Vibrant",
	"pierre-light-protanopia-deuteranopia": "Pierre Light Protanopia & Deuteranopia",
	"pierre-light-tritanopia": "Pierre Light Tritanopia"
};
var PIERRE_THEME_IMPORTS = {
	"pierre-dark": () => import("./pierre-dark-CtOSoZp_.js"),
	"pierre-dark-soft": () => import("./pierre-dark-soft-Bkunvgrq.js"),
	"pierre-dark-vibrant": () => import("./pierre-dark-vibrant-9_9agdtv.js"),
	"pierre-dark-protanopia-deuteranopia": () => import("./pierre-dark-protanopia-deuteranopia-DPEq7TYC.js"),
	"pierre-dark-tritanopia": () => import("./pierre-dark-tritanopia-DNoGo5Hd.js"),
	"pierre-light": () => import("./pierre-light-BnTq4qtD.js"),
	"pierre-light-soft": () => import("./pierre-light-soft-CePZrFAy.js"),
	"pierre-light-vibrant": () => import("./pierre-light-vibrant-CuUn2BCb.js"),
	"pierre-light-protanopia-deuteranopia": () => import("./pierre-light-protanopia-deuteranopia-DSnUxocW.js"),
	"pierre-light-tritanopia": () => import("./pierre-light-tritanopia-Cwj0Sc8s.js")
};
function createPierreTheme(name) {
	return createTheme({
		name,
		collection: PIERRE_COLLECTION,
		colorScheme: pierreColorScheme(name),
		displayName: PIERRE_THEME_DISPLAY_NAMES[name],
		load: PIERRE_THEME_IMPORTS[name]
	});
}
var pierreThemes = createThemeCollection({ themes: PIERRE_THEMES.map((name) => createPierreTheme(name)) });
//#endregion
//#region node_modules/.bun/@pierre+theming@1.0.1+f76cb534c11da2ac/node_modules/@pierre/theming/dist/collections/shiki.js
var SHIKI_COLLECTION = "shiki";
var LIGHT_SHIKI_THEMES = [
	"ayu-light",
	"catppuccin-latte",
	"everforest-light",
	"github-light",
	"github-light-default",
	"github-light-high-contrast",
	"gruvbox-light-hard",
	"gruvbox-light-medium",
	"gruvbox-light-soft",
	"horizon-bright",
	"kanagawa-lotus",
	"light-plus",
	"material-theme-lighter",
	"min-light",
	"night-owl-light",
	"one-light",
	"rose-pine-dawn",
	"slack-ochin",
	"snazzy-light",
	"solarized-light",
	"vitesse-light"
];
var DARK_SHIKI_THEMES = [
	"andromeeda",
	"aurora-x",
	"ayu-dark",
	"ayu-mirage",
	"catppuccin-frappe",
	"catppuccin-macchiato",
	"catppuccin-mocha",
	"dark-plus",
	"dracula",
	"dracula-soft",
	"everforest-dark",
	"github-dark",
	"github-dark-default",
	"github-dark-dimmed",
	"github-dark-high-contrast",
	"gruvbox-dark-hard",
	"gruvbox-dark-medium",
	"gruvbox-dark-soft",
	"horizon",
	"houston",
	"kanagawa-dragon",
	"kanagawa-wave",
	"laserwave",
	"material-theme",
	"material-theme-darker",
	"material-theme-ocean",
	"material-theme-palenight",
	"min-dark",
	"monokai",
	"night-owl",
	"nord",
	"one-dark-pro",
	"plastic",
	"poimandres",
	"red",
	"rose-pine",
	"rose-pine-moon",
	"slack-dark",
	"solarized-dark",
	"synthwave-84",
	"tokyo-night",
	"vesper",
	"vitesse-black",
	"vitesse-dark"
];
var LIGHT_SHIKI_THEME_NAMES = new Set(LIGHT_SHIKI_THEMES);
function shikiColorScheme(name) {
	if (LIGHT_SHIKI_THEME_NAMES.has(name)) return "light";
	return "dark";
}
var SHIKI_THEME_IMPORTS = {
	andromeeda: () => import("./andromeeda-B4yjpELI.js"),
	"aurora-x": () => import("./aurora-x-B_F-UzD2.js"),
	"ayu-dark": () => import("./ayu-dark-DhFxACK4.js"),
	"ayu-light": () => import("./ayu-light-BzdOiRwE.js"),
	"ayu-mirage": () => import("./ayu-mirage-CqSXQORW.js"),
	"catppuccin-frappe": () => import("./catppuccin-frappe-DXr1U2q8.js"),
	"catppuccin-latte": () => import("./catppuccin-latte-Cp9hXquB.js"),
	"catppuccin-macchiato": () => import("./catppuccin-macchiato-BRVMiK3O.js"),
	"catppuccin-mocha": () => import("./catppuccin-mocha-x5M_hn20.js"),
	"dark-plus": () => import("./dark-plus-B9qaWiZb.js"),
	dracula: () => import("./dracula-CZiVqHIP.js"),
	"dracula-soft": () => import("./dracula-soft-DfMOK6qU.js"),
	"everforest-dark": () => import("./everforest-dark-CQi4Sf3Z.js"),
	"everforest-light": () => import("./everforest-light-CbDm8oo5.js"),
	"github-dark": () => import("./github-dark-rJU4-y2l.js"),
	"github-dark-default": () => import("./github-dark-default-_9HYf0jh.js"),
	"github-dark-dimmed": () => import("./github-dark-dimmed-DwF3tvSu.js"),
	"github-dark-high-contrast": () => import("./github-dark-high-contrast-BrxRtZ3T.js"),
	"github-light": () => import("./github-light-CzHckFmF.js"),
	"github-light-default": () => import("./github-light-default-DFXPSyyu.js"),
	"github-light-high-contrast": () => import("./github-light-high-contrast-4bgsxumj.js"),
	"gruvbox-dark-hard": () => import("./gruvbox-dark-hard-D0WIQjpk.js"),
	"gruvbox-dark-medium": () => import("./gruvbox-dark-medium-9sb68oF5.js"),
	"gruvbox-dark-soft": () => import("./gruvbox-dark-soft-C4oRj0MJ.js"),
	"gruvbox-light-hard": () => import("./gruvbox-light-hard-3LdREJ4f.js"),
	"gruvbox-light-medium": () => import("./gruvbox-light-medium-DuzIw1pS.js"),
	"gruvbox-light-soft": () => import("./gruvbox-light-soft-DaKo8A8e.js"),
	horizon: () => import("./horizon-BICEid2Q.js"),
	"horizon-bright": () => import("./horizon-bright-_vFu7yW_.js"),
	houston: () => import("./houston-ByvWzx_D.js"),
	"kanagawa-dragon": () => import("./kanagawa-dragon-BnOhqXgj.js"),
	"kanagawa-lotus": () => import("./kanagawa-lotus-C-cPK0RC.js"),
	"kanagawa-wave": () => import("./kanagawa-wave-CI4l_biU.js"),
	laserwave: () => import("./laserwave-BXG4fD_6.js"),
	"light-plus": () => import("./light-plus-BSRdLiCo.js"),
	"material-theme": () => import("./material-theme-1RPYImuI.js"),
	"material-theme-darker": () => import("./material-theme-darker-DI3OEnG-.js"),
	"material-theme-lighter": () => import("./material-theme-lighter-DsI9ER_j.js"),
	"material-theme-ocean": () => import("./material-theme-ocean-BCOyKQ2E.js"),
	"material-theme-palenight": () => import("./material-theme-palenight-dgby2lcV.js"),
	"min-dark": () => import("./min-dark-DmYL5urg.js"),
	"min-light": () => import("./min-light-CXkAmn1I.js"),
	monokai: () => import("./monokai-Bodz_vhc.js"),
	"night-owl": () => import("./night-owl-DSzeI7Qw.js"),
	"night-owl-light": () => import("./night-owl-light-QGMTqVgc.js"),
	nord: () => import("./nord-XYO6PRDD.js"),
	"one-dark-pro": () => import("./one-dark-pro-CqgI9EVt.js"),
	"one-light": () => import("./one-light-p9STbcy8.js"),
	plastic: () => import("./plastic-D1DEGRtk.js"),
	poimandres: () => import("./poimandres-Cp0cHf71.js"),
	red: () => import("./red-CBm5xWbS.js"),
	"rose-pine": () => import("./rose-pine-CsMXEpAA.js"),
	"rose-pine-dawn": () => import("./rose-pine-dawn-MM3_pymF.js"),
	"rose-pine-moon": () => import("./rose-pine-moon-B6FzoeyJ.js"),
	"slack-dark": () => import("./slack-dark-BJyO7e1p.js"),
	"slack-ochin": () => import("./slack-ochin-DLW0gE0H.js"),
	"snazzy-light": () => import("./snazzy-light-J5lQlWJ8.js"),
	"solarized-dark": () => import("./solarized-dark-ByJ8Ofyf.js"),
	"solarized-light": () => import("./solarized-light-CwFsPqEQ.js"),
	"synthwave-84": () => import("./synthwave-84-UKLz-M7f.js"),
	"tokyo-night": () => import("./tokyo-night-BuOKl8Iy.js"),
	vesper: () => import("./vesper-Ct77WwbS.js"),
	"vitesse-black": () => import("./vitesse-black-DSvPBaHF.js"),
	"vitesse-dark": () => import("./vitesse-dark-C75oTFRA.js"),
	"vitesse-light": () => import("./vitesse-light-DHo4bJRH.js")
};
function createShikiTheme(name) {
	return createTheme({
		name,
		collection: SHIKI_COLLECTION,
		colorScheme: shikiColorScheme(name),
		load: SHIKI_THEME_IMPORTS[name]
	});
}
var shikiThemes = createThemeCollection({ themes: Object.freeze([...LIGHT_SHIKI_THEMES.map((name) => createShikiTheme(name)), ...DARK_SHIKI_THEMES.map((name) => createShikiTheme(name))]) });
createThemeCollection({ themes: [pierreThemes, shikiThemes] });
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/themeResolution.js
function prepareThemeResolution(themeName) {
	if (isWorkerContext()) throw new Error(`Theme "${themeName}" cannot be resolved from a worker context. Themes must be pre-resolved on the main thread and passed to the worker via the resolvedLanguages parameter.`);
	if (themeResolver.hasRegisteredTheme(themeName)) return;
	const descriptor = shikiThemes.getTheme(themeName);
	if (descriptor != null) {
		themeResolver.registerThemeIfAbsent(descriptor.name, descriptor.load);
		return;
	}
	throw new Error(`No valid theme loader registered for "${themeName}"`);
}
function validateResolvedThemeName(themeName, theme) {
	if (theme.name !== themeName) throw new Error(`resolvedTheme: themeName: ${themeName} does not match theme.name: ${theme.name}`);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/resolveTheme.js
async function resolveTheme(themeName) {
	prepareThemeResolution(themeName);
	const theme = await themeResolver.resolveTheme(themeName);
	validateResolvedThemeName(themeName, theme);
	return theme;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/getResolvedOrResolveTheme.js
function getResolvedOrResolveTheme(themeName) {
	return themeResolver.getResolvedTheme(themeName) ?? resolveTheme(themeName);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/shared_highlighter.js
var highlighter;
async function getSharedHighlighter({ themes, langs, preferredHighlighter = "shiki-js" }) {
	highlighter ??= createHighlighter({
		themes: [],
		langs: ["text"],
		engine: preferredHighlighter === "shiki-wasm" ? createOnigurumaEngine(import("./wasm-CpKQF51l.js")) : createJavaScriptRegexEngine()
	});
	const instance = isHighlighterLoading(highlighter) ? await highlighter : highlighter;
	highlighter = instance;
	const languageLoaders = [];
	for (const language of langs) {
		if (language === "text" || language === "ansi") continue;
		const maybeResolvedLanguage = getResolvedOrResolveLanguage(language);
		if ("then" in maybeResolvedLanguage) languageLoaders.push(maybeResolvedLanguage);
		else attachResolvedLanguages(maybeResolvedLanguage, instance);
	}
	const themeLoaders = [];
	for (const themeName of themes) {
		const maybeResolvedTheme = getResolvedOrResolveTheme(themeName);
		if ("then" in maybeResolvedTheme) themeLoaders.push(maybeResolvedTheme);
		else attachResolvedThemes(maybeResolvedTheme, highlighter);
	}
	if (languageLoaders.length > 0 || themeLoaders.length > 0) await Promise.all([Promise.all(languageLoaders).then((languages) => {
		attachResolvedLanguages(languages, instance);
	}), Promise.all(themeLoaders).then((themes) => {
		attachResolvedThemes(themes, instance);
	})]);
	return instance;
}
function isHighlighterLoaded(h = highlighter) {
	return h != null && !("then" in h);
}
function getHighlighterIfLoaded() {
	if (highlighter != null && !("then" in highlighter)) return highlighter;
}
function isHighlighterLoading(h = highlighter) {
	return h != null && "then" in h;
}
function isHighlighterNull(h = highlighter) {
	return h == null;
}
async function preloadHighlighter(options) {
	await getSharedHighlighter(options);
}
async function disposeHighlighter() {
	if (highlighter == null) return;
	(await highlighter).dispose();
	cleanUpResolvedLanguages();
	cleanUpResolvedThemes();
	highlighter = void 0;
}
for (const descriptor of pierreThemes.getThemes()) themeResolver.registerThemeIfAbsent(descriptor.name, descriptor.load);
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getThemes.js
function getThemes(theme = DEFAULT_THEMES) {
	const themesArr = [];
	if (typeof theme === "string") themesArr.push(theme);
	else {
		themesArr.push(theme.dark);
		themesArr.push(theme.light);
	}
	return themesArr;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/areThemesAttached.js
function areThemesAttached(themes) {
	for (const theme of getThemes(themes)) if (!AttachedThemes.has(theme)) return false;
	return true;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/hasResolvedThemes.js
function hasResolvedThemes(themeNames) {
	return themeResolver.hasResolvedThemes(themeNames);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areFileRenderOptionsEqual.js
function areFileRenderOptionsEqual(optionsA, optionsB) {
	return areThemesEqual(optionsA.theme, optionsB.theme) && optionsA.useTokenTransformer === optionsB.useTokenTransformer && optionsA.tokenizeMaxLineLength === optionsB.tokenizeMaxLineLength;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areRenderRangesEqual.js
function areRenderRangesEqual(renderRangeA, renderRangeB) {
	if (renderRangeA == null || renderRangeB == null) return renderRangeA === renderRangeB;
	return renderRangeA.startingLine === renderRangeB.startingLine && renderRangeA.totalLines === renderRangeB.totalLines && renderRangeA.bufferBefore === renderRangeB.bufferBefore && renderRangeA.bufferAfter === renderRangeB.bufferAfter;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createAnnotationElement.js
function createAnnotationElement(span) {
	return createHastElement({
		tagName: "div",
		children: [createHastElement({
			tagName: "div",
			children: span.annotations?.map((slotId) => createHastElement({
				tagName: "slot",
				properties: { name: slotId }
			})),
			properties: { "data-annotation-content": "" }
		})],
		properties: { "data-line-annotation": `${span.hunkIndex},${span.lineIndex}` }
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getIconForType.js
function getIconForType(type) {
	switch (type) {
		case "file": return "diffs-icon-file-code";
		case "change": return "diffs-icon-symbol-modified";
		case "new": return "diffs-icon-symbol-added";
		case "deleted": return "diffs-icon-symbol-deleted";
		case "rename-pure":
		case "rename-changed": return "diffs-icon-symbol-moved";
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createFileHeaderElement.js
function createFileHeaderElement({ fileOrDiff, mode, stickyHeader }) {
	const fileDiff = "type" in fileOrDiff ? fileOrDiff : void 0;
	const properties = {
		"data-diffs-header": mode,
		"data-change-type": fileDiff?.type,
		"data-sticky": stickyHeader ? "" : void 0
	};
	return createHastElement({
		tagName: "div",
		children: [mode === "custom" ? createHastElement({
			tagName: "slot",
			properties: { name: CUSTOM_HEADER_SLOT_ID }
		}) : createHeaderElement({
			name: fileOrDiff.name,
			prevName: "prevName" in fileOrDiff ? fileOrDiff.prevName : void 0,
			iconType: fileDiff?.type ?? "file"
		}), ...mode === "custom" ? [] : [createMetadataElement(fileDiff)]],
		properties
	});
}
function createHeaderElement({ name, prevName, iconType }) {
	const children = [createHastElement({
		tagName: "slot",
		properties: { name: HEADER_PREFIX_SLOT_ID }
	}), createIconElement({
		name: getIconForType(iconType),
		properties: { "data-change-icon": iconType }
	})];
	if (prevName != null) {
		children.push(createHastElement({
			tagName: "div",
			children: [createHastElement({
				tagName: "bdi",
				children: [createTextNodeElement(prevName)]
			})],
			properties: { "data-prev-name": "" }
		}));
		children.push(createIconElement({
			name: "diffs-icon-arrow-right-short",
			properties: { "data-rename-icon": "" }
		}));
	}
	children.push(createHastElement({
		tagName: "div",
		children: [createHastElement({
			tagName: "bdi",
			children: [createTextNodeElement(name)]
		})],
		properties: { "data-title": "" }
	}));
	children.push(createHastElement({
		tagName: "slot",
		properties: { name: HEADER_FILENAME_SUFFIX_SLOT_ID }
	}));
	return createHastElement({
		tagName: "div",
		children,
		properties: { "data-header-content": "" }
	});
}
function createMetadataElement(fileDiff) {
	const children = [];
	if (fileDiff != null) {
		let additions = 0;
		let deletions = 0;
		for (const hunk of fileDiff.hunks) {
			additions += hunk.additionLines;
			deletions += hunk.deletionLines;
		}
		if (deletions > 0 || additions === 0) children.push(createHastElement({
			tagName: "span",
			children: [createTextNodeElement(`-${deletions}`)],
			properties: { "data-deletions-count": "" }
		}));
		if (additions > 0 || deletions === 0) children.push(createHastElement({
			tagName: "span",
			children: [createTextNodeElement(`+${additions}`)],
			properties: { "data-additions-count": "" }
		}));
	}
	children.push(createHastElement({
		tagName: "slot",
		properties: { name: HEADER_METADATA_SLOT_ID }
	}));
	return createHastElement({
		tagName: "div",
		children,
		properties: { "data-metadata": "" }
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createPreElement.js
function createPreElement(options) {
	return createHastElement({
		tagName: "pre",
		properties: createPreWrapperProperties(options)
	});
}
function createPreWrapperProperties({ diffIndicators, disableBackground, disableLineNumbers, overflow, split, totalLines, type, customProperties }) {
	return {
		...customProperties,
		"data-diff": type === "diff" ? "" : void 0,
		"data-file": type === "file" ? "" : void 0,
		"data-diff-type": type === "diff" ? split ? "split" : "single" : void 0,
		"data-overflow": overflow,
		"data-disable-line-numbers": disableLineNumbers ? "" : void 0,
		"data-background": !disableBackground ? "" : void 0,
		"data-indicators": diffIndicators === "bars" || diffIndicators === "classic" ? diffIndicators : void 0,
		style: `--diffs-min-number-column-width-default:${`${totalLines}`.length}ch;`
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getHighlighterOptions.js
function getHighlighterOptions(lang, { theme, preferredHighlighter = "shiki-js" }) {
	return {
		langs: [lang ?? "text"],
		themes: getThemes(theme),
		preferredHighlighter
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/processLine.js
function processLine$1(node, line, state) {
	const lineInfo = typeof state.lineInfo === "function" ? state.lineInfo(line) : state.lineInfo[line - 1];
	if (lineInfo == null) {
		const errorMessage = `processLine: line ${line}, contains no state.lineInfo`;
		console.error(errorMessage, {
			node,
			line,
			state
		});
		throw new Error(errorMessage);
	}
	node.tagName = "div";
	node.properties["data-line"] = lineInfo.lineNumber;
	node.properties["data-alt-line"] = lineInfo.altLineNumber;
	node.properties["data-line-type"] = lineInfo.type;
	node.properties["data-line-index"] = lineInfo.lineIndex;
	if (node.children.length === 0) node.children.push(createTextNodeElement("\n"));
	return node;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/wrapTokenFragments.js
var NO_TOKEN = Symbol("no-token");
var MULTIPLE_TOKENS = Symbol("multiple-tokens");
function wrapTokenFragments(container) {
	const ownTokenChar = getTokenChar(container);
	if (ownTokenChar != null) return ownTokenChar;
	let containerTokenState = NO_TOKEN;
	const wrappedChildren = [];
	let currentTokenChildren = [];
	let currentTokenChar;
	const flushTokenChildren = () => {
		if (currentTokenChildren.length === 0 || currentTokenChar == null) {
			currentTokenChildren = [];
			currentTokenChar = void 0;
			return;
		}
		if (currentTokenChildren.length === 1) {
			const child = currentTokenChildren[0];
			if (child?.type === "element") {
				setTokenChar(child, currentTokenChar);
				for (const grandChild of child.children) stripTokenChar(grandChild);
			} else stripTokenChar(child);
			wrappedChildren.push(child);
			currentTokenChildren = [];
			currentTokenChar = void 0;
			return;
		}
		for (const child of currentTokenChildren) stripTokenChar(child);
		wrappedChildren.push(createHastElement({
			tagName: "span",
			properties: { "data-char": currentTokenChar },
			children: currentTokenChildren
		}));
		currentTokenChildren = [];
		currentTokenChar = void 0;
	};
	const mergeContainerTokenState = (childTokenState) => {
		if (childTokenState === NO_TOKEN) return;
		if (childTokenState === MULTIPLE_TOKENS) {
			containerTokenState = MULTIPLE_TOKENS;
			return;
		}
		if (containerTokenState === NO_TOKEN) {
			containerTokenState = childTokenState;
			return;
		}
		if (containerTokenState !== childTokenState) containerTokenState = MULTIPLE_TOKENS;
	};
	for (const child of container.children) {
		const childTokenState = child.type === "element" ? wrapTokenFragments(child) : NO_TOKEN;
		mergeContainerTokenState(childTokenState);
		if (typeof childTokenState !== "number") {
			flushTokenChildren();
			wrappedChildren.push(child);
			continue;
		}
		if (currentTokenChar != null && currentTokenChar !== childTokenState) flushTokenChildren();
		currentTokenChar ??= childTokenState;
		currentTokenChildren.push(child);
	}
	flushTokenChildren();
	container.children = wrappedChildren;
	return containerTokenState;
}
function getTokenChar(node) {
	const value = node.properties["data-char"];
	if (typeof value === "number") return value;
}
function stripTokenChar(node) {
	if (node.type !== "element") return;
	node.properties["data-char"] = void 0;
	for (const child of node.children) stripTokenChar(child);
}
function setTokenChar(node, char) {
	node.properties["data-char"] = char;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createTransformerWithState.js
function createTransformerWithState(useTokenTransformer = false, useCSSClasses = false) {
	const state = { lineInfo: [] };
	const transformers = [{
		line(node) {
			delete node.properties.class;
			return node;
		},
		pre(pre) {
			const code = findCodeElement(pre);
			const children = [];
			if (code != null) {
				let index = 1;
				for (const node of code.children) {
					if (node.type !== "element") continue;
					if (useTokenTransformer) wrapTokenFragments(node);
					children.push(processLine$1(node, index, state));
					index++;
				}
				code.children = children;
			}
			return pre;
		},
		...useTokenTransformer ? {
			tokens(lines) {
				for (const line of lines) {
					let col = 0;
					for (const token of line) {
						const tokenWithOriginalRange = token;
						tokenWithOriginalRange.__lineChar ??= col;
						col += token.content.length;
					}
				}
			},
			preprocess(_code, options) {
				options.mergeWhitespaces = "never";
			},
			span(hast, _line, _char, _lineElement, token) {
				if (token?.offset != null && token.content != null) {
					const tokenChar = token.__lineChar;
					if (tokenChar != null) hast.properties["data-char"] = tokenChar;
					return hast;
				}
				return hast;
			}
		} : null
	}];
	if (useCSSClasses) transformers.push(tokenStyleNormalizer, toClass);
	if (useTokenTransformer) transformers.push({ line: (node) => {
		if (node.type === "element" && node.children.length === 0) node.children.push({
			type: "element",
			tagName: "br",
			properties: {},
			children: []
		});
		return node;
	} });
	return {
		state,
		transformers,
		toClass
	};
}
var toClass = transformerStyleToClass({ classPrefix: "hl-" });
var tokenStyleNormalizer = {
	name: "token-style-normalizer",
	tokens(lines) {
		for (const line of lines) for (const token of line) {
			if (token.htmlStyle != null) continue;
			const style = {};
			if (token.color != null) style.color = token.color;
			if (token.bgColor != null) style["background-color"] = token.bgColor;
			if (token.fontStyle != null && token.fontStyle !== 0) {
				if ((token.fontStyle & 1) !== 0) style["font-style"] = "italic";
				if ((token.fontStyle & 2) !== 0) style["font-weight"] = "bold";
				if ((token.fontStyle & 4) !== 0) style["text-decoration"] = "underline";
			}
			if (Object.keys(style).length > 0) token.htmlStyle = style;
		}
	}
};
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/formatCSSVariablePrefix.js
function formatCSSVariablePrefix(type) {
	return `--${type === "token" ? "diffs-token" : "diffs"}-`;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getHighlighterThemeStyles.js
function getHighlighterThemeStyles({ theme = DEFAULT_THEMES, highlighter, prefix }) {
	let styles = "";
	if (typeof theme === "string") {
		const themeData = highlighter.getTheme(theme);
		const normalized = normalizeThemeColors(themeData);
		styles += `color:${normalized.fg};`;
		styles += `background-color:${normalized.bg};`;
		styles += `${formatCSSVariablePrefix("global")}fg:${normalized.fg};`;
		styles += `${formatCSSVariablePrefix("global")}bg:${normalized.bg};`;
		styles += getGitVariables(themeData, prefix);
	} else {
		let themeData = highlighter.getTheme(theme.dark);
		let normalized = normalizeThemeColors(themeData);
		styles += `${formatCSSVariablePrefix("global")}dark:${normalized.fg};`;
		styles += `${formatCSSVariablePrefix("global")}dark-bg:${normalized.bg};`;
		styles += getGitVariables(themeData, "dark");
		themeData = highlighter.getTheme(theme.light);
		normalized = normalizeThemeColors(themeData);
		styles += `${formatCSSVariablePrefix("global")}light:${normalized.fg};`;
		styles += `${formatCSSVariablePrefix("global")}light-bg:${normalized.bg};`;
		styles += getGitVariables(themeData, "light");
	}
	return styles;
}
function getGitVariables(themeData, modePrefix) {
	modePrefix = modePrefix != null ? `${modePrefix}-` : "";
	let styles = "";
	const additionGreen = themeData.colors?.["gitDecoration.addedResourceForeground"] ?? themeData.colors?.["terminal.ansiGreen"];
	if (additionGreen != null) styles += `${formatCSSVariablePrefix("global")}${modePrefix}addition-color:${additionGreen};`;
	const deletionRed = themeData.colors?.["gitDecoration.deletedResourceForeground"] ?? themeData.colors?.["terminal.ansiRed"];
	if (deletionRed != null) styles += `${formatCSSVariablePrefix("global")}${modePrefix}deletion-color:${deletionRed};`;
	const modifiedBlue = themeData.colors?.["gitDecoration.modifiedResourceForeground"] ?? themeData.colors?.["terminal.ansiBlue"];
	if (modifiedBlue != null) styles += `${formatCSSVariablePrefix("global")}${modePrefix}modified-color:${modifiedBlue};`;
	return styles;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getLineNodes.js
function getLineNodes(nodes) {
	let firstChild = nodes.children[0];
	while (firstChild != null) {
		if (firstChild.type === "element" && firstChild.tagName === "code") return firstChild.children;
		if ("children" in firstChild) firstChild = firstChild.children[0];
		else firstChild = null;
	}
	console.error(nodes);
	throw new Error("getLineNodes: Unable to find children");
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/renderFileWithHighlighter.js
var DEFAULT_PLAIN_TEXT_OPTIONS$1 = { forcePlainText: false };
function renderFileWithHighlighter(file, highlighter, { theme = DEFAULT_THEMES, tokenizeMaxLineLength, useTokenTransformer }, { forcePlainText, startingLine, totalLines, lines } = DEFAULT_PLAIN_TEXT_OPTIONS$1) {
	if (forcePlainText) {
		startingLine ??= 0;
		totalLines ??= Infinity;
	} else {
		startingLine = 0;
		totalLines = Infinity;
	}
	const isWindowedHighlight = startingLine > 0 || totalLines < Infinity;
	const { state, transformers } = createTransformerWithState(useTokenTransformer);
	const lang = forcePlainText ? "text" : file.lang ?? getFiletypeFromFileName(file.name);
	const baseThemeType = typeof theme === "string" ? highlighter.getTheme(theme).type : void 0;
	const themeStyles = getHighlighterThemeStyles({
		theme,
		highlighter
	});
	state.lineInfo = (shikiLineNumber) => ({
		type: "context",
		lineIndex: shikiLineNumber - 1 + startingLine,
		lineNumber: shikiLineNumber + startingLine
	});
	const hastConfig = (() => {
		if (typeof theme === "string") return {
			lang,
			theme,
			transformers,
			defaultColor: false,
			cssVariablePrefix: formatCSSVariablePrefix("token"),
			tokenizeMaxLineLength,
			tokenizeTimeLimit: 0
		};
		return {
			lang,
			themes: theme,
			transformers,
			defaultColor: false,
			cssVariablePrefix: formatCSSVariablePrefix("token"),
			tokenizeMaxLineLength,
			tokenizeTimeLimit: 0
		};
	})();
	const highlightedLines = getLineNodes(highlighter.codeToHast(isWindowedHighlight ? extractWindowedFileContent(lines ?? linesFromFileContents(file.contents), startingLine, totalLines) : file.contents, hastConfig));
	const code = isWindowedHighlight ? new Array(startingLine) : highlightedLines;
	if (isWindowedHighlight) code.push(...highlightedLines);
	return {
		code,
		themeStyles,
		baseThemeType
	};
}
function extractWindowedFileContent(lines, startingLine, totalLines) {
	if (lines.length === 0) return "";
	const endLine = Math.min(startingLine + totalLines, lines.length);
	return lines.slice(startingLine, endLine).join("");
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/includesFileAnnotations.js
var FILE_ANNOTATION_DOM_KEY = `-1,-1`;
function includesFileAnnotations(annotations) {
	return annotations?.some((annotation) => annotation.lineNumber === 0) ?? false;
}
function getFileAnnotations(annotations) {
	const fileAnnotations = annotations[0];
	return fileAnnotations != null && fileAnnotations.length > 0 ? fileAnnotations : void 0;
}
function shouldRenderFileAnnotations(renderRange) {
	return renderRange.startingLine === 0 && renderRange.totalLines > 0;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/applyLineTextWithNewline.js
function applyLineTextWithNewline(line, lineText) {
	if (line.endsWith("\r\n")) return lineText + "\r\n";
	if (line.endsWith("\r")) return lineText + "\r";
	if (line.endsWith("\n")) return lineText + "\n";
	return lineText;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createContentColumn.js
function createContentColumn(children, rowCount) {
	return createHastElement({
		tagName: "div",
		children,
		properties: {
			"data-content": "",
			style: `grid-row: span ${rowCount}`
		}
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/isFilePlainText.js
function isFilePlainText(file) {
	return (file.lang ?? getFiletypeFromFileName(file.name)) === "text";
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/renderers/FileRenderer.js
function isLineCacheForFile(lineCache, file) {
	return file.cacheKey == null ? lineCache.file === file && lineCache.sourceContents === file.contents : lineCache.cacheKey === file.cacheKey;
}
var instanceId$6 = -1;
var FileRenderer = class {
	options;
	onRenderUpdate;
	workerManager;
	__id = `file-renderer:${++instanceId$6}`;
	highlighter;
	renderCache;
	computedLang = "text";
	lineAnnotations = {};
	lineCache;
	pendingStructuralRows;
	textDocumentCache = /* @__PURE__ */ new WeakMap();
	editSessionActive = false;
	constructor(options = { theme: DEFAULT_THEMES }, onRenderUpdate, workerManager) {
		this.options = options;
		this.onRenderUpdate = onRenderUpdate;
		this.workerManager = workerManager;
		if (workerManager?.isWorkingPool() !== true) this.highlighter = areThemesAttached(options.theme ?? DEFAULT_THEMES) ? getHighlighterIfLoaded() : void 0;
	}
	setOptions(options) {
		this.options = options;
	}
	mergeOptions(options) {
		this.options = {
			...this.options,
			...options
		};
	}
	setLineAnnotations(lineAnnotations) {
		this.lineAnnotations = {};
		for (const annotation of lineAnnotations) {
			const arr = this.lineAnnotations[annotation.lineNumber] ?? [];
			this.lineAnnotations[annotation.lineNumber] = arr;
			arr.push(annotation);
		}
	}
	cleanUp() {
		this.recycle();
		this.workerManager = void 0;
		this.onRenderUpdate = void 0;
	}
	/**
	* Enter edit-session mode: rendering happens locally with the token
	* transformer forced on, and worker-pool requests/results are suspended
	* for this renderer. Called on every editor attach, including a re-attach
	* after recycle.
	*/
	beginEditSession() {
		this.editSessionActive = true;
	}
	/** Leave edit-session mode. Rendering returns to the pool when one works. */
	endEditSession() {
		this.editSessionActive = false;
	}
	/**
	* Ensures that the DOM is compatible with editor render updates
	*/
	editorRenderReady() {
		return this.renderCache?.options.useTokenTransformer === true && this.renderCache.highlighted && this.renderCache.result != null;
	}
	recycle() {
		this.clearRenderCache();
		this.highlighter = void 0;
		this.workerManager?.cleanUpTasks(this);
		this.lineCache = void 0;
		this.endEditSession();
		this.textDocumentCache = /* @__PURE__ */ new WeakMap();
	}
	syncEditedContentsToFile() {
		const { renderCache, lineCache } = this;
		if (renderCache?.isDirty !== true || lineCache == null || !isLineCacheForFile(lineCache, renderCache.file)) return;
		renderCache.file.contents = lineCache.lines.join("");
	}
	hasUnkeyedFileContentsChanged(file) {
		const { lineCache } = this;
		return file.cacheKey == null && lineCache != null && lineCache.file === file && lineCache.sourceContents !== file.contents;
	}
	invalidateChangedUnkeyedFile(file) {
		if (!this.hasUnkeyedFileContentsChanged(file)) return;
		this.workerManager?.cleanUpTasks(this);
		this.clearRenderCache();
		this.lineCache = void 0;
		this.textDocumentCache = /* @__PURE__ */ new WeakMap();
	}
	clearRenderCache() {
		this.syncEditedContentsToFile();
		this.pendingStructuralRows = void 0;
		const renderCache = this.renderCache;
		this.renderCache = void 0;
		if (renderCache != null && renderCache.isDirty === true && renderCache.file.cacheKey != null) this.workerManager?.evictFileFromCache(renderCache.file.cacheKey);
	}
	hydrate(file) {
		const { options } = this.getRenderOptions(file);
		const massiveFile = isFileMassive(this.getOrCreateLineCache(file).length, this.getTokenizeMaxLength());
		let cache = this.workerManager?.getFileResultCache(file);
		if (cache != null && !areFileRenderOptionsEqual(options, cache.options)) cache = void 0;
		this.renderCache ??= {
			file,
			options,
			highlighted: !massiveFile && !isFilePlainText(file),
			result: massiveFile ? void 0 : cache?.result,
			renderRange: void 0
		};
		if (!this.editSessionActive && this.workerManager?.isWorkingPool() === true) {
			if (this.renderCache.result == null && !massiveFile) this.workerManager.highlightFileAST(this, file);
		} else if (this.highlighter == null) {
			this.computedLang = file.lang ?? getFiletypeFromFileName(file.name);
			this.initializeHighlighter();
		}
	}
	getLocalHighlightTheme() {
		return this.workerManager?.getFileRenderOptions().theme ?? this.options.theme ?? DEFAULT_THEMES;
	}
	getEffectiveCodeOptions() {
		const poolOptions = this.workerManager?.isWorkingPool() === true ? this.workerManager.getFileRenderOptions() : void 0;
		return {
			theme: this.getLocalHighlightTheme(),
			tokenizeMaxLineLength: poolOptions?.tokenizeMaxLineLength ?? this.options.tokenizeMaxLineLength
		};
	}
	getRenderOptions(file) {
		const options = (() => {
			if (this.workerManager?.isWorkingPool() === true) {
				const poolOptions = this.workerManager.getFileRenderOptions();
				if (this.editSessionActive && poolOptions.useTokenTransformer !== true) return {
					...poolOptions,
					useTokenTransformer: true
				};
				return poolOptions;
			}
			const { tokenizeMaxLineLength = 1e3 } = this.options;
			return {
				theme: this.getLocalHighlightTheme(),
				useTokenTransformer: this.editSessionActive || this.options.useTokenTransformer === true,
				tokenizeMaxLineLength
			};
		})();
		const { renderCache } = this;
		if (renderCache?.result == null) return {
			options,
			forceHighlight: true
		};
		if (!areFilesEqual(file, renderCache.file) || !areFileRenderOptionsEqual(options, renderCache.options)) return {
			options,
			forceHighlight: true
		};
		return {
			options,
			forceHighlight: false
		};
	}
	getOrCreateLineCache(file) {
		this.invalidateChangedUnkeyedFile(file);
		let { lineCache } = this;
		if (lineCache == null || !isLineCacheForFile(lineCache, file)) lineCache = {
			cacheKey: file.cacheKey,
			file,
			sourceContents: file.contents,
			lines: linesFromFileContents(file.contents)
		};
		this.lineCache = lineCache;
		return lineCache.lines;
	}
	getLineCount(file) {
		const lines = this.getOrCreateLineCache(file);
		return this.textDocumentCache.get(file)?.lineCount ?? lines.length;
	}
	updateRenderCache(dirtyLines, themeType, lineCountChangeInFlight = false) {
		this.pendingStructuralRows = void 0;
		if (this.renderCache == null) return;
		const { file, result } = this.renderCache;
		if (result == null) return;
		const pendingStructuralRows = lineCountChangeInFlight ? /* @__PURE__ */ new Map() : void 0;
		this.pendingStructuralRows = pendingStructuralRows;
		const lineCache = this.lineCache != null && isLineCacheForFile(this.lineCache, file) ? this.lineCache : void 0;
		for (const [line, tokens] of dirtyLines) {
			if (pendingStructuralRows === void 0 && lineCache != null && line < lineCache.lines.length) {
				const lineText = tokens.map((token) => token[2]).join("");
				lineCache.lines[line] = applyLineTextWithNewline(lineCache.lines[line] ?? "", lineText);
			}
			const row = {
				type: "element",
				tagName: "div",
				properties: {
					"data-line": line + 1,
					"data-line-type": "context",
					"data-line-index": line
				},
				children: tokens.map(([char, fg, text]) => {
					if (char === 0 && fg === "") {
						if (text === "") return {
							type: "element",
							tagName: "br",
							properties: {},
							children: []
						};
						return {
							type: "text",
							value: text
						};
					}
					return {
						type: "element",
						tagName: "span",
						properties: {
							"data-char": char,
							style: `color:${fg};`
						},
						children: [{
							type: "text",
							value: text
						}]
					};
				})
			};
			if (pendingStructuralRows !== void 0) pendingStructuralRows.set(line, row);
			else result.code[line] = row;
		}
		result.baseThemeType = themeType;
		this.renderCache.isDirty = true;
	}
	applyDocumentChange(textDocument) {
		const pendingStructuralRows = this.pendingStructuralRows;
		this.pendingStructuralRows = void 0;
		if (this.renderCache == null) return;
		const { file, result } = this.renderCache;
		if (result == null) return;
		const previousLines = this.lineCache != null && isLineCacheForFile(this.lineCache, file) ? this.lineCache.lines : linesFromFileContents(file.contents);
		const nextLines = linesFromFileContents(textDocument.getText());
		if (previousLines.length !== nextLines.length) {
			const maxShared = Math.min(previousLines.length, nextLines.length);
			let prefix = 0;
			while (prefix < maxShared && previousLines[prefix] === nextLines[prefix]) prefix++;
			let suffix = 0;
			while (suffix < maxShared - prefix && previousLines[previousLines.length - 1 - suffix] === nextLines[nextLines.length - 1 - suffix]) suffix++;
			const previousCode = result.code;
			result.code = new Array(nextLines.length);
			for (let i = 0; i < prefix; i++) result.code[i] = previousCode[i];
			for (let i = 0; i < suffix; i++) result.code[nextLines.length - 1 - i] = previousCode[previousLines.length - 1 - i];
			if (pendingStructuralRows !== void 0) {
				for (const [line, row] of pendingStructuralRows) if (line < nextLines.length) result.code[line] = row;
			}
			for (let i = prefix; i < nextLines.length - suffix; i++) result.code[i] ??= {
				type: "element",
				tagName: "div",
				properties: {
					"data-line": i + 1,
					"data-line-type": "context",
					"data-line-index": i
				},
				children: [{
					type: "element",
					tagName: "span",
					properties: { "data-char": 0 },
					children: [{
						type: "text",
						value: textDocument.getLineText(i)
					}]
				}]
			};
			for (let i = 0; i < result.code.length; i++) {
				const line = result.code[i];
				if (line?.type === "element") {
					line.properties["data-line"] = i + 1;
					line.properties["data-line-index"] = i;
				}
			}
			this.renderCache.isDirty = true;
		}
		this.lineCache = {
			cacheKey: file.cacheKey,
			file,
			sourceContents: file.contents,
			lines: nextLines
		};
		this.textDocumentCache.set(file, textDocument);
	}
	renderFile(file = this.renderCache?.file, renderRange = DEFAULT_RENDER_RANGE) {
		if (file == null) return;
		this.invalidateChangedUnkeyedFile(file);
		if (this.renderCache?.isDirty === true && !areFilesEqual(file, this.renderCache.file)) {
			this.clearRenderCache();
			this.lineCache = void 0;
			this.textDocumentCache = /* @__PURE__ */ new WeakMap();
		}
		let { options, forceHighlight } = this.getRenderOptions(file);
		if (this.renderCache?.isDirty === true && !areFileRenderOptionsEqual(options, this.renderCache.options)) this.clearRenderCache();
		const cache = this.getMatchingWorkerResultCache(file, options);
		if (cache != null && !this.hasHighlightedRenderCache(file, options)) {
			this.renderCache = {
				file,
				highlighted: true,
				renderRange: void 0,
				...cache
			};
			forceHighlight = false;
		}
		this.renderCache ??= {
			file,
			highlighted: false,
			options,
			result: void 0,
			renderRange: void 0
		};
		const lines = this.getOrCreateLineCache(file);
		const hasContent = file.contents.length > 0;
		const forcePlainText = !hasContent || isFilePlainText(file) || isFileMassive(lines.length, this.getTokenizeMaxLength());
		const newContent = !areFilesEqual(file, this.renderCache.file);
		const newRenderRange = !areRenderRangesEqual(this.renderCache.renderRange, renderRange);
		if (!this.editSessionActive && this.workerManager?.isWorkingPool() === true) {
			if (forcePlainText || this.renderCache.result == null || !this.renderCache.highlighted && (newContent || newRenderRange)) {
				this.renderCache.file = file;
				this.renderCache.options = options;
				this.renderCache.highlighted = false;
				if (this.renderCache.result == null || newContent || newRenderRange || forceHighlight) this.renderCache.result = this.workerManager.getPlainFileAST(file, renderRange.startingLine, renderRange.totalLines, lines);
				this.renderCache.renderRange = renderRange;
			}
			if (!forcePlainText && hasContent && (!this.renderCache.highlighted || forceHighlight)) this.workerManager.highlightFileAST(this, file);
		} else {
			this.computedLang = file.lang ?? getFiletypeFromFileName(file.name);
			const hasThemes = this.highlighter != null && areThemesAttached(options.theme);
			const hasLangs = this.highlighter != null && areLanguagesAttached(this.computedLang);
			const canHighlight = !forcePlainText && hasLangs;
			if (this.highlighter != null && hasThemes && (forceHighlight || forcePlainText || !this.renderCache.highlighted && canHighlight || this.renderCache.result == null)) {
				const { result, options } = this.renderFileWithHighlighter(file, this.highlighter, forcePlainText || !hasLangs);
				this.renderCache = {
					file,
					options,
					highlighted: canHighlight,
					result,
					renderRange: void 0
				};
			}
			if (!hasThemes || !forcePlainText && !hasLangs) this.asyncHighlight(file).then(({ result, options }) => {
				if (this.renderCache != null) this.renderCache.highlighted = false;
				this.applyHighlightResult(file, result, options, !forcePlainText);
			});
		}
		return this.renderCache.result != null ? this.processFileResult(this.renderCache.file, renderRange, this.renderCache.result) : void 0;
	}
	async asyncRender(file, renderRange = DEFAULT_RENDER_RANGE) {
		const { result } = await this.asyncHighlight(file);
		return this.processFileResult(file, renderRange, result);
	}
	async asyncHighlight(file) {
		const forcePlainText = isFileMassive(this.getOrCreateLineCache(file).length, this.getTokenizeMaxLength());
		this.computedLang = forcePlainText ? "text" : file.lang ?? getFiletypeFromFileName(file.name);
		const hasThemes = this.highlighter != null && hasResolvedThemes(getThemes(this.getLocalHighlightTheme()));
		const hasLangs = forcePlainText || this.highlighter != null && areLanguagesAttached(this.computedLang);
		if (this.highlighter == null || !hasThemes || !hasLangs) this.highlighter = await this.initializeHighlighter();
		return this.renderFileWithHighlighter(file, this.highlighter, forcePlainText);
	}
	renderFileWithHighlighter(file, highlighter, forcePlainText = false) {
		const { options } = this.getRenderOptions(file);
		return {
			result: renderFileWithHighlighter(file, highlighter, options, { forcePlainText }),
			options
		};
	}
	processFileResult(file, renderRange, { code, themeStyles, baseThemeType }) {
		const totalLines = this.getLineCount(file);
		const { disableFileHeader = false } = this.options;
		const contentArray = [];
		const gutter = createGutterWrapper();
		const endLine = Math.min(renderRange.startingLine + renderRange.totalLines, totalLines);
		let rowCount = 0;
		const fileLevelAnnotations = shouldRenderFileAnnotations(renderRange) ? getFileAnnotations(this.lineAnnotations) : void 0;
		if (fileLevelAnnotations != null) {
			gutter.children.push(createGutterGap("context", "annotation", 1));
			contentArray.push(createAnnotationElement({
				type: "annotation",
				hunkIndex: -1,
				lineIndex: -1,
				annotations: fileLevelAnnotations.map((annotation) => getLineAnnotationName(annotation))
			}));
			rowCount++;
		}
		for (let lineIndex = renderRange.startingLine; lineIndex < endLine; lineIndex++) {
			const lineNumber = lineIndex + 1;
			const line = code[lineIndex];
			if (line == null) {
				const message = "FileRenderer.processFileResult: Line doesnt exist";
				console.error(message, {
					name: file.name,
					lineIndex,
					lineNumber
				});
				throw new Error(message);
			}
			gutter.children.push(createGutterItem("context", lineNumber, `${lineIndex}`));
			contentArray.push(line);
			rowCount++;
			const annotations = this.lineAnnotations[lineNumber];
			if (annotations != null) {
				gutter.children.push(createGutterGap("context", "annotation", 1));
				contentArray.push(createAnnotationElement({
					type: "annotation",
					hunkIndex: 0,
					lineIndex: lineNumber,
					annotations: annotations.map((annotation) => getLineAnnotationName(annotation))
				}));
				rowCount++;
			}
		}
		gutter.properties.style = `grid-row: span ${rowCount}`;
		return {
			gutterAST: gutter.children ?? [],
			contentAST: contentArray,
			preAST: this.createPreElement(totalLines),
			headerAST: !disableFileHeader ? this.renderHeader(file) : void 0,
			totalLines,
			rowCount,
			themeStyles,
			baseThemeType,
			bufferBefore: renderRange.bufferBefore,
			bufferAfter: renderRange.bufferAfter,
			css: ""
		};
	}
	renderHeader(file) {
		const { headerRenderMode = "default", stickyHeader = false } = this.options;
		return createFileHeaderElement({
			fileOrDiff: file,
			mode: headerRenderMode,
			stickyHeader
		});
	}
	renderFullHTML(result) {
		return toHtml(this.renderFullAST(result));
	}
	renderFullAST(result, children = []) {
		children.push(createHastElement({
			tagName: "code",
			children: this.renderCodeAST(result),
			properties: { "data-code": "" }
		}));
		return {
			...result.preAST,
			children
		};
	}
	renderCodeAST(result) {
		const gutter = createGutterWrapper();
		gutter.children = result.gutterAST;
		gutter.properties.style = `grid-row: span ${result.rowCount}`;
		return [gutter, createContentColumn(result.contentAST, result.rowCount)];
	}
	renderPartialHTML(children, includeCodeNode = false) {
		if (!includeCodeNode) return toHtml(children);
		return toHtml(createHastElement({
			tagName: "code",
			children,
			properties: { "data-code": "" }
		}));
	}
	async initializeHighlighter() {
		this.highlighter = await getSharedHighlighter(getHighlighterOptions(this.computedLang, {
			theme: this.getLocalHighlightTheme(),
			preferredHighlighter: this.workerManager?.getPreferredHighlighter() ?? this.options.preferredHighlighter
		}));
		return this.highlighter;
	}
	onHighlightSuccess(file, result, options, highlighted = true) {
		if (this.editSessionActive) return;
		this.applyHighlightResult(file, result, options, highlighted);
	}
	applyHighlightResult(file, result, options, highlighted = true) {
		if (this.renderCache == null) return;
		const triggerRenderUpdate = !areFilesEqual(file, this.renderCache.file) || !this.renderCache.highlighted || !areFileRenderOptionsEqual(options, this.renderCache.options);
		this.renderCache = {
			file,
			options,
			highlighted,
			result,
			renderRange: void 0
		};
		if (triggerRenderUpdate) this.onRenderUpdate?.();
	}
	getMatchingWorkerResultCache(file, options) {
		if (this.editSessionActive) return;
		const cache = this.workerManager?.getFileResultCache(file);
		if (cache == null || !areFileRenderOptionsEqual(options, cache.options)) return;
		return cache;
	}
	hasHighlightedRenderCache(file, options) {
		const { renderCache } = this;
		return renderCache?.result != null && renderCache.highlighted && areFilesEqual(file, renderCache.file) && areFileRenderOptionsEqual(options, renderCache.options);
	}
	onHighlightError(error) {
		console.error(error);
	}
	getTokenizeMaxLength() {
		return this.options.tokenizeMaxLength ?? 1e5;
	}
	createPreElement(totalLines) {
		const { disableLineNumbers = false, overflow = "scroll" } = this.options;
		return createPreElement({
			type: "file",
			diffIndicators: "none",
			disableBackground: true,
			disableLineNumbers,
			overflow,
			split: false,
			totalLines
		});
	}
};
function isFileMassive(lineCount, tokenizeMaxLength) {
	return lineCount > tokenizeMaxLength;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/sprite.js
var SVGSpriteSheet = `<svg data-icon-sprite aria-hidden="true" width="0" height="0">
  <symbol id="diffs-icon-arrow-right-short" viewBox="0 0 16 16">
    <path d="M8.47 4.22a.75.75 0 0 0 0 1.06l1.97 1.97H3.75a.75.75 0 0 0 0 1.5h6.69l-1.97 1.97a.75.75 0 1 0 1.06 1.06l3.25-3.25a.75.75 0 0 0 0-1.06L9.53 4.22a.75.75 0 0 0-1.06 0"/>
  </symbol>
  <symbol id="diffs-icon-brand-github" viewBox="0 0 16 16">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.01 8.01 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27s-1.36.09-2 .27c-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8"/>
  </symbol>
  <symbol id="diffs-icon-chevron" viewBox="0 0 16 16">
    <path d="M1.47 4.47a.75.75 0 0 1 1.06 0L8 9.94l5.47-5.47a.75.75 0 1 1 1.06 1.06l-6 6a.75.75 0 0 1-1.06 0l-6-6a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-chevrons-narrow" viewBox="0 0 10 16">
    <path d="M4.47 2.22a.75.75 0 0 1 1.06 0l3.25 3.25a.75.75 0 0 1-1.06 1.06L5 3.81 2.28 6.53a.75.75 0 0 1-1.06-1.06zM1.22 9.47a.75.75 0 0 1 1.06 0L5 12.19l2.72-2.72a.75.75 0 0 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0l-3.25-3.25a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-diff-split" viewBox="0 0 16 16">
    <path d="M14 0H8.5v16H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2m-1.5 6.5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0"/><path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5.5V0zm.5 7.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1 0-1" opacity=".3"/>
  </symbol>
  <symbol id="diffs-icon-diff-unified" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8.5h16zm-8-4a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 0 0 1 0v-1h1a.5.5 0 0 0 0-1h-1v-1A.5.5 0 0 0 8 10" clip-rule="evenodd"/><path fill-rule="evenodd" d="M14 0a2 2 0 0 1 2 2v5.5H0V2a2 2 0 0 1 2-2zM6.5 3.5a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z" clip-rule="evenodd" opacity=".4"/>
  </symbol>
  <symbol id="diffs-icon-expand" viewBox="0 0 16 16">
    <path d="M3.47 5.47a.75.75 0 0 1 1.06 0L8 8.94l3.47-3.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-expand-all" viewBox="0 0 16 16">
    <path d="M11.47 9.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 1 1 1.06-1.06L8 12.94zM7.526 1.418a.75.75 0 0 1 1.004.052l4 4a.75.75 0 1 1-1.06 1.06L8 3.06 4.53 6.53a.75.75 0 1 1-1.06-1.06l4-4z"/>
  </symbol>
  <symbol id="diffs-icon-file-code" viewBox="0 0 16 16">
    <path d="M10.75 0c.199 0 .39.08.53.22l3.5 3.5c.14.14.22.331.22.53v9A2.75 2.75 0 0 1 12.25 16h-8.5A2.75 2.75 0 0 1 1 13.25V2.75A2.75 2.75 0 0 1 3.75 0zm-7 1.5c-.69 0-1.25.56-1.25 1.25v10.5c0 .69.56 1.25 1.25 1.25h8.5c.69 0 1.25-.56 1.25-1.25V5h-1.25A2.25 2.25 0 0 1 10 2.75V1.5z"/><path d="M7.248 6.19a.75.75 0 0 1 .063 1.058L5.753 9l1.558 1.752a.75.75 0 0 1-1.122.996l-2-2.25a.75.75 0 0 1 0-.996l2-2.25a.75.75 0 0 1 1.06-.063M8.69 7.248a.75.75 0 1 1 1.12-.996l2 2.25a.75.75 0 0 1 0 .996l-2 2.25a.75.75 0 1 1-1.12-.996L10.245 9z"/>
  </symbol>
  <symbol id="diffs-icon-plus" viewBox="0 0 16 16">
    <path d="M8 3a.75.75 0 0 1 .75.75v3.5h3.5a.75.75 0 0 1 0 1.5h-3.5v3.5a.75.75 0 0 1-1.5 0v-3.5h-3.5a.75.75 0 0 1 0-1.5h3.5v-3.5A.75.75 0 0 1 8 3"/>
  </symbol>
  <symbol id="diffs-icon-symbol-added" viewBox="0 0 16 16">
    <path d="M8 4a.75.75 0 0 1 .75.75v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5A.75.75 0 0 1 8 4"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-deleted" viewBox="0 0 16 16">
    <path d="M4 8a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5A.75.75 0 0 1 4 8"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-diffstat" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.75 4.296a.75.75 0 0 0-1.5 0V6.25h-2a.75.75 0 0 0 0 1.5h2v1.5h1.5v-1.5h2a.75.75 0 0 0 0-1.5h-2zM5.25 10a.75.75 0 0 0 0 1.5h5.5a.75.75 0 0 0 0-1.5z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ignored" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m11.53-2.47a.75.75 0 0 0-1.06-1.06l-6 6a.75.75 0 1 0 1.06 1.06z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-modified" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m8 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
  </symbol>
  <symbol id="diffs-icon-symbol-moved" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.495 4.695a.75.75 0 0 0-.05 1.06L10.486 8l-2.041 2.246a.75.75 0 0 0 1.11 1.008l2.5-2.75a.75.75 0 0 0 0-1.008l-2.5-2.75a.75.75 0 0 0-1.06-.051m-4 0a.75.75 0 0 0-.05 1.06l2.044 2.248-1.796 1.995a.75.75 0 0 0 1.114 1.004l2.25-2.5a.75.75 0 0 0-.002-1.007l-2.5-2.75a.75.75 0 0 0-1.06-.05"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ref" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706.286.286.71.54 1.41.73V1.86c-.7.19-1.124.444-1.41.73-.324.325-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8m4 6.397c.697.07 1.522.103 2.5.103 1.613 0 2.806-.088 3.704-.288.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5c-.978 0-1.803.033-2.5.103zM0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m7-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1z"/>
  </symbol>
</svg>`;
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areLineAnnotationsEqual.js
function areLineAnnotationsEqual(annotationA, annotationB) {
	return annotationA.lineNumber === annotationB.lineNumber && annotationA.metadata === annotationB.metadata;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/arePrePropertiesEqual.js
function arePrePropertiesEqual(propsA, propsB) {
	if (propsA == null || propsB == null) return propsA === propsB;
	return areCustomPropertiesEqual(propsA.customProperties, propsB.customProperties) && propsA.type === propsB.type && propsA.diffIndicators === propsB.diffIndicators && propsA.disableBackground === propsB.disableBackground && propsA.disableLineNumbers === propsB.disableLineNumbers && propsA.overflow === propsB.overflow && propsA.split === propsB.split && propsA.totalLines === propsB.totalLines;
}
var EMPTY_CUSTOM_PROPERTIES = {};
function areCustomPropertiesEqual(customPropertiesA = EMPTY_CUSTOM_PROPERTIES, customPropertiesB = EMPTY_CUSTOM_PROPERTIES) {
	if (customPropertiesA === customPropertiesB) return true;
	const keysA = Object.keys(customPropertiesA);
	const keysB = Object.keys(customPropertiesB);
	if (keysA.length !== keysB.length) return false;
	for (const key of keysA) if (customPropertiesA[key] !== customPropertiesB[key]) return false;
	return true;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createAnnotationWrapperNode.js
function createAnnotationWrapperNode(slot) {
	const wrapper = document.createElement("div");
	wrapper.dataset.annotationSlot = "";
	wrapper.slot = slot;
	wrapper.style.whiteSpace = "normal";
	return wrapper;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createGutterUtilityContentNode.js
function createGutterUtilityContentNode() {
	const gutterUtilityContent = document.createElement("div");
	gutterUtilityContent.slot = "gutter-utility-slot";
	gutterUtilityContent.style.position = "absolute";
	gutterUtilityContent.style.top = "0";
	gutterUtilityContent.style.bottom = "0";
	gutterUtilityContent.style.textAlign = "center";
	gutterUtilityContent.style.whiteSpace = "normal";
	gutterUtilityContent.style.touchAction = "none";
	return gutterUtilityContent;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createUnsafeCSSStyleNode.js
function createUnsafeCSSStyleNode() {
	const node = document.createElement("style");
	node.setAttribute(UNSAFE_CSS_ATTRIBUTE, "");
	return node;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/style.js
var style_default = "@layer base {\n  :host {\n    --diffs-font-fallback: \"SF Mono\", Monaco, Consolas, \"Ubuntu Mono\", \"Liberation Mono\",\n      \"Courier New\", monospace;\n    --diffs-header-font-fallback: system-ui, -apple-system, \"Segoe UI\", Roboto, \"Helvetica Neue\",\n      \"Noto Sans\", \"Liberation Sans\", Arial, sans-serif;\n    --diffs-mixer: light-dark(#000, #fff);\n    --diffs-gap-fallback: 8px;\n    --diffs-scrollbar-gutter-fallback: 6px;\n    --diffs-scrollbar-gutter: var(--diffs-scrollbar-gutter-override, var(--diffs-scrollbar-gutter-measured, var(--diffs-scrollbar-gutter-fallback)));\n    --diffs-added-light: #0dbe4e;\n    --diffs-added-dark: #5ecc71;\n    --diffs-modified-light: #009fff;\n    --diffs-modified-dark: #69b1ff;\n    --diffs-deleted-light: #ff2e3f;\n    --diffs-deleted-dark: #ff6762;\n    --diffs-warning-light: #d5a910;\n    --diffs-warning-dark: #ffd452;\n    color-scheme: light dark;\n    font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));\n    font-size: var(--diffs-font-size, 13px);\n    line-height: var(--diffs-line-height, 20px);\n    font-feature-settings: var(--diffs-font-features);\n    --diffs-bg: light-dark(var(--diffs-light-bg, #fff), var(--diffs-dark-bg, #000));\n    --diffs-bg-buffer: var(--diffs-bg-buffer-override, light-dark(color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer))));\n    --diffs-bg-context: var(--diffs-bg-context-override, light-dark(color-mix(in lab, var(--diffs-bg) 98.5%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-bg) 92.5%, var(--diffs-mixer))));\n    --diffs-bg-context-gutter: var(--diffs-bg-context-gutter-override, light-dark(color-mix(in lab, var(--diffs-bg-context) 90%, var(--diffs-bg)), color-mix(in lab, var(--diffs-bg-context) 45%, var(--diffs-bg))));\n    --diffs-bg-separator: var(--diffs-bg-separator-override, light-dark(color-mix(in lab, var(--diffs-bg) 96%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-mixer))));\n    --diffs-fg: light-dark(var(--diffs-light, #000), var(--diffs-dark, #fff));\n    --diffs-fg-number: var(--diffs-fg-number-override, light-dark(color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg)), color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg))));\n    --diffs-fg-conflict-marker: var(--diffs-fg-conflict-marker-override, var(--diffs-fg-number));\n    --diffs-deletion-base: var(--diffs-deletion-color-override, light-dark(var(--diffs-light-deletion-color, var(--diffs-deletion-color, var(--diffs-deleted-light))), var(--diffs-dark-deletion-color, var(--diffs-deletion-color, var(--diffs-deleted-dark)))));\n    --diffs-addition-base: var(--diffs-addition-color-override, light-dark(var(--diffs-light-addition-color, var(--diffs-addition-color, var(--diffs-added-light))), var(--diffs-dark-addition-color, var(--diffs-addition-color, var(--diffs-added-dark)))));\n    --diffs-modified-base: var(--diffs-modified-color-override, light-dark(var(--diffs-light-modified-color, var(--diffs-modified-color, var(--diffs-modified-light))), var(--diffs-dark-modified-color, var(--diffs-modified-color, var(--diffs-modified-dark)))));\n    --diffs-bg-deletion: var(--diffs-bg-deletion-override, light-dark(color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-deletion-base)), color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-deletion-base))));\n    --diffs-bg-deletion-emphasis: var(--diffs-bg-deletion-emphasis-override, light-dark(rgb(from var(--diffs-deletion-base) r g b / .15), rgb(from var(--diffs-deletion-base) r g b / .2)));\n    --diffs-bg-addition: var(--diffs-bg-addition-override, light-dark(color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-addition-base)), color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-addition-base))));\n    --diffs-bg-addition-emphasis: var(--diffs-bg-addition-emphasis-override, light-dark(rgb(from var(--diffs-addition-base) r g b / .15), rgb(from var(--diffs-addition-base) r g b / .2)));\n    --diffs-selection-base: var(--diffs-modified-base);\n    --diffs-selection-number-fg: light-dark(color-mix(in lab, var(--diffs-selection-base) 65%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-selection-base) 75%, var(--diffs-mixer)));\n    background-color: var(--diffs-bg);\n    color: var(--diffs-fg);\n    display: block;\n  }\n\n  pre, code, [data-error-wrapper] {\n    isolation: isolate;\n    font-family: var(--diffs-font-family, var(--diffs-font-fallback));\n    outline: none;\n    margin: 0;\n    padding: 0;\n    display: block;\n  }\n\n  pre, code {\n    background-color: var(--diffs-bg);\n  }\n\n  code {\n    contain: content;\n  }\n\n  input, button {\n    font-family: inherit;\n    font-size: inherit;\n    line-height: inherit;\n  }\n\n  *, :before, :after {\n    box-sizing: border-box;\n  }\n\n  [data-icon-sprite] {\n    display: none;\n  }\n\n  [data-diffs-header], [data-separator] {\n    font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));\n  }\n\n  [data-diffs-header][data-sticky] {\n    z-index: 1;\n    background-color: var(--diffs-bg);\n    position: sticky;\n    top: 0;\n  }\n\n  [data-file-info] {\n    color: var(--fg);\n    background-color: color-mix(in lab, var(--bg) 98%, var(--fg));\n    border-block: 1px solid color-mix(in lab, var(--bg) 95%, var(--fg));\n    padding: 10px;\n    font-weight: 700;\n  }\n\n  [data-diff], [data-file] {\n    --diffs-grid-number-column-width: minmax(min-content, max-content);\n    --diffs-code-grid: var(--diffs-grid-number-column-width) 1fr;\n\n    &[data-dehydrated] {\n      --diffs-code-grid: var(--diffs-grid-number-column-width) minmax(0, 1fr);\n    }\n\n    &:hover [data-code]::-webkit-scrollbar-thumb {\n      background-color: var(--diffs-bg-context);\n    }\n  }\n\n  @supports (-webkit-touch-callout: none) {\n    :host {\n      --diffs-scrollbar-gutter-fallback: 0px;\n    }\n  }\n\n  [data-line] span {\n    color: light-dark(var(--diffs-token-light, var(--diffs-light)), var(--diffs-token-dark, var(--diffs-dark)));\n    background-color: light-dark(var(--diffs-token-light-bg, inherit), var(--diffs-token-dark-bg, inherit));\n    font-weight: light-dark(var(--diffs-token-light-font-weight, inherit), var(--diffs-token-dark-font-weight, inherit));\n    font-style: light-dark(var(--diffs-token-light-font-style, inherit), var(--diffs-token-dark-font-style, inherit));\n    text-decoration: light-dark(var(--diffs-token-light-text-decoration, inherit), var(--diffs-token-dark-text-decoration, inherit));\n  }\n\n  [data-line], [data-gutter-buffer], [data-column-number], [data-line-annotation], [data-no-newline], [data-merge-conflict], [data-merge-conflict-actions], [data-editor-overlay] {\n    --diffs-computed-decoration-bg: var(--diffs-bg);\n    --diffs-computed-diff-line-bg: var(--diffs-computed-decoration-bg);\n    --diffs-computed-selected-line-bg: var(--diffs-computed-diff-line-bg);\n    --diffs-computed-editor-active-line-bg: var(--diffs-computed-selected-line-bg);\n    --diffs-computed-hovered-line-bg: var(--diffs-computed-editor-active-line-bg);\n    --diffs-hover-mix-target: var(--diffs-bg-hover-override, var(--diffs-mixer));\n    --diffs-line-bg: var(--diffs-computed-hovered-line-bg);\n    color: var(--diffs-fg);\n    background-color: var(--diffs-line-bg, var(--diffs-bg));\n  }\n\n  [data-line], [data-no-newline] {\n    &[data-decoration-bg] {\n      --mix-deco-light: 92%;\n      --mix-deco-dark: 85%;\n\n      &[data-decoration-bg-depth=\"2\"] {\n        --mix-deco-light: 88%;\n        --mix-deco-dark: 80%;\n      }\n\n      &[data-decoration-bg-depth=\"3\"] {\n        --mix-deco-light: 85%;\n        --mix-deco-dark: 78%;\n      }\n\n      --diffs-hover-mix-target: var(--diffs-decoration-bg);\n      --diffs-computed-decoration-bg: light-dark(color-mix(in lab,\n          var(--diffs-bg) var(--mix-deco-light),\n          var(--diffs-decoration-bg)), color-mix(in lab,\n          var(--diffs-bg) var(--mix-deco-dark),\n          var(--diffs-decoration-bg)));\n    }\n  }\n\n  [data-line-annotation], [data-gutter-buffer=\"annotation\"] {\n    --diffs-annotation-bg: var(--diffs-bg-context);\n    --diffs-computed-decoration-bg: var(--diffs-annotation-bg);\n    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);\n  }\n\n  [data-merge-conflict-actions], [data-gutter-buffer=\"merge-conflict-action\"], [data-gutter-buffer=\"merge-conflict-marker-base\"], [data-gutter-buffer=\"merge-conflict-marker-separator\"], [data-merge-conflict=\"marker-base\"], [data-merge-conflict=\"marker-separator\"] {\n    --diffs-computed-decoration-bg: var(--diffs-bg-context);\n    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);\n  }\n\n  [data-gutter-buffer=\"merge-conflict-marker-start\"], [data-merge-conflict=\"marker-start\"] {\n    --diffs-computed-decoration-bg: light-dark(color-mix(in lab,\n        var(--diffs-bg) 78%,\n        var(--conflict-bg-current-header-override, var(--diffs-addition-base))), color-mix(in lab,\n        var(--diffs-bg) 68%,\n        var(--conflict-bg-current-header-override, var(--diffs-addition-base))));\n    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);\n  }\n\n  [data-gutter-buffer=\"merge-conflict-marker-end\"], [data-merge-conflict=\"marker-end\"] {\n    --diffs-computed-decoration-bg: light-dark(color-mix(in lab,\n        var(--diffs-bg) 78%,\n        var(--conflict-bg-incoming-header-override, var(--diffs-modified-base))), color-mix(in lab,\n        var(--diffs-bg) 68%,\n        var(--conflict-bg-incoming-header-override, var(--diffs-modified-base))));\n    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);\n  }\n\n  [data-has-merge-conflict] [data-line-annotation], [data-has-merge-conflict] [data-gutter-buffer=\"annotation\"] {\n    --diffs-computed-decoration-bg: var(--diffs-bg);\n    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);\n  }\n\n  :where([data-background]) {\n    & [data-gutter-buffer], & [data-column-number] {\n      --mix-light: 91%;\n      --mix-dark: 85%;\n    }\n\n    & [data-line], & [data-no-newline] {\n      --mix-light: 88%;\n      --mix-dark: 80%;\n    }\n\n    & [data-gutter-buffer], & [data-column-number], & [data-line], & [data-no-newline] {\n      --diffs-diff-line-mix-target: var(--diffs-bg);\n\n      &[data-line-type=\"change-deletion\"] {\n        --diffs-diff-line-mix-target: var(--diffs-bg-deletion-override, var(--diffs-deletion-base));\n        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);\n\n        &:where([data-gutter-buffer], [data-column-number]) {\n          color: var(--diffs-fg-number-deletion-override, var(--diffs-deletion-base));\n          --diffs-diff-line-mix-target: var(--diffs-bg-deletion-number-override, var(--diffs-deletion-base));\n        }\n\n        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-light),\n            var(--diffs-diff-line-mix-target)), color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-dark),\n            var(--diffs-diff-line-mix-target)));\n      }\n\n      &[data-line-type=\"change-addition\"] {\n        --diffs-diff-line-mix-target: var(--diffs-bg-addition-override, var(--diffs-addition-base));\n        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);\n\n        &:where([data-gutter-buffer], [data-column-number]) {\n          color: var(--diffs-fg-number-addition-override, var(--diffs-addition-base));\n          --diffs-diff-line-mix-target: var(--diffs-bg-addition-number-override, var(--diffs-addition-base));\n        }\n\n        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-light),\n            var(--diffs-diff-line-mix-target)), color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-dark),\n            var(--diffs-diff-line-mix-target)));\n      }\n\n      &[data-merge-conflict=\"current\"] {\n        --diffs-diff-line-mix-target: var(--conflict-bg-current-override, var(--diffs-addition-base));\n        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);\n\n        &:where([data-gutter-buffer], [data-column-number]) {\n          color: var(--diffs-fg-number-addition-override, var(--diffs-addition-base));\n          --diffs-diff-line-mix-target: var(--conflict-bg-current-number-override, var(--diffs-addition-base));\n        }\n\n        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-light),\n            var(--diffs-diff-line-mix-target)), color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-dark),\n            var(--diffs-diff-line-mix-target)));\n      }\n\n      &[data-merge-conflict=\"incoming\"] {\n        --diffs-diff-line-mix-target: var(--conflict-bg-incoming-override, var(--diffs-modified-base));\n        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);\n\n        &:where([data-gutter-buffer], [data-column-number]) {\n          color: var(--diffs-modified-base);\n          --diffs-diff-line-mix-target: var(--conflict-bg-incoming-number-override, var(--diffs-modified-base));\n        }\n\n        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-light),\n            var(--diffs-diff-line-mix-target)), color-mix(in lab,\n            var(--diffs-computed-decoration-bg) var(--mix-dark),\n            var(--diffs-diff-line-mix-target)));\n      }\n    }\n  }\n\n  [data-gutter-buffer], [data-column-number], [data-line], [data-line-annotation], [data-merge-conflict], [data-merge-conflict-actions], [data-no-newline], [data-editor-overlay] {\n    --diffs-selection-mix-target: var(--diffs-bg-selection-override, var(--diffs-selection-base));\n    --diffs-selection-emphasis-mix-target: var(--diffs-selection-mix-target);\n\n    &:where([data-editor-overlay]), &:where([data-line], [data-line-annotation], [data-merge-conflict], [data-merge-conflict-actions], [data-no-newline])[data-selected-line] {\n      --mix-selection-light: 82%;\n      --mix-selection-dark: 75%;\n      --diffs-hover-mix-target: var(--diffs-selection-mix-target);\n    }\n\n    &:where([data-gutter-buffer][data-selected-line], [data-column-number]:is([data-selected-line], [data-editor-active-line])) {\n      --mix-selection-light: 75%;\n      --mix-selection-dark: 60%;\n      --diffs-selection-mix-target: var(--diffs-bg-selection-number-override, var(--diffs-selection-base));\n      --diffs-hover-mix-target: var(--diffs-selection-mix-target);\n    }\n\n    &:where([data-line][data-selected-line]):is([data-line-type=\"change-addition\"], [data-line-type=\"change-deletion\"]) {\n      --diffs-selection-emphasis-mix-target: light-dark(color-mix(in lab,\n          var(--diffs-diff-line-mix-target, var(--diffs-selection-mix-target))\n            var(--mix-selection-light),\n          var(--diffs-selection-mix-target)), var(--diffs-selection-mix-target));\n    }\n\n    &:where([data-editor-overlay]), &[data-selected-line] {\n      --diffs-computed-selected-line-bg: light-dark(color-mix(in lab,\n          var(--diffs-computed-diff-line-bg) var(--mix-selection-light),\n          var(--diffs-selection-mix-target)), color-mix(in lab,\n          var(--diffs-computed-diff-line-bg) var(--mix-selection-dark),\n          var(--diffs-selection-mix-target)));\n    }\n  }\n\n  [data-line][data-editor-active-line], [data-column-number][data-editor-active-line] {\n    --diffs-computed-editor-active-line-bg: color-mix(in lab,\n      var(--diffs-computed-selected-line-bg)\n        var(--diffs-editor-active-line-source-mix, 100%),\n      var(--diffs-selection-emphasis-mix-target));\n  }\n\n  @media (pointer: fine) {\n    [data-line][data-hovered], [data-gutter-buffer][data-hovered], [data-column-number][data-hovered], [data-line-annotation][data-hovered], [data-no-newline][data-hovered], [data-merge-conflict][data-hovered], [data-merge-conflict-actions][data-hovered], [data-editor-overlay][data-hovered] {\n      --diffs-computed-hovered-line-bg: light-dark(color-mix(in lab,\n          var(--diffs-computed-editor-active-line-bg) 97%,\n          var(--diffs-hover-mix-target)), color-mix(in lab,\n          var(--diffs-computed-editor-active-line-bg) 91%,\n          var(--diffs-hover-mix-target)));\n    }\n  }\n\n  [data-gutter-buffer][data-selected-line], [data-column-number]:is([data-selected-line], [data-editor-active-line]) {\n    color: var(--diffs-selection-number-fg);\n  }\n\n  [data-no-newline] {\n    user-select: none;\n\n    & span {\n      opacity: .6;\n    }\n  }\n\n  [data-diff-type=\"split\"][data-overflow=\"scroll\"] {\n    grid-template-columns: 1fr 1fr;\n    display: grid;\n\n    & [data-additions] {\n      border-left: 1px solid var(--diffs-bg);\n    }\n\n    & [data-deletions] {\n      border-right: 1px solid var(--diffs-bg);\n    }\n  }\n\n  [data-code] {\n    grid-auto-flow: dense;\n    grid-template-columns: var(--diffs-code-grid);\n    overflow: var(--diffs-overflow-override, scroll) clip;\n    overscroll-behavior-x: none;\n    tab-size: var(--diffs-tab-size, 2);\n    padding-top: var(--diffs-gap-block, var(--diffs-gap-fallback));\n    padding-bottom: max(0px,\n      calc(var(--diffs-gap-block, var(--diffs-gap-fallback)) -\n          var(--diffs-scrollbar-gutter)));\n    scrollbar-gutter: stable;\n    align-self: flex-start;\n    display: grid;\n  }\n\n  [data-diffs-scrollbar-measure] {\n    opacity: 0;\n    pointer-events: none;\n    scrollbar-gutter: auto;\n    grid-template-columns: none;\n    width: 100px;\n    height: 100px;\n    padding: 0;\n    position: absolute;\n    top: -200px;\n    left: -200px;\n  }\n\n  [data-container-size] {\n    container-type: inline-size;\n  }\n\n  [data-code]::-webkit-scrollbar {\n    width: 0;\n    height: var(--diffs-scrollbar-gutter);\n  }\n\n  [data-code]::-webkit-scrollbar-track {\n    background: none;\n  }\n\n  [data-code]::-webkit-scrollbar-thumb {\n    background-color: #0000;\n    background-clip: content-box;\n    border: 1px solid #0000;\n    border-radius: 3px;\n  }\n\n  [data-code]::-webkit-scrollbar-corner {\n    background-color: #0000;\n  }\n\n  @supports ((-moz-appearance: none)) {\n    [data-code] {\n      scrollbar-width: thin;\n      scrollbar-color: var(--diffs-bg-context) transparent;\n      padding-bottom: var(--diffs-gap-block, var(--diffs-gap-fallback));\n    }\n  }\n\n  [data-diffs-header] ~ [data-diff], [data-diffs-header] ~ [data-file] {\n    & [data-code], &[data-overflow=\"wrap\"], &[data-dehydrated][data-diff-type=\"split\"][data-overflow=\"scroll\"] {\n      padding-top: 0;\n    }\n  }\n\n  [data-gutter] {\n    grid-template-rows: subgrid;\n    grid-template-columns: subgrid;\n    z-index: 3;\n    background-color: var(--diffs-bg);\n    grid-column: 1;\n    display: grid;\n    position: relative;\n\n    & [data-gutter-buffer], & [data-column-number] {\n      border-right: var(--diffs-gap-style, 2px solid var(--diffs-bg));\n    }\n  }\n\n  [data-content] {\n    grid-template-rows: subgrid;\n    grid-template-columns: subgrid;\n    background-color: var(--diffs-bg);\n    grid-column: 2;\n    min-width: 0;\n    display: grid;\n  }\n\n  [data-diff-type=\"split\"][data-overflow=\"wrap\"], [data-dehydrated][data-diff-type=\"split\"][data-overflow=\"scroll\"] {\n    grid-auto-flow: dense;\n    grid-template-columns: repeat(2, var(--diffs-code-grid));\n    padding-block: var(--diffs-gap-block, var(--diffs-gap-fallback));\n    display: grid;\n\n    & [data-code] {\n      display: contents;\n    }\n\n    & [data-deletions] {\n      & [data-gutter] {\n        grid-column: 1;\n      }\n\n      & [data-content] {\n        border-right: 1px solid var(--diffs-bg);\n        grid-column: 2;\n      }\n    }\n\n    & [data-additions] {\n      & [data-gutter] {\n        border-left: 1px solid var(--diffs-bg);\n        grid-column: 3;\n      }\n\n      & [data-content] {\n        grid-column: 4;\n      }\n    }\n  }\n\n  [data-dehydrated][data-diff-type=\"split\"][data-overflow=\"scroll\"] [data-content] {\n    overflow: clip;\n  }\n\n  [data-overflow=\"scroll\"] [data-gutter] {\n    position: sticky;\n    left: 0;\n  }\n\n  [data-interactive-lines] [data-line] {\n    cursor: pointer;\n  }\n\n  [data-interactive-line-numbers] [data-column-number] {\n    cursor: pointer;\n    touch-action: none;\n  }\n\n  [data-content-buffer], [data-gutter-buffer] {\n    user-select: none;\n    min-height: 1lh;\n    position: relative;\n  }\n\n  [data-gutter-buffer] {\n    padding-left: 2ch;\n    padding-right: 1ch;\n\n    &:before {\n      content: \"\";\n      min-width: var(--diffs-min-number-column-width, var(--diffs-min-number-column-width-default, 3ch));\n      display: block;\n    }\n  }\n\n  [data-gutter-buffer=\"annotation\"] {\n    --diffs-annotation-bg: var(--diffs-bg-context-gutter);\n    min-height: 0;\n  }\n\n  [data-gutter-buffer=\"buffer\"] {\n    --diffs-line-bg: var(--diffs-bg-context-gutter);\n  }\n\n  [data-content-buffer] {\n    background-position: 5px 0;\n    background-size: 8px 8px;\n    background-origin: border-box;\n    background-image: repeating-linear-gradient(-45deg,\n      transparent,\n      transparent calc(3px * 1.414),\n      var(--diffs-bg-buffer) calc(3px * 1.414),\n      var(--diffs-bg-buffer) calc(4px * 1.414));\n    grid-column: 1;\n  }\n\n  [data-separator] {\n    box-sizing: content-box;\n    background-color: var(--diffs-bg);\n  }\n\n  [data-separator=\"simple\"] {\n    min-height: 4px;\n  }\n\n  [data-separator=\"line-info\"], [data-separator=\"line-info-basic\"], [data-separator=\"metadata\"], [data-separator=\"simple\"] {\n    background-color: var(--diffs-bg-separator);\n  }\n\n  [data-separator=\"line-info\"], [data-separator=\"line-info-basic\"], [data-separator=\"metadata\"] {\n    height: 32px;\n    position: relative;\n  }\n\n  [data-separator-wrapper] {\n    user-select: none;\n    fill: currentColor;\n    background-color: var(--diffs-bg);\n    align-items: center;\n    height: 100%;\n    display: flex;\n    position: absolute;\n    inset-inline: 0;\n  }\n\n  [data-content] [data-separator-wrapper] {\n    display: none;\n  }\n\n  [data-separator=\"metadata\"] [data-separator-wrapper] {\n    background-color: var(--diffs-bg-separator);\n    height: 100%;\n    color: var(--diffs-fg-number);\n    white-space: nowrap;\n    text-overflow: ellipsis;\n    min-width: min-content;\n    padding-inline: 1ch;\n    inset-inline: 100% auto;\n    overflow: hidden;\n  }\n\n  [data-separator=\"line-info\"] {\n    margin-block: var(--diffs-gap-block, var(--diffs-gap-fallback));\n\n    & [data-separator-wrapper] {\n      min-width: 16px;\n    }\n  }\n\n  [data-separator=\"line-info-basic\"], [data-separator=\"metadata\"] {\n    margin-block: 0;\n  }\n\n  [data-separator=\"line-info\"][data-separator-first] {\n    margin-top: 0;\n  }\n\n  [data-separator=\"line-info\"][data-separator-last] {\n    margin-bottom: 0;\n  }\n\n  [data-expand-index] [data-separator-wrapper] {\n    grid-template-columns: 32px auto;\n    display: grid;\n  }\n\n  [data-expand-index] [data-separator-wrapper][data-separator-multi-button] {\n    grid-template-columns: 32px 32px auto;\n  }\n\n  [data-expand-button], [data-separator-content] {\n    background-color: var(--diffs-bg-separator);\n    flex: none;\n    align-items: center;\n    display: flex;\n  }\n\n  [data-expand-index] [data-separator-content]:hover {\n    cursor: pointer;\n    text-decoration: underline;\n  }\n\n  [data-expand-button] {\n    cursor: pointer;\n    min-width: 32px;\n    color: var(--diffs-fg-number);\n    border-right: 2px solid var(--diffs-bg);\n    flex-shrink: 0;\n    justify-content: center;\n    align-self: stretch;\n\n    &:hover {\n      color: var(--diffs-fg);\n    }\n\n    &[data-expand-all-button] {\n      display: none;\n    }\n  }\n\n  [data-expand-down] [data-icon] {\n    transform: scaleY(-1);\n  }\n\n  [data-separator-content] {\n    height: 100%;\n    color: var(--diffs-fg-number);\n    flex: auto;\n    justify-content: flex-start;\n    padding: 0 1ch;\n    overflow: hidden;\n  }\n\n  [data-separator=\"line-info\"], [data-separator=\"line-info-basic\"] {\n    & [data-separator-content] {\n      user-select: none;\n      height: 100%;\n      overflow: clip;\n    }\n  }\n\n  [data-unmodified-lines] {\n    text-overflow: ellipsis;\n    white-space: nowrap;\n    flex: 0 auto;\n    min-width: 0;\n    display: block;\n    overflow: hidden;\n  }\n\n  @supports (width: 1cqi) {\n    [data-unified] {\n      & [data-separator=\"line-info\"] [data-separator-wrapper] {\n        padding-inline: var(--diffs-gap-inline, var(--diffs-gap-fallback));\n        width: 100cqi;\n\n        & [data-separator-content] {\n          border-radius: 6px;\n        }\n      }\n\n      & [data-separator=\"line-info\"][data-expand-index] [data-separator-wrapper] [data-separator-content] {\n        border-top-left-radius: unset;\n        border-bottom-left-radius: unset;\n      }\n    }\n\n    [data-gutter] {\n      & [data-separator=\"line-info\"] [data-separator-wrapper] {\n        padding-left: var(--diffs-gap-inline, var(--diffs-gap-fallback));\n      }\n\n      & [data-separator=\"line-info\"] [data-separator-content] {\n        border-top-left-radius: 6px;\n        border-bottom-left-radius: 6px;\n      }\n\n      & [data-separator=\"line-info\"][data-expand-index] [data-separator-content] {\n        border-top-left-radius: unset;\n        border-bottom-left-radius: unset;\n      }\n    }\n\n    [data-additions] {\n      & [data-content] [data-separator=\"line-info\"] {\n        background-color: var(--diffs-bg);\n\n        & [data-separator-wrapper] {\n          display: none;\n        }\n      }\n\n      & [data-gutter] [data-separator=\"line-info\"] [data-separator-wrapper] {\n        background-color: var(--diffs-bg-separator);\n        border-top-right-radius: 6px;\n        border-bottom-right-radius: 6px;\n        height: 100%;\n        display: block;\n\n        & [data-separator-content], & [data-expand-button] {\n          display: none;\n        }\n      }\n    }\n\n    [data-overflow=\"scroll\"] [data-additions] [data-gutter] [data-separator=\"line-info\"] [data-separator-wrapper] {\n      width: calc(100cqi - var(--diffs-gap-inline, var(--diffs-gap-fallback)));\n    }\n\n    [data-overflow=\"wrap\"] [data-additions] [data-content] [data-separator=\"line-info\"] [data-separator-wrapper] {\n      background-color: var(--diffs-bg-separator);\n      height: 100%;\n      margin-right: var(--diffs-gap-inline, var(--diffs-gap-fallback));\n      border-top-right-radius: 6px;\n      border-bottom-right-radius: 6px;\n      display: block;\n\n      & [data-separator-content], & [data-expand-button] {\n        display: none;\n      }\n    }\n\n    [data-separator=\"line-info\"] [data-separator-wrapper] {\n      & [data-expand-both], & [data-expand-down], & [data-expand-up] {\n        border-top-left-radius: 6px;\n        border-bottom-left-radius: 6px;\n      }\n    }\n\n    @media (pointer: fine) {\n      [data-separator=\"line-info\"] [data-separator-wrapper] {\n        &[data-separator-multi-button] {\n          & [data-expand-up] {\n            border-top-left-radius: 6px;\n            border-bottom-left-radius: unset;\n          }\n\n          & [data-expand-down] {\n            border-bottom-left-radius: 6px;\n            border-top-left-radius: unset;\n          }\n        }\n      }\n    }\n  }\n\n  @media (pointer: coarse) {\n    [data-separator=\"line-info-basic\"] [data-separator-wrapper][data-separator-multi-button] {\n      grid-template-columns: 34px 34px auto;\n\n      & [data-separator-content] {\n        grid-column: unset;\n        grid-row: unset;\n      }\n    }\n\n    @supports (width: 1cqi) {\n      [data-separator=\"line-info\"] [data-separator-wrapper] {\n        & [data-expand-both], & [data-expand-down], & [data-expand-up] {\n          border-top-left-radius: 6px;\n          border-bottom-left-radius: 6px;\n        }\n\n        &[data-separator-multi-button] {\n          & [data-expand-up] {\n            border-top-left-radius: 6px;\n            border-bottom-left-radius: 6px;\n          }\n\n          & [data-expand-down] {\n            border-bottom-left-radius: unset;\n            border-top-left-radius: unset;\n          }\n        }\n      }\n    }\n  }\n\n  @media (pointer: fine) {\n    [data-separator-wrapper][data-separator-multi-button] {\n      grid-template-rows: 50% 50%;\n      display: grid;\n\n      & [data-separator-content] {\n        grid-area: 1 / 2 / -1;\n        min-width: min-content;\n      }\n\n      & [data-expand-button] {\n        grid-column: 1;\n      }\n    }\n\n    [data-separator=\"line-info\"] [data-separator-wrapper], [data-separator=\"line-info\"] [data-separator-wrapper][data-separator-multi-button] {\n      grid-template-columns: 34px auto;\n    }\n\n    [data-separator=\"line-info-basic\"][data-expand-index] [data-separator-wrapper] {\n      grid-template-columns: 100% auto;\n    }\n\n    [data-separator=\"line-info\"], [data-separator=\"line-info-basic\"] {\n      & [data-separator-multi-button] {\n        & [data-expand-up] {\n          border-bottom: 1px solid var(--diffs-bg);\n          border-right: 2px solid var(--diffs-bg);\n        }\n\n        & [data-expand-down] {\n          border-top: 1px solid var(--diffs-bg);\n          border-right: 2px solid var(--diffs-bg);\n        }\n      }\n    }\n  }\n\n  [data-additions] [data-gutter] [data-separator-wrapper], [data-additions] [data-separator=\"line-info-basic\"] [data-separator-wrapper], [data-content] [data-separator-wrapper] {\n    display: none;\n  }\n\n  [data-line-annotation] {\n    min-height: var(--diffs-annotation-min-height, 0);\n    z-index: 2;\n  }\n\n  [data-merge-conflict-actions] {\n    z-index: 2;\n  }\n\n  [data-separator=\"custom\"] {\n    grid-template-columns: subgrid;\n    display: grid;\n  }\n\n  [data-line], [data-column-number], [data-no-newline] {\n    padding-inline: 1ch;\n    position: relative;\n  }\n\n  [data-indicators=\"classic\"] [data-line] {\n    padding-inline-start: 2ch;\n  }\n\n  [data-indicators=\"classic\"] {\n    & [data-line-type=\"change-addition\"], & [data-line-type=\"change-deletion\"] {\n      &[data-no-newline], &[data-line] {\n        &:before {\n          user-select: none;\n          width: 1ch;\n          height: 1lh;\n          display: inline-block;\n          position: absolute;\n          top: 0;\n          left: 0;\n        }\n      }\n    }\n\n    & [data-line-type=\"change-addition\"] {\n      &[data-line], &[data-no-newline] {\n        &:before {\n          content: \"+\";\n          color: var(--diffs-addition-base);\n        }\n      }\n    }\n\n    & [data-line-type=\"change-deletion\"] {\n      &[data-line], &[data-no-newline] {\n        &:before {\n          content: \"-\";\n          color: var(--diffs-deletion-base);\n        }\n      }\n    }\n  }\n\n  [data-indicators=\"bars\"] {\n    & [data-line-type=\"change-deletion\"], & [data-line-type=\"change-addition\"] {\n      &[data-column-number] {\n        &:before {\n          content: \"\";\n          user-select: none;\n          contain: strict;\n          width: 4px;\n          height: 100%;\n          display: block;\n          position: absolute;\n          top: 0;\n          left: 0;\n        }\n      }\n    }\n\n    & [data-line-type=\"change-deletion\"] {\n      &[data-column-number] {\n        &:before {\n          background-image: linear-gradient(0deg,\n            var(--diffs-bg-deletion) 50%,\n            var(--diffs-deletion-base) 50%);\n          background-repeat: repeat;\n          background-size: 2px 2px;\n          background-size: calc(1lh / round(1lh / 2px))\n            calc(1lh / round(1lh / 2px));\n        }\n      }\n    }\n\n    & [data-line-type=\"change-addition\"] {\n      &[data-column-number] {\n        &:before {\n          background-color: var(--diffs-addition-base);\n        }\n      }\n    }\n  }\n\n  [data-overflow=\"wrap\"] {\n    & [data-line] {\n      white-space: pre-wrap;\n      word-break: break-word;\n    }\n\n    & [data-annotation-content] {\n      word-break: break-word;\n    }\n  }\n\n  [data-overflow=\"scroll\"] [data-line] {\n    white-space: pre;\n    min-height: 1lh;\n  }\n\n  [data-column-number] {\n    box-sizing: content-box;\n    text-align: right;\n    user-select: none;\n    color: var(--diffs-fg-number);\n    padding-left: 2ch;\n  }\n\n  [data-line-number-content] {\n    min-width: var(--diffs-min-number-column-width, var(--diffs-min-number-column-width-default, 3ch));\n    z-index: 1;\n    display: inline-block;\n    position: relative;\n  }\n\n  [data-disable-line-numbers] {\n    & [data-gutter-buffer], & [data-column-number] {\n      min-width: 4px;\n      padding: 0;\n\n      &:before {\n        min-width: 0;\n      }\n    }\n\n    & [data-line-number-content] {\n      display: none;\n    }\n\n    & [data-gutter-utility-slot] {\n      right: unset;\n      justify-content: flex-start;\n      left: 0;\n    }\n\n    &[data-indicators=\"bars\"] [data-gutter-utility-slot] {\n      left: 6px;\n    }\n  }\n\n  [data-file][data-disable-line-numbers] {\n    & [data-gutter-buffer], & [data-column-number] {\n      border-right: 0;\n      min-width: 0;\n    }\n  }\n\n  [data-diff-span] {\n    box-decoration-break: clone;\n    border-radius: 3px;\n  }\n\n  [data-line-type=\"change-addition\"] [data-diff-span] {\n    background-color: var(--diffs-bg-addition-emphasis);\n  }\n\n  [data-line-type=\"change-deletion\"] [data-diff-span] {\n    background-color: var(--diffs-bg-deletion-emphasis);\n  }\n\n  [data-merge-conflict=\"marker-start\"], [data-merge-conflict=\"marker-base\"], [data-merge-conflict=\"marker-separator\"], [data-merge-conflict=\"marker-end\"] {\n    color: var(--diffs-fg);\n    padding-left: 1ch;\n  }\n\n  [data-merge-conflict=\"marker-start\"], [data-merge-conflict=\"marker-end\"] {\n    align-items: center;\n    display: flex;\n\n    &:after {\n      color: var(--diffs-fg-conflict-marker);\n      font-size: .75rem;\n      font-style: normal;\n      line-height: 1.25rem;\n      font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));\n      padding-left: 1ch;\n    }\n  }\n\n  [data-merge-conflict=\"marker-start\"]:after {\n    content: \"(Current Change)\";\n  }\n\n  [data-merge-conflict=\"marker-end\"]:after {\n    content: \"(Incoming Change)\";\n  }\n\n  [data-merge-conflict-actions-content] {\n    min-height: 1.75rem;\n    font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));\n    color: var(--diffs-fg);\n    align-items: center;\n    gap: .25rem;\n    padding-inline: .5rem;\n    font-size: .75rem;\n    line-height: 1.2;\n    display: flex;\n  }\n\n  [data-merge-conflict-action] {\n    appearance: none;\n    color: var(--diffs-fg-number);\n    font: inherit;\n    cursor: pointer;\n    background: none;\n    border: 0;\n    padding: 0;\n    font-style: normal;\n  }\n\n  [data-merge-conflict-action]:hover {\n    color: var(--diffs-fg);\n  }\n\n  [data-merge-conflict-action=\"current\"]:hover {\n    color: var(--diffs-addition-base);\n  }\n\n  [data-merge-conflict-action=\"incoming\"]:hover {\n    color: var(--diffs-modified-base);\n  }\n\n  [data-merge-conflict-action-separator] {\n    color: var(--diffs-fg-number);\n    opacity: .6;\n    user-select: none;\n  }\n\n  [data-diffs-header=\"default\"] {\n    background-color: var(--diffs-bg);\n    justify-content: space-between;\n    align-items: center;\n    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));\n    min-height: calc(1lh + (var(--diffs-gap-block, var(--diffs-gap-fallback)) * 3));\n    z-index: 2;\n    flex-direction: row;\n    padding-inline: 16px;\n    display: flex;\n    position: relative;\n    top: 0;\n  }\n\n  [data-header-content] {\n    align-items: center;\n    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));\n    white-space: nowrap;\n    flex-direction: row;\n    min-width: 0;\n    display: flex;\n  }\n\n  [data-header-content] [data-prev-name], [data-header-content] [data-title] {\n    text-overflow: ellipsis;\n    white-space: nowrap;\n    direction: rtl;\n    min-width: 0;\n    overflow: hidden;\n  }\n\n  [data-prev-name] {\n    opacity: .7;\n  }\n\n  [data-rename-icon] {\n    fill: currentColor;\n    flex-grow: 0;\n    flex-shrink: 0;\n  }\n\n  [data-diffs-header=\"default\"] [data-metadata] {\n    white-space: nowrap;\n    align-items: center;\n    gap: 1ch;\n    display: flex;\n  }\n\n  [data-diffs-header=\"default\"] [data-additions-count] {\n    font-family: var(--diffs-font-family, var(--diffs-font-fallback));\n    color: var(--diffs-addition-base);\n  }\n\n  [data-diffs-header=\"default\"] [data-deletions-count] {\n    font-family: var(--diffs-font-family, var(--diffs-font-fallback));\n    color: var(--diffs-deletion-base);\n  }\n\n  [data-change-icon] {\n    fill: currentColor;\n    flex-shrink: 0;\n  }\n\n  [data-change-icon=\"change\"], [data-change-icon=\"rename-pure\"], [data-change-icon=\"rename-changed\"] {\n    color: var(--diffs-modified-base);\n  }\n\n  [data-change-icon=\"new\"] {\n    color: var(--diffs-addition-base);\n  }\n\n  [data-change-icon=\"deleted\"] {\n    color: var(--diffs-deletion-base);\n  }\n\n  [data-change-icon=\"file\"] {\n    opacity: .6;\n  }\n\n  [data-annotation-content] {\n    z-index: 2;\n    isolation: isolate;\n    white-space: normal;\n    align-self: flex-start;\n    min-width: 0;\n    display: flow-root;\n    position: relative;\n  }\n\n  [data-overflow=\"scroll\"] [data-annotation-content], [data-overflow=\"scroll\"] [data-merge-conflict-actions-content] {\n    width: var(--diffs-column-content-width, auto);\n    left: var(--diffs-column-number-width, 0);\n    position: sticky;\n  }\n\n  [data-annotation-slot] {\n    text-wrap-mode: wrap;\n    word-break: normal;\n    white-space-collapse: collapse;\n  }\n\n  [data-gutter-utility-slot] {\n    touch-action: none;\n    justify-content: flex-end;\n    display: flex;\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    right: 0;\n  }\n\n  [data-utility-button] {\n    appearance: none;\n    cursor: pointer;\n    width: 1lh;\n    height: 1lh;\n    font-size: var(--diffs-font-size, 13px);\n    line-height: var(--diffs-line-height, 20px);\n    background-color: var(--diffs-modified-base);\n    color: var(--diffs-bg);\n    fill: currentColor;\n    z-index: 4;\n    touch-action: none;\n    border: none;\n    border-radius: 4px;\n    justify-content: center;\n    align-items: center;\n    margin-right: calc(-1lh + 1ch);\n    padding: 0;\n    display: flex;\n    position: relative;\n\n    &:before {\n      content: \"\";\n      display: block;\n      position: absolute;\n      inset: 0 0 0 -4px;\n    }\n  }\n\n  [data-decoration-bar-stack] {\n    pointer-events: none;\n    isolation: isolate;\n    z-index: 1;\n    background-color: var(--diffs-decoration-bar-color, transparent);\n    box-sizing: content-box;\n    border-left: 2px solid var(--diffs-bg);\n    border-right: 2px solid var(--diffs-bg);\n    width: 6px;\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    right: -2px;\n\n    [data-decoration-bar-depth=\"1\"] & {\n      background-color: color-mix(in lab,\n        var(--diffs-bg) 20%,\n        var(--diffs-decoration-bar-color, transparent));\n    }\n\n    [data-decoration-bar-depth=\"2\"] & {\n      background-color: color-mix(in lab,\n        var(--diffs-bg) 45%,\n        var(--diffs-decoration-bar-color, transparent));\n    }\n\n    [data-decoration-bar-depth=\"3\"] & {\n      background-color: color-mix(in lab,\n        var(--diffs-bg) 65%,\n        var(--diffs-decoration-bar-color, transparent));\n    }\n\n    [data-decoration-bar-start] & {\n      border-top-left-radius: 5px;\n      border-top-right-radius: 5px;\n    }\n\n    [data-decoration-bar-end] & {\n      z-index: 3;\n      border-bottom-right-radius: 5px;\n      border-bottom-left-radius: 5px;\n    }\n  }\n\n  [data-placeholder] {\n    contain: strict;\n  }\n\n  [data-error-wrapper] {\n    padding: var(--diffs-gap-block, var(--diffs-gap-fallback))\n      var(--diffs-gap-inline, var(--diffs-gap-fallback));\n    scrollbar-width: none;\n    max-height: 400px;\n    overflow: auto;\n\n    & [data-error-message] {\n      color: var(--diffs-deletion-base);\n      font-size: 18px;\n      font-weight: bold;\n    }\n\n    & [data-error-stack] {\n      color: var(--diffs-fg-number);\n    }\n  }\n}\n\n@layer theme, rendered, unsafe;\n";
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/scrollbarGutter.js
var measuredScrollbarGutter;
function getMeasuredScrollbarGutter(shadowRoot) {
	if (measuredScrollbarGutter != null) return measuredScrollbarGutter;
	const host = shadowRoot.host;
	if (typeof HTMLElement !== "undefined" && host instanceof HTMLElement && !host.isConnected) return;
	const wrapper = document.createElement("div");
	wrapper.setAttribute("data-code", "");
	wrapper.setAttribute(DIFFS_SCROLLBAR_MEASURE_ATTRIBUTE, "true");
	const child = document.createElement("div");
	child.style.position = "relative";
	child.style.width = "200%";
	child.style.height = "200%";
	wrapper.appendChild(child);
	shadowRoot.appendChild(wrapper);
	measuredScrollbarGutter = Math.max(wrapper.offsetHeight - wrapper.clientHeight, 0);
	wrapper.remove();
	return measuredScrollbarGutter;
}
function createMeasuredScrollbarGutterDeclaration(scrollbarGutter) {
	return `${DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY}: ${scrollbarGutter == null ? "var(--diffs-scrollbar-gutter-fallback)" : `${scrollbarGutter}px`};`;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/cssWrappers.js
var LAYER_ORDER = `@layer base, theme, rendered, unsafe;`;
var SCROLLBAR_GUTTER_DECLARATION_PATTERN = new RegExp(`${escapeRegExp(DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY)}\\s*:\\s*[^;]+;`);
function wrapCoreCSS(mainCSS) {
	return `${LAYER_ORDER}
${style_default}
@layer theme {
  ${mainCSS}
}`;
}
function wrapUnsafeCSS(unsafeCSS) {
	return `${LAYER_ORDER}
@layer unsafe {
  ${unsafeCSS}
}`;
}
function wrapThemeCSS(themeCSS, themeType = "system", scrollbarGutter) {
	return `${LAYER_ORDER}
@layer rendered {
  :host {${themeType === "system" ? "" : `
  color-scheme: ${themeType};`}
  ${createMeasuredScrollbarGutterDeclaration(scrollbarGutter)}
  ${themeCSS}
  }
}`;
}
function patchScrollbarGutterSize(themeCSS, scrollbarGutter) {
	const scrollbarGutterRule = createMeasuredScrollbarGutterDeclaration(scrollbarGutter);
	return themeCSS.replace(SCROLLBAR_GUTTER_DECLARATION_PATTERN, scrollbarGutterRule);
}
function escapeRegExp(value) {
	return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getOrCreateCodeNode.js
function getOrCreateCodeNode({ code, pre, columnType, rowSpan, containerSize = false } = {}) {
	if (code == null) {
		code = document.createElement("code");
		code.setAttribute("data-code", "");
		if (columnType != null) code.setAttribute(`data-${columnType}`, "");
		pre?.appendChild(code);
	}
	if (rowSpan != null) code.style.setProperty("grid-row", `span ${rowSpan}`);
	else code.style.removeProperty("grid-row");
	if (containerSize) code.setAttribute("data-container-size", "");
	else code.removeAttribute("data-container-size");
	return code;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/prerenderHTMLIfNecessary.js
function prerenderHTMLIfNecessary(element, html) {
	if (html == null) return;
	const shadowRoot = element.shadowRoot ?? element.attachShadow({ mode: "open" });
	if (shadowRoot.innerHTML === "") shadowRoot.innerHTML = html;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/setWrapperNodeProps.js
function setPreNodeProperties(pre, { type, diffIndicators, disableBackground, disableLineNumbers, overflow, split, totalLines, customProperties }) {
	if (customProperties != null) for (const key in customProperties) {
		const value = customProperties[key];
		if (value != null) pre.setAttribute(key, `${value}`);
	}
	if (type === "diff") {
		pre.setAttribute("data-diff", "");
		pre.removeAttribute("data-file");
	} else {
		pre.setAttribute("data-file", "");
		pre.removeAttribute("data-diff");
	}
	switch (diffIndicators) {
		case "bars":
		case "classic":
			pre.setAttribute("data-indicators", diffIndicators);
			break;
		case "none":
			pre.removeAttribute("data-indicators");
			break;
	}
	if (disableLineNumbers) pre.setAttribute("data-disable-line-numbers", "");
	else pre.removeAttribute("data-disable-line-numbers");
	if (disableBackground) pre.removeAttribute("data-background");
	else pre.setAttribute("data-background", "");
	if (type === "diff") pre.setAttribute("data-diff-type", split ? "split" : "single");
	else pre.removeAttribute("data-diff-type");
	pre.setAttribute("data-overflow", overflow);
	pre.style.setProperty("--diffs-min-number-column-width-default", `${`${totalLines}`.length}ch`);
	return pre;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/isStyleNode.js
function isStyleNode(element) {
	if (typeof HTMLStyleElement !== "undefined" && element instanceof HTMLStyleElement) return true;
	const tagName = element.tagName ?? element.nodeName;
	return typeof tagName === "string" && tagName.toLowerCase() === "style";
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/shouldUseTokenTransformer.js
function shouldUseTokenTransformer(options) {
	return options?.useTokenTransformer === true || options?.onTokenClick != null || options?.onTokenEnter != null || options?.onTokenLeave != null;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getFileRendererOptions.js
function getFileRendererOptions(options) {
	return {
		theme: options?.theme,
		disableLineNumbers: options?.disableLineNumbers,
		overflow: options?.overflow,
		themeType: options?.themeType,
		collapsed: options?.collapsed,
		disableFileHeader: options?.disableFileHeader,
		disableVirtualizationBuffers: options?.disableVirtualizationBuffers,
		stickyHeader: options?.stickyHeader,
		preferredHighlighter: options?.preferredHighlighter,
		useCSSClasses: options?.useCSSClasses,
		useTokenTransformer: shouldUseTokenTransformer(options),
		tokenizeMaxLineLength: options?.tokenizeMaxLineLength,
		tokenizeMaxLength: options?.tokenizeMaxLength,
		unsafeCSS: options?.unsafeCSS,
		headerRenderMode: options?.renderCustomHeader != null ? "custom" : "default"
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/guardWebKitScrollDuringRebuild.js
/**
* Runs a wholesale code-column rebuild with the pre element's height pinned,
* working around a WebKit bug (https://bugs.webkit.org/show_bug.cgi?id=308027):
* when the subtree of a `container-type: inline-size` element is rewritten in
* bulk (column innerHTML swaps, grid-row span rewrites), WebKit resolves the
* ancestor scroller's offset against a transiently collapsed interim layout
* and clamps scrollTop to 0 — the scroller visibly jumps to the top on every
* edit. Pinning `min-height` keeps that interim layout at full height so the
* scroll offset survives; the layout read before unpinning is required, since
* it materializes the interim layout while the pin is active.
*
* Both the pin height read and the pinned-layout read force a synchronous
* layout, so callers own the gating via shouldGuardRebuildScroll: Safari-only,
* edit-mode-only, and never inside CodeView's batched read/write render pass.
*/
function guardWebKitScrollDuringRebuild(pre, rebuild) {
	const height = pre?.offsetHeight ?? 0;
	if (pre == null || height === 0) {
		rebuild();
		return;
	}
	pre.style.minHeight = `${height}px`;
	try {
		rebuild();
		pre.offsetHeight;
	} finally {
		pre.style.minHeight = "";
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/hostTheme.js
function upsertHostThemeStyle({ shadowRoot, currentNode, themeCSS }) {
	if (themeCSS.trim() === "") {
		currentNode?.remove();
		return;
	}
	currentNode ??= createHostThemeStyleNode();
	currentNode.textContent = themeCSS;
	if (currentNode.parentNode !== shadowRoot) shadowRoot.appendChild(currentNode);
	return currentNode;
}
function createHostThemeStyleNode() {
	const node = document.createElement("style");
	node.setAttribute(THEME_CSS_ATTRIBUTE, "");
	return node;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/web-components.js
if (typeof HTMLElement !== "undefined" && customElements.get("diffs-container") == null) {
	let sheet;
	class FileDiffContainer extends HTMLElement {
		constructor() {
			super();
			if (this.shadowRoot != null) return;
			const shadowRoot = this.attachShadow({ mode: "open" });
			if (sheet == null) {
				sheet = new CSSStyleSheet();
				sheet.replaceSync(style_default);
			}
			shadowRoot.adoptedStyleSheets = [sheet];
		}
		connectedCallback() {
			getMeasuredScrollbarGutter(this.shadowRoot ?? this.attachShadow({ mode: "open" }));
		}
	}
	customElements.define(DIFFS_TAG_NAME, FileDiffContainer);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/File.js
var EMPTY_STRINGS = [""];
var instanceId$5 = -1;
var File = class {
	options;
	workerManager;
	isContainerManaged;
	static LoadedCustomComponent = true;
	__id = `file:${++instanceId$5}`;
	type = "file";
	fileContainer;
	spriteSVG;
	pre;
	code;
	bufferBefore;
	bufferAfter;
	themeCSSStyle;
	appliedThemeCSS;
	hasAdoptedThemeCSS = false;
	unsafeCSSStyle;
	appliedUnsafeCSS;
	gutterUtilityContent;
	errorWrapper;
	placeHolder;
	lastRenderedHeaderHTML;
	cachedHeaderHTML;
	appliedPreAttributes;
	lastRowCount;
	mounted = false;
	headerElement;
	headerCustom;
	headerPrefix;
	headerFilenameSuffix;
	headerMetadata;
	fileRenderer;
	resizeManager;
	interactionManager;
	annotationCache = /* @__PURE__ */ new Map();
	lineAnnotations = [];
	managersDirty = false;
	file;
	renderRange;
	enabled = true;
	editor;
	constructor(options = { theme: DEFAULT_THEMES }, workerManager, isContainerManaged = false) {
		this.options = options;
		this.workerManager = workerManager;
		this.isContainerManaged = isContainerManaged;
		this.fileRenderer = new FileRenderer(options, this.handleHighlightRender, this.workerManager);
		this.resizeManager = new ResizeManager();
		this.interactionManager = new InteractionManager("file", pluckInteractionOptions(options));
		this.workerManager?.subscribeToThemeChanges(this);
	}
	handleHighlightRender = () => {
		this.rerender();
	};
	rerender() {
		if (!this.enabled || this.file == null) return;
		this.render({
			file: this.file,
			forceRender: true,
			renderRange: this.renderRange
		});
	}
	__getCurrentFile() {
		return this.file;
	}
	onThemeChange() {
		this.fileRenderer.clearRenderCache();
		this.rerender();
	}
	setOptions(options) {
		if (options == null) return;
		this.options = options;
		this.cachedHeaderHTML = void 0;
		this.syncInteractionOptions();
	}
	syncInteractionOptions() {
		this.interactionManager.setOptions(pluckInteractionOptions(this.options));
	}
	mergeOptions(options) {
		this.options = {
			...this.options,
			...options
		};
	}
	setThemeType(themeType) {
		if ((this.options.themeType ?? "system") === themeType) return;
		this.mergeOptions({ themeType });
		this.applyCachedThemeState(themeType);
	}
	applyCachedThemeState(themeType) {
		if (typeof this.options.theme === "string" || this.fileContainer == null || this.appliedThemeCSS == null) return false;
		const effectiveThemeType = this.appliedThemeCSS.baseThemeType ?? themeType;
		if (this.appliedThemeCSS.themeType === effectiveThemeType) return false;
		this.applyThemeState(this.fileContainer, this.appliedThemeCSS.themeStyles, themeType, this.appliedThemeCSS.baseThemeType);
		return true;
	}
	hasThemeChanged() {
		return this.appliedThemeCSS != null && !areThemesEqual(this.appliedThemeCSS.theme, this.options.theme ?? DEFAULT_THEMES);
	}
	getHoveredLine = () => {
		return this.interactionManager.getHoveredLine();
	};
	setLineAnnotations(lineAnnotations) {
		this.lineAnnotations = lineAnnotations;
	}
	setSelectedLines(range, options) {
		this.interactionManager.setSelection(range, options);
	}
	setEditorActiveLine(lineNumber, options) {
		this.interactionManager.setEditorActiveLine(lineNumber, {
			lineNumberOnly: options?.lineNumberOnly,
			side: options?.side ?? "additions"
		});
	}
	getCodeScrollLeft() {
		return this.code?.scrollLeft ?? 0;
	}
	setCodeScrollLeft(position) {
		if (this.code != null) this.code.scrollLeft = position;
	}
	__getEffectiveCodeOptions() {
		return {
			...this.options,
			...this.fileRenderer.getEffectiveCodeOptions()
		};
	}
	flushManagers() {
		if (!this.managersDirty || this.pre == null) {
			this.managersDirty = false;
			return;
		}
		const { overflow = "scroll" } = this.options;
		this.interactionManager.setup(this.pre);
		this.resizeManager.setup(this.pre, {
			disableAnnotations: overflow === "wrap",
			columnVariables: this.shouldApplyColumnVariables(overflow) ? "apply" : "measure"
		});
		this.managersDirty = false;
	}
	shouldApplyColumnVariables(overflow) {
		return overflow === "scroll" && this.lineAnnotations.length > 0;
	}
	cleanUp(recycle = false) {
		this.emitPostRender(true);
		this.editor?.cleanUp(recycle);
		this.editor = void 0;
		this.resizeManager.cleanUp();
		this.interactionManager.cleanUp();
		this.managersDirty = false;
		this.workerManager?.unsubscribeToThemeChanges(this);
		this.renderRange = void 0;
		if (!this.isContainerManaged) this.fileContainer?.remove();
		this.fileContainer = void 0;
		this.mounted = false;
		if (!recycle) this.lineAnnotations = [];
		this.clearAuxiliaryNodes();
		this.pre = void 0;
		this.code = void 0;
		this.bufferBefore?.remove();
		this.bufferBefore = void 0;
		this.bufferAfter?.remove();
		this.bufferAfter = void 0;
		this.appliedPreAttributes = void 0;
		this.lastRowCount = void 0;
		this.headerElement = void 0;
		this.headerPrefix = void 0;
		this.headerFilenameSuffix = void 0;
		this.headerMetadata = void 0;
		this.headerCustom = void 0;
		this.lastRenderedHeaderHTML = void 0;
		if (!recycle) this.cachedHeaderHTML = void 0;
		this.errorWrapper?.remove();
		this.errorWrapper = void 0;
		this.spriteSVG = void 0;
		this.themeCSSStyle = void 0;
		this.appliedThemeCSS = void 0;
		this.hasAdoptedThemeCSS = false;
		this.unsafeCSSStyle = void 0;
		this.appliedUnsafeCSS = void 0;
		this.placeHolder?.remove();
		this.placeHolder = void 0;
		if (recycle) this.fileRenderer.recycle();
		else {
			this.fileRenderer.cleanUp();
			this.workerManager = void 0;
			this.file = void 0;
		}
		this.enabled = false;
	}
	virtualizedSetup() {
		this.enabled = true;
		this.workerManager?.subscribeToThemeChanges(this);
	}
	hydrate(props) {
		const { fileContainer, prerenderedHTML, preventEmit = false, file, lineAnnotations } = props;
		if (!this.enabled) throw new Error("File.hydrate: attempting to call hydrate after cleaned up");
		if (this.fileContainer != null) throw new Error("File.hydrate: hydrate can only be called before the instance has rendered or hydrated");
		this.hydrateElements(fileContainer, prerenderedHTML);
		if (shouldRenderCode$2(this.pre, file, this.options.collapsed) || shouldRenderHeader$2(this.headerElement, file, this.options.disableFileHeader)) this.render({
			...props,
			preventEmit: true
		});
		else this.hydrationSetup({
			file,
			lineAnnotations
		});
		if (!preventEmit) this.emitPostRender();
	}
	hydrateElements(fileContainer, prerenderedHTML) {
		if (this.fileContainer !== fileContainer) this.emitPostRender(true);
		prerenderHTMLIfNecessary(fileContainer, prerenderedHTML);
		for (const element of Array.from(fileContainer.shadowRoot?.children ?? [])) {
			if (element instanceof SVGElement) {
				this.spriteSVG = element;
				continue;
			}
			if (!(element instanceof HTMLElement)) continue;
			if (element instanceof HTMLPreElement) {
				this.pre = element;
				this.appliedPreAttributes = void 0;
				continue;
			}
			if (element instanceof HTMLStyleElement && element.hasAttribute("data-theme-css")) {
				this.themeCSSStyle = element;
				continue;
			}
			if (element instanceof HTMLStyleElement && element.hasAttribute("data-unsafe-css")) {
				this.unsafeCSSStyle = element;
				this.appliedUnsafeCSS = element.textContent;
				continue;
			}
			if ("diffsHeader" in element.dataset) {
				this.headerElement = element;
				this.lastRenderedHeaderHTML = void 0;
				continue;
			}
		}
		if (this.pre != null) {
			this.syncCodeNodeFromPre(this.pre);
			this.pre.removeAttribute("data-dehydrated");
		}
		this.fileContainer = fileContainer;
		this.hydrateMeasuredScrollbar();
	}
	hydrationSetup({ file, lineAnnotations }) {
		this.lineAnnotations = lineAnnotations ?? this.lineAnnotations;
		this.file = file;
		this.fileRenderer.setOptions(getFileRendererOptions(this.options));
		this.syncInteractionOptions();
		if (this.pre == null) return;
		this.fileRenderer.hydrate(file);
		this.renderAnnotations();
		this.renderGutterUtility();
		this.injectUnsafeCSS();
		this.managersDirty = true;
		this.flushManagers();
	}
	getOrCreateLineCache(file = this.file) {
		return file != null ? this.fileRenderer.getOrCreateLineCache(file) : EMPTY_STRINGS;
	}
	updateBuffers(renderRange) {
		if (this.pre != null) this.applyBuffers(this.pre, renderRange);
	}
	syncRenderViewToEditor() {
		const editor = this.editor;
		const fileContainer = this.fileContainer;
		const file = this.file;
		const lineAnnotations = this.lineAnnotations;
		const renderRange = this.renderRange;
		if (editor != null && fileContainer != null && file != null) this.fileRenderer.initializeHighlighter().then((highlighter) => {
			if (!this.enabled || this.editor !== editor || this.fileContainer !== fileContainer || this.file !== file) return;
			editor.__syncRenderView(highlighter, fileContainer, file, lineAnnotations, renderRange);
		});
	}
	attachEditor(editor) {
		this.editor?.cleanUp();
		this.editor = editor;
		this.fileRenderer.beginEditSession();
		const preparedFile = this.file == null ? void 0 : editor.__prepareFile?.(this.file);
		if (preparedFile !== void 0 && preparedFile !== this.file) this.renderPreparedFile({
			file: preparedFile,
			forceRender: true,
			preventEmit: true,
			renderRange: this.renderRange
		});
		else if (this.fileRenderer.editorRenderReady()) this.syncRenderViewToEditor();
		else this.rerender();
		return () => {
			this.editor = void 0;
			this.fileRenderer.endEditSession();
		};
	}
	applyDocumentChange(textDocument, newLineAnnotations) {
		this.fileRenderer.applyDocumentChange(textDocument);
		if (newLineAnnotations != null && newLineAnnotations !== this.lineAnnotations && this.file != null) {
			this.setLineAnnotations(newLineAnnotations);
			this.fileRenderer.setLineAnnotations(this.lineAnnotations);
			this.renderAnnotations();
		}
		this.rerender();
		this.interactionManager.setSelectionDirty();
	}
	updateRenderCache(dirtyLines, themeType, options) {
		this.fileRenderer.updateRenderCache(dirtyLines, themeType, options?.lineCountChangeInFlight);
	}
	render(props) {
		if (!this.enabled) throw new Error("File.render: attempting to call render after cleaned up");
		const file = this.editor?.__prepareFile?.(props.file) ?? props.file;
		return this.renderPreparedFile(file === props.file ? props : {
			...props,
			file
		});
	}
	renderPreparedFile({ file, fileContainer, forceRender = false, preventEmit = false, containerWrapper, deferManagers = false, lineAnnotations, renderRange }) {
		this.editor?.__postponeBgTokenizeToNextFrame();
		const { collapsed = false, themeType = "system" } = this.options;
		const nextRenderRange = collapsed ? void 0 : renderRange;
		const previousRenderRange = this.renderRange;
		const themeChanged = this.hasThemeChanged();
		const annotationsChanged = lineAnnotations != null && (lineAnnotations.length > 0 || this.lineAnnotations.length > 0) ? lineAnnotations !== this.lineAnnotations : false;
		const didFileChange = !areFilesEqual(this.file, file) || this.fileRenderer.hasUnkeyedFileContentsChanged(file);
		if (!collapsed && !forceRender && areRenderRangesEqual(nextRenderRange, this.renderRange) && !didFileChange && !annotationsChanged && !themeChanged) return this.applyCachedThemeState(themeType);
		this.renderRange = nextRenderRange;
		if (didFileChange) this.cachedHeaderHTML = void 0;
		this.file = file;
		this.fileRenderer.setOptions(getFileRendererOptions(this.options));
		this.syncInteractionOptions();
		if (lineAnnotations != null) this.setLineAnnotations(lineAnnotations);
		this.fileRenderer.setLineAnnotations(this.lineAnnotations);
		const { disableErrorHandling = false, disableFileHeader = false } = this.options;
		if (disableFileHeader) {
			if (this.headerElement != null) {
				this.headerElement.remove();
				this.headerElement = void 0;
				this.lastRenderedHeaderHTML = void 0;
			}
			this.clearHeaderSlots();
		}
		fileContainer = this.getOrCreateFileContainerNode(fileContainer, containerWrapper);
		this.applyCachedThemeState(themeType);
		if (collapsed) {
			this.removeRenderedCode();
			this.clearAuxiliaryNodes();
			try {
				const fileResult = this.fileRenderer.renderFile(file, EMPTY_RENDER_RANGE);
				if (fileResult != null) this.applyThemeState(fileContainer, fileResult.themeStyles, themeType, fileResult.baseThemeType);
				if (fileResult?.headerAST != null) this.applyHeaderToDOM(fileResult.headerAST, fileContainer);
				this.injectUnsafeCSS();
			} catch (error) {
				if (disableErrorHandling) throw error;
				console.error(error);
				if (error instanceof Error) this.applyErrorToDOM(error, fileContainer);
			}
			if (!preventEmit) this.emitPostRender();
			return true;
		}
		try {
			const pre = this.getOrCreatePreNode(fileContainer);
			if (!this.canPartiallyRender(forceRender, annotationsChanged, didFileChange || themeChanged) || !this.applyPartialRender(previousRenderRange, nextRenderRange)) {
				const fileResult = this.fileRenderer.renderFile(file, nextRenderRange);
				if (fileResult == null) {
					if (this.workerManager?.isInitialized() === false) this.workerManager.initialize().then(() => this.rerender());
					return false;
				}
				this.applyThemeState(fileContainer, fileResult.themeStyles, themeType, fileResult.baseThemeType);
				if (fileResult.headerAST != null) this.applyHeaderToDOM(fileResult.headerAST, fileContainer);
				this.applyFullRender(fileResult, pre);
			}
			this.applyBuffers(pre, nextRenderRange);
			this.injectUnsafeCSS();
			this.renderAnnotations();
			this.renderGutterUtility();
			this.managersDirty = true;
			if (!deferManagers) this.flushManagers();
			if (this.editor != null) this.syncRenderViewToEditor();
		} catch (error) {
			if (disableErrorHandling) throw error;
			console.error(error);
			if (error instanceof Error) this.applyErrorToDOM(error, fileContainer);
		}
		if (!preventEmit) this.emitPostRender();
		return true;
	}
	emitPostRender(unmount = false) {
		const { fileContainer, options: { onPostRender } } = this;
		if (unmount) {
			if (!this.mounted) return;
			this.mounted = false;
			if (fileContainer == null) return;
			onPostRender?.(fileContainer, this, "unmount");
			return;
		}
		if (fileContainer == null) return;
		const phase = this.mounted ? "update" : "mount";
		this.mounted = true;
		onPostRender?.(fileContainer, this, phase);
	}
	removeRenderedCode() {
		this.resizeManager.cleanUp();
		this.interactionManager.cleanUp();
		this.bufferBefore?.remove();
		this.bufferBefore = void 0;
		this.bufferAfter?.remove();
		this.bufferAfter = void 0;
		this.code?.remove();
		this.code = void 0;
		this.pre?.remove();
		this.pre = void 0;
		this.appliedPreAttributes = void 0;
		this.lastRowCount = void 0;
	}
	clearAuxiliaryNodes() {
		for (const { element } of this.annotationCache.values()) element.remove();
		this.annotationCache.clear();
		this.gutterUtilityContent?.remove();
		this.gutterUtilityContent = void 0;
	}
	canPartiallyRender(forceRender, annotationsChanged, didContentChange) {
		if (forceRender || annotationsChanged || didContentChange) return false;
		return true;
	}
	renderPlaceholder(height) {
		if (this.fileContainer == null) return false;
		this.emitPostRender(true);
		this.cleanChildNodes();
		if (this.placeHolder == null) {
			const shadowRoot = this.fileContainer.shadowRoot ?? this.fileContainer.attachShadow({ mode: "open" });
			this.placeHolder = document.createElement("div");
			this.placeHolder.dataset.placeholder = "";
			shadowRoot.appendChild(this.placeHolder);
		}
		this.placeHolder.style.setProperty("height", `${height}px`);
		return true;
	}
	async primeHighlightCache(file = this.file) {
		const { workerManager } = this;
		if (file == null || workerManager == null || !workerManager.isWorkingPool() || file.cacheKey == null || isFilePlainText(file)) return;
		const tokenizeMaxLength = this.options.tokenizeMaxLength ?? 1e5;
		if (this.fileRenderer.getOrCreateLineCache(file).length > tokenizeMaxLength) return;
		await workerManager.primeFileHighlightCache(file).catch((error) => {
			console.error(error);
		});
	}
	cleanChildNodes() {
		this.resizeManager.cleanUp();
		this.interactionManager.cleanUp();
		this.clearAuxiliaryNodes();
		this.bufferAfter?.remove();
		this.bufferBefore?.remove();
		this.code?.remove();
		this.errorWrapper?.remove();
		this.headerElement?.remove();
		this.headerPrefix?.remove();
		this.headerFilenameSuffix?.remove();
		this.headerMetadata?.remove();
		this.headerCustom?.remove();
		this.pre?.remove();
		this.spriteSVG?.remove();
		this.themeCSSStyle?.remove();
		this.unsafeCSSStyle?.remove();
		this.bufferAfter = void 0;
		this.bufferBefore = void 0;
		this.code = void 0;
		this.errorWrapper = void 0;
		this.headerElement = void 0;
		this.headerPrefix = void 0;
		this.headerFilenameSuffix = void 0;
		this.headerMetadata = void 0;
		this.headerCustom = void 0;
		this.pre = void 0;
		this.spriteSVG = void 0;
		this.themeCSSStyle = void 0;
		this.appliedThemeCSS = void 0;
		this.hasAdoptedThemeCSS = false;
		this.unsafeCSSStyle = void 0;
		this.appliedUnsafeCSS = void 0;
		this.lastRenderedHeaderHTML = void 0;
		this.lastRowCount = void 0;
		this.mounted = false;
	}
	renderAnnotations() {
		if (this.isContainerManaged || this.fileContainer == null) {
			for (const { element } of this.annotationCache.values()) element.remove();
			this.annotationCache.clear();
			return;
		}
		const staleAnnotations = new Map(this.annotationCache);
		const { renderAnnotation } = this.options;
		if (renderAnnotation != null && this.lineAnnotations.length > 0) for (const [index, annotation] of this.lineAnnotations.entries()) {
			const id = `${index}-${getLineAnnotationName(annotation)}`;
			let cache = this.annotationCache.get(id);
			if (cache == null || !areLineAnnotationsEqual(annotation, cache.annotation)) {
				cache?.element.remove();
				const content = renderAnnotation(annotation);
				if (content == null) continue;
				cache = {
					element: createAnnotationWrapperNode(getLineAnnotationName(annotation)),
					annotation
				};
				cache.element.appendChild(content);
				this.fileContainer.appendChild(cache.element);
				this.annotationCache.set(id, cache);
			}
			staleAnnotations.delete(id);
		}
		for (const [id, { element }] of staleAnnotations.entries()) {
			this.annotationCache.delete(id);
			element.remove();
		}
	}
	renderGutterUtility() {
		const { renderGutterUtility } = this.options;
		if (this.fileContainer == null || renderGutterUtility == null) {
			this.gutterUtilityContent?.remove();
			this.gutterUtilityContent = void 0;
			return;
		}
		const element = renderGutterUtility(this.interactionManager.getHoveredLine);
		if (element != null && this.gutterUtilityContent != null) return;
		else if (element == null) {
			this.gutterUtilityContent?.remove();
			this.gutterUtilityContent = void 0;
			return;
		}
		const gutterUtilityContent = createGutterUtilityContentNode();
		gutterUtilityContent.appendChild(element);
		this.fileContainer.appendChild(gutterUtilityContent);
		this.gutterUtilityContent = gutterUtilityContent;
	}
	injectUnsafeCSS() {
		const { unsafeCSS } = this.options;
		const shadowRoot = this.fileContainer?.shadowRoot;
		if (shadowRoot == null) return;
		if (unsafeCSS == null || unsafeCSS === "") {
			if (this.unsafeCSSStyle != null) {
				this.unsafeCSSStyle.remove();
				this.unsafeCSSStyle = void 0;
			}
			this.appliedUnsafeCSS = void 0;
			return;
		}
		if (this.unsafeCSSStyle?.parentNode === shadowRoot && this.appliedUnsafeCSS === unsafeCSS) return;
		this.unsafeCSSStyle ??= createUnsafeCSSStyleNode();
		if (this.unsafeCSSStyle.parentNode !== shadowRoot) shadowRoot.appendChild(this.unsafeCSSStyle);
		this.unsafeCSSStyle.textContent = wrapUnsafeCSS(unsafeCSS);
		this.appliedUnsafeCSS = unsafeCSS;
	}
	applyThemeState(container, themeStyles, themeType, baseThemeType) {
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		const effectiveThemeType = baseThemeType ?? themeType;
		const currentTheme = this.options.theme ?? DEFAULT_THEMES;
		const theme = typeof currentTheme === "string" ? currentTheme : { ...currentTheme };
		const scrollbarGutter = getMeasuredScrollbarGutter(shadowRoot);
		if (this.themeCSSStyle?.parentNode === shadowRoot && this.appliedThemeCSS?.themeStyles === themeStyles && this.appliedThemeCSS.themeType === effectiveThemeType && this.appliedThemeCSS.scrollbarGutter === scrollbarGutter) {
			this.appliedThemeCSS.theme = theme;
			return;
		}
		if (this.hasAdoptedThemeCSS && this.themeCSSStyle?.parentNode === shadowRoot) {
			this.hasAdoptedThemeCSS = false;
			this.appliedThemeCSS = {
				theme,
				themeStyles,
				themeType: effectiveThemeType,
				baseThemeType,
				scrollbarGutter
			};
			return;
		}
		this.themeCSSStyle = upsertHostThemeStyle({
			shadowRoot,
			currentNode: this.themeCSSStyle,
			themeCSS: wrapThemeCSS(themeStyles, effectiveThemeType, scrollbarGutter)
		});
		this.appliedThemeCSS = this.themeCSSStyle != null ? {
			theme,
			themeStyles,
			themeType: effectiveThemeType,
			baseThemeType,
			scrollbarGutter
		} : void 0;
	}
	hydrateMeasuredScrollbar() {
		const shadowRoot = this.fileContainer?.shadowRoot;
		if (shadowRoot == null || this.themeCSSStyle == null) return;
		this.themeCSSStyle.textContent = patchScrollbarGutterSize(this.themeCSSStyle.textContent ?? "", getMeasuredScrollbarGutter(shadowRoot));
	}
	shouldGuardRebuildScroll() {
		return this.editor != null && isSafari();
	}
	applyFullRender(result, pre) {
		this.cleanupErrorWrapper();
		this.applyPreNodeAttributes(pre, result);
		const code = this.code = getOrCreateCodeNode({ code: this.code });
		const codeAst = this.fileRenderer.renderCodeAST(result);
		this.editor?.__captureFocusForDOMReplacement();
		const applyColumns = () => {
			if (code.childElementCount >= 2) for (let i = 0; i < 2; i++) {
				const domEl = code.children[i];
				const astEl = codeAst[i];
				domEl.innerHTML = toHtml(astEl.children);
				domEl.style.cssText = astEl.properties.style;
			}
			else code.innerHTML = toHtml(codeAst);
			if (!pre.contains(code)) pre.replaceChildren(code);
		};
		if (this.shouldGuardRebuildScroll()) guardWebKitScrollDuringRebuild(pre, applyColumns);
		else applyColumns();
		this.lastRowCount = result.rowCount;
	}
	applyPartialRender(previousRenderRange, renderRange) {
		if (previousRenderRange == null || renderRange == null) return false;
		const { file, code } = this;
		const columns = code != null ? this.getColumns(code) : void 0;
		if (file == null || code == null || columns == null) return false;
		const previousStart = previousRenderRange.startingLine;
		const nextStart = renderRange.startingLine;
		const previousEnd = previousRenderRange.totalLines === Infinity ? Number.POSITIVE_INFINITY : previousStart + previousRenderRange.totalLines;
		const nextEnd = renderRange.totalLines === Infinity ? Number.POSITIVE_INFINITY : nextStart + renderRange.totalLines;
		const overlapStart = Math.max(previousStart, nextStart);
		const overlapEnd = Math.min(previousEnd, nextEnd);
		if (overlapEnd <= overlapStart) return false;
		if (!this.trimDOMToOverlap(columns.gutter, overlapStart, overlapEnd) || !this.trimDOMToOverlap(columns.content, overlapStart, overlapEnd)) throw new Error("File.applyPartialRender: failed to trim to overlap");
		let { length: rowCount } = columns.content.children;
		const renderChunk = (startingLine, totalLines) => {
			if (totalLines <= 0) return;
			return this.fileRenderer.renderFile(file, {
				startingLine,
				totalLines,
				bufferBefore: 0,
				bufferAfter: 0
			});
		};
		const prependResult = nextStart < overlapStart ? renderChunk(nextStart, overlapStart - nextStart) : void 0;
		if (prependResult === void 0 && nextStart < overlapStart) return false;
		const appendTotalLines = nextEnd === Number.POSITIVE_INFINITY ? Number.POSITIVE_INFINITY : Math.max(0, nextEnd - overlapEnd);
		const appendResult = nextEnd > overlapEnd ? renderChunk(overlapEnd, appendTotalLines) : void 0;
		if (appendResult === void 0 && nextEnd > overlapEnd) return false;
		this.cleanupErrorWrapper();
		if (prependResult != null) {
			columns.gutter.insertAdjacentHTML("afterbegin", this.fileRenderer.renderPartialHTML(prependResult.gutterAST));
			columns.content.insertAdjacentHTML("afterbegin", this.fileRenderer.renderPartialHTML(prependResult.contentAST));
			rowCount += prependResult.rowCount;
		}
		if (appendResult != null) {
			columns.gutter.insertAdjacentHTML("beforeend", this.fileRenderer.renderPartialHTML(appendResult.gutterAST));
			columns.content.insertAdjacentHTML("beforeend", this.fileRenderer.renderPartialHTML(appendResult.contentAST));
			rowCount += appendResult.rowCount;
		}
		if (this.lastRowCount !== rowCount) {
			columns.gutter.style.setProperty("grid-row", `span ${rowCount}`);
			columns.content.style.setProperty("grid-row", `span ${rowCount}`);
			this.lastRowCount = rowCount;
		}
		return true;
	}
	getColumns(code) {
		const gutter = code.children[0];
		const content = code.children[1];
		if (!(gutter instanceof HTMLElement) || !(content instanceof HTMLElement) || gutter.dataset.gutter == null || content.dataset.content == null) return;
		return {
			gutter,
			content
		};
	}
	trimDOMToOverlap(container, overlapStart, overlapEnd) {
		const boundaryIndices = this.getDOMBoundaryIndices(container, [overlapStart, overlapEnd]);
		const startIndex = boundaryIndices.get(overlapStart) ?? container.children.length;
		const endIndex = boundaryIndices.get(overlapEnd) ?? container.children.length;
		if (startIndex > endIndex) return false;
		for (let i = container.children.length - 1; i >= endIndex; i -= 1) container.children[i]?.remove();
		for (let i = startIndex - 1; i >= 0; i -= 1) container.children[i]?.remove();
		return true;
	}
	getDOMBoundaryIndices(container, boundaries) {
		const sortedBoundaries = [...new Set(boundaries)].sort((a, b) => a - b);
		const boundaryIndices = /* @__PURE__ */ new Map();
		if (sortedBoundaries.length === 0) return boundaryIndices;
		let boundaryIndex = 0;
		let nextBoundary = sortedBoundaries[boundaryIndex];
		const { children } = container;
		if (nextBoundary === 0) {
			boundaryIndices.set(0, 0);
			boundaryIndex += 1;
			nextBoundary = sortedBoundaries[boundaryIndex];
		}
		for (let i = 0; i < children.length; i += 1) {
			const child = children[i];
			if (!(child instanceof HTMLElement)) continue;
			const lineIndex = this.getLineIndexFromDOMNode(child);
			if (lineIndex == null) continue;
			while (nextBoundary != null && lineIndex >= nextBoundary) {
				boundaryIndices.set(nextBoundary, i);
				boundaryIndex += 1;
				nextBoundary = sortedBoundaries[boundaryIndex];
			}
			if (boundaryIndex >= sortedBoundaries.length) break;
		}
		for (const boundary of sortedBoundaries) if (!boundaryIndices.has(boundary)) boundaryIndices.set(boundary, children.length);
		return boundaryIndices;
	}
	getLineIndexFromDOMNode(node) {
		const lineIndexAttr = node.dataset.lineIndex;
		if (lineIndexAttr == null) return;
		const parsed = Number(lineIndexAttr);
		return Number.isNaN(parsed) ? void 0 : parsed;
	}
	applyBuffers(pre, renderRange) {
		if (renderRange == null || this.shouldDisableVirtualizationBuffers()) {
			if (this.bufferBefore != null) {
				this.bufferBefore.remove();
				this.bufferBefore = void 0;
			}
			if (this.bufferAfter != null) {
				this.bufferAfter.remove();
				this.bufferAfter = void 0;
			}
			return;
		}
		if (renderRange.bufferBefore > 0) {
			if (this.bufferBefore == null) {
				this.bufferBefore = document.createElement("div");
				this.bufferBefore.dataset.virtualizerBuffer = "before";
				pre.before(this.bufferBefore);
			}
			this.bufferBefore.style.setProperty("height", `${renderRange.bufferBefore}px`);
			this.bufferBefore.style.setProperty("contain", "strict");
		} else if (this.bufferBefore != null) {
			this.bufferBefore.remove();
			this.bufferBefore = void 0;
		}
		if (renderRange.bufferAfter > 0) {
			if (this.bufferAfter == null) {
				this.bufferAfter = document.createElement("div");
				this.bufferAfter.dataset.virtualizerBuffer = "after";
				pre.after(this.bufferAfter);
			}
			this.bufferAfter.style.setProperty("height", `${renderRange.bufferAfter}px`);
			this.bufferAfter.style.setProperty("contain", "strict");
		} else if (this.bufferAfter != null) {
			this.bufferAfter.remove();
			this.bufferAfter = void 0;
		}
	}
	shouldDisableVirtualizationBuffers() {
		return this.options.disableVirtualizationBuffers ?? false;
	}
	applyHeaderToDOM(headerAST, container) {
		const { file } = this;
		if (file == null) return;
		this.cleanupErrorWrapper();
		this.placeHolder?.remove();
		this.placeHolder = void 0;
		const headerHTML = this.cachedHeaderHTML ?? toHtml(headerAST);
		this.cachedHeaderHTML = headerHTML;
		if (headerHTML !== this.lastRenderedHeaderHTML) {
			const tempDiv = document.createElement("div");
			tempDiv.innerHTML = headerHTML;
			const newHeader = tempDiv.firstElementChild;
			if (!(newHeader instanceof HTMLElement)) return;
			if (this.headerElement != null) container.shadowRoot?.replaceChild(newHeader, this.headerElement);
			else container.shadowRoot?.prepend(newHeader);
			this.headerElement = newHeader;
			this.lastRenderedHeaderHTML = headerHTML;
		}
		if (this.isContainerManaged) return;
		const { renderHeaderPrefix, renderHeaderFilenameSuffix, renderCustomHeader, renderHeaderMetadata } = this.options;
		if (renderCustomHeader != null) {
			const content = renderCustomHeader(file) ?? void 0;
			this.headerCustom = this.upsertHeaderSlotElement(container, this.headerCustom, CUSTOM_HEADER_SLOT_ID, content);
			this.headerPrefix?.remove();
			this.headerFilenameSuffix?.remove();
			this.headerMetadata?.remove();
			this.headerPrefix = void 0;
			this.headerFilenameSuffix = void 0;
			this.headerMetadata = void 0;
		} else {
			const prefix = renderHeaderPrefix?.(file) ?? void 0;
			const suffix = renderHeaderFilenameSuffix?.(file) ?? void 0;
			const content = renderHeaderMetadata?.(file) ?? void 0;
			this.headerPrefix = this.upsertHeaderSlotElement(container, this.headerPrefix, HEADER_PREFIX_SLOT_ID, prefix);
			this.headerFilenameSuffix = this.upsertHeaderSlotElement(container, this.headerFilenameSuffix, HEADER_FILENAME_SUFFIX_SLOT_ID, suffix);
			this.headerMetadata = this.upsertHeaderSlotElement(container, this.headerMetadata, HEADER_METADATA_SLOT_ID, content);
			this.headerCustom?.remove();
			this.headerCustom = void 0;
		}
	}
	clearHeaderSlots() {
		this.headerPrefix?.remove();
		this.headerFilenameSuffix?.remove();
		this.headerMetadata?.remove();
		this.headerCustom?.remove();
		this.headerPrefix = void 0;
		this.headerFilenameSuffix = void 0;
		this.headerMetadata = void 0;
		this.headerCustom = void 0;
	}
	upsertHeaderSlotElement(container, current, slot, content) {
		if (content == null) {
			current?.remove();
			return;
		}
		const element = current ?? this.createHeaderSlotElement(slot);
		if (current == null) container.appendChild(element);
		this.replaceHeaderSlotContent(element, content);
		return element;
	}
	replaceHeaderSlotContent(element, content) {
		element.replaceChildren();
		if (content instanceof Element) element.appendChild(content);
		else element.innerText = `${content}`;
	}
	createHeaderSlotElement(slot) {
		const element = document.createElement("div");
		element.slot = slot;
		return element;
	}
	getOrCreateFileContainerNode(fileContainer, parentNode) {
		const { fileContainer: previousContainer } = this;
		const nextContainer = fileContainer ?? previousContainer ?? document.createElement("diffs-container");
		const containerChanged = previousContainer !== nextContainer;
		if (previousContainer != null && containerChanged) this.editor?.__captureFocusForDOMReplacement();
		if (containerChanged) this.emitPostRender(true);
		this.fileContainer = nextContainer;
		if (previousContainer != null && containerChanged) {
			this.lastRenderedHeaderHTML = void 0;
			this.headerElement = void 0;
		}
		if (parentNode != null && this.fileContainer.parentNode !== parentNode) parentNode.appendChild(this.fileContainer);
		if (containerChanged) this.adoptReusableShellElements(this.fileContainer);
		this.ensureSpriteSVG(this.fileContainer);
		return this.fileContainer;
	}
	adoptReusableShellElements(fileContainer) {
		const { shadowRoot } = fileContainer;
		if (shadowRoot == null) return;
		for (const element of shadowRoot.children) if (element instanceof SVGElement) this.spriteSVG ??= element;
		else if (isStyleNode(element) && element.hasAttribute("data-theme-css")) {
			this.themeCSSStyle ??= element;
			this.hasAdoptedThemeCSS = true;
		} else if (isStyleNode(element) && element.hasAttribute("data-unsafe-css")) {
			this.unsafeCSSStyle ??= element;
			this.appliedUnsafeCSS ??= this.options.unsafeCSS ?? void 0;
		}
	}
	ensureSpriteSVG(fileContainer) {
		const shadowRoot = fileContainer.shadowRoot ?? fileContainer.attachShadow({ mode: "open" });
		if (this.spriteSVG == null) {
			const fragment = document.createElement("div");
			fragment.innerHTML = SVGSpriteSheet;
			const firstChild = fragment.firstChild;
			if (firstChild instanceof SVGElement) this.spriteSVG = firstChild;
		}
		if (this.spriteSVG != null && this.spriteSVG.parentNode !== shadowRoot) shadowRoot.appendChild(this.spriteSVG);
	}
	getOrCreatePreNode(container) {
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		if (this.pre == null) {
			this.pre = document.createElement("pre");
			this.appliedPreAttributes = void 0;
			this.code = void 0;
			shadowRoot.appendChild(this.pre);
		} else if (this.pre.parentNode !== shadowRoot) {
			this.editor?.__captureFocusForDOMReplacement();
			container.shadowRoot?.appendChild(this.pre);
			this.appliedPreAttributes = void 0;
		}
		this.placeHolder?.remove();
		this.placeHolder = void 0;
		return this.pre;
	}
	syncCodeNodeFromPre(pre) {
		this.code = void 0;
		for (const child of Array.from(pre.children)) {
			if (!(child instanceof HTMLElement)) continue;
			if (child.hasAttribute("data-code")) {
				this.code = child;
				return;
			}
		}
	}
	applyPreNodeAttributes(pre, { totalLines }) {
		const { overflow = "scroll", disableLineNumbers = false } = this.options;
		const preProperties = {
			type: "file",
			split: false,
			overflow,
			disableLineNumbers,
			diffIndicators: "none",
			disableBackground: true,
			totalLines
		};
		if (arePrePropertiesEqual(preProperties, this.appliedPreAttributes)) return;
		setPreNodeProperties(pre, preProperties);
		this.appliedPreAttributes = preProperties;
	}
	applyErrorToDOM(error, container) {
		this.cleanupErrorWrapper();
		this.pre?.remove();
		this.pre = void 0;
		this.appliedPreAttributes = void 0;
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		this.errorWrapper ??= document.createElement("div");
		this.errorWrapper.dataset.errorWrapper = "";
		this.errorWrapper.textContent = "";
		shadowRoot.appendChild(this.errorWrapper);
		const errorMessage = document.createElement("div");
		errorMessage.dataset.errorMessage = "";
		errorMessage.innerText = error.message;
		this.errorWrapper.appendChild(errorMessage);
		const errorStack = document.createElement("pre");
		errorStack.dataset.errorStack = "";
		errorStack.innerText = error.stack ?? "No Error Stack";
		this.errorWrapper.appendChild(errorStack);
	}
	cleanupErrorWrapper() {
		this.errorWrapper?.remove();
		this.errorWrapper = void 0;
	}
};
function shouldRenderCode$2(pre, file, collapsed = false) {
	return !collapsed && pre == null && file != null;
}
function shouldRenderHeader$2(headerElement, file, disableFileHeader = false) {
	return headerElement == null && file != null && !disableFileHeader;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/computeVirtualFileMetrics.js
function computeVirtualFileMetrics(metrics) {
	return {
		...DEFAULT_VIRTUAL_FILE_METRICS,
		...metrics
	};
}
function getVirtualFileHeaderRegion(metrics, disableFileHeader) {
	const paddingTop = getVirtualFilePaddingTop(metrics, disableFileHeader);
	return disableFileHeader ? paddingTop : metrics.diffHeaderHeight + paddingTop;
}
function getVirtualFilePaddingTop(metrics, disableFileHeader) {
	return metrics.paddingTop ?? (disableFileHeader ? metrics.spacing : 0);
}
function getVirtualFilePaddingBottom(metrics) {
	return metrics.paddingBottom ?? metrics.spacing;
}
function getDefaultHunkSeparatorHeight(type) {
	switch (type) {
		case "simple": return 4;
		case "metadata":
		case "line-info":
		case "line-info-basic":
		case "custom": return 32;
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/VirtualizedFile.js
var LAYOUT_CHECKPOINT_INTERVAL = 5e3;
var instanceId$4 = -1;
function hasFileLayoutOptionChanged(previousOptions, nextOptions) {
	return (previousOptions.overflow ?? "scroll") !== (nextOptions.overflow ?? "scroll") || (previousOptions.collapsed ?? false) !== (nextOptions.collapsed ?? false) || (previousOptions.disableLineNumbers ?? false) !== (nextOptions.disableLineNumbers ?? false) || (previousOptions.disableFileHeader ?? false) !== (nextOptions.disableFileHeader ?? false) || previousOptions.unsafeCSS !== nextOptions.unsafeCSS;
}
var VirtualizedFile = class extends File {
	virtualizer;
	metrics;
	__id = `virtualized-file:${++instanceId$4}`;
	top;
	height = 0;
	cache = {
		heights: /* @__PURE__ */ new Map(),
		checkpoints: [],
		fileAnnotationHeight: 0
	};
	isVisible = false;
	isSetup = false;
	layoutDirty = true;
	forceRenderOverride;
	currentCollapsed;
	constructor(options, virtualizer, metrics = DEFAULT_VIRTUAL_FILE_METRICS, workerManager, isContainerManaged = false) {
		super(options, workerManager, isContainerManaged);
		this.virtualizer = virtualizer;
		this.metrics = metrics;
	}
	setMetrics(metrics, force = false) {
		const nextMetrics = computeVirtualFileMetrics(metrics);
		if (!force && areObjectsEqual(this.metrics, nextMetrics)) return;
		this.metrics = nextMetrics;
		this.resetLayoutCache();
	}
	setLineAnnotations(lineAnnotations) {
		if (this.syncLineAnnotations(lineAnnotations)) this.resetLayoutCache();
	}
	syncLineAnnotations(lineAnnotations) {
		if (lineAnnotations == null || lineAnnotations === this.lineAnnotations) return false;
		if (lineAnnotations.length === 0 && this.lineAnnotations.length === 0) return false;
		super.setLineAnnotations(lineAnnotations);
		return true;
	}
	hasLineAnnotations() {
		return this.lineAnnotations.some((annotation) => annotation.lineNumber > 0);
	}
	getLineHeight(lineIndex, hasMetadataLine = false) {
		const cached = this.cache.heights.get(lineIndex);
		if (cached != null) return cached;
		const multiplier = hasMetadataLine ? 2 : 1;
		return this.metrics.lineHeight * multiplier;
	}
	setOptions(options) {
		if (this.isAdvancedMode()) throw new Error("VirtualizedFile.setOptions cannot be used inside CodeView. Update CodeView options instead.");
		if (options == null) return;
		const { options: previousOptions } = this;
		const optionsChanged = !areOptionsEqual(previousOptions, options);
		const layoutChanged = hasFileLayoutOptionChanged(previousOptions, options);
		super.setOptions(options);
		if (layoutChanged) this.resetLayoutCache(true);
		if (optionsChanged) this.forceRenderOverride = true;
		if (optionsChanged) this.virtualizer.instanceChanged(this, layoutChanged);
	}
	setThemeType(themeType) {
		if (this.isAdvancedMode()) throw new Error("VirtualizedFile.setThemeType cannot be used inside CodeView. Update CodeView options instead.");
		super.setThemeType(themeType);
	}
	resetLayoutCache(recompute = false, resetRenderRange = true) {
		this.layoutDirty = true;
		this.cache.fileAnnotationHeight = 0;
		if (this.cache.heights.size > 0) this.cache.heights.clear();
		if (this.cache.checkpoints.length > 0) this.cache.checkpoints.length = 0;
		if (this.renderRange != null && resetRenderRange) this.renderRange = void 0;
		if (recompute && this.isSimpleMode()) this.computeApproximateSize();
	}
	reconcileHeights() {
		let hasHeightChange = false;
		if (this.fileContainer == null || this.file == null) {
			if (this.height !== 0) hasHeightChange = true;
			this.height = 0;
			return hasHeightChange;
		}
		const { overflow = "scroll" } = this.options;
		this.top = this.getVirtualizedTop();
		if (overflow === "scroll" && this.lineAnnotations.length === 0 && !this.isResizeDebuggingEnabled()) return hasHeightChange;
		if (this.code == null) return hasHeightChange;
		const content = this.code.children[1];
		if (!(content instanceof HTMLElement)) return hasHeightChange;
		const hasFileAnnotations = includesFileAnnotations(this.lineAnnotations);
		if (this.renderRange != null && hasFileAnnotations && shouldRenderFileAnnotations(this.renderRange)) {
			const nextFileAnnotationHeight = measureFileAnnotationHeight$1(content) ?? 0;
			if (nextFileAnnotationHeight !== this.cache.fileAnnotationHeight) {
				this.cache.fileAnnotationHeight = nextFileAnnotationHeight;
				hasHeightChange = true;
			}
		} else if (!hasFileAnnotations && this.cache.fileAnnotationHeight !== 0) {
			this.cache.fileAnnotationHeight = 0;
			hasHeightChange = true;
		}
		for (const line of content.children) {
			if (!(line instanceof HTMLElement)) continue;
			const lineIndexAttr = line.dataset.lineIndex;
			if (lineIndexAttr == null) continue;
			const lineIndex = Number(lineIndexAttr);
			let measuredHeight = line.getBoundingClientRect().height;
			let hasMetadata = false;
			if (line.nextElementSibling instanceof HTMLElement && ("lineAnnotation" in line.nextElementSibling.dataset || "noNewline" in line.nextElementSibling.dataset)) {
				if ("noNewline" in line.nextElementSibling.dataset) hasMetadata = true;
				measuredHeight += line.nextElementSibling.getBoundingClientRect().height;
			}
			const expectedHeight = this.getLineHeight(lineIndex, hasMetadata);
			if (measuredHeight === expectedHeight) continue;
			hasHeightChange = true;
			if (measuredHeight === this.metrics.lineHeight * (hasMetadata ? 2 : 1)) this.cache.heights.delete(lineIndex);
			else this.cache.heights.set(lineIndex, measuredHeight);
		}
		if (hasHeightChange || this.isResizeDebuggingEnabled()) this.computeApproximateSize(true);
		return hasHeightChange;
	}
	onRender = (dirty) => {
		if (this.fileContainer == null || this.file == null) return false;
		if (dirty) this.top = this.getVirtualizedTop();
		return this.render({ file: this.file });
	};
	prepareCodeViewItem(file, top, reset, lineAnnotations) {
		const annotationsChanged = this.syncLineAnnotations(lineAnnotations);
		const targetChanged = !areFilesEqual(this.file, file) || this.fileRenderer.hasUnkeyedFileContentsChanged(file);
		let shouldResetLayoutCache = reset?.resetFileLayoutCache === true || targetChanged || annotationsChanged;
		if (reset?.metrics != null) {
			this.metrics = reset.metrics;
			shouldResetLayoutCache = true;
		}
		const { collapsed = false } = this.options;
		if (this.currentCollapsed !== collapsed) {
			this.currentCollapsed = collapsed;
			shouldResetLayoutCache = true;
		}
		if (shouldResetLayoutCache) this.resetLayoutCache();
		if (this.file !== file) this.layoutDirty = true;
		this.file = file;
		this.top = top;
		this.computeApproximateSize();
		return this.height;
	}
	getLinePosition(lineNumber) {
		if (this.file == null || lineNumber < 1) return;
		const { disableFileHeader = false, collapsed = false } = this.options;
		const lastLineIndex = this.fileRenderer.getLineCount(this.file) - 1;
		let top = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		if (collapsed || lastLineIndex < 0) return {
			top,
			height: 0
		};
		const clampedLineIndex = Math.min(Math.max(lineNumber - 1, 0), lastLineIndex);
		const { overflow = "scroll" } = this.options;
		const { lineHeight } = this.metrics;
		top += this.cache.fileAnnotationHeight;
		if (overflow === "scroll" && !this.hasLineAnnotations()) return {
			top: top + clampedLineIndex * lineHeight,
			height: lineHeight
		};
		const checkpoint = this.getLayoutCheckpointBeforeLineIndex(clampedLineIndex);
		top = checkpoint?.top ?? top;
		for (let lineIndex = checkpoint?.lineIndex ?? 0; lineIndex < clampedLineIndex; lineIndex++) top += this.getLineHeight(lineIndex, false);
		return {
			top,
			height: this.getLineHeight(clampedLineIndex, false)
		};
	}
	getEditorViewport() {
		return this.virtualizer.type === "simple" ? this.virtualizer.getRoot() : this.virtualizer.getContainerElement();
	}
	getNumericScrollAnchor(localViewportTop) {
		if (this.file == null || this.renderRange == null) return;
		const { disableFileHeader = false, collapsed = false, overflow = "scroll" } = this.options;
		if (collapsed || this.renderRange.totalLines <= 0) return;
		const lastLineIndex = this.fileRenderer.getLineCount(this.file) - 1;
		if (lastLineIndex < 0) return;
		const headerRegion = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		const firstRenderedLineIndex = Math.min(this.renderRange.startingLine, lastLineIndex);
		const lastRenderedLineIndex = Math.min(firstRenderedLineIndex + this.renderRange.totalLines - 1, lastLineIndex);
		if (lastRenderedLineIndex < firstRenderedLineIndex) return;
		const { fileAnnotationHeight } = this.cache;
		if (overflow === "scroll" && !this.hasLineAnnotations()) {
			const { lineHeight } = this.metrics;
			const firstRenderedLineTop = headerRegion + (firstRenderedLineIndex === 0 ? fileAnnotationHeight : this.renderRange.bufferBefore);
			const lineIndex = firstRenderedLineIndex + Math.max(Math.ceil((localViewportTop - firstRenderedLineTop) / lineHeight), 0);
			if (lineIndex > lastRenderedLineIndex) return;
			return {
				lineNumber: lineIndex + 1,
				top: headerRegion + fileAnnotationHeight + lineIndex * lineHeight
			};
		}
		let top = headerRegion + (firstRenderedLineIndex === 0 ? fileAnnotationHeight : this.renderRange.bufferBefore);
		for (let lineIndex = firstRenderedLineIndex; lineIndex <= lastRenderedLineIndex; lineIndex++) {
			if (top >= localViewportTop) return {
				lineNumber: lineIndex + 1,
				top
			};
			top += this.getLineHeight(lineIndex);
		}
	}
	getVirtualizedHeight() {
		return this.height;
	}
	getAdvancedStickySpecs(windowSpecs) {
		if (this.top == null || this.file == null) return;
		if (this.options.collapsed === true) return {
			topOffset: this.top,
			height: this.height
		};
		const renderRange = windowSpecs != null ? this.computeRenderRangeFromWindow(this.file, this.top, windowSpecs) : this.renderRange;
		if (renderRange == null) return;
		const { bufferBefore, bufferAfter, totalLines } = renderRange;
		let headerOnlyOffset = 0;
		if (totalLines === 0) {
			const activeWindow = windowSpecs ?? this.virtualizer.getWindowSpecs();
			if (this.top < activeWindow.top) headerOnlyOffset = bufferAfter;
		}
		return {
			topOffset: this.top + bufferBefore + headerOnlyOffset,
			height: this.height - (bufferBefore + bufferAfter)
		};
	}
	cleanUp(recycle = false) {
		if (this.fileContainer != null && this.isSimpleMode()) this.getSimpleVirtualizer()?.disconnect(this.fileContainer);
		if (!recycle) this.resetLayoutCache();
		this.isSetup = false;
		super.cleanUp(recycle);
	}
	computeApproximateSize(force = false, file = this.file) {
		const shouldValidateSize = this.isResizeDebuggingEnabled();
		if (!force && !this.layoutDirty && !shouldValidateSize) return;
		const isFirstCompute = this.height === 0;
		this.height = 0;
		this.cache.checkpoints = [];
		if (file == null) {
			this.layoutDirty = false;
			return;
		}
		const { disableFileHeader = false, collapsed = false, overflow = "scroll" } = this.options;
		const { lineHeight } = this.metrics;
		const lineCount = this.fileRenderer.getLineCount(file);
		const headerRegion = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		const paddingBottom = getVirtualFilePaddingBottom(this.metrics);
		this.height += headerRegion;
		if (collapsed) {
			this.layoutDirty = false;
			return;
		}
		this.height += this.cache.fileAnnotationHeight;
		if (overflow === "scroll" && !this.hasLineAnnotations()) this.height += lineCount * lineHeight;
		else for (let lineIndex = 0; lineIndex < lineCount; lineIndex++) {
			this.addLayoutCheckpoint(lineIndex, this.height);
			this.height += this.getLineHeight(lineIndex, false);
		}
		if (lineCount > 0) this.height += paddingBottom;
		if (this.fileContainer != null && shouldValidateSize && !isFirstCompute) {
			const rect = this.fileContainer.getBoundingClientRect();
			if (rect.height !== this.height) console.log("VirtualizedFile.computeApproximateSize: computed height doesnt match", {
				name: file.name,
				elementHeight: rect.height,
				computedHeight: this.height
			});
			else console.log("VirtualizedFile.computeApproximateSize: computed height IS CORRECT");
		}
		this.layoutDirty = false;
	}
	setVisibility(visible) {
		if (this.isAdvancedMode() || this.fileContainer == null) return;
		this.renderRange = void 0;
		if (visible && !this.isVisible) {
			this.top = this.getVirtualizedTop();
			this.isVisible = true;
		} else if (!visible && this.isVisible) {
			this.isVisible = false;
			this.rerender();
		}
	}
	rerender() {
		if (!this.enabled || this.file == null) return;
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, false);
	}
	applyDocumentChange(textDocument, newLineAnnotations, shouldUpdateBuffer = false) {
		const { renderRange: previousRenderRange } = this;
		this.getAdvancedVirtualizer()?.capturePendingLayoutAnchor();
		super.applyDocumentChange(textDocument, newLineAnnotations);
		this.getSimpleVirtualizer()?.markDOMDirty();
		this.resetLayoutCache(this.isSimpleMode(), false);
		if (!this.isSimpleMode()) this.computeApproximateSize(true);
		else if (shouldUpdateBuffer && previousRenderRange !== void 0 && this.file !== void 0) {
			const windowSpecs = this.virtualizer.getWindowSpecs();
			const renderRange = this.computeRenderRangeFromWindow(this.file, this.top ?? 0, windowSpecs);
			if (renderRange.bufferAfter !== previousRenderRange.bufferAfter) this.updateBuffers(renderRange);
		}
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, true);
	}
	renderPreparedFile({ fileContainer, file, forceRender = false, lineAnnotations, ...props }) {
		const didFileChange = this.file == null || !areFilesEqual(this.file, file) || this.fileRenderer.hasUnkeyedFileContentsChanged(file);
		const { forceRenderOverride, isSetup } = this;
		this.forceRenderOverride = void 0;
		const annotationsChanged = this.syncLineAnnotations(lineAnnotations);
		if (annotationsChanged) this.resetLayoutCache();
		fileContainer = this.getOrCreateFileContainerNode(fileContainer);
		if (file == null) {
			console.error("VirtualizedFile.render: attempting to virtually render when we dont have file");
			return false;
		}
		if (!isSetup) {
			this.computeApproximateSize(false, file);
			const virtualizer = this.getSimpleVirtualizer();
			this.top ??= this.getVirtualizedTop();
			if (this.isAdvancedMode()) this.isVisible = true;
			else {
				if (virtualizer == null) throw new Error("VirtualizedFile.render: simple virtualizer is not available");
				virtualizer.connect(fileContainer, this);
				this.isVisible = virtualizer.isInstanceVisible(this.top ?? 0, this.height);
			}
			this.isSetup = true;
		} else {
			this.top ??= this.getVirtualizedTop();
			if (didFileChange && this.isSimpleMode()) {
				this.getSimpleVirtualizer()?.markDOMDirty();
				this.resetLayoutCache(false);
				this.computeApproximateSize(false, file);
			}
		}
		if (!this.isVisible && this.isSimpleMode() && (!didFileChange || !isSetup)) {
			this.file = file;
			if (didFileChange) this.cachedHeaderHTML = void 0;
			return this.renderPlaceholder(this.height);
		}
		const windowSpecs = this.virtualizer.getWindowSpecs();
		const fileTop = this.top ?? 0;
		const renderRange = this.computeRenderRangeFromWindow(file, fileTop, windowSpecs);
		const rendered = super.renderPreparedFile({
			file,
			fileContainer,
			renderRange,
			lineAnnotations,
			forceRender: (forceRenderOverride ?? forceRender) || annotationsChanged || didFileChange,
			...props
		});
		if (this.isSimpleMode() && rendered) this.getSimpleVirtualizer()?.requestHeightReconcile(this);
		return rendered;
	}
	syncVirtualizedTop() {
		this.top = this.getVirtualizedTop();
	}
	shouldDisableVirtualizationBuffers() {
		return this.isAdvancedMode() || super.shouldDisableVirtualizationBuffers();
	}
	shouldGuardRebuildScroll() {
		return false;
	}
	isSimpleMode() {
		return this.virtualizer.type === "simple";
	}
	isAdvancedMode() {
		return this.virtualizer.type === "advanced";
	}
	addLayoutCheckpoint(lineIndex, top) {
		if (lineIndex % LAYOUT_CHECKPOINT_INTERVAL !== 0) return;
		this.cache.checkpoints.push({
			lineIndex,
			top
		});
	}
	getLayoutCheckpointBeforeLineIndex(lineIndex) {
		if (lineIndex <= 0 || this.cache.checkpoints.length === 0) return;
		let low = 0;
		let high = this.cache.checkpoints.length - 1;
		let result;
		while (low <= high) {
			const mid = low + high >> 1;
			const checkpoint = this.cache.checkpoints[mid];
			if (checkpoint == null) throw new Error("VirtualizedFile: invalid checkpoint index");
			if (checkpoint.lineIndex <= lineIndex) {
				result = checkpoint;
				low = mid + 1;
			} else high = mid - 1;
		}
		return result;
	}
	getLayoutCheckpointBeforeTop(top, hunkLineCount) {
		let low = 0;
		let high = this.cache.checkpoints.length - 1;
		let resultIndex = -1;
		while (low <= high) {
			const mid = low + high >> 1;
			const checkpoint = this.cache.checkpoints[mid];
			if (checkpoint == null) throw new Error("VirtualizedFile: invalid checkpoint index");
			if (checkpoint.top <= top) {
				resultIndex = mid;
				low = mid + 1;
			} else high = mid - 1;
		}
		if (hunkLineCount == null) return resultIndex >= 0 ? this.cache.checkpoints[resultIndex] : void 0;
		for (let index = resultIndex; index >= 0; index--) {
			const checkpoint = this.cache.checkpoints[index];
			if (checkpoint == null) throw new Error("VirtualizedFile: invalid checkpoint index");
			if (checkpoint.lineIndex % hunkLineCount === 0) return checkpoint;
		}
	}
	getVirtualizedTop() {
		if (this.virtualizer.type === "advanced") return this.virtualizer.getLocalTopForInstance(this);
		return this.fileContainer != null ? this.virtualizer.getOffsetInScrollContainer(this.fileContainer) : 0;
	}
	getSimpleVirtualizer() {
		return this.virtualizer.type === "simple" ? this.virtualizer : void 0;
	}
	getAdvancedVirtualizer() {
		return this.virtualizer.type === "advanced" ? this.virtualizer : void 0;
	}
	isResizeDebuggingEnabled() {
		return this.getSimpleVirtualizer()?.config.resizeDebugging ?? false;
	}
	computeRenderRangeFromWindow(file, fileTop, { top, bottom }) {
		const { disableFileHeader = false, overflow = "scroll" } = this.options;
		const { hunkLineCount, lineHeight } = this.metrics;
		const lineCount = this.fileRenderer.getLineCount(file);
		const fileHeight = this.height;
		const headerRegion = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		const paddingBottom = lineCount > 0 ? getVirtualFilePaddingBottom(this.metrics) : 0;
		const { fileAnnotationHeight } = this.cache;
		const codeRegionTop = headerRegion + fileAnnotationHeight;
		const codeRowsHeight = Math.max(0, fileHeight - headerRegion - fileAnnotationHeight - paddingBottom);
		const hasFileAnnotations = includesFileAnnotations(this.lineAnnotations);
		const fileAnnotationTop = fileTop + headerRegion;
		const measuredFileAnnotationVisible = fileAnnotationHeight > 0 && hasFileAnnotations && fileAnnotationTop < bottom && fileAnnotationTop + fileAnnotationHeight > top;
		if (fileTop < top - fileHeight || fileTop > bottom) return {
			startingLine: 0,
			totalLines: 0,
			bufferBefore: 0,
			bufferAfter: fileHeight - headerRegion - paddingBottom
		};
		if (lineCount <= hunkLineCount) return {
			startingLine: 0,
			totalLines: hunkLineCount,
			bufferBefore: 0,
			bufferAfter: 0
		};
		const estimatedTargetLines = Math.ceil(Math.max(bottom - top, 0) / lineHeight);
		const totalLines = Math.ceil(estimatedTargetLines / hunkLineCount) * hunkLineCount + hunkLineCount;
		const totalHunks = totalLines / hunkLineCount;
		const viewportCenter = (top + bottom) / 2;
		if (overflow === "scroll" && !this.hasLineAnnotations()) {
			const sourceRowsTop = fileTop + codeRegionTop;
			const sourceRowsBottom = sourceRowsTop + codeRowsHeight;
			if (!measuredFileAnnotationVisible && !(sourceRowsTop < bottom && sourceRowsBottom > top)) return {
				startingLine: 0,
				totalLines: 0,
				bufferBefore: 0,
				bufferAfter: fileHeight - headerRegion - paddingBottom
			};
			const centerLine = Math.floor(measuredFileAnnotationVisible && viewportCenter < fileTop + codeRegionTop ? 0 : (viewportCenter - (fileTop + codeRegionTop)) / lineHeight);
			const idealStartHunk = Math.floor(centerLine / hunkLineCount) - Math.floor(totalHunks / 2);
			const totalHunksInFile = Math.ceil(lineCount / hunkLineCount);
			const startingLine = Math.max(0, Math.min(idealStartHunk, totalHunksInFile)) * hunkLineCount;
			const clampedTotalLines = idealStartHunk < 0 ? totalLines + idealStartHunk * hunkLineCount : totalLines;
			const bufferBefore = startingLine === 0 ? 0 : fileAnnotationHeight + startingLine * lineHeight;
			const renderedLines = Math.min(clampedTotalLines, lineCount - startingLine);
			return {
				startingLine,
				totalLines: clampedTotalLines,
				bufferBefore,
				bufferAfter: Math.max(0, (lineCount - startingLine - renderedLines) * lineHeight)
			};
		}
		const overflowHunks = totalHunks;
		const hunkOffsets = [];
		const checkpoint = this.getLayoutCheckpointBeforeTop(Math.max(0, top - fileTop - totalLines * lineHeight * 2), hunkLineCount);
		let absoluteLineTop = fileTop + (checkpoint?.top ?? codeRegionTop);
		let currentLine = checkpoint?.lineIndex ?? 0;
		let firstVisibleHunk;
		let centerHunk;
		let overflowCounter;
		const startingLineIndex = checkpoint?.lineIndex ?? 0;
		for (let lineIndex = startingLineIndex; lineIndex < lineCount; lineIndex++) {
			const isAtHunkBoundary = currentLine % hunkLineCount === 0;
			const currentHunk = Math.floor(currentLine / hunkLineCount);
			if (isAtHunkBoundary) {
				hunkOffsets[currentHunk] = absoluteLineTop - (fileTop + codeRegionTop);
				if (overflowCounter != null) {
					if (overflowCounter <= 0) break;
					overflowCounter--;
				}
			}
			const lineHeight = this.getLineHeight(lineIndex, false);
			if (absoluteLineTop > top - lineHeight && absoluteLineTop < bottom) firstVisibleHunk ??= currentHunk;
			if (absoluteLineTop + lineHeight > viewportCenter) centerHunk ??= currentHunk;
			if (overflowCounter == null && absoluteLineTop >= bottom && isAtHunkBoundary) overflowCounter = overflowHunks;
			currentLine++;
			absoluteLineTop += lineHeight;
		}
		if (firstVisibleHunk == null) if (measuredFileAnnotationVisible) {
			firstVisibleHunk = 0;
			centerHunk = 0;
		} else return {
			startingLine: 0,
			totalLines: 0,
			bufferBefore: 0,
			bufferAfter: fileHeight - headerRegion - paddingBottom
		};
		centerHunk ??= firstVisibleHunk;
		const idealStartHunk = Math.round(centerHunk - totalHunks / 2);
		const maxStartHunk = Math.max(0, Math.ceil(lineCount / hunkLineCount) - totalHunks);
		const startHunk = Math.max(0, Math.min(idealStartHunk, maxStartHunk));
		const startingLine = startHunk * hunkLineCount;
		const clampedTotalLines = idealStartHunk < 0 ? totalLines + idealStartHunk * hunkLineCount : totalLines;
		const codeBufferBefore = hunkOffsets[startHunk] ?? 0;
		const bufferBefore = startingLine === 0 ? 0 : fileAnnotationHeight + codeBufferBefore;
		const finalHunkIndex = startHunk + clampedTotalLines / hunkLineCount;
		const bufferAfter = finalHunkIndex < hunkOffsets.length ? codeRowsHeight - hunkOffsets[finalHunkIndex] : codeRowsHeight - (absoluteLineTop - fileTop - codeRegionTop);
		return {
			startingLine,
			totalLines: clampedTotalLines,
			bufferBefore,
			bufferAfter: Math.max(0, bufferAfter)
		};
	}
};
function measureFileAnnotationHeight$1(content) {
	let height;
	for (const child of content.children) {
		if (!(child instanceof HTMLElement)) continue;
		if (child.dataset.lineAnnotation !== FILE_ANNOTATION_DOM_KEY) continue;
		height = Math.max(height ?? 0, child.getBoundingClientRect().height);
	}
	return height;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areDiffTargetsEqual.js
function areDiffTargetsEqual(diffA, diffB) {
	return diffA === diffB || diffA?.cacheKey != null && diffA.cacheKey === diffB?.cacheKey;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/cloneFileDiffMetadata.js
function cloneFileDiffMetadata(fileDiff) {
	return {
		...fileDiff,
		hunks: fileDiff.hunks.map((hunk) => ({
			...hunk,
			hunkContent: hunk.hunkContent.map((content) => ({ ...content }))
		})),
		deletionLines: [...fileDiff.deletionLines],
		additionLines: [...fileDiff.additionLines]
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/splitFileContents.js
/**
* Splits file contents into lines using the same logic as diff parsing.
* - Preserves trailing newlines on each line
*
* @param contents - The raw file contents string
* @returns Array of lines with newlines preserved
*/
function splitFileContents(contents) {
	return contents !== "" ? contents.split(SPLIT_WITH_NEWLINES) : [];
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/hydratePartialDiff.js
/**
* Hydrates a partial diff in place with full file line arrays.
*/
function hydratePartialDiff(type, fileDiff, files) {
	const targetFileDiff = type === "clone" ? cloneFileDiffMetadata(fileDiff) : fileDiff;
	if (!targetFileDiff.isPartial) throw new Error("hydratePartialDiff: fileDiff must be partial");
	switch (targetFileDiff.type) {
		case "change":
		case "rename-changed": return hydrateTwoSidedFileDiff(targetFileDiff, requireOldFile(targetFileDiff, files), requireNewFile(targetFileDiff, files));
		case "rename-pure": {
			const newFile = requireNewFile(targetFileDiff, files);
			requireMissingOldFile(targetFileDiff, files);
			const lines = splitFileContents(newFile.contents);
			targetFileDiff.isPartial = false;
			targetFileDiff.deletionLines = lines;
			targetFileDiff.additionLines = lines;
			setHydratedCacheKey(targetFileDiff, null, newFile);
			return targetFileDiff;
		}
	}
	throw new Error(`hydratePartialDiff: ${targetFileDiff.type} diffs cannot be hydrated from loaded files`);
}
function hydrateTwoSidedFileDiff(fileDiff, oldFile, newFile) {
	const deletionLines = splitFileContents(oldFile.contents);
	const additionLines = splitFileContents(newFile.contents);
	const { hunks, splitLineCount, unifiedLineCount } = hydrateHunks(fileDiff.hunks, additionLines.length);
	fileDiff.hunks = hunks;
	fileDiff.splitLineCount = splitLineCount;
	fileDiff.unifiedLineCount = unifiedLineCount;
	fileDiff.isPartial = false;
	fileDiff.deletionLines = deletionLines;
	fileDiff.additionLines = additionLines;
	setHydratedCacheKey(fileDiff, oldFile, newFile);
	return fileDiff;
}
function hydrateHunks(hunks, totalAdditionLines) {
	let splitLineCount = 0;
	let unifiedLineCount = 0;
	let lastHunkAdditionEnd = 0;
	const hydratedHunks = [];
	for (const hunk of hunks) {
		const additionLineIndex = Math.max(hunk.additionStart - 1, 0);
		const deletionLineIndex = Math.max(hunk.deletionStart - 1, 0);
		let contentAdditionLineIndex = additionLineIndex;
		let contentDeletionLineIndex = deletionLineIndex;
		let hunkAdditionLines = 0;
		let hunkDeletionLines = 0;
		let hunkSplitLineCount = 0;
		let hunkUnifiedLineCount = 0;
		const hunkContent = [];
		for (const content of hunk.hunkContent) {
			if (content.type === "context") {
				hunkContent.push({
					...content,
					additionLineIndex: contentAdditionLineIndex,
					deletionLineIndex: contentDeletionLineIndex
				});
				contentAdditionLineIndex += content.lines;
				contentDeletionLineIndex += content.lines;
				hunkSplitLineCount += content.lines;
				hunkUnifiedLineCount += content.lines;
				continue;
			}
			hunkContent.push({
				...content,
				additionLineIndex: contentAdditionLineIndex,
				deletionLineIndex: contentDeletionLineIndex
			});
			contentAdditionLineIndex += content.additions;
			contentDeletionLineIndex += content.deletions;
			hunkAdditionLines += content.additions;
			hunkDeletionLines += content.deletions;
			hunkSplitLineCount += Math.max(content.additions, content.deletions);
			hunkUnifiedLineCount += content.additions + content.deletions;
		}
		const collapsedBefore = Math.max(getHunkSideStartBoundary(hunk.additionStart, hunk.additionCount) - lastHunkAdditionEnd, 0);
		hydratedHunks.push({
			...hunk,
			collapsedBefore,
			additionLineIndex,
			deletionLineIndex,
			additionLines: hunkAdditionLines,
			deletionLines: hunkDeletionLines,
			hunkContent,
			splitLineStart: splitLineCount + collapsedBefore,
			unifiedLineStart: unifiedLineCount + collapsedBefore,
			splitLineCount: hunkSplitLineCount,
			unifiedLineCount: hunkUnifiedLineCount
		});
		splitLineCount += collapsedBefore + hunkSplitLineCount;
		unifiedLineCount += collapsedBefore + hunkUnifiedLineCount;
		lastHunkAdditionEnd = getHunkSideEndBoundary(hunk.additionStart, hunk.additionCount);
	}
	if (hydratedHunks.length > 0) {
		const lastHunk = hydratedHunks[hydratedHunks.length - 1];
		const lastHunkEnd = getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount);
		const collapsedAfter = Math.max(totalAdditionLines - lastHunkEnd, 0);
		splitLineCount += collapsedAfter;
		unifiedLineCount += collapsedAfter;
	}
	return {
		hunks: hydratedHunks,
		splitLineCount,
		unifiedLineCount
	};
}
function requireOldFile(fileDiff, files) {
	if (files.oldFile == null) throw new Error(`hydratePartialDiff: ${fileDiff.type} diff for ${fileDiff.name} requires oldFile`);
	return files.oldFile;
}
function requireNewFile(fileDiff, files) {
	if (files.newFile == null) throw new Error(`hydratePartialDiff: ${fileDiff.type} diff for ${fileDiff.name} requires newFile`);
	return files.newFile;
}
function requireMissingOldFile(fileDiff, files) {
	if (files.oldFile !== null) throw new Error(`hydratePartialDiff: ${fileDiff.type} diff for ${fileDiff.name} requires oldFile to be null`);
}
function getHydratedCacheKey(fileDiff, oldFile, newFile) {
	if (fileDiff.cacheKey != null) return `${fileDiff.cacheKey}:hydrated`;
	return getLoadedFileCacheKey(oldFile, newFile);
}
function setHydratedCacheKey(fileDiff, oldFile, newFile) {
	const cacheKey = getHydratedCacheKey(fileDiff, oldFile, newFile);
	if (cacheKey == null) {
		delete fileDiff.cacheKey;
		return;
	}
	fileDiff.cacheKey = cacheKey;
}
function getLoadedFileCacheKey(oldFile, newFile) {
	if (oldFile != null && newFile != null) return oldFile.cacheKey != null && newFile.cacheKey != null ? `${oldFile.cacheKey}:${newFile.cacheKey}` : void 0;
	return oldFile?.cacheKey ?? newFile?.cacheKey;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/managers/ScrollSyncManager.js
var ScrollSyncManager = class {
	isDeletionsScrolling = false;
	isAdditionsScrolling = false;
	timeoutId = -1;
	codeDeletions;
	codeAdditions;
	enabled = false;
	cleanUp() {
		if (!this.enabled) return;
		this.codeDeletions?.removeEventListener("scroll", this.handleDeletionsScroll);
		this.codeAdditions?.removeEventListener("scroll", this.handleAdditionsScroll);
		clearTimeout(this.timeoutId);
		this.codeDeletions = void 0;
		this.codeAdditions = void 0;
		this.enabled = false;
	}
	setup(pre, codeDeletions, codeAdditions) {
		if (codeDeletions == null || codeAdditions == null) for (const element of pre.children ?? []) {
			if (!(element instanceof HTMLElement)) continue;
			if ("deletions" in element.dataset) codeDeletions = element;
			else if ("additions" in element.dataset) codeAdditions = element;
		}
		if (codeAdditions == null || codeDeletions == null) {
			this.cleanUp();
			return;
		}
		if (this.codeDeletions !== codeDeletions) {
			this.codeDeletions?.removeEventListener("scroll", this.handleDeletionsScroll);
			this.codeDeletions = codeDeletions;
			codeDeletions.addEventListener("scroll", this.handleDeletionsScroll, { passive: true });
		}
		if (this.codeAdditions !== codeAdditions) {
			this.codeAdditions?.removeEventListener("scroll", this.handleAdditionsScroll);
			this.codeAdditions = codeAdditions;
			codeAdditions.addEventListener("scroll", this.handleAdditionsScroll, { passive: true });
		}
		this.enabled = true;
	}
	handleDeletionsScroll = () => {
		if (this.isAdditionsScrolling) return;
		this.isDeletionsScrolling = true;
		clearTimeout(this.timeoutId);
		this.timeoutId = setTimeout(() => {
			this.isDeletionsScrolling = false;
		}, 300);
		this.codeAdditions?.scrollTo({ left: this.codeDeletions?.scrollLeft });
	};
	handleAdditionsScroll = () => {
		if (this.isDeletionsScrolling) return;
		this.isAdditionsScrolling = true;
		clearTimeout(this.timeoutId);
		this.timeoutId = setTimeout(() => {
			this.isAdditionsScrolling = false;
		}, 300);
		this.codeDeletions?.scrollTo({ left: this.codeAdditions?.scrollLeft });
	};
};
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areDiffRenderOptionsEqual.js
function areDiffRenderOptionsEqual(optionsA, optionsB) {
	return areThemesEqual(optionsA.theme, optionsB.theme) && optionsA.useTokenTransformer === optionsB.useTokenTransformer && optionsA.tokenizeMaxLineLength === optionsB.tokenizeMaxLineLength && optionsA.lineDiffType === optionsB.lineDiffType && optionsA.maxLineDiffLength === optionsB.maxLineDiffLength;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createEmptyRowBuffer.js
function createEmptyRowBuffer(size) {
	return createHastElement({
		tagName: "div",
		properties: {
			"data-content-buffer": "",
			"data-buffer-size": size,
			style: `grid-row: span ${size};min-height:calc(${size} * 1lh)`
		}
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createNoNewlineElement.js
function createNoNewlineElement(type) {
	return createHastElement({
		tagName: "div",
		children: [createHastElement({
			tagName: "span",
			children: [createTextNodeElement("No newline at end of file")]
		})],
		properties: {
			"data-no-newline": "",
			"data-line-type": type,
			"data-column-content": ""
		}
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createSeparator.js
function createExpandButton(type) {
	return createHastElement({
		tagName: "div",
		children: [createIconElement({
			name: type === "both" ? "diffs-icon-expand-all" : "diffs-icon-expand",
			properties: { "data-icon": "" }
		})],
		properties: {
			role: "button",
			"data-expand-button": "",
			"data-expand-both": type === "both" ? "" : void 0,
			"data-expand-up": type === "up" ? "" : void 0,
			"data-expand-down": type === "down" ? "" : void 0
		}
	});
}
function createSeparator({ type, content, expandIndex, chunked = false, slotName, isFirstHunk, isLastHunk }) {
	let buttonCount = 0;
	const children = [];
	if (type === "metadata" && content != null) children.push(createHastElement({
		tagName: "div",
		children: [createTextNodeElement(content)],
		properties: { "data-separator-wrapper": "" }
	}));
	if ((type === "line-info" || type === "line-info-basic") && content != null) {
		const contentChildren = [];
		if (expandIndex != null) if (!chunked) {
			contentChildren.push(createExpandButton(!isFirstHunk && !isLastHunk ? "both" : isFirstHunk ? "down" : "up"));
			buttonCount++;
		} else {
			if (!isFirstHunk) {
				contentChildren.push(createExpandButton("up"));
				buttonCount++;
			}
			if (!isLastHunk) {
				contentChildren.push(createExpandButton("down"));
				buttonCount++;
			}
		}
		contentChildren.push(createHastElement({
			tagName: "div",
			children: [createHastElement({
				tagName: "span",
				children: [createTextNodeElement(content)],
				properties: { "data-unmodified-lines": "" }
			})],
			properties: { "data-separator-content": "" }
		}));
		if (chunked && expandIndex != null) contentChildren.push(createHastElement({
			tagName: "div",
			children: [createTextNodeElement("Expand all")],
			properties: {
				role: "button",
				"data-expand-button": "",
				"data-expand-all-button": ""
			}
		}));
		children.push(createHastElement({
			tagName: "div",
			children: contentChildren,
			properties: {
				"data-separator-wrapper": "",
				"data-separator-multi-button": buttonCount > 1 ? "" : void 0
			}
		}));
	}
	if (type === "custom" && slotName != null) children.push(createHastElement({
		tagName: "slot",
		properties: { name: slotName }
	}));
	return createHastElement({
		tagName: "div",
		children,
		properties: {
			"data-separator": children.length === 0 ? "simple" : type,
			"data-expand-index": expandIndex,
			"data-separator-first": isFirstHunk ? "" : void 0,
			"data-separator-last": isLastHunk ? "" : void 0
		}
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getHunkSeparatorSlotName.js
function getHunkSeparatorSlotName(type, hunkIndex) {
	return `hunk-separator-${type}-${hunkIndex}`;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getTotalLineCountFromHunks.js
function getTotalLineCountFromHunks(hunks) {
	const lastHunk = hunks.at(-1);
	if (lastHunk == null) return 0;
	return Math.max(getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount), getHunkSideEndBoundary(lastHunk.deletionStart, lastHunk.deletionCount));
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/isDefaultRenderRange.js
function isDefaultRenderRange(renderRange) {
	return renderRange.startingLine === 0 && renderRange.totalLines === Infinity && renderRange.bufferBefore === 0 && renderRange.bufferAfter === 0;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/parseDiffDecorations.js
function createDiffSpanDecoration({ line, spanStart, spanLength }) {
	return {
		start: {
			line,
			character: spanStart
		},
		end: {
			line,
			character: spanStart + spanLength
		},
		properties: { "data-diff-span": "" },
		alwaysWrap: true
	};
}
function pushOrJoinSpan({ item, arr, enableJoin, isNeutral = false, isLastItem = false }) {
	const lastItem = arr[arr.length - 1];
	if (lastItem == null || isLastItem || !enableJoin) {
		arr.push([isNeutral ? 0 : 1, item.value]);
		return;
	}
	const isLastItemNeutral = lastItem[0] === 0;
	if (isNeutral === isLastItemNeutral || isNeutral && item.value.length === 1 && !isLastItemNeutral) {
		lastItem[1] += item.value;
		return;
	}
	arr.push([isNeutral ? 0 : 1, item.value]);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/virtualDiffLayout.js
/** One-based new-file line range covered by a hunk, as `[start, end)`. */
function getHunkAdditionLineRange(hunk) {
	return [getHunkSideStartBoundary(hunk.additionStart, hunk.additionCount) + 1, getHunkSideEndBoundary(hunk.additionStart, hunk.additionCount) + 1];
}
function getExpandedRegion({ isPartial, rangeSize, expandedHunks, hunkIndex, collapsedContextThreshold }) {
	const normalizedRangeSize = Math.max(rangeSize, 0);
	if (normalizedRangeSize === 0 || isPartial) return {
		fromStart: 0,
		fromEnd: 0,
		rangeSize: normalizedRangeSize,
		collapsedLines: normalizedRangeSize,
		renderAll: false
	};
	if (expandedHunks === true || normalizedRangeSize <= collapsedContextThreshold) return {
		fromStart: normalizedRangeSize,
		fromEnd: 0,
		rangeSize: normalizedRangeSize,
		collapsedLines: 0,
		renderAll: true
	};
	const region = expandedHunks?.get(hunkIndex);
	const fromStart = Math.min(Math.max(region?.fromStart ?? 0, 0), normalizedRangeSize);
	const fromEnd = Math.min(Math.max(region?.fromEnd ?? 0, 0), normalizedRangeSize);
	const expandedCount = fromStart + fromEnd;
	const renderAll = expandedCount >= normalizedRangeSize;
	return {
		fromStart: renderAll ? normalizedRangeSize : fromStart,
		fromEnd: renderAll ? 0 : fromEnd,
		rangeSize: normalizedRangeSize,
		collapsedLines: Math.max(normalizedRangeSize - expandedCount, 0),
		renderAll
	};
}
function hasTrailingContextMismatch(fileDiff) {
	const lastHunk = fileDiff.hunks[fileDiff.hunks.length - 1];
	if (lastHunk == null || fileDiff.isPartial || fileDiff.additionLines.length === 0 || fileDiff.deletionLines.length === 0) return false;
	const additionRemaining = fileDiff.additionLines.length - getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount);
	const deletionRemaining = fileDiff.deletionLines.length - getHunkSideEndBoundary(lastHunk.deletionStart, lastHunk.deletionCount);
	if (additionRemaining <= 0 && deletionRemaining <= 0) return false;
	return additionRemaining !== deletionRemaining;
}
function getTrailingContextRangeSize({ fileDiff, errorPrefix }) {
	const lastHunk = fileDiff.hunks[fileDiff.hunks.length - 1];
	if (lastHunk == null || fileDiff.isPartial || fileDiff.additionLines.length === 0 || fileDiff.deletionLines.length === 0) return 0;
	const additionRemaining = fileDiff.additionLines.length - getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount);
	const deletionRemaining = fileDiff.deletionLines.length - getHunkSideEndBoundary(lastHunk.deletionStart, lastHunk.deletionCount);
	if (additionRemaining <= 0 && deletionRemaining <= 0) return 0;
	if (additionRemaining !== deletionRemaining) throw new Error(`${errorPrefix}: trailing context mismatch (additions=${additionRemaining}, deletions=${deletionRemaining}) for ${fileDiff.name}`);
	return Math.min(additionRemaining, deletionRemaining);
}
function getTrailingExpandedRegion({ fileDiff, hunkIndex, expandedHunks, collapsedContextThreshold, errorPrefix }) {
	if (hunkIndex !== fileDiff.hunks.length - 1) return;
	const trailingRangeSize = getTrailingContextRangeSize({
		fileDiff,
		errorPrefix
	});
	if (trailingRangeSize <= 0) return;
	if (expandedHunks === true || trailingRangeSize <= collapsedContextThreshold) return {
		fromStart: trailingRangeSize,
		fromEnd: 0,
		rangeSize: trailingRangeSize,
		collapsedLines: 0,
		renderAll: true
	};
	const region = expandedHunks?.get(fileDiff.hunks.length);
	const fromStart = Math.min(Math.max(region?.fromStart ?? 0, 0), trailingRangeSize);
	return {
		fromStart,
		fromEnd: 0,
		rangeSize: trailingRangeSize,
		collapsedLines: trailingRangeSize - fromStart,
		renderAll: fromStart >= trailingRangeSize
	};
}
/**
* Whether a one-based new-file line currently has (or will have on scroll) a
* rendered row under the given expansion state — the editor-facing
* visibility oracle. False only for lines hidden inside a collapsed
* unchanged region; lines outside the diff's modeled range report true so
* callers keep their existing missing-row handling. Computed from the same
* inputs as `iterateOverDiff` so layout math and the oracle cannot diverge.
*/
function isAdditionLineRenderable({ fileDiff, lineNumber, expandedHunks, collapsedContextThreshold }) {
	if (expandedHunks === true || fileDiff.isPartial) return true;
	for (const [hunkIndex, hunk] of fileDiff.hunks.entries()) {
		const [hunkStart, hunkEnd] = getHunkAdditionLineRange(hunk);
		if (lineNumber < hunkStart) {
			const region = getExpandedRegion({
				isPartial: fileDiff.isPartial,
				rangeSize: hunk.collapsedBefore,
				expandedHunks,
				hunkIndex,
				collapsedContextThreshold
			});
			const gapStart = hunkStart - region.rangeSize;
			return region.renderAll || lineNumber < gapStart + region.fromStart || lineNumber >= hunkStart - region.fromEnd;
		}
		if (lineNumber < hunkEnd) return true;
	}
	const trailingRegion = getTrailingExpandedRegion({
		fileDiff,
		hunkIndex: fileDiff.hunks.length - 1,
		expandedHunks,
		collapsedContextThreshold,
		errorPrefix: "isAdditionLineRenderable"
	});
	if (trailingRegion == null || trailingRegion.renderAll) return true;
	const lastHunk = fileDiff.hunks[fileDiff.hunks.length - 1];
	const [, trailingStart] = getHunkAdditionLineRange(lastHunk);
	return lineNumber < trailingStart + trailingRegion.fromStart || lineNumber >= trailingStart + trailingRegion.rangeSize;
}
/**
* The nearest renderable new-file line at or beyond `lineNumber` in the
* given direction (one-based), or undefined when every line that way is
* hidden inside collapsed regions. Sequential caret motion uses this to skip
* over collapsed regions like code folds; it walks the hunk metadata once
* instead of probing line by line across a gap.
*/
function getNearestRenderableAdditionLine({ fileDiff, lineNumber, direction, expandedHunks, collapsedContextThreshold }) {
	if (expandedHunks === true || fileDiff.isPartial) return lineNumber;
	const ranges = [];
	let modeledEnd = 1;
	for (const [hunkIndex, hunk] of fileDiff.hunks.entries()) {
		const [hunkStart, hunkEnd] = getHunkAdditionLineRange(hunk);
		const region = getExpandedRegion({
			isPartial: fileDiff.isPartial,
			rangeSize: hunk.collapsedBefore,
			expandedHunks,
			hunkIndex,
			collapsedContextThreshold
		});
		const gapStart = hunkStart - region.rangeSize;
		if (region.renderAll) ranges.push([gapStart, hunkStart]);
		else {
			if (region.fromStart > 0) ranges.push([gapStart, gapStart + region.fromStart]);
			if (region.fromEnd > 0) ranges.push([hunkStart - region.fromEnd, hunkStart]);
		}
		ranges.push([hunkStart, hunkEnd]);
		modeledEnd = hunkEnd;
	}
	const trailingRegion = getTrailingExpandedRegion({
		fileDiff,
		hunkIndex: fileDiff.hunks.length - 1,
		expandedHunks,
		collapsedContextThreshold,
		errorPrefix: "getNearestRenderableAdditionLine"
	});
	if (trailingRegion != null) {
		const trailingStart = modeledEnd;
		modeledEnd = trailingStart + trailingRegion.rangeSize;
		if (trailingRegion.renderAll) ranges.push([trailingStart, modeledEnd]);
		else if (trailingRegion.fromStart > 0) ranges.push([trailingStart, trailingStart + trailingRegion.fromStart]);
	}
	if (lineNumber >= modeledEnd) return lineNumber;
	if (direction === "down") {
		for (const [start, end] of ranges) if (end > lineNumber) return Math.max(start, lineNumber);
		return;
	}
	for (let index = ranges.length - 1; index >= 0; index--) {
		const [start, end] = ranges[index];
		if (start <= lineNumber) return Math.min(end - 1, lineNumber);
	}
}
function getHunkSeparatorHeight({ type, metrics }) {
	return metrics.hunkSeparatorHeight ?? getDefaultHunkSeparatorHeight(type);
}
function getHunkSeparatorGap({ type, metrics }) {
	return type === "simple" || type === "metadata" || type === "line-info-basic" ? 0 : metrics.spacing;
}
function hasLeadingHunkSeparator({ type, hunkIndex, hunkSpecs }) {
	switch (type) {
		case "simple": return hunkIndex > 0;
		case "metadata": return hunkSpecs != null;
		case "line-info":
		case "line-info-basic":
		case "custom": return true;
	}
}
function hasTrailingHunkSeparator(type) {
	return type !== "simple" && type !== "metadata";
}
function getLeadingHunkSeparatorLayout({ type, metrics, hunkIndex, hunkSpecs }) {
	if (!hasLeadingHunkSeparator({
		type,
		hunkIndex,
		hunkSpecs
	})) return;
	const height = getHunkSeparatorHeight({
		type,
		metrics
	});
	const gap = getHunkSeparatorGap({
		type,
		metrics
	});
	const gapBefore = hunkIndex > 0 ? gap : 0;
	const gapAfter = gap;
	return {
		height,
		gapBefore,
		gapAfter,
		totalHeight: gapBefore + height + gapAfter
	};
}
function getTrailingHunkSeparatorLayout({ type, metrics }) {
	if (!hasTrailingHunkSeparator(type)) return;
	const height = getHunkSeparatorHeight({
		type,
		metrics
	});
	const gapBefore = getHunkSeparatorGap({
		type,
		metrics
	});
	return {
		height,
		gapBefore,
		gapAfter: 0,
		totalHeight: gapBefore + height
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/iterateOverDiff.js
function iterateOverDiff({ diff, diffStyle, startingLine = 0, totalLines = Infinity, expandedHunks, collapsedContextThreshold = 1, callback }) {
	const iterationStart = getIterationStartState({
		diff,
		diffStyle,
		startingLine,
		expandedHunks,
		collapsedContextThreshold
	});
	const state = {
		viewportStart: startingLine,
		viewportEnd: startingLine + totalLines,
		isWindowedHighlight: startingLine > 0 || totalLines < Infinity,
		splitCount: iterationStart.splitCount,
		unifiedCount: iterationStart.unifiedCount,
		finalHunkIndex: diff.hunks.length - 1,
		shouldBreak() {
			if (!state.isWindowedHighlight) return false;
			const breakUnified = state.unifiedCount >= startingLine + totalLines;
			const breakSplit = state.splitCount >= startingLine + totalLines;
			if (diffStyle === "unified") return breakUnified;
			else if (diffStyle === "split") return breakSplit;
			else return breakUnified && breakSplit;
		},
		shouldSkip(unifiedCount, splitCount) {
			if (!state.isWindowedHighlight) return false;
			const skipUnified = unifiedCount > 0 && state.unifiedCount + unifiedCount <= startingLine;
			const skipSplit = splitCount > 0 && state.splitCount + splitCount <= startingLine;
			if (diffStyle === "unified") return skipUnified;
			else if (diffStyle === "split") return skipSplit;
			else return skipUnified && skipSplit;
		},
		incrementCounts(unifiedValue, splitValue) {
			if (diffStyle === "unified" || diffStyle === "both") state.unifiedCount += unifiedValue;
			if (diffStyle === "split" || diffStyle === "both") state.splitCount += splitValue;
		},
		isInWindow(unifiedHeight, splitHeight) {
			if (!state.isWindowedHighlight) return true;
			const unifiedInWindow = state.isInUnifiedWindow(unifiedHeight);
			const splitInWindow = state.isInSplitWindow(splitHeight);
			if (diffStyle === "unified") return unifiedInWindow;
			else if (diffStyle === "split") return splitInWindow;
			else return unifiedInWindow || splitInWindow;
		},
		isInUnifiedWindow(unifiedHeight) {
			return !state.isWindowedHighlight || state.unifiedCount >= startingLine - unifiedHeight && state.unifiedCount < startingLine + totalLines;
		},
		isInSplitWindow(splitHeight) {
			return !state.isWindowedHighlight || state.splitCount >= startingLine - splitHeight && state.splitCount < startingLine + totalLines;
		},
		emit(props, silent = false) {
			if (!silent) if (diffStyle === "unified") state.incrementCounts(1, 0);
			else if (diffStyle === "split") state.incrementCounts(0, 1);
			else state.incrementCounts(1, 1);
			return callback(props) ?? false;
		}
	};
	hunkIterator: for (let hunkIndex = iterationStart.hunkIndex; hunkIndex < diff.hunks.length; hunkIndex++) {
		const hunk = diff.hunks[hunkIndex];
		if (hunk == null) throw new Error("iterateOverDiff: invalid hunk index");
		if (state.shouldBreak()) break;
		const deletionBoundary = getHunkSideStartBoundary(hunk.deletionStart, hunk.deletionCount);
		const additionBoundary = getHunkSideStartBoundary(hunk.additionStart, hunk.additionCount);
		const deletionStartIndex = !diff.isPartial && hunk.deletionCount === 0 ? deletionBoundary : hunk.deletionLineIndex;
		const additionStartIndex = !diff.isPartial && hunk.additionCount === 0 ? additionBoundary : hunk.additionLineIndex;
		const leadingRegion = getExpandedRegion({
			isPartial: diff.isPartial,
			rangeSize: hunk.collapsedBefore,
			expandedHunks,
			hunkIndex,
			collapsedContextThreshold
		});
		const trailingRegion = hunkIndex === state.finalHunkIndex ? getTrailingExpandedRegion({
			fileDiff: diff,
			hunkIndex,
			expandedHunks,
			collapsedContextThreshold,
			errorPrefix: "iterateOverDiff"
		}) : void 0;
		const expandedLineCount = leadingRegion.fromStart + leadingRegion.fromEnd;
		function getTrailingCollapsedAfter(unifiedLineIndex, splitLineIndex) {
			if (trailingRegion == null || trailingRegion.collapsedLines <= 0 || trailingRegion.fromStart + trailingRegion.fromEnd > 0) return 0;
			if (diffStyle === "unified") return unifiedLineIndex === hunk.unifiedLineStart + hunk.unifiedLineCount - 1 ? trailingRegion.collapsedLines : 0;
			return splitLineIndex === hunk.splitLineStart + hunk.splitLineCount - 1 ? trailingRegion.collapsedLines : 0;
		}
		let consumedCollapsed = leadingRegion.collapsedLines === 0;
		function consumePendingCollapsed() {
			if (consumedCollapsed) return 0;
			consumedCollapsed = true;
			return leadingRegion.collapsedLines;
		}
		if (!state.shouldSkip(expandedLineCount, expandedLineCount)) {
			let unifiedLineIndex = hunk.unifiedLineStart - leadingRegion.rangeSize;
			let splitLineIndex = hunk.splitLineStart - leadingRegion.rangeSize;
			let deletionLineIndex = deletionStartIndex - leadingRegion.rangeSize;
			let additionLineIndex = additionStartIndex - leadingRegion.rangeSize;
			let deletionLineNumber = deletionBoundary + 1 - leadingRegion.rangeSize;
			let additionLineNumber = additionBoundary + 1 - leadingRegion.rangeSize;
			if (walkContextLines(state, leadingRegion.fromStart, diffStyle, (index) => {
				return state.emit({
					hunkIndex,
					hunk,
					collapsedBefore: 0,
					collapsedAfter: 0,
					type: "context-expanded",
					deletionLine: {
						lineNumber: deletionLineNumber + index,
						lineIndex: deletionLineIndex + index,
						noEOFCR: false,
						unifiedLineIndex: unifiedLineIndex + index,
						splitLineIndex: splitLineIndex + index
					},
					additionLine: {
						unifiedLineIndex: unifiedLineIndex + index,
						splitLineIndex: splitLineIndex + index,
						lineIndex: additionLineIndex + index,
						lineNumber: additionLineNumber + index,
						noEOFCR: false
					}
				});
			})) break hunkIterator;
			unifiedLineIndex = hunk.unifiedLineStart - leadingRegion.fromEnd;
			splitLineIndex = hunk.splitLineStart - leadingRegion.fromEnd;
			deletionLineIndex = deletionStartIndex - leadingRegion.fromEnd;
			additionLineIndex = additionStartIndex - leadingRegion.fromEnd;
			deletionLineNumber = deletionBoundary + 1 - leadingRegion.fromEnd;
			additionLineNumber = additionBoundary + 1 - leadingRegion.fromEnd;
			if (walkContextLines(state, leadingRegion.fromEnd, diffStyle, (index) => {
				return state.emit({
					hunkIndex,
					hunk,
					collapsedBefore: consumePendingCollapsed(),
					collapsedAfter: 0,
					type: "context-expanded",
					deletionLine: {
						lineNumber: deletionLineNumber + index,
						lineIndex: deletionLineIndex + index,
						noEOFCR: false,
						unifiedLineIndex: unifiedLineIndex + index,
						splitLineIndex: splitLineIndex + index
					},
					additionLine: {
						unifiedLineIndex: unifiedLineIndex + index,
						splitLineIndex: splitLineIndex + index,
						lineIndex: additionLineIndex + index,
						lineNumber: additionLineNumber + index,
						noEOFCR: false
					}
				});
			}, () => {
				consumePendingCollapsed();
			})) break hunkIterator;
		} else {
			state.incrementCounts(expandedLineCount, expandedLineCount);
			consumePendingCollapsed();
		}
		let unifiedLineIndex = hunk.unifiedLineStart;
		let splitLineIndex = hunk.splitLineStart;
		let deletionLineIndex = deletionStartIndex;
		let additionLineIndex = additionStartIndex;
		let deletionLineNumber = deletionBoundary + 1;
		let additionLineNumber = additionBoundary + 1;
		const lastContent = hunk.hunkContent.at(-1);
		for (const content of hunk.hunkContent) {
			if (state.shouldBreak()) break hunkIterator;
			const isLastContent = content === lastContent;
			if (content.type === "context") {
				if (!state.shouldSkip(content.lines, content.lines)) {
					if (walkContextLines(state, content.lines, diffStyle, (index) => {
						const isLastLine = isLastContent && index === content.lines - 1;
						const unifiedRowIndex = unifiedLineIndex + index;
						const splitRowIndex = splitLineIndex + index;
						return state.emit({
							hunkIndex,
							hunk,
							collapsedBefore: consumePendingCollapsed(),
							collapsedAfter: getTrailingCollapsedAfter(unifiedRowIndex, splitRowIndex),
							type: "context",
							deletionLine: {
								lineNumber: deletionLineNumber + index,
								lineIndex: deletionLineIndex + index,
								noEOFCR: isLastLine && hunk.noEOFCRDeletions,
								unifiedLineIndex: unifiedRowIndex,
								splitLineIndex: splitRowIndex
							},
							additionLine: {
								unifiedLineIndex: unifiedRowIndex,
								splitLineIndex: splitRowIndex,
								lineIndex: additionLineIndex + index,
								lineNumber: additionLineNumber + index,
								noEOFCR: isLastLine && hunk.noEOFCRAdditions
							}
						});
					}, () => {
						consumePendingCollapsed();
					})) break hunkIterator;
				} else {
					state.incrementCounts(content.lines, content.lines);
					consumePendingCollapsed();
				}
				unifiedLineIndex += content.lines;
				splitLineIndex += content.lines;
				deletionLineIndex += content.lines;
				additionLineIndex += content.lines;
				deletionLineNumber += content.lines;
				additionLineNumber += content.lines;
			} else {
				const splitCount = Math.max(content.deletions, content.additions);
				const unifiedCount = content.deletions + content.additions;
				if (!state.shouldSkip(unifiedCount, splitCount)) {
					const iterationRanges = getChangeIterationRanges(state, content, diffStyle);
					if ((iterationRanges[0]?.[0] ?? 0) > 0) consumePendingCollapsed();
					for (const [rangeStart, rangeEnd] of iterationRanges) for (let index = rangeStart; index < rangeEnd; index++) {
						const collapsedAfter = getTrailingCollapsedAfter(unifiedLineIndex + index, diffStyle === "unified" ? splitLineIndex + (index < content.deletions ? index : index - content.deletions) : splitLineIndex + index);
						if (state.emit(getChangeLineData({
							hunkIndex,
							hunk,
							collapsedBefore: consumePendingCollapsed(),
							collapsedAfter,
							diffStyle,
							index,
							unifiedLineIndex,
							splitLineIndex,
							additionLineIndex,
							deletionLineIndex,
							additionLineNumber,
							deletionLineNumber,
							content,
							isLastContent,
							unifiedCount,
							splitCount
						}), true)) break hunkIterator;
					}
				}
				consumePendingCollapsed();
				state.incrementCounts(unifiedCount, splitCount);
				unifiedLineIndex += unifiedCount;
				splitLineIndex += splitCount;
				deletionLineIndex += content.deletions;
				additionLineIndex += content.additions;
				deletionLineNumber += content.deletions;
				additionLineNumber += content.additions;
			}
		}
		if (trailingRegion != null) {
			const { collapsedLines, fromStart, fromEnd } = trailingRegion;
			const len = fromStart + fromEnd;
			if (walkContextLines(state, len, diffStyle, (index) => {
				const isLastLine = index === len - 1;
				return state.emit({
					hunkIndex: diff.hunks.length,
					hunk: void 0,
					collapsedBefore: 0,
					collapsedAfter: isLastLine ? collapsedLines : 0,
					type: "context-expanded",
					deletionLine: {
						lineNumber: deletionLineNumber + index,
						lineIndex: deletionLineIndex + index,
						noEOFCR: false,
						unifiedLineIndex: unifiedLineIndex + index,
						splitLineIndex: splitLineIndex + index
					},
					additionLine: {
						unifiedLineIndex: unifiedLineIndex + index,
						splitLineIndex: splitLineIndex + index,
						lineIndex: additionLineIndex + index,
						lineNumber: additionLineNumber + index,
						noEOFCR: false
					}
				});
			}, void 0, () => state.shouldBreak())) break hunkIterator;
		}
	}
}
function getIterationStartState({ diff, diffStyle, startingLine, expandedHunks, collapsedContextThreshold }) {
	if (startingLine <= 0 || diffStyle === "both") return {
		hunkIndex: 0,
		splitCount: 0,
		unifiedCount: 0
	};
	const prefixCounts = getHunkPrefixCounts({
		diff,
		expandedHunks,
		collapsedContextThreshold
	});
	let low = 0;
	let high = diff.hunks.length - 1;
	let result = diff.hunks.length;
	while (low <= high) {
		const mid = low + high >> 1;
		const counts = prefixCounts[mid + 1];
		if (counts == null) throw new Error("iterateOverDiff: invalid hunk prefix index");
		if ((diffStyle === "unified" ? counts.unifiedCount : counts.splitCount) > startingLine) {
			result = mid;
			high = mid - 1;
		} else low = mid + 1;
	}
	if (result >= diff.hunks.length) {
		const counts = prefixCounts[diff.hunks.length];
		if (counts == null) throw new Error("iterateOverDiff: invalid terminal hunk prefix index");
		return {
			hunkIndex: diff.hunks.length,
			splitCount: counts.splitCount,
			unifiedCount: counts.unifiedCount
		};
	}
	const counts = prefixCounts[result];
	if (counts == null) throw new Error("iterateOverDiff: invalid selected hunk prefix index");
	return {
		hunkIndex: result,
		splitCount: counts.splitCount,
		unifiedCount: counts.unifiedCount
	};
}
function getHunkPrefixCounts({ diff, expandedHunks, collapsedContextThreshold }) {
	let splitCount = 0;
	let unifiedCount = 0;
	const finalHunkIndex = diff.hunks.length - 1;
	const prefixCounts = [{
		splitCount: 0,
		unifiedCount: 0
	}];
	for (let index = 0; index < diff.hunks.length; index++) {
		const hunk = diff.hunks[index];
		if (hunk == null) throw new Error("iterateOverDiff: invalid hunk summary index");
		const leadingRegion = getExpandedRegion({
			isPartial: diff.isPartial,
			rangeSize: hunk.collapsedBefore,
			expandedHunks,
			hunkIndex: index,
			collapsedContextThreshold
		});
		const leadingCount = leadingRegion.fromStart + leadingRegion.fromEnd;
		splitCount += leadingCount + hunk.splitLineCount;
		unifiedCount += leadingCount + hunk.unifiedLineCount;
		const trailingRegion = index === finalHunkIndex ? getTrailingExpandedRegion({
			fileDiff: diff,
			hunkIndex: index,
			expandedHunks,
			collapsedContextThreshold,
			errorPrefix: "iterateOverDiff"
		}) : void 0;
		if (trailingRegion != null) {
			const trailingCount = trailingRegion.fromStart + trailingRegion.fromEnd;
			splitCount += trailingCount;
			unifiedCount += trailingCount;
		}
		prefixCounts.push({
			splitCount,
			unifiedCount
		});
	}
	return prefixCounts;
}
function getContextLineIterationBounds(state, count, diffStyle) {
	if (!state.isWindowedHighlight || count <= 0) return [0, count];
	const ranges = [];
	function pushRange(currentCount) {
		const start = Math.max(0, state.viewportStart - currentCount);
		const end = Math.min(count, state.viewportEnd - currentCount);
		if (end > start) ranges.push([start, end]);
	}
	if (diffStyle !== "split") pushRange(state.unifiedCount);
	if (diffStyle !== "unified") pushRange(state.splitCount);
	if (ranges.length === 0) return [0, 0];
	let start = ranges[0][0];
	let end = ranges[0][1];
	for (let index = 1; index < ranges.length; index++) {
		const range = ranges[index];
		start = Math.min(start, range[0]);
		end = Math.max(end, range[1]);
	}
	return [start, end];
}
function walkContextLines(state, count, diffStyle, callback, onSkippedStart, shouldBreak) {
	const [startIndex, endIndex] = getContextLineIterationBounds(state, count, diffStyle);
	if (startIndex > 0) {
		state.incrementCounts(startIndex, startIndex);
		onSkippedStart?.();
	}
	let index = startIndex;
	while (index < count) {
		if (shouldBreak?.() === true) return true;
		if (index >= endIndex) {
			state.incrementCounts(count - index, count - index);
			break;
		}
		if (state.isInWindow(0, 0)) {
			if (callback(index) === true) return true;
		} else state.incrementCounts(1, 1);
		index++;
	}
	return false;
}
function getChangeIterationRanges(state, content, diffStyle) {
	if (!state.isWindowedHighlight) return [[0, diffStyle === "unified" ? content.deletions + content.additions : Math.max(content.deletions, content.additions)]];
	const useUnified = diffStyle !== "split";
	const useSplit = diffStyle !== "unified";
	const iterationSpace = diffStyle === "unified" ? "unified" : "split";
	const iterationRanges = [];
	function getVisibleRange(start, count) {
		if (start + count <= state.viewportStart || start >= state.viewportEnd) return;
		const visibleStart = Math.max(0, state.viewportStart - start);
		const visibleEnd = Math.min(count, state.viewportEnd - start);
		return visibleEnd > visibleStart ? [visibleStart, visibleEnd] : void 0;
	}
	function mapRangeToIteration(range, kind) {
		if (iterationSpace === "split") return range;
		return kind === "additions" ? [range[0] + content.deletions, range[1] + content.deletions] : range;
	}
	function pushRange(range, kind) {
		if (range == null) return;
		const [start, end] = mapRangeToIteration(range, kind);
		if (end > start) iterationRanges.push([start, end]);
	}
	if (useUnified) {
		pushRange(getVisibleRange(state.unifiedCount, content.deletions), "deletions");
		pushRange(getVisibleRange(state.unifiedCount + content.deletions, content.additions), "additions");
	}
	if (useSplit) {
		pushRange(getVisibleRange(state.splitCount, content.deletions), "deletions");
		pushRange(getVisibleRange(state.splitCount, content.additions), "additions");
	}
	if (iterationRanges.length === 0) return iterationRanges;
	iterationRanges.sort((a, b) => a[0] - b[0]);
	const merged = [iterationRanges[0]];
	for (const [start, end] of iterationRanges.slice(1)) {
		const last = merged[merged.length - 1];
		if (start <= last[1]) last[1] = Math.max(last[1], end);
		else merged.push([start, end]);
	}
	return merged;
}
function getChangeLineData({ hunkIndex, hunk, collapsedAfter, collapsedBefore, diffStyle, index, unifiedLineIndex, splitLineIndex, additionLineIndex, deletionLineIndex, additionLineNumber, deletionLineNumber, content, isLastContent, unifiedCount, splitCount }) {
	const unifiedDeletionLineIndex = index < content.deletions ? unifiedLineIndex + index : void 0;
	const unifiedAdditionLineIndex = diffStyle === "unified" ? index >= content.deletions ? unifiedLineIndex + index : void 0 : index < content.additions ? unifiedLineIndex + content.deletions + index : void 0;
	const resolvedSplitLineIndex = diffStyle === "unified" ? splitLineIndex + (index < content.deletions ? index : index - content.deletions) : splitLineIndex + index;
	const deletionLineIndexValue = index < content.deletions ? deletionLineIndex + index : void 0;
	const deletionLineNumberValue = index < content.deletions ? deletionLineNumber + index : void 0;
	const additionLineIndexValue = diffStyle === "unified" ? index >= content.deletions ? additionLineIndex + (index - content.deletions) : void 0 : index < content.additions ? additionLineIndex + index : void 0;
	const additionLineNumberValue = diffStyle === "unified" ? index >= content.deletions ? additionLineNumber + (index - content.deletions) : void 0 : index < content.additions ? additionLineNumber + index : void 0;
	const noEOFCRDeletion = diffStyle === "unified" ? isLastContent && index === content.deletions - 1 && hunk.noEOFCRDeletions : isLastContent && index === splitCount - 1 && hunk.noEOFCRDeletions;
	const noEOFCRAddition = diffStyle === "unified" ? isLastContent && index === unifiedCount - 1 && hunk.noEOFCRAdditions : isLastContent && index === splitCount - 1 && hunk.noEOFCRAdditions;
	const deletionLine = deletionLineIndexValue != null && deletionLineNumberValue != null && unifiedDeletionLineIndex != null ? {
		lineNumber: deletionLineNumberValue,
		lineIndex: deletionLineIndexValue,
		noEOFCR: noEOFCRDeletion,
		unifiedLineIndex: unifiedDeletionLineIndex,
		splitLineIndex: resolvedSplitLineIndex
	} : void 0;
	const additionLine = additionLineIndexValue != null && additionLineNumberValue != null && unifiedAdditionLineIndex != null ? {
		unifiedLineIndex: unifiedAdditionLineIndex,
		splitLineIndex: resolvedSplitLineIndex,
		lineIndex: additionLineIndexValue,
		lineNumber: additionLineNumberValue,
		noEOFCR: noEOFCRAddition
	} : void 0;
	if (deletionLine == null && additionLine != null) return {
		type: "change",
		hunkIndex,
		hunk,
		collapsedAfter,
		collapsedBefore,
		deletionLine: void 0,
		additionLine
	};
	else if (deletionLine != null && additionLine == null) return {
		type: "change",
		hunkIndex,
		hunk,
		collapsedAfter,
		collapsedBefore,
		deletionLine,
		additionLine: void 0
	};
	if (deletionLine == null || additionLine == null) throw new Error("iterateOverDiff: missing change line data");
	return {
		type: "change",
		hunkIndex,
		hunk,
		collapsedAfter,
		collapsedBefore,
		deletionLine,
		additionLine
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/renderDiffWithHighlighter.js
var DEFAULT_PLAIN_TEXT_OPTIONS = { forcePlainText: false };
function renderDiffWithHighlighter(diff, highlighter, options, { forcePlainText, startingLine, totalLines, expandedHunks, collapsedContextThreshold = 1 } = DEFAULT_PLAIN_TEXT_OPTIONS) {
	if (forcePlainText) {
		startingLine ??= 0;
		totalLines ??= Infinity;
	} else {
		startingLine = 0;
		totalLines = Infinity;
	}
	const isWindowedHighlight = startingLine > 0 || totalLines < Infinity;
	const baseThemeType = typeof options.theme === "string" ? highlighter.getTheme(options.theme).type : void 0;
	const themeStyles = getHighlighterThemeStyles({
		theme: options.theme,
		highlighter
	});
	const lineDiffType = forcePlainText && !isWindowedHighlight && (diff.unifiedLineCount > 1e3 || diff.splitLineCount > 1e3) ? "none" : options.lineDiffType;
	const code = {
		deletionLines: [],
		additionLines: []
	};
	const { maxLineDiffLength } = options;
	const shouldGroupAll = !forcePlainText && !diff.isPartial;
	const expandedHunksForIteration = forcePlainText ? expandedHunks : void 0;
	const buckets = /* @__PURE__ */ new Map();
	function getBucketForHunk(hunkIndex) {
		const index = shouldGroupAll ? 0 : hunkIndex;
		const bucket = buckets.get(index) ?? createBucket();
		buckets.set(index, bucket);
		return bucket;
	}
	function appendContent(lineContent, lineIndex, segments, contentWrapper) {
		if (isWindowedHighlight) {
			let segment = segments.at(-1);
			if (segment == null || segment.targetIndex + segment.count !== lineIndex) {
				segment = {
					targetIndex: lineIndex,
					originalOffset: contentWrapper.length,
					count: 0
				};
				segments.push(segment);
			}
			segment.count++;
		}
		contentWrapper.push(lineContent);
	}
	iterateOverDiff({
		diff,
		diffStyle: "both",
		startingLine,
		totalLines,
		expandedHunks: isWindowedHighlight ? expandedHunksForIteration : true,
		collapsedContextThreshold,
		callback: ({ hunkIndex, additionLine, deletionLine, type }) => {
			const bucket = getBucketForHunk(hunkIndex);
			const splitLineIndex = additionLine != null ? additionLine.splitLineIndex : deletionLine.splitLineIndex;
			if (type === "change" && additionLine != null && deletionLine != null) computeLineDiffDecorations({
				additionLine: diff.additionLines[additionLine.lineIndex],
				deletionLine: diff.deletionLines[deletionLine.lineIndex],
				deletionLineIndex: bucket.deletionContent.length,
				additionLineIndex: bucket.additionContent.length,
				deletionDecorations: bucket.deletionDecorations,
				additionDecorations: bucket.additionDecorations,
				lineDiffType,
				maxLineDiffLength
			});
			if (deletionLine != null) {
				appendContent(diff.deletionLines[deletionLine.lineIndex], deletionLine.lineIndex, bucket.deletionSegments, bucket.deletionContent);
				bucket.deletionInfo.push({
					type: type === "change" ? "change-deletion" : type,
					lineNumber: deletionLine.lineNumber,
					altLineNumber: type === "change" ? void 0 : additionLine.lineNumber ?? void 0,
					lineIndex: `${deletionLine.unifiedLineIndex},${splitLineIndex}`
				});
			}
			if (additionLine != null) {
				appendContent(diff.additionLines[additionLine.lineIndex], additionLine.lineIndex, bucket.additionSegments, bucket.additionContent);
				bucket.additionInfo.push({
					type: type === "change" ? "change-addition" : type,
					lineNumber: additionLine.lineNumber,
					altLineNumber: type === "change" ? void 0 : deletionLine.lineNumber ?? void 0,
					lineIndex: `${additionLine.unifiedLineIndex},${splitLineIndex}`
				});
			}
		}
	});
	for (const bucket of buckets.values()) {
		if (bucket.deletionContent.length === 0 && bucket.additionContent.length === 0) continue;
		const deletionFile = {
			name: diff.prevName ?? diff.name,
			contents: bucket.deletionContent.value
		};
		const additionFile = {
			name: diff.name,
			contents: bucket.additionContent.value
		};
		const { deletionLines, additionLines } = renderTwoFiles({
			deletionFile,
			deletionInfo: bucket.deletionInfo,
			deletionDecorations: bucket.deletionDecorations,
			additionFile,
			additionInfo: bucket.additionInfo,
			additionDecorations: bucket.additionDecorations,
			highlighter,
			options,
			languageOverride: forcePlainText ? "text" : diff.lang
		});
		if (shouldGroupAll) {
			code.deletionLines = deletionLines;
			code.additionLines = additionLines;
			continue;
		}
		if (bucket.deletionSegments.length > 0) for (const seg of bucket.deletionSegments) for (let i = 0; i < seg.count; i++) code.deletionLines[seg.targetIndex + i] = deletionLines[seg.originalOffset + i];
		else code.deletionLines.push(...deletionLines);
		if (bucket.additionSegments.length > 0) for (const seg of bucket.additionSegments) for (let i = 0; i < seg.count; i++) code.additionLines[seg.targetIndex + i] = additionLines[seg.originalOffset + i];
		else code.additionLines.push(...additionLines);
	}
	return {
		code,
		themeStyles,
		baseThemeType
	};
}
function computeLineDiffDecorations({ deletionLine, additionLine, deletionLineIndex, additionLineIndex, deletionDecorations, additionDecorations, lineDiffType, maxLineDiffLength }) {
	if (deletionLine == null || additionLine == null || lineDiffType === "none") return;
	deletionLine = cleanLastNewline(deletionLine);
	additionLine = cleanLastNewline(additionLine);
	if (deletionLine.length > maxLineDiffLength || additionLine.length > maxLineDiffLength) return;
	const lineDiff = lineDiffType === "char" ? diffChars(deletionLine, additionLine) : diffWordsWithSpace(deletionLine, additionLine);
	const deletionSpans = [];
	const additionSpans = [];
	const enableJoin = lineDiffType === "word-alt";
	const lastItem = lineDiff.at(-1);
	for (const item of lineDiff) {
		const isLastItem = item === lastItem;
		if (!item.added && !item.removed) {
			pushOrJoinSpan({
				item,
				arr: deletionSpans,
				enableJoin,
				isNeutral: true,
				isLastItem
			});
			pushOrJoinSpan({
				item,
				arr: additionSpans,
				enableJoin,
				isNeutral: true,
				isLastItem
			});
		} else if (item.removed) pushOrJoinSpan({
			item,
			arr: deletionSpans,
			enableJoin,
			isLastItem
		});
		else pushOrJoinSpan({
			item,
			arr: additionSpans,
			enableJoin,
			isLastItem
		});
	}
	let spanIndex = 0;
	for (const span of deletionSpans) {
		if (span[0] === 1) deletionDecorations.push(createDiffSpanDecoration({
			line: deletionLineIndex,
			spanStart: spanIndex,
			spanLength: span[1].length
		}));
		spanIndex += span[1].length;
	}
	spanIndex = 0;
	for (const span of additionSpans) {
		if (span[0] === 1) additionDecorations.push(createDiffSpanDecoration({
			line: additionLineIndex,
			spanStart: spanIndex,
			spanLength: span[1].length
		}));
		spanIndex += span[1].length;
	}
}
function createBucket() {
	return {
		deletionContent: {
			push(value) {
				this.value += value;
				this.length++;
			},
			value: "",
			length: 0
		},
		additionContent: {
			push(value) {
				this.value += value;
				this.length++;
			},
			value: "",
			length: 0
		},
		deletionInfo: [],
		additionInfo: [],
		deletionDecorations: [],
		additionDecorations: [],
		deletionSegments: [],
		additionSegments: []
	};
}
function renderTwoFiles({ deletionFile, additionFile, deletionInfo, additionInfo, highlighter, deletionDecorations, additionDecorations, languageOverride, options: { theme: themeOrThemes = DEFAULT_THEMES, ...options } }) {
	const deletionLang = languageOverride ?? getFiletypeFromFileName(deletionFile.name);
	const additionLang = languageOverride ?? getFiletypeFromFileName(additionFile.name);
	const { state, transformers } = createTransformerWithState(options.useTokenTransformer);
	const hastConfig = (() => {
		return typeof themeOrThemes === "string" ? {
			...options,
			lang: "text",
			theme: themeOrThemes,
			transformers,
			decorations: void 0,
			defaultColor: false,
			cssVariablePrefix: formatCSSVariablePrefix("token"),
			tokenizeTimeLimit: 0
		} : {
			...options,
			lang: "text",
			themes: themeOrThemes,
			transformers,
			decorations: void 0,
			defaultColor: false,
			cssVariablePrefix: formatCSSVariablePrefix("token"),
			tokenizeTimeLimit: 0
		};
	})();
	return {
		deletionLines: (() => {
			if (deletionFile.contents === "") return [];
			hastConfig.lang = deletionLang;
			state.lineInfo = deletionInfo;
			hastConfig.decorations = deletionDecorations;
			return getLineNodes(highlighter.codeToHast(cleanLastNewline(deletionFile.contents), hastConfig));
		})(),
		additionLines: (() => {
			if (additionFile.contents === "") return [];
			hastConfig.lang = additionLang;
			hastConfig.decorations = additionDecorations;
			state.lineInfo = additionInfo;
			return getLineNodes(highlighter.codeToHast(cleanLastNewline(additionFile.contents), hastConfig));
		})()
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/updateDiffHunks.js
/** Rebuilds all hunk metadata from the current deletion/addition line arrays. */
function recomputeDiffHunks(diff, parseDiffOptions) {
	const recomputed = parseDiffFromFile({
		name: diff.prevName ?? diff.name,
		contents: diff.deletionLines.join("")
	}, {
		name: diff.name,
		contents: diff.additionLines.join(""),
		lang: diff.lang
	}, parseDiffOptions);
	return {
		hunks: recomputed.hunks,
		splitLineCount: recomputed.splitLineCount,
		unifiedLineCount: recomputed.unifiedLineCount,
		additionLines: recomputed.additionLines,
		deletionLines: recomputed.deletionLines,
		type: recomputed.type
	};
}
function buildTopAlignedAdditionSentinel(lineCount, deletionContents) {
	const count = Math.max(lineCount, 1);
	let sentinel = Array.from({ length: count }, (_, index) => `${" ".repeat(index + 1)}\n`).join("");
	if (sentinel === deletionContents) sentinel = Array.from({ length: count }, (_, index) => `\u0000${" ".repeat(index)}\n`).join("");
	return sentinel;
}
function hasOnlyBlankAdditionContents(additionLines) {
	for (const line of additionLines) if (line.trim().length > 0) return false;
	return true;
}
function shouldTopAlignAdditionRecompute(diff, additionLines) {
	return additionLines.length > 0 && additionLines.length < diff.deletionLines.length && hasOnlyBlankAdditionContents(additionLines);
}
function recomputeTopAlignedAdditionDiff(diff, additionLines, parseDiffOptions) {
	const deletionContents = diff.deletionLines.join("");
	const additionSentinel = buildTopAlignedAdditionSentinel(additionLines.length, deletionContents);
	const recomputed = parseDiffFromFile({
		name: diff.prevName ?? diff.name,
		contents: deletionContents
	}, {
		name: diff.name,
		contents: additionSentinel,
		lang: diff.lang
	}, parseDiffOptions);
	return {
		hunks: recomputed.hunks,
		splitLineCount: recomputed.splitLineCount,
		unifiedLineCount: recomputed.unifiedLineCount,
		additionLines,
		deletionLines: recomputed.deletionLines,
		type: recomputed.type
	};
}
function recomputeEmptyDocumentDiff(diff, parseDiffOptions) {
	return recomputeTopAlignedAdditionDiff(diff, [""], parseDiffOptions);
}
/** Rebuilds diff hunks after an edit, top-aligning sparse addition sides when needed. */
function recomputeDiffHunksForEdit(diff, parseDiffOptions) {
	if (diff.additionLines.length === 0) return recomputeEmptyDocumentDiff(diff, parseDiffOptions);
	if (shouldTopAlignAdditionRecompute(diff, diff.additionLines)) return recomputeTopAlignedAdditionDiff(diff, diff.additionLines, parseDiffOptions);
	const additionLines = diff.additionLines;
	const recomputed = recomputeDiffHunks(diff, parseDiffOptions);
	preserveTrailingEditorBlankLine(recomputed, additionLines);
	return recomputed;
}
function hasTrailingEditorBlankLine(additionLines) {
	return additionLines.length > 1 && additionLines.at(-1) === "";
}
function preserveTrailingEditorBlankLine(recomputed, additionLines) {
	if (!hasTrailingEditorBlankLine(additionLines)) return;
	const extraLineCount = additionLines.length - recomputed.additionLines.length;
	if (extraLineCount <= 0) return;
	const extraAdditionLineIndex = recomputed.additionLines.length;
	const lastHunk = recomputed.hunks.at(-1);
	if (lastHunk == null) return;
	if (getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount) !== extraAdditionLineIndex) return;
	for (const content of lastHunk.hunkContent) if (content.type === "change" && content.additions < content.deletions && content.additionLineIndex + content.additions === extraAdditionLineIndex) {
		recomputed.additionLines = additionLines;
		content.additions += extraLineCount;
		lastHunk.additionCount += extraLineCount;
		lastHunk.additionLines += extraLineCount;
		recomputeDiffRenderLineCounts(recomputed);
		return;
	}
}
/** Updates hunk metadata after addition lines change; re-parses affected hunks only. */
function updateDiffHunks(diff, changedAdditionLineIndexes, parseDiffOptions) {
	if (diff.isPartial) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
	if (diff.deletionLines.length !== diff.additionLines.length) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
	const changedLines = Array.from(changedAdditionLineIndexes);
	if (changedLines.length === 0) return applyHunkUpdateResult(diff, {
		hunks: diff.hunks,
		splitLineCount: diff.splitLineCount,
		unifiedLineCount: diff.unifiedLineCount,
		type: diff.type
	});
	for (const line of changedLines) {
		const additionLine = diff.additionLines[line];
		const deletionLine = diff.deletionLines[line];
		if (additionLine == null || deletionLine == null) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
		if (cleanLastNewline(additionLine) === cleanLastNewline(deletionLine)) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
	}
	const affectedHunkIndexes = getAffectedHunkIndexes(diff, changedLines);
	if (affectedHunkIndexes.size === 0) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
	for (const hunkIndex of affectedHunkIndexes) if (!reparseHunkRegion(diff, hunkIndex, parseDiffOptions)) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
	recomputeDiffRenderLineCounts(diff);
	if (hasTrailingContextMismatch(diff)) return applyHunkUpdateResult(diff, recomputeDiffHunks(diff, parseDiffOptions));
	return applyHunkUpdateResult(diff, {
		hunks: diff.hunks,
		splitLineCount: diff.splitLineCount,
		unifiedLineCount: diff.unifiedLineCount,
		type: diff.type
	});
}
function applyHunkUpdateResult(diff, result) {
	Object.assign(diff, result);
	return result;
}
function getAffectedHunkIndexes(diff, changedAdditionLineIndexes) {
	const indexes = /* @__PURE__ */ new Set();
	for (const line of changedAdditionLineIndexes) {
		const hunkIndex = findHunkIndexForAdditionLine(diff, line);
		if (hunkIndex == null) return /* @__PURE__ */ new Set();
		indexes.add(hunkIndex);
	}
	return indexes;
}
function findHunkIndexForAdditionLine(diff, line) {
	for (const [hunkIndex, hunk] of diff.hunks.entries()) {
		const end = hunk.additionLineIndex + hunk.additionCount;
		if (line >= hunk.additionLineIndex && line < end) return hunkIndex;
	}
}
function reparseHunkRegion(diff, hunkIndex, parseDiffOptions) {
	const hunk = diff.hunks[hunkIndex];
	if (hunk == null) return false;
	const deletionSlice = diff.deletionLines.slice(hunk.deletionLineIndex, hunk.deletionLineIndex + hunk.deletionCount);
	const additionSlice = diff.additionLines.slice(hunk.additionLineIndex, hunk.additionLineIndex + hunk.additionCount);
	const reparsed = parseDiffFromFile({
		name: diff.prevName ?? diff.name,
		contents: deletionSlice.join("")
	}, {
		name: diff.name,
		contents: additionSlice.join(""),
		lang: diff.lang
	}, {
		...parseDiffOptions,
		context: 0
	});
	const reparsedHunk = reparsed.hunks[0];
	if (reparsedHunk == null || reparsed.hunks.length !== 1) return false;
	applyReparsedHunk(hunk, reparsedHunk);
	syncHunkNoEOFCRFromFullFile(diff, hunkIndex);
	return true;
}
function syncHunkNoEOFCRFromFullFile(diff, hunkIndex) {
	const hunk = diff.hunks[hunkIndex];
	if (hunk == null) return;
	if (!(hunkIndex === diff.hunks.length - 1)) {
		hunk.noEOFCRAdditions = false;
		hunk.noEOFCRDeletions = false;
		return;
	}
	const lastAdditionLine = diff.additionLines.at(-1);
	const lastDeletionLine = diff.deletionLines.at(-1);
	hunk.noEOFCRAdditions = lastAdditionLine != null && lastAdditionLine !== "" && !lastAdditionLine.endsWith("\n");
	hunk.noEOFCRDeletions = lastDeletionLine != null && lastDeletionLine !== "" && !lastDeletionLine.endsWith("\n");
}
function applyReparsedHunk(target, parsed) {
	const additionOffset = target.additionLineIndex;
	const deletionOffset = target.deletionLineIndex;
	target.hunkContent = parsed.hunkContent.map((content) => offsetHunkContent(content, additionOffset, deletionOffset));
	target.additionLineIndex = additionOffset + parsed.additionLineIndex;
	target.additionStart = target.additionStart + parsed.additionLineIndex;
	target.additionCount = parsed.additionCount;
	target.additionLines = parsed.additionLines;
	if (parsed.deletionLineIndex >= 0) {
		target.deletionLineIndex = deletionOffset + parsed.deletionLineIndex;
		target.deletionStart = target.deletionStart + parsed.deletionLineIndex;
	}
	target.deletionCount = parsed.deletionCount;
	target.deletionLines = parsed.deletionLines;
	target.noEOFCRAdditions = parsed.noEOFCRAdditions;
	target.noEOFCRDeletions = parsed.noEOFCRDeletions;
	recomputeHunkRenderLineCounts(target);
}
function offsetHunkContent(content, additionOffset, deletionOffset) {
	return {
		...content,
		additionLineIndex: content.additionLineIndex + additionOffset,
		deletionLineIndex: content.deletionLineIndex + deletionOffset
	};
}
function recomputeHunkRenderLineCounts(hunk) {
	let splitLineCount = 0;
	let unifiedLineCount = 0;
	for (const content of hunk.hunkContent) if (content.type === "context") {
		splitLineCount += content.lines;
		unifiedLineCount += content.lines;
	} else {
		splitLineCount += Math.max(content.additions, content.deletions);
		unifiedLineCount += content.additions + content.deletions;
	}
	hunk.splitLineCount = splitLineCount;
	hunk.unifiedLineCount = unifiedLineCount;
}
function recomputeDiffRenderLineCounts(diff) {
	let splitTotal = 0;
	let unifiedTotal = 0;
	let lastHunkAdditionEnd = 0;
	for (const hunk of diff.hunks) {
		hunk.collapsedBefore = Math.max(getHunkSideStartBoundary(hunk.additionStart, hunk.additionCount) - lastHunkAdditionEnd, 0);
		hunk.splitLineStart = splitTotal + hunk.collapsedBefore;
		hunk.unifiedLineStart = unifiedTotal + hunk.collapsedBefore;
		recomputeHunkRenderLineCounts(hunk);
		splitTotal += hunk.collapsedBefore + hunk.splitLineCount;
		unifiedTotal += hunk.collapsedBefore + hunk.unifiedLineCount;
		lastHunkAdditionEnd = getHunkSideEndBoundary(hunk.additionStart, hunk.additionCount);
	}
	if (diff.hunks.length > 0) {
		const lastHunk = diff.hunks[diff.hunks.length - 1];
		const collapsedAfter = Math.max(diff.additionLines.length - getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount), 0);
		splitTotal += collapsedAfter;
		unifiedTotal += collapsedAfter;
	}
	diff.splitLineCount = splitTotal;
	diff.unifiedLineCount = unifiedTotal;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/editSessionHunks.js
var deletionLineSetCache = /* @__PURE__ */ new WeakMap();
/**
* Drops the editor document's phantom trailing empty line (a document ending
* in a newline exposes one extra empty line the parsed diff never contains)
* so session line arrays compare like parse-derived ones.
*/
function normalizeEditorLines(lines) {
	if (lines.length > 1 && lines[lines.length - 1] === "") return lines.slice(0, -1);
	return lines;
}
/**
* Find the complete old/current divergence core. The old side is immutable
* during an edit session, so this result needs no prior-pass snapshot.
*/
function findDivergenceCore(deletionLines, additionLines) {
	const maxStart = Math.min(deletionLines.length, additionLines.length);
	let start = 0;
	while (start < maxStart && deletionLines[start] === additionLines[start]) start++;
	let deletionEnd = deletionLines.length;
	let additionEnd = additionLines.length;
	while (deletionEnd > start && additionEnd > start && deletionLines[deletionEnd - 1] === additionLines[additionEnd - 1]) {
		deletionEnd--;
		additionEnd--;
	}
	if (start === deletionEnd && start === additionEnd) return;
	return {
		start,
		deletionEnd,
		additionEnd
	};
}
/**
* Rebuild the session skeleton as a pure function of the immutable old lines,
* current new lines, and old-side ranges of the previous regions. One
* canonical parse supplies the same change blocks that session exit will use.
*/
function rebuildSessionHunks(diff, parseDiffOptions) {
	const previousHunks = diff.hunks;
	const editorAdditionLines = diff.additionLines;
	const canonicalAdditionLines = normalizeEditorLines(editorAdditionLines);
	const canonicalDiff = canonicalAdditionLines === editorAdditionLines ? diff : {
		...diff,
		additionLines: canonicalAdditionLines
	};
	const plans = buildRegionPlans(previousHunks, parseCanonicalChangeBlocks(canonicalDiff, parseDiffOptions), diff.deletionLines.length);
	const nextHunks = buildRegionHunks(canonicalDiff, plans);
	diff.additionLines = canonicalAdditionLines;
	diff.hunks = nextHunks;
	diff.editSessionDirty = true;
	finalizeSessionHunks(diff);
	preserveTrailingEditorBlankLine(diff, editorAdditionLines);
	if (!hasRegionOrSplitLayoutChanged(previousHunks, diff.hunks)) return;
	return { regions: plans.map((plan) => plan.previousSpan) };
}
/**
* Keep a cheap content-only path when a same-line-count pass cannot alter the
* canonical blocks. Gap, ambiguous, or multi-region edits rebuild statelessly.
*/
function applySessionChangedLines(diff, changedAdditionLineIndexes, parseDiffOptions, previousAdditionLines) {
	const lines = Array.from(new Set(changedAdditionLineIndexes)).filter((line) => line >= 0 && line < diff.additionLines.length).sort((a, b) => a - b);
	if (lines.length === 0) return;
	const { hunks } = diff;
	let regionIndex;
	let hunkIndex = 0;
	for (const line of lines) {
		while (hunkIndex < hunks.length) {
			const hunk = hunks[hunkIndex];
			if (line < getHunkAdditionStart(hunk) + hunk.additionCount) break;
			hunkIndex++;
		}
		const hunk = hunks[hunkIndex];
		const start = hunk == null ? void 0 : getHunkAdditionStart(hunk);
		if (start == null || line < start || regionIndex != null && regionIndex !== hunkIndex) return rebuildSessionHunks(diff, parseDiffOptions);
		regionIndex = hunkIndex;
	}
	if (regionIndex == null) return;
	if (canRetainCanonicalBlocks(diff, lines, regionIndex, previousAdditionLines, parseDiffOptions)) {
		diff.editSessionDirty = true;
		return;
	}
	return rebuildSessionHunks(diff, parseDiffOptions);
}
function canRetainCanonicalBlocks(diff, changedLines, regionIndex, previousAdditionLines, parseDiffOptions) {
	if (previousAdditionLines == null || parseDiffOptions?.ignoreWhitespace === true || parseDiffOptions?.stripTrailingCr === true) return false;
	const deletionLineSet = getDeletionLineSet(diff);
	const hunk = diff.hunks[regionIndex];
	if (hunk.hunkContent.some(isPureChange)) return false;
	for (const line of changedLines) {
		const previousLine = previousAdditionLines.get(line);
		const additionLine = diff.additionLines[line];
		if (previousLine == null || additionLine == null || deletionLineSet.has(previousLine) || deletionLineSet.has(additionLine)) return false;
		let insideBalancedChange = false;
		for (const content of hunk.hunkContent) if (content.type === "change" && content.additions === content.deletions && line >= content.additionLineIndex && line < content.additionLineIndex + content.additions) {
			insideBalancedChange = true;
			break;
		}
		if (!insideBalancedChange) return false;
	}
	return true;
}
function getDeletionLineSet(diff) {
	const cached = deletionLineSetCache.get(diff);
	if (cached?.lines === diff.deletionLines) return cached.set;
	const set = new Set(diff.deletionLines);
	deletionLineSetCache.set(diff, {
		lines: diff.deletionLines,
		set
	});
	return set;
}
function isPureChange(content) {
	return content?.type === "change" && (content.additions === 0 || content.deletions === 0);
}
/** Preserve expansion at the surviving outer edges of rebuilt old-side gaps. */
function remapExpandedHunksForRegionChange(expandedHunks, change) {
	const remapped = /* @__PURE__ */ new Map();
	const { regions } = change;
	for (let key = 0; key <= regions.length; key++) {
		const previous = regions[key - 1];
		const next = regions[key];
		const fromStartSource = key === 0 ? expandedHunks.get(0) : previous == null ? void 0 : expandedHunks.get(previous.lastIndex + 1);
		const fromEndSource = next == null ? void 0 : expandedHunks.get(next.firstIndex);
		const fromStart = fromStartSource?.fromStart ?? 0;
		const fromEnd = fromEndSource?.fromEnd ?? 0;
		if (fromStart > 0 || fromEnd > 0) remapped.set(key, {
			fromStart,
			fromEnd
		});
	}
	return remapped;
}
/** Snapshot the expanded gap-edge slices before the exit recompute. */
function captureExpansionAnchors(diff, expandedHunks, collapsedContextThreshold) {
	const anchors = [];
	if (diff.isPartial) return anchors;
	for (const [hunkIndex, hunk] of diff.hunks.entries()) {
		const region = getExpandedRegion({
			isPartial: diff.isPartial,
			rangeSize: hunk.collapsedBefore,
			expandedHunks,
			hunkIndex,
			collapsedContextThreshold
		});
		if (region.rangeSize <= collapsedContextThreshold) continue;
		const gapEnd = getHunkDeletionStart(hunk);
		const gapStart = gapEnd - region.rangeSize;
		if (region.fromStart > 0) anchors.push([gapStart, gapStart + region.fromStart]);
		if (region.fromEnd > 0) anchors.push([gapEnd - region.fromEnd, gapEnd]);
	}
	const trailingRegion = getTrailingExpandedRegion({
		fileDiff: diff,
		hunkIndex: diff.hunks.length - 1,
		expandedHunks,
		collapsedContextThreshold,
		errorPrefix: "captureExpansionAnchors"
	});
	if (trailingRegion != null && trailingRegion.fromStart > 0 && trailingRegion.rangeSize > collapsedContextThreshold) {
		const lastHunk = diff.hunks[diff.hunks.length - 1];
		const gapStart = getHunkDeletionStart(lastHunk) + lastHunk.deletionCount;
		anchors.push([gapStart, gapStart + trailingRegion.fromStart]);
	}
	return anchors;
}
/**
* Rebuild gap expansion state against the recomputed hunks: for each new
* gap, an anchor touching the gap's start edge restores `fromStart`, one
* touching its end edge restores `fromEnd`, and anchors for gaps that no
* longer exist drop.
*/
function rebuildExpansionFromAnchors(diff, anchors) {
	const rebuilt = /* @__PURE__ */ new Map();
	if (anchors.length === 0) return rebuilt;
	const applyGap = (key, gapStart, gapEnd) => {
		if (gapEnd <= gapStart) return;
		let fromStart = 0;
		let fromEnd = 0;
		for (const [start, end] of anchors) {
			if (end <= gapStart || start >= gapEnd) continue;
			if (start <= gapStart) fromStart = Math.max(fromStart, Math.min(end, gapEnd) - gapStart);
			if (end >= gapEnd) fromEnd = Math.max(fromEnd, gapEnd - Math.max(start, gapStart));
		}
		if (fromStart > 0 || fromEnd > 0) rebuilt.set(key, {
			fromStart,
			fromEnd
		});
	};
	for (const [hunkIndex, hunk] of diff.hunks.entries()) {
		const gapEnd = getHunkDeletionStart(hunk);
		applyGap(hunkIndex, gapEnd - Math.max(hunk.collapsedBefore, 0), gapEnd);
	}
	const lastHunk = diff.hunks[diff.hunks.length - 1];
	if (lastHunk != null && !diff.isPartial && diff.deletionLines.length > 0) applyGap(diff.hunks.length, getHunkDeletionStart(lastHunk) + lastHunk.deletionCount, diff.deletionLines.length);
	return rebuilt;
}
/**
* Genuine session exit: when session passes reshaped the hunks, run the real
* full recompute so exit state matches a non-session edit pipeline, and clear
* the marker. Returns true when a recompute ran.
*/
function finishEditSessionForDiff(diff, parseDiffOptions) {
	if (diff.editSessionDirty !== true) return false;
	diff.editSessionDirty = void 0;
	Object.assign(diff, diff.additionLines.length <= 1 && diff.additionLines.join("") === "" ? recomputeDiffHunks(diff, parseDiffOptions) : recomputeDiffHunksForEdit(diff, parseDiffOptions));
	return true;
}
function parseCanonicalChangeBlocks(diff, parseDiffOptions) {
	if (findDivergenceCore(diff.deletionLines, diff.additionLines) == null) return [];
	const parsed = parseDiffFromFile({
		name: diff.prevName ?? diff.name,
		contents: diff.deletionLines.join("")
	}, {
		name: diff.name,
		contents: diff.additionLines.join(""),
		lang: diff.lang
	}, parseDiffOptions);
	const blocks = [];
	let coveredAdditions = 0;
	let coveredDeletions = 0;
	for (const hunk of parsed.hunks) {
		const contextLines = hunk.additionCount > 0 ? hunk.additionLineIndex - coveredAdditions : hunk.deletionLineIndex - coveredDeletions;
		coveredAdditions += contextLines;
		coveredDeletions += contextLines;
		for (const content of hunk.hunkContent) {
			if (content.type === "context") {
				coveredAdditions += content.lines;
				coveredDeletions += content.lines;
				continue;
			}
			const block = offsetHunkContent(content, 0, 0);
			if (block.additions === 0) block.additionLineIndex = coveredAdditions;
			if (block.deletions === 0) block.deletionLineIndex = coveredDeletions;
			blocks.push(block);
			coveredAdditions += block.additions;
			coveredDeletions += block.deletions;
		}
	}
	return blocks;
}
function buildRegionPlans(previousHunks, blocks, deletionLineCount) {
	const previousPlans = previousHunks.map((hunk, index) => {
		const deletionStart = getHunkDeletionStart(hunk);
		return {
			deletionStart,
			deletionEnd: deletionStart + hunk.deletionCount,
			blocks: [],
			previousSpan: {
				firstIndex: index,
				lastIndex: index
			}
		};
	});
	const plans = [];
	let previousIndex = 0;
	for (const block of blocks) {
		const blockStart = block.deletionLineIndex;
		const blockEnd = blockStart + block.deletions;
		while (previousIndex < previousPlans.length && previousPlans[previousIndex].deletionEnd < blockStart) {
			plans.push(previousPlans[previousIndex]);
			previousIndex++;
		}
		let plan = plans.length > 0 && blockTouchesRegion(blockStart, blockEnd, plans[plans.length - 1]) ? plans.pop() : void 0;
		while (previousIndex < previousPlans.length && previousPlans[previousIndex].deletionStart <= blockEnd) {
			plan = mergeRegionPlans(plan, previousPlans[previousIndex]);
			previousIndex++;
		}
		if (plan == null) {
			let deletionStart = blockStart;
			let deletionEnd = blockEnd;
			if ((block.deletions === 0 || block.additions === 0) && deletionLineCount > block.deletions) {
				const previousEnd = plans[plans.length - 1]?.deletionEnd ?? 0;
				const nextStart = previousPlans[previousIndex]?.deletionStart ?? deletionLineCount;
				if (blockStart > previousEnd) deletionStart--;
				else if (blockEnd < nextStart) deletionEnd++;
			}
			plan = {
				deletionStart,
				deletionEnd,
				blocks: [],
				previousSpan: void 0
			};
		}
		plan.deletionStart = Math.min(plan.deletionStart, blockStart);
		plan.deletionEnd = Math.max(plan.deletionEnd, blockEnd);
		plan.blocks.push(block);
		plans.push(plan);
	}
	while (previousIndex < previousPlans.length) {
		plans.push(previousPlans[previousIndex]);
		previousIndex++;
	}
	return plans;
}
function blockTouchesRegion(blockStart, blockEnd, region) {
	return blockStart <= region.deletionEnd && blockEnd >= region.deletionStart;
}
function mergeRegionPlans(target, source) {
	if (target == null) return source;
	target.deletionStart = Math.min(target.deletionStart, source.deletionStart);
	target.deletionEnd = Math.max(target.deletionEnd, source.deletionEnd);
	target.blocks.push(...source.blocks);
	if (source.previousSpan != null) {
		target.previousSpan ??= { ...source.previousSpan };
		target.previousSpan.firstIndex = Math.min(target.previousSpan.firstIndex, source.previousSpan.firstIndex);
		target.previousSpan.lastIndex = Math.max(target.previousSpan.lastIndex, source.previousSpan.lastIndex);
	}
	return target;
}
function buildRegionHunks(diff, plans) {
	const hunks = [];
	let deletionCursor = 0;
	let additionCursor = 0;
	for (const plan of plans) {
		const contextBefore = plan.deletionStart - deletionCursor;
		if (contextBefore < 0) throw new Error("buildRegionHunks: overlapping old-side regions");
		deletionCursor += contextBefore;
		additionCursor += contextBefore;
		const additionStart = additionCursor;
		const hunkContent = [];
		for (const canonicalBlock of plan.blocks) {
			const deletionContext = canonicalBlock.deletionLineIndex - deletionCursor;
			const additionContext = canonicalBlock.additionLineIndex - additionCursor;
			if (deletionContext < 0 || deletionContext !== additionContext) throw new Error("buildRegionHunks: canonical block context mismatch");
			pushContext(hunkContent, deletionContext, additionCursor, deletionCursor);
			deletionCursor += deletionContext;
			additionCursor += additionContext;
			hunkContent.push({ ...canonicalBlock });
			deletionCursor += canonicalBlock.deletions;
			additionCursor += canonicalBlock.additions;
		}
		const trailingContext = plan.deletionEnd - deletionCursor;
		if (trailingContext < 0) throw new Error("buildRegionHunks: block exceeds its old-side region");
		pushContext(hunkContent, trailingContext, additionCursor, deletionCursor);
		deletionCursor += trailingContext;
		additionCursor += trailingContext;
		hunks.push(createRegionHunk(diff, {
			additionStart,
			additionEnd: additionCursor,
			deletionStart: plan.deletionStart,
			deletionEnd: plan.deletionEnd
		}, hunkContent));
	}
	if (diff.deletionLines.length - deletionCursor !== diff.additionLines.length - additionCursor) throw new Error("buildRegionHunks: trailing context mismatch");
	return hunks;
}
function createRegionHunk(diff, bounds, hunkContent) {
	const additionCount = bounds.additionEnd - bounds.additionStart;
	const deletionCount = bounds.deletionEnd - bounds.deletionStart;
	let additionLines = 0;
	let deletionLines = 0;
	for (const content of hunkContent) if (content.type === "change") {
		additionLines += content.additions;
		deletionLines += content.deletions;
	}
	const hunk = {
		collapsedBefore: 0,
		additionStart: getUnifiedStart(bounds.additionStart, additionCount),
		additionCount,
		additionLines,
		additionLineIndex: getUnifiedLineIndex(bounds.additionStart, additionCount),
		deletionStart: getUnifiedStart(bounds.deletionStart, deletionCount),
		deletionCount,
		deletionLines,
		deletionLineIndex: getUnifiedLineIndex(bounds.deletionStart, deletionCount),
		hunkContent,
		hunkSpecs: `@@ -${getUnifiedStart(bounds.deletionStart, deletionCount)},${deletionCount} +${getUnifiedStart(bounds.additionStart, additionCount)},${additionCount} @@`,
		splitLineStart: 0,
		splitLineCount: 0,
		unifiedLineStart: 0,
		unifiedLineCount: 0,
		noEOFCRAdditions: false,
		noEOFCRDeletions: false
	};
	recomputeHunkRenderLineCounts(hunk);
	return hunk;
}
function pushContext(hunkContent, lines, additionLineIndex, deletionLineIndex) {
	if (lines > 0) hunkContent.push({
		type: "context",
		lines,
		additionLineIndex,
		deletionLineIndex
	});
}
function hasRegionOrSplitLayoutChanged(previous, next) {
	if (previous.length !== next.length) return true;
	for (let index = 0; index < previous.length; index++) {
		const previousHunk = previous[index];
		const nextHunk = next[index];
		if (getHunkDeletionStart(previousHunk) !== getHunkDeletionStart(nextHunk) || previousHunk.deletionCount !== nextHunk.deletionCount || getHunkAdditionStart(previousHunk) !== getHunkAdditionStart(nextHunk) || previousHunk.additionCount !== nextHunk.additionCount || previousHunk.splitLineCount !== nextHunk.splitLineCount || !haveSameSplitRowMapping(previousHunk, nextHunk)) return true;
	}
	return false;
}
function haveSameSplitRowMapping(previous, next) {
	const previousRows = iterateSplitRowMapping(previous);
	const nextRows = iterateSplitRowMapping(next);
	while (true) {
		const previousRow = previousRows.next();
		const nextRow = nextRows.next();
		if (previousRow.done === true || nextRow.done === true) return previousRow.done === nextRow.done;
		if (previousRow.value[0] !== nextRow.value[0] || previousRow.value[1] !== nextRow.value[1]) return false;
	}
}
function* iterateSplitRowMapping(hunk) {
	for (const content of hunk.hunkContent) {
		if (content.type === "context") {
			for (let offset = 0; offset < content.lines; offset++) yield [content.deletionLineIndex + offset, content.additionLineIndex + offset];
			continue;
		}
		const rowCount = Math.max(content.deletions, content.additions);
		for (let offset = 0; offset < rowCount; offset++) yield [offset < content.deletions ? content.deletionLineIndex + offset : void 0, offset < content.additions ? content.additionLineIndex + offset : void 0];
	}
}
function getHunkAdditionStart(hunk) {
	return getHunkSideStartBoundary(hunk.additionStart, hunk.additionCount);
}
function getHunkDeletionStart(hunk) {
	return getHunkSideStartBoundary(hunk.deletionStart, hunk.deletionCount);
}
function getUnifiedStart(lineIndex, count) {
	return count === 0 ? lineIndex : lineIndex + 1;
}
function getUnifiedLineIndex(lineIndex, count) {
	return count === 0 ? lineIndex - 1 : lineIndex;
}
function finalizeSessionHunks(diff) {
	recomputeDiffRenderLineCounts(diff);
	for (let index = 0; index < diff.hunks.length; index++) syncHunkNoEOFCRFromFullFile(diff, index);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/isDiffPlainText.js
function isDiffPlainText(diff) {
	const computedLang = diff.lang ?? getFiletypeFromFileName(diff.name);
	const computedPreviousLang = diff.lang ?? (diff.prevName != null ? getFiletypeFromFileName(diff.prevName) : "text");
	return computedLang === "text" && computedPreviousLang === "text";
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/renderers/DiffHunksRenderer.js
var instanceId$3 = -1;
var DiffHunksRenderer = class {
	options;
	onRenderUpdate;
	workerManager;
	__id = `diff-hunks-renderer:${++instanceId$3}`;
	highlighter;
	diff;
	expandedHunks = /* @__PURE__ */ new Map();
	deletionAnnotations = {};
	additionAnnotations = {};
	computedLang = "text";
	renderCache;
	editSessionActive = false;
	constructor(options = { theme: DEFAULT_THEMES }, onRenderUpdate, workerManager) {
		this.options = options;
		this.onRenderUpdate = onRenderUpdate;
		this.workerManager = workerManager;
		if (workerManager?.isWorkingPool() !== true) this.highlighter = areThemesAttached(options.theme ?? DEFAULT_THEMES) ? getHighlighterIfLoaded() : void 0;
	}
	cleanUp() {
		this.recycle();
		this.expandedHunks.clear();
		this.workerManager = void 0;
		this.onRenderUpdate = void 0;
	}
	recycle() {
		this.highlighter = void 0;
		this.diff = void 0;
		this.clearRenderCache();
		this.additionAnnotations = {};
		this.deletionAnnotations = {};
		this.workerManager?.cleanUpTasks(this);
		this.endEditSession();
	}
	/**
	* Enter edit-session mode: hunk updates preserve the current region
	* skeleton instead of recomputing hunks, and rendering happens locally
	* with the token transformer forced on (worker-pool requests/results are
	* suspended for this renderer). An empty additions document gets one row so
	* the editor has a line for its caret. Called on every editor attach,
	* including a re-attach after recycle.
	*/
	beginEditSession() {
		this.editSessionActive = true;
		const diff = this.diffCache;
		if (diff != null && !diff.isPartial && diff.additionLines.length === 0) {
			Object.assign(diff, recomputeEmptyDocumentDiff(diff, this.options.parseDiffOptions));
			this.markEditSessionPass(diff);
			this.clearRenderCache();
		}
	}
	/** Leave edit-session mode. The exit recompute is the host's concern. */
	endEditSession() {
		this.editSessionActive = false;
	}
	/**
	* Ensures that the DOM is compatible with editor render updates
	*/
	editorRenderReady() {
		return this.renderCache?.options.useTokenTransformer === true && this.renderCache.highlighted && this.renderCache.result != null;
	}
	/**
	* Re-highlights the current diff in the background and swaps the fresh
	* result in (with a re-render) once it completes. Needed after an edit
	* session's exit recompute: session passes plain-fill shifted lines in the
	* cached result, and the recompute mutates the diff in place (same object,
	* same cacheKey), so identity/cacheKey checks would otherwise treat the
	* stale highlight as current forever. The current result — content-correct,
	* mostly highlighted — keeps rendering until the fresh one lands, so no
	* interim paint drops highlighting.
	*/
	refreshHighlightedResult() {
		const { renderCache } = this;
		if (renderCache == null || isDiffPlainText(renderCache.diff) || isDiffMassive(renderCache.diff, this.getTokenizeMaxLength())) return Promise.resolve();
		const { diff } = renderCache;
		const { workerManager } = this;
		if (!this.editSessionActive && workerManager?.isWorkingPool() === true && diff.cacheKey != null) {
			workerManager.evictDiffFromCache(diff.cacheKey);
			return workerManager.primeDiffHighlightCache(diff).then(() => {
				this.applyRefreshedResult(diff, workerManager.getDiffResultCache(diff));
			}).catch((error) => this.onHighlightError(error));
		}
		return this.asyncHighlight(diff).then((fresh) => this.applyRefreshedResult(diff, fresh)).catch((error) => this.onHighlightError(error));
	}
	applyRefreshedResult(diff, fresh) {
		if (fresh == null || this.renderCache == null || this.renderCache.diff !== diff || this.editSessionActive) return;
		const { options } = this.getRenderOptions(diff);
		if (!areDiffRenderOptionsEqual(options, fresh.options)) return;
		this.renderCache = {
			diff,
			options: fresh.options,
			highlighted: true,
			result: fresh.result,
			renderRange: void 0
		};
		this.onRenderUpdate?.();
	}
	get diffCache() {
		return this.renderCache?.diff ?? this.diff;
	}
	clearRenderCache() {
		const renderCache = this.renderCache;
		this.renderCache = void 0;
		if (renderCache != null && renderCache.isDirty === true && renderCache.diff.cacheKey != null) this.workerManager?.evictDiffFromCache(renderCache.diff.cacheKey);
	}
	setOptions(options) {
		this.options = options;
	}
	mergeOptions(options) {
		this.options = {
			...this.options,
			...options
		};
	}
	expandHunk(index, direction, expansionLineCount = this.getOptionsWithDefaults().expansionLineCount) {
		const region = { ...this.expandedHunks.get(index) ?? {
			fromStart: 0,
			fromEnd: 0
		} };
		if (direction === "up" || direction === "both") region.fromStart += expansionLineCount;
		if (direction === "down" || direction === "both") region.fromEnd += expansionLineCount;
		if (this.renderCache?.highlighted !== true) this.clearRenderCache();
		this.expandedHunks.set(index, region);
	}
	getExpandedHunk(hunkIndex) {
		return this.expandedHunks.get(hunkIndex) ?? DEFAULT_EXPANDED_REGION;
	}
	getExpandedHunksMap() {
		return this.expandedHunks;
	}
	/** Replace the whole expansion map (session-exit expansion remapping). */
	setExpandedHunksMap(expandedHunks) {
		this.expandedHunks = expandedHunks;
	}
	setLineAnnotations(lineAnnotations) {
		this.additionAnnotations = {};
		this.deletionAnnotations = {};
		for (const annotation of lineAnnotations) {
			const map = (() => {
				switch (annotation.side) {
					case "deletions": return this.deletionAnnotations;
					case "additions": return this.additionAnnotations;
				}
			})();
			const arr = map[annotation.lineNumber] ?? [];
			map[annotation.lineNumber] = arr;
			arr.push(annotation);
		}
	}
	/**
	* Returns true when a session-mode pass changed the region skeleton itself
	* (a gap edit synthesized or merged regions), which changes the rendered
	* row set without a line-count change — the host must escalate to a full
	* re-render instead of its cheap refresh path.
	*/
	updateRenderCache(dirtyLines, themeType, lineCountChangeInFlight = false) {
		if (this.renderCache == null) return false;
		const { result, diff } = this.renderCache;
		if (result == null) return false;
		if (diff.isPartial) throw new Error("Could not update render cache for partial diff");
		const hastLines = result.code.additionLines;
		const changedAdditionLines = [];
		const previousAdditionLines = /* @__PURE__ */ new Map();
		for (const [line, tokens] of dirtyLines) {
			const prevProps = hastLines[line]?.properties ?? {};
			const lineText = tokens.map((a) => a[2]).join("");
			const canSyncDiffLine = line < diff.additionLines.length;
			const prevLine = canSyncDiffLine ? diff.additionLines[line] ?? "" : "";
			const prevText = cleanLastNewline(prevLine);
			if (canSyncDiffLine) {
				diff.additionLines[line] = applyLineTextWithNewline(prevLine, lineText);
				if (prevText !== lineText) {
					changedAdditionLines.push(line);
					previousAdditionLines.set(line, prevLine);
				}
			}
			hastLines[line] = {
				type: "element",
				tagName: "div",
				properties: {
					"data-line": prevProps["data-line"] ?? line + 1,
					"data-line-index": prevProps["data-line-index"] ?? line,
					"data-line-type": prevProps["data-line-type"] ?? "context"
				},
				children: tokens.map(([char, fg, text]) => {
					if (char === 0 && fg === "") {
						if (text === "") return {
							type: "element",
							tagName: "br",
							properties: {},
							children: []
						};
						return {
							type: "text",
							value: text
						};
					}
					return {
						type: "element",
						tagName: "span",
						properties: {
							"data-char": char,
							style: `color:${fg};`
						},
						children: [{
							type: "text",
							value: text
						}]
					};
				})
			};
		}
		let regionsChanged = false;
		if (changedAdditionLines.length > 0) if (this.editSessionActive && !diff.isPartial) {
			if (!lineCountChangeInFlight) if (diff.additionLines.length <= 1 && diff.additionLines.join("") === "") {
				Object.assign(diff, recomputeEmptyDocumentDiff(diff, this.options.parseDiffOptions));
				this.markEditSessionPass(diff);
				regionsChanged = true;
			} else if (shouldTopAlignAdditionRecompute(diff, diff.additionLines)) {
				Object.assign(diff, recomputeTopAlignedAdditionDiff(diff, diff.additionLines, this.options.parseDiffOptions));
				this.markEditSessionPass(diff);
				regionsChanged = true;
			} else {
				const change = applySessionChangedLines(diff, changedAdditionLines, this.options.parseDiffOptions, previousAdditionLines);
				this.applyExpansionRemap(change);
				regionsChanged = change != null;
			}
		} else Object.assign(diff, updateDiffHunks(diff, changedAdditionLines, this.options.parseDiffOptions));
		result.baseThemeType = themeType;
		this.renderCache.isDirty = true;
		return regionsChanged;
	}
	applyExpansionRemap(change) {
		if (change != null) this.expandedHunks = remapExpandedHunksForRegionChange(this.expandedHunks, change);
	}
	applyDocumentChange(textDocument) {
		if (this.renderCache == null) return;
		const { diff, result } = this.renderCache;
		if (result == null) return;
		if (diff.isPartial) throw new Error("Could not apply document change for partial diff");
		const { additionLines: previousAdditionLines } = diff;
		diff.additionLines = getEditorDocumentLines(textDocument, previousAdditionLines);
		result.code.additionLines = realignAdditionHastLines(previousAdditionLines, diff.additionLines, result.code.additionLines, textDocument);
		if (diff.additionLines.length <= 1 && diff.additionLines.join("") === "") {
			Object.assign(diff, recomputeEmptyDocumentDiff(diff, this.options.parseDiffOptions));
			result.code.additionLines[0] = createPlainAdditionLineElement(0, textDocument.getLineText(0));
			this.markEditSessionPass(diff);
		} else if (this.editSessionActive) this.applySessionDocumentChange(diff);
		else Object.assign(diff, recomputeDiffHunksForEdit(diff, this.options.parseDiffOptions));
		this.renderCache.isDirty = true;
	}
	applySessionDocumentChange(diff) {
		const { parseDiffOptions } = this.options;
		const rawLines = diff.additionLines;
		if (shouldTopAlignAdditionRecompute(diff, rawLines)) {
			Object.assign(diff, recomputeTopAlignedAdditionDiff(diff, rawLines, parseDiffOptions));
			this.markEditSessionPass(diff);
			return;
		}
		this.applyExpansionRemap(rebuildSessionHunks(diff, parseDiffOptions));
	}
	markEditSessionPass(diff) {
		if (!this.editSessionActive) return;
		diff.editSessionDirty = true;
	}
	getUnifiedLineDecoration({ lineType }) {
		return {
			gutterLineType: lineType,
			contentProperties: { "data-line-type": lineType }
		};
	}
	getSplitLineDecoration({ side, type }) {
		const lineType = type === "change" ? side === "deletions" ? "change-deletion" : "change-addition" : type;
		return {
			gutterLineType: lineType,
			contentProperties: { "data-line-type": lineType }
		};
	}
	createAnnotationElement = (span) => {
		return createAnnotationElement(span);
	};
	getOptionsWithDefaults() {
		const { diffIndicators = "bars", diffStyle = "split", disableBackground = false, disableFileHeader = false, disableLineNumbers = false, disableVirtualizationBuffers = false, collapsed = false, expandUnchanged = false, collapsedContextThreshold = 1, expansionLineCount = 100, hunkSeparators = "line-info", lineDiffType = "word-alt", maxLineDiffLength = 1e3, overflow = "scroll", stickyHeader = false, theme = DEFAULT_THEMES, headerRenderMode = "default", tokenizeMaxLineLength = 1e3, tokenizeMaxLength = DEFAULT_TOKENIZE_MAX_LENGTH, useTokenTransformer = false, useCSSClasses = false } = this.options;
		return {
			diffIndicators,
			diffStyle,
			disableBackground,
			disableFileHeader,
			disableLineNumbers,
			disableVirtualizationBuffers,
			collapsed,
			expandUnchanged,
			collapsedContextThreshold,
			expansionLineCount,
			hunkSeparators,
			lineDiffType,
			maxLineDiffLength,
			overflow,
			stickyHeader,
			theme: this.workerManager?.getDiffRenderOptions().theme ?? theme,
			headerRenderMode,
			tokenizeMaxLineLength,
			tokenizeMaxLength,
			useTokenTransformer,
			useCSSClasses
		};
	}
	async initializeHighlighter() {
		this.highlighter = await getSharedHighlighter(getHighlighterOptions(this.computedLang, {
			theme: this.getLocalHighlightTheme(),
			preferredHighlighter: this.workerManager?.getPreferredHighlighter() ?? this.options.preferredHighlighter
		}));
		return this.highlighter;
	}
	hydrate(diff) {
		if (diff == null) return;
		this.diff = diff;
		const { options } = this.getRenderOptions(diff);
		const massiveDiff = isDiffMassive(diff, this.getTokenizeMaxLength());
		let cache = this.workerManager?.getDiffResultCache(diff);
		if (cache != null && !areDiffRenderOptionsEqual(options, cache.options)) cache = void 0;
		this.renderCache ??= {
			diff,
			highlighted: !massiveDiff && !isDiffPlainText(diff),
			options,
			result: massiveDiff ? void 0 : cache?.result,
			renderRange: void 0
		};
		if (!this.editSessionActive && this.workerManager?.isWorkingPool() === true) {
			if (this.renderCache.result == null && !massiveDiff) this.workerManager.highlightDiffAST(this, this.diff);
		} else if (this.highlighter == null) {
			this.computedLang = diff.lang ?? getFiletypeFromFileName(diff.name);
			this.initializeHighlighter();
		}
	}
	getLocalHighlightTheme() {
		return this.workerManager?.getDiffRenderOptions().theme ?? this.options.theme ?? DEFAULT_THEMES;
	}
	getEffectiveCodeOptions() {
		const poolOptions = this.workerManager?.isWorkingPool() === true ? this.workerManager.getDiffRenderOptions() : void 0;
		return {
			theme: this.getLocalHighlightTheme(),
			tokenizeMaxLineLength: poolOptions?.tokenizeMaxLineLength ?? this.options.tokenizeMaxLineLength
		};
	}
	getRenderOptions(diff) {
		const options = (() => {
			if (this.workerManager?.isWorkingPool() === true) {
				const poolOptions = this.workerManager.getDiffRenderOptions();
				if (this.editSessionActive && poolOptions.useTokenTransformer !== true) return {
					...poolOptions,
					useTokenTransformer: true
				};
				return poolOptions;
			}
			const { theme, tokenizeMaxLineLength, lineDiffType, maxLineDiffLength } = this.getOptionsWithDefaults();
			return {
				theme,
				useTokenTransformer: this.editSessionActive || this.options.useTokenTransformer === true,
				tokenizeMaxLineLength,
				lineDiffType,
				maxLineDiffLength
			};
		})();
		this.getOptionsWithDefaults();
		const { renderCache } = this;
		if (renderCache?.result == null) return {
			options,
			forceHighlight: true
		};
		if (!areDiffTargetsEqual(diff, renderCache.diff) || !areDiffRenderOptionsEqual(options, renderCache.options)) return {
			options,
			forceHighlight: true
		};
		return {
			options,
			forceHighlight: false
		};
	}
	renderDiff(diff = this.renderCache?.diff, renderRange = DEFAULT_RENDER_RANGE) {
		if (diff == null) return;
		const { expandUnchanged, collapsedContextThreshold } = this.getOptionsWithDefaults();
		let { options, forceHighlight } = this.getRenderOptions(diff);
		const cache = this.getMatchingWorkerResultCache(diff, options);
		if (cache != null && !this.hasHighlightedRenderCache(diff, options)) {
			this.renderCache = {
				diff,
				highlighted: true,
				renderRange: void 0,
				...cache
			};
			forceHighlight = false;
		}
		this.renderCache ??= {
			diff,
			highlighted: false,
			options,
			result: void 0,
			renderRange: void 0
		};
		const hasContent = diff.additionLines.length > 0 || diff.deletionLines.length > 0;
		const forcePlainText = !hasContent || isDiffPlainText(diff) || isDiffMassive(diff, this.getTokenizeMaxLength());
		const newContent = !areDiffTargetsEqual(diff, this.renderCache.diff);
		const newRenderRange = !areRenderRangesEqual(this.renderCache.renderRange, renderRange);
		if (!this.editSessionActive && this.workerManager?.isWorkingPool() === true) {
			const highlightPending = this.renderCache.result == null && this.renderCache.highlighted && !forcePlainText && !newContent && isDefaultRenderRange(renderRange);
			if (highlightPending) this.renderCache.highlightPending = true;
			if (!highlightPending && (forcePlainText || this.renderCache.result == null || !this.renderCache.highlighted && (newContent || newRenderRange))) {
				this.renderCache.diff = diff;
				this.renderCache.options = options;
				this.renderCache.highlighted = false;
				if (this.renderCache.result == null || newContent || newRenderRange || forceHighlight) this.renderCache.result = this.workerManager.getPlainDiffAST(diff, renderRange.startingLine, renderRange.totalLines, isDefaultRenderRange(renderRange) ? true : expandUnchanged ? true : this.expandedHunks, collapsedContextThreshold);
				this.renderCache.renderRange = renderRange;
			}
			if (!forcePlainText && hasContent && (!this.renderCache.highlighted || forceHighlight)) this.workerManager.highlightDiffAST(this, diff);
		} else {
			this.computedLang = diff.lang ?? getFiletypeFromFileName(diff.name);
			const hasThemes = this.highlighter != null && areThemesAttached(options.theme);
			const hasLangs = this.highlighter != null && areLanguagesAttached(this.computedLang);
			const canHighlight = !forcePlainText && hasLangs;
			if (this.highlighter != null && hasThemes && (forceHighlight || forcePlainText || !this.renderCache.highlighted && canHighlight || this.renderCache.result == null)) {
				const { result, options } = this.renderDiffWithHighlighter(diff, this.highlighter, forcePlainText || !hasLangs);
				this.renderCache = {
					diff,
					options,
					highlighted: canHighlight,
					result,
					renderRange: void 0
				};
			}
			if (!hasThemes || !forcePlainText && !hasLangs) this.asyncHighlight(diff).then(({ result, options }) => {
				if (this.renderCache != null) this.renderCache.highlighted = false;
				this.applyHighlightResult(diff, result, options, !forcePlainText);
			});
		}
		return this.renderCache.result != null ? this.processDiffResult(this.renderCache.diff, renderRange, this.renderCache.result) : void 0;
	}
	async asyncRender(diff, renderRange = DEFAULT_RENDER_RANGE) {
		const { result } = await this.asyncHighlight(diff);
		return this.processDiffResult(diff, renderRange, result);
	}
	createPreElement(split, totalLines, customProperties) {
		const { diffIndicators, disableBackground, disableLineNumbers, overflow } = this.getOptionsWithDefaults();
		return createPreElement({
			type: "diff",
			diffIndicators,
			disableBackground,
			disableLineNumbers,
			overflow,
			split,
			totalLines,
			customProperties
		});
	}
	async asyncHighlight(diff) {
		const forcePlainText = isDiffMassive(diff, this.getTokenizeMaxLength());
		this.computedLang = forcePlainText ? "text" : diff.lang ?? getFiletypeFromFileName(diff.name);
		const hasThemes = this.highlighter != null && areThemesAttached(this.getLocalHighlightTheme());
		const hasLangs = forcePlainText || this.highlighter != null && areLanguagesAttached(this.computedLang);
		if (this.highlighter == null || !hasThemes || !hasLangs) this.highlighter = await this.initializeHighlighter();
		return this.renderDiffWithHighlighter(diff, this.highlighter, forcePlainText);
	}
	renderDiffWithHighlighter(diff, highlighter, forcePlainText = false) {
		const { options } = this.getRenderOptions(diff);
		const { collapsedContextThreshold } = this.getOptionsWithDefaults();
		const result = renderDiffWithHighlighter(diff, highlighter, options, {
			forcePlainText,
			expandedHunks: forcePlainText ? true : void 0,
			collapsedContextThreshold
		});
		if (this.editSessionActive && diff.additionLines.length === 1 && diff.additionLines[0] === "" && result.code.additionLines[0] == null) {
			let fallbackLine;
			iterateOverDiff({
				diff,
				diffStyle: "both",
				expandedHunks: forcePlainText ? true : void 0,
				collapsedContextThreshold,
				callback: ({ additionLine }) => {
					if (additionLine?.lineIndex !== 0) return;
					fallbackLine = additionLine;
					return true;
				}
			});
			if (fallbackLine == null) throw new Error("DiffHunksRenderer: missing empty addition line");
			result.code.additionLines[0] = createPlainAdditionLineElement(0, "", fallbackLine.unifiedLineIndex, fallbackLine.splitLineIndex);
		}
		return {
			result,
			options
		};
	}
	onHighlightSuccess(diff, result, options, highlighted = true) {
		if (this.editSessionActive) return;
		this.applyHighlightResult(diff, result, options, highlighted);
	}
	applyHighlightResult(diff, result, options, highlighted = true) {
		if (this.renderCache == null) return;
		const triggerRenderUpdate = this.renderCache.highlightPending === true || !this.renderCache.highlighted || !areDiffRenderOptionsEqual(this.renderCache.options, options) || !areDiffTargetsEqual(this.renderCache.diff, diff);
		this.renderCache = {
			diff,
			options,
			highlighted,
			result,
			renderRange: void 0
		};
		if (triggerRenderUpdate) this.onRenderUpdate?.();
	}
	getMatchingWorkerResultCache(diff, options) {
		if (this.editSessionActive) return;
		const cache = this.workerManager?.getDiffResultCache(diff);
		if (cache == null || !areDiffRenderOptionsEqual(options, cache.options)) return;
		return cache;
	}
	hasHighlightedRenderCache(diff, options) {
		const { renderCache } = this;
		return renderCache?.result != null && renderCache.highlighted && areDiffTargetsEqual(diff, renderCache.diff) && areDiffRenderOptionsEqual(options, renderCache.options);
	}
	onHighlightError(error) {
		console.error(error);
	}
	getTokenizeMaxLength() {
		return this.options.tokenizeMaxLength ?? 1e5;
	}
	processDiffResult(fileDiff, renderRange, { code, themeStyles, baseThemeType }) {
		const { diffStyle, disableFileHeader, expandUnchanged, expansionLineCount, collapsedContextThreshold, hunkSeparators } = this.getOptionsWithDefaults();
		const isRenderCacheDirty = this.renderCache?.isDirty ?? false;
		this.diff = fileDiff;
		const unified = diffStyle === "unified";
		const canHydrateContext = canHydrateCollapsedContext$1(fileDiff, this.options.loadDiffFiles != null);
		const isExpandableDiff = !fileDiff.isPartial || canHydrateContext;
		let additionsContentAST = [];
		let deletionsContentAST = [];
		let unifiedContentAST = [];
		const hunkData = [];
		const { additionLines, deletionLines } = code;
		const context = {
			rowCount: 0,
			hunkSeparators,
			additionsContentAST,
			deletionsContentAST,
			unifiedContentAST,
			unifiedGutterAST: createGutterWrapper(),
			deletionsGutterAST: createGutterWrapper(),
			additionsGutterAST: createGutterWrapper(),
			expansionLineCount,
			hunkData,
			incrementRowCount(count = 1) {
				context.rowCount += count;
			},
			pushToGutter(type, element) {
				switch (type) {
					case "unified":
						context.unifiedGutterAST.children.push(element);
						break;
					case "deletions":
						context.deletionsGutterAST.children.push(element);
						break;
					case "additions":
						context.additionsGutterAST.children.push(element);
						break;
				}
			}
		};
		const trailingRangeSize = getTrailingContextRangeSize({
			fileDiff,
			errorPrefix: "DiffHunksRenderer.processDiffResult"
		});
		const pendingSplitContext = {
			size: 0,
			side: void 0,
			increment() {
				this.size += 1;
			},
			flush() {
				if (diffStyle === "unified") return;
				if (this.size <= 0 || this.side == null) {
					this.side = void 0;
					this.size = 0;
					return;
				}
				if (this.side === "additions") {
					context.pushToGutter("additions", createGutterGap(void 0, "buffer", this.size));
					additionsContentAST?.push(createEmptyRowBuffer(this.size));
				} else {
					context.pushToGutter("deletions", createGutterGap(void 0, "buffer", this.size));
					deletionsContentAST?.push(createEmptyRowBuffer(this.size));
				}
				this.size = 0;
				this.side = void 0;
			}
		};
		const pushGutterLineNumber = (type, lineType, lineNumber, lineIndex, gutterProperties) => {
			context.pushToGutter(type, createGutterItem(lineType, lineNumber, lineIndex, gutterProperties));
		};
		function pushSeparators(props) {
			pendingSplitContext.flush();
			if (diffStyle === "unified") pushSeparator("unified", props, context);
			else {
				pushSeparator("deletions", props, context);
				pushSeparator("additions", props, context);
			}
		}
		this.pushFileLevelAnnotations(fileDiff, diffStyle, renderRange, context);
		iterateOverDiff({
			diff: fileDiff,
			diffStyle,
			startingLine: renderRange.startingLine,
			totalLines: renderRange.totalLines,
			expandedHunks: expandUnchanged ? true : this.expandedHunks,
			collapsedContextThreshold,
			callback: ({ hunkIndex, hunk, collapsedBefore, collapsedAfter, additionLine, deletionLine, type }) => {
				const splitLineIndex = deletionLine != null ? deletionLine.splitLineIndex : additionLine.splitLineIndex;
				const unifiedLineIndex = additionLine != null ? additionLine.unifiedLineIndex : deletionLine.unifiedLineIndex;
				if (diffStyle === "split" && type !== "change") pendingSplitContext.flush();
				if (collapsedBefore > 0) pushSeparators({
					hunkIndex,
					collapsedLines: collapsedBefore,
					rangeSize: Math.max(hunk?.collapsedBefore ?? 0, 0),
					hunkSpecs: hunk?.hunkSpecs,
					isFirstHunk: hunkIndex === 0,
					isLastHunk: false,
					isExpandable: isExpandableDiff
				});
				const lineIndex = diffStyle === "unified" ? unifiedLineIndex : splitLineIndex;
				const renderedLineContext = {
					type,
					hunkIndex,
					lineIndex,
					unifiedLineIndex,
					splitLineIndex,
					deletionLine,
					additionLine
				};
				if (diffStyle === "unified") {
					const injectedRows = this.getUnifiedInjectedRowsForLine?.(renderedLineContext);
					if (injectedRows?.before != null) pushUnifiedInjectedRows(injectedRows.before, context);
					let deletionLineContent = deletionLine != null ? deletionLines[deletionLine.lineIndex] : void 0;
					let additionLineContent = additionLine != null ? additionLines[additionLine.lineIndex] : void 0;
					if (deletionLineContent == null && additionLineContent == null) {
						const errorMessage = "DiffHunksRenderer.processDiffResult: deletionLine and additionLine are null, something is wrong";
						console.error(errorMessage, { file: fileDiff.name });
						throw new Error(errorMessage);
					}
					const lineType = type === "change" ? additionLine != null ? "change-addition" : "change-deletion" : type;
					const lineDecoration = this.getUnifiedLineDecoration({
						type,
						lineType,
						additionLineIndex: additionLine?.lineIndex,
						deletionLineIndex: deletionLine?.lineIndex
					});
					pushGutterLineNumber("unified", lineDecoration.gutterLineType, additionLine != null ? additionLine.lineNumber : deletionLine.lineNumber, `${unifiedLineIndex},${splitLineIndex}`, lineDecoration.gutterProperties);
					if (additionLineContent != null) additionLineContent = withContentProperties(additionLineContent, lineDecoration.contentProperties, isRenderCacheDirty && additionLine != null ? {
						"data-line": additionLine.lineNumber,
						"data-line-index": `${unifiedLineIndex},${splitLineIndex}`
					} : void 0);
					else if (deletionLineContent != null) deletionLineContent = withContentProperties(deletionLineContent, lineDecoration.contentProperties, isRenderCacheDirty && deletionLine != null ? {
						"data-line": deletionLine.lineNumber,
						"data-line-index": `${unifiedLineIndex},${splitLineIndex}`
					} : void 0);
					pushLineWithAnnotation({
						diffStyle: "unified",
						type,
						deletionLine: deletionLineContent,
						additionLine: additionLineContent,
						unifiedSpan: this.getAnnotations("unified", deletionLine?.lineNumber, additionLine?.lineNumber, hunkIndex, lineIndex),
						createAnnotationElement: (span) => this.createAnnotationElement(span),
						context
					});
					if (injectedRows?.after != null) pushUnifiedInjectedRows(injectedRows.after, context);
				} else {
					const injectedRows = this.getSplitInjectedRowsForLine?.(renderedLineContext);
					if (injectedRows?.before != null) pushSplitInjectedRows(injectedRows.before, context, pendingSplitContext);
					let deletionLineContent = deletionLine != null ? deletionLines[deletionLine.lineIndex] : void 0;
					let additionLineContent = additionLine != null ? additionLines[additionLine.lineIndex] : void 0;
					const deletionLineDecoration = this.getSplitLineDecoration({
						side: "deletions",
						type,
						lineIndex: deletionLine?.lineIndex
					});
					const additionLineDecoration = this.getSplitLineDecoration({
						side: "additions",
						type,
						lineIndex: additionLine?.lineIndex
					});
					if (deletionLineContent == null && additionLineContent == null) {
						const errorMessage = "DiffHunksRenderer.processDiffResult: deletionLine and additionLine are null, something is wrong";
						console.error(errorMessage, { file: fileDiff.name });
						throw new Error(errorMessage);
					}
					const missingSide = (() => {
						if (type === "change") {
							if (additionLineContent == null) return "additions";
							else if (deletionLineContent == null) return "deletions";
						}
					})();
					if (missingSide != null) {
						if (pendingSplitContext.side != null && pendingSplitContext.side !== missingSide) pendingSplitContext.flush();
						pendingSplitContext.side = missingSide;
						pendingSplitContext.increment();
					} else if (type === "change") pendingSplitContext.flush();
					const annotationSpans = this.getAnnotations("split", deletionLine?.lineNumber, additionLine?.lineNumber, hunkIndex, lineIndex);
					if (annotationSpans != null && pendingSplitContext.size > 0) pendingSplitContext.flush();
					if (deletionLine != null) {
						const deletionLineDecorated = withContentProperties(deletionLineContent, deletionLineDecoration.contentProperties, isRenderCacheDirty ? {
							"data-line": deletionLine.lineNumber,
							"data-line-index": `${deletionLine.unifiedLineIndex},${splitLineIndex}`
						} : void 0);
						pushGutterLineNumber("deletions", deletionLineDecoration.gutterLineType, deletionLine.lineNumber, `${deletionLine.unifiedLineIndex},${splitLineIndex}`, deletionLineDecoration.gutterProperties);
						if (deletionLineDecorated != null) deletionLineContent = deletionLineDecorated;
					}
					if (additionLine != null) {
						const additionLineDecorated = withContentProperties(additionLineContent, additionLineDecoration.contentProperties, isRenderCacheDirty ? {
							"data-line": additionLine.lineNumber,
							"data-line-index": `${additionLine.unifiedLineIndex},${splitLineIndex}`
						} : void 0);
						pushGutterLineNumber("additions", additionLineDecoration.gutterLineType, additionLine.lineNumber, `${additionLine.unifiedLineIndex},${splitLineIndex}`, additionLineDecoration.gutterProperties);
						if (additionLineDecorated != null) additionLineContent = additionLineDecorated;
					}
					pushLineWithAnnotation({
						diffStyle: "split",
						type,
						additionLine: additionLineContent,
						deletionLine: deletionLineContent,
						...annotationSpans,
						createAnnotationElement: (span) => this.createAnnotationElement(span),
						context
					});
					if (injectedRows?.after != null) pushSplitInjectedRows(injectedRows.after, context, pendingSplitContext);
				}
				const isFinalSplitHunkRow = diffStyle === "split" && hunk != null && splitLineIndex === hunk.splitLineStart + hunk.splitLineCount - 1;
				const isFinalHunkRow = hunkIndex === fileDiff.hunks.length - 1 && hunk != null && (diffStyle === "split" ? splitLineIndex === hunk.splitLineStart + hunk.splitLineCount - 1 : unifiedLineIndex === hunk.unifiedLineStart + hunk.unifiedLineCount - 1);
				const splitNoEOFCRDeletion = isFinalSplitHunkRow ? hunk.noEOFCRDeletions : false;
				const splitNoEOFCRAddition = isFinalSplitHunkRow ? hunk.noEOFCRAdditions : false;
				const noEOFCRDeletion = (deletionLine?.noEOFCR ?? false) || splitNoEOFCRDeletion;
				const noEOFCRAddition = (additionLine?.noEOFCR ?? false) || splitNoEOFCRAddition;
				if (noEOFCRAddition || noEOFCRDeletion) {
					if (diffStyle === "split") pendingSplitContext.flush();
					if (noEOFCRDeletion) {
						const noEOFType = type === "context" || type === "context-expanded" ? type : "change-deletion";
						if (diffStyle === "unified") {
							context.unifiedContentAST.push(createNoNewlineElement(noEOFType));
							context.pushToGutter("unified", createGutterGap(noEOFType, "metadata", 1));
						} else {
							context.deletionsContentAST.push(createNoNewlineElement(noEOFType));
							context.pushToGutter("deletions", createGutterGap(noEOFType, "metadata", 1));
							if (!noEOFCRAddition) {
								context.pushToGutter("additions", createGutterGap(void 0, "buffer", 1));
								context.additionsContentAST.push(createEmptyRowBuffer(1));
							}
						}
					}
					if (noEOFCRAddition) {
						const noEOFType = type === "context" || type === "context-expanded" ? type : "change-addition";
						if (diffStyle === "unified") {
							context.unifiedContentAST.push(createNoNewlineElement(noEOFType));
							context.pushToGutter("unified", createGutterGap(noEOFType, "metadata", 1));
						} else {
							context.additionsContentAST.push(createNoNewlineElement(noEOFType));
							context.pushToGutter("additions", createGutterGap(noEOFType, "metadata", 1));
							if (!noEOFCRDeletion) {
								context.pushToGutter("deletions", createGutterGap(void 0, "buffer", 1));
								context.deletionsContentAST.push(createEmptyRowBuffer(1));
							}
						}
					}
					context.incrementRowCount(1);
				}
				if (hunkSeparators !== "simple" && hunkSeparators !== "metadata" && (collapsedAfter > 0 || isFinalHunkRow && canHydrateContext)) pushSeparators({
					hunkIndex: type === "context-expanded" ? hunkIndex : hunkIndex + 1,
					collapsedLines: isFinalHunkRow && canHydrateContext ? "unknown" : collapsedAfter,
					rangeSize: trailingRangeSize,
					hunkSpecs: void 0,
					isFirstHunk: false,
					isLastHunk: true,
					isExpandable: isExpandableDiff
				});
				context.incrementRowCount(1);
			}
		});
		if (diffStyle === "split") pendingSplitContext.flush();
		const totalLines = Math.max(getTotalLineCountFromHunks(fileDiff.hunks), fileDiff.additionLines.length ?? 0, fileDiff.deletionLines.length ?? 0);
		const hasBuffer = renderRange.bufferBefore > 0 || renderRange.bufferAfter > 0;
		const shouldIncludeAdditions = !unified && fileDiff.type !== "deleted";
		const shouldIncludeDeletions = !unified && fileDiff.type !== "new";
		const hasContent = context.rowCount > 0 || hasBuffer;
		additionsContentAST = shouldIncludeAdditions && hasContent ? additionsContentAST : void 0;
		deletionsContentAST = shouldIncludeDeletions && hasContent ? deletionsContentAST : void 0;
		unifiedContentAST = unified && hasContent ? unifiedContentAST : void 0;
		const preNode = this.createPreElement(deletionsContentAST != null && additionsContentAST != null, totalLines);
		return {
			unifiedGutterAST: unified && hasContent ? context.unifiedGutterAST.children : void 0,
			unifiedContentAST,
			deletionsGutterAST: shouldIncludeDeletions && hasContent ? context.deletionsGutterAST.children : void 0,
			deletionsContentAST,
			additionsGutterAST: shouldIncludeAdditions && hasContent ? context.additionsGutterAST.children : void 0,
			additionsContentAST,
			hunkData,
			preNode,
			themeStyles,
			baseThemeType,
			headerElement: !disableFileHeader ? this.renderHeader(this.diff) : void 0,
			totalLines,
			rowCount: context.rowCount,
			bufferBefore: renderRange.bufferBefore,
			bufferAfter: renderRange.bufferAfter,
			css: ""
		};
	}
	renderCodeAST(type, result) {
		const gutterAST = type === "unified" ? result.unifiedGutterAST : type === "deletions" ? result.deletionsGutterAST : result.additionsGutterAST;
		const contentAST = type === "unified" ? result.unifiedContentAST : type === "deletions" ? result.deletionsContentAST : result.additionsContentAST;
		if (gutterAST == null || contentAST == null) return;
		const gutter = createGutterWrapper(gutterAST);
		gutter.properties.style = `grid-row: span ${result.rowCount}`;
		return [gutter, createContentColumn(contentAST, result.rowCount)];
	}
	renderFullAST(result, children = []) {
		const containerSize = this.getOptionsWithDefaults().hunkSeparators === "line-info";
		const unifiedAST = this.renderCodeAST("unified", result);
		if (unifiedAST != null) {
			children.push(createHastElement({
				tagName: "code",
				children: unifiedAST,
				properties: {
					"data-code": "",
					"data-container-size": containerSize ? "" : void 0,
					"data-unified": ""
				}
			}));
			return {
				...result.preNode,
				children
			};
		}
		const deletionsAST = this.renderCodeAST("deletions", result);
		if (deletionsAST != null) children.push(createHastElement({
			tagName: "code",
			children: deletionsAST,
			properties: {
				"data-code": "",
				"data-container-size": containerSize ? "" : void 0,
				"data-deletions": ""
			}
		}));
		const additionsAST = this.renderCodeAST("additions", result);
		if (additionsAST != null) children.push(createHastElement({
			tagName: "code",
			children: additionsAST,
			properties: {
				"data-code": "",
				"data-container-size": containerSize ? "" : void 0,
				"data-additions": ""
			}
		}));
		return {
			...result.preNode,
			children
		};
	}
	renderFullHTML(result, tempChildren = []) {
		return toHtml(this.renderFullAST(result, tempChildren));
	}
	renderPartialHTML(children, columnType) {
		if (columnType == null) return toHtml(children);
		return toHtml(createHastElement({
			tagName: "code",
			children,
			properties: {
				"data-code": "",
				"data-container-size": this.getOptionsWithDefaults().hunkSeparators === "line-info" ? "" : void 0,
				[`data-${columnType}`]: ""
			}
		}));
	}
	pushFileLevelAnnotations(fileDiff, diffStyle, renderRange, context) {
		if (!shouldRenderFileAnnotations(renderRange)) return;
		const deletionAnnotationNames = fileDiff.type !== "new" ? getAnnotationNames(getFileAnnotations(this.deletionAnnotations)) : [];
		const additionAnnotationNames = fileDiff.type !== "deleted" ? getAnnotationNames(getFileAnnotations(this.additionAnnotations)) : [];
		if (deletionAnnotationNames.length === 0 && additionAnnotationNames.length === 0) return;
		const hunkIndex = -1;
		const lineIndex = -1;
		const { createAnnotationElement } = this;
		if (diffStyle === "unified") {
			pushLineWithAnnotation({
				diffStyle,
				type: "context",
				unifiedSpan: {
					type: "annotation",
					hunkIndex,
					lineIndex,
					annotations: deletionAnnotationNames.concat(additionAnnotationNames)
				},
				createAnnotationElement,
				context
			});
			return;
		}
		pushLineWithAnnotation({
			diffStyle,
			type: "context",
			deletionSpan: {
				type: "annotation",
				hunkIndex,
				lineIndex,
				annotations: deletionAnnotationNames
			},
			additionSpan: {
				type: "annotation",
				hunkIndex,
				lineIndex,
				annotations: additionAnnotationNames
			},
			createAnnotationElement,
			context
		});
	}
	getAnnotations(type, deletionLineNumber, additionLineNumber, hunkIndex, lineIndex) {
		const deletionSpan = {
			type: "annotation",
			hunkIndex,
			lineIndex,
			annotations: []
		};
		if (deletionLineNumber != null) for (const anno of this.deletionAnnotations[deletionLineNumber] ?? []) deletionSpan.annotations.push(getLineAnnotationName(anno));
		const additionSpan = {
			type: "annotation",
			hunkIndex,
			lineIndex,
			annotations: []
		};
		if (additionLineNumber != null) for (const anno of this.additionAnnotations[additionLineNumber] ?? []) (type === "unified" ? deletionSpan : additionSpan).annotations.push(getLineAnnotationName(anno));
		if (type === "unified") {
			if (deletionSpan.annotations.length > 0) return deletionSpan;
			return;
		}
		if (additionSpan.annotations.length === 0 && deletionSpan.annotations.length === 0) return;
		return {
			deletionSpan,
			additionSpan
		};
	}
	renderHeader(diff) {
		const { headerRenderMode, stickyHeader } = this.getOptionsWithDefaults();
		return createFileHeaderElement({
			fileOrDiff: diff,
			mode: headerRenderMode,
			stickyHeader
		});
	}
};
function getAnnotationNames(annotations) {
	return annotations?.map((annotation) => getLineAnnotationName(annotation)) ?? [];
}
var EN_PLURAL_RULES = new Intl.PluralRules("en-US");
function getModifiedLinesString(lines) {
	return `${lines} unmodified line${EN_PLURAL_RULES.select(lines) === "one" ? "" : "s"}`;
}
function pushUnifiedInjectedRows(rows, context) {
	for (const row of rows) {
		context.unifiedContentAST.push(row.content);
		context.pushToGutter("unified", row.gutter);
		context.incrementRowCount(1);
	}
}
function pushSplitInjectedRows(rows, context, pendingSplitContext) {
	for (const { deletion, addition } of rows) {
		if (deletion == null && addition == null) continue;
		const missingSide = deletion != null && addition != null ? void 0 : deletion == null ? "deletions" : "additions";
		if (missingSide == null || pendingSplitContext.side !== missingSide) pendingSplitContext.flush();
		if (deletion != null) {
			context.deletionsContentAST.push(deletion.content);
			context.pushToGutter("deletions", deletion.gutter);
		}
		if (addition != null) {
			context.additionsContentAST.push(addition.content);
			context.pushToGutter("additions", addition.gutter);
		}
		if (missingSide != null) {
			pendingSplitContext.side = missingSide;
			pendingSplitContext.increment();
		}
		context.incrementRowCount(1);
	}
}
function pushLineWithAnnotation({ diffStyle, type, deletionLine, additionLine, unifiedSpan, deletionSpan, additionSpan, createAnnotationElement, context }) {
	let hasAnnotationRow = false;
	if (diffStyle === "unified") {
		if (additionLine != null) context.unifiedContentAST.push(additionLine);
		else if (deletionLine != null) context.unifiedContentAST.push(deletionLine);
		if (unifiedSpan != null) {
			const lineType = type === "change" ? deletionLine != null ? "change-deletion" : "change-addition" : type;
			context.unifiedContentAST.push(createAnnotationElement(unifiedSpan));
			context.pushToGutter("unified", createGutterGap(lineType, "annotation", 1));
			hasAnnotationRow = true;
		}
	} else if (diffStyle === "split") {
		if (deletionLine != null) context.deletionsContentAST.push(deletionLine);
		if (additionLine != null) context.additionsContentAST.push(additionLine);
		if (deletionSpan != null) {
			const lineType = type === "change" ? deletionLine != null ? "change-deletion" : "context" : type;
			context.deletionsContentAST.push(createAnnotationElement(deletionSpan));
			context.pushToGutter("deletions", createGutterGap(lineType, "annotation", 1));
			hasAnnotationRow = true;
		}
		if (additionSpan != null) {
			const lineType = type === "change" ? additionLine != null ? "change-addition" : "context" : type;
			context.additionsContentAST.push(createAnnotationElement(additionSpan));
			context.pushToGutter("additions", createGutterGap(lineType, "annotation", 1));
			hasAnnotationRow = true;
		}
	}
	if (hasAnnotationRow) context.incrementRowCount(1);
}
function pushSeparator(type, { hunkIndex, collapsedLines, rangeSize, hunkSpecs, isFirstHunk, isLastHunk, isExpandable }, context) {
	if (typeof collapsedLines === "number" && collapsedLines <= 0) return;
	const linesAST = type === "unified" ? context.unifiedContentAST : type === "deletions" ? context.deletionsContentAST : context.additionsContentAST;
	if (context.hunkSeparators === "metadata") {
		if (hunkSpecs != null) {
			context.pushToGutter(type, createSeparator({
				type: "metadata",
				content: hunkSpecs,
				isFirstHunk,
				isLastHunk
			}));
			linesAST.push(createSeparator({
				type: "metadata",
				content: hunkSpecs,
				isFirstHunk,
				isLastHunk
			}));
			if (type !== "additions") context.incrementRowCount(1);
		}
		return;
	}
	if (context.hunkSeparators === "simple") {
		if (hunkIndex > 0) {
			context.pushToGutter(type, createSeparator({
				type: "simple",
				isFirstHunk,
				isLastHunk: false
			}));
			linesAST.push(createSeparator({
				type: "simple",
				isFirstHunk,
				isLastHunk: false
			}));
			if (type !== "additions") context.incrementRowCount(1);
		}
		return;
	}
	const slotName = getHunkSeparatorSlotName(type, hunkIndex);
	const chunked = rangeSize > context.expansionLineCount;
	const expandIndex = isExpandable ? hunkIndex : void 0;
	const content = typeof collapsedLines === "number" ? getModifiedLinesString(collapsedLines) : "More unchanged context may be available";
	context.pushToGutter(type, createSeparator({
		type: context.hunkSeparators,
		content,
		expandIndex,
		chunked,
		slotName,
		isFirstHunk,
		isLastHunk
	}));
	linesAST.push(createSeparator({
		type: context.hunkSeparators,
		content,
		expandIndex,
		chunked,
		slotName,
		isFirstHunk,
		isLastHunk
	}));
	if (type !== "additions") context.incrementRowCount(1);
	context.hunkData.push({
		slotName,
		hunkIndex,
		lines: typeof collapsedLines === "number" ? collapsedLines : 0,
		lineCountKnown: typeof collapsedLines === "number",
		type,
		expandable: isExpandable ? {
			up: !isFirstHunk,
			down: !isLastHunk,
			chunked
		} : void 0
	});
}
function withContentProperties(lineNode, contentProperties, extendProperties) {
	if (lineNode == null || lineNode.type !== "element" || contentProperties == null && extendProperties == null) return lineNode;
	return {
		...lineNode,
		properties: {
			...lineNode.properties,
			...contentProperties,
			...extendProperties
		}
	};
}
function contentLineCount(lines) {
	return lines.length > 0 && lines[lines.length - 1] === "" ? lines.length - 1 : lines.length;
}
function realignAdditionHastLines(previousLines, nextLines, hastLines, textDocument) {
	const previousContentLength = contentLineCount(previousLines);
	const nextContentLength = contentLineCount(nextLines);
	const maxShared = Math.min(previousContentLength, nextContentLength);
	let prefix = 0;
	while (prefix < maxShared && previousLines[prefix] === nextLines[prefix]) prefix++;
	let suffix = 0;
	while (suffix < maxShared - prefix && previousLines[previousContentLength - 1 - suffix] === nextLines[nextContentLength - 1 - suffix]) suffix++;
	const realigned = new Array(nextLines.length);
	for (let index = 0; index < prefix; index++) realigned[index] = hastLines[index];
	for (let offset = 0; offset < suffix; offset++) realigned[nextContentLength - 1 - offset] = hastLines[previousContentLength - 1 - offset];
	if (previousContentLength < previousLines.length && nextContentLength < nextLines.length) realigned[nextLines.length - 1] = hastLines[previousLines.length - 1];
	for (let index = previousLines.length; index < nextLines.length; index++) realigned[index] ??= hastLines[index];
	for (let index = prefix; index < nextLines.length; index++) realigned[index] ??= createPlainAdditionLineElement(index, textDocument.getLineText(index));
	return realigned;
}
function createPlainAdditionLineElement(lineIndex, lineText, unifiedLineIndex = lineIndex, splitLineIndex = lineIndex) {
	return {
		type: "element",
		tagName: "div",
		properties: {
			"data-line": lineIndex + 1,
			"data-line-index": `${unifiedLineIndex},${splitLineIndex}`,
			"data-line-type": "context"
		},
		children: [{
			type: "element",
			tagName: "span",
			properties: { "data-char": 0 },
			children: [{
				type: "text",
				value: lineText
			}]
		}]
	};
}
function getEditorDocumentLines(textDocument, previousLines) {
	const lines = [];
	const fallbackLineBreak = getFallbackLineBreak(previousLines);
	for (let line = 0; line < textDocument.lineCount; line++) {
		const lineText = textDocument.getLineText(line, true);
		lines.push(line < textDocument.lineCount - 1 && !hasLineBreakSuffix(lineText) ? lineText + fallbackLineBreak : lineText);
	}
	return lines;
}
function hasLineBreakSuffix(line) {
	return line.endsWith("\n") || line.endsWith("\r");
}
function getFallbackLineBreak(lines) {
	for (const line of lines) {
		if (line.endsWith("\r\n")) return "\r\n";
		if (line.endsWith("\n")) return "\n";
		if (line.endsWith("\r")) return "\r";
	}
	return "\n";
}
function isDiffMassive(diff, tokenizeMaxLength) {
	return Math.max(diff.additionLines.length, diff.deletionLines.length) > tokenizeMaxLength;
}
function canHydrateCollapsedContext$1(fileDiff, hasFileLoader) {
	return fileDiff.isPartial && hasFileLoader && (fileDiff.type === "change" || fileDiff.type === "rename-changed");
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areDiffLineAnnotationsEqual.js
function areDiffLineAnnotationsEqual(annotationA, annotationB) {
	return annotationA.lineNumber === annotationB.lineNumber && annotationA.side === annotationB.side && annotationA.metadata === annotationB.metadata;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areHunkDataEqual.js
function areHunkDataEqual(hunkA, hunkB) {
	return hunkA.slotName === hunkB.slotName && hunkA.hunkIndex === hunkB.hunkIndex && hunkA.lines === hunkB.lines && hunkA.lineCountKnown === hunkB.lineCountKnown && hunkA.type === hunkB.type && hunkA.expandable?.chunked === hunkB.expandable?.chunked && hunkA.expandable?.up === hunkB.expandable?.up && hunkA.expandable?.down === hunkB.expandable?.down;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/awaitWithTimeout.js
async function awaitWithTimeout(callback, timeout = 300) {
	let timeoutId;
	try {
		await Promise.race([callback(), new Promise((resolve) => {
			timeoutId = setTimeout(resolve, timeout);
		})]);
	} finally {
		if (timeoutId != null) clearTimeout(timeoutId);
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getDiffFileInput.js
function getDiffFileInput({ oldFile, newFile }, context) {
	if (oldFile === void 0 && newFile === void 0) return;
	if (oldFile === void 0 || newFile === void 0) throw new Error(`${context}: Pass null for an intentionally missing oldFile or newFile side`);
	if (oldFile === null) {
		if (newFile === null) throw new Error(`${context}: You must pass oldFile, newFile, or both`);
		return {
			oldFile,
			newFile
		};
	}
	if (newFile === null) return {
		oldFile,
		newFile
	};
	return {
		oldFile,
		newFile
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getDiffHunksRendererOptions.js
function getDiffHunksRendererOptions(options) {
	return {
		theme: options?.theme,
		disableLineNumbers: options?.disableLineNumbers,
		overflow: options?.overflow,
		collapsed: options?.collapsed,
		disableFileHeader: options?.disableFileHeader,
		disableVirtualizationBuffers: options?.disableVirtualizationBuffers,
		stickyHeader: options?.stickyHeader,
		preferredHighlighter: options?.preferredHighlighter,
		useCSSClasses: options?.useCSSClasses,
		useTokenTransformer: shouldUseTokenTransformer(options),
		tokenizeMaxLineLength: options?.tokenizeMaxLineLength,
		tokenizeMaxLength: options?.tokenizeMaxLength,
		diffStyle: options?.diffStyle,
		diffIndicators: options?.diffIndicators,
		disableBackground: options?.disableBackground,
		hunkSeparators: typeof options?.hunkSeparators === "function" ? "custom" : options?.hunkSeparators,
		expandUnchanged: options?.expandUnchanged,
		loadDiffFiles: options?.loadDiffFiles,
		collapsedContextThreshold: options?.collapsedContextThreshold,
		lineDiffType: options?.lineDiffType,
		maxLineDiffLength: options?.maxLineDiffLength,
		expansionLineCount: options?.expansionLineCount,
		headerRenderMode: options?.renderCustomHeader != null ? "custom" : "default"
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/FileDiff.js
function canHydrateDiff(fileDiff) {
	return fileDiff.isPartial && (fileDiff.type === "change" || fileDiff.type === "rename-changed" || fileDiff.type === "rename-pure");
}
var instanceId$2 = -1;
var FileDiff = class {
	options;
	workerManager;
	isContainerManaged;
	static LoadedCustomComponent = true;
	__id = `file-diff:${++instanceId$2}`;
	type = "file-diff";
	fileContainer;
	spriteSVG;
	pre;
	codeUnified;
	codeDeletions;
	codeAdditions;
	bufferBefore;
	bufferAfter;
	themeCSSStyle;
	appliedThemeCSS;
	hasAdoptedThemeCSS = false;
	unsafeCSSStyle;
	appliedUnsafeCSS;
	gutterUtilityContent;
	headerElement;
	headerPrefix;
	headerFilenameSuffix;
	headerMetadata;
	headerCustom;
	separatorCache = /* @__PURE__ */ new Map();
	errorWrapper;
	placeHolder;
	hunksRenderer;
	resizeManager;
	scrollSyncManager;
	interactionManager;
	annotationCache = /* @__PURE__ */ new Map();
	lineAnnotations = [];
	managersDirty = false;
	deletionFile;
	additionFile;
	fileDiff;
	renderRange;
	pendingFiles;
	appliedPreAttributes;
	lastRenderedHeaderHTML;
	cachedHeaderHTML;
	lastRowCount;
	mounted = false;
	enabled = true;
	editor;
	refreshViewTimeout;
	lineStateRefreshPending = false;
	deferredSelectedLines;
	deferredEditorActiveLine;
	constructor(options = { theme: DEFAULT_THEMES }, workerManager, isContainerManaged = false) {
		this.options = options;
		this.workerManager = workerManager;
		this.isContainerManaged = isContainerManaged;
		this.hunksRenderer = this.createHunksRenderer(options);
		this.resizeManager = new ResizeManager();
		this.scrollSyncManager = new ScrollSyncManager();
		this.interactionManager = new InteractionManager("diff", pluckInteractionOptions(options, typeof options.hunkSeparators === "function" || (options.hunkSeparators ?? "line-info") === "line-info" || options.hunkSeparators === "line-info-basic" ? this.handleExpandHunk : void 0, this.getLineIndex));
		this.workerManager?.subscribeToThemeChanges(this);
		this.enabled = true;
	}
	handleHighlightRender = () => {
		this.rerender();
	};
	getHunksRendererOptions(options) {
		return getDiffHunksRendererOptions(options);
	}
	createHunksRenderer(options) {
		return new DiffHunksRenderer(this.getHunksRendererOptions(options), this.handleHighlightRender, this.workerManager);
	}
	getLineIndex = (lineNumber, side = "additions") => {
		const fileDiff = this.fileDiffCache;
		if (fileDiff == null) return;
		const lastHunk = fileDiff.hunks.at(-1);
		let targetUnifiedIndex;
		let targetSplitIndex;
		hunkIterator: for (const hunk of fileDiff.hunks) {
			const hunkStart = side === "deletions" ? hunk.deletionStart : hunk.additionStart;
			const hunkCount = side === "deletions" ? hunk.deletionCount : hunk.additionCount;
			let currentLineNumber = getHunkSideStartBoundary(hunkStart, hunkCount) + 1;
			let splitIndex = hunk.splitLineStart;
			let unifiedIndex = hunk.unifiedLineStart;
			if (lineNumber < currentLineNumber) {
				const difference = currentLineNumber - lineNumber;
				targetUnifiedIndex = Math.max(unifiedIndex - difference, 0);
				targetSplitIndex = Math.max(splitIndex - difference, 0);
				break hunkIterator;
			}
			if (lineNumber >= currentLineNumber + hunkCount) {
				if (hunk === lastHunk) {
					const difference = lineNumber - (currentLineNumber + hunkCount);
					targetUnifiedIndex = unifiedIndex + hunk.unifiedLineCount + difference;
					targetSplitIndex = splitIndex + hunk.splitLineCount + difference;
					break hunkIterator;
				}
				continue;
			}
			for (const content of hunk.hunkContent) if (content.type === "context") if (lineNumber < currentLineNumber + content.lines) {
				const difference = lineNumber - currentLineNumber;
				targetSplitIndex = splitIndex + difference;
				targetUnifiedIndex = unifiedIndex + difference;
				break hunkIterator;
			} else {
				currentLineNumber += content.lines;
				splitIndex += content.lines;
				unifiedIndex += content.lines;
			}
			else {
				const sideCount = side === "deletions" ? content.deletions : content.additions;
				if (lineNumber < currentLineNumber + sideCount) {
					const indexDifference = lineNumber - currentLineNumber;
					targetUnifiedIndex = unifiedIndex + (side === "additions" ? content.deletions : 0) + indexDifference;
					targetSplitIndex = splitIndex + indexDifference;
					break hunkIterator;
				} else {
					currentLineNumber += sideCount;
					splitIndex += Math.max(content.deletions, content.additions);
					unifiedIndex += content.deletions + content.additions;
				}
			}
			break hunkIterator;
		}
		if (targetUnifiedIndex == null || targetSplitIndex == null) return;
		return [targetUnifiedIndex, targetSplitIndex];
	};
	setOptions(options) {
		if (options == null) return;
		this.options = options;
		this.cachedHeaderHTML = void 0;
		this.hunksRenderer.setOptions(this.getHunksRendererOptions(options));
		this.syncInteractionOptions();
	}
	syncInteractionOptions() {
		this.interactionManager.setOptions(pluckInteractionOptions(this.options, typeof this.options.hunkSeparators === "function" || (this.options.hunkSeparators ?? "line-info") === "line-info" || this.options.hunkSeparators === "line-info-basic" ? this.handleExpandHunk : void 0, this.getLineIndex));
	}
	mergeOptions(options) {
		this.options = {
			...this.options,
			...options
		};
	}
	setThemeType(themeType) {
		if ((this.options.themeType ?? "system") === themeType) return;
		this.mergeOptions({ themeType });
		this.applyCachedThemeState(themeType);
	}
	applyCachedThemeState(themeType) {
		if (typeof this.options.theme === "string" || this.fileContainer == null || this.appliedThemeCSS == null) return false;
		const effectiveThemeType = this.appliedThemeCSS.baseThemeType ?? themeType;
		if (this.appliedThemeCSS.themeType === effectiveThemeType) return false;
		this.applyThemeState(this.fileContainer, this.appliedThemeCSS.themeStyles, themeType, this.appliedThemeCSS.baseThemeType);
		return true;
	}
	hasThemeChanged() {
		return this.appliedThemeCSS != null && !areThemesEqual(this.appliedThemeCSS.theme, this.options.theme ?? DEFAULT_THEMES);
	}
	getHoveredLine = () => {
		return this.interactionManager.getHoveredLine();
	};
	setLineAnnotations(lineAnnotations) {
		this.lineAnnotations = lineAnnotations;
	}
	canPartiallyRender(forceRender, annotationsChanged, didContentChange) {
		if (forceRender || annotationsChanged || didContentChange || typeof this.options.hunkSeparators === "function") return false;
		return true;
	}
	setSelectedLines(range, options) {
		if (this.lineStateRefreshPending) this.deferredSelectedLines = [range, options];
		else this.interactionManager.setSelection(range, options);
	}
	setEditorActiveLine(lineNumber, options) {
		if (this.lineStateRefreshPending) this.deferredEditorActiveLine = [lineNumber, options];
		else this.interactionManager.setEditorActiveLine(lineNumber, {
			lineNumberOnly: options?.lineNumberOnly,
			side: options?.side ?? "additions"
		});
	}
	flushDeferredLineState() {
		const { deferredEditorActiveLine: editorActiveLine, deferredSelectedLines: selectedLines } = this;
		this.lineStateRefreshPending = false;
		this.deferredEditorActiveLine = void 0;
		this.deferredSelectedLines = void 0;
		if (editorActiveLine != null) this.setEditorActiveLine(...editorActiveLine);
		if (selectedLines != null) this.interactionManager.setSelection(...selectedLines);
	}
	flushManagers() {
		if (!this.managersDirty || this.pre == null) {
			this.managersDirty = false;
			return;
		}
		const { diffStyle = "split", overflow = "scroll" } = this.options;
		this.interactionManager.setup(this.pre);
		this.resizeManager.setup(this.pre, {
			disableAnnotations: overflow === "wrap",
			columnVariables: this.shouldApplyColumnVariables(overflow) ? "apply" : "measure"
		});
		if (overflow === "scroll" && diffStyle === "split") this.scrollSyncManager.setup(this.pre, this.codeDeletions, this.codeAdditions);
		else this.scrollSyncManager.cleanUp();
		this.managersDirty = false;
	}
	shouldApplyColumnVariables(overflow) {
		if (typeof this.options.hunkSeparators === "function") return true;
		return overflow === "scroll" && (this.lineAnnotations.length > 0 || this.pre?.hasAttribute("data-has-merge-conflict") === true);
	}
	getCodeScrollLeft() {
		return Math.max(this.codeUnified?.scrollLeft ?? 0, this.codeDeletions?.scrollLeft ?? 0, this.codeAdditions?.scrollLeft ?? 0);
	}
	setCodeScrollLeft(position) {
		if (this.codeUnified != null) this.codeUnified.scrollLeft = position;
		if (this.codeAdditions != null) this.codeAdditions.scrollLeft = position;
		if (this.codeDeletions != null) this.codeDeletions.scrollLeft = position;
	}
	__getEffectiveCodeOptions() {
		return {
			...this.options,
			...this.hunksRenderer.getEffectiveCodeOptions()
		};
	}
	cleanUp(recycle = false) {
		dequeueRender(this.handleEditSessionRender);
		this.emitPostRender(true);
		this.editor?.cleanUp(recycle);
		this.editor = void 0;
		this.resizeManager.cleanUp();
		this.interactionManager.cleanUp();
		this.scrollSyncManager.cleanUp();
		this.managersDirty = false;
		this.workerManager?.unsubscribeToThemeChanges(this);
		this.renderRange = void 0;
		this.pendingFiles = void 0;
		if (!this.isContainerManaged) this.fileContainer?.remove();
		this.fileContainer = void 0;
		this.mounted = false;
		if (!recycle) this.lineAnnotations = [];
		this.clearAuxiliaryNodes();
		this.annotationCache.clear();
		this.pre = void 0;
		this.codeUnified = void 0;
		this.codeDeletions = void 0;
		this.codeAdditions = void 0;
		this.bufferBefore?.remove();
		this.bufferBefore = void 0;
		this.bufferAfter?.remove();
		this.bufferAfter = void 0;
		this.appliedPreAttributes = void 0;
		this.headerElement = void 0;
		this.headerPrefix = void 0;
		this.headerFilenameSuffix = void 0;
		this.headerMetadata = void 0;
		this.headerCustom = void 0;
		this.placeHolder?.remove();
		this.placeHolder = void 0;
		this.lastRenderedHeaderHTML = void 0;
		if (!recycle) this.cachedHeaderHTML = void 0;
		this.errorWrapper?.remove();
		this.errorWrapper = void 0;
		this.spriteSVG = void 0;
		this.lastRowCount = void 0;
		this.themeCSSStyle = void 0;
		this.appliedThemeCSS = void 0;
		this.hasAdoptedThemeCSS = false;
		this.unsafeCSSStyle = void 0;
		this.appliedUnsafeCSS = void 0;
		if (recycle) this.hunksRenderer.recycle();
		else {
			this.hunksRenderer.cleanUp();
			this.workerManager = void 0;
			this.fileDiff = void 0;
			this.deletionFile = void 0;
			this.additionFile = void 0;
		}
		if (this.refreshViewTimeout != null) {
			clearTimeout(this.refreshViewTimeout);
			this.refreshViewTimeout = void 0;
		}
		this.lineStateRefreshPending = false;
		this.deferredEditorActiveLine = void 0;
		this.deferredSelectedLines = void 0;
		this.enabled = false;
	}
	virtualizedSetup() {
		this.enabled = true;
		this.workerManager?.subscribeToThemeChanges(this);
	}
	hydrate({ fileContainer, prerenderedHTML, preventEmit = false, lineAnnotations, fileDiff, ...fileInputProps }) {
		if (!this.enabled) throw new Error("FileDiff.hydrate: attempting to call hydrate after cleaned up");
		if (this.fileContainer != null) throw new Error("FileDiff.hydrate: hydrate can only be called before the instance has rendered or hydrated");
		const fileInput = getDiffFileInput(fileInputProps, "FileDiff.hydrate");
		const oldFile = fileInput?.oldFile;
		const newFile = fileInput?.newFile;
		this.hydrateElements(fileContainer, prerenderedHTML);
		if (shouldRenderCode$1(this.pre, hasDiffContent({
			fileDiff,
			oldFile,
			newFile
		}), this.options.collapsed) || shouldRenderHeader$1(this.headerElement, hasDiffHeaderContent({
			fileDiff,
			oldFile,
			newFile
		}), this.options.disableFileHeader)) this.render({
			...fileInputProps,
			fileContainer,
			lineAnnotations,
			fileDiff,
			preventEmit: true
		});
		else this.hydrationSetup({
			fileDiff,
			lineAnnotations,
			...fileInput
		});
		if (!preventEmit) this.emitPostRender();
	}
	hydrateElements(fileContainer, prerenderedHTML) {
		if (this.fileContainer !== fileContainer) this.emitPostRender(true);
		prerenderHTMLIfNecessary(fileContainer, prerenderedHTML);
		for (const element of fileContainer.shadowRoot?.children ?? []) {
			if (element instanceof SVGElement) {
				this.spriteSVG = element;
				continue;
			}
			if (!(element instanceof HTMLElement)) continue;
			if (element instanceof HTMLPreElement) {
				this.pre = element;
				for (const code of element.children) {
					if (!(code instanceof HTMLElement) || code.tagName.toLowerCase() !== "code") continue;
					if ("deletions" in code.dataset) this.codeDeletions = code;
					if ("additions" in code.dataset) this.codeAdditions = code;
					if ("unified" in code.dataset) this.codeUnified = code;
				}
				continue;
			}
			if ("diffsHeader" in element.dataset) {
				this.headerElement = element;
				continue;
			}
			if (element instanceof HTMLStyleElement && element.hasAttribute("data-theme-css")) {
				this.themeCSSStyle = element;
				continue;
			}
			if (element instanceof HTMLStyleElement && element.hasAttribute("data-unsafe-css")) {
				this.unsafeCSSStyle = element;
				this.appliedUnsafeCSS = element.textContent;
				continue;
			}
		}
		if (this.pre != null) {
			this.syncCodeNodesFromPre(this.pre);
			this.pre.removeAttribute("data-dehydrated");
		}
		this.fileContainer = fileContainer;
		this.hydrateMeasuredScrollbar();
	}
	hydrationSetup({ fileDiff, oldFile, newFile, lineAnnotations }) {
		this.lineAnnotations = lineAnnotations ?? this.lineAnnotations;
		this.additionFile = newFile;
		this.deletionFile = oldFile;
		this.fileDiff = fileDiff ?? (oldFile !== void 0 && newFile !== void 0 ? parseDiffFromFile(oldFile, newFile, this.options.parseDiffOptions) : void 0);
		if (this.pre == null) return;
		this.syncInteractionOptions();
		this.hunksRenderer.hydrate(this.fileDiff);
		this.renderAnnotations();
		this.renderGutterUtility();
		this.injectUnsafeCSS();
		this.managersDirty = true;
		this.flushManagers();
	}
	rerender() {
		if (!this.enabled || this.fileDiff == null && this.additionFile == null && this.deletionFile == null) return;
		this.render({
			forceRender: true,
			renderRange: this.renderRange
		});
	}
	onThemeChange() {
		this.hunksRenderer.clearRenderCache();
		this.rerender();
	}
	handleExpandHunk = (hunkIndex, direction, expansionLineCountOverride) => {
		this.expandHunk(hunkIndex, direction, expansionLineCountOverride);
	};
	expandHunk = (hunkIndex, direction, expansionLineCountOverride) => {
		this.hunksRenderer.expandHunk(hunkIndex, direction, expansionLineCountOverride);
		this.loadFilesIfNecessary();
		this.rerender();
	};
	loadFilesIfNecessary() {
		const { fileDiff, options: { loadDiffFiles } } = this;
		if (fileDiff == null || loadDiffFiles == null || !canHydrateDiff(fileDiff) || this.pendingFiles?.fileDiff === fileDiff) return;
		this.pendingFiles = {
			fileDiff,
			promise: this.loadFilesForDiff(fileDiff, loadDiffFiles)
		};
	}
	async loadFilesForDiff(fileDiff, loadDiffFiles) {
		try {
			const files = await loadDiffFiles(fileDiff);
			if (!this.enabled || this.fileDiff !== fileDiff) return;
			await this.handleFilesLoaded(fileDiff, files);
		} catch (error) {
			if (this.options.disableErrorHandling === true) throw error;
			console.error(error);
		} finally {
			if (this.pendingFiles?.fileDiff === fileDiff) this.pendingFiles = void 0;
		}
	}
	async handleFilesLoaded(expectedDiff, files) {
		if (this.fileDiff !== expectedDiff || !expectedDiff.isPartial) return;
		hydratePartialDiff("merge", expectedDiff, files);
		this.setHydratedState(files);
		await awaitWithTimeout(() => this.primeHighlightCache(expectedDiff));
		if (!this.enabled || this.fileDiff !== expectedDiff) return;
		this.rerender();
	}
	setHydratedState(files) {
		this.deletionFile = files.oldFile;
		this.additionFile = files.newFile;
		this.workerManager?.cleanUpTasks(this.hunksRenderer);
		this.hunksRenderer.clearRenderCache();
	}
	render({ fileDiff, deferManagers = false, forceRender = false, preventEmit = false, lineAnnotations, fileContainer, containerWrapper, renderRange, ...fileInputProps }) {
		const fileInput = getDiffFileInput(fileInputProps, "FileDiff.render");
		const oldFile = fileInput?.oldFile;
		const newFile = fileInput?.newFile;
		if (!this.enabled) throw new Error("FileDiff.render: attempting to call render after cleaned up");
		if (fileDiff != null && fileDiff.cacheKey === void 0) fileDiff.cacheKey = fileDiff.prevName != null ? fileDiff.prevName + ":" + fileDiff.name : fileDiff.name;
		this.editor?.__postponeBgTokenizeToNextFrame();
		const { collapsed = false, themeType = "system", expandUnchanged = false } = this.options;
		const nextRenderRange = collapsed ? void 0 : renderRange;
		const themeChanged = this.hasThemeChanged();
		const hasFileInput = fileInput != null;
		const filesDidChange = hasFileInput && (!areOptionalFilesEqual$1(oldFile, this.deletionFile) || !areOptionalFilesEqual$1(newFile, this.additionFile));
		let diffDidChange = fileDiff != null && fileDiff !== this.fileDiff;
		const annotationsChanged = lineAnnotations != null && (lineAnnotations.length > 0 || this.lineAnnotations.length > 0) ? lineAnnotations !== this.lineAnnotations : false;
		if (!collapsed && areRenderRangesEqual(nextRenderRange, this.renderRange) && !forceRender && !annotationsChanged && !themeChanged && (fileDiff != null && fileDiff === this.fileDiff || fileDiff == null && !filesDidChange)) return this.applyCachedThemeState(themeType);
		let nextParsedFileDiff;
		if (fileDiff == null && hasFileInput && (filesDidChange || this.fileDiff == null)) nextParsedFileDiff = parseDiffFromFile(fileInput.oldFile, fileInput.newFile, this.options.parseDiffOptions);
		const { renderRange: previousRenderRange } = this;
		this.renderRange = nextRenderRange;
		if (hasFileInput) {
			this.deletionFile = oldFile;
			this.additionFile = newFile;
		} else if (fileDiff != null) {
			this.deletionFile = void 0;
			this.additionFile = void 0;
		}
		if (fileDiff != null) this.fileDiff = fileDiff;
		else if (nextParsedFileDiff != null) {
			diffDidChange = true;
			this.fileDiff = nextParsedFileDiff;
		}
		if (diffDidChange) this.cachedHeaderHTML = void 0;
		if (lineAnnotations != null) this.setLineAnnotations(lineAnnotations);
		if (this.fileDiff == null) return false;
		if (this.fileDiff.editSessionDirty === true && this.shouldSelfHealEditSession()) {
			finishEditSessionForDiff(this.fileDiff, this.options.parseDiffOptions);
			this.hunksRenderer.refreshHighlightedResult();
		}
		if (expandUnchanged) this.loadFilesIfNecessary();
		this.hunksRenderer.setOptions(this.getHunksRendererOptions(this.options));
		this.syncInteractionOptions();
		this.hunksRenderer.setLineAnnotations(this.lineAnnotations);
		const { disableErrorHandling = false, disableFileHeader = false } = this.options;
		if (disableFileHeader) {
			if (this.headerElement != null) {
				this.headerElement.remove();
				this.headerElement = void 0;
				this.lastRenderedHeaderHTML = void 0;
			}
			this.clearHeaderSlots();
		}
		fileContainer = this.getOrCreateFileContainer(fileContainer, containerWrapper);
		this.applyCachedThemeState(themeType);
		if (collapsed) {
			this.removeRenderedCode();
			this.clearAuxiliaryNodes();
			try {
				const hunksResult = this.hunksRenderer.renderDiff(this.fileDiff, EMPTY_RENDER_RANGE);
				if (hunksResult != null) this.applyThemeState(fileContainer, hunksResult.themeStyles, themeType, hunksResult.baseThemeType);
				if (hunksResult?.headerElement != null) this.applyHeaderToDOM(hunksResult.headerElement, fileContainer);
				this.renderSeparators([]);
				this.injectUnsafeCSS();
			} catch (error) {
				if (disableErrorHandling) throw error;
				console.error(error);
				if (error instanceof Error) this.applyErrorToDOM(error, fileContainer);
			}
			if (!preventEmit) this.emitPostRender();
			return true;
		}
		try {
			const pre = this.getOrCreatePreNode(fileContainer);
			if (!(this.canPartiallyRender(forceRender, annotationsChanged, filesDidChange || diffDidChange || themeChanged) && this.applyPartialRender({
				previousRenderRange,
				renderRange: nextRenderRange
			}))) {
				const hunksResult = this.hunksRenderer.renderDiff(this.fileDiff, nextRenderRange);
				if (hunksResult == null) {
					if (this.workerManager?.isInitialized() === false) this.workerManager.initialize().then(() => this.rerender());
					return false;
				}
				this.applyThemeState(fileContainer, hunksResult.themeStyles, themeType, hunksResult.baseThemeType);
				if (hunksResult.headerElement != null) this.applyHeaderToDOM(hunksResult.headerElement, fileContainer);
				if (hunksResult.additionsContentAST != null || hunksResult.deletionsContentAST != null || hunksResult.unifiedContentAST != null) this.applyHunksToDOM(pre, hunksResult);
				else if (this.pre != null) {
					this.pre.remove();
					this.pre = void 0;
				}
				this.renderSeparators(hunksResult.hunkData);
			}
			this.applyBuffers(pre, nextRenderRange);
			this.injectUnsafeCSS();
			this.renderAnnotations();
			this.renderGutterUtility();
			this.managersDirty = true;
			if (!deferManagers) this.flushManagers();
			if (this.editor != null) this.syncRenderViewToEditor();
		} catch (error) {
			if (disableErrorHandling) throw error;
			console.error(error);
			if (error instanceof Error) this.applyErrorToDOM(error, fileContainer);
		}
		if (!preventEmit) this.emitPostRender();
		return true;
	}
	emitPostRender(unmount = false) {
		const { fileContainer, options: { onPostRender } } = this;
		if (unmount) {
			if (!this.mounted) return;
			this.mounted = false;
			if (fileContainer == null) return;
			this.options.onPostRender?.(fileContainer, this, "unmount");
			return;
		}
		if (fileContainer == null) return;
		const phase = this.mounted ? "update" : "mount";
		this.mounted = true;
		onPostRender?.(fileContainer, this, phase);
	}
	get fileDiffCache() {
		return this.hunksRenderer.diffCache ?? this.fileDiff;
	}
	syncRenderViewToEditor() {
		const editor = this.editor;
		const fileContainer = this.fileContainer;
		const fileDiff = this.fileDiffCache;
		const lineAnnotations = this.lineAnnotations;
		const renderRange = this.computeEditorRenderRange(this.renderRange);
		if (editor != null && fileContainer != null && fileDiff != null && !fileDiff.isPartial) this.hunksRenderer.initializeHighlighter().then((highlighter) => {
			if (!this.enabled || this.editor !== editor || this.fileContainer !== fileContainer || this.fileDiffCache !== fileDiff) return;
			editor.__syncRenderView(highlighter, fileContainer, fileDiff, lineAnnotations, renderRange);
		});
	}
	computeEditorRenderRange(renderRange) {
		const fileDiff = this.fileDiffCache;
		if (renderRange == null || fileDiff == null || isDefaultRenderRange(renderRange)) return renderRange;
		const { diffStyle = "split", expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		let firstLineNumber;
		let lastLineNumber;
		iterateOverDiff({
			diff: fileDiff,
			diffStyle,
			startingLine: renderRange.startingLine,
			totalLines: renderRange.totalLines,
			expandedHunks: expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold,
			callback: ({ additionLine }) => {
				if (additionLine != null) {
					firstLineNumber ??= additionLine.lineNumber;
					lastLineNumber = additionLine.lineNumber;
				}
			}
		});
		if (firstLineNumber == null || lastLineNumber == null) return {
			...renderRange,
			startingLine: 0,
			totalLines: 0
		};
		return {
			...renderRange,
			startingLine: firstLineNumber - 1,
			totalLines: lastLineNumber - firstLineNumber + 1
		};
	}
	attachEditor(editor) {
		if (this.type !== "file-diff") throw new Error(`FileDiff.attachEditor: cannot attach an editor to a "${this.type}" diff`);
		this.editor?.cleanUp();
		this.editor = editor;
		this.hunksRenderer.beginEditSession();
		if (this.fileDiff?.isPartial === true) this.loadFilesIfNecessary();
		if (this.hunksRenderer.editorRenderReady()) this.syncRenderViewToEditor();
		else this.rerender();
		return (recycle) => {
			this.editor = void 0;
			if (recycle !== true) this.finishEditSession();
		};
	}
	finishEditSession() {
		this.hunksRenderer.endEditSession();
		this.completeEditSession();
	}
	/**
	* Run the genuine session-end recompute: restore recompute-shaped hunks (a
	* context-only region collapses away, boundaries re-derive), preserve
	* expansion state best-effort via old-side anchors, and repaint through
	* the session render path — which also invalidates virtualized layout,
	* since nothing else does at exit now that editing does not flip
	* expandUnchanged. Marker-guarded and idempotent; CodeView also calls this
	* when reaping a session whose detach closure was consumed by a recycle.
	* Safe on a cleaned-up instance: the recompute is pure metadata work and
	* the deferred rerender is enabled-guarded. Returns true when a recompute
	* ran.
	*/
	completeEditSession() {
		const fileDiff = this.fileDiffCache;
		if (fileDiff == null || fileDiff.editSessionDirty !== true) return false;
		const { collapsedContextThreshold = 1 } = this.options;
		const anchors = captureExpansionAnchors(fileDiff, this.hunksRenderer.getExpandedHunksMap(), collapsedContextThreshold);
		finishEditSessionForDiff(fileDiff, this.options.parseDiffOptions);
		this.hunksRenderer.setExpandedHunksMap(rebuildExpansionFromAnchors(fileDiff, anchors));
		this.hunksRenderer.refreshHighlightedResult();
		this.escalateEditSessionRender();
		return true;
	}
	applyDocumentChange(textDocument, newLineAnnotations) {
		this.hunksRenderer.applyDocumentChange(textDocument);
		const fileDiff = this.hunksRenderer.diffCache;
		if (fileDiff != null) {
			const cacheKey = this.fileDiff?.cacheKey;
			if (cacheKey != null && fileDiff.cacheKey == null) fileDiff.cacheKey = cacheKey;
			this.fileDiff = fileDiff;
		}
		if (newLineAnnotations !== void 0 && newLineAnnotations !== this.lineAnnotations) {
			this.setLineAnnotations(newLineAnnotations);
			this.hunksRenderer.setLineAnnotations(this.lineAnnotations);
			this.renderAnnotations();
		}
		this.rerender();
		this.interactionManager.setSelectionDirty();
	}
	updateRenderCache(dirtyLines, themeType, options = {}) {
		const { shouldRefreshDiffsView, lineCountChangeInFlight } = options;
		if (this.hunksRenderer.updateRenderCache(dirtyLines, themeType, lineCountChangeInFlight)) {
			if (this.refreshViewTimeout != null) {
				clearTimeout(this.refreshViewTimeout);
				this.refreshViewTimeout = void 0;
			}
			this.lineStateRefreshPending = true;
			this.escalateEditSessionRender();
			return;
		}
		if (shouldRefreshDiffsView === true) {
			if (this.refreshViewTimeout != null) clearTimeout(this.refreshViewTimeout);
			this.lineStateRefreshPending = true;
			this.refreshViewTimeout = setTimeout(() => {
				this.refreshViewTimeout = void 0;
				if (this.options.diffStyle === "split") this.refreshSplitDiffView();
				else this.refreshUnifiedDiffView();
				this.flushDeferredLineState();
			}, 150);
		}
	}
	isLineRenderable(lineNumber) {
		const fileDiff = this.fileDiffCache;
		if (fileDiff == null) return true;
		const { expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		return isAdditionLineRenderable({
			fileDiff,
			lineNumber,
			expandedHunks: expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold
		});
	}
	getNearestRenderableLine(lineNumber, direction) {
		const fileDiff = this.fileDiffCache;
		if (fileDiff == null) return lineNumber;
		const { expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		return getNearestRenderableAdditionLine({
			fileDiff,
			lineNumber,
			direction,
			expandedHunks: expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold
		});
	}
	revealLine(lineNumber) {
		const fileDiff = this.fileDiffCache;
		const { expandUnchanged = false, collapsedContextThreshold = 1, expansionLineCount = 100 } = this.options;
		if (fileDiff == null || fileDiff.isPartial || expandUnchanged) return false;
		const expandedHunks = this.hunksRenderer.getExpandedHunksMap();
		for (const [hunkIndex, hunk] of fileDiff.hunks.entries()) {
			const [hunkStart, hunkEnd] = getHunkAdditionLineRange(hunk);
			if (lineNumber < hunkStart) {
				const region = getExpandedRegion({
					isPartial: fileDiff.isPartial,
					rangeSize: hunk.collapsedBefore,
					expandedHunks,
					hunkIndex,
					collapsedContextThreshold
				});
				const gapStart = hunkStart - region.rangeSize;
				if (region.renderAll || lineNumber < gapStart + region.fromStart || lineNumber >= hunkStart - region.fromEnd) return false;
				const fromStartDistance = lineNumber - (gapStart + region.fromStart) + 1;
				const fromEndDistance = hunkStart - region.fromEnd - lineNumber;
				if (fromStartDistance <= fromEndDistance) this.expandHunk(hunkIndex, "up", fromStartDistance + expansionLineCount);
				else this.expandHunk(hunkIndex, "down", fromEndDistance + expansionLineCount);
				return true;
			}
			if (lineNumber < hunkEnd) return false;
		}
		const trailingRegion = getTrailingExpandedRegion({
			fileDiff,
			hunkIndex: fileDiff.hunks.length - 1,
			expandedHunks,
			collapsedContextThreshold,
			errorPrefix: "FileDiff.revealLine"
		});
		if (trailingRegion == null || trailingRegion.renderAll) return false;
		const lastHunk = fileDiff.hunks[fileDiff.hunks.length - 1];
		const [, trailingStart] = getHunkAdditionLineRange(lastHunk);
		if (lineNumber < trailingStart + trailingRegion.fromStart || lineNumber >= trailingStart + trailingRegion.rangeSize) return false;
		this.expandHunk(fileDiff.hunks.length, "up", lineNumber - (trailingStart + trailingRegion.fromStart) + 1 + expansionLineCount);
		return true;
	}
	shouldSelfHealEditSession() {
		return this.editor == null;
	}
	escalateEditSessionRender() {
		queueRender(this.handleEditSessionRender);
	}
	handleEditSessionRender = () => {
		this.rerender();
		this.flushDeferredLineState();
	};
	removeRenderedCode() {
		this.resizeManager.cleanUp();
		this.scrollSyncManager.cleanUp();
		this.interactionManager.cleanUp();
		this.bufferBefore?.remove();
		this.bufferBefore = void 0;
		this.bufferAfter?.remove();
		this.bufferAfter = void 0;
		this.codeUnified?.remove();
		this.codeUnified = void 0;
		this.codeDeletions?.remove();
		this.codeDeletions = void 0;
		this.codeAdditions?.remove();
		this.codeAdditions = void 0;
		this.pre?.remove();
		this.pre = void 0;
		this.appliedPreAttributes = void 0;
		this.lastRowCount = void 0;
	}
	clearAuxiliaryNodes() {
		for (const { element } of this.separatorCache.values()) element.remove();
		this.separatorCache.clear();
		for (const { element } of this.annotationCache.values()) element.remove();
		this.annotationCache.clear();
		this.gutterUtilityContent?.remove();
		this.gutterUtilityContent = void 0;
	}
	renderPlaceholder(height) {
		if (this.fileContainer == null) return false;
		this.emitPostRender(true);
		this.cleanChildNodes();
		if (this.placeHolder == null) {
			const shadowRoot = this.fileContainer.shadowRoot ?? this.fileContainer.attachShadow({ mode: "open" });
			this.placeHolder = document.createElement("div");
			this.placeHolder.dataset.placeholder = "";
			shadowRoot.appendChild(this.placeHolder);
		}
		this.placeHolder.style.setProperty("height", `${height}px`);
		return true;
	}
	async primeHighlightCache(fileDiff = this.fileDiff) {
		const { workerManager } = this;
		if (fileDiff == null || workerManager == null || !workerManager.isWorkingPool() || fileDiff.cacheKey == null || isDiffPlainText(fileDiff)) return;
		const tokenizeMaxLength = this.options.tokenizeMaxLength ?? 1e5;
		if (Math.max(fileDiff.additionLines.length, fileDiff.deletionLines.length) > tokenizeMaxLength) return;
		await workerManager.primeDiffHighlightCache(fileDiff).catch((error) => {
			console.error(error);
		});
	}
	cleanChildNodes() {
		this.resizeManager.cleanUp();
		this.scrollSyncManager.cleanUp();
		this.interactionManager.cleanUp();
		this.clearAuxiliaryNodes();
		this.bufferAfter?.remove();
		this.bufferBefore?.remove();
		this.codeAdditions?.remove();
		this.codeDeletions?.remove();
		this.codeUnified?.remove();
		this.errorWrapper?.remove();
		this.headerElement?.remove();
		this.headerPrefix?.remove();
		this.headerFilenameSuffix?.remove();
		this.headerMetadata?.remove();
		this.headerCustom?.remove();
		this.pre?.remove();
		this.spriteSVG?.remove();
		this.themeCSSStyle?.remove();
		this.unsafeCSSStyle?.remove();
		this.bufferAfter = void 0;
		this.bufferBefore = void 0;
		this.codeAdditions = void 0;
		this.codeDeletions = void 0;
		this.codeUnified = void 0;
		this.errorWrapper = void 0;
		this.headerElement = void 0;
		this.headerPrefix = void 0;
		this.headerFilenameSuffix = void 0;
		this.headerMetadata = void 0;
		this.headerCustom = void 0;
		this.pre = void 0;
		this.spriteSVG = void 0;
		this.themeCSSStyle = void 0;
		this.appliedThemeCSS = void 0;
		this.hasAdoptedThemeCSS = false;
		this.unsafeCSSStyle = void 0;
		this.appliedUnsafeCSS = void 0;
		this.lastRenderedHeaderHTML = void 0;
		this.lastRowCount = void 0;
		this.mounted = false;
	}
	renderSeparators(hunkData) {
		const { hunkSeparators } = this.options;
		if (this.isContainerManaged || this.fileContainer == null || typeof hunkSeparators !== "function") {
			for (const { element } of this.separatorCache.values()) element.remove();
			this.separatorCache.clear();
			return;
		}
		const staleSeparators = new Map(this.separatorCache);
		for (const hunk of hunkData) {
			const id = hunk.slotName;
			let cache = this.separatorCache.get(id);
			if (cache == null || !areHunkDataEqual(hunk, cache.hunkData)) {
				cache?.element.remove();
				const element = document.createElement("div");
				element.style.display = "contents";
				element.slot = hunk.slotName;
				const child = hunkSeparators(hunk, this);
				if (child != null) element.appendChild(child);
				this.fileContainer.appendChild(element);
				cache = {
					element,
					hunkData: hunk
				};
				this.separatorCache.set(id, cache);
			}
			staleSeparators.delete(id);
		}
		for (const [id, { element }] of staleSeparators.entries()) {
			this.separatorCache.delete(id);
			element.remove();
		}
	}
	renderAnnotations() {
		if (this.isContainerManaged || this.fileContainer == null) {
			for (const { element } of this.annotationCache.values()) element.remove();
			this.annotationCache.clear();
			return;
		}
		const staleAnnotations = new Map(this.annotationCache);
		const { renderAnnotation } = this.options;
		if (renderAnnotation != null && this.lineAnnotations.length > 0) for (const [index, annotation] of this.lineAnnotations.entries()) {
			const id = `${index}-${getLineAnnotationName(annotation)}`;
			let cache = this.annotationCache.get(id);
			if (cache == null || !areDiffLineAnnotationsEqual(annotation, cache.annotation)) {
				cache?.element.remove();
				const content = renderAnnotation(annotation);
				if (content == null) continue;
				cache = {
					element: createAnnotationWrapperNode(getLineAnnotationName(annotation)),
					annotation
				};
				cache.element.appendChild(content);
				this.fileContainer.appendChild(cache.element);
				this.annotationCache.set(id, cache);
			}
			staleAnnotations.delete(id);
		}
		for (const [id, { element }] of staleAnnotations.entries()) {
			this.annotationCache.delete(id);
			element.remove();
		}
	}
	renderGutterUtility() {
		const { renderGutterUtility } = this.options;
		if (this.fileContainer == null || renderGutterUtility == null) {
			this.gutterUtilityContent?.remove();
			this.gutterUtilityContent = void 0;
			return;
		}
		const element = renderGutterUtility(this.interactionManager.getHoveredLine);
		if (element != null && this.gutterUtilityContent != null) return;
		else if (element == null) {
			this.gutterUtilityContent?.remove();
			this.gutterUtilityContent = void 0;
			return;
		}
		const gutterUtilityContent = createGutterUtilityContentNode();
		gutterUtilityContent.appendChild(element);
		this.fileContainer.appendChild(gutterUtilityContent);
		this.gutterUtilityContent = gutterUtilityContent;
	}
	getOrCreateFileContainer(fileContainer, parentNode) {
		const { fileContainer: previousContainer } = this;
		const nextContainer = fileContainer ?? previousContainer ?? document.createElement("diffs-container");
		const containerChanged = previousContainer !== nextContainer;
		if (previousContainer != null && containerChanged) this.editor?.__captureFocusForDOMReplacement();
		if (containerChanged) this.emitPostRender(true);
		this.fileContainer = nextContainer;
		if (previousContainer != null && containerChanged) {
			this.lastRenderedHeaderHTML = void 0;
			this.headerElement = void 0;
		}
		if (parentNode != null && this.fileContainer.parentNode !== parentNode) parentNode.appendChild(this.fileContainer);
		if (containerChanged) this.adoptReusableShellElements(this.fileContainer);
		this.ensureSpriteSVG(this.fileContainer);
		return this.fileContainer;
	}
	adoptReusableShellElements(fileContainer) {
		const { shadowRoot } = fileContainer;
		if (shadowRoot == null) return;
		for (const element of shadowRoot.children) if (element instanceof SVGElement) this.spriteSVG ??= element;
		else if (isStyleNode(element) && element.hasAttribute("data-theme-css")) {
			this.themeCSSStyle ??= element;
			this.hasAdoptedThemeCSS = true;
		} else if (isStyleNode(element) && element.hasAttribute("data-unsafe-css")) {
			this.unsafeCSSStyle ??= element;
			this.appliedUnsafeCSS ??= this.options.unsafeCSS ?? void 0;
		}
	}
	ensureSpriteSVG(fileContainer) {
		const shadowRoot = fileContainer.shadowRoot ?? fileContainer.attachShadow({ mode: "open" });
		if (this.spriteSVG == null) {
			const fragment = document.createElement("div");
			fragment.innerHTML = SVGSpriteSheet;
			const firstChild = fragment.firstChild;
			if (firstChild instanceof SVGElement) this.spriteSVG = firstChild;
		}
		if (this.spriteSVG != null && this.spriteSVG.parentNode !== shadowRoot) shadowRoot.appendChild(this.spriteSVG);
	}
	getOrCreatePreNode(container) {
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		if (this.pre == null) {
			this.pre = document.createElement("pre");
			this.appliedPreAttributes = void 0;
			this.codeUnified = void 0;
			this.codeDeletions = void 0;
			this.codeAdditions = void 0;
			shadowRoot.appendChild(this.pre);
		} else if (this.pre.parentNode !== shadowRoot) {
			this.editor?.__captureFocusForDOMReplacement();
			shadowRoot.appendChild(this.pre);
			this.appliedPreAttributes = void 0;
		}
		this.placeHolder?.remove();
		this.placeHolder = void 0;
		return this.pre;
	}
	syncCodeNodesFromPre(pre) {
		this.codeUnified = void 0;
		this.codeDeletions = void 0;
		this.codeAdditions = void 0;
		for (const child of Array.from(pre.children)) {
			if (!(child instanceof HTMLElement)) continue;
			if (child.hasAttribute("data-unified")) this.codeUnified = child;
			else if (child.hasAttribute("data-deletions")) this.codeDeletions = child;
			else if (child.hasAttribute("data-additions")) this.codeAdditions = child;
		}
	}
	applyHeaderToDOM(headerAST, container) {
		this.cleanupErrorWrapper();
		this.placeHolder?.remove();
		this.placeHolder = void 0;
		const { fileDiff } = this;
		const headerHTML = this.cachedHeaderHTML ?? toHtml(headerAST);
		this.cachedHeaderHTML = headerHTML;
		if (headerHTML !== this.lastRenderedHeaderHTML) {
			const tempDiv = document.createElement("div");
			tempDiv.innerHTML = headerHTML;
			const newHeader = tempDiv.firstElementChild;
			if (!(newHeader instanceof HTMLElement)) return;
			if (this.headerElement != null) container.shadowRoot?.replaceChild(newHeader, this.headerElement);
			else container.shadowRoot?.prepend(newHeader);
			this.headerElement = newHeader;
			this.lastRenderedHeaderHTML = headerHTML;
		}
		if (this.isContainerManaged || fileDiff == null) return;
		const { renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata } = this.options;
		if (renderCustomHeader != null) {
			const content = renderCustomHeader(fileDiff) ?? void 0;
			this.headerCustom = this.upsertHeaderSlotElement(container, this.headerCustom, CUSTOM_HEADER_SLOT_ID, content);
			this.headerPrefix?.remove();
			this.headerFilenameSuffix?.remove();
			this.headerMetadata?.remove();
			this.headerPrefix = void 0;
			this.headerFilenameSuffix = void 0;
			this.headerMetadata = void 0;
			return;
		}
		const prefix = renderHeaderPrefix?.(fileDiff) ?? void 0;
		const suffix = renderHeaderFilenameSuffix?.(fileDiff) ?? void 0;
		const content = renderHeaderMetadata?.(fileDiff) ?? void 0;
		this.headerPrefix = this.upsertHeaderSlotElement(container, this.headerPrefix, HEADER_PREFIX_SLOT_ID, prefix);
		this.headerFilenameSuffix = this.upsertHeaderSlotElement(container, this.headerFilenameSuffix, HEADER_FILENAME_SUFFIX_SLOT_ID, suffix);
		this.headerMetadata = this.upsertHeaderSlotElement(container, this.headerMetadata, HEADER_METADATA_SLOT_ID, content);
		this.headerCustom?.remove();
		this.headerCustom = void 0;
	}
	clearHeaderSlots() {
		this.headerPrefix?.remove();
		this.headerFilenameSuffix?.remove();
		this.headerMetadata?.remove();
		this.headerCustom?.remove();
		this.headerPrefix = void 0;
		this.headerFilenameSuffix = void 0;
		this.headerMetadata = void 0;
		this.headerCustom = void 0;
	}
	upsertHeaderSlotElement(container, current, slot, content) {
		if (content == null) {
			current?.remove();
			return;
		}
		const element = current ?? this.createHeaderSlotElement(slot);
		if (current == null) container.appendChild(element);
		this.replaceHeaderSlotContent(element, content);
		return element;
	}
	replaceHeaderSlotContent(element, content) {
		element.replaceChildren();
		if (content instanceof Element) element.appendChild(content);
		else element.innerText = `${content}`;
	}
	createHeaderSlotElement(slot) {
		const element = document.createElement("div");
		element.slot = slot;
		return element;
	}
	injectUnsafeCSS() {
		const { unsafeCSS } = this.options;
		const shadowRoot = this.fileContainer?.shadowRoot;
		if (shadowRoot == null) return;
		if (unsafeCSS == null || unsafeCSS === "") {
			if (this.unsafeCSSStyle != null) {
				this.unsafeCSSStyle.remove();
				this.unsafeCSSStyle = void 0;
			}
			this.appliedUnsafeCSS = void 0;
			return;
		}
		if (this.unsafeCSSStyle?.parentNode === shadowRoot && this.appliedUnsafeCSS === unsafeCSS) return;
		this.unsafeCSSStyle ??= createUnsafeCSSStyleNode();
		if (this.unsafeCSSStyle.parentNode !== shadowRoot) shadowRoot.appendChild(this.unsafeCSSStyle);
		this.unsafeCSSStyle.textContent = wrapUnsafeCSS(unsafeCSS);
		this.appliedUnsafeCSS = unsafeCSS;
	}
	applyThemeState(container, themeStyles, themeType, baseThemeType) {
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		const effectiveThemeType = baseThemeType ?? themeType;
		const currentTheme = this.options.theme ?? DEFAULT_THEMES;
		const theme = typeof currentTheme === "string" ? currentTheme : { ...currentTheme };
		const scrollbarGutter = getMeasuredScrollbarGutter(shadowRoot);
		if (this.themeCSSStyle?.parentNode === shadowRoot && this.appliedThemeCSS?.themeStyles === themeStyles && this.appliedThemeCSS.themeType === effectiveThemeType && this.appliedThemeCSS.scrollbarGutter === scrollbarGutter) {
			this.appliedThemeCSS.theme = theme;
			return;
		}
		if (this.hasAdoptedThemeCSS && this.themeCSSStyle?.parentNode === shadowRoot) {
			this.hasAdoptedThemeCSS = false;
			this.appliedThemeCSS = {
				theme,
				themeStyles,
				themeType: effectiveThemeType,
				baseThemeType,
				scrollbarGutter
			};
			return;
		}
		this.themeCSSStyle = upsertHostThemeStyle({
			shadowRoot,
			currentNode: this.themeCSSStyle,
			themeCSS: wrapThemeCSS(themeStyles, effectiveThemeType, scrollbarGutter)
		});
		this.appliedThemeCSS = this.themeCSSStyle != null ? {
			theme,
			themeStyles,
			themeType: effectiveThemeType,
			baseThemeType,
			scrollbarGutter
		} : void 0;
	}
	hydrateMeasuredScrollbar() {
		const shadowRoot = this.fileContainer?.shadowRoot;
		if (shadowRoot == null || this.themeCSSStyle == null) return;
		this.themeCSSStyle.textContent = patchScrollbarGutterSize(this.themeCSSStyle.textContent ?? "", getMeasuredScrollbarGutter(shadowRoot));
	}
	shouldGuardRebuildScroll() {
		return this.editor != null && isSafari();
	}
	applyHunksToDOM(pre, result) {
		if (this.shouldGuardRebuildScroll()) guardWebKitScrollDuringRebuild(pre, () => this.replaceCodeColumns(pre, result));
		else this.replaceCodeColumns(pre, result);
	}
	applyCodeColumnsInPlace(code, ast, rowCount) {
		const columns = this.getColumnPair(code);
		if (columns == null) return false;
		const gutterChildren = getElementChildren(ast[0]);
		const contentChildren = getElementChildren(ast[1]);
		if (gutterChildren == null || contentChildren == null) return false;
		columns.gutter.innerHTML = toHtml(gutterChildren);
		columns.content.innerHTML = toHtml(contentChildren);
		if (rowCount !== this.lastRowCount) {
			columns.gutter.style.setProperty("grid-row", `span ${rowCount}`);
			columns.content.style.setProperty("grid-row", `span ${rowCount}`);
		}
		return true;
	}
	replaceCodeColumns(pre, result) {
		const { overflow = "scroll" } = this.options;
		const containerSize = (this.options.hunkSeparators ?? "line-info") === "line-info";
		const rowSpan = overflow === "wrap" ? result.rowCount : void 0;
		this.cleanupErrorWrapper();
		this.applyPreNodeAttributes(pre, result);
		let shouldReplace = false;
		const codeElements = [];
		const unifiedAST = this.hunksRenderer.renderCodeAST("unified", result);
		const deletionsAST = this.hunksRenderer.renderCodeAST("deletions", result);
		const additionsAST = this.hunksRenderer.renderCodeAST("additions", result);
		this.editor?.__captureFocusForDOMReplacement();
		if (unifiedAST != null) {
			shouldReplace = this.codeUnified == null || this.codeAdditions != null || this.codeDeletions != null;
			this.codeDeletions?.remove();
			this.codeDeletions = void 0;
			this.codeAdditions?.remove();
			this.codeAdditions = void 0;
			this.codeUnified = getOrCreateCodeNode({
				code: this.codeUnified,
				columnType: "unified",
				rowSpan,
				containerSize
			});
			if (!this.applyCodeColumnsInPlace(this.codeUnified, unifiedAST, result.rowCount)) this.codeUnified.innerHTML = this.hunksRenderer.renderPartialHTML(unifiedAST);
			codeElements.push(this.codeUnified);
		} else if (deletionsAST != null || additionsAST != null) {
			if (deletionsAST != null) {
				shouldReplace = this.codeDeletions == null || this.codeUnified != null;
				this.codeUnified?.remove();
				this.codeUnified = void 0;
				this.codeDeletions = getOrCreateCodeNode({
					code: this.codeDeletions,
					columnType: "deletions",
					rowSpan,
					containerSize
				});
				if (!this.applyCodeColumnsInPlace(this.codeDeletions, deletionsAST, result.rowCount)) this.codeDeletions.innerHTML = this.hunksRenderer.renderPartialHTML(deletionsAST);
				codeElements.push(this.codeDeletions);
			} else {
				this.codeDeletions?.remove();
				this.codeDeletions = void 0;
			}
			if (additionsAST != null) {
				shouldReplace = shouldReplace || this.codeAdditions == null || this.codeUnified != null;
				this.codeUnified?.remove();
				this.codeUnified = void 0;
				this.codeAdditions = getOrCreateCodeNode({
					code: this.codeAdditions,
					columnType: "additions",
					rowSpan,
					containerSize
				});
				if (!this.applyCodeColumnsInPlace(this.codeAdditions, additionsAST, result.rowCount)) this.codeAdditions.innerHTML = this.hunksRenderer.renderPartialHTML(additionsAST);
				codeElements.push(this.codeAdditions);
			} else {
				this.codeAdditions?.remove();
				this.codeAdditions = void 0;
			}
		} else {
			this.codeUnified?.remove();
			this.codeUnified = void 0;
			this.codeDeletions?.remove();
			this.codeDeletions = void 0;
			this.codeAdditions?.remove();
			this.codeAdditions = void 0;
		}
		if (codeElements.length === 0) pre.textContent = "";
		else if (shouldReplace) pre.replaceChildren(...codeElements);
		this.lastRowCount = result.rowCount;
	}
	applyPartialRender({ previousRenderRange, renderRange }) {
		const { pre, codeUnified, codeAdditions, codeDeletions, options: { diffStyle = "split" } } = this;
		if (pre == null || previousRenderRange == null || renderRange == null || !Number.isFinite(previousRenderRange.totalLines) || !Number.isFinite(renderRange.totalLines) || this.lastRowCount == null) return false;
		const codeElements = this.getCodeColumns(diffStyle, codeUnified, codeDeletions, codeAdditions);
		if (codeElements == null) return false;
		const previousStart = previousRenderRange.startingLine;
		const nextStart = renderRange.startingLine;
		const previousEnd = previousStart + previousRenderRange.totalLines;
		const nextEnd = nextStart + renderRange.totalLines;
		const overlapStart = Math.max(previousStart, nextStart);
		const overlapEnd = Math.min(previousEnd, nextEnd);
		if (overlapEnd <= overlapStart) return false;
		const trimStart = Math.max(0, overlapStart - previousStart);
		const trimEnd = Math.max(0, previousEnd - overlapEnd);
		const trimResult = this.trimColumns({
			columns: codeElements,
			trimStart,
			trimEnd,
			previousStart,
			overlapStart,
			overlapEnd,
			diffStyle
		});
		if (trimResult < 0) throw new Error("FileDiff.applyPartialRender: failed to trim to overlap");
		if (this.lastRowCount < trimResult) throw new Error("FileDiff.applyPartialRender: trimmed beyond DOM row count");
		let rowCount = this.lastRowCount - trimResult;
		const renderChunk = (startingLine, totalLines) => {
			if (totalLines <= 0 || this.fileDiff == null) return;
			return this.hunksRenderer.renderDiff(this.fileDiff, {
				startingLine,
				totalLines,
				bufferBefore: 0,
				bufferAfter: 0
			});
		};
		const prependResult = renderChunk(nextStart, Math.max(overlapStart - nextStart, 0));
		if (prependResult == null && nextStart < overlapStart) return false;
		const appendResult = renderChunk(overlapEnd, Math.max(nextEnd - overlapEnd, 0));
		if (appendResult == null && nextEnd > overlapEnd) return false;
		const applyChunk = (result, insertPosition) => {
			if (result == null) return;
			if (diffStyle === "unified" && !Array.isArray(codeElements)) this.insertPartialHTML(diffStyle, codeElements, result, insertPosition);
			else if (diffStyle === "split" && Array.isArray(codeElements)) this.insertPartialHTML(diffStyle, codeElements, result, insertPosition);
			else throw new Error("FileDiff.applyPartialRender.applyChunk: invalid chunk application");
			rowCount += result.rowCount;
		};
		this.cleanupErrorWrapper();
		applyChunk(prependResult, "afterbegin");
		applyChunk(appendResult, "beforeend");
		if (this.lastRowCount !== rowCount) {
			this.applyRowSpan(diffStyle, codeElements, rowCount);
			this.lastRowCount = rowCount;
		}
		return true;
	}
	insertPartialHTML(diffStyle, columns, result, insertPosition) {
		if (diffStyle === "unified" && !Array.isArray(columns)) {
			const unifiedAST = this.hunksRenderer.renderCodeAST("unified", result);
			this.renderPartialColumn(columns, unifiedAST, insertPosition);
		} else if (diffStyle === "split" && Array.isArray(columns)) {
			const deletionsAST = this.hunksRenderer.renderCodeAST("deletions", result);
			const additionsAST = this.hunksRenderer.renderCodeAST("additions", result);
			this.renderPartialColumn(columns[0], deletionsAST, insertPosition);
			this.renderPartialColumn(columns[1], additionsAST, insertPosition);
		} else throw new Error("FileDiff.insertPartialHTML: Invalid argument composition");
	}
	refreshSplitDiffView() {
		if (this.options.diffStyle !== "split") return;
		const hunksResult = this.hunksRenderer.renderDiff(this.fileDiff, this.renderRange);
		if (hunksResult == null) return;
		const columns = this.getCodeColumns("split", this.codeUnified, this.codeDeletions, this.codeAdditions);
		if (!Array.isArray(columns)) return;
		const applyLineType = (type, column) => {
			if (column == null) return;
			const ast = this.hunksRenderer.renderCodeAST(type, hunksResult);
			const gutterChildren = getElementChildren(ast?.[0]);
			const contentChildren = getElementChildren(ast?.[1]);
			for (const [el, astChildren] of [[column.gutter, gutterChildren], [column.content, contentChildren]]) if (astChildren != null && el.childElementCount === astChildren.length) for (let i = 0; i < astChildren.length; i++) {
				const gutterElement = el.children[i];
				const lineType = astChildren[i].properties["data-line-type"];
				if (lineType != null && gutterElement.dataset.lineType !== lineType) gutterElement.dataset.lineType = lineType;
			}
		};
		applyLineType("deletions", columns[0]);
		applyLineType("additions", columns[1]);
	}
	refreshUnifiedDiffView() {
		if (this.options.diffStyle !== "unified") return;
		const hunksResult = this.hunksRenderer.renderDiff(this.fileDiff, this.renderRange);
		if (hunksResult == null) return;
		const columns = this.getCodeColumns("unified", this.codeUnified, this.codeDeletions, this.codeAdditions);
		if (columns == null || Array.isArray(columns)) return;
		const ast = this.hunksRenderer.renderCodeAST("unified", hunksResult);
		const gutterChildren = getElementChildren(ast?.[0]);
		const contentChildren = getElementChildren(ast?.[1]);
		const applyColumns = () => {
			for (const [el, astChildren] of [[columns.gutter, gutterChildren], [columns.content, contentChildren]]) if (astChildren != null) el.innerHTML = toHtml(astChildren);
			if (hunksResult.rowCount !== this.lastRowCount) {
				this.applyRowSpan("unified", columns, hunksResult.rowCount);
				this.lastRowCount = hunksResult.rowCount;
			}
		};
		if (this.shouldGuardRebuildScroll()) guardWebKitScrollDuringRebuild(this.pre, applyColumns);
		else applyColumns();
		this.renderSeparators(hunksResult.hunkData);
		this.managersDirty = true;
		this.flushManagers();
		this.syncRenderViewToEditor();
	}
	renderPartialColumn(column, ast, insertPosition) {
		if (column == null || ast == null) return;
		const gutterChildren = getElementChildren(ast[0]);
		const contentChildren = getElementChildren(ast[1]);
		if (gutterChildren == null || contentChildren == null) throw new Error("FileDiff.insertPartialHTML: Unexpected AST structure");
		const firstHASTElement = contentChildren.at(0);
		if (insertPosition === "beforeend" && firstHASTElement?.type === "element" && typeof firstHASTElement.properties["data-buffer-size"] === "number") this.mergeBuffersIfNecessary(firstHASTElement.properties["data-buffer-size"], column.content.children[column.content.children.length - 1], column.gutter.children[column.gutter.children.length - 1], gutterChildren, contentChildren, true);
		const lastHASTElement = contentChildren.at(-1);
		if (insertPosition === "afterbegin" && lastHASTElement?.type === "element" && typeof lastHASTElement.properties["data-buffer-size"] === "number") this.mergeBuffersIfNecessary(lastHASTElement.properties["data-buffer-size"], column.content.children[0], column.gutter.children[0], gutterChildren, contentChildren, false);
		column.gutter.insertAdjacentHTML(insertPosition, this.hunksRenderer.renderPartialHTML(gutterChildren));
		column.content.insertAdjacentHTML(insertPosition, this.hunksRenderer.renderPartialHTML(contentChildren));
	}
	mergeBuffersIfNecessary(adjustmentSize, contentElement, gutterElement, gutterChildren, contentChildren, fromStart) {
		if (!(contentElement instanceof HTMLElement) || !(gutterElement instanceof HTMLElement)) return;
		const currentSize = this.getBufferSize(contentElement.dataset);
		if (currentSize == null) return;
		if (fromStart) {
			gutterChildren.shift();
			contentChildren.shift();
		} else {
			gutterChildren.pop();
			contentChildren.pop();
		}
		this.updateBufferSize(contentElement, currentSize + adjustmentSize);
		this.updateBufferSize(gutterElement, currentSize + adjustmentSize);
	}
	applyRowSpan(diffStyle, columns, rowCount) {
		const applySpan = (column) => {
			if (column == null) return;
			column.gutter.style.setProperty("grid-row", `span ${rowCount}`);
			column.content.style.setProperty("grid-row", `span ${rowCount}`);
		};
		if (diffStyle === "unified" && !Array.isArray(columns)) applySpan(columns);
		else if (diffStyle === "split" && Array.isArray(columns)) {
			applySpan(columns[0]);
			applySpan(columns[1]);
		} else throw new Error("dun fuuuuked up");
	}
	trimColumnRows(columns, preTrimCount, postTrimStart) {
		let visibleLineIndex = 0;
		let rowCount = 0;
		let rowIndex = 0;
		let pendingMetadataTrim = false;
		const hasPostTrim = postTrimStart >= 0;
		if (columns == null) return 0;
		const contentChildren = Array.from(columns.content.children);
		const gutterChildren = Array.from(columns.gutter.children);
		if (contentChildren.length !== gutterChildren.length) throw new Error("FileDiff.trimColumnRows: columns do not match");
		while (rowIndex < contentChildren.length) {
			if (preTrimCount <= 0 && !hasPostTrim && !pendingMetadataTrim) break;
			const gutterElement = gutterChildren[rowIndex];
			const contentElement = contentChildren[rowIndex];
			rowIndex++;
			if (!(gutterElement instanceof HTMLElement) || !(contentElement instanceof HTMLElement)) {
				console.error({
					gutterElement,
					contentElement
				});
				throw new Error("FileDiff.trimColumnRows: invalid row elements");
			}
			if (pendingMetadataTrim) {
				pendingMetadataTrim = false;
				if (gutterElement.dataset.gutterBuffer === "annotation" && "lineAnnotation" in contentElement.dataset || gutterElement.dataset.gutterBuffer === "metadata" && "noNewline" in contentElement.dataset) {
					gutterElement.remove();
					contentElement.remove();
					rowCount++;
					continue;
				}
			}
			if ("lineIndex" in gutterElement.dataset && "lineIndex" in contentElement.dataset) {
				if (preTrimCount > 0 || hasPostTrim && visibleLineIndex >= postTrimStart) {
					gutterElement.remove();
					contentElement.remove();
					if (preTrimCount > 0) {
						preTrimCount--;
						if (preTrimCount === 0) pendingMetadataTrim = true;
					}
					rowCount++;
				}
				visibleLineIndex++;
				continue;
			}
			if ("separator" in gutterElement.dataset && "separator" in contentElement.dataset) {
				if (preTrimCount > 0 || hasPostTrim && visibleLineIndex >= postTrimStart) {
					gutterElement.remove();
					contentElement.remove();
					rowCount++;
				}
				continue;
			}
			if (gutterElement.dataset.gutterBuffer === "annotation" && "lineAnnotation" in contentElement.dataset) {
				if (preTrimCount > 0 || hasPostTrim && visibleLineIndex >= postTrimStart) {
					gutterElement.remove();
					contentElement.remove();
					rowCount++;
				}
				continue;
			}
			if (gutterElement.dataset.gutterBuffer === "metadata" && "noNewline" in contentElement.dataset) {
				if (preTrimCount > 0 || hasPostTrim && visibleLineIndex >= postTrimStart) {
					gutterElement.remove();
					contentElement.remove();
					rowCount++;
				}
				continue;
			}
			if (gutterElement.dataset.gutterBuffer === "buffer" && "contentBuffer" in contentElement.dataset) {
				const totalRows = this.getBufferSize(contentElement.dataset);
				if (totalRows == null) throw new Error("FileDiff.trimColumnRows: invalid element");
				if (preTrimCount > 0) {
					const rowsToRemove = Math.min(preTrimCount, totalRows);
					const newSize = totalRows - rowsToRemove;
					if (newSize > 0) {
						this.updateBufferSize(gutterElement, newSize);
						this.updateBufferSize(contentElement, newSize);
						rowCount += rowsToRemove;
					} else {
						gutterElement.remove();
						contentElement.remove();
						rowCount += totalRows;
					}
					preTrimCount -= rowsToRemove;
					if (preTrimCount === 0 && newSize === 0) pendingMetadataTrim = true;
				} else if (hasPostTrim) {
					const bufferStart = visibleLineIndex;
					const bufferEnd = visibleLineIndex + totalRows - 1;
					if (postTrimStart <= bufferStart) {
						gutterElement.remove();
						contentElement.remove();
						rowCount += totalRows;
					} else if (postTrimStart <= bufferEnd) {
						const rowsToRemove = bufferEnd - postTrimStart + 1;
						const newSize = totalRows - rowsToRemove;
						this.updateBufferSize(gutterElement, newSize);
						this.updateBufferSize(contentElement, newSize);
						rowCount += rowsToRemove;
					}
				}
				visibleLineIndex += totalRows;
				continue;
			}
			console.error({
				gutterElement,
				contentElement
			});
			throw new Error("FileDiff.trimColumnRows: unknown row elements");
		}
		return rowCount;
	}
	trimColumns({ columns, diffStyle, overlapEnd, overlapStart, previousStart, trimEnd, trimStart }) {
		const preTrimCount = Math.max(0, overlapStart - previousStart);
		const postTrimStart = overlapEnd - previousStart;
		if (postTrimStart < 0) throw new Error("FileDiff.trimColumns: overlap ends before previous");
		const shouldTrimStart = trimStart > 0;
		const shouldTrimEnd = trimEnd > 0;
		if (!shouldTrimStart && !shouldTrimEnd) return 0;
		const effectivePreTrimCount = shouldTrimStart ? preTrimCount : 0;
		const effectivePostTrimStart = shouldTrimEnd ? postTrimStart : -1;
		if (diffStyle === "unified" && !Array.isArray(columns)) return this.trimColumnRows(columns, effectivePreTrimCount, effectivePostTrimStart);
		else if (diffStyle === "split" && Array.isArray(columns)) {
			const deletionsTrim = this.trimColumnRows(columns[0], effectivePreTrimCount, effectivePostTrimStart);
			const additionsTrim = this.trimColumnRows(columns[1], effectivePreTrimCount, effectivePostTrimStart);
			if (columns[0] != null && columns[1] != null && deletionsTrim !== additionsTrim) throw new Error("FileDiff.trimColumns: split columns out of sync");
			return columns[0] != null ? deletionsTrim : additionsTrim;
		} else {
			console.error({
				diffStyle,
				columns
			});
			throw new Error("FileDiff.trimColumns: Invalid columns for diffType");
		}
	}
	getBufferSize(properties) {
		const parsed = Number.parseInt(properties?.bufferSize ?? "", 10);
		return Number.isNaN(parsed) ? void 0 : parsed;
	}
	updateBufferSize(element, size) {
		element.dataset.bufferSize = `${size}`;
		element.style.setProperty("grid-row", `span ${size}`);
		element.style.setProperty("min-height", `calc(${size} * 1lh)`);
	}
	getColumnPair(code) {
		if (code == null) return;
		const gutter = code.children[0];
		const content = code.children[1];
		if (!(gutter instanceof HTMLElement) || !(content instanceof HTMLElement) || gutter.dataset.gutter == null || content.dataset.content == null) return;
		return {
			gutter,
			content
		};
	}
	getCodeColumns(diffStyle, codeUnified, codeDeletions, codeAdditions) {
		if (diffStyle === "unified") return this.getColumnPair(codeUnified);
		else {
			const deletions = this.getColumnPair(codeDeletions);
			const additions = this.getColumnPair(codeAdditions);
			return deletions != null || additions != null ? [deletions, additions] : void 0;
		}
	}
	updateBuffers(renderRange) {
		if (this.pre != null) this.applyBuffers(this.pre, renderRange);
	}
	applyBuffers(pre, renderRange) {
		if (renderRange == null || this.shouldDisableVirtualizationBuffers()) {
			if (this.bufferBefore != null) {
				this.bufferBefore.remove();
				this.bufferBefore = void 0;
			}
			if (this.bufferAfter != null) {
				this.bufferAfter.remove();
				this.bufferAfter = void 0;
			}
			return;
		}
		if (renderRange.bufferBefore > 0) {
			if (this.bufferBefore == null) {
				this.bufferBefore = document.createElement("div");
				this.bufferBefore.dataset.virtualizerBuffer = "before";
				pre.before(this.bufferBefore);
			}
			this.bufferBefore.style.setProperty("height", `${renderRange.bufferBefore}px`);
			this.bufferBefore.style.setProperty("contain", "strict");
		} else if (this.bufferBefore != null) {
			this.bufferBefore.remove();
			this.bufferBefore = void 0;
		}
		if (renderRange.bufferAfter > 0) {
			if (this.bufferAfter == null) {
				this.bufferAfter = document.createElement("div");
				this.bufferAfter.dataset.virtualizerBuffer = "after";
				pre.after(this.bufferAfter);
			}
			this.bufferAfter.style.setProperty("height", `${renderRange.bufferAfter}px`);
			this.bufferAfter.style.setProperty("contain", "strict");
		} else if (this.bufferAfter != null) {
			this.bufferAfter.remove();
			this.bufferAfter = void 0;
		}
	}
	shouldDisableVirtualizationBuffers() {
		return this.options.disableVirtualizationBuffers ?? false;
	}
	applyPreNodeAttributes(pre, { additionsContentAST, deletionsContentAST, totalLines }, customProperties) {
		const { diffIndicators = "bars", disableBackground = false, disableLineNumbers = false, overflow = "scroll", diffStyle = "split" } = this.options;
		const preProperties = {
			type: "diff",
			diffIndicators,
			disableBackground,
			disableLineNumbers,
			overflow,
			split: diffStyle === "unified" ? false : additionsContentAST != null && deletionsContentAST != null,
			totalLines,
			customProperties
		};
		if (arePrePropertiesEqual(preProperties, this.appliedPreAttributes)) return;
		setPreNodeProperties(pre, preProperties);
		this.appliedPreAttributes = preProperties;
	}
	applyErrorToDOM(error, container) {
		this.cleanupErrorWrapper();
		this.pre?.remove();
		this.pre = void 0;
		this.appliedPreAttributes = void 0;
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		this.errorWrapper ??= document.createElement("div");
		this.errorWrapper.dataset.errorWrapper = "";
		this.errorWrapper.textContent = "";
		shadowRoot.appendChild(this.errorWrapper);
		const errorMessage = document.createElement("div");
		errorMessage.dataset.errorMessage = "";
		errorMessage.innerText = error.message;
		this.errorWrapper.appendChild(errorMessage);
		const errorStack = document.createElement("pre");
		errorStack.dataset.errorStack = "";
		errorStack.innerText = error.stack ?? "No Error Stack";
		this.errorWrapper.appendChild(errorStack);
	}
	cleanupErrorWrapper() {
		this.errorWrapper?.remove();
		this.errorWrapper = void 0;
	}
};
function areOptionalFilesEqual$1(fileA, fileB) {
	if (fileA == null || fileB == null) return fileA == null && fileB == null;
	return areFilesEqual(fileA, fileB);
}
function hasDiffContent({ fileDiff, oldFile, newFile }) {
	return fileDiff != null && fileDiff.hunks.length > 0 || oldFile != null || newFile != null;
}
function hasDiffHeaderContent({ fileDiff, oldFile, newFile }) {
	return fileDiff != null || oldFile != null || newFile != null;
}
function shouldRenderCode$1(pre, hasContent, collapsed = false) {
	return !collapsed && pre == null && hasContent;
}
function shouldRenderHeader$1(headerElement, hasContent, disableFileHeader = false) {
	return headerElement == null && hasContent && !disableFileHeader;
}
function getElementChildren(node) {
	if (node == null || node.type !== "element") return;
	return node.children ?? [];
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/computeEstimatedDiffHeights.js
function computeEstimatedDiffHeights({ fileDiff, metrics, disableFileHeader, hunkSeparators, expandUnchanged, expandedHunks: configuredExpandedHunks, collapsedContextThreshold, canHydratePartialDiff }) {
	let splitHeight = getVirtualFileHeaderRegion(metrics, disableFileHeader);
	let unifiedHeight = splitHeight;
	const expandedHunks = expandUnchanged ? true : configuredExpandedHunks;
	const finalHunkIndex = fileDiff.hunks.length - 1;
	for (let hunkIndex = 0; hunkIndex < fileDiff.hunks.length; hunkIndex++) {
		const hunk = fileDiff.hunks[hunkIndex];
		if (hunk == null) throw new Error("computeEstimatedDiffHeights: invalid hunk index");
		const leadingRegion = getExpandedRegion({
			isPartial: fileDiff.isPartial,
			rangeSize: hunk.collapsedBefore,
			expandedHunks,
			hunkIndex,
			collapsedContextThreshold
		});
		const leadingExpandedHeight = (leadingRegion.fromStart + leadingRegion.fromEnd) * metrics.lineHeight;
		splitHeight += leadingExpandedHeight;
		unifiedHeight += leadingExpandedHeight;
		if (leadingRegion.collapsedLines > 0) {
			const separatorHeight = getLeadingHunkSeparatorLayout({
				type: hunkSeparators,
				metrics,
				hunkIndex,
				hunkSpecs: hunk.hunkSpecs
			})?.totalHeight ?? 0;
			splitHeight += separatorHeight;
			unifiedHeight += separatorHeight;
		}
		splitHeight += hunk.splitLineCount * metrics.lineHeight;
		unifiedHeight += hunk.unifiedLineCount * metrics.lineHeight;
		const metadataLineCounts = getNoNewlineMetadataLineCounts(hunk);
		splitHeight += metadataLineCounts.split * metrics.lineHeight;
		unifiedHeight += metadataLineCounts.unified * metrics.lineHeight;
		const trailingRegion = hunkIndex === finalHunkIndex ? getTrailingExpandedRegion({
			fileDiff,
			hunkIndex,
			expandedHunks,
			collapsedContextThreshold,
			errorPrefix: "computeEstimatedDiffHeights"
		}) : void 0;
		if (trailingRegion != null) {
			const trailingExpandedHeight = (trailingRegion.fromStart + trailingRegion.fromEnd) * metrics.lineHeight;
			splitHeight += trailingExpandedHeight;
			unifiedHeight += trailingExpandedHeight;
			if (trailingRegion.collapsedLines > 0) {
				const separatorHeight = getTrailingHunkSeparatorLayout({
					type: hunkSeparators,
					metrics
				})?.totalHeight ?? 0;
				splitHeight += separatorHeight;
				unifiedHeight += separatorHeight;
			}
		} else if (hunkIndex === finalHunkIndex && fileDiff.isPartial && canHydratePartialDiff) {
			const separatorHeight = getTrailingHunkSeparatorLayout({
				type: hunkSeparators,
				metrics
			})?.totalHeight ?? 0;
			splitHeight += separatorHeight;
			unifiedHeight += separatorHeight;
		}
	}
	if (fileDiff.hunks.length > 0) {
		const paddingBottom = getVirtualFilePaddingBottom(metrics);
		splitHeight += paddingBottom;
		unifiedHeight += paddingBottom;
	}
	return {
		splitHeight,
		unifiedHeight
	};
}
function getNoNewlineMetadataLineCounts(hunk) {
	if (!hunk.noEOFCRAdditions && !hunk.noEOFCRDeletions) return {
		split: 0,
		unified: 0
	};
	const lastContent = hunk.hunkContent.at(-1);
	if (lastContent == null) return {
		split: 0,
		unified: 0
	};
	if (lastContent.type === "context") {
		const metadataRows = lastContent.lines > 0 ? 1 : 0;
		return {
			split: metadataRows,
			unified: metadataRows
		};
	}
	return getChangeNoNewlineMetadataLineCounts(hunk, lastContent);
}
function getChangeNoNewlineMetadataLineCounts(hunk, content) {
	const unified = (content.deletions > 0 && hunk.noEOFCRDeletions ? 1 : 0) + (content.additions > 0 && hunk.noEOFCRAdditions ? 1 : 0);
	const splitDeletionHasMetadata = content.deletions > 0 && hunk.noEOFCRDeletions;
	const splitAdditionHasMetadata = content.additions > 0 && hunk.noEOFCRAdditions;
	return {
		split: splitDeletionHasMetadata || splitAdditionHasMetadata ? 1 : 0,
		unified
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/VirtualizedFileDiff.js
var VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL = 3e3;
var instanceId$1 = -1;
var VirtualizedFileDiff = class extends FileDiff {
	__id = `little-virtualized-file-diff:${++instanceId$1}`;
	top;
	height = 0;
	metrics;
	cache = {
		heightDeltas: /* @__PURE__ */ new Map(),
		measuredHeightDeltaTotal: 0,
		estimatedSplitHeight: void 0,
		estimatedUnifiedHeight: void 0,
		checkpoints: [],
		totalLines: 0,
		fileAnnotationHeight: 0
	};
	isVisible = false;
	isSetup = false;
	virtualizer;
	layoutDirty = true;
	forceRenderOverride;
	currentCollapsed;
	currentExpandUnchanged;
	pendingHydratedDiff;
	pendingExpansions;
	constructor(options, virtualizer, metrics, workerManager, isContainerManaged = false) {
		super(options, workerManager, isContainerManaged);
		this.virtualizer = virtualizer;
		this.metrics = computeVirtualFileMetrics(metrics);
	}
	setMetrics(metrics, force = false) {
		const nextMetrics = computeVirtualFileMetrics(metrics);
		if (!force && areObjectsEqual(this.metrics, nextMetrics)) return;
		this.metrics = nextMetrics;
		this.resetLayoutCache({ includeEstimatedHeights: true });
	}
	setLineAnnotations(lineAnnotations) {
		if (this.syncLineAnnotations(lineAnnotations)) this.resetLayoutCache({ includeEstimatedHeights: false });
	}
	syncLineAnnotations(lineAnnotations) {
		if (lineAnnotations == null || lineAnnotations === this.lineAnnotations || lineAnnotations.length === 0 && this.lineAnnotations.length === 0) return false;
		super.setLineAnnotations(lineAnnotations);
		return true;
	}
	setFileAnnotationHeight(nextHeight) {
		const previousHeight = this.cache.fileAnnotationHeight;
		if (nextHeight === previousHeight) return false;
		this.cache.fileAnnotationHeight = nextHeight;
		this.cache.measuredHeightDeltaTotal += nextHeight - previousHeight;
		return true;
	}
	hasFileAnnotations(fileDiff = this.fileDiff) {
		if (fileDiff == null || !includesFileAnnotations(this.lineAnnotations)) return false;
		return this.lineAnnotations.some((annotation) => {
			if (annotation.lineNumber !== 0) return false;
			if (fileDiff.type === "new") return annotation.side === "additions";
			if (fileDiff.type === "deleted") return annotation.side === "deletions";
			return true;
		});
	}
	getLineHeight(lineIndex, hasMetadataLine = false) {
		return this.getEstimatedLineHeight(hasMetadataLine) + (this.cache.heightDeltas.get(lineIndex) ?? 0);
	}
	getEstimatedLineHeight(hasMetadataLine = false) {
		const multiplier = hasMetadataLine ? 2 : 1;
		return this.metrics.lineHeight * multiplier;
	}
	setOptions(options) {
		if (this.isAdvancedMode()) throw new Error("VirtualizedFileDiff.setOptions cannot be used inside CodeView. Update CodeView options instead.");
		if (options == null) return;
		const { options: previousOptions } = this;
		const optionsChanged = !areOptionsEqual(previousOptions, options);
		const layoutChanged = optionsChanged && hasDiffLayoutOptionChanged(previousOptions, options);
		super.setOptions(options);
		if (layoutChanged) this.resetLayoutCache({
			forceSimpleRecompute: true,
			includeEstimatedHeights: hasDiffEstimateOptionChanged(previousOptions, options)
		});
		if (optionsChanged) this.forceRenderOverride = true;
		if (optionsChanged && this.isSimpleMode()) this.virtualizer.instanceChanged(this, layoutChanged);
	}
	setThemeType(themeType) {
		if (this.isAdvancedMode()) throw new Error("VirtualizedFileDiff.setThemeType cannot be used inside CodeView. Update CodeView options instead.");
		super.setThemeType(themeType);
	}
	resetLayoutCache({ forceSimpleRecompute = false, includeEstimatedHeights = false, resetRenderRange = true } = {}) {
		this.layoutDirty = true;
		this.cache.fileAnnotationHeight = 0;
		if (this.cache.heightDeltas.size > 0) this.cache.heightDeltas.clear();
		if (this.cache.measuredHeightDeltaTotal !== 0) this.cache.measuredHeightDeltaTotal = 0;
		this.invalidateDerivedLayoutCache(includeEstimatedHeights, resetRenderRange);
		if (forceSimpleRecompute && this.isSimpleMode()) this.computeApproximateSize();
	}
	invalidateDerivedLayoutCache(includeEstimatedHeights, resetRenderRange = true) {
		this.layoutDirty = true;
		if (this.cache.checkpoints.length > 0) this.cache.checkpoints.length = 0;
		if (this.cache.totalLines !== 0) this.cache.totalLines = 0;
		if (includeEstimatedHeights) {
			this.cache.estimatedSplitHeight = void 0;
			this.cache.estimatedUnifiedHeight = void 0;
		}
		if (this.renderRange != null && resetRenderRange) this.renderRange = void 0;
	}
	reconcileHeights() {
		let hasHeightChange = false;
		const { overflow = "scroll" } = this.options;
		if (this.fileContainer == null || this.fileDiff == null) {
			if (this.height !== 0) hasHeightChange = true;
			this.height = 0;
			return hasHeightChange;
		}
		this.top = this.getVirtualizedTop();
		if (overflow === "scroll" && this.lineAnnotations.length === 0 && !this.isResizeDebuggingEnabled()) return hasHeightChange;
		const diffStyle = this.getDiffStyle();
		const codeGroups = diffStyle === "split" ? [this.codeDeletions, this.codeAdditions] : [this.codeUnified];
		const hasFileAnnotations = this.hasFileAnnotations(this.fileDiff);
		if (this.renderRange != null && hasFileAnnotations && shouldRenderFileAnnotations(this.renderRange)) {
			const nextFileAnnotationHeight = measureFileAnnotationHeight(codeGroups) ?? 0;
			if (this.setFileAnnotationHeight(nextFileAnnotationHeight)) hasHeightChange = true;
		} else if (!hasFileAnnotations && this.setFileAnnotationHeight(0)) hasHeightChange = true;
		for (const codeGroup of codeGroups) {
			if (codeGroup == null) continue;
			const content = codeGroup.children[1];
			if (!(content instanceof HTMLElement)) continue;
			for (const line of content.children) {
				if (!(line instanceof HTMLElement)) continue;
				const lineIndexAttr = line.dataset.lineIndex;
				if (lineIndexAttr == null) continue;
				const lineIndex = parseLineIndex(lineIndexAttr, diffStyle);
				let measuredHeight = line.getBoundingClientRect().height;
				let hasMetadata = false;
				if (line.nextElementSibling instanceof HTMLElement && ("lineAnnotation" in line.nextElementSibling.dataset || "noNewline" in line.nextElementSibling.dataset)) {
					if ("noNewline" in line.nextElementSibling.dataset) hasMetadata = true;
					measuredHeight += line.nextElementSibling.getBoundingClientRect().height;
				}
				const estimatedHeight = this.getEstimatedLineHeight(hasMetadata);
				const previousDelta = this.cache.heightDeltas.get(lineIndex) ?? 0;
				const nextDelta = measuredHeight - estimatedHeight;
				if (nextDelta === previousDelta) continue;
				hasHeightChange = true;
				this.cache.measuredHeightDeltaTotal += nextDelta - previousDelta;
				if (nextDelta === 0) this.cache.heightDeltas.delete(lineIndex);
				else this.cache.heightDeltas.set(lineIndex, nextDelta);
			}
		}
		if (hasHeightChange || this.isResizeDebuggingEnabled()) this.computeApproximateSize(true);
		return hasHeightChange;
	}
	onRender = (dirty) => {
		if (this.fileContainer == null) return false;
		if (dirty) this.top = this.getVirtualizedTop();
		return this.render();
	};
	flushManagers() {
		super.flushManagers();
		if (this.lineStateRefreshPending) this.flushDeferredLineState();
	}
	prepareCodeViewItem(fileDiff, top, reset, lineAnnotations) {
		const targetChanged = !areDiffTargetsEqual(this.fileDiff, fileDiff);
		const annotationsChanged = this.syncLineAnnotations(lineAnnotations);
		let shouldResetLayoutCache = reset?.resetDiffLayoutCache === true || targetChanged || annotationsChanged;
		let includeEstimatedHeights = targetChanged || reset?.resetDiffLayoutCache === true && reset.includeEstimatedDiffHeights;
		if (reset?.metrics != null) {
			this.metrics = computeVirtualFileMetrics(reset.metrics);
			shouldResetLayoutCache = true;
			includeEstimatedHeights = true;
		}
		const { collapsed = false, expandUnchanged = false } = this.options;
		if (this.currentCollapsed !== collapsed) {
			this.currentCollapsed = collapsed;
			shouldResetLayoutCache = true;
		}
		if (this.currentExpandUnchanged !== expandUnchanged) {
			this.currentExpandUnchanged = expandUnchanged;
			shouldResetLayoutCache = true;
			includeEstimatedHeights = true;
		}
		if (shouldResetLayoutCache) this.resetLayoutCache({ includeEstimatedHeights });
		this.fileDiff = fileDiff;
		this.top = top;
		this.computeApproximateSize();
		return this.height;
	}
	getLinePosition(lineNumber, side = "additions") {
		if (this.fileDiff == null || lineNumber < 1) return;
		const targetLineIndexes = this.getLineIndex(lineNumber, side);
		if (targetLineIndexes == null) return;
		const { disableFileHeader = false, expandUnchanged = false, collapsed = false, collapsedContextThreshold = 1 } = this.options;
		const diffStyle = this.getDiffStyle();
		const hunkSeparators = this.getHunkSeparatorType();
		const targetLineIndex = diffStyle === "split" ? targetLineIndexes[1] : targetLineIndexes[0];
		this.approximateLayoutCheckpoints();
		const headerRegion = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		const checkpoint = this.getLayoutCheckpointBeforeLineIndex(targetLineIndex);
		let top = checkpoint?.top ?? headerRegion + this.cache.fileAnnotationHeight;
		if (collapsed) return {
			top: headerRegion,
			height: 0
		};
		let position;
		iterateOverDiff({
			diff: this.fileDiff,
			diffStyle,
			startingLine: checkpoint?.renderedLineIndex ?? 0,
			expandedHunks: expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold,
			callback: ({ hunkIndex, hunk, collapsedBefore, collapsedAfter, deletionLine, additionLine }) => {
				const lineIndex = diffStyle === "split" ? additionLine?.splitLineIndex ?? deletionLine?.splitLineIndex : additionLine?.unifiedLineIndex ?? deletionLine?.unifiedLineIndex;
				if (lineIndex == null) throw new Error("VirtualizedFileDiff.getLinePosition: missing line index data");
				if (collapsedBefore > 0) {
					const separator = getLeadingHunkSeparatorLayout({
						type: hunkSeparators,
						metrics: this.metrics,
						hunkIndex,
						hunkSpecs: hunk?.hunkSpecs
					});
					if (separator != null) {
						top += separator.gapBefore;
						if (targetLineIndex >= lineIndex - collapsedBefore && targetLineIndex < lineIndex) {
							position = {
								top,
								height: separator.height
							};
							return true;
						}
						top += separator.height + separator.gapAfter;
					}
				}
				const lineHeight = this.getLineHeight(lineIndex, (additionLine?.noEOFCR ?? false) || (deletionLine?.noEOFCR ?? false));
				if (lineIndex === targetLineIndex) {
					position = {
						top,
						height: lineHeight
					};
					return true;
				}
				top += lineHeight;
				if (collapsedAfter > 0) {
					const separator = getTrailingHunkSeparatorLayout({
						type: hunkSeparators,
						metrics: this.metrics
					});
					if (separator != null) {
						if (targetLineIndex > lineIndex && targetLineIndex <= lineIndex + collapsedAfter) {
							position = {
								top: top + separator.gapBefore,
								height: separator.height
							};
							return true;
						}
						top += separator.totalHeight;
					}
				}
				return false;
			}
		});
		return position;
	}
	getEditorViewport() {
		return this.virtualizer.type === "simple" ? this.virtualizer.getRoot() : this.virtualizer.getContainerElement();
	}
	getNumericScrollAnchor(localViewportTop) {
		if (this.fileDiff == null) return;
		const { disableFileHeader = false, expandUnchanged = false, collapsed = false, collapsedContextThreshold = 1 } = this.options;
		if (collapsed) return;
		const diffStyle = this.getDiffStyle();
		const hunkSeparators = this.getHunkSeparatorType();
		this.approximateLayoutCheckpoints();
		const checkpoint = this.getLayoutCheckpointBeforeTop(localViewportTop);
		let top = checkpoint?.top ?? getVirtualFileHeaderRegion(this.metrics, disableFileHeader) + this.cache.fileAnnotationHeight;
		let anchor;
		iterateOverDiff({
			diff: this.fileDiff,
			diffStyle,
			startingLine: checkpoint?.renderedLineIndex ?? 0,
			expandedHunks: expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold,
			callback: ({ hunkIndex, hunk, collapsedBefore, collapsedAfter, deletionLine, additionLine }) => {
				const lineIndex = diffStyle === "split" ? additionLine?.splitLineIndex ?? deletionLine?.splitLineIndex : additionLine?.unifiedLineIndex ?? deletionLine?.unifiedLineIndex;
				if (lineIndex == null) throw new Error("VirtualizedFileDiff.getNumericScrollAnchor: missing line index data");
				if (collapsedBefore > 0) {
					const separator = getLeadingHunkSeparatorLayout({
						type: hunkSeparators,
						metrics: this.metrics,
						hunkIndex,
						hunkSpecs: hunk?.hunkSpecs
					});
					if (separator != null) top += separator.totalHeight;
				}
				if (top >= localViewportTop) {
					if (deletionLine != null) anchor = {
						lineNumber: deletionLine.lineNumber,
						side: "deletions",
						top
					};
					else if (additionLine != null) anchor = {
						lineNumber: additionLine.lineNumber,
						side: "additions",
						top
					};
					if (anchor != null) return true;
				}
				const lineHeight = this.getLineHeight(lineIndex, (additionLine?.noEOFCR ?? false) || (deletionLine?.noEOFCR ?? false));
				top += lineHeight;
				if (collapsedAfter > 0) {
					const separator = getTrailingHunkSeparatorLayout({
						type: hunkSeparators,
						metrics: this.metrics
					});
					if (separator != null) top += separator.totalHeight;
				}
				return false;
			}
		});
		return anchor;
	}
	getVirtualizedHeight() {
		return this.height;
	}
	getAdvancedStickySpecs(windowSpecs) {
		if (this.top == null || this.fileDiff == null) return;
		if (this.options.collapsed === true) return {
			topOffset: this.top,
			height: this.height
		};
		const renderRange = windowSpecs != null ? this.computeRenderRangeFromWindow(this.fileDiff, this.top, windowSpecs) : this.renderRange;
		if (renderRange == null) return;
		const { bufferBefore, bufferAfter, totalLines } = renderRange;
		let headerOnlyOffset = 0;
		if (totalLines === 0) {
			const activeWindow = windowSpecs ?? this.virtualizer.getWindowSpecs();
			if (this.top < activeWindow.top) headerOnlyOffset = bufferAfter;
		}
		return {
			topOffset: this.top + bufferBefore + headerOnlyOffset,
			height: this.height - (bufferBefore + bufferAfter)
		};
	}
	cleanUp(recycle = false) {
		if (this.fileContainer != null && this.isSimpleMode()) this.getSimpleVirtualizer()?.disconnect(this.fileContainer);
		if (!recycle) {
			this.resetLayoutCache({ includeEstimatedHeights: true });
			this.pendingExpansions = void 0;
			this.pendingHydratedDiff = void 0;
		}
		this.isSetup = false;
		super.cleanUp(recycle);
	}
	expandHunk = (hunkIndex, direction, expansionLineCountOverride) => {
		if (this.fileDiff == null) return;
		if (this.isAdvancedMode()) {
			this.pendingExpansions ??= [];
			this.pendingExpansions.push({
				hunkIndex,
				direction,
				expansionLineCountOverride
			});
		} else {
			this.hunksRenderer.expandHunk(hunkIndex, direction, expansionLineCountOverride);
			this.resetLayoutCache({ includeEstimatedHeights: true });
			this.computeApproximateSize();
		}
		this.loadFilesIfNecessary();
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, true);
	};
	async handleFilesLoaded(expectedDiff, files) {
		if (this.fileDiff !== expectedDiff || !expectedDiff.isPartial) return;
		if (this.isAdvancedMode()) {
			const nextDiff = hydratePartialDiff("clone", expectedDiff, files);
			await awaitWithTimeout(() => this.primeHighlightCache(nextDiff));
			if (!this.enabled || this.fileDiff !== expectedDiff) return;
			this.pendingHydratedDiff = {
				expectedDiff,
				nextDiff,
				files
			};
		} else {
			hydratePartialDiff("merge", expectedDiff, files);
			this.setHydratedState(files);
			await awaitWithTimeout(() => this.primeHighlightCache(expectedDiff));
			if (!this.enabled || this.fileDiff !== expectedDiff) return;
			this.resetLayoutCache({ includeEstimatedHeights: true });
			this.computeApproximateSize();
		}
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, true);
	}
	consumeCodeViewLayoutChanges(expectedFileDiff) {
		let hasLayoutChange = false;
		let nextDiff;
		const { pendingExpansions, pendingHydratedDiff } = this;
		if (pendingExpansions != null) {
			this.pendingExpansions = void 0;
			for (const pendingExpansion of pendingExpansions) {
				this.hunksRenderer.expandHunk(pendingExpansion.hunkIndex, pendingExpansion.direction, pendingExpansion.expansionLineCountOverride);
				hasLayoutChange = true;
			}
		}
		if (pendingHydratedDiff != null) {
			this.pendingHydratedDiff = void 0;
			if (pendingHydratedDiff.expectedDiff === expectedFileDiff) {
				this.setHydratedState(pendingHydratedDiff.files);
				nextDiff = pendingHydratedDiff.nextDiff;
			}
		}
		if (nextDiff != null) {
			this.forceRenderOverride = true;
			this.resetLayoutCache({ includeEstimatedHeights: true });
		} else if (hasLayoutChange) {
			this.forceRenderOverride = true;
			this.invalidateDerivedLayoutCache(true);
		}
		return nextDiff;
	}
	loadFilesIfNecessary() {
		if (this.pendingHydratedDiff != null) {
			if (this.pendingHydratedDiff.expectedDiff === this.fileDiff) return;
			this.pendingHydratedDiff = void 0;
		}
		super.loadFilesIfNecessary();
	}
	isLineRenderable(lineNumber) {
		if (super.isLineRenderable(lineNumber)) return true;
		const { pendingExpansions } = this;
		const fileDiff = this.fileDiffCache;
		if (pendingExpansions == null || pendingExpansions.length === 0 || fileDiff == null) return false;
		const { expansionLineCount = 100, collapsedContextThreshold = 1 } = this.options;
		const staged = new Map(this.hunksRenderer.getExpandedHunksMap());
		for (const expansion of pendingExpansions) {
			const region = { ...staged.get(expansion.hunkIndex) ?? {
				fromStart: 0,
				fromEnd: 0
			} };
			const count = expansion.expansionLineCountOverride ?? expansionLineCount;
			if (expansion.direction === "up" || expansion.direction === "both") region.fromStart += count;
			if (expansion.direction === "down" || expansion.direction === "both") region.fromEnd += count;
			staged.set(expansion.hunkIndex, region);
		}
		return isAdditionLineRenderable({
			fileDiff,
			lineNumber,
			expandedHunks: staged,
			collapsedContextThreshold
		});
	}
	/**
	* Invalidate layout after an edit session changed the rendered row set
	* without a line-count change (a mid-session region change or the exit
	* recompute): estimated heights bake the hunk shapes in, and nothing else
	* invalidates them now that editing does not flip expandUnchanged. Public
	* so CodeView can run it when reaping a session whose instance was already
	* released.
	*/
	invalidateEditSessionLayout() {
		this.getSimpleVirtualizer()?.markDOMDirty();
		this.resetLayoutCache({
			forceSimpleRecompute: this.isSimpleMode(),
			includeEstimatedHeights: true,
			resetRenderRange: false
		});
		if (!this.isSimpleMode()) this.computeApproximateSize(true);
		this.getSimpleVirtualizer()?.requestHeightReconcile(this);
	}
	escalateEditSessionRender() {
		this.invalidateEditSessionLayout();
		if (!this.enabled || this.fileDiff == null) return;
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, true);
	}
	shouldSelfHealEditSession() {
		return !this.isAdvancedMode() && super.shouldSelfHealEditSession();
	}
	setVisibility(visible) {
		if (this.isAdvancedMode() || this.fileContainer == null) return;
		this.renderRange = void 0;
		if (visible && !this.isVisible) {
			this.top = this.getVirtualizedTop();
			this.isVisible = true;
		} else if (!visible && this.isVisible) {
			this.isVisible = false;
			this.rerender();
		}
	}
	rerender() {
		if (!this.enabled || this.fileDiff == null && this.additionFile == null && this.deletionFile == null) return;
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, false);
	}
	applyDocumentChange(textDocument, newLineAnnotations, shouldUpdateBuffer = false) {
		const { renderRange: previousRenderRange } = this;
		this.getAdvancedVirtualizer()?.capturePendingLayoutAnchor();
		super.applyDocumentChange(textDocument, newLineAnnotations);
		this.getSimpleVirtualizer()?.markDOMDirty();
		this.resetLayoutCache({
			forceSimpleRecompute: this.isSimpleMode(),
			includeEstimatedHeights: true,
			resetRenderRange: false
		});
		if (!this.isSimpleMode()) this.computeApproximateSize(true);
		else if (shouldUpdateBuffer && previousRenderRange !== void 0 && this.fileDiff !== void 0) {
			const windowSpecs = this.virtualizer.getWindowSpecs();
			const renderRange = this.computeRenderRangeFromWindow(this.fileDiff, this.top ?? 0, windowSpecs);
			if (renderRange.bufferAfter !== previousRenderRange.bufferAfter) this.updateBuffers(renderRange);
		}
		this.forceRenderOverride = true;
		this.virtualizer.instanceChanged(this, true);
	}
	computeApproximateSize(force = false, fileDiff = this.fileDiff) {
		const shouldValidateSize = this.isResizeDebuggingEnabled();
		if (!force && !this.layoutDirty && !shouldValidateSize) return;
		const isFirstCompute = this.height === 0;
		this.height = 0;
		this.cache.checkpoints = [];
		this.cache.totalLines = 0;
		if (fileDiff == null) {
			this.layoutDirty = false;
			return;
		}
		const { disableFileHeader = false, collapsed = false } = this.options;
		const headerRegion = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		this.height += headerRegion;
		if (collapsed) {
			this.layoutDirty = false;
			return;
		}
		this.height = this.getActiveEstimatedHeight(fileDiff) + this.cache.measuredHeightDeltaTotal;
		if (shouldValidateSize && !isFirstCompute) this.validateComputedHeight(fileDiff);
		this.layoutDirty = false;
	}
	getActiveEstimatedHeight(fileDiff = this.fileDiff) {
		this.ensureEstimatedDiffHeights(fileDiff);
		const estimatedHeight = this.getDiffStyle() === "split" ? this.cache.estimatedSplitHeight : this.cache.estimatedUnifiedHeight;
		if (estimatedHeight == null) throw new Error("VirtualizedFileDiff.getActiveEstimatedHeight: missing estimated height");
		return estimatedHeight;
	}
	ensureEstimatedDiffHeights(fileDiff = this.fileDiff) {
		if (fileDiff == null) {
			this.cache.estimatedSplitHeight = void 0;
			this.cache.estimatedUnifiedHeight = void 0;
			return;
		}
		if (this.cache.estimatedSplitHeight != null && this.cache.estimatedUnifiedHeight != null) return;
		const { disableFileHeader = false, expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		const { splitHeight, unifiedHeight } = computeEstimatedDiffHeights({
			fileDiff,
			metrics: this.metrics,
			disableFileHeader,
			hunkSeparators: this.getHunkSeparatorType(),
			expandUnchanged,
			expandedHunks: this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold,
			canHydratePartialDiff: canHydrateCollapsedContext(fileDiff, this.options.loadDiffFiles != null)
		});
		this.cache.estimatedSplitHeight = splitHeight;
		this.cache.estimatedUnifiedHeight = unifiedHeight;
	}
	validateComputedHeight(fileDiff = this.fileDiff) {
		if (this.fileContainer == null || fileDiff == null) return;
		const rect = this.fileContainer.getBoundingClientRect();
		if (rect.height !== this.height) console.log("VirtualizedFileDiff.computeApproximateSize: computed height doesnt match", {
			name: fileDiff.name,
			elementHeight: rect.height,
			computedHeight: this.height
		});
		else console.log("VirtualizedFileDiff.computeApproximateSize: computed height IS CORRECT");
	}
	render({ fileContainer, fileDiff, forceRender = false, lineAnnotations, ...fileInputProps } = {}) {
		const fileInput = getDiffFileInput(fileInputProps, "VirtualizedFileDiff.render");
		const hasFileInput = fileInput != null;
		const oldFile = fileInput?.oldFile;
		const newFile = fileInput?.newFile;
		const filesDidChange = hasFileInput && (!areOptionalFilesEqual(oldFile, this.deletionFile) || !areOptionalFilesEqual(newFile, this.additionFile));
		let nextFileDiff = fileDiff ?? this.fileDiff;
		if (fileDiff == null && hasFileInput && (filesDidChange || this.fileDiff == null)) nextFileDiff = parseDiffFromFile(fileInput.oldFile, fileInput.newFile, this.options.parseDiffOptions);
		const { forceRenderOverride, isSetup } = this;
		this.forceRenderOverride = void 0;
		const annotationsChanged = this.syncLineAnnotations(lineAnnotations);
		if (annotationsChanged) this.resetLayoutCache({ includeEstimatedHeights: false });
		const diffInputChanged = fileDiff != null && fileDiff !== this.fileDiff;
		const targetChanged = nextFileDiff != null && !areDiffTargetsEqual(this.fileDiff, nextFileDiff);
		const dataChanged = diffInputChanged || filesDidChange;
		if (targetChanged) this.resetLayoutCache({ includeEstimatedHeights: true });
		fileContainer = this.getOrCreateFileContainer(fileContainer);
		if (nextFileDiff == null) {
			console.error("VirtualizedFileDiff.render: attempting to virtually render when we dont have the correct data");
			return false;
		}
		if (!isSetup) {
			this.computeApproximateSize(false, nextFileDiff);
			const virtualizer = this.getSimpleVirtualizer();
			this.top ??= this.getVirtualizedTop();
			if (this.isAdvancedMode()) this.isVisible = true;
			else {
				if (virtualizer == null) throw new Error("VirtualizedFileDiff.render: simple virtualizer is not available");
				virtualizer.connect(fileContainer, this);
				this.isVisible = virtualizer.isInstanceVisible(this.top ?? 0, this.height);
			}
			this.isSetup = true;
		} else {
			this.top ??= this.getVirtualizedTop();
			if (targetChanged) {
				this.getSimpleVirtualizer()?.markDOMDirty();
				this.computeApproximateSize(false, nextFileDiff);
			}
		}
		if (!this.isVisible && this.isSimpleMode() && (!dataChanged || !isSetup)) {
			this.fileDiff = nextFileDiff;
			if (fileInput != null) {
				this.deletionFile = oldFile;
				this.additionFile = newFile;
			}
			if (targetChanged) this.cachedHeaderHTML = void 0;
			return this.renderPlaceholder(this.height);
		}
		const windowSpecs = this.virtualizer.getWindowSpecs();
		const fileTop = this.top ?? 0;
		const renderRange = this.computeRenderRangeFromWindow(nextFileDiff, fileTop, windowSpecs);
		const rendered = super.render({
			fileDiff: nextFileDiff,
			fileContainer,
			renderRange,
			lineAnnotations,
			forceRender: (forceRenderOverride ?? forceRender) || annotationsChanged || targetChanged,
			...fileInput,
			...fileInputProps
		});
		if (this.isSimpleMode() && rendered) this.getSimpleVirtualizer()?.requestHeightReconcile(this);
		return rendered;
	}
	syncVirtualizedTop() {
		this.top = this.getVirtualizedTop();
	}
	shouldDisableVirtualizationBuffers() {
		return this.isAdvancedMode() || super.shouldDisableVirtualizationBuffers();
	}
	shouldGuardRebuildScroll() {
		return false;
	}
	isSimpleMode() {
		return this.virtualizer.type === "simple";
	}
	isAdvancedMode() {
		return this.virtualizer.type === "advanced";
	}
	getVirtualizedTop() {
		if (this.virtualizer.type === "advanced") return this.virtualizer.getLocalTopForInstance(this);
		return this.fileContainer != null ? this.virtualizer.getOffsetInScrollContainer(this.fileContainer) : 0;
	}
	getSimpleVirtualizer() {
		return this.virtualizer.type === "simple" ? this.virtualizer : void 0;
	}
	getAdvancedVirtualizer() {
		return this.virtualizer.type === "advanced" ? this.virtualizer : void 0;
	}
	isResizeDebuggingEnabled() {
		return this.getSimpleVirtualizer()?.config.resizeDebugging ?? false;
	}
	getDiffStyle() {
		return this.options.diffStyle ?? "split";
	}
	getHunkSeparatorType() {
		return getOptionHunkSeparatorType(this.options.hunkSeparators);
	}
	approximateLayoutCheckpoints(fileDiff = this.fileDiff) {
		if (!this.layoutDirty && this.cache.checkpoints.length > 0 || fileDiff == null || fileDiff.hunks.length === 0 || this.options.collapsed === true) return;
		const { disableFileHeader = false, expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		const finalHunkIndex = fileDiff.hunks.length - 1;
		const canHydratePartialDiff = canHydrateCollapsedContext(fileDiff, this.options.loadDiffFiles != null);
		const diffStyle = this.getDiffStyle();
		const hunkSeparators = this.getHunkSeparatorType();
		const expandedHunks = expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap();
		const heightDeltaPrefix = createHeightDeltaPrefix(this.cache.heightDeltas);
		let top = getVirtualFileHeaderRegion(this.metrics, disableFileHeader) + this.cache.fileAnnotationHeight;
		let renderedLineIndex = 0;
		const processRows = ({ rowCount, startLineIndex, preSeparatorHeight = 0, postSeparatorHeight = 0, metadataOffsets = [] }) => {
			if (rowCount <= 0) return;
			const blockStart = renderedLineIndex;
			const blockEnd = renderedLineIndex + rowCount;
			let nextCheckpoint = getNextCheckpointIndex(blockStart);
			while (nextCheckpoint < blockEnd) {
				const offset = nextCheckpoint - blockStart;
				const checkpointTop = top + (offset > 0 ? preSeparatorHeight : 0) + offset * this.metrics.lineHeight + countMetadataOffsetsBefore(metadataOffsets, offset) * this.metrics.lineHeight + sumHeightDeltas(heightDeltaPrefix, startLineIndex, startLineIndex + offset);
				this.cache.checkpoints.push({
					renderedLineIndex: nextCheckpoint,
					lineIndex: startLineIndex + offset,
					top: checkpointTop
				});
				nextCheckpoint += VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL;
			}
			top += preSeparatorHeight + rowCount * this.metrics.lineHeight + metadataOffsets.length * this.metrics.lineHeight + sumHeightDeltas(heightDeltaPrefix, startLineIndex, startLineIndex + rowCount) + postSeparatorHeight;
			renderedLineIndex = blockEnd;
		};
		for (let hunkIndex = 0; hunkIndex < fileDiff.hunks.length; hunkIndex++) {
			const hunk = fileDiff.hunks[hunkIndex];
			if (hunk == null) throw new Error("VirtualizedFileDiff.approximateLayoutCheckpoints: invalid hunk index");
			const leadingRegion = getExpandedRegion({
				isPartial: fileDiff.isPartial,
				rangeSize: hunk.collapsedBefore,
				expandedHunks,
				hunkIndex,
				collapsedContextThreshold
			});
			const leadingSeparatorHeight = leadingRegion.collapsedLines > 0 ? getLeadingHunkSeparatorLayout({
				type: hunkSeparators,
				metrics: this.metrics,
				hunkIndex,
				hunkSpecs: hunk.hunkSpecs
			})?.totalHeight ?? 0 : 0;
			processRows({
				rowCount: leadingRegion.fromStart,
				startLineIndex: (diffStyle === "split" ? hunk.splitLineStart : hunk.unifiedLineStart) - leadingRegion.rangeSize
			});
			let pendingLeadingSeparatorHeight = leadingSeparatorHeight;
			processRows({
				rowCount: leadingRegion.fromEnd,
				startLineIndex: (diffStyle === "split" ? hunk.splitLineStart : hunk.unifiedLineStart) - leadingRegion.fromEnd,
				preSeparatorHeight: pendingLeadingSeparatorHeight
			});
			if (leadingRegion.fromEnd > 0) pendingLeadingSeparatorHeight = 0;
			const trailingRegion = hunkIndex === finalHunkIndex ? getTrailingExpandedRegion({
				fileDiff,
				hunkIndex,
				expandedHunks,
				collapsedContextThreshold,
				errorPrefix: "VirtualizedFileDiff"
			}) : void 0;
			const trailingSeparatorHeight = trailingRegion != null && trailingRegion.collapsedLines > 0 ? getTrailingHunkSeparatorLayout({
				type: hunkSeparators,
				metrics: this.metrics
			})?.totalHeight ?? 0 : hunkIndex === finalHunkIndex && canHydratePartialDiff ? getTrailingHunkSeparatorLayout({
				type: hunkSeparators,
				metrics: this.metrics
			})?.totalHeight ?? 0 : 0;
			const trailingExpandedCount = trailingRegion != null ? trailingRegion.fromStart + trailingRegion.fromEnd : 0;
			const hunkBodyRowCount = diffStyle === "split" ? hunk.splitLineCount : hunk.unifiedLineCount;
			const hunkBodyStartLineIndex = diffStyle === "split" ? hunk.splitLineStart : hunk.unifiedLineStart;
			processRows({
				rowCount: hunkBodyRowCount,
				startLineIndex: hunkBodyStartLineIndex,
				preSeparatorHeight: pendingLeadingSeparatorHeight,
				postSeparatorHeight: trailingExpandedCount === 0 ? trailingSeparatorHeight : 0,
				metadataOffsets: getHunkMetadataOffsets({
					diffStyle,
					hunk,
					rowCount: hunkBodyRowCount
				})
			});
			if (trailingRegion != null && trailingExpandedCount > 0) processRows({
				rowCount: trailingExpandedCount,
				startLineIndex: hunkBodyStartLineIndex + hunkBodyRowCount,
				postSeparatorHeight: trailingSeparatorHeight
			});
		}
		this.cache.totalLines = renderedLineIndex;
	}
	getLayoutCheckpointBeforeLineIndex(lineIndex) {
		if (lineIndex <= 0 || this.cache.checkpoints.length === 0) return;
		let low = 0;
		let high = this.cache.checkpoints.length - 1;
		let result;
		while (low <= high) {
			const mid = low + high >> 1;
			const checkpoint = this.cache.checkpoints[mid];
			if (checkpoint == null) throw new Error("VirtualizedFileDiff: invalid checkpoint index");
			if (checkpoint.lineIndex <= lineIndex) {
				result = checkpoint;
				low = mid + 1;
			} else high = mid - 1;
		}
		return result;
	}
	getLayoutCheckpointBeforeTop(top, hunkLineCount) {
		let low = 0;
		let high = this.cache.checkpoints.length - 1;
		let resultIndex = -1;
		while (low <= high) {
			const mid = low + high >> 1;
			const checkpoint = this.cache.checkpoints[mid];
			if (checkpoint == null) throw new Error("VirtualizedFileDiff: invalid checkpoint index");
			if (checkpoint.top <= top) {
				resultIndex = mid;
				low = mid + 1;
			} else high = mid - 1;
		}
		if (hunkLineCount == null) return resultIndex >= 0 ? this.cache.checkpoints[resultIndex] : void 0;
		for (let index = resultIndex; index >= 0; index--) {
			const checkpoint = this.cache.checkpoints[index];
			if (checkpoint == null) throw new Error("VirtualizedFileDiff: invalid checkpoint index");
			if (checkpoint.renderedLineIndex % hunkLineCount === 0) return checkpoint;
		}
	}
	getExpandedLineCount(fileDiff, diffStyle) {
		let count = 0;
		if (fileDiff.isPartial) {
			for (const hunk of fileDiff.hunks) count += diffStyle === "split" ? hunk.splitLineCount : hunk.unifiedLineCount;
			return count;
		}
		const { expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		const expandedHunks = expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap();
		for (const [hunkIndex, hunk] of fileDiff.hunks.entries()) {
			const hunkCount = diffStyle === "split" ? hunk.splitLineCount : hunk.unifiedLineCount;
			count += hunkCount;
			const collapsedBefore = Math.max(hunk.collapsedBefore, 0);
			const { fromStart, fromEnd, renderAll } = getExpandedRegion({
				isPartial: fileDiff.isPartial,
				rangeSize: collapsedBefore,
				expandedHunks,
				hunkIndex,
				collapsedContextThreshold
			});
			if (collapsedBefore > 0) count += renderAll ? collapsedBefore : fromStart + fromEnd;
		}
		const trailingRegion = getTrailingExpandedRegion({
			fileDiff,
			hunkIndex: fileDiff.hunks.length - 1,
			expandedHunks,
			collapsedContextThreshold,
			errorPrefix: "VirtualizedFileDiff"
		});
		if (trailingRegion != null) count += trailingRegion.fromStart + trailingRegion.fromEnd;
		return count;
	}
	getLayoutLineCount(fileDiff, diffStyle) {
		const expandedLineCount = this.getExpandedLineCount(fileDiff, diffStyle);
		const metadataLineCount = diffStyle === "split" ? fileDiff.splitLineCount : fileDiff.unifiedLineCount;
		return Math.max(expandedLineCount, metadataLineCount, fileDiff.additionLines.length, fileDiff.deletionLines.length, this.cache.totalLines);
	}
	computeRenderRangeFromWindow(fileDiff, fileTop, { top, bottom }) {
		const { disableFileHeader = false, expandUnchanged = false, collapsedContextThreshold = 1 } = this.options;
		const { hunkLineCount, lineHeight } = this.metrics;
		const diffStyle = this.getDiffStyle();
		const hunkSeparators = this.getHunkSeparatorType();
		const canHydratePartialDiff = canHydrateCollapsedContext(fileDiff, this.options.loadDiffFiles != null);
		const fileHeight = this.height;
		let lineCount = this.getLayoutLineCount(fileDiff, diffStyle);
		const headerRegion = getVirtualFileHeaderRegion(this.metrics, disableFileHeader);
		const paddingBottom = fileDiff.hunks.length > 0 ? getVirtualFilePaddingBottom(this.metrics) : 0;
		const { fileAnnotationHeight } = this.cache;
		const codeRegionTop = headerRegion + fileAnnotationHeight;
		const codeHeight = Math.max(0, fileHeight - headerRegion - fileAnnotationHeight - paddingBottom);
		const hasFileAnnotations = this.hasFileAnnotations(fileDiff);
		const fileAnnotationTop = fileTop + headerRegion;
		const measuredFileAnnotationVisible = fileAnnotationHeight > 0 && hasFileAnnotations && fileAnnotationTop < bottom && fileAnnotationTop + fileAnnotationHeight > top;
		if (fileTop < top - fileHeight || fileTop > bottom) return {
			startingLine: 0,
			totalLines: 0,
			bufferBefore: 0,
			bufferAfter: fileHeight - headerRegion - paddingBottom
		};
		if (lineCount <= hunkLineCount || fileDiff.hunks.length === 0) return {
			startingLine: 0,
			totalLines: hunkLineCount,
			bufferBefore: 0,
			bufferAfter: 0
		};
		this.approximateLayoutCheckpoints(fileDiff);
		lineCount = this.getLayoutLineCount(fileDiff, diffStyle);
		const estimatedTargetLines = Math.ceil(Math.max(bottom - top, 0) / lineHeight);
		const totalLines = Math.ceil(estimatedTargetLines / hunkLineCount) * hunkLineCount + hunkLineCount;
		const totalHunks = totalLines / hunkLineCount;
		const overflowHunks = totalHunks;
		const hunkOffsets = [];
		const viewportCenter = (top + bottom) / 2;
		const checkpoint = this.getLayoutCheckpointBeforeTop(Math.max(0, top - fileTop - totalLines * lineHeight * 2), hunkLineCount);
		let absoluteLineTop = fileTop + (checkpoint?.top ?? codeRegionTop);
		let currentLine = checkpoint?.renderedLineIndex ?? 0;
		let firstVisibleHunk;
		let centerHunk;
		let overflowCounter;
		iterateOverDiff({
			diff: fileDiff,
			diffStyle,
			startingLine: checkpoint?.renderedLineIndex ?? 0,
			expandedHunks: expandUnchanged ? true : this.hunksRenderer.getExpandedHunksMap(),
			collapsedContextThreshold,
			callback: ({ hunkIndex, hunk, collapsedBefore, collapsedAfter, deletionLine, additionLine }) => {
				const splitLineIndex = additionLine != null ? additionLine.splitLineIndex : deletionLine.splitLineIndex;
				const unifiedLineIndex = additionLine != null ? additionLine.unifiedLineIndex : deletionLine.unifiedLineIndex;
				const hasMetadata = (additionLine?.noEOFCR ?? false) || (deletionLine?.noEOFCR ?? false);
				const isFinalHunkRow = hunkIndex === fileDiff.hunks.length - 1 && hunk != null && (diffStyle === "split" ? splitLineIndex === hunk.splitLineStart + hunk.splitLineCount - 1 : unifiedLineIndex === hunk.unifiedLineStart + hunk.unifiedLineCount - 1);
				const gapAdjustment = (collapsedBefore > 0 ? getLeadingHunkSeparatorLayout({
					type: hunkSeparators,
					metrics: this.metrics,
					hunkIndex,
					hunkSpecs: hunk?.hunkSpecs
				}) : void 0)?.totalHeight ?? 0;
				absoluteLineTop += gapAdjustment;
				const isAtHunkBoundary = currentLine % hunkLineCount === 0;
				const currentHunk = Math.floor(currentLine / hunkLineCount);
				if (isAtHunkBoundary) {
					hunkOffsets[currentHunk] = absoluteLineTop - (fileTop + codeRegionTop + gapAdjustment);
					if (overflowCounter != null) {
						if (overflowCounter <= 0) return true;
						overflowCounter--;
					}
				}
				const lineHeight = this.getLineHeight(diffStyle === "split" ? splitLineIndex : unifiedLineIndex, hasMetadata);
				if (absoluteLineTop > top - lineHeight && absoluteLineTop < bottom) firstVisibleHunk ??= currentHunk;
				if (centerHunk == null && absoluteLineTop + lineHeight > viewportCenter) centerHunk = currentHunk;
				if (overflowCounter == null && absoluteLineTop >= bottom && isAtHunkBoundary) overflowCounter = overflowHunks;
				currentLine++;
				absoluteLineTop += lineHeight;
				if (collapsedAfter > 0 || isFinalHunkRow && canHydratePartialDiff) {
					const trailingSeparator = getTrailingHunkSeparatorLayout({
						type: hunkSeparators,
						metrics: this.metrics
					});
					if (trailingSeparator != null) {
						if (absoluteLineTop < bottom && absoluteLineTop + trailingSeparator.totalHeight > top) firstVisibleHunk ??= currentHunk;
						if (centerHunk == null && absoluteLineTop + trailingSeparator.totalHeight > viewportCenter) centerHunk = currentHunk;
						absoluteLineTop += trailingSeparator.totalHeight;
					}
				}
				return false;
			}
		});
		if (firstVisibleHunk == null) if (measuredFileAnnotationVisible) {
			firstVisibleHunk = 0;
			centerHunk = 0;
		} else return {
			startingLine: 0,
			totalLines: 0,
			bufferBefore: 0,
			bufferAfter: fileHeight - headerRegion - paddingBottom
		};
		centerHunk ??= firstVisibleHunk;
		const idealStartHunk = Math.round(centerHunk - totalHunks / 2);
		const maxStartHunk = Math.max(0, Math.ceil(lineCount / hunkLineCount) - totalHunks);
		const startHunk = Math.max(0, Math.min(idealStartHunk, maxStartHunk));
		const startingLine = startHunk * hunkLineCount;
		const clampedTotalLines = idealStartHunk < 0 ? totalLines + idealStartHunk * hunkLineCount : totalLines;
		const codeBufferBefore = hunkOffsets[startHunk] ?? 0;
		const bufferBefore = startingLine === 0 ? 0 : fileAnnotationHeight + codeBufferBefore;
		const finalHunkIndex = startHunk + clampedTotalLines / hunkLineCount;
		const bufferAfter = finalHunkIndex < hunkOffsets.length ? codeHeight - hunkOffsets[finalHunkIndex] : codeHeight - (absoluteLineTop - fileTop - codeRegionTop);
		return {
			startingLine,
			totalLines: clampedTotalLines,
			bufferBefore,
			bufferAfter: Math.max(0, bufferAfter)
		};
	}
};
function measureFileAnnotationHeight(codeGroups) {
	let height;
	for (const codeGroup of codeGroups) {
		if (codeGroup == null) continue;
		const content = codeGroup.children[1];
		if (!(content instanceof HTMLElement)) continue;
		for (const child of content.children) {
			if (!(child instanceof HTMLElement)) continue;
			if (child.dataset.lineAnnotation !== FILE_ANNOTATION_DOM_KEY) continue;
			height = Math.max(height ?? 0, child.getBoundingClientRect().height);
		}
	}
	return height;
}
function createHeightDeltaPrefix(heightDeltas) {
	const entries = Array.from(heightDeltas).sort((a, b) => a[0] - b[0]);
	const lineIndexes = [];
	const prefixTotals = [0];
	let total = 0;
	for (const [lineIndex, delta] of entries) {
		lineIndexes.push(lineIndex);
		total += delta;
		prefixTotals.push(total);
	}
	return {
		lineIndexes,
		prefixTotals
	};
}
function sumHeightDeltas({ lineIndexes, prefixTotals }, startLineIndex, endLineIndex) {
	if (startLineIndex >= endLineIndex || lineIndexes.length === 0) return 0;
	const start = lowerBound(lineIndexes, startLineIndex);
	return (prefixTotals[lowerBound(lineIndexes, endLineIndex)] ?? 0) - (prefixTotals[start] ?? 0);
}
function lowerBound(values, target) {
	let low = 0;
	let high = values.length;
	while (low < high) {
		const mid = low + high >> 1;
		const value = values[mid];
		if (value == null) throw new Error("VirtualizedFileDiff: invalid prefix index");
		if (value < target) low = mid + 1;
		else high = mid;
	}
	return low;
}
function getNextCheckpointIndex(renderedLineIndex) {
	return Math.ceil(renderedLineIndex / VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL) * VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL;
}
function countMetadataOffsetsBefore(metadataOffsets, offset) {
	let count = 0;
	for (const metadataOffset of metadataOffsets) if (metadataOffset < offset) count++;
	return count;
}
function getHunkMetadataOffsets({ diffStyle, hunk, rowCount }) {
	if (rowCount <= 0 || !hunk.noEOFCRAdditions && !hunk.noEOFCRDeletions) return [];
	const lastContent = hunk.hunkContent.at(-1);
	if (lastContent == null) return [];
	if (lastContent.type === "context") return [rowCount - 1];
	const splitCount = Math.max(lastContent.deletions, lastContent.additions);
	const unifiedCount = lastContent.deletions + lastContent.additions;
	if (diffStyle === "split") return splitCount > 0 && (hunk.noEOFCRAdditions || hunk.noEOFCRDeletions) ? [rowCount - 1] : [];
	const offsets = [];
	const contentStartOffset = rowCount - unifiedCount;
	if (lastContent.deletions > 0 && hunk.noEOFCRDeletions) offsets.push(contentStartOffset + lastContent.deletions - 1);
	if (lastContent.additions > 0 && hunk.noEOFCRAdditions) offsets.push(rowCount - 1);
	return offsets;
}
function hasDiffLayoutOptionChanged(previousOptions, nextOptions) {
	return (previousOptions.diffStyle ?? "split") !== (nextOptions.diffStyle ?? "split") || (previousOptions.overflow ?? "scroll") !== (nextOptions.overflow ?? "scroll") || (previousOptions.collapsed ?? false) !== (nextOptions.collapsed ?? false) || (previousOptions.disableLineNumbers ?? false) !== (nextOptions.disableLineNumbers ?? false) || (previousOptions.disableFileHeader ?? false) !== (nextOptions.disableFileHeader ?? false) || (previousOptions.diffIndicators ?? "bars") !== (nextOptions.diffIndicators ?? "bars") || (previousOptions.hunkSeparators ?? "line-info") !== (nextOptions.hunkSeparators ?? "line-info") || Boolean(previousOptions.loadDiffFiles) !== Boolean(nextOptions.loadDiffFiles) || (previousOptions.expandUnchanged ?? false) !== (nextOptions.expandUnchanged ?? false) || (previousOptions.collapsedContextThreshold ?? 1) !== (nextOptions.collapsedContextThreshold ?? 1) || previousOptions.unsafeCSS !== nextOptions.unsafeCSS;
}
function hasDiffEstimateOptionChanged(previousOptions, nextOptions) {
	return (previousOptions.disableFileHeader ?? false) !== (nextOptions.disableFileHeader ?? false) || (previousOptions.hunkSeparators ?? "line-info") !== (nextOptions.hunkSeparators ?? "line-info") || Boolean(previousOptions.loadDiffFiles) !== Boolean(nextOptions.loadDiffFiles) || (previousOptions.expandUnchanged ?? false) !== (nextOptions.expandUnchanged ?? false) || (previousOptions.collapsedContextThreshold ?? 1) !== (nextOptions.collapsedContextThreshold ?? 1);
}
function canHydrateCollapsedContext(fileDiff, hasFileLoader) {
	return fileDiff.isPartial && hasFileLoader && (fileDiff.type === "change" || fileDiff.type === "rename-changed");
}
function getOptionHunkSeparatorType(hunkSeparators) {
	return typeof hunkSeparators === "function" ? "custom" : hunkSeparators ?? "line-info";
}
function areOptionalFilesEqual(fileA, fileB) {
	if (fileA == null || fileB == null) return fileA == null && fileB == null;
	return areFilesEqual(fileA, fileB);
}
function parseLineIndex(lineIndexAttr, diffStyle) {
	const [unifiedIndex, splitIndex] = lineIndexAttr.split(",").map(Number);
	return diffStyle === "split" ? splitIndex : unifiedIndex;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areManagedSnapshotsEqual.js
function areManagedSnapshotsEqual(previous, next) {
	if (previous == null || next == null) return previous === next;
	if (previous.header !== next.header || previous.footer !== next.footer) return false;
	return areRenderedItemsEqual(previous.items, next.items);
}
function areRenderedItemsEqual(previous, next) {
	if (previous == null || next == null) return previous === next;
	if (previous.length !== next.length) return false;
	for (let index = 0; index < previous.length; index++) {
		const previousItem = previous[index];
		const nextItem = next[index];
		if (previousItem == null || nextItem == null || previousItem.id !== nextItem.id || previousItem.type !== nextItem.type || previousItem.element !== nextItem.element || previousItem.instance !== nextItem.instance || previousItem.version !== nextItem.version) return false;
	}
	return true;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createCodeViewHeaderFooterHostElement.js
function createCodeViewHeaderFooterHostElement(type, container, resizeObserver) {
	const element = document.createElement("div");
	element.style.display = "flow-root";
	if (type === "header") {
		element.setAttribute(CODE_VIEW_HEADER_ATTRIBUTE, "");
		container.before(element);
	} else {
		element.setAttribute(CODE_VIEW_FOOTER_ATTRIBUTE, "");
		container.after(element);
	}
	resizeObserver?.observe(element);
	return element;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/roundToDevicePixel.js
/**
* Snap a CSS-pixel value to the nearest device-pixel boundary. Browsers store
* scrollTop on the device-pixel grid on fractional-DPR displays (1.25x, 1.5x,
* etc.), so rounding computed scroll targets against that grid keeps delta
* math settling cleanly instead of hovering around fractional residuals.
*
* Reads window.devicePixelRatio fresh on each call so monitor-switching and
* zoom changes are picked up without needing to flush any cached value.
*/
function roundToDevicePixel(value) {
	const dpr = window.devicePixelRatio ?? 1;
	return Math.round(value * dpr) / dpr;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/CodeView.js
var CODE_VIEW_DIFF_OPTION_KEYS = [
	"theme",
	"disableLineNumbers",
	"overflow",
	"themeType",
	"disableFileHeader",
	"disableVirtualizationBuffers",
	"preferredHighlighter",
	"useCSSClasses",
	"useTokenTransformer",
	"tokenizeMaxLineLength",
	"tokenizeMaxLength",
	"unsafeCSS",
	"diffStyle",
	"diffIndicators",
	"disableBackground",
	"expandUnchanged",
	"loadDiffFiles",
	"collapsedContextThreshold",
	"lineDiffType",
	"maxLineDiffLength",
	"expansionLineCount",
	"lineHoverHighlight",
	"enableTokenInteractionsOnWhitespace",
	"enableGutterUtility",
	"__debugPointerEvents",
	"enableLineSelection",
	"controlledSelection",
	"disableErrorHandling"
];
var CODE_VIEW_FILE_OPTION_KEYS = [
	"theme",
	"disableLineNumbers",
	"overflow",
	"themeType",
	"disableFileHeader",
	"disableVirtualizationBuffers",
	"preferredHighlighter",
	"useCSSClasses",
	"useTokenTransformer",
	"tokenizeMaxLineLength",
	"tokenizeMaxLength",
	"unsafeCSS",
	"lineHoverHighlight",
	"enableTokenInteractionsOnWhitespace",
	"enableGutterUtility",
	"__debugPointerEvents",
	"enableLineSelection",
	"controlledSelection",
	"disableErrorHandling"
];
var CODE_VIEW_SHARED_CALLBACK_KEYS = [
	"renderCustomHeader",
	"renderHeaderPrefix",
	"renderHeaderFilenameSuffix",
	"renderHeaderMetadata",
	"renderAnnotation",
	"renderGutterUtility",
	"onPostRender",
	"onGutterUtilityClick",
	"onLineClick",
	"onLineNumberClick",
	"onLineEnter",
	"onLineLeave",
	"onTokenClick",
	"onTokenEnter",
	"onTokenLeave"
];
var CODE_VIEW_SELECTION_CALLBACK_KEYS = [
	"onLineSelected",
	"onLineSelectionStart",
	"onLineSelectionChange",
	"onLineSelectionEnd"
];
var CODE_VIEW_ITEM_OPTIONS_STATE = Symbol("CodeView.itemOptionsState");
function defineOptionsState(options, state) {
	Object.defineProperty(options, CODE_VIEW_ITEM_OPTIONS_STATE, {
		configurable: false,
		enumerable: false,
		value: state
	});
}
function getItemOptionsState(options) {
	return options[CODE_VIEW_ITEM_OPTIONS_STATE];
}
function defineItemOption(target, key, get) {
	Object.defineProperty(target, key, {
		configurable: false,
		enumerable: true,
		get() {
			return get(this);
		}
	});
}
var DEFAULT_SCROLL_INTERACTION_RESTORE_DELAY_MS = 120;
var SUB_PIXEL_TOLERANCE = 1;
var SCROLLING_CODE_OVERFLOW_FIX_VARIABLE = "--diffs-overflow-override";
var SCROLL_REBASE_CONTAINER_HEIGHT = 12e6;
var SCROLL_REBASE_TRIGGER_TOP = 1e6;
var SCROLL_REBASE_TARGET_TOP = 2e6;
var SCROLL_REBASE_TARGET_BOTTOM = SCROLL_REBASE_CONTAINER_HEIGHT - SCROLL_REBASE_TARGET_TOP;
var SCROLL_REBASE_THRESHOLD = SCROLL_REBASE_CONTAINER_HEIGHT - SCROLL_REBASE_TRIGGER_TOP;
function assertEditorFactory(createEditor) {
	if (createEditor == null) throw new Error("CodeView: createEditor is required for items with edit: true");
}
var MOBILE_SAFARI = (() => {
	const { navigator } = globalThis;
	const userAgent = navigator.userAgent;
	const isIOS = /iP(?:hone|ad|od)/.test(userAgent);
	const isIPadOS = navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
	return (isIOS || isIPadOS) && /AppleWebKit/.test(userAgent) && /Safari/.test(userAgent) && !/(CriOS|FxiOS|EdgiOS|OPiOS)/.test(userAgent);
})();
var CodeView = class CodeView {
	static __STOP = false;
	static __lastScrollPosition = 0;
	type = "advanced";
	config = {
		overscrollSize: 200,
		intersectionObserverMargin: 0,
		resizeDebugging: false
	};
	items = [];
	idToItem = /* @__PURE__ */ new Map();
	selectedLines = null;
	itemEditors = /* @__PURE__ */ new Map();
	attachedEditors = /* @__PURE__ */ new Set();
	instanceToItem = /* @__PURE__ */ new Map();
	layoutDirtyIndex;
	pendingLayoutReset;
	renderOptionsRevision = 0;
	slotCoordinator;
	slotSnapshot;
	scrollListeners = /* @__PURE__ */ new Set();
	scrollHeight = 0;
	containerHeight = -1;
	scrollTop = 0;
	scrollPageOffset = 0;
	scrollDirty = true;
	scrollInteractionFixTimer;
	pointerEventsDisabled = false;
	codeOverflowFix = false;
	height = 0;
	heightDirty = true;
	windowSpecs = {
		top: 0,
		bottom: 0
	};
	renderState = {
		scrollTop: -1,
		firstIndex: -1,
		lastIndex: -1,
		stickyHeight: 0,
		stickyTop: -1,
		stickyBottom: -1
	};
	itemMetricsCache = DEFAULT_CODE_VIEW_FILE_METRICS;
	fileOptionsPrototype;
	diffOptionsPrototype;
	pendingScrollTarget;
	pendingLayoutAnchor;
	shouldFixContainerFocus = false;
	scrollAnimation;
	root;
	resizeObserver;
	container = document.createElement("div");
	stickyContainer = document.createElement("div");
	stickyOffset = document.createElement("div");
	header = {
		element: void 0,
		render: void 0,
		height: 0
	};
	footer = {
		element: void 0,
		render: void 0,
		height: 0
	};
	elementPool = [];
	elementPoolVersion = 0;
	elementPoolTracker = /* @__PURE__ */ new WeakMap();
	pendingElementPool = [];
	options;
	workerManager;
	isReadySubscription;
	isContainerManaged;
	constructor(options = { theme: DEFAULT_THEMES }, workerManager, isContainerManaged = false) {
		this.options = options;
		this.computeMetricsCache(options.itemMetrics);
		this.fileOptionsPrototype = this.createFileOptionsPrototype();
		this.diffOptionsPrototype = this.createDiffOptionsPrototype();
		this.workerManager = workerManager;
		this.isContainerManaged = isContainerManaged;
		this.stickyOffset.style.contain = "layout size";
		this.stickyContainer.style.position = "sticky";
		this.stickyContainer.style.width = "100%";
		this.stickyContainer.style.contain = "layout style inline-size";
		this.stickyContainer.style.isolation = "isolate";
		this.stickyContainer.style.display = "flex";
		this.stickyContainer.style.flexDirection = "column";
	}
	getLayout() {
		return this.options.layout ?? DEFAULT_CODE_VIEW_LAYOUT;
	}
	getItemTopOffset() {
		return this.getLayout().paddingTop + this.header.height;
	}
	computeMetricsCache(itemMetrics) {
		this.itemMetricsCache = {
			hunkLineCount: itemMetrics?.hunkLineCount ?? DEFAULT_CODE_VIEW_FILE_METRICS.hunkLineCount,
			lineHeight: itemMetrics?.lineHeight ?? DEFAULT_CODE_VIEW_FILE_METRICS.lineHeight,
			diffHeaderHeight: itemMetrics?.diffHeaderHeight ?? DEFAULT_CODE_VIEW_FILE_METRICS.diffHeaderHeight,
			hunkSeparatorHeight: itemMetrics?.hunkSeparatorHeight,
			spacing: itemMetrics?.spacing ?? DEFAULT_CODE_VIEW_FILE_METRICS.spacing,
			paddingTop: itemMetrics?.paddingTop,
			paddingBottom: itemMetrics?.paddingBottom
		};
		return this.itemMetricsCache;
	}
	getSmoothScrollSettings() {
		return this.options.smoothScrollSettings ?? DEFAULT_SMOOTH_SCROLL_SETTINGS;
	}
	shouldDisablePointerEvents() {
		return this.options.pointerEventsOnScroll !== true;
	}
	shouldValidateItemHeights() {
		return DIFFS_DEVELOPMENT_BUILD && this.options.__devOnlyValidateItemHeights === true;
	}
	validateRenderedItemHeight(item) {
		if (!this.shouldValidateItemHeights() || item.element == null) return;
		const stickySpecs = item.instance.getAdvancedStickySpecs();
		if (stickySpecs == null) return;
		const expectedHeight = stickySpecs.height;
		const actualHeight = item.element.getBoundingClientRect().height;
		if (expectedHeight === actualHeight) return;
		console.error("CodeView: reconciled item height does not match DOM height", {
			id: item.item.id,
			type: item.type,
			index: item.index,
			version: item.version,
			expectedHeight,
			actualHeight,
			delta: actualHeight - expectedHeight,
			stickyTopOffset: stickySpecs.topOffset,
			virtualizedHeight: item.instance.getVirtualizedHeight(),
			top: item.top,
			scrollTop: this.getScrollTop(),
			windowSpecs: { ...this.windowSpecs },
			element: item.element,
			instance: item.instance
		});
	}
	validateStickyContainerHeight() {
		if (!this.shouldValidateItemHeights()) return;
		const { firstIndex, lastIndex, stickyHeight, stickyTop, stickyBottom } = this.renderState;
		if (firstIndex === -1 || lastIndex === -1) return;
		const actualHeight = this.stickyContainer.getBoundingClientRect().height;
		if (Math.abs(actualHeight - stickyHeight) < SUB_PIXEL_TOLERANCE) return;
		console.error("CodeView: sticky container height does not match computed layout", {
			computedStickyHeight: stickyHeight,
			actualStickyHeight: actualHeight,
			delta: actualHeight - stickyHeight,
			stickyTop,
			stickyBottom,
			firstIndex,
			lastIndex,
			firstStickySpecs: this.items[firstIndex]?.instance.getAdvancedStickySpecs(),
			lastStickySpecs: this.items[lastIndex]?.instance.getAdvancedStickySpecs(),
			scrollTop: this.getScrollTop(),
			scrollPageOffset: this.scrollPageOffset,
			windowSpecs: { ...this.windowSpecs },
			stickyContainer: this.stickyContainer
		});
	}
	clearScrollInteractionTimer() {
		if (this.scrollInteractionFixTimer != null) {
			clearTimeout(this.scrollInteractionFixTimer);
			this.scrollInteractionFixTimer = void 0;
		}
	}
	suspendScrollInteractions() {
		this.clearScrollInteractionTimer();
		if (this.shouldDisablePointerEvents() && !this.pointerEventsDisabled) {
			this.stickyContainer.style.pointerEvents = "none";
			this.pointerEventsDisabled = true;
		}
		if (MOBILE_SAFARI && !this.codeOverflowFix) {
			this.stickyContainer.style.setProperty(SCROLLING_CODE_OVERFLOW_FIX_VARIABLE, "hidden");
			this.codeOverflowFix = true;
		}
		this.scrollInteractionFixTimer = setTimeout(this.restoreScrollInteractions, DEFAULT_SCROLL_INTERACTION_RESTORE_DELAY_MS);
	}
	restoreScrollInteractions = () => {
		this.clearScrollInteractionTimer();
		if (this.pointerEventsDisabled) {
			this.stickyContainer.style.removeProperty("pointer-events");
			this.pointerEventsDisabled = false;
		}
		if (this.codeOverflowFix) {
			this.stickyContainer.style.setProperty(SCROLLING_CODE_OVERFLOW_FIX_VARIABLE, "auto");
			this.codeOverflowFix = false;
		}
	};
	syncLayout() {
		const { gap, paddingBottom, paddingTop } = this.getLayout();
		this.stickyContainer.style.gap = `${gap}px`;
		this.container?.style.setProperty("margin-top", `${paddingTop}px`);
		this.container?.style.setProperty("margin-bottom", `${paddingBottom}px`);
	}
	reconcileHeaderFooterHosts() {
		const headerChanged = this.reconcileHost("header");
		const footerChanged = this.reconcileHost("footer");
		return headerChanged || footerChanged;
	}
	reconcileHost(type) {
		const { root, container } = this;
		if (root == null || container == null) return false;
		const host = type === "header" ? this.header : this.footer;
		const render = type === "header" ? this.options.renderCodeViewHeader : this.options.renderCodeViewFooter;
		if (render == null) {
			if (host.element == null) return false;
			this.resizeObserver?.unobserve(host.element);
			host.element.remove();
			host.element = void 0;
			host.render = void 0;
			this.setHostHeight(host, 0);
			return false;
		}
		if (host.element != null && render === host.render) return false;
		const element = host.element ?? createCodeViewHeaderFooterHostElement(type, container, this.resizeObserver);
		host.element = element;
		const content = render();
		if (content != null) element.replaceChildren(content);
		else if (!this.isContainerManaged && element.children.length > 0) element.textContent = "";
		host.render = render;
		return true;
	}
	setHostHeight(host, height) {
		if (host.height === height) return;
		host.height = height;
		this.scrollDirty = true;
	}
	measureMountedHosts() {
		if (this.header.element != null) this.setHostHeight(this.header, this.header.element.getBoundingClientRect().height);
		if (this.footer.element != null) this.setHostHeight(this.footer, this.footer.element.getBoundingClientRect().height);
	}
	setup(root) {
		if (this.root != null) throw new Error("CodeView.setup: already setup");
		this.workerManager?.subscribeToThemeChanges(this);
		this.root = root;
		this.root.style.overflowAnchor = "none";
		if (!this.root.hasAttribute("tabindex")) this.root.tabIndex = -1;
		this.container ??= document.createElement("div");
		this.container.style.contain = "layout style";
		this.syncLayout();
		this.container.appendChild(this.stickyOffset);
		this.container.appendChild(this.stickyContainer);
		this.root.appendChild(this.container);
		this.scrollDirty = true;
		this.heightDirty = true;
		this.resizeObserver = new ResizeObserver(this.handleResize);
		this.resizeObserver.observe(this.stickyContainer);
		this.root.addEventListener("scroll", this.handleScroll, { passive: true });
		this.root.addEventListener("wheel", this.clearPendingScroll, { passive: true });
		this.root.addEventListener("touchstart", this.clearPendingScroll, { passive: true });
		this.root.addEventListener("pointerdown", this.clearPendingScroll, { passive: true });
		this.root.addEventListener("keydown", this.clearPendingScroll, { passive: true });
		this.resizeObserver.observe(this.root);
		this.render(true);
		window.__INSTANCE = this;
		window.__TOGGLE = () => {
			if (CodeView.__STOP) {
				CodeView.__STOP = false;
				this.scrollTo({
					type: "position",
					position: CodeView.__lastScrollPosition,
					behavior: "instant"
				});
			} else {
				CodeView.__lastScrollPosition = this.getScrollTop();
				CodeView.__STOP = true;
			}
		};
	}
	reset() {
		dequeueRender(this.computeRenderRangeAndEmit);
		this.clearReadySubscription();
		this.restoreScrollInteractions();
		this.cleanAllRenderedItems();
		for (const record of this.itemEditors.values()) record.editor.cleanUp();
		this.itemEditors.clear();
		this.attachedEditors.clear();
		this.selectedLines = null;
		this.items.length = 0;
		this.idToItem.clear();
		this.instanceToItem.clear();
		this.layoutDirtyIndex = void 0;
		this.pendingLayoutReset = void 0;
		this.stickyContainer.textContent = "";
		this.stickyOffset.style.height = "";
		this.container?.style.removeProperty("height");
		this.containerHeight = -1;
		this.windowSpecs = {
			top: 0,
			bottom: 0
		};
		this.pendingLayoutAnchor = void 0;
		this.shouldFixContainerFocus = false;
		this.height = 0;
		this.scrollTop = 0;
		this.scrollPageOffset = 0;
		this.scrollHeight = 0;
		this.scrollDirty = true;
		this.heightDirty = true;
		this.resetRenderState();
		if (!this.isContainerManaged) this.flushSlotCoordinator();
	}
	cleanUp() {
		this.reset();
		this.clearElementPool();
		this.restoreScrollInteractions();
		this.workerManager?.unsubscribeToThemeChanges(this);
		this.resizeObserver?.disconnect();
		this.resizeObserver = void 0;
		this.root?.removeEventListener("scroll", this.handleScroll);
		this.root?.removeEventListener("wheel", this.clearPendingScroll);
		this.root?.removeEventListener("touchstart", this.clearPendingScroll);
		this.root?.removeEventListener("pointerdown", this.clearPendingScroll);
		this.root?.removeEventListener("keydown", this.clearPendingScroll);
		this.root?.style.removeProperty("overflow-anchor");
		this.container?.remove();
		this.stickyOffset.remove();
		this.stickyContainer.remove();
		this.stickyContainer.textContent = "";
		this.header.element?.remove();
		this.header.element = void 0;
		this.header.render = void 0;
		this.header.height = 0;
		this.footer.element?.remove();
		this.footer.element = void 0;
		this.footer.render = void 0;
		this.footer.height = 0;
		this.root = void 0;
		this.container = void 0;
	}
	cleanAllRenderedItems() {
		if (this.renderState.firstIndex === -1) return;
		for (let index = this.renderState.firstIndex; index <= this.renderState.lastIndex; index++) {
			const item = this.items[index];
			if (item == null) throw new Error(`CodeView.cleanAllRenderedItems: Item does not exist at index: ${index}`);
			this.releaseRenderedItem(item);
		}
	}
	primeScrollTarget(target) {
		if (target.type === "position") return;
		const item = this.idToItem.get(target.id);
		if (item == null) return;
		item.instance.primeHighlightCache();
	}
	getElementPoolLimit() {
		const viewportSize = this.getHeight() + this.config.overscrollSize * 2;
		const { diffHeaderHeight } = this.itemMetricsCache;
		return Math.max(8, Math.ceil(viewportSize / Math.max(diffHeaderHeight, 10)) + 1) * (this.isContainerManaged ? 2 : 1);
	}
	acquireElement() {
		this.promotePendingPooledElements();
		let element = this.elementPool.pop();
		while (element != null && !this.isElementPoolGenerationCurrent(element)) element = this.elementPool.pop();
		element ??= document.createElement(DIFFS_TAG_NAME);
		this.markElementPoolGenerationCurrent(element);
		return element;
	}
	releaseRenderedItem(item) {
		const { element } = item;
		if (element != null && this.renderedItemOwnsFocus(element)) this.shouldFixContainerFocus = true;
		item.instance.cleanUp(true);
		this.attachedEditors.delete(item.item.id);
		item.element = void 0;
		if (element == null) return;
		element.remove();
		this.cleanElement(element);
		this.queueElementForPool(element);
	}
	renderedItemOwnsFocus(element) {
		const { activeElement } = document;
		return activeElement === element || element.contains(activeElement) || element.shadowRoot?.activeElement != null;
	}
	fixContainerFocus() {
		if (this.shouldFixContainerFocus) {
			this.shouldFixContainerFocus = false;
			this.root?.focus({ preventScroll: true });
		}
	}
	cleanElement(element) {
		const { shadowRoot } = element;
		if (shadowRoot != null) {
			for (const child of Array.from(shadowRoot.children)) if (!isPooledShadowChild(child)) child.remove();
		}
		if (!this.isContainerManaged) element.replaceChildren();
	}
	queueElementForPool(element) {
		const poolLimit = this.getElementPoolLimit();
		if (!this.isElementPoolGenerationCurrent(element) || this.getElementPoolSize() >= poolLimit) return;
		if (this.isElementClean(element)) this.elementPool.push(element);
		else this.pendingElementPool.push(element);
	}
	promotePendingPooledElements() {
		if (this.pendingElementPool.length === 0) return;
		const { pendingElementPool: pendingElements } = this;
		this.pendingElementPool = [];
		const poolLimit = this.getElementPoolLimit();
		for (const element of pendingElements) if (this.isElementPoolGenerationCurrent(element) && this.isElementClean(element) && this.elementPool.length < poolLimit) this.elementPool.push(element);
		else if (this.isElementPoolGenerationCurrent(element) && this.getElementPoolSize() < poolLimit) this.pendingElementPool.push(element);
	}
	isElementClean(element) {
		return element.childNodes.length === 0;
	}
	getElementPoolSize() {
		return this.elementPool.length + this.pendingElementPool.length;
	}
	clearElementPool() {
		this.elementPool.length = 0;
		this.pendingElementPool.length = 0;
	}
	invalidateElementPool() {
		this.elementPoolVersion++;
		this.clearElementPool();
	}
	markElementPoolGenerationCurrent(element) {
		this.elementPoolTracker.set(element, this.elementPoolVersion);
	}
	isElementPoolGenerationCurrent(element) {
		return this.elementPoolTracker.get(element) === this.elementPoolVersion;
	}
	resolveEffectiveScrollBehavior(target, destination) {
		if (prefersReducedMotion()) return "instant";
		if (target.behavior !== "smooth-auto") return target.behavior ?? "instant";
		return Math.abs(destination - this.getScrollTop()) <= this.getHeight() * 10 ? "smooth" : "instant";
	}
	scrollTo(target) {
		if (this.root == null) return;
		const pendingTarget = this.normalizeScrollTarget(target);
		if (pendingTarget == null) return;
		const destination = this.resolveScrollTargetTop(pendingTarget);
		if (destination == null) return;
		this.primeScrollTarget(pendingTarget);
		if (this.resolveEffectiveScrollBehavior(pendingTarget, destination) === "smooth") this.scrollAnimation ??= {
			position: this.getScrollTop(),
			velocity: 0,
			lastTimestamp: performance.now()
		};
		else this.scrollAnimation = void 0;
		this.suspendScrollInteractions();
		this.pendingLayoutAnchor = void 0;
		this.pendingScrollTarget = pendingTarget;
		this.render();
	}
	setSelectedLines(selection, options) {
		this.applySelectedLines(selection, options);
	}
	getSelectedLines() {
		return this.selectedLines;
	}
	clearSelectedLines(options) {
		this.applySelectedLines(null, options);
	}
	getItem(itemId) {
		return this.idToItem.get(itemId)?.item;
	}
	/**
	* Get the live editor for an item currently in edit mode. Use this to drive
	* editor APIs CodeView does not wrap (applyEdits, undo, setMarkers, …).
	* Returns undefined once the item leaves edit mode.
	*/
	getEditor(itemId) {
		return this.itemEditors.get(itemId)?.editor;
	}
	updateItem(input) {
		const item = this.idToItem.get(input.id);
		if (item == null) {
			console.error(`CodeView.updateItem: unknown item id "${input.id}"`);
			return false;
		}
		if (!this.syncItemRecord(item, input)) return false;
		this.markItemLayoutDirty(item);
		this.scrollDirty = true;
		this.render();
		this.syncItemEditors();
		this.syncSelection();
		return true;
	}
	updateItemId(oldId, newId) {
		if (oldId === newId) return true;
		const item = this.idToItem.get(oldId);
		if (item == null) {
			console.error(`CodeView.updateItemId: unknown item id "${oldId}"`);
			return false;
		}
		if (this.idToItem.has(newId)) {
			console.error(`CodeView.updateItemId: duplicate item id "${newId}"`);
			return false;
		}
		this.idToItem.delete(oldId);
		item.item.id = newId;
		this.idToItem.set(newId, item);
		this.updateItemOptionsId(item.instance.options, newId);
		if (this.selectedLines?.id === oldId) {
			this.selectedLines = {
				...this.selectedLines,
				id: newId
			};
			this.options.onSelectedLinesChange?.(this.selectedLines);
		}
		const editorRecord = this.itemEditors.get(oldId);
		if (editorRecord != null) {
			editorRecord.state.id = newId;
			this.itemEditors.delete(oldId);
			this.itemEditors.set(newId, editorRecord);
			if (this.attachedEditors.delete(oldId)) this.attachedEditors.add(newId);
		}
		this.renamePendingScrollTarget(oldId, newId);
		this.renamePendingLayoutAnchor(oldId, newId);
		this.render();
		return true;
	}
	addItem(input) {
		this.addItems([input]);
	}
	addItems(inputs) {
		this.appendItemsInternal(inputs);
		this.syncItemEditors();
		this.syncSelection();
	}
	removeItem(itemId) {
		const item = this.idToItem.get(itemId);
		if (item == null) {
			console.error(`CodeView.removeItem: unknown item id "${itemId}"`);
			return false;
		}
		const nextItems = [];
		for (const current of this.items) if (current !== item) nextItems.push(current.item);
		this.setItems(nextItems);
		return true;
	}
	setItems(items) {
		let removedItemsById;
		if (this.items.length === 0) this.appendItemsInternal(items);
		else if (!this.tryAppendItems(items)) removedItemsById = this.reconcileItems(items);
		this.syncItemEditors(removedItemsById);
		this.syncSelection();
	}
	/**
	* Append new records to the viewer while preserving existing layout state.
	* This is the shared path for imperative adds and the append-only reconcile
	* fast path, so it measures new items immediately and only triggers render
	* once at the end.
	*/
	appendItemsInternal(inputs, render = true) {
		if (inputs.length === 0) return;
		const layout = this.getLayout();
		let nextTop = this.items.length === 0 ? 0 : this.scrollHeight + layout.gap;
		const appendedTop = nextTop;
		for (let index = 0; index < inputs.length; index++) {
			const input = inputs[index];
			if (input == null) throw new Error("CodeView.appendItemsInternal: missing input item");
			if (this.idToItem.has(input.id)) throw new Error(`CodeView.addItem: duplicate id "${input.id}"`);
			const item = this.createItem(input, this.items.length, nextTop);
			this.items.push(item);
			this.idToItem.set(item.item.id, item);
			this.instanceToItem.set(item.instance, item);
			item.height = prepareItemInstance(item);
			nextTop += item.height + layout.gap;
		}
		this.scrollHeight = nextTop - layout.gap;
		this.scrollDirty = true;
		if (render) if (this.canSkipRenderForAppend(appendedTop)) this.syncContainerHeight();
		else this.render();
	}
	canSkipRenderForAppend(appendedTop) {
		return this.container != null && this.renderState.firstIndex !== -1 && this.pendingScrollTarget == null && this.scrollAnimation == null && this.layoutDirtyIndex == null && appendedTop > this.windowSpecs.bottom;
	}
	onThemeChange() {
		this.invalidateElementPool();
	}
	setOptions(options) {
		if (options == null) return;
		this.capturePendingLayoutAnchor();
		const { options: prevOptions } = this;
		const previousLayout = this.getLayout();
		const { itemMetricsCache: previousItemMetrics } = this;
		if (shouldClearPool(prevOptions, options)) this.invalidateElementPool();
		this.options = options;
		const nextItemMetrics = this.computeMetricsCache(options.itemMetrics);
		const itemMetricsChanged = !areObjectsEqual(previousItemMetrics, nextItemMetrics);
		const layoutChanged = !areObjectsEqual(previousLayout, this.getLayout());
		if (layoutChanged) this.syncLayout();
		const itemLayoutChanged = itemMetricsChanged || hasItemLayoutOptionChanged(prevOptions, options);
		if (itemLayoutChanged) {
			const previousReset = this.pendingLayoutReset;
			this.pendingLayoutReset = {
				metrics: itemMetricsChanged ? nextItemMetrics : previousReset?.metrics,
				resetFileLayoutCache: true,
				resetDiffLayoutCache: true,
				includeEstimatedDiffHeights: previousReset?.includeEstimatedDiffHeights === true || itemMetricsChanged || hasCodeViewDiffEstimateOptionChanged(prevOptions, options)
			};
		}
		if (layoutChanged || itemLayoutChanged) {
			this.markLayoutDirtyFromIndex(0);
			this.scrollDirty = true;
		}
		if (!areOptionsEqual(prevOptions, options)) this.renderOptionsRevision++;
		this.syncItemEditors();
		const headerFooterChanged = prevOptions.renderCodeViewHeader !== options.renderCodeViewHeader || prevOptions.renderCodeViewFooter !== options.renderCodeViewFooter;
		if (!this.isContainerManaged && (this.items.length > 0 || headerFooterChanged)) this.render();
	}
	capturePendingLayoutAnchor(nextItems = this.idToItem) {
		if (this.root == null || this.items.length === 0 || this.pendingScrollTarget != null) return;
		this.pendingLayoutAnchor = this.getScrollAnchor(this.getScrollTop(), nextItems);
	}
	render(immediate = false) {
		if (CodeView.__STOP) return;
		if (immediate) {
			dequeueRender(this.computeRenderRangeAndEmit);
			this.computeRenderRangeAndEmit();
		} else queueRender(this.computeRenderRangeAndEmit);
	}
	isReady() {
		const { workerManager } = this;
		if (workerManager == null || workerManager.isInitialized() || workerManager.getStats().workersFailed) {
			this.clearReadySubscription();
			return true;
		}
		this.isReadySubscription ??= workerManager.subscribeToStatChanges((stats) => {
			if (stats.managerState !== "initialized" && !stats.workersFailed) return;
			this.clearReadySubscription();
			this.render(true);
		});
		if (workerManager.getStats().managerState === "waiting") workerManager.initialize().catch(() => {});
		return false;
	}
	clearReadySubscription() {
		if (this.isReadySubscription == null) return;
		this.isReadySubscription();
		this.isReadySubscription = void 0;
	}
	instanceChanged(instance, layoutDirty) {
		const item = this.instanceToItem.get(instance);
		if (item == null) throw new Error("CodeView.instanceChanged: An instance has changed that is not registered");
		if (layoutDirty) this.markItemLayoutDirty(item);
		this.render();
	}
	getWindowSpecs() {
		return this.windowSpecs;
	}
	getContainerElement() {
		return this.root;
	}
	getHeaderElement() {
		return this.header.element;
	}
	getFooterElement() {
		return this.footer.element;
	}
	getRenderedItems() {
		const { firstIndex, lastIndex } = this.renderState;
		if (firstIndex === -1 || lastIndex === -1 || lastIndex < firstIndex) return [];
		const renderedItems = [];
		for (let index = firstIndex; index <= lastIndex; index++) {
			const item = this.items[index];
			if (item?.element == null) continue;
			if (item.type === "diff") renderedItems.push({
				id: item.item.id,
				type: "diff",
				item: item.item,
				version: item.version,
				element: item.element,
				instance: item.instance
			});
			else renderedItems.push({
				id: item.item.id,
				type: "file",
				item: item.item,
				version: item.version,
				element: item.element,
				instance: item.instance
			});
		}
		return renderedItems;
	}
	setSlotCoordinator(coordinator) {
		if (coordinator === this.slotCoordinator) return false;
		this.slotCoordinator = coordinator;
		this.slotSnapshot = void 0;
		return true;
	}
	getSlotSnapshot(coordinator) {
		return this.buildSlotSnapshot(coordinator);
	}
	buildSlotSnapshot(coordinator) {
		const items = getSlotItems(this.getRenderedItems(), coordinator);
		const { element: header } = this.header;
		const { element: footer } = this.footer;
		if (items == null && header == null && footer == null) return;
		return {
			items,
			header,
			footer
		};
	}
	subscribeToScroll(listener) {
		this.scrollListeners.add(listener);
		return () => {
			this.scrollListeners.delete(listener);
		};
	}
	getLocalTopForInstance(instance) {
		const item = this.instanceToItem.get(instance);
		if (item == null) throw new Error("CodeView.getLocalTopForInstance: unknown virtualized instance");
		return item.top;
	}
	getTopForItem(id) {
		const item = this.idToItem.get(id);
		if (item == null) return;
		return item.top + this.getItemTopOffset();
	}
	createItem(input, index, top) {
		const { itemMetricsCache: itemMetrics } = this;
		if (input.type === "diff") {
			const instance = new VirtualizedFileDiff(this.createDiffOptions(input.id), this, itemMetrics, this.workerManager, this.isContainerManaged);
			return {
				type: "diff",
				item: input,
				version: input.version,
				index,
				top,
				height: 0,
				element: void 0,
				renderedOptionsRevision: this.renderOptionsRevision,
				instance
			};
		}
		const instance = new VirtualizedFile(this.createFileOptions(input.id), this, itemMetrics, this.workerManager, this.isContainerManaged);
		return {
			type: "file",
			item: input,
			version: input.version,
			index,
			top,
			height: 0,
			element: void 0,
			renderedOptionsRevision: this.renderOptionsRevision,
			instance
		};
	}
	applySelectedLines(selection, options) {
		const { selectedLines: prevSelection } = this;
		if (selection == null && prevSelection == null || selection != null && prevSelection?.id === selection.id && areSelectionsEqual(prevSelection.range, selection.range)) return;
		if (prevSelection != null && prevSelection.id !== selection?.id) this.idToItem.get(prevSelection.id)?.instance.setSelectedLines(null, { notify: false });
		this.selectedLines = selection;
		this.idToItem.get(selection?.id ?? "")?.instance.setSelectedLines(selection?.range ?? null, options);
	}
	syncSelection() {
		if (this.selectedLines == null) return;
		const item = this.idToItem.get(this.selectedLines.id);
		if (item == null) {
			this.selectedLines = null;
			this.options.onSelectedLinesChange?.(null);
			return;
		}
		item.instance.setSelectedLines(this.selectedLines.range, { notify: false });
	}
	isItemInEditMode(item) {
		return item.item.edit === true && item.item.collapsed !== true;
	}
	/**
	* Attach (or lazily create) the editor for a mounted edit-mode item. Called
	* from the render loop so every mounted item passes through it: fresh
	* mounts, remounts after virtualization released the item, and items whose
	* edit flag was just turned on. Editors persist across unmounts, so a
	* remounted item re-attaches its existing editor and resumes the retained
	* document; the renderers keep the host's file/diff data in sync with the
	* session so the remount paints the edited text.
	*/
	attachItemEditor(item) {
		const { id } = item.item;
		const { createEditor } = this.options;
		if (item.element == null || this.attachedEditors.has(id) || !this.isItemInEditMode(item)) return;
		let record = this.itemEditors.get(id);
		let createdEditor = false;
		try {
			if (record == null) {
				assertEditorFactory(createEditor);
				const state = { id };
				const editor = createEditor({ onChange: (file, lineAnnotations) => {
					const latest = this.idToItem.get(state.id);
					if (latest == null) return;
					state.lastChange = {
						item: latest.item,
						file,
						lineAnnotations
					};
					this.options.onItemEditChange?.(latest.item, file, lineAnnotations);
				} });
				if (editor == null) return;
				record = {
					editor,
					state
				};
				this.itemEditors.set(id, record);
				createdEditor = true;
			}
			record.editor.edit(item.instance);
			this.attachedEditors.add(id);
		} catch (error) {
			if (createdEditor && record != null) {
				this.itemEditors.delete(id);
				record.editor.cleanUp();
			}
			this.releaseRenderedItem(item);
			throw error;
		}
	}
	/**
	* Drop editors for items that can no longer be edited: removed, edit turned
	* off, or collapsed. Attachment happens in the render loop via
	* attachItemEditor, so this only reconciles editors CodeView is already
	* holding.
	*/
	syncItemEditors(removedItems) {
		if (this.itemEditors.size === 0) return;
		const completions = [];
		for (const [id, record] of this.itemEditors) {
			const item = this.idToItem.get(id);
			const removedItem = removedItems?.get(id);
			if (removedItem == null && item != null && this.isItemInEditMode(item)) continue;
			record.editor.cleanUp();
			this.itemEditors.delete(id);
			this.attachedEditors.delete(id);
			const { lastChange } = record.state;
			const itemSnapshot = removedItem == null ? item?.item ?? lastChange?.item : lastChange?.item ?? removedItem.item;
			if (itemSnapshot?.type === "diff") {
				if (removedItem == null && item != null && item.type === "diff" && item.instance.completeEditSession()) {
					this.markItemLayoutDirty(item);
					this.render();
				}
				finishEditSessionForDiff(itemSnapshot.fileDiff);
			}
			if (lastChange != null) completions.push(removedItem != null || item == null ? lastChange : {
				...lastChange,
				item: item.item
			});
		}
		for (const { item, file, lineAnnotations } of completions) this.options.onItemEditComplete?.(item, file, lineAnnotations);
	}
	renamePendingScrollTarget(oldId, newId) {
		const { pendingScrollTarget } = this;
		if (pendingScrollTarget == null || pendingScrollTarget.type === "position" || pendingScrollTarget.id !== oldId) return;
		this.pendingScrollTarget = {
			...pendingScrollTarget,
			id: newId
		};
	}
	renamePendingLayoutAnchor(oldId, newId) {
		if (this.pendingLayoutAnchor?.id === oldId) this.pendingLayoutAnchor.id = newId;
	}
	createFileOptionsPrototype() {
		const prototype = {};
		for (const key of CODE_VIEW_FILE_OPTION_KEYS) defineItemOption(prototype, key, () => this.options[key]);
		defineItemOption(prototype, "stickyHeader", () => this.options.stickyHeaders);
		defineItemOption(prototype, "collapsed", (receiver) => {
			const state = getItemOptionsState(receiver);
			if (state == null) return;
			return this.getItemOptions(state, "file")?.item.collapsed;
		});
		for (const key of CODE_VIEW_SHARED_CALLBACK_KEYS) this.defineItemSharedCallback(prototype, "file", key);
		for (const key of CODE_VIEW_SELECTION_CALLBACK_KEYS) this.defineItemSelectionCallback(prototype, "file", key);
		return prototype;
	}
	createDiffOptionsPrototype() {
		const prototype = {};
		for (const key of CODE_VIEW_DIFF_OPTION_KEYS) defineItemOption(prototype, key, () => this.options[key]);
		defineItemOption(prototype, "stickyHeader", () => this.options.stickyHeaders);
		defineItemOption(prototype, "hunkSeparators", () => this.options.hunkSeparators);
		defineItemOption(prototype, "collapsed", (receiver) => {
			const state = getItemOptionsState(receiver);
			if (state == null) return;
			return this.getItemOptions(state, "diff")?.item.collapsed;
		});
		for (const key of CODE_VIEW_SHARED_CALLBACK_KEYS) this.defineItemSharedCallback(prototype, "diff", key);
		for (const key of CODE_VIEW_SELECTION_CALLBACK_KEYS) this.defineItemSelectionCallback(prototype, "diff", key);
		return prototype;
	}
	createFileOptions(id) {
		const options = Object.create(this.fileOptionsPrototype);
		defineOptionsState(options, { id });
		return options;
	}
	createDiffOptions(id) {
		const options = Object.create(this.diffOptionsPrototype);
		defineOptionsState(options, { id });
		return options;
	}
	updateItemOptionsId(options, id) {
		const state = getItemOptionsState(options);
		if (state == null) throw new Error(`CodeView.updateItemOptionsId: No valid state`);
		state.id = id;
	}
	getItemOptions(state, mode) {
		const item = this.idToItem.get(state.id);
		if (item == null || item.type !== mode) return;
		return item;
	}
	defineItemSharedCallback(options, mode, key) {
		defineItemOption(options, key, (receiver) => {
			if (this.options[key] == null) return;
			const state = getItemOptionsState(receiver);
			if (state == null) return;
			const callbackCache = state.callbackCache ??= {};
			let wrapped = callbackCache[key];
			if (wrapped == null) {
				wrapped = ((...args) => {
					const latest = this.getItemOptions(state, mode);
					if (latest == null) return;
					const callback = this.options[key];
					return callback?.(...args, latest);
				});
				callbackCache[key] = wrapped;
			}
			return wrapped;
		});
	}
	defineItemSelectionCallback(options, mode, key) {
		defineItemOption(options, key, (receiver) => {
			const state = getItemOptionsState(receiver);
			if (state == null) return;
			const callbackCache = state.callbackCache ??= {};
			let wrapped = callbackCache[key];
			if (wrapped == null) {
				wrapped = ((range) => {
					const latest = this.getItemOptions(state, mode);
					if (latest == null) return;
					const selection = range == null ? null : {
						id: latest.item.id,
						range
					};
					if (this.options.controlledSelection !== true) {
						if (range != null || this.selectedLines?.id === latest.item.id) this.applySelectedLines(selection, { notify: false });
					}
					this.options.onSelectedLinesChange?.(selection);
					const callback = this.options[key];
					return callback?.(range, latest);
				});
				callbackCache[key] = wrapped;
			}
			return wrapped;
		});
	}
	/**
	* Track the earliest index whose measured layout may now be stale. Later
	* render passes relayout from this point forward so we do not have to rebuild
	* positions for the whole list after every change.
	*/
	markLayoutDirtyFromIndex(index) {
		this.layoutDirtyIndex = Math.min(this.layoutDirtyIndex ?? index, index);
	}
	/**
	* Mark the earliest affected item as layout-dirty after an imperative change.
	* Each record carries its current array index so this stays O(1) even when
	* the viewer holds a very large number of items.
	*/
	markItemLayoutDirty(item) {
		if (this.items[item.index] !== item) throw new Error(`CodeView.markItemLayoutDirty: unknown item id "${item.item.id}"`);
		this.markLayoutDirtyFromIndex(item.index);
	}
	/**
	* Detect the common controlled-update case where the new list simply extends
	* the existing ordered prefix. When that happens we can reuse every current
	* record in place, sync any versioned payload changes, and append only the new
	* tail instead of rebuilding the whole list.
	*/
	tryAppendItems(items) {
		if (items.length <= this.items.length) return false;
		for (let index = 0; index < this.items.length; index++) {
			const existingItem = this.items[index];
			if (existingItem == null) throw new Error("CodeView.tryAppendItems: missing existing item");
			const nextItem = items[index];
			if (nextItem == null || existingItem.item.id !== nextItem.id || existingItem.type !== nextItem.type) return false;
		}
		for (let index = 0; index < this.items.length; index++) {
			const existingItem = this.items[index];
			if (existingItem == null) throw new Error("CodeView.tryAppendItems: missing existing item");
			const nextItem = items[index];
			if (nextItem == null) throw new Error("CodeView.tryAppendItems: append candidate missing prefix item");
			if (this.syncItemRecord(existingItem, nextItem)) this.markLayoutDirtyFromIndex(index);
		}
		this.appendItemsInternal(items.slice(this.items.length), false);
		this.scrollDirty = true;
		this.render();
		return true;
	}
	/**
	* Reconcile a new controlled item list against the existing records by id.
	* This reuses records and instances when type matches, cleans up removed
	* records, rebuilds the lookup maps, and marks layout dirty whenever order,
	* membership, or versioned item data changes.
	*/
	reconcileItems(items) {
		const { items: previousItems, idToItem: previousById } = this;
		const removedItems = new Set(previousItems);
		const nextItems = [];
		const nextIdToItem = /* @__PURE__ */ new Map();
		const nextInstanceToItem = /* @__PURE__ */ new Map();
		const removedItemsById = /* @__PURE__ */ new Map();
		let firstDirtyIndex;
		for (let index = 0; index < items.length; index++) {
			const input = items[index];
			if (input == null) throw new Error("CodeView.reconcileItems: missing input item");
			if (nextIdToItem.has(input.id)) throw new Error(`CodeView.setItems: duplicate id "${input.id}"`);
			const previousItem = previousById.get(input.id);
			const item = previousItem != null && previousItem.type === input.type ? previousItem : this.createItem(input, index, 0);
			item.index = index;
			if (previousItem != null && previousItem.type === input.type) {
				removedItems.delete(previousItem);
				if (this.syncItemRecord(item, input)) firstDirtyIndex = Math.min(firstDirtyIndex ?? index, index);
			} else firstDirtyIndex = Math.min(firstDirtyIndex ?? index, index);
			if (previousItems[index] !== item) firstDirtyIndex = Math.min(firstDirtyIndex ?? index, index);
			nextItems.push(item);
			nextIdToItem.set(input.id, item);
			nextInstanceToItem.set(item.instance, item);
		}
		if (firstDirtyIndex == null) {
			if (removedItems.size === 0) return;
			firstDirtyIndex = Math.max(nextItems.length - 1, 0);
		}
		this.capturePendingLayoutAnchor(nextIdToItem);
		for (let index = 0; index < previousItems.length; index++) {
			const removedItem = previousItems[index];
			if (removedItem == null || !removedItems.has(removedItem)) continue;
			removedItemsById.set(removedItem.item.id, removedItem);
			this.releaseRenderedItem(removedItem);
			const dirtyIndex = Math.max(nextItems.length - 1, 0);
			firstDirtyIndex = Math.min(firstDirtyIndex ?? dirtyIndex, dirtyIndex);
		}
		this.items = nextItems;
		this.idToItem = nextIdToItem;
		this.instanceToItem = nextInstanceToItem;
		if (this.renderState.firstIndex >= nextItems.length) this.resetRenderState();
		else if (this.renderState.lastIndex >= nextItems.length) this.renderState.lastIndex = nextItems.length - 1;
		this.markLayoutDirtyFromIndex(firstDirtyIndex);
		this.scrollDirty = true;
		this.render();
		return removedItemsById.size > 0 ? removedItemsById : void 0;
	}
	/**
	* Update a reused record from the latest controlled item only when its item
	* version changes. Matching versions mean CodeView keeps the current record
	* snapshot, which lets imperative updates remain in place until the caller
	* intentionally publishes a newer version.
	*/
	syncItemRecord(item, nextItem) {
		if (item.type !== nextItem.type) throw new Error(`CodeView.syncItemRecord: type mismatch for id "${nextItem.id}"`);
		if (item.version === nextItem.version) return false;
		item.item = nextItem;
		item.version = nextItem.version;
		item.renderedOptionsRevision = -1;
		return true;
	}
	getMaxScrollTopForHeight(scrollHeight) {
		const { paddingBottom, paddingTop } = this.getLayout();
		return Math.max(paddingTop + this.header.height + scrollHeight + this.footer.height + paddingBottom - this.getHeight(), 0);
	}
	getMaxScrollTop() {
		return this.getMaxScrollTopForHeight(this.getScrollHeight());
	}
	shouldRebaseScroll() {
		return this.getMaxScrollTop() > SCROLL_REBASE_THRESHOLD;
	}
	getPagedScrollHeight() {
		return this.shouldRebaseScroll() ? Math.min(this.getScrollHeight(), SCROLL_REBASE_CONTAINER_HEIGHT) : this.getScrollHeight();
	}
	getMaxPagedScrollTop() {
		return this.getMaxScrollTopForHeight(this.getPagedScrollHeight());
	}
	clampPagedScrollTop(value) {
		const maxScroll = this.getMaxPagedScrollTop();
		return Math.max(0, Math.min(value, maxScroll));
	}
	/**
	* Clamps a logical scroll position to the min/max allowable scroll range
	* based on the full computed content height.
	*/
	clampScrollTop(value) {
		const maxScroll = this.getMaxScrollTop();
		return Math.max(0, Math.min(value, maxScroll));
	}
	getMaxScrollPageOffset() {
		return Math.max(this.getMaxScrollTop() - this.getMaxPagedScrollTop(), 0);
	}
	clampScrollPageOffset(value) {
		const maxOffset = this.getMaxScrollPageOffset();
		return Math.max(0, Math.min(value, maxOffset));
	}
	resolveScrollPageWindow(scrollTop, preferredPagedScrollTop) {
		let pagedScrollTop = roundToDevicePixel(this.clampPagedScrollTop(preferredPagedScrollTop));
		let scrollPageOffset = this.clampScrollPageOffset(scrollTop - pagedScrollTop);
		pagedScrollTop = roundToDevicePixel(this.clampPagedScrollTop(scrollTop - scrollPageOffset));
		scrollPageOffset = this.clampScrollPageOffset(scrollTop - pagedScrollTop);
		return {
			pagedScrollTop,
			scrollPageOffset
		};
	}
	/**
	* Resolve how a logical scrollTop maps onto the reusable paged scroll window
	* without mutating the current page offset.
	*/
	resolvePagedScrollPosition(logicalScrollTop) {
		if (!this.shouldRebaseScroll()) return {
			pagedScrollTop: this.clampPagedScrollTop(logicalScrollTop),
			scrollPageOffset: 0
		};
		const currentPageOffset = this.clampScrollPageOffset(this.scrollPageOffset);
		const pagedScrollTop = logicalScrollTop - currentPageOffset;
		const pagedMaxScrollTop = this.getMaxPagedScrollTop();
		const maxRebaseOffset = this.getMaxScrollPageOffset();
		const shouldMoveDown = pagedScrollTop > SCROLL_REBASE_THRESHOLD && currentPageOffset < maxRebaseOffset;
		const shouldMoveUp = pagedScrollTop < SCROLL_REBASE_TRIGGER_TOP && currentPageOffset > 0;
		if (pagedScrollTop < 0 || pagedScrollTop > pagedMaxScrollTop || shouldMoveDown || shouldMoveUp) return this.resolveScrollPageWindow(logicalScrollTop, shouldMoveUp ? Math.min(SCROLL_REBASE_TARGET_BOTTOM, pagedMaxScrollTop) : SCROLL_REBASE_TARGET_TOP);
		return {
			pagedScrollTop: roundToDevicePixel(this.clampPagedScrollTop(pagedScrollTop)),
			scrollPageOffset: currentPageOffset
		};
	}
	needsScrollPageUpdate(logicalScrollTop) {
		const roundedScrollTop = roundToDevicePixel(this.clampScrollTop(logicalScrollTop));
		const { scrollPageOffset } = this.resolvePagedScrollPosition(roundedScrollTop);
		return scrollPageOffset !== this.scrollPageOffset;
	}
	getPagedLayoutTop(logicalTop) {
		if (!this.shouldRebaseScroll()) return logicalTop;
		return Math.max(logicalTop - this.scrollPageOffset, 0);
	}
	getStickyHeaderOffset() {
		return this.options.stickyHeaders === true && this.options.disableFileHeader !== true ? this.itemMetricsCache.diffHeaderHeight : 0;
	}
	getScrollTargetRect(target) {
		const item = this.idToItem.get(target.id);
		if (item == null) {
			console.warn(`CodeView.scrollTo: unknown item id "${target.id}"`);
			return;
		}
		if (target.type === "item") return {
			top: item.top,
			height: item.height
		};
		if (target.type === "range") {
			const rangePosition = this.getRangeScrollPosition(item, target);
			if (rangePosition == null) {
				console.warn(`CodeView.scrollTo: unable to resolve range ${formatSelectedLineRange(target.range)} for item "${target.id}"`);
				return;
			}
			return {
				top: item.top + rangePosition.top,
				height: rangePosition.height
			};
		}
		const linePosition = this.getLineScrollPosition(item, target);
		if (linePosition == null) {
			console.warn(`CodeView.scrollTo: unable to resolve line ${target.lineNumber} for item "${target.id}"`);
			return;
		}
		return {
			top: item.top + linePosition.top,
			height: linePosition.height
		};
	}
	normalizeScrollTarget(target) {
		if (target.type === "position" || target.align !== "nearest") return target;
		const rect = this.getScrollTargetRect(target);
		if (rect == null) return;
		const offset = target.offset ?? 0;
		const targetTop = this.getItemTopOffset() + rect.top;
		const targetBottom = targetTop + rect.height;
		const currentTop = this.getScrollTop();
		const visibleTop = currentTop + (target.type === "line" || target.type === "range" ? this.getStickyHeaderOffset() : 0);
		const visibleBottom = currentTop + this.getHeight();
		if (targetTop - offset <= visibleTop && targetBottom + offset >= visibleBottom) return;
		if (targetTop - offset < visibleTop) return {
			...target,
			align: "start"
		};
		if (targetBottom + offset > visibleBottom) return {
			...target,
			align: "end"
		};
	}
	/**
	* Resolve a target's scroll position
	
	* Returns `undefined` when we can't resolve a target for whatever reason
	*/
	resolveScrollTargetTop(target) {
		if (target.type === "position") {
			const clampedPosition = this.clampScrollTop(target.position);
			return clampedPosition !== target.position ? clampedPosition : this.clampScrollTop(target.position - this.getStickyHeaderOffset());
		}
		const item = this.idToItem.get(target.id);
		if (item == null) {
			console.warn(`CodeView.scrollTo: unknown item id "${target.id}"`);
			return;
		}
		if (target.type === "item") return this.clampScrollTop(this.resolveAlignedScrollPosition(item.top, item.height, target.align, target.offset));
		if (target.type === "range") {
			const rangePosition = this.getRangeScrollPosition(item, target);
			if (rangePosition == null) {
				console.warn(`CodeView.scrollTo: unable to resolve range ${formatSelectedLineRange(target.range)} for item "${target.id}"`);
				return;
			}
			return this.clampScrollTop(this.resolveAlignedScrollPosition(item.top + rangePosition.top, rangePosition.height, target.align, target.offset, this.getStickyHeaderOffset()));
		}
		const linePosition = this.getLineScrollPosition(item, target);
		if (linePosition == null) {
			console.warn(`CodeView.scrollTo: unable to resolve line ${target.lineNumber} for item "${target.id}"`);
			return;
		}
		return this.clampScrollTop(this.resolveAlignedScrollPosition(item.top + linePosition.top, linePosition.height, target.align, target.offset, this.getStickyHeaderOffset()));
	}
	/**
	* Given an existing scroll target (scroll top and height), figure out the
	* correct scroll position to target based on the desired alignment, offset
	* and stickyOffset if necessary
	*/
	resolveAlignedScrollPosition(targetTop, targetHeight, align, offset = 0, stickyOffset = 0) {
		targetTop += this.getItemTopOffset();
		const viewportHeight = this.getHeight();
		if (align === "center" && targetHeight + offset < viewportHeight) return targetTop - (viewportHeight - targetHeight) / 2 + offset;
		if (align === "end") return targetTop - (viewportHeight - targetHeight) + offset;
		return targetTop - stickyOffset - offset;
	}
	getLineScrollPosition(item, target) {
		if (item.type === "diff") return item.instance.getLinePosition(target.lineNumber, target.side);
		return item.instance.getLinePosition(target.lineNumber);
	}
	getRangeScrollPosition(item, target) {
		const { range } = target;
		const startPosition = this.getLineScrollPosition(item, {
			type: "line",
			id: target.id,
			lineNumber: range.start,
			side: range.side
		});
		const endPosition = this.getLineScrollPosition(item, {
			type: "line",
			id: target.id,
			lineNumber: range.end,
			side: range.endSide ?? range.side
		});
		if (startPosition == null || endPosition == null) return;
		const startTop = startPosition.top;
		const startBottom = startTop + startPosition.height;
		const endTop = endPosition.top;
		const endBottom = endTop + endPosition.height;
		const top = Math.min(startTop, endTop);
		return {
			top,
			height: Math.max(startBottom, endBottom) - top
		};
	}
	/**
	* Determine target scroll position for current frame.
	*
	* If there's no pendingScrollTarget then we just return the current scroll
	* position
	*
	* If there's a pendingScrollTarget then we depend on whether there's a
	* smooth scroll animation or not. If not just return the destination, or
	* compute next position given the smooth scroll spring physics
	*/
	computeTargetScrollTopForFrame(scrollTop, frameTimestamp) {
		if (this.pendingScrollTarget == null) return scrollTop;
		const destination = this.resolveScrollTargetTop(this.pendingScrollTarget);
		if (destination == null) return scrollTop;
		const { scrollAnimation } = this;
		if (scrollAnimation == null) return destination;
		return this.computeSpringStep(scrollAnimation, destination, frameTimestamp).position;
	}
	/**
	* Closed-form critical-damped ODE step.
	*
	* Stable at any dt (Euler would blow up once ω·dt ≳ 1), so this survives
	* big RAF gaps (tab-wake, offscreen frames) and resize-driven ticks that
	* fire outside the normal RAF cadence.
	*/
	computeSpringStep(animation, destination, frameTimestamp) {
		const dt = Math.max(0, frameTimestamp - animation.lastTimestamp);
		const { omega } = this.getSmoothScrollSettings();
		const decay = Math.exp(-omega * dt);
		const displacement = animation.position - destination;
		const springCoeff = animation.velocity + omega * displacement;
		return {
			position: destination + (displacement + springCoeff * dt) * decay,
			velocity: (springCoeff * (1 - omega * dt) - omega * displacement) * decay
		};
	}
	/**
	* For any given pendingScrollTarget, updates any in flight smooth scroll
	* animations and returns the target scrollTop to move towards
	*
	* Resolves the animation based on frame time and adopts any necessary scroll
	* anchoring corrections if necessary
	*/
	advanceScrollAnimation(frameTimestamp, anchorDelta) {
		if (this.pendingScrollTarget == null) return;
		const destination = this.resolveScrollTargetTop(this.pendingScrollTarget);
		if (destination == null) {
			this.pendingScrollTarget = void 0;
			this.scrollAnimation = void 0;
			return;
		}
		const animation = this.scrollAnimation;
		if (animation == null) return destination;
		animation.position += anchorDelta;
		const { position, velocity } = this.computeSpringStep(animation, destination, frameTimestamp);
		animation.lastTimestamp = frameTimestamp;
		animation.position = position;
		animation.velocity = velocity;
		const { positionEpsilon, velocityEpsilon } = this.getSmoothScrollSettings();
		if (Math.abs(destination - position) <= positionEpsilon && Math.abs(velocity) <= velocityEpsilon) {
			animation.position = destination;
			animation.velocity = 0;
			this.scrollAnimation = void 0;
			return destination;
		}
		return animation.position;
	}
	computeRenderRangeAndEmit = (timestamp = performance.now()) => {
		if (CodeView.__STOP || this.container == null) return;
		if (!this.isReady()) return;
		const viewportHeight = this.getHeight();
		const initialScrollTop = this.getScrollTop();
		let scrollTopAfterLayout = initialScrollTop;
		let computeScrollCorrection = this.pendingLayoutAnchor != null;
		let scrollAnchor = this.getScrollAnchor(scrollTopAfterLayout);
		if (this.layoutDirtyIndex != null) {
			this.recomputeLayout(this.layoutDirtyIndex, this.pendingLayoutReset);
			this.layoutDirtyIndex = void 0;
			this.pendingLayoutReset = void 0;
			computeScrollCorrection = true;
		}
		if (computeScrollCorrection && scrollAnchor != null) {
			const anchoredScrollTopAfterLayout = this.resolveAnchoredScrollTop(scrollAnchor);
			if (anchoredScrollTopAfterLayout != null) {
				const layoutAnchorDelta = anchoredScrollTopAfterLayout - scrollTopAfterLayout;
				scrollTopAfterLayout = anchoredScrollTopAfterLayout;
				if (this.scrollAnimation != null) this.scrollAnimation.position += layoutAnchorDelta;
			}
		}
		if (computeScrollCorrection) {
			scrollTopAfterLayout = this.clampScrollTop(scrollTopAfterLayout);
			this.syncContainerHeight();
		}
		const targetScrollTop = this.computeTargetScrollTopForFrame(scrollTopAfterLayout, timestamp);
		const fitPerfectly = !computeScrollCorrection && (this.renderState.scrollTop === -1 || Math.abs(targetScrollTop - this.renderState.scrollTop) > viewportHeight + this.config.overscrollSize * 2);
		if (fitPerfectly) scrollAnchor = void 0;
		this.windowSpecs = createWindowFromScrollPosition({
			scrollTop: targetScrollTop - this.header.height,
			height: viewportHeight,
			scrollHeight: this.getScrollHeight(),
			fitPerfectly,
			fitPerfectlyOverscroll: this.getFitPerfectlyOverscroll(),
			overscrollSize: this.config.overscrollSize
		});
		let syncedScrollTop = initialScrollTop;
		if (this.pendingScrollTarget != null && targetScrollTop !== syncedScrollTop || this.needsScrollPageUpdate(targetScrollTop)) {
			this.applyScrollFix(targetScrollTop, syncedScrollTop, this.windowSpecs);
			syncedScrollTop = targetScrollTop;
		}
		const { top, bottom } = this.windowSpecs;
		const { firstIndex, lastIndex } = this.renderState;
		if (firstIndex >= 0) for (let index = firstIndex; index <= lastIndex; index++) {
			const item = this.items[index];
			if (item == null) throw new Error(`CodeView.computeRenderRangeAndEmit: No item at index: ${index}`);
			if (!(item.top > top - item.height && item.top <= bottom)) this.releaseRenderedItem(item);
		}
		const hostsChanged = this.reconcileHeaderFooterHosts();
		let prevElement;
		const updatedItems = /* @__PURE__ */ new Set();
		const startingIndex = this.findFirstVisibleIndex(top);
		const lastRenderedIndex = this.findLastVisibleIndex(bottom);
		for (let itemIndex = startingIndex; itemIndex <= lastRenderedIndex; itemIndex++) {
			const item = this.items[itemIndex];
			if (item == null) throw new Error(`CodeView.computeRenderRangeAndEmit: missing item`);
			const { instance } = item;
			if (item.element == null) {
				item.element = this.acquireElement();
				syncRenderedItemOrder(this.stickyContainer, item.element, prevElement);
				instance.virtualizedSetup();
				if (renderItem(item, item.element)) {
					item.renderedOptionsRevision = this.renderOptionsRevision;
					updatedItems.add(item);
				}
				prevElement = item.element;
			} else {
				syncRenderedItemOrder(this.stickyContainer, item.element, prevElement);
				if (renderItem(item, void 0, item.renderedOptionsRevision !== this.renderOptionsRevision)) {
					item.renderedOptionsRevision = this.renderOptionsRevision;
					updatedItems.add(item);
				}
				prevElement = item.element;
			}
			if (item.item.edit === true) this.attachItemEditor(item);
		}
		this.renderState.firstIndex = startingIndex <= lastRenderedIndex ? startingIndex : -1;
		this.renderState.lastIndex = lastRenderedIndex;
		this.flushSlotCoordinator();
		this.flushManagers(updatedItems);
		if (hostsChanged) this.measureMountedHosts();
		this.reconcileRenderedItems(updatedItems);
		this.syncContainerHeight();
		this.updateStickyPositioning();
		const anchoredScrollTopAfterRender = scrollAnchor != null ? this.resolveAnchoredScrollTop(scrollAnchor) : void 0;
		if (scrollAnchor === this.pendingLayoutAnchor) this.pendingLayoutAnchor = void 0;
		const postRenderAnchorDelta = anchoredScrollTopAfterRender != null ? anchoredScrollTopAfterRender - scrollTopAfterLayout : 0;
		let postRenderScrollTop = targetScrollTop;
		let shouldCheckPendingTargetSettled = false;
		if (this.pendingScrollTarget != null) {
			const pendingTargetScrollTop = this.advanceScrollAnimation(timestamp, postRenderAnchorDelta);
			if (pendingTargetScrollTop != null) {
				postRenderScrollTop = pendingTargetScrollTop;
				shouldCheckPendingTargetSettled = true;
			} else postRenderScrollTop = scrollTopAfterLayout;
		} else postRenderScrollTop = anchoredScrollTopAfterRender ?? targetScrollTop;
		if (postRenderScrollTop !== syncedScrollTop) {
			this.applyScrollFix(postRenderScrollTop, syncedScrollTop, this.windowSpecs);
			syncedScrollTop = postRenderScrollTop;
		}
		if (shouldCheckPendingTargetSettled && this.pendingScrollTarget != null && this.isPendingTargetSettled(this.pendingScrollTarget)) {
			this.pendingScrollTarget = void 0;
			this.scrollAnimation = void 0;
		}
		this.renderState.scrollTop = roundToDevicePixel(syncedScrollTop);
		this.updateStickyPositioning();
		this.validateStickyContainerHeight();
		this.fixContainerFocus();
		if (fitPerfectly || this.scrollAnimation != null) this.render();
	};
	flushManagers(updatedItems) {
		for (const item of updatedItems) item.instance.flushManagers();
	}
	syncContainerHeight() {
		const pagedScrollHeight = this.getPagedScrollHeight();
		if (this.container == null || this.containerHeight === pagedScrollHeight) return;
		this.container.style.height = `${pagedScrollHeight}px`;
		this.containerHeight = pagedScrollHeight;
	}
	getStickyBounds(windowSpecs) {
		const { firstIndex, lastIndex } = windowSpecs != null ? {
			firstIndex: this.findFirstVisibleIndex(windowSpecs.top),
			lastIndex: this.findLastVisibleIndex(windowSpecs.bottom)
		} : this.renderState;
		if (firstIndex === -1 || lastIndex === -1 || firstIndex > lastIndex) return;
		const firstStickySpecs = this.items[firstIndex]?.instance.getAdvancedStickySpecs(windowSpecs);
		const lastStickySpecs = this.items[lastIndex]?.instance.getAdvancedStickySpecs(windowSpecs);
		if (firstStickySpecs == null || lastStickySpecs == null) return;
		return {
			stickyTop: this.getPagedLayoutTop(Math.max(firstStickySpecs.topOffset, 0)),
			stickyBottom: this.getPagedLayoutTop(lastStickySpecs.topOffset + lastStickySpecs.height)
		};
	}
	applyStickyPositioning({ stickyTop, stickyBottom }) {
		const height = this.getHeight();
		const { itemMetricsCache: itemMetrics } = this;
		const stickyContainerHeight = stickyBottom - stickyTop;
		this.renderState.stickyHeight = stickyContainerHeight;
		this.renderState.stickyTop = stickyTop;
		this.renderState.stickyBottom = stickyBottom;
		this.stickyOffset.style.height = `${stickyTop}px`;
		const randomOffset = (Math.random() * itemMetrics.lineHeight >> 0) * -1;
		const stickyJitter = -Math.max(stickyContainerHeight + randomOffset, 0) + height;
		this.stickyContainer.style.top = `${stickyJitter}px`;
		this.stickyContainer.style.bottom = `${stickyJitter + itemMetrics.diffHeaderHeight}px`;
	}
	syncPagedScrollScaffolding(windowSpecs) {
		this.syncContainerHeight();
		const stickyBounds = this.getStickyBounds(windowSpecs);
		if (stickyBounds == null) return;
		this.applyStickyPositioning(stickyBounds);
	}
	reconcileRenderedItems(updatedItems) {
		const { firstIndex, lastIndex } = this.renderState;
		if (firstIndex === -1) return;
		let currentTop = -1;
		let heightChanged = false;
		for (let index = firstIndex; index < this.items.length; index++) {
			if (!heightChanged && index > lastIndex) break;
			const item = this.items[index];
			if (item == null) throw new Error("CodeView.reconcileRenderedItems: Invalid item");
			if (currentTop === -1) currentTop = item.top;
			else if (item.top !== currentTop) {
				item.top = currentTop;
				item.instance.syncVirtualizedTop();
				heightChanged = true;
			}
			if (updatedItems == null ? index <= lastIndex : updatedItems.has(item)) {
				if (item.instance.reconcileHeights()) {
					heightChanged = true;
					item.height = item.instance.getVirtualizedHeight();
				}
				this.validateRenderedItemHeight(item);
			}
			currentTop += item.instance.getVirtualizedHeight();
			if (index < this.items.length - 1) currentTop += this.getLayout().gap;
		}
		if (heightChanged && currentTop != null) {
			this.scrollDirty = true;
			this.scrollHeight = currentTop;
		}
	}
	updateStickyPositioning() {
		const stickyBounds = this.getStickyBounds();
		if (stickyBounds == null) {
			if (this.renderState.firstIndex === -1) this.stickyOffset.style.height = "";
			return;
		}
		const { stickyTop, stickyBottom } = stickyBounds;
		if (stickyBottom - stickyTop === this.renderState.stickyHeight && stickyTop === this.renderState.stickyTop && stickyBottom === this.renderState.stickyBottom) return;
		this.applyStickyPositioning(stickyBounds);
	}
	handleScroll = () => {
		if (CodeView.__STOP) return;
		this.suspendScrollInteractions();
		this.scrollDirty = true;
		this.notifyScroll();
		this.render();
	};
	clearPendingScroll = () => {
		this.pendingScrollTarget = void 0;
		this.pendingLayoutAnchor = void 0;
		this.scrollAnimation = void 0;
	};
	handleResize = (entries) => {
		let shouldRender = false;
		for (const entry of entries) if (entry.target === this.stickyContainer) {
			const blockSize = entry.borderBoxSize[0].blockSize;
			if (Math.abs(blockSize - this.renderState.stickyHeight) >= SUB_PIXEL_TOLERANCE) {
				const currentScrollTop = this.getScrollTop();
				const anchor = this.getScrollAnchor(currentScrollTop);
				this.reconcileRenderedItems();
				this.updateStickyPositioning();
				const anchoredScrollTop = anchor != null ? this.resolveAnchoredScrollTop(anchor) : void 0;
				if (anchoredScrollTop != null) {
					const resizeAnchorDelta = anchoredScrollTop - currentScrollTop;
					this.applyScrollFix(anchoredScrollTop, currentScrollTop, this.windowSpecs);
					if (this.scrollAnimation != null) this.scrollAnimation.position += resizeAnchorDelta;
				}
				if (this.pendingScrollTarget != null && this.isPendingTargetSettled(this.pendingScrollTarget)) {
					this.pendingScrollTarget = void 0;
					this.scrollAnimation = void 0;
				}
				shouldRender = true;
			}
		} else if (entry.target === this.header.element || entry.target === this.footer.element) {
			const host = entry.target === this.header.element ? this.header : this.footer;
			const blockSize = entry.borderBoxSize[0].blockSize;
			if (blockSize !== host.height) {
				const currentScrollTop = this.getScrollTop();
				const anchor = this.getScrollAnchor(currentScrollTop);
				this.setHostHeight(host, blockSize);
				const anchoredScrollTop = anchor != null ? this.resolveAnchoredScrollTop(anchor) : void 0;
				if (anchoredScrollTop != null) {
					const resizeAnchorDelta = anchoredScrollTop - currentScrollTop;
					this.applyScrollFix(anchoredScrollTop, currentScrollTop, this.windowSpecs);
					if (this.scrollAnimation != null) this.scrollAnimation.position += resizeAnchorDelta;
				}
				if (this.pendingScrollTarget != null && this.isPendingTargetSettled(this.pendingScrollTarget)) {
					this.pendingScrollTarget = void 0;
					this.scrollAnimation = void 0;
				}
				shouldRender = true;
			}
		} else {
			this.scrollDirty = true;
			this.heightDirty = true;
			shouldRender = true;
		}
		if (shouldRender) this.render(true);
	};
	/**
	* Figure out scrollTop accounting for sticky header if enabled and
	* necessary
	*/
	getScrollAnchorViewportTop(absoluteItemTop, scrollTop) {
		return absoluteItemTop < scrollTop ? scrollTop + this.getStickyHeaderOffset() : scrollTop;
	}
	/**
	* Attempt to find a scroll anchor based on build in metrics of the existing
	* rendered files/diff.
	*
	* A scroll anchor represents the first fully visible element (in other
	* words, the first file or first line who's top is fully in the viewport).
	*/
	getScrollAnchor(scrollTop, availableItems = this.idToItem) {
		let skippedItem;
		const { pendingLayoutAnchor } = this;
		if (pendingLayoutAnchor != null) {
			const pendingItem = this.idToItem.get(pendingLayoutAnchor.id);
			if (pendingItem != null && availableItems.get(pendingLayoutAnchor.id) === pendingItem) return pendingLayoutAnchor;
			if (pendingItem != null) skippedItem = pendingItem;
		}
		if (scrollTop <= 0) return;
		const { firstIndex, lastIndex, stickyTop, stickyBottom } = this.renderState;
		if (firstIndex === -1 || lastIndex === -1) return;
		const viewportHeight = this.getHeight();
		if (stickyTop === -1 || stickyBottom === -1) return;
		for (let index = firstIndex; index <= lastIndex; index++) {
			const item = this.items[index];
			if (item == null) continue;
			const absoluteItemTop = this.getItemTopOffset() + item.top;
			if (absoluteItemTop + item.height <= scrollTop) continue;
			if (absoluteItemTop >= scrollTop + viewportHeight) break;
			if (!(availableItems.get(item.item.id) === item)) {
				skippedItem ??= item;
				continue;
			}
			if (absoluteItemTop >= scrollTop) return {
				type: "item",
				id: item.item.id,
				viewportOffset: absoluteItemTop - scrollTop
			};
			const localViewportTop = this.getScrollAnchorViewportTop(absoluteItemTop, scrollTop) - absoluteItemTop;
			const lineAnchor = item.instance.getNumericScrollAnchor(localViewportTop);
			if (lineAnchor != null) {
				const absoluteLineTop = absoluteItemTop + lineAnchor.top;
				return {
					type: "line",
					id: item.item.id,
					lineNumber: lineAnchor.lineNumber,
					side: lineAnchor.side,
					viewportOffset: absoluteLineTop - scrollTop
				};
			}
		}
		if (skippedItem != null) for (let index = skippedItem.index + 1; index < this.items.length; index++) {
			const candidate = this.items[index];
			if (candidate != null && availableItems.get(candidate.item.id) === candidate) return {
				type: "item",
				id: candidate.item.id,
				viewportOffset: 0
			};
		}
	}
	/**
	* Given a scroll anchor, attempt to resolve a newly updated (and clamped)
	* scroll position to keep the anchored element in place.
	*
	* If we can't resolve a position for whatever reason, we'll return
	* undefined.
	*/
	resolveAnchoredScrollTop(anchor) {
		const item = this.idToItem.get(anchor.id);
		if (item == null) return;
		const itemTopOffset = this.getItemTopOffset();
		if (anchor.type === "item") {
			const absoluteItemTop = itemTopOffset + item.top;
			return this.clampScrollTop(absoluteItemTop - anchor.viewportOffset);
		}
		const linePosition = item.type === "diff" ? item.instance.getLinePosition(anchor.lineNumber, anchor.side) : item.instance.getLinePosition(anchor.lineNumber);
		if (linePosition == null) return;
		const absoluteLineTop = itemTopOffset + item.top + linePosition.top;
		return this.clampScrollTop(absoluteLineTop - anchor.viewportOffset);
	}
	/**
	* Apply a device-pixel-rounded scroll position if it differs from the last
	* logical scrollTop synchronized into the paged scroll scaffold.
	*/
	applyScrollFix(targetScrollTop, syncedScrollTop, windowSpecs) {
		if (this.root == null) return;
		const roundedTargetScrollTop = roundToDevicePixel(this.clampScrollTop(targetScrollTop));
		const roundedSyncedScrollTop = roundToDevicePixel(syncedScrollTop);
		const { scrollPageOffset: previousPageOffset } = this;
		const syncedPagedScrollTop = roundToDevicePixel(this.clampPagedScrollTop(roundedSyncedScrollTop - previousPageOffset));
		const { pagedScrollTop, scrollPageOffset } = this.resolvePagedScrollPosition(roundedTargetScrollTop);
		const targetPagedScrollTop = pagedScrollTop;
		const rebaseChanged = previousPageOffset !== scrollPageOffset;
		if (roundedTargetScrollTop === this.renderState.scrollTop && roundedTargetScrollTop === roundedSyncedScrollTop && targetPagedScrollTop === syncedPagedScrollTop && !rebaseChanged) return;
		this.suspendScrollInteractions();
		if (targetPagedScrollTop !== syncedPagedScrollTop || rebaseChanged) {
			this.scrollPageOffset = scrollPageOffset;
			this.syncPagedScrollScaffolding(windowSpecs);
		}
		if (targetPagedScrollTop !== syncedPagedScrollTop) this.root.scrollTo({
			top: targetPagedScrollTop,
			behavior: "instant"
		});
		this.renderState.scrollTop = roundedTargetScrollTop;
		this.scrollTop = roundedTargetScrollTop;
		this.scrollDirty = false;
	}
	/**
	* Decide whether a pending programmatic scroll has reached its
	* destination and should be cleared.
	*/
	isPendingTargetSettled(target) {
		const top = this.resolveScrollTargetTop(target);
		if (top == null) return true;
		return roundToDevicePixel(this.getScrollTop()) === roundToDevicePixel(top);
	}
	getScrollTop() {
		if (!this.scrollDirty) return this.scrollTop;
		this.scrollDirty = false;
		const rootScrollTop = this.root?.scrollTop ?? 0;
		this.scrollTop = this.clampScrollTop(rootScrollTop + this.scrollPageOffset);
		return this.scrollTop;
	}
	getHeight() {
		if (!this.heightDirty) return this.height;
		this.heightDirty = false;
		this.height = this.root?.getBoundingClientRect().height ?? 0;
		return this.height;
	}
	getScrollHeight() {
		return this.scrollHeight;
	}
	flushSlotCoordinator() {
		if (this.slotCoordinator == null) return;
		const slotSnapshot = this.buildSlotSnapshot(this.slotCoordinator);
		if (areManagedSnapshotsEqual(this.slotSnapshot, slotSnapshot)) return;
		this.slotSnapshot = slotSnapshot;
		this.slotCoordinator.onSnapshotChange(slotSnapshot);
	}
	notifyScroll() {
		if (this.scrollListeners.size === 0) return;
		const scrollTop = this.getScrollTop();
		for (const listener of this.scrollListeners) listener(scrollTop, this);
	}
	/**
	* Find the first item whose bottom edge crosses into the viewport window.
	* This lets scroll-time rendering jump directly near the visible range instead
	* of linearly scanning from the start of very large item lists.
	*/
	findFirstVisibleIndex(top) {
		let low = 0;
		let high = this.items.length - 1;
		let result = this.items.length;
		while (low <= high) {
			const mid = low + high >> 1;
			const item = this.items[mid];
			if (item == null) throw new Error("CodeView.findFirstVisibleIndex: invalid item index");
			if (item.top + item.height > top) {
				result = mid;
				high = mid - 1;
			} else low = mid + 1;
		}
		return result;
	}
	/**
	* Find the last item whose top edge is still within the viewport window.
	* Paired with findFirstVisibleIndex, this bounds the render loop to only the
	* slice of items that can actually intersect the current scroll range.
	*/
	findLastVisibleIndex(bottom) {
		let low = 0;
		let high = this.items.length - 1;
		let result = -1;
		while (low <= high) {
			const mid = low + high >> 1;
			const item = this.items[mid];
			if (item == null) throw new Error("CodeView.findLastVisibleIndex: invalid item index");
			if (item.top <= bottom) {
				result = mid;
				low = mid + 1;
			} else high = mid - 1;
		}
		return result;
	}
	/**
	* Recompute measured tops and heights starting from the earliest dirty item.
	* Earlier items keep their existing layout, while everything from startIndex
	* onward is remeasured so downstream positions and total scroll height stay
	* consistent after inserts, removals, or versioned item updates.
	*/
	recomputeLayout(startIndex = 0, reset) {
		if (this.items.length === 0) {
			this.scrollHeight = 0;
			return;
		}
		const layout = this.getLayout();
		let runningTop = 0;
		if (startIndex > 0) {
			const previousItem = this.items[startIndex - 1];
			if (previousItem == null) throw new Error("CodeView.recomputeLayout: invalid dirty index");
			runningTop = previousItem.top + previousItem.height + layout.gap;
		}
		for (let index = startIndex; index < this.items.length; index++) {
			const item = this.items[index];
			if (item == null) throw new Error("CodeView.recomputeLayout: invalid item index");
			item.top = runningTop;
			if (item.type === "diff") {
				const fileDiff = item.instance.consumeCodeViewLayoutChanges(item.item.fileDiff);
				if (fileDiff != null) Object.assign(item.item.fileDiff, fileDiff);
				item.height = item.instance.prepareCodeViewItem(item.item.fileDiff, runningTop, reset, item.item.annotations ?? []);
			} else item.height = item.instance.prepareCodeViewItem(item.item.file, runningTop, reset, item.item.annotations ?? []);
			runningTop += item.height;
			if (index < this.items.length - 1) runningTop += layout.gap;
		}
		if (runningTop !== this.scrollHeight) this.scrollDirty = true;
		this.scrollHeight = runningTop;
	}
	resetRenderState() {
		this.renderState.scrollTop = -1;
		this.renderState.firstIndex = -1;
		this.renderState.lastIndex = -1;
		this.renderState.stickyHeight = 0;
		this.renderState.stickyTop = -1;
		this.renderState.stickyBottom = -1;
	}
	getFitPerfectlyOverscroll() {
		return this.getLayout().gap + this.itemMetricsCache.diffHeaderHeight;
	}
};
function prepareItemInstance(item) {
	item.instance.cleanUp(true);
	if (item.type === "diff") return item.instance.prepareCodeViewItem(item.item.fileDiff, item.top, void 0, item.item.annotations ?? []);
	else return item.instance.prepareCodeViewItem(item.item.file, item.top, void 0, item.item.annotations ?? []);
}
function shouldClearPool(previousOptions, nextOptions) {
	return !areThemesEqual(previousOptions.theme ?? DEFAULT_THEMES, nextOptions.theme ?? DEFAULT_THEMES) || (previousOptions.themeType ?? "system") !== (nextOptions.themeType ?? "system") || previousOptions.unsafeCSS !== nextOptions.unsafeCSS;
}
function hasItemLayoutOptionChanged(previousOptions, nextOptions) {
	return (previousOptions.overflow ?? "scroll") !== (nextOptions.overflow ?? "scroll") || (previousOptions.disableLineNumbers ?? false) !== (nextOptions.disableLineNumbers ?? false) || (previousOptions.disableFileHeader ?? false) !== (nextOptions.disableFileHeader ?? false) || previousOptions.unsafeCSS !== nextOptions.unsafeCSS || (previousOptions.diffStyle ?? "split") !== (nextOptions.diffStyle ?? "split") || (previousOptions.diffIndicators ?? "bars") !== (nextOptions.diffIndicators ?? "bars") || (previousOptions.hunkSeparators ?? "line-info") !== (nextOptions.hunkSeparators ?? "line-info") || (previousOptions.expandUnchanged ?? false) !== (nextOptions.expandUnchanged ?? false) || (previousOptions.collapsedContextThreshold ?? 1) !== (nextOptions.collapsedContextThreshold ?? 1);
}
function hasCodeViewDiffEstimateOptionChanged(previousOptions, nextOptions) {
	return (previousOptions.disableFileHeader ?? false) !== (nextOptions.disableFileHeader ?? false) || (previousOptions.hunkSeparators ?? "line-info") !== (nextOptions.hunkSeparators ?? "line-info") || (previousOptions.expandUnchanged ?? false) !== (nextOptions.expandUnchanged ?? false) || (previousOptions.collapsedContextThreshold ?? 1) !== (nextOptions.collapsedContextThreshold ?? 1);
}
function isPooledShadowChild(child) {
	if (child instanceof SVGElement) return true;
	return isStyleNode(child) && (child.hasAttribute("data-core-css") || child.hasAttribute("data-theme-css") || child.hasAttribute("data-unsafe-css"));
}
function formatSelectedLineRange(range) {
	const start = formatSelectedLinePoint(range.start, range.side);
	const end = formatSelectedLinePoint(range.end, range.endSide ?? range.side);
	return start === end ? start : `${start}-${end}`;
}
function formatSelectedLinePoint(lineNumber, side) {
	if (side == null) return `${lineNumber}`;
	return `${side === "deletions" ? "D" : "A"}${lineNumber}`;
}
function renderItem(item, fileContainer, forceRender = false) {
	if (item.type === "diff") return item.instance.render({
		deferManagers: true,
		fileContainer,
		fileDiff: item.item.fileDiff,
		forceRender,
		lineAnnotations: item.item.annotations ?? []
	});
	else return item.instance.render({
		deferManagers: true,
		fileContainer,
		file: item.item.file,
		forceRender,
		lineAnnotations: item.item.annotations ?? []
	});
}
/**
* Keep the rendered DOM order aligned with the current record order even when
* we reuse existing elements. Reused items may already be mounted elsewhere in
* the sticky container, so this moves them into the correct sibling position
* before rendering updates.
*/
function syncRenderedItemOrder(container, element, prevElement) {
	if (prevElement == null) {
		if (container.firstChild !== element) container.prepend(element);
		return;
	}
	if (prevElement.nextSibling !== element) prevElement.after(element);
}
function hasAnnotations(item) {
	return (item.annotations?.length ?? 0) > 0;
}
function getSlotItems(renderedItems, { hasHeaderRenderers, hasAnnotationRenderer, hasGutterRenderer }) {
	if (renderedItems.length === 0) return;
	if (hasHeaderRenderers || hasGutterRenderer) return renderedItems;
	if (!hasAnnotationRenderer) return;
	const slotSnapshot = [];
	for (const renderedItem of renderedItems) if (hasAnnotations(renderedItem.item)) slotSnapshot.push(renderedItem);
	return slotSnapshot.length > 0 ? slotSnapshot : void 0;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/resolveRegion.js
function resolveRegion(diff, target) {
	const { resolution, hunkIndex, startContentIndex, endContentIndex, indexesToDelete = /* @__PURE__ */ new Set() } = target;
	const currentHunk = diff.hunks[hunkIndex];
	if (currentHunk == null) {
		console.error({
			diff,
			hunkIndex
		});
		throw new Error(`resolveRegion: Invalid hunk index: ${hunkIndex}`);
	}
	if (startContentIndex < 0 || endContentIndex >= currentHunk.hunkContent.length || startContentIndex > endContentIndex) throw new Error(`resolveRegion: Invalid content range, ${startContentIndex}, ${endContentIndex}`);
	const { hunks, additionLines, deletionLines } = diff;
	const resolvedDiff = {
		...diff,
		hunks: [],
		deletionLines: [],
		additionLines: [],
		splitLineCount: 0,
		unifiedLineCount: 0,
		cacheKey: diff.cacheKey != null ? `${diff.cacheKey}:${resolution[0]}-${hunkIndex}:${startContentIndex}-${endContentIndex}` : void 0
	};
	const cursor = {
		nextAdditionLineIndex: 0,
		nextDeletionLineIndex: 0,
		nextAdditionStart: 1,
		nextDeletionStart: 1,
		splitLineCount: 0,
		unifiedLineCount: 0
	};
	const updatesEOFState = hunkIndex === hunks.length - 1 && endContentIndex === currentHunk.hunkContent.length - 1;
	const shouldProcessCollapsedContext = !diff.isPartial;
	for (const [index, hunk] of hunks.entries()) {
		processCollapsedContext(diff, resolvedDiff, cursor, getHunkSideStartBoundary(hunk.deletionStart, hunk.deletionCount) - hunk.collapsedBefore, getHunkSideStartBoundary(hunk.additionStart, hunk.additionCount) - hunk.collapsedBefore, hunk.collapsedBefore, shouldProcessCollapsedContext);
		const newHunk = {
			...hunk,
			hunkContent: [],
			additionStart: cursor.nextAdditionStart,
			deletionStart: cursor.nextDeletionStart,
			additionLineIndex: cursor.nextAdditionLineIndex,
			deletionLineIndex: cursor.nextDeletionLineIndex,
			additionCount: 0,
			deletionCount: 0,
			deletionLines: 0,
			additionLines: 0,
			splitLineStart: cursor.splitLineCount,
			unifiedLineStart: cursor.unifiedLineCount,
			splitLineCount: 0,
			unifiedLineCount: 0
		};
		for (const [contentIndex, content] of hunk.hunkContent.entries()) if (index !== hunkIndex || contentIndex < startContentIndex || contentIndex > endContentIndex) {
			pushContentLinesToDiff(content, resolvedDiff, deletionLines, additionLines);
			const newContent = {
				...content,
				additionLineIndex: cursor.nextAdditionLineIndex,
				deletionLineIndex: cursor.nextDeletionLineIndex
			};
			newHunk.hunkContent.push(newContent);
			advanceCursor(newContent, cursor, newHunk);
		} else if (indexesToDelete.has(contentIndex)) newHunk.hunkContent.push({
			type: "context",
			lines: 0,
			deletionLineIndex: cursor.nextDeletionLineIndex,
			additionLineIndex: cursor.nextAdditionLineIndex
		});
		else if (content.type === "context") {
			pushContentLinesToDiff(content, resolvedDiff, deletionLines, additionLines);
			const newContent = {
				...content,
				deletionLineIndex: cursor.nextDeletionLineIndex,
				additionLineIndex: cursor.nextAdditionLineIndex
			};
			newHunk.hunkContent.push(newContent);
			advanceCursor(newContent, cursor, newHunk);
		} else {
			pushResolveLinesToDiff(resolution, content, resolvedDiff, deletionLines, additionLines);
			const newContent = {
				type: "context",
				lines: resolution === "deletions" ? content.deletions : resolution === "additions" ? content.additions : content.deletions + content.additions,
				deletionLineIndex: cursor.nextDeletionLineIndex,
				additionLineIndex: cursor.nextAdditionLineIndex
			};
			newHunk.hunkContent.push(newContent);
			advanceCursor(newContent, cursor, newHunk);
		}
		if (index === hunkIndex && updatesEOFState) {
			const noEOFCR = resolution === "deletions" ? hunk.noEOFCRDeletions : hunk.noEOFCRAdditions;
			newHunk.noEOFCRAdditions = noEOFCR;
			newHunk.noEOFCRDeletions = noEOFCR;
		}
		if (newHunk.additionCount === 0) {
			newHunk.additionStart--;
			if (!diff.isPartial) newHunk.additionLineIndex--;
		}
		if (newHunk.deletionCount === 0) {
			newHunk.deletionStart--;
			if (!diff.isPartial) newHunk.deletionLineIndex--;
		}
		resolvedDiff.hunks.push(newHunk);
	}
	const finalHunk = hunks.at(-1);
	if (finalHunk != null && !diff.isPartial) {
		const finalDeletionEnd = getHunkSideEndBoundary(finalHunk.deletionStart, finalHunk.deletionCount);
		const finalAdditionEnd = getHunkSideEndBoundary(finalHunk.additionStart, finalHunk.additionCount);
		const trailingContext = Math.min(deletionLines.length - finalDeletionEnd, additionLines.length - finalAdditionEnd);
		pushCollapsedContextLines(resolvedDiff, deletionLines, additionLines, finalDeletionEnd, finalAdditionEnd, trailingContext);
		cursor.splitLineCount += trailingContext;
		cursor.unifiedLineCount += trailingContext;
	}
	resolvedDiff.splitLineCount = cursor.splitLineCount;
	resolvedDiff.unifiedLineCount = cursor.unifiedLineCount;
	return resolvedDiff;
}
function pushCollapsedContextLines(diff, deletionLines, additionLines, deletionLineIndex, additionLineIndex, lineCount) {
	for (let index = 0; index < lineCount; index++) {
		const deletionLine = deletionLines[deletionLineIndex + index];
		const additionLine = additionLines[additionLineIndex + index];
		if (deletionLine == null || additionLine == null) throw new Error("pushCollapsedContextLines: missing collapsed context line");
		diff.deletionLines.push(deletionLine);
		diff.additionLines.push(additionLine);
	}
}
function processCollapsedContext(sourceDiff, resolvedDiff, cursor, deletionLineIndex, additionLineIndex, lineCount, shouldProcessContent) {
	if (lineCount <= 0) return;
	if (shouldProcessContent) {
		pushCollapsedContextLines(resolvedDiff, sourceDiff.deletionLines, sourceDiff.additionLines, deletionLineIndex, additionLineIndex, lineCount);
		cursor.nextAdditionLineIndex += lineCount;
		cursor.nextDeletionLineIndex += lineCount;
	}
	cursor.nextAdditionStart += lineCount;
	cursor.nextDeletionStart += lineCount;
	cursor.splitLineCount += lineCount;
	cursor.unifiedLineCount += lineCount;
}
function pushContentLinesToDiff(content, diff, deletionLines, additionLines) {
	if (content.type === "context") for (let i = 0; i < content.lines; i++) {
		const line = additionLines[content.additionLineIndex + i];
		if (line == null) {
			console.error({
				additionLines,
				content,
				i
			});
			throw new Error("pushContentLinesToDiff: Context line does not exist");
		}
		diff.deletionLines.push(line);
		diff.additionLines.push(line);
	}
	else {
		const len = Math.max(content.deletions, content.additions);
		for (let i = 0; i < len; i++) {
			if (i < content.deletions) {
				const line = deletionLines[content.deletionLineIndex + i];
				if (line == null) {
					console.error({
						deletionLines,
						content,
						i
					});
					throw new Error("pushContentLinesToDiff: Deletion line does not exist");
				}
				diff.deletionLines.push(line);
			}
			if (i < content.additions) {
				const line = additionLines[content.additionLineIndex + i];
				if (line == null) {
					console.error({
						additionLines,
						content,
						i
					});
					throw new Error("pushContentLinesToDiff: Addition line does not exist");
				}
				diff.additionLines.push(line);
			}
		}
	}
}
function pushResolveLinesToDiff(resolution, content, diff, deletionLines, additionLines) {
	if (resolution === "deletions" || resolution === "both") for (let i = 0; i < content.deletions; i++) {
		const line = deletionLines[content.deletionLineIndex + i];
		if (line == null) {
			console.error({
				deletionLines,
				content,
				i
			});
			throw new Error("pushResolveLinesToDiff: Deletion line does not exist");
		}
		diff.deletionLines.push(line);
		diff.additionLines.push(line);
	}
	if (resolution === "additions" || resolution === "both") for (let i = 0; i < content.additions; i++) {
		const line = additionLines[content.additionLineIndex + i];
		if (line == null) {
			console.error({
				additionLines,
				content,
				i
			});
			throw new Error("pushResolveLinesToDiff: Addition line does not exist");
		}
		diff.deletionLines.push(line);
		diff.additionLines.push(line);
	}
}
function advanceCursor(content, cursor, hunk) {
	if (content.type === "context") {
		cursor.nextAdditionLineIndex += content.lines;
		cursor.nextDeletionLineIndex += content.lines;
		cursor.nextAdditionStart += content.lines;
		cursor.nextDeletionStart += content.lines;
		cursor.splitLineCount += content.lines;
		cursor.unifiedLineCount += content.lines;
		hunk.additionCount += content.lines;
		hunk.deletionCount += content.lines;
		hunk.splitLineCount += content.lines;
		hunk.unifiedLineCount += content.lines;
	} else {
		cursor.nextAdditionLineIndex += content.additions;
		cursor.nextDeletionLineIndex += content.deletions;
		cursor.nextAdditionStart += content.additions;
		cursor.nextDeletionStart += content.deletions;
		cursor.splitLineCount += Math.max(content.deletions, content.additions);
		cursor.unifiedLineCount += content.deletions + content.additions;
		hunk.deletionCount += content.deletions;
		hunk.deletionLines += content.deletions;
		hunk.additionCount += content.additions;
		hunk.additionLines += content.additions;
		hunk.splitLineCount += Math.max(content.deletions, content.additions);
		hunk.unifiedLineCount += content.deletions + content.additions;
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/normalizeDiffResolution.js
function normalizeDiffResolution(options) {
	const type = (() => {
		return typeof options === "string" ? options : options.type;
	})();
	return type === "accept" || type === "incoming" ? "additions" : type === "reject" || type === "current" ? "deletions" : "both";
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/resolveConflict.js
function resolveConflict(diff, conflict, type) {
	return resolveRegion(diff, {
		resolution: normalizeDiffResolution(type),
		hunkIndex: conflict.hunkIndex,
		startContentIndex: conflict.startContentIndex,
		endContentIndex: conflict.endContentIndex,
		indexesToDelete: getConflictDeleteContentIndexes(conflict)
	});
}
function getConflictDeleteContentIndexes(conflict) {
	const indexes = /* @__PURE__ */ new Set();
	if (conflict.baseContentIndex != null) indexes.add(conflict.baseContentIndex);
	if (conflict.endMarkerContentIndex !== conflict.endContentIndex) indexes.add(conflict.endMarkerContentIndex);
	return indexes;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getMergeConflictActionSlotName.js
function getMergeConflictActionSlotName({ hunkIndex, lineIndex, conflictIndex }) {
	return `merge-conflict-action-${hunkIndex}-${lineIndex}-${conflictIndex}`;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/parseMergeConflictDiffFromFile.js
function getMergeConflictActionAnchor(action, fileDiff) {
	const hunk = fileDiff.hunks[action.hunkIndex];
	if (hunk == null) return;
	return {
		hunkIndex: action.hunkIndex,
		lineIndex: getUnifiedLineStartForContent(hunk, action.startContentIndex)
	};
}
function parseMergeConflictDiffFromFile(file, maxContextLines = 6) {
	maxContextLines = Math.max(maxContextLines, 1);
	const s = {
		deletionLines: [],
		additionLines: [],
		conflictStack: [],
		conflictBuilders: [],
		actions: [],
		hunks: [],
		nextConflictIndex: 0,
		splitLineCount: 0,
		unifiedLineCount: 0,
		lastHunkEnd: 0,
		activeHunk: void 0,
		maxContextLines,
		maxContextLines2: maxContextLines * 2
	};
	const contents = file.contents;
	const contentLength = contents.length;
	if (contentLength > 0) {
		let lineStart = 0;
		let lineIndex = 0;
		let newlinePos = contents.indexOf("\n", lineStart);
		while (newlinePos !== -1) {
			processLine(s, contents.slice(lineStart, newlinePos + 1), lineIndex);
			lineStart = newlinePos + 1;
			lineIndex++;
			newlinePos = contents.indexOf("\n", lineStart);
		}
		if (lineStart < contentLength) processLine(s, contents.slice(lineStart), lineIndex);
	}
	if (s.conflictStack.length > 0) throw new Error("parseMergeConflictDiffFromFile: unfinished merge conflict marker stack");
	if (s.activeHunk != null && s.activeHunk.hunkContent.length > 0) {
		flushBufferedContext(s, s.activeHunk, "trailing");
		finalizeActiveHunk(s);
	}
	for (let conflictIndex = 0; conflictIndex < s.conflictBuilders.length; conflictIndex++) {
		const builder = s.conflictBuilders[conflictIndex];
		if (builder == null || !builder.completed) throw new Error(`parseMergeConflictDiffFromFile: failed to build merge conflict action ${conflictIndex}`);
	}
	if (s.hunks.length > 0 && s.additionLines.length > 0 && s.deletionLines.length > 0) {
		const lastHunk = s.hunks[s.hunks.length - 1];
		const collapsedAfter = Math.max(s.additionLines.length - getHunkSideEndBoundary(lastHunk.additionStart, lastHunk.additionCount), 0);
		s.splitLineCount += collapsedAfter;
		s.unifiedLineCount += collapsedAfter;
	}
	const currentContents = s.deletionLines.join("");
	const incomingContents = s.additionLines.join("");
	const currentFile = createResolvedConflictFile(file, "current", currentContents);
	const incomingFile = createResolvedConflictFile(file, "incoming", incomingContents);
	let type = "change";
	if (incomingContents === "") type = "deleted";
	else if (currentContents === "") type = "new";
	const fileDiff = {
		name: file.name,
		prevName: void 0,
		type,
		hunks: s.hunks,
		splitLineCount: s.splitLineCount,
		unifiedLineCount: s.unifiedLineCount,
		isPartial: false,
		deletionLines: s.deletionLines,
		additionLines: s.additionLines,
		cacheKey: file.cacheKey != null ? `${file.cacheKey}:merge-conflict-diff` : void 0
	};
	return {
		fileDiff,
		currentFile,
		incomingFile,
		actions: s.actions,
		markerRows: buildMergeConflictMarkerRows(fileDiff, s.actions)
	};
}
function processLine(s, line, index) {
	const frame = s.conflictStack[s.conflictStack.length - 1];
	if (frame == null) {
		if (line.length >= 7 && line.charCodeAt(0) === 60 && getMergeConflictMarkerType(line) === "start") {
			handleStartMarker(s, line, index);
			return;
		}
		emitContextLine(s, line);
		return;
	}
	const markerType = getMergeConflictMarkerType(line);
	if (markerType === "start") {
		handleStartMarker(s, line, index);
		return;
	}
	if (markerType === "base") {
		frame.stage = "base";
		frame.baseMarkerLineIndex = index;
		frame.markerLines.base = line;
		return;
	}
	if (markerType === "separator") {
		frame.stage = "incoming";
		frame.separatorLineIndex = index;
		frame.markerLines.separator = line;
		return;
	}
	if (markerType === "end") {
		const completedFrame = s.conflictStack.pop();
		if (completedFrame == null) throw new Error("parseMergeConflictDiffFromFile: encountered end marker before start marker");
		finalizeConflict(s, completedFrame, index, line);
		return;
	}
	if (frame.stage === "current") emitChangeLine(s, "deletion", line, frame.conflictIndex, "current");
	else if (frame.stage === "base") emitContextLine(s, line, frame.conflictIndex);
	else emitChangeLine(s, "addition", line, frame.conflictIndex, "incoming");
}
function ensureActiveHunk(s) {
	s.activeHunk ??= createHunkBuilder(s.additionLines.length + 1, s.deletionLines.length + 1);
	return s.activeHunk;
}
function assignConflictContent(s, conflictIndex, role, contentIndex) {
	const builder = s.conflictBuilders[conflictIndex];
	if (builder == null) throw new Error(`parseMergeConflictDiffFromFile: failed to locate conflict action ${conflictIndex}`);
	const action = builder.action;
	const hunkIndex = s.hunks.length;
	if (action.hunkIndex < 0) action.hunkIndex = hunkIndex;
	else if (action.hunkIndex !== hunkIndex) throw new Error(`parseMergeConflictDiffFromFile: conflict ${conflictIndex} spans multiple hunks and cannot be anchored`);
	if (action.startContentIndex < 0) action.startContentIndex = contentIndex;
	action.endContentIndex = contentIndex;
	action.endMarkerContentIndex = contentIndex;
	if (role === "current") {
		action.currentContentIndex ??= contentIndex;
		return;
	}
	if (role === "base") {
		action.baseContentIndex ??= contentIndex;
		return;
	}
	action.incomingContentIndex = contentIndex;
}
function appendChangeLine(hunk, lineType, additionLineIndex, deletionLineIndex) {
	const hunkContent = hunk.hunkContent;
	const lastContent = hunkContent[hunkContent.length - 1];
	if (lastContent?.type === "change") {
		if (lineType === "addition") lastContent.additions++;
		else lastContent.deletions++;
		return hunkContent.length - 1;
	}
	hunkContent.push({
		type: "change",
		additions: lineType === "addition" ? 1 : 0,
		deletions: lineType === "deletion" ? 1 : 0,
		additionLineIndex,
		deletionLineIndex
	});
	return hunkContent.length - 1;
}
function flushBufferedContext(s, hunk, mode) {
	let count = hunk.contextBufferCount;
	let addStart = hunk.contextBufferAdditionStart;
	let delStart = hunk.contextBufferDeletionStart;
	if (mode === "leading" && count > s.maxContextLines) {
		const difference = count - s.maxContextLines;
		addStart += difference;
		delStart += difference;
		count = s.maxContextLines;
		hunk.additionStart += difference;
		hunk.deletionStart += difference;
		hunk.additionLineIndex += difference;
		hunk.deletionLineIndex += difference;
	}
	if (mode === "trailing" && count > s.maxContextLines) count = s.maxContextLines;
	if (count === 0) {
		hunk.contextBufferCount = 0;
		hunk.contextBufferBaseConflicts = void 0;
		return;
	}
	const hunkContent = hunk.hunkContent;
	const lastContent = hunkContent[hunkContent.length - 1];
	let contentIndex;
	if (lastContent?.type === "context") {
		lastContent.lines += count;
		contentIndex = hunkContent.length - 1;
	} else {
		hunkContent.push({
			type: "context",
			lines: count,
			additionLineIndex: addStart,
			deletionLineIndex: delStart
		});
		contentIndex = hunkContent.length - 1;
	}
	hunk.additionCount += count;
	hunk.deletionCount += count;
	const baseConflicts = hunk.contextBufferBaseConflicts;
	if (baseConflicts != null) {
		const bufferStartOffset = addStart - hunk.contextBufferAdditionStart;
		for (const [offset, conflictIndex] of baseConflicts) if (offset >= bufferStartOffset && offset < bufferStartOffset + count) assignConflictContent(s, conflictIndex, "base", contentIndex);
	}
	hunk.contextBufferCount = 0;
	hunk.contextBufferBaseConflicts = void 0;
}
function finalizeActiveHunk(s) {
	if (s.activeHunk == null) return;
	const hunk = s.activeHunk;
	s.activeHunk = void 0;
	if (hunk.hunkContent.length === 0) return;
	let hunkSplitLineCount = 0;
	let hunkUnifiedLineCount = 0;
	for (const content of hunk.hunkContent) if (content.type === "context") {
		hunkSplitLineCount += content.lines;
		hunkUnifiedLineCount += content.lines;
	} else {
		hunkSplitLineCount += Math.max(content.additions, content.deletions);
		hunkUnifiedLineCount += content.additions + content.deletions;
	}
	const additionStart = hunk.additionCount === 0 ? hunk.additionStart - 1 : hunk.additionStart;
	const deletionStart = hunk.deletionCount === 0 ? hunk.deletionStart - 1 : hunk.deletionStart;
	const collapsedBefore = Math.max(getHunkSideStartBoundary(additionStart, hunk.additionCount) - s.lastHunkEnd, 0);
	const finalizedHunk = {
		collapsedBefore,
		additionStart,
		additionCount: hunk.additionCount,
		additionLines: hunk.additionLines,
		additionLineIndex: hunk.additionLineIndex,
		deletionStart,
		deletionCount: hunk.deletionCount,
		deletionLines: hunk.deletionLines,
		deletionLineIndex: hunk.deletionLineIndex,
		hunkContent: hunk.hunkContent,
		hunkContext: void 0,
		hunkSpecs: `@@ -${formatHunkRange(deletionStart, hunk.deletionCount)} +${formatHunkRange(additionStart, hunk.additionCount)} @@\n`,
		splitLineStart: s.splitLineCount + collapsedBefore,
		splitLineCount: hunkSplitLineCount,
		unifiedLineStart: s.unifiedLineCount + collapsedBefore,
		unifiedLineCount: hunkUnifiedLineCount,
		noEOFCRAdditions: false,
		noEOFCRDeletions: false
	};
	s.hunks.push(finalizedHunk);
	s.splitLineCount += collapsedBefore + hunkSplitLineCount;
	s.unifiedLineCount += collapsedBefore + hunkUnifiedLineCount;
	s.lastHunkEnd = getHunkSideEndBoundary(additionStart, hunk.additionCount);
}
function splitHunkWithBufferedContext(s) {
	if (s.activeHunk == null) return;
	const hunk = s.activeHunk;
	const count = hunk.contextBufferCount;
	const omittedContextLineCount = count - s.maxContextLines2;
	const nextAddStart = hunk.contextBufferAdditionStart + count - s.maxContextLines;
	const nextDelStart = hunk.contextBufferDeletionStart + count - s.maxContextLines;
	let nextBaseConflicts;
	if (hunk.contextBufferBaseConflicts != null) {
		const tailOffset = count - s.maxContextLines;
		for (const [offset, ci] of hunk.contextBufferBaseConflicts) if (offset >= tailOffset) {
			nextBaseConflicts ??= /* @__PURE__ */ new Map();
			nextBaseConflicts.set(offset - tailOffset, ci);
		}
	}
	flushBufferedContext(s, hunk, "trailing");
	const emittedAdditionCount = hunk.additionCount;
	const emittedDeletionCount = hunk.deletionCount;
	finalizeActiveHunk(s);
	s.activeHunk = createHunkBuilder(hunk.additionStart + emittedAdditionCount + omittedContextLineCount, hunk.deletionStart + emittedDeletionCount + omittedContextLineCount);
	s.activeHunk.contextBufferAdditionStart = nextAddStart;
	s.activeHunk.contextBufferDeletionStart = nextDelStart;
	s.activeHunk.contextBufferCount = s.maxContextLines;
	s.activeHunk.contextBufferBaseConflicts = nextBaseConflicts;
}
function emitContextLine(s, line, baseConflictIndex = -1) {
	const hunk = ensureActiveHunk(s);
	if (hunk.contextBufferCount === 0) {
		hunk.contextBufferAdditionStart = s.additionLines.length;
		hunk.contextBufferDeletionStart = s.deletionLines.length;
	}
	s.additionLines.push(line);
	s.deletionLines.push(line);
	if (baseConflictIndex >= 0) {
		hunk.contextBufferBaseConflicts ??= /* @__PURE__ */ new Map();
		hunk.contextBufferBaseConflicts.set(hunk.contextBufferCount, baseConflictIndex);
	}
	hunk.contextBufferCount++;
}
function emitChangeLine(s, lineType, line, conflictIndex, role) {
	let hunk = ensureActiveHunk(s);
	if (hunk.hunkContent.length > 0 && hunk.contextBufferCount > s.maxContextLines2) {
		splitHunkWithBufferedContext(s);
		hunk = s.activeHunk;
	}
	flushBufferedContext(s, hunk, hunk.hunkContent.length === 0 ? "leading" : "before-change");
	const additionLineIndex = s.additionLines.length;
	const deletionLineIndex = s.deletionLines.length;
	if (lineType === "addition") s.additionLines.push(line);
	else s.deletionLines.push(line);
	const contentIndex = appendChangeLine(hunk, lineType, additionLineIndex, deletionLineIndex);
	if (lineType === "addition") {
		hunk.additionCount++;
		hunk.additionLines++;
	} else {
		hunk.deletionCount++;
		hunk.deletionLines++;
	}
	assignConflictContent(s, conflictIndex, role, contentIndex);
}
function finalizeConflict(s, frame, endLineIndex, endMarkerLine) {
	if (frame.separatorLineIndex == null || frame.markerLines.separator == null) throw new Error(`parseMergeConflictDiffFromFile: conflict ${frame.conflictIndex} is missing a separator marker`);
	const builder = s.conflictBuilders[frame.conflictIndex];
	if (builder == null) throw new Error(`parseMergeConflictDiffFromFile: failed to finalize conflict ${frame.conflictIndex}`);
	const action = builder.action;
	action.markerLines.separator = frame.markerLines.separator;
	action.markerLines.end = endMarkerLine;
	if (frame.markerLines.base != null) action.markerLines.base = frame.markerLines.base;
	action.conflict = {
		conflictIndex: frame.conflictIndex,
		startLineIndex: frame.startLineIndex,
		startLineNumber: frame.startLineIndex + 1,
		separatorLineIndex: frame.separatorLineIndex,
		separatorLineNumber: frame.separatorLineIndex + 1,
		endLineIndex,
		endLineNumber: endLineIndex + 1,
		baseMarkerLineIndex: frame.baseMarkerLineIndex,
		baseMarkerLineNumber: frame.baseMarkerLineIndex != null ? frame.baseMarkerLineIndex + 1 : void 0
	};
	const fallbackContentIndex = action.currentContentIndex ?? action.incomingContentIndex;
	action.currentContentIndex ??= fallbackContentIndex;
	action.incomingContentIndex ??= fallbackContentIndex;
	if (action.startContentIndex < 0 && fallbackContentIndex != null) action.startContentIndex = fallbackContentIndex;
	if (action.endContentIndex < 0 && fallbackContentIndex != null) action.endContentIndex = fallbackContentIndex;
	if (action.endMarkerContentIndex < 0 && fallbackContentIndex != null) action.endMarkerContentIndex = fallbackContentIndex;
	if (action.hunkIndex < 0 || action.startContentIndex < 0 || action.endContentIndex < 0 || action.endMarkerContentIndex < 0) throw new Error(`parseMergeConflictDiffFromFile: failed to anchor merge conflict ${frame.conflictIndex}`);
	s.actions[action.conflictIndex] = action;
	builder.completed = true;
}
function handleStartMarker(s, line, lineIndex) {
	const conflictIndex = s.nextConflictIndex;
	s.nextConflictIndex++;
	s.conflictStack.push({
		conflictIndex,
		stage: "current",
		startLineIndex: lineIndex,
		markerLines: { start: line }
	});
	s.conflictBuilders[conflictIndex] = {
		completed: false,
		action: {
			conflict: {
				conflictIndex,
				startLineIndex: lineIndex,
				startLineNumber: lineIndex + 1,
				separatorLineIndex: lineIndex,
				separatorLineNumber: lineIndex + 1,
				endLineIndex: lineIndex,
				endLineNumber: lineIndex + 1,
				baseMarkerLineIndex: void 0,
				baseMarkerLineNumber: void 0
			},
			conflictIndex,
			hunkIndex: -1,
			startContentIndex: -1,
			endContentIndex: -1,
			endMarkerContentIndex: -1,
			markerLines: {
				start: line,
				separator: "",
				end: ""
			}
		}
	};
}
function createHunkBuilder(additionStart, deletionStart) {
	return {
		additionStart,
		deletionStart,
		additionCount: 0,
		deletionCount: 0,
		additionLines: 0,
		deletionLines: 0,
		additionLineIndex: Math.max(additionStart - 1, 0),
		deletionLineIndex: Math.max(deletionStart - 1, 0),
		hunkContent: [],
		contextBufferAdditionStart: Math.max(additionStart - 1, 0),
		contextBufferDeletionStart: Math.max(deletionStart - 1, 0),
		contextBufferCount: 0,
		contextBufferBaseConflicts: void 0
	};
}
function formatHunkRange(start, count) {
	return count === 1 ? `${start}` : `${start},${count}`;
}
function getMergeConflictMarkerType(line) {
	if (line.length < 7) return;
	const markerCode = line.charCodeAt(0);
	if (markerCode !== 60 && markerCode !== 62 && markerCode !== 61 && markerCode !== 124) return;
	const lineEnd = getLineContentEndIndex(line);
	if (lineEnd < 7) return;
	let markerLength = 1;
	while (markerLength < lineEnd && line.charCodeAt(markerLength) === markerCode) markerLength++;
	if (markerLength < 7) return;
	if (markerCode === 61) return markerLength === lineEnd ? "separator" : void 0;
	if (markerLength !== lineEnd && !isWhitespaceCode(line.charCodeAt(markerLength))) return;
	if (markerCode === 60) return "start";
	if (markerCode === 62) return "end";
	return "base";
}
function getLineContentEndIndex(line) {
	let end = line.length;
	if (end > 0 && line.charCodeAt(end - 1) === 10) end--;
	if (end > 0 && line.charCodeAt(end - 1) === 13) end--;
	return end;
}
function isWhitespaceCode(code) {
	return code === 9 || code === 10 || code === 11 || code === 12 || code === 13 || code === 32;
}
function createResolvedConflictFile(file, side, contents) {
	return {
		...file,
		contents,
		cacheKey: file.cacheKey != null ? `${file.cacheKey}:merge-conflict-${side}` : void 0
	};
}
function buildMergeConflictMarkerRows(fileDiff, actions) {
	const markerRows = [];
	const hunkLineStartCache = new Array(fileDiff.hunks.length);
	const getLineStart = (hunkIndex, contentIndex) => {
		const hunk = fileDiff.hunks[hunkIndex];
		if (hunk == null) return 0;
		let starts = hunkLineStartCache[hunkIndex];
		if (starts == null) {
			starts = new Array(hunk.hunkContent.length + 1);
			let lineIndex = hunk.unifiedLineStart;
			starts[0] = lineIndex;
			for (let index = 0; index < hunk.hunkContent.length; index++) {
				const content = hunk.hunkContent[index];
				lineIndex += content.type === "context" ? content.lines : content.deletions + content.additions;
				starts[index + 1] = lineIndex;
			}
			hunkLineStartCache[hunkIndex] = starts;
		}
		return starts[Math.max(contentIndex, 0)] ?? hunk.unifiedLineStart;
	};
	const getLineEnd = (hunkIndex, contentIndex) => {
		const lineStart = getLineStart(hunkIndex, contentIndex);
		const lineEndExclusive = hunkLineStartCache[hunkIndex]?.[Math.max(contentIndex + 1, 0)] ?? getLineStart(hunkIndex, contentIndex + 1);
		return Math.max(lineStart, lineEndExclusive - 1);
	};
	for (const action of actions) {
		if (action == null) continue;
		const hunk = fileDiff.hunks[action.hunkIndex];
		if (hunk == null) continue;
		const actionLineIndex = getLineStart(action.hunkIndex, action.startContentIndex);
		markerRows.push(createMergeConflictMarkerRow(action, "marker-start", action.startContentIndex, action.markerLines.start, actionLineIndex));
		if (action.baseContentIndex != null) {
			const currentContentIndex = action.currentContentIndex;
			const incomingContentIndex = action.incomingContentIndex;
			if (currentContentIndex == null || incomingContentIndex == null) continue;
			const baseMarkerLine = action.markerLines.base;
			if (baseMarkerLine == null) continue;
			const currentChange = hunk.hunkContent[currentContentIndex];
			const baseContext = hunk.hunkContent[action.baseContentIndex];
			const incomingChange = hunk.hunkContent[incomingContentIndex];
			if (currentChange?.type !== "change" || baseContext?.type !== "context" || incomingChange?.type !== "change") continue;
			const currentStart = getLineStart(action.hunkIndex, currentContentIndex);
			const incomingStart = getLineStart(action.hunkIndex, incomingContentIndex);
			markerRows.push(createMergeConflictMarkerRow(action, "marker-base", action.baseContentIndex, baseMarkerLine, currentStart + currentChange.deletions));
			markerRows.push(createMergeConflictMarkerRow(action, "marker-separator", action.baseContentIndex, action.markerLines.separator, incomingStart), createMergeConflictMarkerRow(action, "marker-end", action.endMarkerContentIndex, action.markerLines.end, getLineEnd(action.hunkIndex, action.endMarkerContentIndex)));
			continue;
		}
		const currentContentIndex = action.currentContentIndex;
		if (currentContentIndex == null) continue;
		const content = hunk.hunkContent[currentContentIndex];
		if (content?.type !== "change") continue;
		const contentStart = getLineStart(action.hunkIndex, currentContentIndex);
		const separatorLineIndex = content.deletions > 0 ? contentStart + content.deletions : actionLineIndex;
		markerRows.push(createMergeConflictMarkerRow(action, "marker-separator", currentContentIndex, action.markerLines.separator, separatorLineIndex), createMergeConflictMarkerRow(action, "marker-end", action.endMarkerContentIndex, action.markerLines.end, getLineEnd(action.hunkIndex, action.endMarkerContentIndex)));
	}
	return markerRows;
}
function createMergeConflictMarkerRow(action, type, contentIndex, lineText, lineIndex) {
	return {
		type,
		hunkIndex: action.hunkIndex,
		contentIndex,
		conflictIndex: action.conflictIndex,
		lineText,
		lineIndex
	};
}
function getUnifiedLineStartForContent(hunk, contentIndex) {
	let lineIndex = hunk.unifiedLineStart;
	for (let index = 0; index < contentIndex; index++) {
		const content = hunk.hunkContent[index];
		lineIndex += content.type === "context" ? content.lines : content.deletions + content.additions;
	}
	return lineIndex;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/renderers/UnresolvedFileHunksRenderer.js
var UnresolvedFileHunksRenderer = class extends DiffHunksRenderer {
	pendingConflictActions = [];
	pendingMarkerRows = [];
	injectedRows = /* @__PURE__ */ new Map();
	options;
	constructor(options = { theme: DEFAULT_THEMES }, onRenderUpdate, workerManager) {
		super(void 0, onRenderUpdate, workerManager);
		this.options = options;
	}
	setConflictState(conflictActions, markerRows, diff) {
		this.pendingConflictActions = conflictActions;
		this.pendingMarkerRows = markerRows;
		this.syncInjectedRows(conflictActions, markerRows, diff);
	}
	syncInjectedRows(conflictActions, markerRows, diff) {
		this.injectedRows.clear();
		for (const action of conflictActions) {
			const anchor = action != null ? getMergeConflictActionAnchor(action, diff) : void 0;
			if (action == null || anchor == null) continue;
			const row = {
				type: "actions",
				hunkIndex: anchor.hunkIndex,
				lineIndex: anchor.lineIndex,
				conflictIndex: action.conflictIndex
			};
			this.addInjectedRow(row);
		}
		for (const row of markerRows) this.addInjectedRow(row);
	}
	addInjectedRow(row) {
		const key = `${row.hunkIndex}:${row.lineIndex}`;
		const rows = this.injectedRows.get(key);
		if (rows == null) this.injectedRows.set(key, [row]);
		else rows.push(row);
	}
	renderDiff(diff, renderRange = DEFAULT_RENDER_RANGE) {
		if (diff != null) this.syncInjectedRows(this.pendingConflictActions, this.pendingMarkerRows, diff);
		return super.renderDiff(diff, renderRange);
	}
	async asyncRender(diff, renderRange = DEFAULT_RENDER_RANGE) {
		this.syncInjectedRows(this.pendingConflictActions, this.pendingMarkerRows, diff);
		return super.asyncRender(diff, renderRange);
	}
	createPreElement(split, totalLines) {
		return super.createPreElement(split, totalLines, { "data-has-merge-conflict": "" });
	}
	getUnifiedLineDecoration({ type, lineType }) {
		const mergeConflictType = type === "change" ? lineType === "change-deletion" ? "current" : "incoming" : void 0;
		return {
			gutterLineType: type === "change" ? "context" : lineType,
			gutterProperties: getMergeConflictGutterProperties(mergeConflictType),
			contentProperties: getMergeConflictContentProperties(type, mergeConflictType)
		};
	}
	getSplitLineDecoration({ side, type }) {
		const mergeConflictType = type === "change" ? side === "deletions" ? "current" : "incoming" : void 0;
		return {
			gutterLineType: type === "change" ? "context" : type,
			gutterProperties: getMergeConflictGutterProperties(mergeConflictType),
			contentProperties: getMergeConflictContentProperties(type, mergeConflictType)
		};
	}
	getUnifiedInjectedRowsForLine = (ctx) => {
		const rows = this.injectedRows.get(`${ctx.hunkIndex}:${ctx.lineIndex}`);
		if (rows == null || rows.length === 0) return;
		const { mergeConflictActionsType } = this.getOptionsWithDefaults();
		const before = [];
		const after = [];
		for (const row of rows) {
			if (row.type === "actions") {
				before.push({
					content: createMergeConflictActionsRowElement({
						row,
						includeDefaultActions: mergeConflictActionsType === "default",
						includeSlot: true
					}),
					gutter: createMergeConflictGutterGap("action")
				});
				continue;
			}
			(row.type === "marker-end" ? after : before).push({
				content: createMergeConflictMarkerRowElement(row),
				gutter: createMergeConflictGutterGap("marker", row.type)
			});
		}
		return {
			before: before.length > 0 ? before : void 0,
			after: after.length > 0 ? after : void 0
		};
	};
	getOptionsWithDefaults() {
		const options = super.getOptionsWithDefaults();
		options.diffStyle = "unified";
		options.lineDiffType = "none";
		options.mergeConflictActionsType = this.options.mergeConflictActionsType ?? "default";
		return options;
	}
};
function getMergeConflictGutterProperties(mergeConflictType) {
	return mergeConflictType != null ? { "data-merge-conflict": mergeConflictType } : void 0;
}
function getMergeConflictContentProperties(type, mergeConflictType) {
	if (mergeConflictType == null) return;
	if (type === "change") {
		if (mergeConflictType === "current" || mergeConflictType === "incoming") return {
			"data-line-type": "context",
			"data-merge-conflict": mergeConflictType
		};
		return;
	}
	if (mergeConflictType === "marker-start" || mergeConflictType === "marker-base" || mergeConflictType === "marker-separator" || mergeConflictType === "marker-end") return { "data-merge-conflict": mergeConflictType };
}
function createMergeConflictGutterGap(type, markerType) {
	const gap = createGutterGap(void 0, "annotation", 1);
	gap.properties["data-gutter-buffer"] = type === "action" ? "merge-conflict-action" : `merge-conflict-${markerType ?? "marker"}`;
	return gap;
}
function createMergeConflictActionsRowElement({ row, includeDefaultActions, includeSlot }) {
	const contentChildren = includeDefaultActions ? createMergeConflictActionsContent(row.conflictIndex) : [];
	if (includeSlot) contentChildren.push(createHastElement({
		tagName: "slot",
		properties: {
			name: getMergeConflictActionSlotName({
				hunkIndex: row.hunkIndex,
				lineIndex: row.lineIndex,
				conflictIndex: row.conflictIndex
			}),
			"data-merge-conflict-action-slot": ""
		}
	}));
	return createHastElement({
		tagName: "div",
		properties: { "data-merge-conflict-actions": "" },
		children: [createHastElement({
			tagName: "div",
			properties: { "data-merge-conflict-actions-content": "" },
			children: contentChildren
		})]
	});
}
function createMergeConflictMarkerRowElement(row) {
	return createHastElement({
		tagName: "div",
		properties: {
			"data-merge-conflict": row.type,
			"data-merge-conflict-marker-row": ""
		},
		children: [createTextNodeElement(row.lineText.replace(/(?:\r\n|\n|\r)$/, ""))]
	});
}
function createMergeConflictActionsContent(conflictIndex) {
	return [
		createMergeConflictActionButton({
			resolution: "current",
			label: "Accept current change",
			conflictIndex
		}),
		createMergeConflictActionSeparator(),
		createMergeConflictActionButton({
			resolution: "incoming",
			label: "Accept incoming change",
			conflictIndex
		}),
		createMergeConflictActionSeparator(),
		createMergeConflictActionButton({
			resolution: "both",
			label: "Accept both",
			conflictIndex
		})
	];
}
function createMergeConflictActionButton({ resolution, label, conflictIndex }) {
	return createHastElement({
		tagName: "button",
		properties: {
			type: "button",
			"data-merge-conflict-action": resolution,
			"data-merge-conflict-conflict-index": `${conflictIndex}`
		},
		children: [createTextNodeElement(label)]
	});
}
function createMergeConflictActionSeparator() {
	return createHastElement({
		tagName: "span",
		properties: { "data-merge-conflict-action-separator": "" },
		children: [createTextNodeElement("|")]
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areMergeConflictActionsEqual.js
function areMergeConflictActionsEqual(a, b) {
	return a.hunkIndex === b.hunkIndex && a.startContentIndex === b.startContentIndex && a.endContentIndex === b.endContentIndex && a.currentContentIndex === b.currentContentIndex && a.baseContentIndex === b.baseContentIndex && a.incomingContentIndex === b.incomingContentIndex && a.endMarkerContentIndex === b.endMarkerContentIndex && a.conflictIndex === b.conflictIndex && areConflictsEqual(a.conflict, b.conflict);
}
function areConflictsEqual(a, b) {
	return a.conflictIndex === b.conflictIndex && a.startLineIndex === b.startLineIndex && a.startLineNumber === b.startLineNumber && a.separatorLineIndex === b.separatorLineIndex && a.separatorLineNumber === b.separatorLineNumber && a.endLineIndex === b.endLineIndex && a.endLineNumber === b.endLineNumber && a.baseMarkerLineIndex === b.baseMarkerLineIndex && a.baseMarkerLineNumber === b.baseMarkerLineNumber;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/UnresolvedFile.js
var instanceId = -1;
var UnresolvedFile = class extends FileDiff {
	options;
	__id = `unresolved-file:${++instanceId}`;
	type = "unresolved-file";
	computedCache = {
		file: void 0,
		fileDiff: void 0,
		actions: void 0,
		markerRows: void 0
	};
	conflictActions = [];
	markerRows = [];
	conflictActionCache = /* @__PURE__ */ new Map();
	constructor(options = { theme: DEFAULT_THEMES }, workerManager, isContainerManaged = false) {
		super(void 0, workerManager, isContainerManaged);
		this.options = options;
		this.setOptions(options);
	}
	setOptions(options) {
		if (options == null) return;
		if (options.onMergeConflictAction != null && options.onMergeConflictResolve != null) throw new Error("UnresolvedFile: onMergeConflictAction and onMergeConflictResolve are mutually exclusive. Use only one callback.");
		this.options = options;
		this.hunksRenderer.setOptions(this.getHunksRendererOptions(options));
		this.syncInteractionOptions();
	}
	syncInteractionOptions() {
		this.interactionManager.setOptions(pluckInteractionOptions(this.options, typeof this.options.hunkSeparators === "function" || (this.options.hunkSeparators ?? "line-info") === "line-info" || this.options.hunkSeparators === "line-info-basic" ? this.handleExpandHunk : void 0, this.getLineIndex, this.handleMergeConflictActionClick));
	}
	createHunksRenderer(options) {
		return new UnresolvedFileHunksRenderer(this.getHunksRendererOptions(options), this.handleHighlightRender, this.workerManager);
	}
	getHunksRendererOptions(options) {
		return getUnresolvedDiffHunksRendererOptions(options, this.options);
	}
	applyPreNodeAttributes(pre, result) {
		super.applyPreNodeAttributes(pre, result, { "data-has-merge-conflict": "" });
	}
	cleanUp() {
		this.emitPostRender(true);
		this.clearMergeConflictActionCache();
		this.computedCache = {
			file: void 0,
			fileDiff: void 0,
			actions: void 0,
			markerRows: void 0
		};
		this.conflictActions = [];
		super.cleanUp();
	}
	getOrComputeDiff({ file, fileDiff, actions, markerRows }) {
		const { maxContextLines, onMergeConflictAction } = this.options;
		wrapper: if (onMergeConflictAction != null) {
			const hasFileDiff = fileDiff != null;
			if (hasFileDiff !== (actions != null) || hasFileDiff !== (markerRows != null)) throw new Error("UnresolvedFile.getOrComputeDiff: fileDiff, actions, and markerRows must be passed together");
			if (fileDiff != null && actions != null && markerRows != null) {
				this.computedCache = {
					file: file ?? this.computedCache.file,
					fileDiff,
					actions,
					markerRows
				};
				break wrapper;
			} else if (file != null || this.computedCache.file != null) {
				if (file != null && this.computedCache.file != null && !areFilesEqual(file, this.computedCache.file) && this.computedCache.fileDiff != null && this.computedCache.actions != null) throw new Error("UnresolvedFile.getOrComputeDiff: file can only be used to initialize unresolved state once. Pass fileDiff and actions for subsequent updates.");
				file ??= this.computedCache.file;
				if (file == null) throw new Error("UnresolvedFile.getOrComputeDiff: file is null, should be impossible");
				if (!areFilesEqual(file, this.computedCache.file) || this.computedCache.fileDiff == null || this.computedCache.actions == null) {
					const computed = parseMergeConflictDiffFromFile(file, maxContextLines);
					this.computedCache = {
						file,
						fileDiff: computed.fileDiff,
						actions: computed.actions,
						markerRows: computed.markerRows
					};
				}
				fileDiff = this.computedCache.fileDiff;
				actions = this.computedCache.actions;
				markerRows = this.computedCache.markerRows;
				break wrapper;
			} else {
				fileDiff = this.computedCache.fileDiff;
				actions = this.computedCache.actions;
				markerRows = this.computedCache.markerRows;
				break wrapper;
			}
		} else {
			if (fileDiff != null || actions != null || markerRows != null) throw new Error("UnresolvedFile.getOrComputeDiff: fileDiff, actions, and markerRows are only usable in controlled mode, you must pass in `onMergeConflictAction`");
			if (file != null && this.computedCache.file != null && !areFilesEqual(file, this.computedCache.file)) throw new Error("UnresolvedFile.getOrComputeDiff: uncontrolled unresolved files parse the file only once. Later updates must come from the cached diff state.");
			this.computedCache.file ??= file;
			if (this.computedCache.fileDiff == null && this.computedCache.file != null) {
				const computed = parseMergeConflictDiffFromFile(this.computedCache.file, maxContextLines);
				this.computedCache.fileDiff = computed.fileDiff;
				this.computedCache.actions = computed.actions;
				this.computedCache.markerRows = computed.markerRows;
			}
			fileDiff = this.computedCache.fileDiff;
			actions = this.computedCache.actions;
			markerRows = this.computedCache.markerRows;
			break wrapper;
		}
		if (fileDiff == null || actions == null || markerRows == null) return;
		return {
			fileDiff,
			actions,
			markerRows
		};
	}
	hydrate(props) {
		const { file, fileDiff, actions, markerRows, lineAnnotations, fileContainer, prerenderedHTML, preventEmit = false } = props;
		const source = this.getOrComputeDiff({
			file,
			fileDiff,
			actions,
			markerRows
		});
		if (source == null) return;
		this.hydrateElements(fileContainer, prerenderedHTML);
		this.setActiveMergeConflictState(source.actions, source.markerRows);
		if (shouldRenderCode(this.pre, source.fileDiff, this.options.collapsed) || shouldRenderHeader(this.headerElement, source.fileDiff, this.options.disableFileHeader)) this.render({
			...props,
			preventEmit: true
		});
		else {
			this.hydrationSetup({
				fileDiff: source.fileDiff,
				lineAnnotations
			});
			if (this.pre != null) this.renderMergeConflictActionSlots();
		}
		if (!preventEmit) this.emitPostRender();
	}
	rerender() {
		if (!this.enabled || this.fileDiff == null) return;
		this.render({
			forceRender: true,
			renderRange: this.renderRange
		});
	}
	render(props = {}) {
		const { file, fileDiff, actions, markerRows, lineAnnotations, preventEmit = false, ...rest } = props;
		const source = this.getOrComputeDiff({
			file,
			fileDiff,
			actions,
			markerRows
		});
		if (source == null) return false;
		this.setActiveMergeConflictState(source.actions, source.markerRows);
		const didRender = super.render({
			...rest,
			fileDiff: source.fileDiff,
			lineAnnotations,
			preventEmit: true
		});
		if (didRender) {
			this.renderMergeConflictActionSlots();
			if (!preventEmit) this.emitPostRender();
		}
		return didRender;
	}
	resolveConflict(conflictIndex, resolution, fileDiff = this.computedCache.fileDiff) {
		const action = this.conflictActions[conflictIndex];
		if (fileDiff == null || action == null) return;
		if (action.conflictIndex !== conflictIndex) {
			console.error({
				conflictIndex,
				action
			});
			throw new Error("UnresolvedFile.resolveConflict: conflictIndex and conflictAction don't match");
		}
		const newFileDiff = resolveConflict(fileDiff, action, resolution);
		const previousFile = this.computedCache.file;
		const { file, actions, markerRows } = rebuildFileAndActions({
			fileDiff: newFileDiff,
			previousActions: this.conflictActions,
			resolvedConflictIndex: conflictIndex,
			previousFile,
			resolution
		});
		return {
			file,
			fileDiff: newFileDiff,
			actions,
			markerRows
		};
	}
	resolveConflictAndRender(conflictIndex, resolution) {
		const action = this.conflictActions[conflictIndex];
		if (action == null) return;
		if (action.conflictIndex !== conflictIndex) {
			console.error({
				conflictIndex,
				action
			});
			throw new Error("UnresolvedFile.resolveConflictAndRender: conflictIndex and conflictAction don't match");
		}
		const payload = {
			resolution,
			conflict: action.conflict
		};
		const { file, fileDiff, actions, markerRows } = this.resolveConflict(conflictIndex, resolution) ?? {};
		if (file == null || fileDiff == null || actions == null || markerRows == null) return;
		this.computedCache = {
			file,
			fileDiff,
			actions,
			markerRows
		};
		this.setActiveMergeConflictState(actions, markerRows);
		if (this.workerManager != null) this.hunksRenderer.renderDiff(fileDiff);
		else this.render({ forceRender: true });
		this.options.onMergeConflictResolve?.(file, payload);
	}
	setActiveMergeConflictState(actions = this.conflictActions, markerRows = this.markerRows) {
		this.conflictActions = actions;
		this.markerRows = markerRows;
		if (this.computedCache.fileDiff != null && this.hunksRenderer instanceof UnresolvedFileHunksRenderer) this.hunksRenderer.setConflictState(this.options.mergeConflictActionsType === "none" ? [] : actions, markerRows, this.computedCache.fileDiff);
	}
	handleMergeConflictActionClick = (target) => {
		const action = this.conflictActions[target.conflictIndex];
		if (action == null) return;
		if (action.conflictIndex !== target.conflictIndex) {
			console.error({
				conflictIndex: target.conflictIndex,
				action
			});
			throw new Error("UnresolvedFile.handleMergeConflictActionClick: conflictIndex and conflictAction don't match");
		}
		const payload = {
			resolution: target.resolution,
			conflict: action.conflict
		};
		if (this.options.onMergeConflictAction != null) {
			this.options.onMergeConflictAction(payload, this);
			return;
		}
		this.resolveConflictAndRender(target.conflictIndex, target.resolution);
	};
	renderMergeConflictActionSlots() {
		const { fileDiff } = this.computedCache;
		if (this.isContainerManaged || this.fileContainer == null || typeof this.options.mergeConflictActionsType !== "function" || this.conflictActions.length === 0 || fileDiff == null) {
			this.clearMergeConflictActionCache();
			return;
		}
		const staleActions = new Map(this.conflictActionCache);
		for (let actionIndex = 0; actionIndex < this.conflictActions.length; actionIndex++) {
			const action = this.conflictActions[actionIndex];
			if (action == null) continue;
			if (action.conflictIndex !== actionIndex) {
				console.error({
					conflictIndex: actionIndex,
					action
				});
				throw new Error("UnresolvedFile.renderMergeConflictActionSlots: conflictIndex and conflictAction don't match");
			}
			const anchor = getMergeConflictActionAnchor(action, fileDiff);
			if (anchor == null) continue;
			const conflictIndex = action.conflictIndex;
			const slotName = getMergeConflictActionSlotName({
				hunkIndex: anchor.hunkIndex,
				lineIndex: anchor.lineIndex,
				conflictIndex
			});
			const id = `${actionIndex}-${slotName}`;
			let cache = this.conflictActionCache.get(id);
			if (cache == null || !areMergeConflictActionsEqual(cache.action, action)) {
				cache?.element.remove();
				const rendered = this.renderMergeConflictAction(action);
				if (rendered == null) continue;
				const element = createAnnotationWrapperNode(slotName);
				element.appendChild(rendered);
				this.fileContainer.appendChild(element);
				cache = {
					element,
					action
				};
				this.conflictActionCache.set(id, cache);
			}
			staleActions.delete(id);
		}
		for (const [id, { element }] of staleActions.entries()) {
			this.conflictActionCache.delete(id);
			element.remove();
		}
	}
	renderMergeConflictAction(action) {
		if (typeof this.options.mergeConflictActionsType !== "function") return;
		const rendered = this.options.mergeConflictActionsType(action, this);
		if (rendered == null) return;
		if (rendered instanceof HTMLElement) return rendered;
		if (typeof DocumentFragment !== "undefined" && rendered instanceof DocumentFragment) {
			const wrapper = document.createElement("div");
			wrapper.style.display = "contents";
			wrapper.appendChild(rendered);
			return wrapper;
		}
	}
	clearMergeConflictActionCache() {
		for (const { element } of this.conflictActionCache.values()) element.remove();
		this.conflictActionCache.clear();
	}
};
function rebuildFileAndActions({ fileDiff, previousActions, resolvedConflictIndex, previousFile, resolution }) {
	const resolvedAction = previousActions[resolvedConflictIndex];
	if (resolvedAction == null) throw new Error("rebuildFileAndActions: missing resolved action for unresolved file rebuild");
	const actions = updateConflictActionsAfterResolution(previousActions, resolvedConflictIndex, resolvedAction, resolution);
	const markerRows = buildMergeConflictMarkerRows(fileDiff, actions);
	return {
		file: rebuildUnresolvedFile({
			fileDiff,
			resolvedAction,
			resolvedConflictIndex,
			previousFile,
			resolution
		}),
		actions,
		markerRows
	};
}
function rebuildUnresolvedFile({ resolvedAction, resolvedConflictIndex, previousFile, fileDiff, resolution }) {
	const lines = splitFileContents(previousFile?.contents ?? "");
	const { conflict } = resolvedAction;
	const replacementLines = getResolvedConflictReplacementLines(lines, conflict, resolution);
	const contents = [
		...lines.slice(0, conflict.startLineIndex),
		...replacementLines,
		...lines.slice(conflict.endLineIndex + 1)
	].join("");
	return {
		name: previousFile?.name ?? fileDiff.name,
		contents,
		cacheKey: previousFile?.cacheKey != null ? `${previousFile.cacheKey}:mc-${resolvedConflictIndex}-${resolution}` : void 0
	};
}
function getResolvedConflictReplacementLines(lines, conflict, resolution) {
	const currentLines = lines.slice(conflict.startLineIndex + 1, conflict.baseMarkerLineIndex ?? conflict.separatorLineIndex);
	const incomingLines = lines.slice(conflict.separatorLineIndex + 1, conflict.endLineIndex);
	if (resolution === "current") return currentLines;
	if (resolution === "incoming") return incomingLines;
	return [...currentLines, ...incomingLines];
}
function updateConflictActionsAfterResolution(previousActions, resolvedConflictIndex, resolvedAction, resolution) {
	const lineDelta = getResolvedConflictLineDelta(resolvedAction.conflict, resolution);
	return previousActions.map((action, index) => {
		if (index === resolvedConflictIndex) return;
		if (action == null) return;
		if (action.conflict.startLineIndex > resolvedAction.conflict.endLineIndex) return {
			...action,
			conflict: shiftMergeConflictRegion(action.conflict, lineDelta)
		};
		return action;
	});
}
function getResolvedConflictLineDelta(conflict, resolution) {
	const currentLineCount = (conflict.baseMarkerLineIndex ?? conflict.separatorLineIndex) - conflict.startLineIndex - 1;
	const incomingLineCount = conflict.endLineIndex - conflict.separatorLineIndex - 1;
	return (resolution === "current" ? currentLineCount : resolution === "incoming" ? incomingLineCount : currentLineCount + incomingLineCount) - (conflict.endLineIndex - conflict.startLineIndex + 1);
}
function shiftMergeConflictRegion(conflict, lineDelta) {
	return {
		...conflict,
		startLineIndex: conflict.startLineIndex + lineDelta,
		startLineNumber: conflict.startLineNumber + lineDelta,
		separatorLineIndex: conflict.separatorLineIndex + lineDelta,
		separatorLineNumber: conflict.separatorLineNumber + lineDelta,
		endLineIndex: conflict.endLineIndex + lineDelta,
		endLineNumber: conflict.endLineNumber + lineDelta,
		baseMarkerLineIndex: conflict.baseMarkerLineIndex != null ? conflict.baseMarkerLineIndex + lineDelta : void 0,
		baseMarkerLineNumber: conflict.baseMarkerLineNumber != null ? conflict.baseMarkerLineNumber + lineDelta : void 0
	};
}
function shouldRenderCode(pre, fileDiff, collapsed = false) {
	return !collapsed && pre == null && fileDiff != null;
}
function shouldRenderHeader(headerElement, fileDiff, disableFileHeader = false) {
	return headerElement == null && fileDiff != null && !disableFileHeader;
}
function getUnresolvedDiffHunksRendererOptions(options, baseOptions) {
	const merged = {
		...baseOptions,
		...options
	};
	return {
		...merged,
		useTokenTransformer: shouldUseTokenTransformer(merged),
		hunkSeparators: typeof options?.hunkSeparators === "function" ? "custom" : options?.hunkSeparators,
		mergeConflictActionsType: typeof options?.mergeConflictActionsType === "function" ? "custom" : options?.mergeConflictActionsType
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areVirtualWindowSpecsEqual.js
function areVirtualWindowSpecsEqual(windowSpecsA, windowSpecsB) {
	if (windowSpecsA == null || windowSpecsB == null) return windowSpecsA === windowSpecsB;
	return windowSpecsA.top === windowSpecsB.top && windowSpecsA.bottom === windowSpecsB.bottom;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/Virtualizer.js
var DEFAULT_OVERSCROLL_SIZE = 1e3;
var INTERSECTION_OBSERVER_MARGIN = DEFAULT_OVERSCROLL_SIZE * 4;
var INTERSECTION_OBSERVER_THRESHOLD = [
	0,
	1e-6,
	.99999,
	1
];
var DEFAULT_VIRTUALIZER_CONFIG = {
	overscrollSize: DEFAULT_OVERSCROLL_SIZE,
	intersectionObserverMargin: INTERSECTION_OBSERVER_MARGIN,
	resizeDebugging: false
};
var lastSize = 0;
var instance = -1;
var Virtualizer = class Virtualizer {
	static __STOP = false;
	static __lastScrollPosition = 0;
	__id = `virtualizer-${++instance}`;
	config;
	type = "simple";
	intersectionObserver;
	scrollTop = 0;
	height = 0;
	scrollHeight = 0;
	windowSpecs = {
		top: 0,
		bottom: 0
	};
	root;
	contentContainer;
	resizeObserver;
	observers = /* @__PURE__ */ new Map();
	visibleInstances = /* @__PURE__ */ new Map();
	visibleInstancesDirty = false;
	instancesChanged = /* @__PURE__ */ new Set();
	reconcileQueue = /* @__PURE__ */ new Set();
	scrollDirty = true;
	heightDirty = true;
	scrollHeightDirty = true;
	renderedObservers = 0;
	connectQueue = /* @__PURE__ */ new Map();
	constructor(config) {
		this.config = {
			...DEFAULT_VIRTUALIZER_CONFIG,
			...config
		};
	}
	setup(root, contentContainer) {
		if (this.root != null) return;
		this.root = root;
		this.resizeObserver = new ResizeObserver(this.handleContainerResize);
		this.intersectionObserver = new IntersectionObserver(this.handleIntersectionChange, {
			root: this.root,
			threshold: INTERSECTION_OBSERVER_THRESHOLD,
			rootMargin: `${this.config.intersectionObserverMargin}px 0px ${this.config.intersectionObserverMargin}px 0px`
		});
		if (root instanceof Document) this.setupWindow();
		else this.setupElement(contentContainer);
		window.__INSTANCE = this;
		window.__TOGGLE = () => {
			if (Virtualizer.__STOP) {
				Virtualizer.__STOP = false;
				(this.getScrollContainerElement() ?? window).scrollTo({ top: Virtualizer.__lastScrollPosition });
				queueRender(this.computeRenderRangeAndEmit);
			} else {
				Virtualizer.__lastScrollPosition = this.getScrollTop();
				Virtualizer.__STOP = true;
			}
		};
		for (const [container, instance] of this.connectQueue.entries()) this.connect(container, instance);
		this.connectQueue.clear();
		this.markDOMDirty();
		queueRender(this.computeRenderRangeAndEmit);
	}
	instanceChanged(instance, domDirty) {
		this.instancesChanged.add(instance);
		if (domDirty) this.markDOMDirty();
		queueRender(this.computeRenderRangeAndEmit);
	}
	requestHeightReconcile(instance) {
		this.reconcileQueue.add(instance);
		queueRender(this.computeRenderRangeAndEmit);
	}
	getWindowSpecs() {
		if (this.windowSpecs.top === 0 && this.windowSpecs.bottom === 0) this.windowSpecs = createWindowFromScrollPosition({
			scrollTop: this.getScrollTop(),
			height: this.getHeight(),
			scrollHeight: this.getScrollHeight(),
			overscrollSize: this.config.overscrollSize
		});
		return this.windowSpecs;
	}
	getRoot() {
		return this.root;
	}
	isInstanceVisible(elementTop, elementHeight) {
		const scrollTop = this.getScrollTop();
		const height = this.getHeight();
		const margin = this.config.intersectionObserverMargin;
		const top = scrollTop - margin;
		const bottom = scrollTop + height + margin;
		return !(elementTop < top - elementHeight || elementTop > bottom);
	}
	handleContainerResize = (entries) => {
		if (this.root == null) return;
		let shouldQueueUpdate = false;
		for (const entry of entries) {
			const blockSize = entry.borderBoxSize[0].blockSize;
			if (this.root instanceof Document) {
				if (blockSize !== this.scrollHeight) {
					this.scrollHeightDirty = true;
					shouldQueueUpdate = true;
					if (this.config.resizeDebugging) {
						console.log("Virtualizer: content size change", this.__id, {
							sizeChange: blockSize - lastSize,
							newSize: blockSize
						});
						lastSize = blockSize;
					}
				}
			} else if (entry.target === this.root) {
				if (blockSize !== this.height) {
					this.heightDirty = true;
					shouldQueueUpdate = true;
				}
			} else if (entry.target === this.contentContainer) {
				this.scrollHeightDirty = true;
				shouldQueueUpdate = true;
				if (this.config.resizeDebugging) {
					console.log("Virtualizer: scroller size change", this.__id, {
						sizeChange: blockSize - lastSize,
						newSize: blockSize
					});
					lastSize = blockSize;
				}
			}
		}
		if (shouldQueueUpdate) queueRender(this.computeRenderRangeAndEmit);
	};
	setupWindow() {
		if (this.root == null || !(this.root instanceof Document)) throw new Error("Virtualizer.setupWindow: Invalid setup method");
		window.addEventListener("scroll", this.handleWindowScroll, { passive: true });
		window.addEventListener("resize", this.handleWindowResize, { passive: true });
		this.resizeObserver?.observe(this.root.documentElement);
	}
	setupElement(contentContainer) {
		if (this.root == null || this.root instanceof Document) throw new Error("Virtualizer.setupElement: Invalid setup method");
		this.root.addEventListener("scroll", this.handleElementScroll, { passive: true });
		this.resizeObserver?.observe(this.root);
		contentContainer ??= this.root.firstElementChild ?? void 0;
		if (contentContainer instanceof HTMLElement) {
			this.contentContainer = contentContainer;
			this.resizeObserver?.observe(contentContainer);
		}
	}
	cleanUp() {
		dequeueRender(this.computeRenderRangeAndEmit);
		this.resizeObserver?.disconnect();
		this.resizeObserver = void 0;
		this.intersectionObserver?.disconnect();
		this.intersectionObserver = void 0;
		this.root?.removeEventListener("scroll", this.handleElementScroll);
		window.removeEventListener("scroll", this.handleWindowScroll);
		window.removeEventListener("resize", this.handleWindowResize);
		this.root = void 0;
		this.contentContainer = void 0;
		this.observers.clear();
		this.visibleInstances.clear();
		this.instancesChanged.clear();
		this.reconcileQueue.clear();
		this.connectQueue.clear();
		this.visibleInstancesDirty = false;
		this.windowSpecs = {
			top: 0,
			bottom: 0
		};
		this.scrollTop = 0;
		this.height = 0;
		this.scrollHeight = 0;
		this.scrollDirty = true;
		this.heightDirty = true;
		this.scrollHeightDirty = true;
	}
	getOffsetInScrollContainer(element) {
		return this.getScrollTop() + getRelativeBoundingTop(element, this.getScrollContainerElement());
	}
	connect(container, instance) {
		if (this.observers.has(container)) throw new Error("Virtualizer.connect: instance is already connected...");
		if (this.intersectionObserver == null) this.connectQueue.set(container, instance);
		else {
			this.intersectionObserver.observe(container);
			this.observers.set(container, instance);
			this.instancesChanged.add(instance);
			this.markDOMDirty();
			queueRender(this.computeRenderRangeAndEmit);
		}
		return () => this.disconnect(container);
	}
	disconnect(container) {
		const instance = this.observers.get(container);
		this.connectQueue.delete(container);
		if (instance == null) return;
		this.intersectionObserver?.unobserve(container);
		this.observers.delete(container);
		this.instancesChanged.delete(instance);
		this.reconcileQueue.delete(instance);
		if (this.visibleInstances.delete(container)) this.visibleInstancesDirty = true;
		this.markDOMDirty();
		queueRender(this.computeRenderRangeAndEmit);
	}
	handleWindowResize = () => {
		if (Virtualizer.__STOP || window.innerHeight === this.height) return;
		this.heightDirty = true;
		queueRender(this.computeRenderRangeAndEmit);
	};
	handleWindowScroll = () => {
		if (Virtualizer.__STOP || this.root == null || !(this.root instanceof Document)) return;
		this.scrollDirty = true;
		queueRender(this.computeRenderRangeAndEmit);
	};
	handleElementScroll = () => {
		if (Virtualizer.__STOP || this.root == null || this.root instanceof Document) return;
		this.scrollDirty = true;
		queueRender(this.computeRenderRangeAndEmit);
	};
	computeRenderRangeAndEmit = () => {
		if (Virtualizer.__STOP) return;
		const wrapperDirty = this.heightDirty || this.scrollHeightDirty;
		let instancesHaveChanged = this.instancesChanged.size > 0;
		if (this.instancesChanged.size === 0) {
			const windowSpecs = createWindowFromScrollPosition({
				scrollTop: this.getScrollTop(),
				height: this.getHeight(),
				scrollHeight: this.getScrollHeight(),
				overscrollSize: this.config.overscrollSize
			});
			if (!wrapperDirty && areVirtualWindowSpecsEqual(this.windowSpecs, windowSpecs) && this.renderedObservers === this.observers.size && !this.visibleInstancesDirty && this.reconcileQueue.size === 0) return;
			this.windowSpecs = windowSpecs;
		}
		this.visibleInstancesDirty = false;
		this.renderedObservers = this.observers.size;
		const anchor = this.getScrollAnchor(this.height);
		const updatedInstances = /* @__PURE__ */ new Set();
		for (const instance of wrapperDirty ? this.observers.values() : this.visibleInstances.values()) if (instance.onRender(wrapperDirty)) updatedInstances.add(instance);
		for (const instance of this.instancesChanged) {
			if (updatedInstances.has(instance)) continue;
			if (instance.onRender(wrapperDirty)) updatedInstances.add(instance);
		}
		this.scrollFix(anchor);
		for (const instance of updatedInstances) {
			this.reconcileQueue.delete(instance);
			instance.reconcileHeights();
		}
		for (const instance of this.reconcileQueue) if (instance.reconcileHeights()) instancesHaveChanged = true;
		this.reconcileQueue.clear();
		instancesHaveChanged ||= this.instancesChanged.size > 0;
		if (instancesHaveChanged) this.markDOMDirty();
		if (instancesHaveChanged || wrapperDirty) queueRender(this.computeRenderRangeAndEmit);
		updatedInstances.clear();
		this.instancesChanged.clear();
	};
	scrollFix(anchor) {
		if (anchor == null) return;
		const scrollContainer = this.getScrollContainerElement();
		const { lineIndex, lineOffset, fileElement, fileOffset, fileTypeOffset } = anchor;
		if (lineIndex != null && lineOffset != null) {
			const element = fileElement.shadowRoot?.querySelector(`[data-line][data-line-index="${lineIndex}"]`);
			if (element instanceof HTMLElement) {
				const top = getRelativeBoundingTop(element, scrollContainer);
				if (top !== lineOffset) {
					const scrollOffset = top - lineOffset;
					this.applyScrollFix(scrollOffset);
				}
				return;
			}
		}
		const top = getRelativeBoundingTop(fileElement, scrollContainer);
		if (fileTypeOffset === "top") {
			if (top !== fileOffset) this.applyScrollFix(top - fileOffset);
		} else {
			const bottom = top + fileElement.getBoundingClientRect().height;
			if (bottom !== fileOffset) this.applyScrollFix(bottom - fileOffset);
		}
	}
	applyScrollFix(scrollOffset) {
		if (this.root == null || this.root instanceof Document) window.scrollTo({
			top: window.scrollY + scrollOffset,
			behavior: "instant"
		});
		else this.root.scrollTo({
			top: this.root.scrollTop + scrollOffset,
			behavior: "instant"
		});
		this.markDOMDirty();
	}
	getScrollAnchor(viewportHeight) {
		const scrollContainer = this.getScrollContainerElement();
		let bestAnchor;
		for (const [fileElement] of this.visibleInstances.entries()) {
			const fileTop = getRelativeBoundingTop(fileElement, scrollContainer);
			const fileBottom = fileTop + fileElement.offsetHeight;
			let fileOffset;
			let fileTypeOffset;
			if (fileBottom <= 0) {
				fileOffset = fileBottom;
				fileTypeOffset = "bottom";
			} else {
				fileOffset = fileTop;
				fileTypeOffset = "top";
			}
			let bestLineIndex;
			let bestLineOffset;
			if (fileBottom > 0 && fileTop < viewportHeight) for (const line of fileElement.shadowRoot?.querySelectorAll("[data-line][data-line-index]") ?? []) {
				if (!(line instanceof HTMLElement)) continue;
				const lineIndex = line.dataset.lineIndex;
				if (lineIndex == null) continue;
				const lineOffset = getRelativeBoundingTop(line, scrollContainer);
				if (lineOffset < 0) continue;
				bestLineIndex = lineIndex;
				bestLineOffset = lineOffset;
				break;
			}
			if (bestAnchor?.lineOffset != null && bestLineOffset == null) continue;
			let shouldReplace = false;
			if (bestAnchor == null) shouldReplace = true;
			else if (bestLineOffset != null && (bestAnchor.lineOffset == null || bestLineOffset < bestAnchor.lineOffset)) shouldReplace = true;
			else if (bestLineOffset == null && bestAnchor.lineOffset == null) {
				if (fileOffset >= 0 && (bestAnchor.fileOffset < 0 || fileOffset < bestAnchor.fileOffset)) shouldReplace = true;
				else if (fileOffset < 0 && bestAnchor.fileOffset < 0 && fileOffset > bestAnchor.fileOffset) shouldReplace = true;
			}
			if (shouldReplace) bestAnchor = {
				fileElement,
				fileTypeOffset,
				fileOffset,
				lineIndex: bestLineIndex,
				lineOffset: bestLineOffset
			};
		}
		return bestAnchor;
	}
	handleIntersectionChange = (entries) => {
		this.scrollDirty = true;
		for (const { target, isIntersecting } of entries) {
			if (!(target instanceof HTMLElement)) throw new Error("Virtualizer.handleIntersectionChange: target not an HTMLElement");
			const instance = this.observers.get(target);
			if (instance == null) continue;
			if (isIntersecting && !this.visibleInstances.has(target)) {
				instance.setVisibility(true);
				this.visibleInstances.set(target, instance);
				this.visibleInstancesDirty = true;
			} else if (!isIntersecting && this.visibleInstances.has(target)) {
				instance.setVisibility(false);
				this.visibleInstances.delete(target);
				this.visibleInstancesDirty = true;
			}
		}
		if (this.visibleInstancesDirty) queueRender(this.computeRenderRangeAndEmit);
	};
	/** Return the logical vertical position for the scroll container */
	getScrollTop() {
		if (!this.scrollDirty) return this.scrollTop;
		this.scrollDirty = false;
		let scrollTop = (() => {
			if (this.root == null) return 0;
			if (this.root instanceof Document) return window.scrollY;
			return this.root.scrollTop;
		})();
		scrollTop = this.clampScrollTop(scrollTop);
		this.scrollTop = scrollTop;
		return scrollTop;
	}
	/** Scroll to a logical vertical position and queue the normal render pass. */
	scrollTo({ top, behavior = "auto" }) {
		const { root } = this;
		if (root == null) return;
		const scrollTop = this.clampScrollTop(top);
		if (root instanceof Document) window.scrollTo({
			top: scrollTop,
			behavior
		});
		else root.scrollTo({
			top: scrollTop,
			behavior
		});
		this.scrollDirty = true;
		queueRender(this.computeRenderRangeAndEmit);
	}
	clampScrollTop(scrollTop) {
		return Math.max(0, Math.min(scrollTop, this.getScrollHeight() - this.getHeight()));
	}
	getScrollHeight() {
		if (!this.scrollHeightDirty) return this.scrollHeight;
		this.scrollHeightDirty = false;
		this.scrollHeight = (() => {
			if (this.root == null) return 0;
			if (this.root instanceof Document) return this.root.documentElement.scrollHeight;
			return this.root.scrollHeight;
		})();
		return this.scrollHeight;
	}
	getHeight() {
		if (!this.heightDirty) return this.height;
		this.heightDirty = false;
		this.height = (() => {
			if (this.root == null) return 0;
			if (this.root instanceof Document) return globalThis.innerHeight;
			return this.root.getBoundingClientRect().height;
		})();
		return this.height;
	}
	markDOMDirty() {
		this.scrollDirty = true;
		this.scrollHeightDirty = true;
		this.heightDirty = true;
	}
	getScrollContainerElement() {
		return this.root == null || this.root instanceof Document ? void 0 : this.root;
	}
};
function getRelativeBoundingTop(element, scrollContainer) {
	const rect = element.getBoundingClientRect();
	const scrollContainerTop = scrollContainer?.getBoundingClientRect().top ?? 0;
	return rect.top - scrollContainerTop;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/getResolvedLanguages.js
function getResolvedLanguages(languages) {
	const resolvedLanguages = [];
	for (const language of languages) {
		const resolvedLanguage = ResolvedLanguages.get(language);
		if (resolvedLanguage == null) throw new Error(`getResolvedLanguages: ${language} is not resolved. Please resolve languages before calling getResolvedLanguages`);
		resolvedLanguages.push(resolvedLanguage);
	}
	return resolvedLanguages;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/hasResolvedLanguages.js
function hasResolvedLanguages(languages) {
	for (const language of Array.isArray(languages) ? languages : [languages]) if (!ResolvedLanguages.has(language)) return false;
	return true;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/resolveLanguages.js
async function resolveLanguages(languages) {
	const resolvedLanguages = [];
	const languagesToResolve = [];
	for (const language of languages) {
		if (language === "text" || language === "ansi") continue;
		const maybeResolvedLanguage = getResolvedOrResolveLanguage(language) ?? resolveLanguage(language);
		if ("then" in maybeResolvedLanguage) languagesToResolve.push(maybeResolvedLanguage);
		else resolvedLanguages.push(maybeResolvedLanguage);
	}
	if (languagesToResolve.length > 0) await Promise.all(languagesToResolve).then((_resolvedLanguages) => {
		for (const resolvedLanguage of _resolvedLanguages) {
			if (resolvedLanguage == null) throw new Error("resolvedLanguages: unable to resolve language");
			resolvedLanguages.push(resolvedLanguage);
		}
	});
	return resolvedLanguages;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/getResolvedThemes.js
function getResolvedThemes(themeNames) {
	return themeResolver.getResolvedThemes(themeNames);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/resolveThemes.js
async function resolveThemes(themes) {
	for (const themeName of themes) prepareThemeResolution(themeName);
	const resolvedThemes = await themeResolver.resolveThemes(themes);
	for (let i = 0; i < themes.length; i++) validateResolvedThemeName(themes[i], resolvedThemes[i]);
	return resolvedThemes;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getSingularPatch.js
function getSingularPatch(patch) {
	const parsedPatches = parsePatchFiles(patch);
	if (parsedPatches.length !== 1) {
		console.error(parsedPatches);
		throw new Error("PatchDiff: Provided patch must include only 1 patch, with 1 diff");
	}
	const { files } = parsedPatches[0];
	if (files.length !== 1) {
		console.error(files);
		throw new Error("FileDiff: Provided patch must contain exactly 1 file diff");
	}
	return files[0];
}
//#endregion
export { createUnsafeCSSStyleNode as $, createGutterGap as $t, pushOrJoinSpan as A, preloadHighlighter as At, cloneFileDiffMetadata as B, codeToHtml as Bt, FileDiff as C, getThemes as Ct, isDiffPlainText as D, isHighlighterLoaded as Dt, DiffHunksRenderer as E, getSharedHighlighter as Et, createNoNewlineElement as F, attachResolvedThemes as Ft, setPreNodeProperties as G, AttachedLanguages as Gt, VirtualizedFile as H, cleanUpResolvedLanguages as Ht, createEmptyRowBuffer as I, themeResolver as It, patchScrollbarGutterSize as J, ResolvingLanguages as Jt, prerenderHTMLIfNecessary as K, RegisteredCustomLanguages as Kt, areDiffRenderOptionsEqual as L, AttachedThemes as Lt, getTotalLineCountFromHunks as M, resolveTheme as Mt, getHunkSeparatorSlotName as N, createTheme as Nt, renderDiffWithHighlighter as O, isHighlighterLoading as Ot, createSeparator as P, cleanUpResolvedThemes as Pt, getMeasuredScrollbarGutter as Q, createGutterUtilityElement as Qt, ScrollSyncManager as R, getResolvedOrResolveLanguage as Rt, VirtualizedFileDiff as S, areThemesAttached as St, areDiffLineAnnotationsEqual as T, getHighlighterIfLoaded as Tt, File as U, attachResolvedLanguages as Ut, areDiffTargetsEqual as V, isWorkerContext as Vt, upsertHostThemeStyle as W, areLanguagesAttached as Wt, wrapThemeCSS as X, InteractionManager as Xt, wrapCoreCSS as Y, ResizeManager as Yt, wrapUnsafeCSS as Z, pluckInteractionOptions as Zt, CODE_VIEW_DIFF_OPTION_KEYS as _, areOptionsEqual as _n, getIconForType as _t, hasResolvedLanguages as a, findCodeElement as an, FileRenderer as at, areManagedSnapshotsEqual as b, areFileRenderOptionsEqual as bt, areVirtualWindowSpecsEqual as c, parseDiffFromFile as cn, getLineNodes as ct, getMergeConflictActionAnchor as d, processPatch as dn, createTransformerWithState as dt, createGutterItem as en, createGutterUtilityContentNode as et, parseMergeConflictDiffFromFile as f, detachString as fn, processLine$1 as ft, resolveRegion as g, areSelectionsEqual as gn, createFileHeaderElement as gt, normalizeDiffResolution as h, createWindowFromScrollPosition as hn, createPreWrapperProperties as ht, resolveLanguages as i, createTextNodeElement as in, SVGSpriteSheet as it, isDefaultRenderRange as j, getResolvedOrResolveTheme as jt, createDiffSpanDecoration as k, isHighlighterNull as kt, UnresolvedFile as l, parsePatchFiles as ln, getHighlighterThemeStyles as lt, resolveConflict as m, cleanLastNewline as mn, createPreElement as mt, resolveThemes as n, createHastElement as nn, arePrePropertiesEqual as nt, getResolvedLanguages as o, areFilesEqual as on, isFilePlainText as ot, getMergeConflictActionSlotName as p, releaseStringDetachBuffer as pn, getHighlighterOptions as pt, getOrCreateCodeNode as q, ResolvedLanguages as qt, getResolvedThemes as r, createIconElement as rn, areLineAnnotationsEqual as rt, Virtualizer as s, prefersReducedMotion as sn, renderFileWithHighlighter as st, getSingularPatch as t, createGutterWrapper as tn, createAnnotationWrapperNode as tt, getUnresolvedDiffHunksRendererOptions as u, processFile as un, formatCSSVariablePrefix as ut, CODE_VIEW_FILE_OPTION_KEYS as v, areThemesEqual as vn, createAnnotationElement as vt, areHunkDataEqual as w, disposeHighlighter as wt, VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL as x, hasResolvedThemes as xt, CodeView as y, areObjectsEqual as yn, areRenderRangesEqual as yt, hydratePartialDiff as z, resolveLanguage as zt };
