import { $create, $createNodeSelection, $createParagraphNode, $createRangeSelection, $getNodeByKey, $getNodeFromDOMNode, $getRoot, $getSelection, $getState, $isBlockElementNode, $isEditorState, $isNodeSelection, $isRangeSelection, $normalizeSelection__EXPERIMENTAL as $normalizeSelection, $setSelection, $setState, CLEAR_EDITOR_COMMAND, CLICK_COMMAND, DecoratorNode, FORMAT_TEXT_COMMAND, HISTORY_MERGE_TAG, INDENT_CONTENT_COMMAND, INSERT_TAB_COMMAND, KEY_TAB_COMMAND, LineBreakNode, OUTDENT_CONTENT_COMMAND, ParagraphNode, RootNode, TEXT_TYPE_TO_FORMAT, TabNode, TextNode, addClassNamesToElement, createCommand, createEditor, createState, defineExtension, isDOMNode, mergeRegister, removeClassNamesFromElement, safeCast, shallowMergeConfig, toggleTextFormatType } from "./lexical.js";
import { n as $handleIndentAndOutdent, t as $getNearestBlockElementAncestorOrThrow } from "./LexicalUtils.dev-3NAN296g.js";
//#region node_modules/.bun/@lexical+extension@0.41.0/node_modules/@lexical/extension/LexicalExtension.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var i = Symbol.for("preact-signals");
function t() {
	if (r > 1) {
		r--;
		return;
	}
	let i, t = false;
	while (void 0 !== s) {
		let o = s;
		s = void 0;
		f++;
		while (void 0 !== o) {
			const n = o.o;
			o.o = void 0;
			o.f &= -3;
			if (!(8 & o.f) && v(o)) try {
				o.c();
			} catch (o) {
				if (!t) {
					i = o;
					t = true;
				}
			}
			o = n;
		}
	}
	f = 0;
	r--;
	if (t) throw i;
}
function o(i) {
	if (r > 0) return i();
	r++;
	try {
		return i();
	} finally {
		t();
	}
}
var n;
var s;
function h(i) {
	const t = n;
	n = void 0;
	try {
		return i();
	} finally {
		n = t;
	}
}
var r = 0;
var f = 0;
var e = 0;
function u(i) {
	if (void 0 === n) return;
	let t = i.n;
	if (void 0 === t || t.t !== n) {
		t = {
			i: 0,
			S: i,
			p: n.s,
			n: void 0,
			t: n,
			e: void 0,
			x: void 0,
			r: t
		};
		if (void 0 !== n.s) n.s.n = t;
		n.s = t;
		i.n = t;
		if (32 & n.f) i.S(t);
		return t;
	} else if (-1 === t.i) {
		t.i = 0;
		if (void 0 !== t.n) {
			t.n.p = t.p;
			if (void 0 !== t.p) t.p.n = t.n;
			t.p = n.s;
			t.n = void 0;
			n.s.n = t;
			n.s = t;
		}
		return t;
	}
}
function c(i, t) {
	this.v = i;
	this.i = 0;
	this.n = void 0;
	this.t = void 0;
	this.W = null == t ? void 0 : t.watched;
	this.Z = null == t ? void 0 : t.unwatched;
	this.name = null == t ? void 0 : t.name;
}
c.prototype.brand = i;
c.prototype.h = function() {
	return true;
};
c.prototype.S = function(i) {
	const t = this.t;
	if (t !== i && void 0 === i.e) {
		i.x = t;
		this.t = i;
		if (void 0 !== t) t.e = i;
		else h(() => {
			var i;
			null == (i = this.W) || i.call(this);
		});
	}
};
c.prototype.U = function(i) {
	if (void 0 !== this.t) {
		const t = i.e, o = i.x;
		if (void 0 !== t) {
			t.x = o;
			i.e = void 0;
		}
		if (void 0 !== o) {
			o.e = t;
			i.x = void 0;
		}
		if (i === this.t) {
			this.t = o;
			if (void 0 === o) h(() => {
				var i;
				null == (i = this.Z) || i.call(this);
			});
		}
	}
};
c.prototype.subscribe = function(i) {
	return E(() => {
		const t = this.value, o = n;
		n = void 0;
		try {
			i(t);
		} finally {
			n = o;
		}
	}, { name: "sub" });
};
c.prototype.valueOf = function() {
	return this.value;
};
c.prototype.toString = function() {
	return this.value + "";
};
c.prototype.toJSON = function() {
	return this.value;
};
c.prototype.peek = function() {
	const i = n;
	n = void 0;
	try {
		return this.value;
	} finally {
		n = i;
	}
};
Object.defineProperty(c.prototype, "value", {
	get() {
		const i = u(this);
		if (void 0 !== i) i.i = this.i;
		return this.v;
	},
	set(i) {
		if (i !== this.v) {
			if (f > 100) throw new Error("Cycle detected");
			this.v = i;
			this.i++;
			e++;
			r++;
			try {
				for (let i = this.t; void 0 !== i; i = i.x) i.t.N();
			} finally {
				t();
			}
		}
	}
});
function d(i, t) {
	return new c(i, t);
}
function v(i) {
	for (let t = i.s; void 0 !== t; t = t.n) if (t.S.i !== t.i || !t.S.h() || t.S.i !== t.i) return true;
	return false;
}
function l(i) {
	for (let t = i.s; void 0 !== t; t = t.n) {
		const o = t.S.n;
		if (void 0 !== o) t.r = o;
		t.S.n = t;
		t.i = -1;
		if (void 0 === t.n) {
			i.s = t;
			break;
		}
	}
}
function y(i) {
	let t, o = i.s;
	while (void 0 !== o) {
		const i = o.p;
		if (-1 === o.i) {
			o.S.U(o);
			if (void 0 !== i) i.n = o.n;
			if (void 0 !== o.n) o.n.p = i;
		} else t = o;
		o.S.n = o.r;
		if (void 0 !== o.r) o.r = void 0;
		o = i;
	}
	i.s = t;
}
function a(i, t) {
	c.call(this, void 0);
	this.x = i;
	this.s = void 0;
	this.g = e - 1;
	this.f = 4;
	this.W = null == t ? void 0 : t.watched;
	this.Z = null == t ? void 0 : t.unwatched;
	this.name = null == t ? void 0 : t.name;
}
a.prototype = new c();
a.prototype.h = function() {
	this.f &= -3;
	if (1 & this.f) return false;
	if (32 == (36 & this.f)) return true;
	this.f &= -5;
	if (this.g === e) return true;
	this.g = e;
	this.f |= 1;
	if (this.i > 0 && !v(this)) {
		this.f &= -2;
		return true;
	}
	const i = n;
	try {
		l(this);
		n = this;
		const i = this.x();
		if (16 & this.f || this.v !== i || 0 === this.i) {
			this.v = i;
			this.f &= -17;
			this.i++;
		}
	} catch (i) {
		this.v = i;
		this.f |= 16;
		this.i++;
	}
	n = i;
	y(this);
	this.f &= -2;
	return true;
};
a.prototype.S = function(i) {
	if (void 0 === this.t) {
		this.f |= 36;
		for (let i = this.s; void 0 !== i; i = i.n) i.S.S(i);
	}
	c.prototype.S.call(this, i);
};
a.prototype.U = function(i) {
	if (void 0 !== this.t) {
		c.prototype.U.call(this, i);
		if (void 0 === this.t) {
			this.f &= -33;
			for (let i = this.s; void 0 !== i; i = i.n) i.S.U(i);
		}
	}
};
a.prototype.N = function() {
	if (!(2 & this.f)) {
		this.f |= 6;
		for (let i = this.t; void 0 !== i; i = i.x) i.t.N();
	}
};
Object.defineProperty(a.prototype, "value", { get() {
	if (1 & this.f) throw new Error("Cycle detected");
	const i = u(this);
	this.h();
	if (void 0 !== i) i.i = this.i;
	if (16 & this.f) throw this.v;
	return this.v;
} });
function w(i, t) {
	return new a(i, t);
}
function _(i) {
	const o = i.u;
	i.u = void 0;
	if ("function" == typeof o) {
		r++;
		const s = n;
		n = void 0;
		try {
			o();
		} catch (t) {
			i.f &= -2;
			i.f |= 8;
			b(i);
			throw t;
		} finally {
			n = s;
			t();
		}
	}
}
function b(i) {
	for (let t = i.s; void 0 !== t; t = t.n) t.S.U(t);
	i.x = void 0;
	i.s = void 0;
	_(i);
}
function g(i) {
	if (n !== this) throw new Error("Out-of-order effect");
	y(this);
	n = i;
	this.f &= -2;
	if (8 & this.f) b(this);
	t();
}
function p(i, t) {
	this.x = i;
	this.u = void 0;
	this.s = void 0;
	this.o = void 0;
	this.f = 32;
	this.name = null == t ? void 0 : t.name;
}
p.prototype.c = function() {
	const i = this.S();
	try {
		if (8 & this.f) return;
		if (void 0 === this.x) return;
		const t = this.x();
		if ("function" == typeof t) this.u = t;
	} finally {
		i();
	}
};
p.prototype.S = function() {
	if (1 & this.f) throw new Error("Cycle detected");
	this.f |= 1;
	this.f &= -9;
	_(this);
	l(this);
	r++;
	const i = n;
	n = this;
	return g.bind(this, i);
};
p.prototype.N = function() {
	if (!(2 & this.f)) {
		this.f |= 2;
		this.o = s;
		s = this;
	}
};
p.prototype.d = function() {
	this.f |= 8;
	if (!(1 & this.f)) b(this);
};
p.prototype.dispose = function() {
	this.d();
};
function E(i, t) {
	const o = new p(i, t);
	try {
		o.c();
	} catch (i) {
		o.d();
		throw i;
	}
	const n = o.d.bind(o);
	n[Symbol.dispose] = n;
	return n;
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* @experimental
* Return an object with the same shape as `defaults` with a {@link Signal}
* for each value. If specified, the second `opts` argument is a partial
* of overrides to the defaults and will be used as the initial value.
*
* Typically used to make a reactive version of some subset of the
* configuration of an extension, so it can be reconfigured at runtime.
*
* @param defaults The object with default values
* @param opts Overrides to those default values
* @returns An object with signals initialized with the default values
*/
function namedSignals(defaults, opts = {}) {
	const initial = {};
	for (const k in defaults) {
		const v = opts[k];
		initial[k] = d(v === void 0 ? defaults[k] : v);
	}
	return initial;
}
defineExtension({
	build: (editor, config, state) => {
		return namedSignals(config);
	},
	config: safeCast({
		defaultSelection: "rootEnd",
		disabled: false
	}),
	name: "@lexical/extension/AutoFocus",
	register(editor, config, state) {
		const stores = state.getOutput();
		return E(() => stores.disabled.value ? void 0 : editor.registerRootListener((rootElement) => {
			editor.focus(() => {
				const activeElement = document.activeElement;
				if (rootElement !== null && (activeElement === null || !rootElement.contains(activeElement))) rootElement.focus({ preventScroll: true });
			}, { defaultSelection: stores.defaultSelection.peek() });
		}));
	}
});
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function $defaultOnClear() {
	const root = $getRoot();
	const selection = $getSelection();
	const paragraph = $createParagraphNode();
	root.clear();
	root.append(paragraph);
	if (selection !== null) paragraph.select();
	if ($isRangeSelection(selection)) selection.format = 0;
}
function registerClearEditor(editor, $onClear = $defaultOnClear) {
	return editor.registerCommand(CLEAR_EDITOR_COMMAND, (payload) => {
		editor.update($onClear);
		return true;
	}, 0);
}
defineExtension({
	build(editor, config, state) {
		return namedSignals(config);
	},
	config: safeCast({ $onClear: $defaultOnClear }),
	name: "@lexical/extension/ClearEditor",
	register(editor, config, state) {
		const { $onClear } = state.getOutput();
		return E(() => registerClearEditor(editor, $onClear.value));
	}
});
function getNodeConfig(config) {
	return (typeof config.nodes === "function" ? config.nodes() : config.nodes) || [];
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var formatState = createState("format", { parse: (value) => typeof value === "number" ? value : 0 });
var DecoratorTextNode = class extends DecoratorNode {
	$config() {
		return this.config("decorator-text", {
			extends: DecoratorNode,
			stateConfigs: [{
				flat: true,
				stateConfig: formatState
			}]
		});
	}
	getFormat() {
		return $getState(this, formatState);
	}
	getFormatFlags(type, alignWithFormat) {
		return toggleTextFormatType(this.getFormat(), type, alignWithFormat);
	}
	hasFormat(type) {
		const formatFlag = TEXT_TYPE_TO_FORMAT[type];
		return (this.getFormat() & formatFlag) !== 0;
	}
	setFormat(type) {
		return $setState(this, formatState, type);
	}
	toggleFormat(type) {
		const newFormat = toggleTextFormatType(this.getFormat(), type, null);
		return this.setFormat(newFormat);
	}
	isInline() {
		return true;
	}
	createDOM() {
		return document.createElement("span");
	}
	updateDOM() {
		return false;
	}
};
function $isDecoratorTextNode(node) {
	return node instanceof DecoratorTextNode;
}
defineExtension({
	name: "@lexical/extension/DecoratorText",
	nodes: () => [DecoratorTextNode],
	register(editor, config, state) {
		return editor.registerCommand(FORMAT_TEXT_COMMAND, (formatType) => {
			const selection = $getSelection();
			if ($isNodeSelection(selection) || $isRangeSelection(selection)) {
				for (const node of selection.getNodes()) if ($isDecoratorTextNode(node)) node.toggleFormat(formatType);
			}
			return false;
		}, 1);
	}
});
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* @experimental
* Create a Signal that will subscribe to a value from an external store when watched, similar to
* React's [useSyncExternalStore](https://react.dev/reference/react/useSyncExternalStore).
*
* @param getSnapshot Used to get the initial value of the signal when created and when first watched.
* @param register A callback that will subscribe to some external store and update the signal, must return a dispose function.
* @returns The signal
*/
function watchedSignal(getSnapshot, register) {
	let dispose;
	return d(getSnapshot(), {
		unwatched() {
			if (dispose) {
				dispose();
				dispose = void 0;
			}
		},
		watched() {
			this.value = getSnapshot();
			dispose = register(this);
		}
	});
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* An extension to provide the current EditorState as a signal
*/
var EditorStateExtension = defineExtension({
	build(editor) {
		return watchedSignal(() => editor.getEditorState(), (editorStateSignal) => editor.registerUpdateListener((payload) => {
			editorStateSignal.value = payload.editorState;
		}));
	},
	name: "@lexical/extension/EditorState"
});
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function formatDevErrorMessage(message) {
	throw new Error(message);
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Recursively merge the given theme configuration in-place.
*
* @returns If `a` and `b` are both objects (and `b` is not an Array) then
* all keys in `b` are merged into `a` then `a` is returned.
* Otherwise `b` is returned.
*
* @example
* ```ts
* const a = { a: "a", nested: { a: 1 } };
* const b = { b: "b", nested: { b: 2 } };
* const rval = deepThemeMergeInPlace(a, b);
* expect(a).toBe(rval);
* expect(a).toEqual({ a: "a", b: "b", nested: { a: 1, b: 2 } });
* ```
*/
function deepThemeMergeInPlace(a, b) {
	if (a && b && !Array.isArray(b) && typeof a === "object" && typeof b === "object") {
		const aObj = a;
		const bObj = b;
		for (const k in bObj) aObj[k] = deepThemeMergeInPlace(aObj[k], bObj[k]);
		return a;
	}
	return b;
}
var ExtensionRepStateIds = {
	unmarked: 0,
	temporary: 1,
	permanent: 2,
	configured: 3,
	initialized: 4,
	built: 5,
	registered: 6,
	afterRegistration: 7
};
function isExactlyUnmarkedExtensionRepState(state) {
	return state.id === ExtensionRepStateIds.unmarked;
}
function isExactlyTemporaryExtensionRepState(state) {
	return state.id === ExtensionRepStateIds.temporary;
}
function isExactlyPermanentExtensionRepState(state) {
	return state.id === ExtensionRepStateIds.permanent;
}
function isConfiguredExtensionRepState(state) {
	return state.id >= ExtensionRepStateIds.configured;
}
function isInitializedExtensionRepState(state) {
	return state.id >= ExtensionRepStateIds.initialized;
}
function isBuiltExtensionRepState(state) {
	return state.id >= ExtensionRepStateIds.built;
}
function isAfterRegistrationState(state) {
	return state.id >= ExtensionRepStateIds.afterRegistration;
}
function applyTemporaryMark(state) {
	if (!isExactlyUnmarkedExtensionRepState(state)) formatDevErrorMessage(`LexicalBuilder: Can not apply a temporary mark from state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.unmarked)} unmarked)`);
	return Object.assign(state, { id: ExtensionRepStateIds.temporary });
}
function applyPermanentMark(state) {
	if (!isExactlyTemporaryExtensionRepState(state)) formatDevErrorMessage(`LexicalBuilder: Can not apply a permanent mark from state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.temporary)} temporary)`);
	return Object.assign(state, { id: ExtensionRepStateIds.permanent });
}
function applyConfiguredState(state, config, registerState) {
	return Object.assign(state, {
		config,
		id: ExtensionRepStateIds.configured,
		registerState
	});
}
function applyInitializedState(state, initResult, registerState) {
	return Object.assign(state, {
		id: ExtensionRepStateIds.initialized,
		initResult,
		registerState
	});
}
function applyBuiltState(state, output, registerState) {
	return Object.assign(state, {
		id: ExtensionRepStateIds.built,
		output,
		registerState
	});
}
function applyRegisteredState(state) {
	return Object.assign(state, { id: ExtensionRepStateIds.registered });
}
function applyAfterRegistrationState(state) {
	return Object.assign(state, { id: ExtensionRepStateIds.afterRegistration });
}
function rollbackToBuiltState(state) {
	return Object.assign(state, { id: ExtensionRepStateIds.built });
}
var emptySet = /* @__PURE__ */ new Set();
/**
* @internal
*/
var ExtensionRep = class {
	builder;
	configs;
	_dependency;
	_peerNameSet;
	extension;
	state;
	_signal;
	constructor(builder, extension) {
		this.builder = builder;
		this.extension = extension;
		this.configs = /* @__PURE__ */ new Set();
		this.state = { id: ExtensionRepStateIds.unmarked };
	}
	mergeConfigs() {
		let config = this.extension.config || {};
		const mergeConfig = this.extension.mergeConfig ? this.extension.mergeConfig.bind(this.extension) : shallowMergeConfig;
		for (const cfg of this.configs) config = mergeConfig(config, cfg);
		return config;
	}
	init(editorConfig) {
		const initialState = this.state;
		if (!isExactlyPermanentExtensionRepState(initialState)) formatDevErrorMessage(`ExtensionRep: Can not configure from state id ${String(initialState.id)}`);
		const initState = {
			getDependency: this.getInitDependency.bind(this),
			getDirectDependentNames: this.getDirectDependentNames.bind(this),
			getPeer: this.getInitPeer.bind(this),
			getPeerNameSet: this.getPeerNameSet.bind(this)
		};
		const buildState = {
			...initState,
			getDependency: this.getDependency.bind(this),
			getInitResult: this.getInitResult.bind(this),
			getPeer: this.getPeer.bind(this)
		};
		const state = applyConfiguredState(initialState, this.mergeConfigs(), initState);
		this.state = state;
		let initResult;
		if (this.extension.init) initResult = this.extension.init(editorConfig, state.config, initState);
		this.state = applyInitializedState(state, initResult, buildState);
	}
	build(editor) {
		const state = this.state;
		if (!(state.id === ExtensionRepStateIds.initialized)) formatDevErrorMessage(`ExtensionRep: register called in state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.built)} initialized)`);
		let output;
		if (this.extension.build) output = this.extension.build(editor, state.config, state.registerState);
		const registerState = {
			...state.registerState,
			getOutput: () => output,
			getSignal: this.getSignal.bind(this)
		};
		this.state = applyBuiltState(state, output, registerState);
	}
	register(editor, signal) {
		this._signal = signal;
		const state = this.state;
		if (!(state.id === ExtensionRepStateIds.built)) formatDevErrorMessage(`ExtensionRep: register called in state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.built)} built)`);
		const cleanup = this.extension.register && this.extension.register(editor, state.config, state.registerState);
		this.state = applyRegisteredState(state);
		return () => {
			const afterRegistrationState = this.state;
			if (!(afterRegistrationState.id === ExtensionRepStateIds.afterRegistration)) formatDevErrorMessage(`ExtensionRep: rollbackToBuiltState called in state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.afterRegistration)} afterRegistration)`);
			this.state = rollbackToBuiltState(afterRegistrationState);
			if (cleanup) cleanup();
		};
	}
	afterRegistration(editor) {
		const state = this.state;
		if (!(state.id === ExtensionRepStateIds.registered)) formatDevErrorMessage(`ExtensionRep: afterRegistration called in state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.registered)} registered)`);
		let rval;
		if (this.extension.afterRegistration) rval = this.extension.afterRegistration(editor, state.config, state.registerState);
		this.state = applyAfterRegistrationState(state);
		return rval;
	}
	getSignal() {
		if (!(this._signal !== void 0)) formatDevErrorMessage(`ExtensionRep.getSignal() called before register`);
		return this._signal;
	}
	getInitResult() {
		if (!(this.extension.init !== void 0)) formatDevErrorMessage(`ExtensionRep: getInitResult() called for Extension ${this.extension.name} that does not define init`);
		const state = this.state;
		if (!isInitializedExtensionRepState(state)) formatDevErrorMessage(`ExtensionRep: getInitResult() called for ExtensionRep in state id ${String(state.id)} < ${String(ExtensionRepStateIds.initialized)} (initialized)`);
		return state.initResult;
	}
	getInitPeer(name) {
		const rep = this.builder.extensionNameMap.get(name);
		return rep ? rep.getExtensionInitDependency() : void 0;
	}
	getExtensionInitDependency() {
		const state = this.state;
		if (!isConfiguredExtensionRepState(state)) formatDevErrorMessage(`ExtensionRep: getExtensionInitDependency called in state id ${String(state.id)} (expected >= ${String(ExtensionRepStateIds.configured)} configured)`);
		return { config: state.config };
	}
	getPeer(name) {
		const rep = this.builder.extensionNameMap.get(name);
		return rep ? rep.getExtensionDependency() : void 0;
	}
	getInitDependency(dep) {
		const rep = this.builder.getExtensionRep(dep);
		if (!(rep !== void 0)) formatDevErrorMessage(`LexicalExtensionBuilder: Extension ${this.extension.name} missing dependency extension ${dep.name} to be in registry`);
		return rep.getExtensionInitDependency();
	}
	getDependency(dep) {
		const rep = this.builder.getExtensionRep(dep);
		if (!(rep !== void 0)) formatDevErrorMessage(`LexicalExtensionBuilder: Extension ${this.extension.name} missing dependency extension ${dep.name} to be in registry`);
		return rep.getExtensionDependency();
	}
	getState() {
		const state = this.state;
		if (!isAfterRegistrationState(state)) formatDevErrorMessage(`ExtensionRep getState called in state id ${String(state.id)} (expected ${String(ExtensionRepStateIds.afterRegistration)} afterRegistration)`);
		return state;
	}
	getDirectDependentNames() {
		return this.builder.incomingEdges.get(this.extension.name) || emptySet;
	}
	getPeerNameSet() {
		let s = this._peerNameSet;
		if (!s) {
			s = new Set((this.extension.peerDependencies || []).map(([name]) => name));
			this._peerNameSet = s;
		}
		return s;
	}
	getExtensionDependency() {
		if (!this._dependency) {
			const state = this.state;
			if (!isBuiltExtensionRepState(state)) formatDevErrorMessage(`Extension ${this.extension.name} used as a dependency before build`);
			this._dependency = {
				config: state.config,
				init: state.initResult,
				output: state.output
			};
		}
		return this._dependency;
	}
};
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var HISTORY_MERGE_OPTIONS = { tag: HISTORY_MERGE_TAG };
function $defaultInitializer() {
	const root = $getRoot();
	if (root.isEmpty()) root.append($createParagraphNode());
}
/**
* An extension to set the initial state of the editor from
* a function or serialized JSON EditorState. This is
* implicitly included with all editors built with
* Lexical Extension. This happens in the `afterRegistration`
* phase so your initial state may depend on registered commands,
* but you should not call `editor.setRootElement` earlier than
* this phase to avoid rendering an empty editor first.
*/
var InitialStateExtension = defineExtension({
	config: safeCast({
		setOptions: HISTORY_MERGE_OPTIONS,
		updateOptions: HISTORY_MERGE_OPTIONS
	}),
	init({ $initialEditorState = $defaultInitializer }) {
		return {
			$initialEditorState,
			initialized: false
		};
	},
	afterRegistration(editor, { updateOptions, setOptions }, state) {
		const initResult = state.getInitResult();
		if (!initResult.initialized) {
			initResult.initialized = true;
			const { $initialEditorState } = initResult;
			if ($isEditorState($initialEditorState)) editor.setEditorState($initialEditorState, setOptions);
			else if (typeof $initialEditorState === "function") editor.update(() => {
				$initialEditorState(editor);
			}, updateOptions);
			else if ($initialEditorState && (typeof $initialEditorState === "string" || typeof $initialEditorState === "object")) {
				const parsedEditorState = editor.parseEditorState($initialEditorState);
				editor.setEditorState(parsedEditorState, setOptions);
			}
		}
		return () => {};
	},
	name: "@lexical/extension/InitialState",
	nodes: [
		RootNode,
		TextNode,
		LineBreakNode,
		TabNode,
		ParagraphNode
	]
});
/** @internal Use a well-known symbol for dev tools purposes */
var builderSymbol = Symbol.for("@lexical/extension/LexicalBuilder");
/** @internal */
function noop() {}
/** Throw the given Error */
function defaultOnError(err) {
	throw err;
}
/** @internal */
function maybeWithBuilder(editor) {
	return editor;
}
function normalizeExtensionArgument(arg) {
	return Array.isArray(arg) ? arg : [arg];
}
var PACKAGE_VERSION = "0.41.0+dev.esm";
/** @internal */
var LexicalBuilder = class LexicalBuilder {
	roots;
	extensionNameMap;
	outgoingConfigEdges;
	incomingEdges;
	conflicts;
	_sortedExtensionReps;
	PACKAGE_VERSION;
	constructor(roots) {
		this.outgoingConfigEdges = /* @__PURE__ */ new Map();
		this.incomingEdges = /* @__PURE__ */ new Map();
		this.extensionNameMap = /* @__PURE__ */ new Map();
		this.conflicts = /* @__PURE__ */ new Map();
		this.PACKAGE_VERSION = PACKAGE_VERSION;
		this.roots = roots;
		for (const extension of roots) this.addExtension(extension);
	}
	static fromExtensions(extensions) {
		const roots = [normalizeExtensionArgument(InitialStateExtension)];
		for (const extension of extensions) roots.push(normalizeExtensionArgument(extension));
		return new LexicalBuilder(roots);
	}
	static maybeFromEditor(editor) {
		const builder = maybeWithBuilder(editor)[builderSymbol];
		if (builder) {
			if (!(builder.PACKAGE_VERSION === PACKAGE_VERSION)) formatDevErrorMessage(`LexicalBuilder.fromEditor: The given editor was created with LexicalBuilder ${builder.PACKAGE_VERSION} but this version is ${PACKAGE_VERSION}. A project should have exactly one copy of LexicalBuilder`);
			if (!(builder instanceof LexicalBuilder)) formatDevErrorMessage(`LexicalBuilder.fromEditor: There are multiple copies of the same version of LexicalBuilder in your project, and this editor was created with another one. Your project, or one of its dependencies, has its package.json and/or bundler configured incorrectly.`);
		}
		return builder;
	}
	/** Look up the editor that was created by this LexicalBuilder or throw */
	static fromEditor(editor) {
		const builder = LexicalBuilder.maybeFromEditor(editor);
		if (!(builder !== void 0)) formatDevErrorMessage(`LexicalBuilder.fromEditor: The given editor was not created with LexicalBuilder`);
		return builder;
	}
	constructEditor() {
		const { $initialEditorState: _$initialEditorState, onError, ...editorConfig } = this.buildCreateEditorArgs();
		const editor = Object.assign(createEditor({
			...editorConfig,
			...onError ? { onError: (err) => {
				onError(err, editor);
			} } : {}
		}), { [builderSymbol]: this });
		for (const extensionRep of this.sortedExtensionReps()) extensionRep.build(editor);
		return editor;
	}
	buildEditor() {
		let disposeOnce = noop;
		function dispose() {
			try {
				disposeOnce();
			} finally {
				disposeOnce = noop;
			}
		}
		const editor = Object.assign(this.constructEditor(), {
			dispose,
			[Symbol.dispose]: dispose
		});
		disposeOnce = mergeRegister(this.registerEditor(editor), () => editor.setRootElement(null));
		return editor;
	}
	hasExtensionByName(name) {
		return this.extensionNameMap.has(name);
	}
	getExtensionRep(extension) {
		const rep = this.extensionNameMap.get(extension.name);
		if (rep) {
			if (!(rep.extension === extension)) formatDevErrorMessage(`LexicalBuilder: A registered extension with name ${extension.name} exists but does not match the given extension`);
			return rep;
		}
	}
	addEdge(fromExtensionName, toExtensionName, configs) {
		const outgoing = this.outgoingConfigEdges.get(fromExtensionName);
		if (outgoing) outgoing.set(toExtensionName, configs);
		else this.outgoingConfigEdges.set(fromExtensionName, /* @__PURE__ */ new Map([[toExtensionName, configs]]));
		const incoming = this.incomingEdges.get(toExtensionName);
		if (incoming) incoming.add(fromExtensionName);
		else this.incomingEdges.set(toExtensionName, /* @__PURE__ */ new Set([fromExtensionName]));
	}
	addExtension(arg) {
		if (!(this._sortedExtensionReps === void 0)) formatDevErrorMessage(`LexicalBuilder: addExtension called after finalization`);
		const [extension] = normalizeExtensionArgument(arg);
		if (!(typeof extension.name === "string")) formatDevErrorMessage(`LexicalBuilder: extension name must be string, not ${typeof extension.name}`);
		let extensionRep = this.extensionNameMap.get(extension.name);
		if (!(extensionRep === void 0 || extensionRep.extension === extension)) formatDevErrorMessage(`LexicalBuilder: Multiple extensions registered with name ${extension.name}, names must be unique`);
		if (!extensionRep) {
			extensionRep = new ExtensionRep(this, extension);
			this.extensionNameMap.set(extension.name, extensionRep);
			const hasConflict = this.conflicts.get(extension.name);
			if (typeof hasConflict === "string") formatDevErrorMessage(`LexicalBuilder: extension ${extension.name} conflicts with ${hasConflict}`);
			for (const name of extension.conflictsWith || []) {
				if (!!this.extensionNameMap.has(name)) formatDevErrorMessage(`LexicalBuilder: extension ${extension.name} conflicts with ${name}`);
				this.conflicts.set(name, extension.name);
			}
			for (const dep of extension.dependencies || []) {
				const normDep = normalizeExtensionArgument(dep);
				this.addEdge(extension.name, normDep[0].name, normDep.slice(1));
				this.addExtension(normDep);
			}
			for (const [depName, config] of extension.peerDependencies || []) this.addEdge(extension.name, depName, config ? [config] : []);
		}
	}
	sortedExtensionReps() {
		if (this._sortedExtensionReps) return this._sortedExtensionReps;
		const sortedExtensionReps = [];
		const visit = (rep, fromExtensionName) => {
			let mark = rep.state;
			if (isExactlyPermanentExtensionRepState(mark)) return;
			const extensionName = rep.extension.name;
			if (!isExactlyUnmarkedExtensionRepState(mark)) formatDevErrorMessage(`LexicalBuilder: Circular dependency detected for Extension ${extensionName} from ${fromExtensionName || "[unknown]"}`);
			mark = applyTemporaryMark(mark);
			rep.state = mark;
			const outgoingConfigEdges = this.outgoingConfigEdges.get(extensionName);
			if (outgoingConfigEdges) for (const toExtensionName of outgoingConfigEdges.keys()) {
				const toRep = this.extensionNameMap.get(toExtensionName);
				if (toRep) visit(toRep, extensionName);
			}
			mark = applyPermanentMark(mark);
			rep.state = mark;
			sortedExtensionReps.push(rep);
		};
		for (const rep of this.extensionNameMap.values()) if (isExactlyUnmarkedExtensionRepState(rep.state)) visit(rep);
		for (const rep of sortedExtensionReps) for (const [toExtensionName, configs] of this.outgoingConfigEdges.get(rep.extension.name) || []) if (configs.length > 0) {
			const toRep = this.extensionNameMap.get(toExtensionName);
			if (toRep) for (const config of configs) toRep.configs.add(config);
		}
		for (const [extension, ...configs] of this.roots) if (configs.length > 0) {
			const toRep = this.extensionNameMap.get(extension.name);
			if (!(toRep !== void 0)) formatDevErrorMessage(`LexicalBuilder: Expecting existing ExtensionRep for ${extension.name}`);
			for (const config of configs) toRep.configs.add(config);
		}
		this._sortedExtensionReps = sortedExtensionReps;
		return this._sortedExtensionReps;
	}
	registerEditor(editor) {
		const extensionReps = this.sortedExtensionReps();
		const controller = new AbortController();
		const cleanups = [() => controller.abort()];
		const signal = controller.signal;
		for (const extensionRep of extensionReps) {
			const cleanup = extensionRep.register(editor, signal);
			if (cleanup) cleanups.push(cleanup);
		}
		for (const extensionRep of extensionReps) {
			const cleanup = extensionRep.afterRegistration(editor);
			if (cleanup) cleanups.push(cleanup);
		}
		return mergeRegister(...cleanups);
	}
	buildCreateEditorArgs() {
		const config = {};
		const nodes = /* @__PURE__ */ new Set();
		const replacedNodes = /* @__PURE__ */ new Map();
		const htmlExport = /* @__PURE__ */ new Map();
		const htmlImport = {};
		const theme = {};
		const extensionReps = this.sortedExtensionReps();
		for (const extensionRep of extensionReps) {
			const { extension } = extensionRep;
			if (extension.onError !== void 0) config.onError = extension.onError;
			if (extension.disableEvents !== void 0) config.disableEvents = extension.disableEvents;
			if (extension.parentEditor !== void 0) config.parentEditor = extension.parentEditor;
			if (extension.editable !== void 0) config.editable = extension.editable;
			if (extension.namespace !== void 0) config.namespace = extension.namespace;
			if (extension.$initialEditorState !== void 0) config.$initialEditorState = extension.$initialEditorState;
			if (extension.nodes) for (const node of getNodeConfig(extension)) {
				if (typeof node !== "function") {
					const conflictExtension = replacedNodes.get(node.replace);
					if (conflictExtension) formatDevErrorMessage(`LexicalBuilder: Extension ${extension.name} can not register replacement for node ${node.replace.name} because ${conflictExtension.extension.name} already did`);
					replacedNodes.set(node.replace, extensionRep);
				}
				nodes.add(node);
			}
			if (extension.html) {
				if (extension.html.export) for (const [k, v] of extension.html.export.entries()) htmlExport.set(k, v);
				if (extension.html.import) Object.assign(htmlImport, extension.html.import);
			}
			if (extension.theme) deepThemeMergeInPlace(theme, extension.theme);
		}
		if (Object.keys(theme).length > 0) config.theme = theme;
		if (nodes.size) config.nodes = [...nodes];
		const hasImport = Object.keys(htmlImport).length > 0;
		const hasExport = htmlExport.size > 0;
		if (hasImport || hasExport) {
			config.html = {};
			if (hasImport) config.html.import = htmlImport;
			if (hasExport) config.html.export = htmlExport;
		}
		for (const extensionRep of extensionReps) extensionRep.init(config);
		if (!config.onError) config.onError = defaultOnError;
		return config;
	}
};
/**
* @experimental
* Get the finalized config and output of an Extension that was used to build the
* editor by name.
*
* This can be used from the implementation of a LexicalNode or in other
* situation where you have an editor reference but it's not easy to pass the
* config around. Use this version if you do not have a concrete reference to
* the Extension for some reason (e.g. it is an optional peer dependency, or you
* are avoiding a circular import).
*
* Both the explicit Extension type and the name are required.
*
*  @example
* ```tsx
* import type { HistoryExtension } from "@lexical/history";
* getPeerDependencyFromEditor<typeof HistoryExtension>(editor, "@lexical/history/History");
* ```

* @param editor - The editor that may have been built using extension
* @param extensionName - The name of the Extension
* @returns The config and output of the Extension or undefined
*/
function getPeerDependencyFromEditor(editor, extensionName) {
	const peer = LexicalBuilder.fromEditor(editor).extensionNameMap.get(extensionName);
	return peer ? peer.getExtensionDependency() : void 0;
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var EMPTY_SET = /* @__PURE__ */ new Set();
/**
* An extension that provides a `watchNodeKey` output that
* returns a signal for the selection state of a node.
*
* Typically used for tracking whether a DecoratorNode is
* currently selected or not. A framework independent
* alternative to {@link useLexicalNodeSelection}.
*/
var NodeSelectionExtension = defineExtension({
	build(editor, config, state) {
		const editorStateStore = state.getDependency(EditorStateExtension).output;
		const watchedNodeStore = d({ watchedNodeKeys: /* @__PURE__ */ new Map() });
		const selectedNodeKeys = watchedSignal(() => void 0, () => E(() => {
			const prevSelectedNodeKeys = selectedNodeKeys.peek();
			const { watchedNodeKeys } = watchedNodeStore.value;
			let nextSelectedNodeKeys;
			let didChange = false;
			editorStateStore.value.read(() => {
				if ($getSelection()) for (const [key, listeners] of watchedNodeKeys.entries()) {
					if (listeners.size === 0) {
						watchedNodeKeys.delete(key);
						continue;
					}
					const node = $getNodeByKey(key);
					const isSelected = node && node.isSelected() || false;
					didChange = didChange || isSelected !== (prevSelectedNodeKeys ? prevSelectedNodeKeys.has(key) : false);
					if (isSelected) {
						nextSelectedNodeKeys = nextSelectedNodeKeys || /* @__PURE__ */ new Set();
						nextSelectedNodeKeys.add(key);
					}
				}
			});
			if (!(!didChange && nextSelectedNodeKeys && prevSelectedNodeKeys && nextSelectedNodeKeys.size === prevSelectedNodeKeys.size)) selectedNodeKeys.value = nextSelectedNodeKeys;
		}));
		function watchNodeKey(key) {
			const watcher = w(() => (selectedNodeKeys.value || EMPTY_SET).has(key));
			const { watchedNodeKeys } = watchedNodeStore.peek();
			let listeners = watchedNodeKeys.get(key);
			const hadListener = listeners !== void 0;
			listeners = listeners || /* @__PURE__ */ new Set();
			listeners.add(watcher);
			if (!hadListener) {
				watchedNodeKeys.set(key, listeners);
				watchedNodeStore.value = { watchedNodeKeys };
			}
			return watcher;
		}
		return { watchNodeKey };
	},
	dependencies: [EditorStateExtension],
	name: "@lexical/extension/NodeSelection"
});
createCommand("INSERT_HORIZONTAL_RULE_COMMAND");
var HorizontalRuleNode = class HorizontalRuleNode extends DecoratorNode {
	static getType() {
		return "horizontalrule";
	}
	static clone(node) {
		return new HorizontalRuleNode(node.__key);
	}
	static importJSON(serializedNode) {
		return $createHorizontalRuleNode().updateFromJSON(serializedNode);
	}
	static importDOM() {
		return { hr: () => ({
			conversion: $convertHorizontalRuleElement,
			priority: 0
		}) };
	}
	exportDOM() {
		return { element: document.createElement("hr") };
	}
	createDOM(config) {
		const element = document.createElement("hr");
		addClassNamesToElement(element, config.theme.hr);
		return element;
	}
	getTextContent() {
		return "\n";
	}
	isInline() {
		return false;
	}
	updateDOM() {
		return false;
	}
};
function $convertHorizontalRuleElement() {
	return { node: $createHorizontalRuleNode() };
}
function $createHorizontalRuleNode() {
	return $create(HorizontalRuleNode);
}
function $isHorizontalRuleNode(node) {
	return node instanceof HorizontalRuleNode;
}
function $toggleNodeSelection(node, shiftKey = false) {
	const selection = $getSelection();
	const wasSelected = node.isSelected();
	const key = node.getKey();
	let nodeSelection;
	if (shiftKey && $isNodeSelection(selection)) nodeSelection = selection;
	else {
		nodeSelection = $createNodeSelection();
		$setSelection(nodeSelection);
	}
	if (wasSelected) nodeSelection.delete(key);
	else nodeSelection.add(key);
}
defineExtension({
	dependencies: [EditorStateExtension, NodeSelectionExtension],
	name: "@lexical/extension/HorizontalRule",
	nodes: () => [HorizontalRuleNode],
	register(editor, config, state) {
		const { watchNodeKey } = state.getDependency(NodeSelectionExtension).output;
		const nodeSelectionStore = d({ nodeSelections: /* @__PURE__ */ new Map() });
		const isSelectedClassName = editor._config.theme.hrSelected ?? "selected";
		return mergeRegister(editor.registerCommand(CLICK_COMMAND, (event) => {
			if (isDOMNode(event.target)) {
				const node = $getNodeFromDOMNode(event.target);
				if ($isHorizontalRuleNode(node)) {
					$toggleNodeSelection(node, event.shiftKey);
					return true;
				}
			}
			return false;
		}, 1), editor.registerMutationListener(HorizontalRuleNode, (nodes, payload) => {
			o(() => {
				let didChange = false;
				const { nodeSelections } = nodeSelectionStore.peek();
				for (const [k, v] of nodes.entries()) if (v === "destroyed") {
					nodeSelections.delete(k);
					didChange = true;
				} else {
					const prev = nodeSelections.get(k);
					const dom = editor.getElementByKey(k);
					if (prev) prev.domNode.value = dom;
					else {
						didChange = true;
						nodeSelections.set(k, {
							domNode: d(dom),
							selectedSignal: watchNodeKey(k)
						});
					}
				}
				if (didChange) nodeSelectionStore.value = { nodeSelections };
			});
		}), E(() => {
			const effects = [];
			for (const { domNode, selectedSignal } of nodeSelectionStore.value.nodeSelections.values()) effects.push(E(() => {
				const dom = domNode.value;
				if (dom) if (selectedSignal.value) addClassNamesToElement(dom, isSelectedClassName);
				else removeClassNamesFromElement(dom, isSelectedClassName);
			}));
			return mergeRegister(...effects);
		}));
	}
});
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function $indentOverTab(selection) {
	if (selection.getNodes().filter((node) => $isBlockElementNode(node) && node.canIndent()).length > 0) return true;
	const anchor = selection.anchor;
	const focus = selection.focus;
	const first = focus.isBefore(anchor) ? focus : anchor;
	const firstBlock = $getNearestBlockElementAncestorOrThrow(first.getNode());
	if (firstBlock.canIndent()) {
		const firstBlockKey = firstBlock.getKey();
		let selectionAtStart = $createRangeSelection();
		selectionAtStart.anchor.set(firstBlockKey, 0, "element");
		selectionAtStart.focus.set(firstBlockKey, 0, "element");
		selectionAtStart = $normalizeSelection(selectionAtStart);
		if (selectionAtStart.anchor.is(first)) return true;
	}
	return false;
}
function $defaultCanIndent(node) {
	return node.canBeEmpty();
}
function registerTabIndentation(editor, maxIndent, $canIndent = $defaultCanIndent) {
	return mergeRegister(editor.registerCommand(KEY_TAB_COMMAND, (event) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		event.preventDefault();
		const command = $indentOverTab(selection) ? event.shiftKey ? OUTDENT_CONTENT_COMMAND : INDENT_CONTENT_COMMAND : INSERT_TAB_COMMAND;
		return editor.dispatchCommand(command, void 0);
	}, 0), editor.registerCommand(INDENT_CONTENT_COMMAND, () => {
		const currentMaxIndent = typeof maxIndent === "number" ? maxIndent : maxIndent ? maxIndent.peek() : null;
		if (!$isRangeSelection($getSelection())) return false;
		const $currentCanIndent = typeof $canIndent === "function" ? $canIndent : $canIndent.peek();
		return $handleIndentAndOutdent((block) => {
			if ($currentCanIndent(block)) {
				const newIndent = block.getIndent() + 1;
				if (!currentMaxIndent || newIndent < currentMaxIndent) block.setIndent(newIndent);
			}
		});
	}, 4));
}
defineExtension({
	build(editor, config, state) {
		return namedSignals(config);
	},
	config: safeCast({
		$canIndent: $defaultCanIndent,
		disabled: false,
		maxIndent: null
	}),
	name: "@lexical/extension/TabIndentation",
	register(editor, config, state) {
		const { disabled, maxIndent, $canIndent } = state.getOutput();
		return E(() => {
			if (!disabled.value) return registerTabIndentation(editor, maxIndent, $canIndent);
		});
	}
});
//#endregion
export { o as a, namedSignals as i, LexicalBuilder as n, getPeerDependencyFromEditor as r, E as t };
