import { i as __toESM, n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { t as require_react_dom } from "./react-dom.js";
import { C as useIsoLayoutEffect, f as getWindow, m as isElement, n as useStableCallback, t as useId } from "./useId-Cfrl5XdH.js";
import { t as addEventListener } from "./addEventListener-BcJLlhNA.js";
import { D as POPUP_COLLISION_AVOIDANCE, E as LEGACY_SWIPE_IGNORE_SELECTOR, S as BASE_UI_SWIPE_IGNORE_SELECTOR, c as ReactStore, lt as FocusGuard, t as inertValue, ut as mergeCleanups } from "./inertValue-C-bH78NQ.js";
import { c as matchesFocusVisible } from "./element-du8in3y-.js";
import { t as ownerDocument } from "./owner-BmKt4Bpq.js";
import { c as NOOP, l as useRefWithInit, s as EMPTY_OBJECT, t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { t as useOnMount } from "./useOnMount-CiuP5FVI.js";
import { n as useTimeout, t as Timeout } from "./useTimeout-CHZlR9Tr.js";
import { n as contains, r as getTarget, t as activeElement } from "./shadowDom-CQZHMuh3.js";
import { t as visuallyHidden } from "./visuallyHidden-Xbj0ZvZT.js";
import { n as transitionStatusMapping, r as useOpenChangeComplete } from "./stateAttributesMapping-DKWbKMwM.js";
import { r as useAnchorPositioning, t as usePositioner } from "./usePositioner-CXpcG81q.js";
import { t as useFloatingRootContext } from "./useFloatingRootContext-WJnXvW5K.js";
import { t as useButton } from "./useButton-vy-VFWTJ.js";
import { t as FloatingPortalLite } from "./FloatingPortalLite-DyrzMru0.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/provider/ToastProviderContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var ToastContext = /*#__PURE__*/ import_react.createContext(void 0);
ToastContext.displayName = "ToastContext";
function useToastProviderContext() {
	const context = import_react.useContext(ToastContext);
	if (!context) throw new Error("Base UI: useToastManager must be used within <Toast.Provider>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+utils@0.3.2+0ea9ec2a211d4613/node_modules/@base-ui/utils/generateId.mjs
var counter = 0;
function generateId(prefix) {
	counter += 1;
	return `${prefix}-${Math.random().toString(36).slice(2, 6)}-${counter}`;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/utils/resolvePromiseOptions.mjs
function resolvePromiseOptions(options, result) {
	if (typeof options === "string") return { description: options };
	if (typeof options === "function") {
		const resolvedOptions = options(result);
		return typeof resolvedOptions === "string" ? { description: resolvedOptions } : resolvedOptions;
	}
	return options;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/store.mjs
/**
* A toast once it lives in the store. `addToast` is the only way in and it always
* assigns `updateKey`, so unlike the public `ToastObject` it is never missing.
*/
function createToastMetadata(toasts) {
	const metadata = /* @__PURE__ */ new Map();
	let visibleIndex = 0;
	let offsetY = 0;
	toasts.forEach((toast, toastIndex) => {
		const isEnding = toast.transitionStatus === "ending";
		metadata.set(toast.id, {
			value: toast,
			domIndex: toastIndex,
			visibleIndex: isEnding ? -1 : visibleIndex,
			offsetY
		});
		offsetY += toast.height || 0;
		if (!isEnding) visibleIndex += 1;
	});
	return metadata;
}
function applyLimited(toasts, limit) {
	let activeIndex = 0;
	return toasts.map((toast) => {
		if (toast.transitionStatus === "ending") return toast;
		const limited = activeIndex >= limit;
		activeIndex += 1;
		return toast.limited === limited ? toast : {
			...toast,
			limited
		};
	});
}
var selectors = {
	toasts: (state) => state.toasts,
	isEmpty: (state) => state.toasts.length === 0,
	toast: (state, id) => state.toastMetadata.get(id)?.value,
	toastIndex: (state, id) => state.toastMetadata.get(id)?.domIndex ?? -1,
	toastOffsetY: (state, id) => state.toastMetadata.get(id)?.offsetY ?? 0,
	toastVisibleIndex: (state, id) => state.toastMetadata.get(id)?.visibleIndex ?? -1,
	focused: (state) => state.focused,
	expanded: (state) => state.hovering || state.focused,
	expandedOrOutOfFocus: (state) => state.hovering || state.focused || !state.isWindowFocused,
	prevFocusElement: (state) => state.prevFocusElement
};
var ToastStore = class extends ReactStore {
	timers = /* @__PURE__ */ new Map();
	areTimersPaused = false;
	constructor(initialState) {
		super({
			...initialState,
			toastMetadata: createToastMetadata(initialState.toasts)
		}, {}, selectors);
	}
	setViewport = (viewport) => {
		this.set("viewport", viewport);
	};
	syncProviderProps(timeout, limit) {
		const limitChanged = this.state.limit !== limit;
		if (this.state.timeout === timeout && !limitChanged) return;
		const updates = {
			timeout,
			limit
		};
		if (limitChanged) {
			const newToasts = applyLimited(this.state.toasts, limit);
			updates.toasts = newToasts;
			updates.toastMetadata = createToastMetadata(newToasts);
		}
		this.update(updates);
	}
	disposeEffect = () => {
		return () => {
			this.timers.forEach((timer) => {
				timer.timeout?.clear();
			});
			this.timers.clear();
		};
	};
	removeToast(toastId, skipOnRemove = false) {
		const index = selectors.toastIndex(this.state, toastId);
		if (index === -1) return;
		const toast = this.state.toasts[index];
		if (!skipOnRemove) toast?.onRemove?.();
		const newToasts = [...this.state.toasts];
		newToasts.splice(index, 1);
		this.setToasts(newToasts);
	}
	addToast = (toast) => {
		const { timeout, limit } = this.state;
		const id = toast.id || generateId("toast");
		if (toast.id) {
			const existingToast = selectors.toast(this.state, toast.id);
			if (existingToast) if (existingToast.transitionStatus === "ending") this.removeToast(toast.id, true);
			else {
				const { id: ignoredId, transitionStatus: ignoredTransitionStatus, ...updates } = toast;
				this.updateToastInternal(toast.id, updates, true, true);
				return toast.id;
			}
		}
		const toastToAdd = {
			...toast,
			id,
			updateKey: 0,
			transitionStatus: "starting"
		};
		const updatedToasts = [toastToAdd, ...this.state.toasts];
		this.setToasts(applyLimited(updatedToasts, limit));
		const duration = toastToAdd.timeout ?? timeout;
		if (toastToAdd.type !== "loading" && duration > 0) this.scheduleTimer(id, duration, () => this.closeToast(id));
		if (selectors.expandedOrOutOfFocus(this.state)) this.pauseTimers();
		return id;
	};
	updateToast = (id, updates) => {
		this.updateToastInternal(id, updates, false, true);
	};
	updateToastInternal = (id, updates, resetTimer = false, markUpdated = false) => {
		const { timeout, toasts } = this.state;
		const prevToast = selectors.toast(this.state, id);
		if (!prevToast) return;
		if (prevToast.transitionStatus === "ending") return;
		const nextToast = {
			...prevToast,
			...updates,
			...markUpdated && { updateKey: prevToast.updateKey + 1 }
		};
		this.setToasts(toasts.map((toast) => toast.id === id ? nextToast : toast));
		const nextTimeout = nextToast.timeout ?? timeout;
		const prevTimeout = prevToast.timeout ?? timeout;
		const timeoutUpdated = Object.hasOwn(updates, "timeout");
		const shouldHaveTimer = nextToast.transitionStatus !== "ending" && nextToast.type !== "loading" && nextTimeout > 0;
		const hasTimer = this.timers.has(id);
		const timeoutChanged = prevTimeout !== nextTimeout;
		const wasLoading = prevToast.type === "loading";
		if (!shouldHaveTimer && hasTimer) {
			this.clearTimer(id);
			return;
		}
		if (shouldHaveTimer && (!hasTimer || timeoutChanged || timeoutUpdated || wasLoading || resetTimer)) {
			this.clearTimer(id);
			this.scheduleTimer(id, nextTimeout, () => this.closeToast(id));
			if (selectors.expandedOrOutOfFocus(this.state)) this.pauseTimers();
		}
	};
	closeToast = (toastId) => {
		const closeAll = toastId === void 0;
		const { limit, toasts } = this.state;
		let toastsToClose;
		if (closeAll) {
			toastsToClose = toasts;
			this.clearTimers();
		} else {
			const toast = selectors.toast(this.state, toastId);
			if (!toast) return;
			toastsToClose = [toast];
			this.clearTimer(toastId);
		}
		const newToasts = applyLimited(toasts.map((item) => closeAll || item.id === toastId ? {
			...item,
			transitionStatus: "ending",
			height: 0
		} : item), limit);
		this.setToasts(newToasts, !newToasts.some((toast) => toast.transitionStatus !== "ending"));
		toastsToClose.forEach((toast) => {
			if (toast.transitionStatus !== "ending") toast.onClose?.();
		});
		this.handleFocusManagement(toastId);
	};
	promiseToast = (promiseValue, options) => {
		const loadingOptions = resolvePromiseOptions(options.loading);
		const id = this.addToast({
			...loadingOptions,
			type: "loading"
		});
		const handledPromise = promiseValue.then((result) => {
			const successOptions = resolvePromiseOptions(options.success, result);
			this.updateToast(id, {
				...successOptions,
				type: "success",
				timeout: successOptions.timeout
			});
			return result;
		}).catch((error) => {
			const errorOptions = resolvePromiseOptions(options.error, error);
			this.updateToast(id, {
				...errorOptions,
				type: "error",
				timeout: errorOptions.timeout
			});
			return Promise.reject(error);
		});
		if ({}.hasOwnProperty.call(options, "setPromise")) options.setPromise(handledPromise);
		return handledPromise;
	};
	pauseTimers() {
		if (this.areTimersPaused) return;
		this.areTimersPaused = true;
		this.timers.forEach((timer) => {
			if (timer.timeout) {
				timer.timeout.clear();
				timer.remaining = Math.max(timer.remaining - (Date.now() - timer.start), 0);
			}
		});
	}
	resumeTimers() {
		if (!this.areTimersPaused) return;
		this.areTimersPaused = false;
		this.timers.forEach((timer, id) => {
			timer.remaining = timer.remaining > 0 ? timer.remaining : timer.delay;
			timer.timeout ??= Timeout.create();
			timer.timeout.start(timer.remaining, () => {
				this.handleTimerFired(id);
				timer.callback();
			});
			timer.start = Date.now();
		});
	}
	restoreFocusToPrevElement() {
		this.state.prevFocusElement?.focus({ preventScroll: true });
	}
	handleDocumentPointerDown = (event) => {
		if (event.pointerType !== "touch") return;
		const target = getTarget(event);
		if (contains(this.state.viewport, target)) return;
		this.resumeTimers();
		this.update({
			hovering: false,
			focused: false
		});
	};
	scheduleTimer(id, delay, callback) {
		const start = Date.now();
		const currentTimeout = !selectors.expandedOrOutOfFocus(this.state) ? Timeout.create() : void 0;
		currentTimeout?.start(delay, () => {
			this.handleTimerFired(id);
			callback();
		});
		this.timers.set(id, {
			timeout: currentTimeout,
			start,
			delay,
			remaining: delay,
			callback
		});
	}
	clearTimers() {
		this.timers.forEach((timer) => {
			timer.timeout?.clear();
		});
		this.timers.clear();
		this.areTimersPaused = false;
	}
	clearTimer(id) {
		this.timers.get(id)?.timeout?.clear();
		this.timers.delete(id);
		this.resetPausedStateIfNoTimersRemain();
	}
	handleTimerFired(id) {
		this.timers.delete(id);
		this.resetPausedStateIfNoTimersRemain();
	}
	resetPausedStateIfNoTimersRemain() {
		if (this.timers.size === 0) this.areTimersPaused = false;
	}
	setToasts(newToasts, clearInteraction = newToasts.length === 0) {
		const updates = {
			toasts: newToasts,
			toastMetadata: createToastMetadata(newToasts)
		};
		if (clearInteraction) {
			updates.hovering = false;
			updates.focused = false;
		}
		this.update(updates);
	}
	handleFocusManagement(toastId) {
		const activeEl = activeElement(ownerDocument(this.state.viewport));
		if (!this.state.viewport || !contains(this.state.viewport, activeEl) || !matchesFocusVisible(activeEl)) return;
		if (toastId === void 0) {
			this.restoreFocusToPrevElement();
			return;
		}
		const toasts = selectors.toasts(this.state);
		const currentIndex = selectors.toastIndex(this.state, toastId);
		const scan = (from, step) => {
			for (let index = from; index >= 0 && index < toasts.length; index += step) if (toasts[index].transitionStatus !== "ending") return toasts[index];
			return null;
		};
		const nextToast = scan(currentIndex + 1, 1) ?? scan(currentIndex - 1, -1);
		if (nextToast) nextToast.ref?.current?.focus();
		else this.restoreFocusToPrevElement();
	}
};
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/provider/ToastProvider.mjs
var import_jsx_runtime = require_jsx_runtime();
var ToastProvider = function ToastProvider(props) {
	const { children, timeout = 5e3, limit = 3, toastManager } = props;
	const store = useRefWithInit(() => new ToastStore({
		timeout,
		limit,
		viewport: null,
		toasts: [],
		hovering: false,
		focused: false,
		isWindowFocused: true,
		prevFocusElement: null
	})).current;
	useOnMount(store.disposeEffect);
	import_react.useEffect(function subscribeToToastManager() {
		if (!toastManager) return;
		return toastManager[" subscribe"](({ action, options }) => {
			const id = options.id;
			if (action === "promise" && options.promise) store.promiseToast(options.promise, options);
			else if (action === "update" && id) store.updateToast(id, options);
			else if (action === "close") store.closeToast(id);
			else store.addToast(options);
		});
	}, [store, toastManager]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(ToastContext.Provider, {
		value: store,
		children: [/*#__PURE__*/ (0, import_jsx_runtime.jsx)(ToastProviderPropsSynchronizer, {
			store,
			timeout,
			limit
		}), children]
	});
};
ToastProvider.displayName = "ToastProvider";
function ToastProviderPropsSynchronizer(props) {
	const { store, timeout, limit } = props;
	useIsoLayoutEffect(() => {
		store.syncProviderProps(timeout, limit);
	}, [
		store,
		timeout,
		limit
	]);
	return null;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/viewport/ToastViewport.mjs
/**
* A container viewport for toasts.
* Renders a `<div>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastViewport = /*#__PURE__*/ import_react.forwardRef(function ToastViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const store = useToastProviderContext();
	const windowFocusTimeout = useTimeout();
	const handlingFocusGuardRef = import_react.useRef(false);
	const markedReadyForMouseLeaveRef = import_react.useRef(false);
	const touchActiveRef = import_react.useRef(false);
	const isEmpty = store.useState("isEmpty");
	const toasts = store.useState("toasts");
	const focused = store.useState("focused");
	const expanded = store.useState("expanded");
	const prevFocusElement = store.useState("prevFocusElement");
	const frontmostHeight = toasts[0]?.height;
	const hasTransitioningToasts = toasts.some((toast) => toast.transitionStatus === "ending");
	const highPriorityToasts = toasts.filter((toast) => toast.priority === "high");
	import_react.useEffect(() => {
		const viewport = store.state.viewport;
		if (!viewport || isEmpty) return;
		const win = getWindow(viewport);
		const doc = ownerDocument(viewport);
		function handleGlobalKeyDown(event) {
			if (event.key === "F6" && getTarget(event) !== viewport) {
				event.preventDefault();
				store.set("prevFocusElement", activeElement(doc));
				viewport?.focus({ preventScroll: true });
				store.pauseTimers();
				store.set("focused", true);
			}
		}
		function handleWindowBlur(event) {
			if (getTarget(event) !== win) return;
			store.set("isWindowFocused", false);
			store.pauseTimers();
		}
		function handleWindowFocus(event) {
			if (event.relatedTarget) return;
			const target = getTarget(event);
			const activeEl = activeElement(ownerDocument(viewport));
			if (target === win || !contains(viewport, target) || !matchesFocusVisible(activeEl)) store.resumeTimers();
			windowFocusTimeout.start(0, () => store.set("isWindowFocused", true));
		}
		return mergeCleanups(addEventListener(win, "keydown", handleGlobalKeyDown), addEventListener(win, "blur", handleWindowBlur, true), addEventListener(win, "focus", handleWindowFocus, true), addEventListener(doc, "pointerdown", store.handleDocumentPointerDown, true));
	}, [
		store,
		windowFocusTimeout,
		isEmpty
	]);
	function handleFocusGuard(event) {
		handlingFocusGuardRef.current = true;
		const firstFocusableToast = event.relatedTarget === store.state.viewport ? toasts.find((toast) => toast.transitionStatus !== "ending" && !toast.limited) : void 0;
		if (firstFocusableToast) firstFocusableToast.ref?.current?.focus();
		else store.restoreFocusToPrevElement();
	}
	function handleKeyDown(event) {
		if (event.key === "Tab" && event.shiftKey && getTarget(event.nativeEvent) === store.state.viewport) {
			event.preventDefault();
			store.restoreFocusToPrevElement();
		}
	}
	function flushMouseLeave() {
		if (store.state.toasts.some((toast) => toast.transitionStatus === "ending") || touchActiveRef.current || !markedReadyForMouseLeaveRef.current) return;
		if (store.state.isWindowFocused) store.resumeTimers();
		store.set("hovering", false);
		markedReadyForMouseLeaveRef.current = false;
	}
	import_react.useEffect(flushMouseLeave, [hasTransitioningToasts, store]);
	function handleMouseEnter() {
		store.pauseTimers();
		store.set("hovering", true);
		markedReadyForMouseLeaveRef.current = false;
	}
	function resumeTimersIfWindowFocused() {
		if (store.state.isWindowFocused) store.resumeTimers();
	}
	function handleMouseLeave() {
		markedReadyForMouseLeaveRef.current = true;
		flushMouseLeave();
	}
	function handlePointerDown(event) {
		if (event.pointerType === "touch") touchActiveRef.current = true;
	}
	function handlePointerEnd(event) {
		if (event.pointerType !== "touch") return;
		touchActiveRef.current = false;
		flushMouseLeave();
	}
	function handleFocus() {
		if (handlingFocusGuardRef.current) {
			handlingFocusGuardRef.current = false;
			return;
		}
		if (focused) return;
		if (matchesFocusVisible(activeElement(ownerDocument(store.state.viewport)))) {
			store.set("focused", true);
			store.pauseTimers();
		}
	}
	function handleBlur(event) {
		if (!focused || contains(store.state.viewport, event.relatedTarget)) return;
		store.set("focused", false);
		resumeTimersIfWindowFocused();
	}
	const defaultProps = {
		tabIndex: -1,
		role: "region",
		"aria-live": "polite",
		"aria-atomic": false,
		"aria-relevant": "additions text",
		"aria-label": "Notifications",
		onMouseEnter: handleMouseEnter,
		onMouseMove: handleMouseEnter,
		onMouseLeave: handleMouseLeave,
		onFocus: handleFocus,
		onBlur: handleBlur,
		onKeyDown: handleKeyDown,
		onClick: handleFocus,
		onPointerDown: handlePointerDown,
		onPointerUp: handlePointerEnd,
		onPointerCancel: handlePointerEnd,
		style: { ["--toast-frontmost-height"]: frontmostHeight ? `${frontmostHeight}px` : void 0 }
	};
	const state = { expanded };
	const focusGuard = !isEmpty && prevFocusElement && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, { onFocus: handleFocusGuard });
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, store.setViewport],
		state,
		props: [
			defaultProps,
			elementProps,
			{ children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
				focusGuard,
				children,
				focusGuard
			] }) }
		]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		focusGuard,
		element,
		!focused && highPriorityToasts.length > 0 && /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
			style: visuallyHidden,
			children: highPriorityToasts.map((toast) => /*#__PURE__*/ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				"aria-atomic": true,
				children: [/*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", { children: toast.title }), /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", { children: toast.description })]
			}, toast.id))
		})
	] });
});
ToastViewport.displayName = "ToastViewport";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/root/ToastRootContext.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var ToastRootContext = /*#__PURE__*/ import_react.createContext(void 0);
ToastRootContext.displayName = "ToastRootContext";
function useToastRootContext() {
	const context = import_react.useContext(ToastRootContext);
	if (!context) throw new Error("Base UI: ToastRootContext is missing. Toast parts must be used within <Toast.Root>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/useSwipeDismiss.mjs
function getDisplacement(direction, deltaX, deltaY) {
	switch (direction) {
		case "up": return -deltaY;
		case "down": return deltaY;
		case "left": return -deltaX;
		case "right": return deltaX;
		default: return 0;
	}
}
function getElementTransform(element) {
	const transform = getWindow(element).getComputedStyle(element).transform;
	let translateX = 0;
	let translateY = 0;
	let scale = 1;
	if (transform && transform !== "none") {
		const matrix = transform.match(/matrix(?:3d)?\(([^)]+)\)/);
		if (matrix) {
			const values = matrix[1].split(", ").map(parseFloat);
			if (values.length === 6) {
				translateX = values[4];
				translateY = values[5];
				scale = Math.sqrt(values[0] * values[0] + values[1] * values[1]);
			} else if (values.length === 16) {
				translateX = values[12];
				translateY = values[13];
				scale = values[0];
			}
		}
	}
	return {
		x: translateX,
		y: translateY,
		scale
	};
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/root/ToastRoot.mjs
var toastRootStateAttributesMapping = {
	...transitionStatusMapping,
	swipeDirection(value) {
		return value ? { "data-swipe-direction": value } : null;
	}
};
var SWIPE_THRESHOLD = 40;
var REVERSE_CANCEL_THRESHOLD = 10;
var OPPOSITE_DIRECTION_DAMPING_FACTOR = .5;
var MIN_DRAG_THRESHOLD = 1;
var TOAST_SWIPE_IGNORE_SELECTOR = `${BASE_UI_SWIPE_IGNORE_SELECTOR},${LEGACY_SWIPE_IGNORE_SELECTOR}`;
/**
* Groups all parts of an individual toast.
* Renders a `<div>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastRoot = /*#__PURE__*/ import_react.forwardRef(function ToastRoot(componentProps, forwardedRef) {
	const { toast, render, className, swipeDirection = ["down", "right"], style, ...elementProps } = componentProps;
	const isAnchored = toast.positionerProps?.anchor !== void 0;
	let swipeDirections = [];
	if (!isAnchored) swipeDirections = Array.isArray(swipeDirection) ? swipeDirection : [swipeDirection];
	const swipeEnabled = swipeDirections.length > 0;
	const store = useToastProviderContext();
	const [currentSwipeDirection, setCurrentSwipeDirection] = import_react.useState(void 0);
	const [isSwiping, setIsSwiping] = import_react.useState(false);
	const [isRealSwipe, setIsRealSwipe] = import_react.useState(false);
	const [dragOffset, setDragOffset] = import_react.useState({
		x: 0,
		y: 0
	});
	const [initialTransform, setInitialTransform] = import_react.useState({
		x: 0,
		y: 0,
		scale: 1
	});
	const [titleId, setTitleId] = import_react.useState();
	const [descriptionId, setDescriptionId] = import_react.useState();
	const [lockedDirection, setLockedDirection] = import_react.useState(null);
	const rootRef = import_react.useRef(null);
	const lastToastIdRef = import_react.useRef(void 0);
	const dragStartPosRef = import_react.useRef({
		x: 0,
		y: 0
	});
	const initialTransformRef = import_react.useRef({
		x: 0,
		y: 0,
		scale: 1
	});
	const intendedSwipeDirectionRef = import_react.useRef(void 0);
	const maxSwipeDisplacementRef = import_react.useRef(0);
	const cancelledSwipeRef = import_react.useRef(false);
	const swipeCancelBaselineRef = import_react.useRef({
		x: 0,
		y: 0
	});
	const isFirstPointerMoveRef = import_react.useRef(false);
	const dragOffsetRef = import_react.useRef({
		x: 0,
		y: 0
	});
	const activePointerIdRef = import_react.useRef(null);
	const dragAbortControllerRef = import_react.useRef(null);
	const domIndex = store.useState("toastIndex", toast.id);
	const visibleIndex = store.useState("toastVisibleIndex", toast.id);
	const offsetY = store.useState("toastOffsetY", toast.id);
	const focused = store.useState("focused");
	const expanded = store.useState("expanded");
	useOpenChangeComplete({
		open: toast.transitionStatus !== "ending",
		ref: rootRef,
		onComplete() {
			if (toast.transitionStatus === "ending") store.removeToast(toast.id);
		}
	});
	const recalculateHeight = useStableCallback((flushSync = false) => {
		const element = rootRef.current;
		if (!element) return;
		const previousHeight = element.style.height;
		element.style.height = "auto";
		const height = element.offsetHeight;
		element.style.height = previousHeight;
		function update() {
			store.updateToastInternal(toast.id, {
				ref: rootRef,
				height,
				transitionStatus: void 0
			});
		}
		if (flushSync) import_react_dom.flushSync(update);
		else update();
	});
	useIsoLayoutEffect(() => {
		const previousToastId = lastToastIdRef.current;
		if (toast.transitionStatus !== "starting" && previousToastId === toast.id) return;
		if (previousToastId !== void 0) {
			setCurrentSwipeDirection(void 0);
			setInitialTransform({
				x: 0,
				y: 0,
				scale: 1
			});
			setResolvedDragOffset({
				x: 0,
				y: 0
			});
		}
		lastToastIdRef.current = toast.id;
		recalculateHeight();
	}, [
		recalculateHeight,
		toast.id,
		toast.transitionStatus
	]);
	function setResolvedDragOffset(nextDragOffset) {
		dragOffsetRef.current = nextDragOffset;
		setDragOffset(nextDragOffset);
	}
	useIsoLayoutEffect(() => {
		return () => {
			dragAbortControllerRef.current?.abort();
		};
	}, []);
	function applyDirectionalDamping(deltaX, deltaY) {
		const damp = (delta) => delta > 0 ? delta ** OPPOSITE_DIRECTION_DAMPING_FACTOR : -(Math.abs(delta) ** OPPOSITE_DIRECTION_DAMPING_FACTOR);
		const dampX = deltaX > 0 && !swipeDirections.includes("right") || deltaX < 0 && !swipeDirections.includes("left");
		const dampY = deltaY > 0 && !swipeDirections.includes("down") || deltaY < 0 && !swipeDirections.includes("up");
		return {
			x: dampX ? damp(deltaX) : deltaX,
			y: dampY ? damp(deltaY) : deltaY
		};
	}
	const handleSwipeEnd = useStableCallback((event) => {
		if (event.pointerId !== activePointerIdRef.current) return;
		activePointerIdRef.current = null;
		dragAbortControllerRef.current?.abort();
		dragAbortControllerRef.current = null;
		setIsSwiping(false);
		setIsRealSwipe(false);
		setLockedDirection(null);
		const resolvedInitialTransform = initialTransformRef.current;
		if (event.type === "pointercancel" || cancelledSwipeRef.current) {
			setResolvedDragOffset({
				x: resolvedInitialTransform.x,
				y: resolvedInitialTransform.y
			});
			setCurrentSwipeDirection(void 0);
			return;
		}
		const resolvedDragOffset = dragOffsetRef.current;
		const deltaX = resolvedDragOffset.x - resolvedInitialTransform.x;
		const deltaY = resolvedDragOffset.y - resolvedInitialTransform.y;
		let dismissDirection;
		for (const direction of swipeDirections) if (getDisplacement(direction, deltaX, deltaY) > SWIPE_THRESHOLD) {
			dismissDirection = direction;
			break;
		}
		if (dismissDirection) {
			setCurrentSwipeDirection(dismissDirection);
			store.closeToast(toast.id);
		} else {
			setResolvedDragOffset({
				x: resolvedInitialTransform.x,
				y: resolvedInitialTransform.y
			});
			setCurrentSwipeDirection(void 0);
		}
	});
	function handlePointerDown(event) {
		if (event.button !== 0) return;
		if (event.pointerType === "touch") store.pauseTimers();
		if (getTarget(event.nativeEvent)?.closest(`button,a,input,textarea,[role="button"],${TOAST_SWIPE_IGNORE_SELECTOR}`)) return;
		cancelledSwipeRef.current = false;
		intendedSwipeDirectionRef.current = void 0;
		maxSwipeDisplacementRef.current = 0;
		activePointerIdRef.current = event.pointerId;
		dragStartPosRef.current = {
			x: event.clientX,
			y: event.clientY
		};
		swipeCancelBaselineRef.current = dragStartPosRef.current;
		const element = event.currentTarget;
		const transform = getElementTransform(element);
		initialTransformRef.current = transform;
		setInitialTransform(transform);
		setResolvedDragOffset({
			x: transform.x,
			y: transform.y
		});
		store.set("hovering", true);
		setIsSwiping(true);
		setIsRealSwipe(false);
		setLockedDirection(null);
		isFirstPointerMoveRef.current = true;
		dragAbortControllerRef.current?.abort();
		const dragAbortController = new AbortController();
		dragAbortControllerRef.current = dragAbortController;
		const doc = ownerDocument(element);
		doc.addEventListener("pointerup", handleSwipeEnd, { signal: dragAbortController.signal });
		doc.addEventListener("pointercancel", handleSwipeEnd, { signal: dragAbortController.signal });
		element.setPointerCapture?.(event.pointerId);
	}
	function handlePointerMove(event) {
		if (event.pointerId !== activePointerIdRef.current) return;
		event.preventDefault();
		if (isFirstPointerMoveRef.current) {
			dragStartPosRef.current = {
				x: event.clientX,
				y: event.clientY
			};
			isFirstPointerMoveRef.current = false;
		}
		const { clientY, clientX, movementX, movementY } = event;
		if (movementY < 0 && clientY > swipeCancelBaselineRef.current.y || movementY > 0 && clientY < swipeCancelBaselineRef.current.y) swipeCancelBaselineRef.current = {
			x: swipeCancelBaselineRef.current.x,
			y: clientY
		};
		if (movementX < 0 && clientX > swipeCancelBaselineRef.current.x || movementX > 0 && clientX < swipeCancelBaselineRef.current.x) swipeCancelBaselineRef.current = {
			x: clientX,
			y: swipeCancelBaselineRef.current.y
		};
		const deltaX = clientX - dragStartPosRef.current.x;
		const deltaY = clientY - dragStartPosRef.current.y;
		const cancelDeltaY = clientY - swipeCancelBaselineRef.current.y;
		const cancelDeltaX = clientX - swipeCancelBaselineRef.current.x;
		let resolvedLockedDirection = lockedDirection;
		if (!isRealSwipe) {
			if (Math.sqrt(deltaX * deltaX + deltaY * deltaY) >= MIN_DRAG_THRESHOLD) {
				setIsRealSwipe(true);
				const hasHorizontal = swipeDirections.includes("left") || swipeDirections.includes("right");
				const hasVertical = swipeDirections.includes("up") || swipeDirections.includes("down");
				if (hasHorizontal && hasVertical) {
					resolvedLockedDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "horizontal" : "vertical";
					setLockedDirection(resolvedLockedDirection);
				}
			}
		}
		let candidate;
		if (!intendedSwipeDirectionRef.current) {
			if (resolvedLockedDirection === "vertical") {
				if (deltaY > 0) candidate = "down";
				else if (deltaY < 0) candidate = "up";
			} else if (resolvedLockedDirection === "horizontal") {
				if (deltaX > 0) candidate = "right";
				else if (deltaX < 0) candidate = "left";
			} else if (Math.abs(deltaX) >= Math.abs(deltaY)) candidate = deltaX > 0 ? "right" : "left";
			else candidate = deltaY > 0 ? "down" : "up";
			if (candidate && swipeDirections.includes(candidate)) {
				intendedSwipeDirectionRef.current = candidate;
				maxSwipeDisplacementRef.current = getDisplacement(candidate, deltaX, deltaY);
				setCurrentSwipeDirection(candidate);
			}
		} else {
			const direction = intendedSwipeDirectionRef.current;
			const currentDisplacement = getDisplacement(direction, cancelDeltaX, cancelDeltaY);
			if (currentDisplacement > SWIPE_THRESHOLD) {
				cancelledSwipeRef.current = false;
				setCurrentSwipeDirection(direction);
			} else if (!(swipeDirections.includes("left") && swipeDirections.includes("right")) && !(swipeDirections.includes("up") && swipeDirections.includes("down")) && maxSwipeDisplacementRef.current - currentDisplacement >= REVERSE_CANCEL_THRESHOLD) cancelledSwipeRef.current = true;
		}
		const dampedDelta = applyDirectionalDamping(deltaX, deltaY);
		let newOffsetX = initialTransformRef.current.x;
		let newOffsetY = initialTransformRef.current.y;
		const hasHorizontalDir = swipeDirections.includes("left") || swipeDirections.includes("right");
		const hasVerticalDir = swipeDirections.includes("up") || swipeDirections.includes("down");
		if (resolvedLockedDirection !== "vertical" && hasHorizontalDir) newOffsetX += dampedDelta.x;
		if (resolvedLockedDirection !== "horizontal" && hasVerticalDir) newOffsetY += dampedDelta.y;
		setResolvedDragOffset({
			x: newOffsetX,
			y: newOffsetY
		});
	}
	function handleKeyDown(event) {
		if (event.key === "Escape") {
			if (!rootRef.current || !contains(rootRef.current, activeElement(ownerDocument(rootRef.current)))) return;
			store.closeToast(toast.id);
		}
	}
	import_react.useEffect(() => {
		const element = rootRef.current;
		if (!swipeEnabled || !element) return;
		function preventDefaultTouchStart(event) {
			if (activePointerIdRef.current === null || !contains(element, getTarget(event))) return;
			event.preventDefault();
		}
		return addEventListener(element, "touchmove", preventDefaultTouchStart, { passive: false });
	}, [swipeEnabled]);
	function getDragStyles() {
		const deltaX = dragOffset.x - initialTransform.x;
		const deltaY = dragOffset.y - initialTransform.y;
		return {
			transition: isSwiping ? "none" : void 0,
			transform: isSwiping ? `translateX(${dragOffset.x}px) translateY(${dragOffset.y}px) scale(${initialTransform.scale})` : void 0,
			["--toast-swipe-movement-x"]: `${deltaX}px`,
			["--toast-swipe-movement-y"]: `${deltaY}px`
		};
	}
	const isHighPriority = toast.priority === "high";
	const defaultProps = {
		role: isHighPriority ? "alertdialog" : "dialog",
		tabIndex: 0,
		"aria-modal": false,
		"aria-labelledby": titleId,
		"aria-describedby": descriptionId,
		"aria-hidden": isHighPriority && !focused ? true : void 0,
		onPointerDown: swipeEnabled ? handlePointerDown : void 0,
		onPointerMove: swipeEnabled ? handlePointerMove : void 0,
		onPointerUp: swipeEnabled ? handleSwipeEnd : void 0,
		onPointerCancel: swipeEnabled ? handleSwipeEnd : void 0,
		onKeyDown: handleKeyDown,
		inert: inertValue(toast.limited),
		style: {
			...getDragStyles(),
			["--toast-index"]: toast.transitionStatus === "ending" ? domIndex : visibleIndex,
			["--toast-offset-y"]: `${offsetY}px`,
			["--toast-height"]: toast.height ? `${toast.height}px` : void 0
		}
	};
	const toastRoot = import_react.useMemo(() => ({
		toast,
		setTitleId,
		setDescriptionId,
		recalculateHeight,
		visibleIndex,
		expanded
	}), [
		toast,
		setTitleId,
		setDescriptionId,
		recalculateHeight,
		visibleIndex,
		expanded
	]);
	const state = {
		transitionStatus: toast.transitionStatus,
		expanded,
		limited: toast.limited || false,
		type: toast.type,
		swiping: isSwiping,
		swipeDirection: currentSwipeDirection
	};
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, rootRef],
		state,
		stateAttributesMapping: toastRootStateAttributesMapping,
		props: [defaultProps, elementProps]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ToastRootContext.Provider, {
		value: toastRoot,
		children: element
	});
});
ToastRoot.displayName = "ToastRoot";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/content/ToastContent.mjs
/**
* A container for the contents of a toast.
* Renders a `<div>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastContent = /*#__PURE__*/ import_react.forwardRef(function ToastContent(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { visibleIndex, expanded, recalculateHeight } = useToastRootContext();
	const contentRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		recalculateHeight();
		const node = contentRef.current;
		if (!node || typeof ResizeObserver !== "function" || typeof MutationObserver !== "function") return;
		const resizeObserver = new ResizeObserver(() => recalculateHeight(true));
		const mutationObserver = new MutationObserver(() => recalculateHeight(true));
		resizeObserver.observe(node);
		mutationObserver.observe(node, {
			childList: true,
			subtree: true,
			characterData: true
		});
		return () => {
			resizeObserver.disconnect();
			mutationObserver.disconnect();
		};
	}, [recalculateHeight]);
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, contentRef],
		state: {
			expanded,
			behind: visibleIndex > 0
		},
		props: elementProps
	});
});
ToastContent.displayName = "ToastContent";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/utils/isRenderableNode.mjs
function isRenderableNode(node) {
	if (node == null || typeof node === "boolean" || node === "") return false;
	if (Array.isArray(node)) return node.some(isRenderableNode);
	return true;
}
function hasRenderableChildren(element) {
	return /*#__PURE__*/ import_react.isValidElement(element) && isRenderableNode(element.props.children);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/utils/useToastLabelPart.mjs
/**
* Shared logic for `Toast.Title` and `Toast.Description`, which only differ by the rendered tag,
* the fallback content, and which id setter they register with. Resolves the content and returns
* the pieces each part passes to `useRenderElement` and `useToastLabelElement`.
*/
function useToastLabelPart(idProp, childrenProp, part) {
	const { toast, setTitleId, setDescriptionId } = useToastRootContext();
	const setId = part === "title" ? setTitleId : setDescriptionId;
	const children = childrenProp ?? (part === "title" ? toast.title : toast.description);
	return {
		id: useId(idProp),
		children,
		type: toast.type,
		setId
	};
}
/**
* Mounts the evaluated label element only when it carries renderable content (so a `render` prop's
* own children count, while a childless styling-only `render` stays conditional), registering the
* generated id with the root while the part renders.
*/
function useToastLabelElement(element, id, setId) {
	const shouldRender = hasRenderableChildren(element);
	useIsoLayoutEffect(() => {
		if (!shouldRender) return;
		setId(id);
		return () => {
			setId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [
		shouldRender,
		id,
		setId
	]);
	return shouldRender ? element : null;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/description/ToastDescription.mjs
/**
* A description that describes the toast.
* Can be used as the default message for the toast when no title is provided.
* Renders a `<p>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastDescription = /*#__PURE__*/ import_react.forwardRef(function ToastDescription(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, children: childrenProp, ...elementProps } = componentProps;
	const { id, children, type, setId } = useToastLabelPart(idProp, childrenProp, "description");
	return useToastLabelElement(useRenderElement("p", componentProps, {
		ref: forwardedRef,
		state: { type },
		props: {
			...elementProps,
			id,
			children
		}
	}), id, setId);
});
ToastDescription.displayName = "ToastDescription";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/title/ToastTitle.mjs
/**
* A title that labels the toast.
* Renders an `<h2>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastTitle = /*#__PURE__*/ import_react.forwardRef(function ToastTitle(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, children: childrenProp, ...elementProps } = componentProps;
	const { id, children, type, setId } = useToastLabelPart(idProp, childrenProp, "title");
	return useToastLabelElement(useRenderElement("h2", componentProps, {
		ref: forwardedRef,
		state: { type },
		props: {
			...elementProps,
			id,
			children
		}
	}), id, setId);
});
ToastTitle.displayName = "ToastTitle";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/close/ToastClose.mjs
/**
* Closes the toast when clicked.
* Renders a `<button>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastClose = /*#__PURE__*/ import_react.forwardRef(function ToastClose(componentProps, forwardedRef) {
	const { render, className, style, disabled, nativeButton = true, ...elementProps } = componentProps;
	const store = useToastProviderContext();
	const { toast, expanded } = useToastRootContext();
	const [hasFocus, setHasFocus] = import_react.useState(false);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = { type: toast.type };
	return useRenderElement("button", componentProps, {
		ref: [forwardedRef, buttonRef],
		state,
		props: [
			{
				"aria-hidden": !expanded && !hasFocus,
				onClick() {
					store.closeToast(toast.id);
				},
				onFocus() {
					setHasFocus(true);
				},
				onBlur() {
					setHasFocus(false);
				}
			},
			elementProps,
			getButtonProps
		]
	});
});
ToastClose.displayName = "ToastClose";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/action/ToastAction.mjs
/**
* Performs an action when clicked.
* Renders a `<button>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastAction = /*#__PURE__*/ import_react.forwardRef(function ToastAction(componentProps, forwardedRef) {
	const { render, className, style, disabled, nativeButton = true, ...elementProps } = componentProps;
	const { toast } = useToastRootContext();
	const computedChildren = toast.actionProps?.children ?? elementProps.children;
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = { type: toast.type };
	const element = useRenderElement("button", componentProps, {
		ref: [forwardedRef, buttonRef],
		state,
		props: [
			elementProps,
			toast.actionProps,
			getButtonProps,
			{ children: computedChildren }
		]
	});
	return hasRenderableChildren(element) ? element : null;
});
ToastAction.displayName = "ToastAction";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/portal/ToastPortal.mjs
/**
* A portal element that moves the viewport to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastPortal = /*#__PURE__*/ import_react.forwardRef(function ToastPortal(props, forwardedRef) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortalLite, {
		ref: forwardedRef,
		...props
	});
});
ToastPortal.displayName = "ToastPortal";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/positioner/ToastPositionerContext.mjs
var ToastPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
ToastPositionerContext.displayName = "ToastPositionerContext";
function useToastPositionerContext() {
	const context = import_react.useContext(ToastPositionerContext);
	if (context === void 0) throw new Error("Base UI: ToastPositionerContext is missing. ToastPositioner parts must be placed within <Toast.Positioner>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/positioner/ToastPositioner.mjs
/**
* Positions the toast against the anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastPositioner = /*#__PURE__*/ import_react.forwardRef(function ToastPositioner(componentProps, forwardedRef) {
	const { toast, ...props } = componentProps;
	const store = useToastProviderContext();
	const positionerProps = toast.positionerProps ?? EMPTY_OBJECT;
	const { render, className, anchor: anchorProp = positionerProps.anchor, positionMethod = positionerProps.positionMethod ?? "absolute", side = positionerProps.side ?? "top", align = positionerProps.align ?? "center", sideOffset = positionerProps.sideOffset ?? 0, alignOffset = positionerProps.alignOffset ?? 0, collisionBoundary = positionerProps.collisionBoundary ?? "clipping-ancestors", collisionPadding = positionerProps.collisionPadding ?? 5, arrowPadding = positionerProps.arrowPadding ?? 5, sticky = positionerProps.sticky ?? false, disableAnchorTracking = positionerProps.disableAnchorTracking ?? false, collisionAvoidance = positionerProps.collisionAvoidance ?? POPUP_COLLISION_AVOIDANCE, style, ...elementProps } = props;
	const [positionerElement, setPositionerElement] = import_react.useState(null);
	const domIndex = store.useState("toastIndex", toast.id);
	const visibleIndex = store.useState("toastVisibleIndex", toast.id);
	const anchor = isElement(anchorProp) ? anchorProp : null;
	const positioning = useAnchorPositioning({
		anchor,
		positionMethod,
		floatingRootContext: useFloatingRootContext({
			open: true,
			onOpenChange: NOOP,
			elements: {
				floating: positionerElement,
				reference: anchor
			}
		}),
		mounted: true,
		side,
		sideOffset,
		align,
		alignOffset,
		collisionBoundary,
		collisionPadding,
		sticky,
		arrowPadding,
		disableAnchorTracking,
		keepMounted: true,
		collisionAvoidance
	});
	const element = usePositioner(componentProps, {
		side: positioning.side,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden
	}, {
		styles: {
			...positioning.positionerStyles,
			["--toast-index"]: toast.transitionStatus === "ending" ? domIndex : visibleIndex
		},
		transitionStatus: toast.transitionStatus,
		props: elementProps,
		refs: [forwardedRef, setPositionerElement]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ToastPositionerContext.Provider, {
		value: positioning,
		children: element
	});
});
ToastPositioner.displayName = "ToastPositioner";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/arrow/ToastArrow.mjs
/**
* Displays an element positioned against the toast anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Toast](https://base-ui.com/react/components/toast)
*/
var ToastArrow = /*#__PURE__*/ import_react.forwardRef(function ToastArrow(componentProps, forwardedRef) {
	const { className, render, style, ...elementProps } = componentProps;
	const { arrowRef, side, align, arrowUncentered, arrowStyles } = useToastPositionerContext();
	return useRenderElement("div", componentProps, {
		state: {
			side,
			align,
			uncentered: arrowUncentered
		},
		ref: [forwardedRef, arrowRef],
		props: [{
			style: arrowStyles,
			"aria-hidden": true
		}, elementProps]
	});
});
ToastArrow.displayName = "ToastArrow";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/useToastManager.mjs
/**
* Returns the array of toasts and methods to manage them.
*/
function useToastManager() {
	const store = useToastProviderContext();
	const toasts = store.useState("toasts");
	return import_react.useMemo(() => ({
		toasts,
		add: store.addToast,
		close: store.closeToast,
		update: store.updateToast,
		promise: store.promiseToast
	}), [toasts, store]);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/createToastManager.mjs
/**
* Creates a new toast manager.
*/
function createToastManager() {
	const listeners = /* @__PURE__ */ new Set();
	function emit(data) {
		listeners.forEach((listener) => listener(data));
	}
	return {
		" subscribe": function subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		add(options) {
			const id = options.id || generateId("toast");
			emit({
				action: "add",
				options: {
					...options,
					id,
					transitionStatus: "starting"
				}
			});
			return id;
		},
		close(id) {
			emit({
				action: "close",
				options: { id }
			});
		},
		update(id, updates) {
			emit({
				action: "update",
				options: {
					...updates,
					id
				}
			});
		},
		promise(promiseValue, options) {
			let handledPromise = promiseValue;
			emit({
				action: "promise",
				options: {
					...options,
					promise: promiseValue,
					setPromise(promise) {
						handledPromise = promise;
					}
				}
			});
			return handledPromise;
		}
	};
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toast/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Action: () => ToastAction,
	Arrow: () => ToastArrow,
	Close: () => ToastClose,
	Content: () => ToastContent,
	Description: () => ToastDescription,
	Portal: () => ToastPortal,
	Positioner: () => ToastPositioner,
	Provider: () => ToastProvider,
	Root: () => ToastRoot,
	Title: () => ToastTitle,
	Viewport: () => ToastViewport,
	createToastManager: () => createToastManager,
	useToastManager: () => useToastManager
});
//#endregion
export { index_parts_exports as Toast };
