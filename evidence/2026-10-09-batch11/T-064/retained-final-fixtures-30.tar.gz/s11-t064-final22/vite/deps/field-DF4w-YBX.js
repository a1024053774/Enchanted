import { i as __toESM, n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { C as useIsoLayoutEffect, n as useStableCallback, r as SafeReact } from "./useId-Cfrl5XdH.js";
import { t as ownerDocument } from "./owner-BmKt4Bpq.js";
import { l as useRefWithInit, s as EMPTY_OBJECT, t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { n as useTimeout } from "./useTimeout-CHZlR9Tr.js";
import { t as activeElement } from "./shadowDom-CQZHMuh3.js";
import { t as createChangeEventDetails, v as none } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { r as mergeProps } from "./merge-props-BSY6QP_a.js";
import { n as transitionStatusMapping, r as useOpenChangeComplete } from "./stateAttributesMapping-DKWbKMwM.js";
import { t as useTransitionStatus } from "./useTransitionStatus-DmfddCng.js";
import { t as error } from "./error-scG2ld3p.js";
import { t as useBaseUiId } from "./useBaseUiId-BBG3KkG2.js";
import { t as useControlled } from "./useControlled-tPZe1TD5.js";
import { i as useRegisterFieldControl, l as DEFAULT_VALIDITY_STATE, n as useLabelableContext, o as FieldRootContext, r as useFormContext, s as useFieldRootContext, t as LabelableContext, u as fieldValidityMapping } from "./LabelableContext-CdYnDOEr.js";
import { t as useLabelableId } from "./useLabelableId-DmWnMHl6.js";
import { n as useFieldItemContext, t as FieldItemContext } from "./FieldItemContext-DX7Le6Rm.js";
import { n as useLabel } from "./useLabel-C0H9kumO.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/fieldset/root/FieldsetRootContext.mjs
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var FieldsetRootContext = /*#__PURE__*/ import_react.createContext(void 0);
FieldsetRootContext.displayName = "FieldsetRootContext";
function useFieldsetRootContext(optional = false) {
	const context = import_react.useContext(FieldsetRootContext);
	if (!context && !optional) throw new Error("Base UI: FieldsetRootContext is missing. Fieldset parts must be placed within <Fieldset.Root>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/labelable-provider/LabelableProvider.mjs
var LabelableProvider = function LabelableProvider(props) {
	const defaultId = useBaseUiId();
	const initialControlId = props.controlId === void 0 ? defaultId : props.controlId;
	const [controlId, setControlIdState] = import_react.useState(initialControlId);
	const [labelId, setLabelId] = import_react.useState(props.labelId);
	const [messageIds, setMessageIds] = import_react.useState([]);
	const registrationsRef = useRefWithInit(() => /* @__PURE__ */ new Map());
	const { messageIds: parentMessageIds } = useLabelableContext();
	const registerControlId = useStableCallback((source, nextId) => {
		const registrations = registrationsRef.current;
		if (nextId === void 0) {
			registrations.delete(source);
			return;
		}
		registrations.set(source, nextId);
		setControlIdState((prev) => {
			if (registrations.size === 0) return;
			let nextControlId;
			for (const id of registrations.values()) {
				if (prev !== void 0 && id === prev) return prev;
				if (nextControlId === void 0) nextControlId = id;
			}
			return nextControlId;
		});
	});
	const getDescriptionProps = import_react.useCallback((externalProps) => {
		const ids = externalProps["aria-describedby"] ? externalProps["aria-describedby"].split(" ") : [];
		ids.push(...parentMessageIds, ...messageIds);
		return {
			...externalProps,
			"aria-describedby": Array.from(new Set(ids)).join(" ") || void 0
		};
	}, [parentMessageIds, messageIds]);
	const contextValue = import_react.useMemo(() => ({
		controlId,
		registerControlId,
		labelId,
		setLabelId,
		messageIds,
		setMessageIds,
		getDescriptionProps
	}), [
		controlId,
		registerControlId,
		labelId,
		setLabelId,
		messageIds,
		setMessageIds,
		getDescriptionProps
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(LabelableContext.Provider, {
		value: contextValue,
		children: props.children
	});
};
LabelableProvider.displayName = "LabelableProvider";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/utils/getCombinedFieldValidityData.mjs
/**
* Combines the field's client-side, stateful validity data with the external invalid state to
* determine the field's true validity.
*/
function getCombinedFieldValidityData(validityData, invalid) {
	return {
		...validityData,
		state: {
			...validityData.state,
			valid: !invalid && validityData.state.valid
		}
	};
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/root/useFieldValidation.mjs
var validityKeys = Object.keys(DEFAULT_VALIDITY_STATE);
/**
* Whether an input participates in the surrounding Base UI Form. Inputs that are effectively
* disabled, or whose `form` attribute explicitly associates them with another form, are excluded.
* DOM position only matters when it associates the input with a different form. Otherwise, field
* registration is context-driven, so portaled inputs (for example inside a dialog) still belong to
* the form for both validation and values projected into `onFormSubmit`.
*/
function isEligibleInput(input, formElement) {
	if (input.matches(":disabled")) return false;
	if (!formElement || input.form === formElement) return true;
	return input.form === null && !input.hasAttribute("form");
}
/**
* Picks the input whose native validity should represent a field that owns several inputs (such as a
* checkbox or radio group). Prefers the first eligible currently-invalid input, where "first" follows
* registration order (mount order), and otherwise returns the first eligible input.
*/
function findRepresentativeInput(inputs, formElement) {
	let fallback = null;
	for (const input of inputs.keys()) {
		if (!isEligibleInput(input, formElement)) continue;
		if (!input.validity.valid) return input;
		fallback ??= input;
	}
	return fallback;
}
function clearCustomValidity(element, inputs) {
	for (const input of inputs.keys()) input.setCustomValidity("");
	element?.setCustomValidity("");
}
function useFieldValidation(params) {
	const { elementRef, formRef } = useFormContext();
	const { setValidityData, validate, validityData, validationDebounceTime, invalid, markedDirtyRef, state, shouldValidateOnChange, registeredFieldIdRef } = params;
	const { controlId, getDescriptionProps } = useLabelableContext();
	const timeout = useTimeout();
	const inputRef = import_react.useRef(null);
	const registeredInputs = useRefWithInit(() => /* @__PURE__ */ new Map()).current;
	const validationCommitIdRef = import_react.useRef(0);
	const registerInput = import_react.useCallback((element, registration) => {
		registeredInputs.set(element, registration);
		return () => {
			registeredInputs.delete(element);
		};
	}, [registeredInputs]);
	const getInputControl = useStableCallback(() => {
		const element = findRepresentativeInput(registeredInputs, elementRef.current);
		return element && registeredInputs.get(element)?.controlRef.current || null;
	});
	const commit = useStableCallback(async (value, revalidate = false) => {
		validationCommitIdRef.current += 1;
		const validationCommitId = validationCommitIdRef.current;
		function updateRegisteredFieldValidity(nextValidityData, externalInvalid = invalid) {
			const fieldId = registeredFieldIdRef.current ?? controlId;
			if (fieldId == null) return;
			const currentFieldData = formRef.current.fields.get(fieldId);
			if (!currentFieldData) return;
			const validityDataWithFormErrors = getCombinedFieldValidityData(nextValidityData, externalInvalid);
			formRef.current.fields.set(fieldId, {
				...currentFieldData,
				validityData: validityDataWithFormErrors
			});
		}
		function publishAllValid(input, externalInvalid) {
			const nextValidityData = {
				value,
				state: {
					...DEFAULT_VALIDITY_STATE,
					valid: true
				},
				error: "",
				errors: [],
				initialValue: validityData.initialValue
			};
			clearCustomValidity(input, registeredInputs);
			updateRegisteredFieldValidity(nextValidityData, externalInvalid);
			setValidityData(nextValidityData);
		}
		const element = registeredInputs.size > 0 ? findRepresentativeInput(registeredInputs, elementRef.current) : inputRef.current;
		if (revalidate) {
			if (state.valid !== false || !element) return;
			const currentNativeValidity = element.validity;
			if (!currentNativeValidity.valueMissing) {
				publishAllValid(element, false);
				return;
			}
			for (const key of validityKeys) if (key !== "valid" && key !== "valueMissing" && key !== "customError" && currentNativeValidity[key]) return;
		}
		function getState(el) {
			const computedState = validityKeys.reduce((acc, key) => {
				acc[key] = el.validity[key];
				return acc;
			}, {});
			let hasOnlyValueMissingError = false;
			for (const key of validityKeys) {
				if (key === "valid") continue;
				if (key === "valueMissing" && computedState[key]) hasOnlyValueMissingError = true;
				else if (computedState[key]) return computedState;
			}
			if (hasOnlyValueMissingError && !markedDirtyRef.current) {
				computedState.valid = true;
				computedState.valueMissing = false;
			}
			return computedState;
		}
		timeout.clear();
		let result = null;
		let validationErrors = [];
		const nextState = element ? getState(element) : {
			...DEFAULT_VALIDITY_STATE,
			valid: true
		};
		let defaultValidationMessage;
		const isValidatingOnChange = shouldValidateOnChange();
		if (element && element.validationMessage && !isValidatingOnChange) {
			defaultValidationMessage = element.validationMessage;
			validationErrors = [element.validationMessage];
		} else {
			const formValues = Array.from(formRef.current.fields.values()).reduce((acc, field) => {
				if (field.name) acc[field.name] = field.getValue();
				return acc;
			}, {});
			const resultOrPromise = validate(value, formValues);
			if (typeof resultOrPromise === "object" && resultOrPromise !== null && "then" in resultOrPromise) {
				result = await resultOrPromise;
				if (validationCommitId !== validationCommitIdRef.current) return;
			} else result = resultOrPromise;
			if (result !== null) {
				nextState.valid = false;
				nextState.customError = true;
				if (Array.isArray(result)) {
					validationErrors = result;
					element?.setCustomValidity(result.join("\n"));
				} else if (result) {
					validationErrors = [result];
					element?.setCustomValidity(result);
				}
			} else if (isValidatingOnChange) {
				clearCustomValidity(element, registeredInputs);
				nextState.customError = false;
				if (element && element.validationMessage) {
					defaultValidationMessage = element.validationMessage;
					validationErrors = [element.validationMessage];
				} else if ((!element || element.validity.valid) && !nextState.valid) nextState.valid = true;
			}
		}
		const nextValidityData = {
			value,
			state: nextState,
			error: defaultValidationMessage ?? (Array.isArray(result) ? result[0] : result ?? ""),
			errors: validationErrors,
			initialValue: validityData.initialValue
		};
		updateRegisteredFieldValidity(nextValidityData);
		setValidityData(nextValidityData);
	});
	const change = useStableCallback((value) => {
		timeout.clear();
		const validateOnChange = shouldValidateOnChange();
		if (validateOnChange && value !== "" && validationDebounceTime) {
			validationCommitIdRef.current += 1;
			timeout.start(validationDebounceTime, () => {
				commit(value);
			});
		} else commit(value, !validateOnChange);
	});
	const getValidationProps = import_react.useCallback((disabled, externalProps = {}) => mergeProps(getDescriptionProps(externalProps), state.valid === false && !state.disabled && !disabled ? { "aria-invalid": true } : EMPTY_OBJECT), [
		getDescriptionProps,
		state.disabled,
		state.valid
	]);
	return import_react.useMemo(() => ({
		getValidationProps,
		inputRef,
		registeredInputs,
		registerInput,
		getInputControl,
		commit,
		change
	}), [
		getValidationProps,
		registeredInputs,
		registerInput,
		getInputControl,
		commit,
		change
	]);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/field-register-control/useFieldControlRegistration.mjs
function useFieldControlRegistration(params) {
	const { commit, invalid, markedDirtyRef, name, setRegisteredFieldName, registeredFieldIdRef, setValidityData, validityData } = params;
	const { formRef } = useFormContext();
	const activeFieldControlSourceRef = import_react.useRef(null);
	const registrationRef = import_react.useRef(null);
	const initialValueCapturedRef = import_react.useRef(false);
	const getValueForForm = useStableCallback(() => {
		const registration = registrationRef.current;
		if (!registration) return;
		if (registration.getValue) return registration.getValue();
		return registration.value;
	});
	function getRegistrationValue(registration) {
		return registration.value === void 0 ? getValueForForm() : registration.value;
	}
	const validate = useStableCallback(() => {
		const registration = registrationRef.current;
		markedDirtyRef.current = true;
		if (!registration) {
			commit(validityData.value);
			return;
		}
		commit(getRegistrationValue(registration));
	});
	function refreshRegistration() {
		const registration = registrationRef.current;
		if (!registration || !registration.id) return;
		formRef.current.fields.set(registration.id, {
			getValue: getValueForForm,
			name: name ?? registration.name,
			controlRef: registration.controlRef,
			validityData: getCombinedFieldValidityData(validityData, invalid),
			validate
		});
	}
	function deleteRegistration(id = registrationRef.current?.id) {
		if (id) formRef.current.fields.delete(id);
	}
	function captureInitialValue(registration) {
		if (initialValueCapturedRef.current) return;
		initialValueCapturedRef.current = true;
		const initialValue = getRegistrationValue(registration);
		setValidityData((prev) => prev.initialValue === initialValue ? prev : {
			...prev,
			initialValue
		});
	}
	useIsoLayoutEffect(() => {
		const registration = registrationRef.current;
		if (!registration || !registration.id) return;
		setRegisteredFieldName(name ? void 0 : registration.name);
		formRef.current.fields.set(registration.id, {
			getValue: getValueForForm,
			name: name ?? registration.name,
			controlRef: registration.controlRef,
			validityData: getCombinedFieldValidityData(validityData, invalid),
			validate
		});
	}, [
		formRef,
		getValueForForm,
		invalid,
		name,
		setRegisteredFieldName,
		validate,
		validityData
	]);
	useIsoLayoutEffect(() => {
		const fields = formRef.current.fields;
		return () => {
			const id = registrationRef.current?.id;
			if (id) fields.delete(id);
		};
	}, [formRef]);
	return [validate, useStableCallback((source, registration) => {
		if (!registration) {
			if (activeFieldControlSourceRef.current === source) {
				activeFieldControlSourceRef.current = null;
				deleteRegistration();
				registrationRef.current = null;
				setRegisteredFieldName(void 0);
				registeredFieldIdRef.current = void 0;
			}
			return;
		}
		const previousId = registrationRef.current?.id;
		activeFieldControlSourceRef.current = source;
		registrationRef.current = registration;
		if (!name) setRegisteredFieldName(registration.name);
		registeredFieldIdRef.current = registration.id;
		if (previousId && previousId !== registration.id) deleteRegistration(previousId);
		captureInitialValue(registration);
		refreshRegistration();
	})];
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/root/FieldRoot.mjs
/**
* @internal
*/
var FieldRootInner = /*#__PURE__*/ import_react.forwardRef(function FieldRootInner(componentProps, forwardedRef) {
	const { errors, validationMode: formValidationMode, submitAttemptedRef } = useFormContext();
	const { render, className, validate: validateProp, validationDebounceTime = 0, validationMode = formValidationMode, name, disabled: disabledProp = false, invalid: invalidProp, dirty: dirtyProp, touched: touchedProp, actionsRef, style, ...elementProps } = componentProps;
	const disabledFieldset = useFieldsetRootContext(true)?.disabled;
	const validate = useStableCallback(validateProp || (() => null));
	const disabled = disabledFieldset || disabledProp;
	const [touchedState, setTouchedUnwrapped] = import_react.useState(false);
	const [dirtyState, setDirtyUnwrapped] = import_react.useState(false);
	const [filled, setFilled] = import_react.useState(false);
	const [focused, setFocused] = import_react.useState(false);
	const dirty = dirtyProp ?? dirtyState;
	const touched = touchedProp ?? touchedState;
	const markedDirtyRef = import_react.useRef(dirty);
	const registeredFieldIdRef = import_react.useRef(void 0);
	const [registeredFieldName, setRegisteredFieldName] = import_react.useState();
	const effectiveName = name ?? registeredFieldName;
	useIsoLayoutEffect(() => {
		if (dirtyProp !== void 0) markedDirtyRef.current = dirtyProp;
	}, [dirtyProp]);
	const setDirty = useStableCallback((value) => {
		if (dirtyProp !== void 0) return;
		if (value) markedDirtyRef.current = true;
		setDirtyUnwrapped(value);
	});
	const setTouched = useStableCallback((value) => {
		if (touchedProp !== void 0) return;
		setTouchedUnwrapped(value);
	});
	const shouldValidateOnChange = useStableCallback(() => validationMode === "onChange" || validationMode === "onSubmit" && submitAttemptedRef.current);
	const formError = effectiveName && Object.hasOwn(errors, effectiveName) ? errors[effectiveName] : null;
	const hasFormError = !!(Array.isArray(formError) ? formError.length : formError);
	const invalid = invalidProp === true || hasFormError;
	const [validityData, setValidityData] = import_react.useState({
		state: DEFAULT_VALIDITY_STATE,
		error: "",
		errors: [],
		value: null,
		initialValue: null
	});
	const valid = !invalid && (disabled ? null : validityData.state.valid);
	const state = import_react.useMemo(() => ({
		disabled,
		touched,
		dirty,
		valid,
		filled,
		focused
	}), [
		disabled,
		touched,
		dirty,
		valid,
		filled,
		focused
	]);
	const validation = useFieldValidation({
		setValidityData,
		validate,
		validityData,
		validationDebounceTime,
		invalid,
		markedDirtyRef,
		state,
		shouldValidateOnChange,
		registeredFieldIdRef
	});
	const [validateFieldControl, registerFieldControl] = useFieldControlRegistration({
		commit: validation.commit,
		invalid,
		markedDirtyRef,
		name,
		setRegisteredFieldName,
		registeredFieldIdRef,
		setValidityData,
		validityData
	});
	import_react.useImperativeHandle(actionsRef, () => ({ validate: validateFieldControl }), [validateFieldControl]);
	const contextValue = import_react.useMemo(() => ({
		invalid,
		name: effectiveName,
		validityData,
		setValidityData,
		disabled,
		setTouched,
		setDirty,
		setFilled,
		setFocused,
		validationMode,
		shouldValidateOnChange,
		state,
		registerFieldControl,
		validation
	}), [
		invalid,
		effectiveName,
		validityData,
		disabled,
		setTouched,
		setDirty,
		setFilled,
		setFocused,
		validationMode,
		shouldValidateOnChange,
		state,
		registerFieldControl,
		validation
	]);
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		state,
		props: elementProps,
		stateAttributesMapping: fieldValidityMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FieldRootContext.Provider, {
		value: contextValue,
		children: element
	});
});
FieldRootInner.displayName = "FieldRootInner";
var FieldRoot = /*#__PURE__*/ import_react.forwardRef(function FieldRoot(componentProps, forwardedRef) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(LabelableProvider, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FieldRootInner, {
		...componentProps,
		ref: forwardedRef
	}) });
});
FieldRoot.displayName = "FieldRoot";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/label/FieldLabel.mjs
/**
* An accessible label that is automatically associated with the field control.
* Renders a `<label>` element.
*
* Documentation: [Base UI Field](https://base-ui.com/react/components/field)
*/
var FieldLabel = /*#__PURE__*/ import_react.forwardRef(function FieldLabel(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, nativeLabel = true, ...elementProps } = componentProps;
	const fieldRootContext = useFieldRootContext(false);
	const fieldItemContext = useFieldItemContext();
	const { labelId } = useLabelableContext();
	const state = {
		...fieldRootContext.state,
		disabled: fieldRootContext.disabled || fieldItemContext.disabled
	};
	const labelRef = import_react.useRef(null);
	const labelProps = useLabel({
		id: labelId ?? idProp,
		native: nativeLabel
	});
	import_react.useEffect(() => {
		if (!labelRef.current) return;
		const isLabelTag = labelRef.current.tagName === "LABEL";
		if (nativeLabel) {
			if (!isLabelTag) error(`<Field.Label> expected a <label> element because the \`nativeLabel\` prop is true. Rendering a non-<label> disables native label association, so \`htmlFor\` will not work. Use a real <label> in the \`render\` prop, or set \`nativeLabel\` to \`false\`.${SafeReact.captureOwnerStack?.() || ""}`);
		} else if (isLabelTag) error(`<Field.Label> expected a non-<label> element because the \`nativeLabel\` prop is false. Rendering a <label> assumes native label behavior while Base UI treats it as non-native, which can cause unexpected pointer behavior. Use a non-<label> in the \`render\` prop, or set \`nativeLabel\` to \`true\`.${SafeReact.captureOwnerStack?.() || ""}`);
	}, [nativeLabel]);
	return useRenderElement("label", componentProps, {
		ref: [forwardedRef, labelRef],
		state,
		props: [labelProps, elementProps],
		stateAttributesMapping: fieldValidityMapping
	});
});
FieldLabel.displayName = "FieldLabel";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/error/FieldError.mjs
var stateAttributesMapping = {
	...fieldValidityMapping,
	...transitionStatusMapping
};
/**
* An error message displayed if the field control fails validation.
* Renders a `<div>` element.
*
* Documentation: [Base UI Field](https://base-ui.com/react/components/field)
*/
var FieldError = /*#__PURE__*/ import_react.forwardRef(function FieldError(componentProps, forwardedRef) {
	const { render, id: idProp, className, match, style, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const { validityData, state: fieldState, name } = useFieldRootContext(false);
	const { setMessageIds } = useLabelableContext();
	const { errors } = useFormContext();
	const formError = name && Object.hasOwn(errors, name) ? errors[name] : null;
	const hasFormError = !!(Array.isArray(formError) ? formError.length : formError);
	const hasSpecificMatch = typeof match === "string";
	let rendered = false;
	if (match === true) rendered = true;
	else if (fieldState.disabled) rendered = false;
	else if (hasSpecificMatch) rendered = Boolean(validityData.state[match]);
	else rendered = hasFormError || validityData.state.valid === false;
	const { mounted, transitionStatus, setMounted } = useTransitionStatus(rendered);
	useIsoLayoutEffect(() => {
		if (!rendered || !id) return;
		setMessageIds((v) => v.concat(id));
		return () => {
			setMessageIds((v) => v.filter((item) => item !== id));
		};
	}, [
		rendered,
		id,
		setMessageIds
	]);
	const errorRef = import_react.useRef(null);
	const [lastRenderedMessage, setLastRenderedMessage] = import_react.useState(null);
	const [lastRenderedMessageKey, setLastRenderedMessageKey] = import_react.useState(null);
	let error = validityData.error;
	if (!hasSpecificMatch && hasFormError) error = formError;
	else if (validityData.errors.length > 1) error = validityData.errors;
	let errorMessage = error;
	if (Array.isArray(error)) errorMessage = error.length > 1 ? /*#__PURE__*/ (0, import_jsx_runtime.jsx)("ul", { children: error.map((message) => /*#__PURE__*/ (0, import_jsx_runtime.jsx)("li", { children: message }, message)) }) : error[0];
	const errorKey = Array.isArray(error) ? JSON.stringify(error) : error;
	if (rendered && errorKey !== lastRenderedMessageKey) {
		setLastRenderedMessageKey(errorKey);
		setLastRenderedMessage(errorMessage);
	}
	useOpenChangeComplete({
		open: rendered,
		ref: errorRef,
		onComplete() {
			if (!rendered) setMounted(false);
		}
	});
	const state = {
		...fieldState,
		transitionStatus
	};
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, errorRef],
		state,
		props: [{
			id,
			children: rendered ? errorMessage : lastRenderedMessage
		}, elementProps],
		stateAttributesMapping,
		enabled: mounted
	});
	if (!mounted) return null;
	return element;
});
FieldError.displayName = "FieldError";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/description/FieldDescription.mjs
/**
* A paragraph with additional information about the field.
* Renders a `<p>` element.
*
* Documentation: [Base UI Field](https://base-ui.com/react/components/field)
*/
var FieldDescription = /*#__PURE__*/ import_react.forwardRef(function FieldDescription(componentProps, forwardedRef) {
	const { render, id: idProp, className, style, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const fieldRootContext = useFieldRootContext(false);
	const fieldItemContext = useFieldItemContext();
	const { setMessageIds } = useLabelableContext();
	const state = {
		...fieldRootContext.state,
		disabled: fieldRootContext.disabled || fieldItemContext.disabled
	};
	useIsoLayoutEffect(() => {
		if (!id) return;
		setMessageIds((v) => v.concat(id));
		return () => {
			setMessageIds((v) => v.filter((item) => item !== id));
		};
	}, [id, setMessageIds]);
	return useRenderElement("p", componentProps, {
		ref: forwardedRef,
		state,
		props: [{ id }, elementProps],
		stateAttributesMapping: fieldValidityMapping
	});
});
FieldDescription.displayName = "FieldDescription";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/control/FieldControl.mjs
/**
* The form control to label and validate.
* Renders an `<input>` element.
*
* You can omit this part and use any Base UI input component instead. For example,
* [Input](https://base-ui.com/react/components/input), [Checkbox](https://base-ui.com/react/components/checkbox),
* or [Select](https://base-ui.com/react/components/select), among others, will work with Field out of the box.
*
* Documentation: [Base UI Field](https://base-ui.com/react/components/field)
*/
var FieldControl = /*#__PURE__*/ import_react.forwardRef(function FieldControl(componentProps, forwardedRef) {
	const { render, className, id: idProp, name: nameProp, value: valueProp, disabled: disabledProp = false, onValueChange, defaultValue, autoFocus = false, style, ...elementProps } = componentProps;
	const { state: fieldState, name: fieldName, disabled: fieldDisabled, setTouched, setDirty, validityData, setFocused, setFilled, validationMode, validation } = useFieldRootContext();
	const { clearErrors } = useFormContext();
	const disabled = fieldDisabled || disabledProp;
	const name = fieldName ?? nameProp;
	const state = {
		...fieldState,
		disabled
	};
	const { labelId } = useLabelableContext();
	const id = useLabelableId({ id: idProp });
	useIsoLayoutEffect(() => {
		const hasExternalValue = valueProp != null;
		if (validation.inputRef.current?.value || hasExternalValue && valueProp !== "") setFilled(true);
		else if (hasExternalValue && valueProp === "") setFilled(false);
	}, [
		validation.inputRef,
		setFilled,
		valueProp
	]);
	const inputRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (autoFocus && inputRef.current === activeElement(ownerDocument(inputRef.current))) setFocused(true);
	}, [autoFocus, setFocused]);
	const [valueUnwrapped] = useControlled({
		controlled: valueProp,
		default: defaultValue,
		name: "FieldControl",
		state: "value"
	});
	const isControlled = valueProp !== void 0;
	const value = isControlled ? valueUnwrapped : void 0;
	const getValueFromInput = useStableCallback(() => validation.inputRef.current?.value);
	useRegisterFieldControl(validation.inputRef, id, value, getValueFromInput, !disabled, nameProp);
	return useRenderElement("input", componentProps, {
		ref: [forwardedRef, inputRef],
		state,
		props: [
			{
				id,
				disabled,
				name,
				ref: validation.inputRef,
				"aria-labelledby": labelId,
				autoFocus,
				...isControlled ? { value } : { defaultValue },
				onChange(event) {
					const inputValue = event.currentTarget.value;
					onValueChange?.(inputValue, createChangeEventDetails(none, event.nativeEvent));
					setDirty(inputValue !== (validityData.initialValue ?? ""));
					setFilled(inputValue !== "");
					if (!event.nativeEvent.defaultPrevented) {
						clearErrors(name);
						validation.change(inputValue);
					}
				},
				onFocus() {
					setFocused(true);
				},
				onBlur(event) {
					setTouched(true);
					setFocused(false);
					if (validationMode === "onBlur") validation.commit(event.currentTarget.value);
				},
				onKeyDown(event) {
					if (event.currentTarget.tagName === "INPUT" && event.key === "Enter") {
						setTouched(true);
						validation.commit(event.currentTarget.value);
					}
				}
			},
			elementProps,
			(props) => validation.getValidationProps(disabled, props)
		],
		stateAttributesMapping: fieldValidityMapping
	});
});
FieldControl.displayName = "FieldControl";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/validity/FieldValidity.mjs
/**
* Used to display a custom message based on the field's validity.
* Requires `children` to be a function that accepts field validity state as an argument.
*
* Documentation: [Base UI Field](https://base-ui.com/react/components/field)
*/
var FieldValidity = function FieldValidity(props) {
	const { children } = props;
	const { validityData, invalid } = useFieldRootContext(false);
	const combinedFieldValidityData = import_react.useMemo(() => getCombinedFieldValidityData(validityData, invalid), [validityData, invalid]);
	const { transitionStatus } = useTransitionStatus(combinedFieldValidityData.state.valid === false);
	const fieldValidityState = import_react.useMemo(() => {
		return {
			...combinedFieldValidityData,
			validity: combinedFieldValidityData.state,
			transitionStatus
		};
	}, [combinedFieldValidityData, transitionStatus]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: children(fieldValidityState) });
};
FieldValidity.displayName = "FieldValidity";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/item/FieldItem.mjs
/**
* Groups individual items in a checkbox group or radio group with a label and description.
* Renders a `<div>` element.
*
* Documentation: [Base UI Field](https://base-ui.com/react/components/field)
*/
var FieldItem = /*#__PURE__*/ import_react.forwardRef(function FieldItem(componentProps, forwardedRef) {
	const { render, className, style, disabled: disabledProp = false, ...elementProps } = componentProps;
	const { state: fieldState, disabled: rootDisabled } = useFieldRootContext(false);
	const disabled = rootDisabled || disabledProp;
	const state = {
		...fieldState,
		disabled
	};
	const fieldItemContext = import_react.useMemo(() => ({ disabled }), [disabled]);
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		state,
		props: elementProps,
		stateAttributesMapping: fieldValidityMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(LabelableProvider, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FieldItemContext.Provider, {
		value: fieldItemContext,
		children: element
	}) });
});
FieldItem.displayName = "FieldItem";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/field/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Control: () => FieldControl,
	Description: () => FieldDescription,
	Error: () => FieldError,
	Item: () => FieldItem,
	Label: () => FieldLabel,
	Root: () => FieldRoot,
	Validity: () => FieldValidity
});
//#endregion
export { FieldControl as n, index_parts_exports as t };
