import { $getRoot, $isDecoratorNode, $isElementNode, $isParagraphNode, $isTextNode } from "./lexical.js";
//#region node_modules/.bun/@lexical+text@0.41.0/node_modules/@lexical/text/LexicalText.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Returns the root's text content.
* @returns The root's text content.
*/
function $rootTextContent() {
	return $getRoot().getTextContent();
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Determines if the root has any text content and can trim any whitespace if it does.
* @param isEditorComposing - Is the editor in composition mode due to an active Input Method Editor?
* @param trim - Should the root text have its whitespaced trimmed? Defaults to true.
* @returns true if text content is empty, false if there is text or isEditorComposing is true.
*/
function $isRootTextContentEmpty(isEditorComposing, trim = true) {
	if (isEditorComposing) return false;
	let text = $rootTextContent();
	if (trim) text = text.trim();
	return text === "";
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Determines if the input should show the placeholder. If anything is in
* in the root the placeholder should not be shown.
* @param isComposing - Is the editor in composition mode due to an active Input Method Editor?
* @returns true if the input should show the placeholder, false otherwise.
*/
function $canShowPlaceholder(isComposing) {
	if (!$isRootTextContentEmpty(isComposing, false)) return false;
	const children = $getRoot().getChildren();
	const childrenLength = children.length;
	if (childrenLength > 1) return false;
	for (let i = 0; i < childrenLength; i++) {
		const topBlock = children[i];
		if ($isDecoratorNode(topBlock)) return false;
		if ($isElementNode(topBlock)) {
			if (!$isParagraphNode(topBlock)) return false;
			if (topBlock.__indent !== 0) return false;
			const topBlockChildren = topBlock.getChildren();
			const topBlockChildrenLength = topBlockChildren.length;
			for (let s = 0; s < topBlockChildrenLength; s++) {
				const child = topBlockChildren[i];
				if (!$isTextNode(child)) return false;
			}
		}
	}
	return true;
}
/**
* Returns a function that executes {@link $canShowPlaceholder}
* @param isEditorComposing - Is the editor in composition mode due to an active Input Method Editor?
* @returns A function that executes $canShowPlaceholder with arguments.
*/
function $canShowPlaceholderCurry(isEditorComposing) {
	return () => $canShowPlaceholder(isEditorComposing);
}
//#endregion
export { $canShowPlaceholderCurry as t };
