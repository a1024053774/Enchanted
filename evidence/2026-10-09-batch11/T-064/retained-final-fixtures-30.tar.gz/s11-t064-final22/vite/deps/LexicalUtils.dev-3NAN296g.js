import { $findMatchingParent, $getSelection, $isElementNode, $isRangeSelection } from "./lexical.js";
//#region node_modules/.bun/@lexical+utils@0.41.0/node_modules/@lexical/utils/LexicalUtils.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function formatDevErrorMessage(message) {
	throw new Error(message);
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var CAN_USE_DOM$1 = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var documentMode = CAN_USE_DOM$1 && "documentMode" in document ? document.documentMode : null;
CAN_USE_DOM$1 && /Mac|iPod|iPhone|iPad/.test(navigator.platform);
CAN_USE_DOM$1 && /^(?!.*Seamonkey)(?=.*Firefox).*/i.test(navigator.userAgent);
CAN_USE_DOM$1 && "InputEvent" in window && !documentMode && "getTargetRanges" in new window.InputEvent("input");
CAN_USE_DOM$1 && /Version\/[\d.]+.*Safari/.test(navigator.userAgent);
CAN_USE_DOM$1 && /iPad|iPhone|iPod/.test(navigator.userAgent) && window.MSStream;
CAN_USE_DOM$1 && /Android/.test(navigator.userAgent);
CAN_USE_DOM$1 && /^(?=.*Chrome).*/i.test(navigator.userAgent);
CAN_USE_DOM$1 && /AppleWebKit\/[\d.]+/.test(navigator.userAgent);
/**
* Returns the element node of the nearest ancestor, otherwise throws an error.
* @param startNode - The starting node of the search
* @returns The ancestor node found
*/
function $getNearestBlockElementAncestorOrThrow(startNode) {
	const blockNode = $findMatchingParent(startNode, (node) => $isElementNode(node) && !node.isInline());
	if (!$isElementNode(blockNode)) formatDevErrorMessage(`Expected node ${startNode.__key} to have closest block element node.`);
	return blockNode;
}
/**
* @param object = The instance of the type
* @param objectClass = The class of the type
* @returns Whether the object is has the same Klass of the objectClass, ignoring the difference across window (e.g. different iframes)
*/
function objectKlassEquals(object, objectClass) {
	return object !== null ? Object.getPrototypeOf(object).constructor.name === objectClass.name : false;
}
/**
* Applies the provided callback to each indentable block element in the Selection
*
* @param indentOrOutdent callback for performing the indent or outdent action
* on a given block element.
* @returns true if at least one block was handled, false otherwise.
*/
function $handleIndentAndOutdent(indentOrOutdent) {
	const selection = $getSelection();
	if (!$isRangeSelection(selection)) return false;
	const alreadyHandled = /* @__PURE__ */ new Set();
	const nodes = selection.getNodes();
	for (let i = 0; i < nodes.length; i++) {
		const node = nodes[i];
		const key = node.getKey();
		if (alreadyHandled.has(key)) continue;
		const parentBlock = $findMatchingParent(node, (parentNode) => $isElementNode(parentNode) && !parentNode.isInline());
		if (parentBlock === null) continue;
		const parentKey = parentBlock.getKey();
		if (parentBlock.canIndent() && !alreadyHandled.has(parentKey)) {
			alreadyHandled.add(parentKey);
			indentOrOutdent(parentBlock);
		}
	}
	return alreadyHandled.size > 0;
}
//#endregion
export { $handleIndentAndOutdent as n, objectKlassEquals as r, $getNearestBlockElementAncestorOrThrow as t };
