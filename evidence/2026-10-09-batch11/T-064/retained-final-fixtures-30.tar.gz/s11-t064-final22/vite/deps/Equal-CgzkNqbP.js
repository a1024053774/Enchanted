import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Pipeable.js
var Pipeable_exports = /* @__PURE__ */ __exportAll({
	Class: () => Class,
	Mixin: () => Mixin,
	Prototype: () => Prototype,
	pipeArguments: () => pipeArguments
});
/**
* @since 2.0.0
*/
/**
* @since 2.0.0
* @category utilities
* @example
* ```ts
* import { Pipeable } from "effect"
*
* // pipeArguments is used internally to implement efficient piping
* function customPipe<A>(self: A, ...fns: Array<(a: any) => any>): unknown {
*   return Pipeable.pipeArguments(self, arguments as any)
* }
*
* // Example usage
* const add = (x: number) => (y: number) => x + y
* const multiply = (x: number) => (y: number) => x * y
*
* const result = customPipe(5, add(2), multiply(3))
* console.log(result) // 21
* ```
*/
var pipeArguments = (self, args) => {
	switch (args.length) {
		case 0: return self;
		case 1: return args[0](self);
		case 2: return args[1](args[0](self));
		case 3: return args[2](args[1](args[0](self)));
		case 4: return args[3](args[2](args[1](args[0](self))));
		case 5: return args[4](args[3](args[2](args[1](args[0](self)))));
		case 6: return args[5](args[4](args[3](args[2](args[1](args[0](self))))));
		case 7: return args[6](args[5](args[4](args[3](args[2](args[1](args[0](self)))))));
		case 8: return args[7](args[6](args[5](args[4](args[3](args[2](args[1](args[0](self))))))));
		case 9: return args[8](args[7](args[6](args[5](args[4](args[3](args[2](args[1](args[0](self)))))))));
		default: {
			let ret = self;
			for (let i = 0, len = args.length; i < len; i++) ret = args[i](ret);
			return ret;
		}
	}
};
/**
* @since 4.0.0
*/
var Prototype = { pipe() {
	return pipeArguments(this, arguments);
} };
/**
* @since 4.0.0
* @category constructors
*/
var Class = /*#__PURE__*/ function() {
	function PipeableBase() {}
	PipeableBase.prototype = Prototype;
	return PipeableBase;
}();
/**
* @since 4.0.0
* @category constructors
*/
var Mixin = (klass) => class extends klass {
	pipe() {
		return pipeArguments(this, arguments);
	}
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Function.js
var Function_exports = /* @__PURE__ */ __exportAll({
	SK: () => SK,
	absurd: () => absurd,
	apply: () => apply,
	coerceUnsafe: () => coerceUnsafe,
	compose: () => compose$1,
	constFalse: () => constFalse,
	constNull: () => constNull,
	constTrue: () => constTrue,
	constUndefined: () => constUndefined,
	constVoid: () => constVoid,
	constant: () => constant,
	dual: () => dual,
	flip: () => flip,
	flow: () => flow,
	hole: () => hole,
	identity: () => identity,
	memoize: () => memoize,
	pipe: () => pipe,
	satisfies: () => satisfies,
	tupled: () => tupled,
	untupled: () => untupled
});
/**
* Creates a function that can be used in a data-last (aka `pipe`able) or
* data-first style.
*
* The first parameter to `dual` is either the arity of the uncurried function
* or a predicate that determines if the function is being used in a data-first
* or data-last style.
*
* Using the arity is the most common use case, but there are some cases where
* you may want to use a predicate. For example, if you have a function that
* takes an optional argument, you can use a predicate to determine if the
* function is being used in a data-first or data-last style.
*
* You can pass either the arity of the uncurried function or a predicate
* which determines if the function is being used in a data-first or
* data-last style.
*
* @example
* ```ts
* import { dual, pipe } from "effect/Function"
*
* // Using arity to determine data-first or data-last style
* const sum = dual<
*   (that: number) => (self: number) => number,
*   (self: number, that: number) => number
* >(2, (self, that) => self + that)
*
* console.log(sum(2, 3)) // 5 (data-first)
* console.log(pipe(2, sum(3))) // 5 (data-last)
* ```
*
* **Example** (Using arity to determine data-first or data-last style)
*
* ```ts
* import { dual, pipe } from "effect/Function"
*
* const sum = dual<
*   (that: number) => (self: number) => number,
*   (self: number, that: number) => number
* >(2, (self, that) => self + that)
*
* console.log(sum(2, 3)) // 5
* console.log(pipe(2, sum(3))) // 5
* ```
*
* **Example** (Using call signatures to define the overloads)
*
* ```ts
* import { dual, pipe } from "effect/Function"
*
* const sum: {
*   (that: number): (self: number) => number
*   (self: number, that: number): number
* } = dual(2, (self: number, that: number): number => self + that)
*
* console.log(sum(2, 3)) // 5
* console.log(pipe(2, sum(3))) // 5
* ```
*
* **Example** (Using a predicate to determine data-first or data-last style)
*
* ```ts
* import { dual, pipe } from "effect/Function"
*
* const sum = dual<
*   (that: number) => (self: number) => number,
*   (self: number, that: number) => number
* >(
*   (args) => args.length === 2,
*   (self, that) => self + that
* )
*
* console.log(sum(2, 3)) // 5
* console.log(pipe(2, sum(3))) // 5
* ```
*
* @category combinators
* @since 2.0.0
*/
var dual = function(arity, body) {
	if (typeof arity === "function") return function() {
		return arity(arguments) ? body.apply(this, arguments) : (self) => body(self, ...arguments);
	};
	switch (arity) {
		case 0:
		case 1: throw new RangeError(`Invalid arity ${arity}`);
		case 2: return function(a, b) {
			if (arguments.length >= 2) return body(a, b);
			return function(self) {
				return body(self, a);
			};
		};
		case 3: return function(a, b, c) {
			if (arguments.length >= 3) return body(a, b, c);
			return function(self) {
				return body(self, a, b);
			};
		};
		default: return function() {
			if (arguments.length >= arity) return body.apply(this, arguments);
			const args = arguments;
			return function(self) {
				return body(self, ...args);
			};
		};
	}
};
/**
* Apply a function to a given value.
*
* @example
* ```ts
* import { apply, pipe } from "effect/Function"
* import { length } from "effect/String"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe(length, apply("hello")), 5)
* ```
*
* @category combinators
* @since 2.0.0
*/
var apply = (a) => (self) => self(a);
/**
* The identity function, i.e. A function that returns its input argument.
*
* @example
* ```ts
* import { identity } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(identity(5), 5)
* ```
*
* @category combinators
* @since 2.0.0
*/
var identity = (a) => a;
/**
* A function that ensures that the type of an expression matches some type,
* without changing the resulting type of that expression.
*
* @example
* ```ts
* import { satisfies } from "effect/Function"
* import * as assert from "node:assert"
*
* const test1 = satisfies<number>()(5 as const)
* // ^? const test: 5
* // @ts-expect-error
* const test2 = satisfies<string>()(5)
* // ^? Argument of type 'number' is not assignable to parameter of type 'string'
*
* assert.deepStrictEqual(satisfies<number>()(5), 5)
* ```
*
* @category type utils
* @since 2.0.0
*/
var satisfies = () => (b) => b;
/**
* Casts the result to the specified type.
*
* @example
* ```ts
* import { coerceUnsafe, identity } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(coerceUnsafe, identity)
* ```
*
* @category type utils
* @since 2.0.0
*/
var coerceUnsafe = identity;
/**
* Creates a constant value that never changes.
*
* This is useful when you want to pass a value to a higher-order function (a function that takes another function as its argument)
* and want that inner function to always use the same value, no matter how many times it is called.
*
* @example
* ```ts
* import { constant } from "effect/Function"
* import * as assert from "node:assert"
*
* const constNull = constant(null)
*
* assert.deepStrictEqual(constNull(), null)
* assert.deepStrictEqual(constNull(), null)
* ```
*
* @category constructors
* @since 2.0.0
*/
var constant = (value) => () => value;
/**
* A thunk that returns always `true`.
*
* @example
* ```ts
* import { constTrue } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(constTrue(), true)
* ```
*
* @category constants
* @since 2.0.0
*/
var constTrue = /*#__PURE__*/ constant(true);
/**
* A thunk that returns always `false`.
*
* @example
* ```ts
* import { constFalse } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(constFalse(), false)
* ```
*
* @category constants
* @since 2.0.0
*/
var constFalse = /*#__PURE__*/ constant(false);
/**
* A thunk that returns always `null`.
*
* @example
* ```ts
* import { constNull } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(constNull(), null)
* ```
*
* @category constants
* @since 2.0.0
*/
var constNull = /*#__PURE__*/ constant(null);
/**
* A thunk that returns always `undefined`.
*
* @example
* ```ts
* import { constUndefined } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(constUndefined(), undefined)
* ```
*
* @category constants
* @since 2.0.0
*/
var constUndefined = /*#__PURE__*/ constant(void 0);
/**
* A thunk that returns always `void`.
*
* @example
* ```ts
* import { constVoid } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(constVoid(), undefined)
* ```
*
* @category constants
* @since 2.0.0
*/
var constVoid = constUndefined;
/**
* Reverses the order of arguments for a curried function.
*
* @example
* ```ts
* import { flip } from "effect/Function"
* import * as assert from "node:assert"
*
* const f = (a: number) => (b: string) => a - b.length
*
* assert.deepStrictEqual(flip(f)("aaa")(2), -1)
* ```
*
* @category combinators
* @since 2.0.0
*/
var flip = (f) => (...b) => (...a) => f(...a)(...b);
/**
* Composes two functions, `ab` and `bc` into a single function that takes in an argument `a` of type `A` and returns a result of type `C`.
* The result is obtained by first applying the `ab` function to `a` and then applying the `bc` function to the result of `ab`.
*
* @example
* ```ts
* import { compose } from "effect/Function"
* import * as assert from "node:assert"
*
* const increment = (n: number) => n + 1
* const square = (n: number) => n * n
*
* assert.strictEqual(compose(increment, square)(2), 9)
* ```
*
* @category combinators
* @since 2.0.0
*/
var compose$1 = /*#__PURE__*/ dual(2, (ab, bc) => (a) => bc(ab(a)));
/**
* The `absurd` function is a stub for cases where a value of type `never` is encountered in your code,
* meaning that it should be impossible for this code to be executed.
*
* This function is particularly useful when it's necessary to specify that certain cases are impossible.
*
* @example
* ```ts
* import { absurd } from "effect/Function"
*
* const handleNever = (value: never) => {
*   return absurd(value) // This will throw an error if called
* }
* ```
*
* @category utilities
* @since 2.0.0
*/
var absurd = (_) => {
	throw new Error("Called `absurd` function which should be uncallable");
};
/**
* Creates a tupled version of this function: instead of `n` arguments, it accepts a single tuple argument.
*
* @example
* ```ts
* import { tupled } from "effect/Function"
* import * as assert from "node:assert"
*
* const sumTupled = tupled((x: number, y: number): number => x + y)
*
* assert.deepStrictEqual(sumTupled([1, 2]), 3)
* ```
*
* @category combinators
* @since 2.0.0
*/
var tupled = (f) => (a) => f(...a);
/**
* Inverse function of `tupled`
*
* @example
* ```ts
* import { untupled } from "effect/Function"
* import * as assert from "node:assert"
*
* const getFirst = untupled(<A, B>(tuple: [A, B]): A => tuple[0])
*
* assert.deepStrictEqual(getFirst(1, 2), 1)
* ```
*
* @category combinators
* @since 2.0.0
*/
var untupled = (f) => (...a) => f(a);
function pipe(a, ...args) {
	return pipeArguments(a, args);
}
function flow(ab, bc, cd, de, ef, fg, gh, hi, ij) {
	switch (arguments.length) {
		case 1: return ab;
		case 2: return function() {
			return bc(ab.apply(this, arguments));
		};
		case 3: return function() {
			return cd(bc(ab.apply(this, arguments)));
		};
		case 4: return function() {
			return de(cd(bc(ab.apply(this, arguments))));
		};
		case 5: return function() {
			return ef(de(cd(bc(ab.apply(this, arguments)))));
		};
		case 6: return function() {
			return fg(ef(de(cd(bc(ab.apply(this, arguments))))));
		};
		case 7: return function() {
			return gh(fg(ef(de(cd(bc(ab.apply(this, arguments)))))));
		};
		case 8: return function() {
			return hi(gh(fg(ef(de(cd(bc(ab.apply(this, arguments))))))));
		};
		case 9: return function() {
			return ij(hi(gh(fg(ef(de(cd(bc(ab.apply(this, arguments)))))))));
		};
	}
}
/**
* Type hole simulation. Creates a placeholder for any type, primarily used during development.
*
* @example
* ```ts
* import { hole } from "effect/Function"
*
* // Use during development as a placeholder
* const placeholder: string = hole<string>()
* ```
*
* @category utilities
* @since 2.0.0
*/
var hole = /*#__PURE__*/ coerceUnsafe(absurd);
/**
* The SK combinator, also known as the "S-K combinator" or "S-combinator", is a fundamental combinator in the
* lambda calculus and the SKI combinator calculus.
*
* This function is useful for discarding the first argument passed to it and returning the second argument.
*
* @example
* ```ts
* import { SK } from "effect/Function"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(SK(0, "hello"), "hello")
* ```
*
* @category combinators
* @since 2.0.0
*/
var SK = (_, b) => b;
/**
* @since 4.0.0
*/
function memoize(f) {
	const cache = /* @__PURE__ */ new WeakMap();
	return (a) => {
		if (cache.has(a)) return cache.get(a);
		const result = f(a);
		cache.set(a, result);
		return result;
	};
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/equal.js
/** @internal */
var getAllObjectKeys = (obj) => {
	const keys = new Set(Reflect.ownKeys(obj));
	if (obj.constructor === Object) return keys;
	if (obj instanceof Error) keys.delete("stack");
	const proto = Object.getPrototypeOf(obj);
	let current = proto;
	while (current !== null && current !== Object.prototype) {
		const ownKeys = Reflect.ownKeys(current);
		for (let i = 0; i < ownKeys.length; i++) keys.add(ownKeys[i]);
		current = Object.getPrototypeOf(current);
	}
	if (keys.has("constructor") && typeof obj.constructor === "function" && proto === obj.constructor.prototype) keys.delete("constructor");
	return keys;
};
/** @internal */
var byReferenceInstances = /*#__PURE__*/ new WeakSet();
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Predicate.js
/**
* Predicate and Refinement helpers for runtime checks, filtering, and type narrowing.
* This module provides small, pure functions you can combine to decide whether a
* value matches a condition and, when using refinements, narrow TypeScript types.
*
* Mental model:
* - A `Predicate<A>` is just `(a: A) => boolean`.
* - A `Refinement<A, B>` is a predicate that narrows `A` to `B` when true.
* - Guards like `isString` are predicates/refinements for common runtime types.
* - Combinators like `and`/`or` build new predicates from existing ones.
* - `Tuple` and `Struct` lift element/property predicates to compound values.
*
* Common tasks:
* - Reuse an existing predicate on a different input shape -> {@link mapInput}
* - Combine checks -> {@link and}, {@link or}, {@link not}, {@link xor}
* - Build tuple/object checks -> {@link Tuple}, {@link Struct}
* - Narrow `unknown` to a concrete type -> {@link Refinement}, {@link compose}
* - Check runtime types -> {@link isString}, {@link isNumber}, {@link isObject}
*
* Gotchas:
* - `isTruthy` uses JavaScript truthiness; `0`, "", and `false` are false.
* - `isObject` excludes arrays; use {@link isObjectOrArray} for both.
* - `isIterable` treats strings as iterable.
* - `isPromise`/`isPromiseLike` are structural checks (then/catch), not `instanceof`.
* - `isTupleOf` and `isTupleOfAtLeast` only check length, not element types.
*
* **Example** (Filter by a predicate)
*
* ```ts
* import * as Predicate from "effect/Predicate"
*
* const isPositive = (n: number) => n > 0
* const data = [2, -1, 3]
*
* console.log(data.filter(isPositive))
* ```
*
* See also: {@link Predicate}, {@link Refinement}, {@link and}, {@link or}, {@link mapInput}
*
* @since 2.0.0
*/
var Predicate_exports = /* @__PURE__ */ __exportAll({
	Struct: () => Struct,
	Tuple: () => Tuple,
	and: () => and,
	compose: () => compose,
	eqv: () => eqv,
	every: () => every,
	hasProperty: () => hasProperty,
	implies: () => implies,
	isBigInt: () => isBigInt,
	isBoolean: () => isBoolean,
	isDate: () => isDate,
	isError: () => isError,
	isFunction: () => isFunction,
	isIterable: () => isIterable,
	isMap: () => isMap,
	isNever: () => isNever,
	isNotNull: () => isNotNull,
	isNotNullish: () => isNotNullish,
	isNotUndefined: () => isNotUndefined,
	isNull: () => isNull,
	isNullish: () => isNullish,
	isNumber: () => isNumber,
	isObject: () => isObject,
	isObjectKeyword: () => isObjectKeyword,
	isObjectOrArray: () => isObjectOrArray,
	isPromise: () => isPromise,
	isPromiseLike: () => isPromiseLike,
	isPropertyKey: () => isPropertyKey,
	isReadonlyObject: () => isReadonlyObject,
	isRegExp: () => isRegExp,
	isSet: () => isSet,
	isString: () => isString,
	isSymbol: () => isSymbol,
	isTagged: () => isTagged,
	isTruthy: () => isTruthy,
	isTupleOf: () => isTupleOf,
	isTupleOfAtLeast: () => isTupleOfAtLeast,
	isUint8Array: () => isUint8Array,
	isUndefined: () => isUndefined,
	isUnknown: () => isUnknown,
	mapInput: () => mapInput,
	nand: () => nand,
	nor: () => nor,
	not: () => not,
	or: () => or,
	some: () => some,
	xor: () => xor
});
/**
* Transforms the input of a predicate using a mapping function.
*
* When to use:
* - You have a predicate on `A` and want one on `B` via `B -> A`.
* - You want to check derived values (lengths, projections, etc.).
*
* Behavior:
* - Pure; does not mutate input.
* - Returns a new predicate that applies `f` before `self`.
* - No short-circuit beyond what `self` does.
*
* **Example** (Check string length)
*
* ```ts
* import { Predicate } from "effect"
*
* const isLongerThan2 = Predicate.mapInput((s: string) => s.length)(
*   (n: number) => n > 2
* )
*
* console.log(isLongerThan2("hello"))
* ```
*
* See also: {@link Predicate}, {@link and}, {@link not}
*
* @category combinators
* @since 2.0.0
*/
var mapInput = /*#__PURE__*/ dual(2, (self, f) => (b) => self(f(b)));
/**
* Checks whether a readonly array has exactly `n` elements.
*
* When to use:
* - You need a runtime check for tuple length.
* - You want to narrow `ReadonlyArray<T>` to `TupleOf<N, T>`.
*
* Behavior:
* - Pure; does not mutate input.
* - Only checks length, not element types.
* - Returns a refinement on the array type.
*
* **Example** (Exact length)
*
* ```ts
* import { Predicate } from "effect"
*
* const isPair = Predicate.isTupleOf(2)
*
* console.log(isPair([1, 2]))
* ```
*
* See also: {@link isTupleOfAtLeast}, {@link Tuple}
*
* @category guards
* @since 3.3.0
*/
var isTupleOf = /*#__PURE__*/ dual(2, (self, n) => self.length === n);
/**
* Checks whether a readonly array has at least `n` elements.
*
* When to use:
* - You need a runtime check for tuple-like minimum length.
* - You want to narrow `ReadonlyArray<T>` to `TupleOfAtLeast<N, T>`.
*
* Behavior:
* - Pure; does not mutate input.
* - Only checks length, not element types.
* - Returns a refinement on the array type.
*
* **Example** (Minimum length)
*
* ```ts
* import { Predicate } from "effect"
*
* const hasAtLeast2 = Predicate.isTupleOfAtLeast(2)
*
* console.log(hasAtLeast2([1, 2, 3]))
* ```
*
* See also: {@link isTupleOf}, {@link Tuple}
*
* @category guards
* @since 3.3.0
*/
var isTupleOfAtLeast = /*#__PURE__*/ dual(2, (self, n) => self.length >= n);
/**
* Checks whether a value is truthy.
*
* When to use:
* - You want a predicate that mirrors JavaScript truthiness.
* - You need to filter out falsy values like `0`, "", and `false`.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `!!input` under the hood.
* - Treats `0`, "", `false`, `null`, and `undefined` as false.
*
* **Example** (Filter truthy)
*
* ```ts
* import { Predicate } from "effect"
*
* const values = [0, 1, "", "ok", false]
* const truthy = values.filter(Predicate.isTruthy)
*
* console.log(truthy)
* ```
*
* See also: {@link isNullish}, {@link isNotNullish}
*
* @category guards
* @since 2.0.0
*/
function isTruthy(input) {
	return !!input;
}
/**
* Checks whether a value is a `Set`.
*
* When to use:
* - You need a runtime guard for `Set` values.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `instanceof Set`.
*
* **Example** (Guard a Set)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = new Set([1, 2])
*
* if (Predicate.isSet(data)) {
*   console.log(data.size)
* }
* ```
*
* See also: {@link isMap}, {@link isIterable}
*
* @category guards
* @since 2.0.0
*/
function isSet(input) {
	return input instanceof Set;
}
/**
* Checks whether a value is a `Map`.
*
* When to use:
* - You need a runtime guard for `Map` values.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `instanceof Map`.
*
* **Example** (Guard a Map)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = new Map([["a", 1]])
*
* if (Predicate.isMap(data)) {
*   console.log(data.size)
* }
* ```
*
* See also: {@link isSet}, {@link isIterable}
*
* @category guards
* @since 2.0.0
*/
function isMap(input) {
	return input instanceof Map;
}
/**
* Checks whether a value is a `string`.
*
* When to use:
* - You need to guard an `unknown` value as a string.
* - You want to narrow in `if` statements.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "string"`.
*
* **Example** (Guard string)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = "hi"
*
* if (Predicate.isString(data)) {
*   console.log(data.toUpperCase())
* }
* ```
*
* See also: {@link isNumber}, {@link isBoolean}, {@link Refinement}
*
* @category guards
* @since 2.0.0
*/
function isString(input) {
	return typeof input === "string";
}
/**
* Checks whether a value is a `number`.
*
* When to use:
* - You need to guard an `unknown` value as a number.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "number"`.
* - Does not exclude `NaN` or `Infinity`.
*
* **Example** (Guard number)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = 42
*
* if (Predicate.isNumber(data)) {
*   console.log(data + 1)
* }
* ```
*
* See also: {@link isBigInt}, {@link isString}
*
* @category guards
* @since 2.0.0
*/
function isNumber(input) {
	return typeof input === "number";
}
/**
* Checks whether a value is a `boolean`.
*
* When to use:
* - You need to guard an `unknown` value as a boolean.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "boolean"`.
*
* **Example** (Guard boolean)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = true
*
* if (Predicate.isBoolean(data)) {
*   console.log(data ? "yes" : "no")
* }
* ```
*
* See also: {@link isString}, {@link isNumber}
*
* @category guards
* @since 2.0.0
*/
function isBoolean(input) {
	return typeof input === "boolean";
}
/**
* Checks whether a value is a `bigint`.
*
* When to use:
* - You need to guard an `unknown` value as a bigint.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "bigint"`.
*
* **Example** (Guard bigint)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = 1n
*
* if (Predicate.isBigInt(data)) {
*   console.log(data + 2n)
* }
* ```
*
* See also: {@link isNumber}
*
* @category guards
* @since 2.0.0
*/
function isBigInt(input) {
	return typeof input === "bigint";
}
/**
* Checks whether a value is a `symbol`.
*
* When to use:
* - You need to guard an `unknown` value as a symbol.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "symbol"`.
*
* **Example** (Guard symbol)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = Symbol.for("id")
*
* if (Predicate.isSymbol(data)) {
*   console.log(data.description)
* }
* ```
*
* See also: {@link isPropertyKey}
*
* @category guards
* @since 2.0.0
*/
function isSymbol(input) {
	return typeof input === "symbol";
}
/**
* Checks whether a value is a valid `PropertyKey` (string, number, or symbol).
*
* When to use:
* - You need to guard unknown keys before indexing.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses {@link isString}, {@link isNumber}, and {@link isSymbol}.
*
* **Example** (Guard property key)
*
* ```ts
* import { Predicate } from "effect"
*
* const key: unknown = "name"
* const obj: Record<PropertyKey, unknown> = { name: "Ada" }
*
* if (Predicate.isPropertyKey(key) && key in obj) {
*   console.log(obj[key])
* }
* ```
*
* See also: {@link isString}, {@link isNumber}, {@link isSymbol}
*
* @category guards
* @since 4.0.0
*/
function isPropertyKey(u) {
	return isString(u) || isNumber(u) || isSymbol(u);
}
/**
* Checks whether a value is a `function`.
*
* When to use:
* - You need to guard an `unknown` value as callable.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "function"`.
*
* **Example** (Guard function)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = () => 1
*
* if (Predicate.isFunction(data)) {
*   console.log(data())
* }
* ```
*
* See also: {@link isObjectKeyword}
*
* @category guards
* @since 2.0.0
*/
function isFunction(input) {
	return typeof input === "function";
}
/**
* Checks whether a value is `undefined`.
*
* When to use:
* - You need a guard for optional values.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `input === undefined`.
*
* **Example** (Guard undefined)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = undefined
*
* console.log(Predicate.isUndefined(data))
* ```
*
* See also: {@link isNotUndefined}, {@link isNullish}
*
* @category guards
* @since 2.0.0
*/
function isUndefined(input) {
	return input === void 0;
}
/**
* Checks whether a value is not `undefined`.
*
* When to use:
* - You want to filter out `undefined` while preserving other falsy values.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns a refinement that excludes `undefined`.
*
* **Example** (Filter undefined)
*
* ```ts
* import { Predicate } from "effect"
*
* const values = [1, undefined, 2]
* const defined = values.filter(Predicate.isNotUndefined)
*
* console.log(defined)
* ```
*
* See also: {@link isUndefined}, {@link isNotNullish}
*
* @category guards
* @since 2.0.0
*/
function isNotUndefined(input) {
	return input !== void 0;
}
/**
* Checks whether a value is `null`.
*
* When to use:
* - You need a guard for nullable values.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `input === null`.
*
* **Example** (Guard null)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = null
*
* console.log(Predicate.isNull(data))
* ```
*
* See also: {@link isNotNull}, {@link isNullish}
*
* @category guards
* @since 2.0.0
*/
function isNull(input) {
	return input === null;
}
/**
* Checks whether a value is not `null`.
*
* When to use:
* - You want to filter out `null` while preserving other falsy values.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns a refinement that excludes `null`.
*
* **Example** (Filter null)
*
* ```ts
* import { Predicate } from "effect"
*
* const values = [1, null, 2]
* const nonNull = values.filter(Predicate.isNotNull)
*
* console.log(nonNull)
* ```
*
* See also: {@link isNull}, {@link isNotNullish}
*
* @category guards
* @since 2.0.0
*/
function isNotNull(input) {
	return input !== null;
}
/**
* Checks whether a value is `null` or `undefined`.
*
* When to use:
* - You want to guard nullish values explicitly.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `input === null || input === undefined`.
*
* **Example** (Guard nullish)
*
* ```ts
* import { Predicate } from "effect"
*
* const values = [0, null, "", undefined]
* const nullish = values.filter(Predicate.isNullish)
*
* console.log(nullish)
* ```
*
* See also: {@link isNotNullish}, {@link isUndefined}, {@link isNull}
*
* @category guards
* @since 4.0.0
*/
function isNullish(input) {
	return input === null || input === void 0;
}
/**
* Checks whether a value is not `null` and not `undefined`.
*
* When to use:
* - You want to filter out nullish values but keep other falsy ones.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `input != null`.
*
* **Example** (Filter non-nullish)
*
* ```ts
* import { Predicate } from "effect"
*
* const values = [0, null, "", undefined]
* const present = values.filter(Predicate.isNotNullish)
*
* console.log(present)
* ```
*
* See also: {@link isNullish}, {@link isNotNull}, {@link isNotUndefined}
*
* @category guards
* @since 4.0.0
*/
function isNotNullish(input) {
	return input != null;
}
/**
* A guard that always returns `false`.
*
* When to use:
* - You need a predicate that never accepts, e.g. in default branches.
*
* Behavior:
* - Pure; does not mutate input.
* - Always returns `false`.
*
* **Example** (Never matches)
*
* ```ts
* import { Predicate } from "effect"
*
* console.log(Predicate.isNever("anything"))
* ```
*
* See also: {@link isUnknown}
*
* @category guards
* @since 2.0.0
*/
function isNever(_) {
	return false;
}
/**
* A guard that always returns `true`.
*
* When to use:
* - You need a predicate that always accepts, e.g. as a placeholder.
*
* Behavior:
* - Pure; does not mutate input.
* - Always returns `true`.
*
* **Example** (Always matches)
*
* ```ts
* import { Predicate } from "effect"
*
* console.log(Predicate.isUnknown(123))
* ```
*
* See also: {@link isNever}
*
* @category guards
* @since 2.0.0
*/
function isUnknown(_) {
	return true;
}
/**
* Checks whether a value is an object or an array (non-null object).
*
* When to use:
* - You want to accept plain objects and arrays, but not `null`.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "object" && input !== null`.
* - Includes arrays.
*
* **Example** (Object or array)
*
* ```ts
* import { Predicate } from "effect"
*
* console.log(Predicate.isObjectOrArray([]))
* ```
*
* See also: {@link isObject}, {@link isObjectKeyword}
*
* @category guards
* @since 4.0.0
*/
function isObjectOrArray(input) {
	return typeof input === "object" && input !== null;
}
/**
* Checks whether a value is a plain object (not an array, not `null`).
*
* When to use:
* - You need to accept objects but exclude arrays.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `typeof input === "object" && input !== null && !Array.isArray(input)`.
*
* **Example** (Guard object)
*
* ```ts
* import { Predicate } from "effect"
*
* console.log(Predicate.isObject({ a: 1 }))
* console.log(Predicate.isObject([1, 2]))
* ```
*
* See also: {@link isObjectOrArray}, {@link isReadonlyObject}
*
* @category guards
* @since 4.0.0
*/
function isObject(input) {
	return typeof input === "object" && input !== null && !Array.isArray(input);
}
/**
* Checks whether a value is a readonly object.
*
* When to use:
* - You need a guard for object-like values and do not care about mutability.
*
* Behavior:
* - Pure; does not mutate input.
* - Delegates to {@link isObject}.
*
* **Example** (Readonly object)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = { a: 1 }
*
* console.log(Predicate.isReadonlyObject(data))
* ```
*
* See also: {@link isObject}
*
* @category guards
* @since 4.0.0
*/
function isReadonlyObject(input) {
	return isObject(input);
}
/**
* Checks whether a value is an `object` in the JavaScript sense (objects, arrays, functions).
*
* When to use:
* - You want to accept arrays and functions as well as objects.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns `true` for arrays and functions, `false` for `null`.
*
* **Example** (Object keyword)
*
* ```ts
* import { Predicate } from "effect"
*
* console.log(Predicate.isObjectKeyword(() => 1))
* console.log(Predicate.isObjectKeyword(null))
* ```
*
* See also: {@link isObject}, {@link isObjectOrArray}
*
* @category guards
* @since 2.0.0
*/
function isObjectKeyword(input) {
	return typeof input === "object" && input !== null || isFunction(input);
}
/**
* Checks whether a value has a given property key.
*
* When to use:
* - You need to guard property access on `unknown` values.
* - You want a simple structural guard for objects.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses the `in` operator and {@link isObjectKeyword}.
* - Does not check property value types.
*
* **Example** (Guard property)
*
* ```ts
* import { Predicate } from "effect"
*
* const hasName = Predicate.hasProperty("name")
* const data: unknown = { name: "Ada" }
*
* if (hasName(data)) {
*   console.log(data.name)
* }
* ```
*
* See also: {@link isTagged}, {@link isObjectKeyword}
*
* @category guards
* @since 2.0.0
*/
var hasProperty = /*#__PURE__*/ dual(2, (self, property) => isObjectKeyword(self) && property in self);
/**
* Checks whether a value has a `_tag` property equal to the given tag.
*
* When to use:
* - You model tagged unions with a `_tag` field.
* - You want a quick, structural guard for tagged values.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses {@link hasProperty} and strict equality on `_tag`.
*
* **Example** (Guard tagged)
*
* ```ts
* import { Predicate } from "effect"
*
* const isOk = Predicate.isTagged("Ok")
*
* console.log(isOk({ _tag: "Ok", value: 1 }))
* ```
*
* See also: {@link hasProperty}
*
* @category guards
* @since 2.0.0
*/
var isTagged = /*#__PURE__*/ dual(2, (self, tag) => hasProperty(self, "_tag") && self["_tag"] === tag);
/**
* Checks whether a value is an `Error`.
*
* When to use:
* - You need to guard errors caught from unknown sources.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `instanceof Error`.
*
* **Example** (Guard error)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = new Error("boom")
*
* console.log(Predicate.isError(data))
* ```
*
* See also: {@link isUnknown}
*
* @category guards
* @since 2.0.0
*/
function isError(input) {
	return input instanceof Error;
}
/**
* Checks whether a value is a `Uint8Array`.
*
* When to use:
* - You need to guard binary data at runtime.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `instanceof Uint8Array`.
*
* **Example** (Guard Uint8Array)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = new Uint8Array([1, 2])
*
* console.log(Predicate.isUint8Array(data))
* ```
*
* See also: {@link isIterable}, {@link isSet}
*
* @category guards
* @since 2.0.0
*/
function isUint8Array(input) {
	return input instanceof Uint8Array;
}
/**
* Checks whether a value is a `Date`.
*
* When to use:
* - You need to guard dates at runtime.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `instanceof Date`.
*
* **Example** (Guard Date)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = new Date()
*
* console.log(Predicate.isDate(data))
* ```
*
* See also: {@link isRegExp}
*
* @category guards
* @since 2.0.0
*/
function isDate(input) {
	return input instanceof Date;
}
/**
* Checks whether a value is iterable.
*
* When to use:
* - You need a guard before iterating an unknown value.
*
* Behavior:
* - Pure; does not mutate input.
* - Accepts strings as iterable.
* - Uses {@link hasProperty} for `Symbol.iterator`.
*
* **Example** (Guard iterable)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = [1, 2, 3]
*
* console.log(Predicate.isIterable(data))
* ```
*
* See also: {@link isSet}, {@link isMap}
*
* @category guards
* @since 2.0.0
*/
function isIterable(input) {
	return hasProperty(input, Symbol.iterator) || isString(input);
}
/**
* Checks whether a value is a `Promise`-like object with `then` and `catch`.
*
* When to use:
* - You need to detect promise instances across realms.
*
* Behavior:
* - Pure; does not mutate input.
* - Structural check for `then` and `catch` functions.
*
* **Example** (Guard promise)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = Promise.resolve(1)
*
* console.log(Predicate.isPromise(data))
* ```
*
* See also: {@link isPromiseLike}
*
* @category guards
* @since 2.0.0
*/
function isPromise(input) {
	return hasProperty(input, "then") && "catch" in input && isFunction(input.then) && isFunction(input.catch);
}
/**
* Checks whether a value is `PromiseLike` (has a `then` method).
*
* When to use:
* - You only need `then` to interop with promise-like values.
*
* Behavior:
* - Pure; does not mutate input.
* - Structural check for a callable `then`.
*
* **Example** (Guard promise-like)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = { then: () => {} }
*
* console.log(Predicate.isPromiseLike(data))
* ```
*
* See also: {@link isPromise}
*
* @category guards
* @since 2.0.0
*/
function isPromiseLike(input) {
	return hasProperty(input, "then") && isFunction(input.then);
}
/**
* Checks whether a value is a `RegExp`.
*
* When to use:
* - You need a runtime guard for regular expressions.
*
* Behavior:
* - Pure; does not mutate input.
* - Uses `instanceof RegExp`.
*
* **Example** (Guard RegExp)
*
* ```ts
* import { Predicate } from "effect"
*
* const data: unknown = /abc/
*
* console.log(Predicate.isRegExp(data))
* ```
*
* See also: {@link isDate}
*
* @category guards
* @since 3.9.0
*/
function isRegExp(input) {
	return input instanceof RegExp;
}
/**
* Composes two predicates or refinements into one.
*
* When to use:
* - You want to chain two refinements for progressive narrowing.
* - You want a predicate that applies two checks in sequence.
*
* Behavior:
* - Pure; does not mutate input.
* - For refinements, the output type is narrowed by both.
* - Short-circuits on the first `false`.
*
* **Example** (Compose refinements)
*
* ```ts
* import { Predicate } from "effect"
*
* const isNumber: Predicate.Refinement<unknown, number> = (u): u is number => typeof u === "number"
* const isInteger: Predicate.Refinement<number, number> = (n): n is number => Number.isInteger(n)
*
* const isIntegerNumber = Predicate.compose(isNumber, isInteger)
*
* console.log(isIntegerNumber(1))
* ```
*
* See also: {@link and}, {@link Refinement}
*
* @category combinators
* @since 2.0.0
*/
var compose = /*#__PURE__*/ dual(2, (ab, bc) => (a) => ab(a) && bc(a));
/**
* Creates a predicate for tuples by applying predicates to each element.
*
* When to use:
* - You want to validate tuple positions independently.
* - You want to lift element predicates into a tuple predicate.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns a refinement if any element predicate is a refinement.
* - Stops at the first failing element.
*
* **Example** (Tuple predicate)
*
* ```ts
* import { Predicate } from "effect"
*
* const tupleCheck = Predicate.Tuple([(n: number) => n > 0, Predicate.isString])
*
* console.log(tupleCheck([1, "ok"]))
* ```
*
* See also: {@link Struct}, {@link isTupleOf}
*
* @category combinators
* @since 4.0.0
*/
function Tuple(elements) {
	return (as) => {
		for (let i = 0; i < elements.length; i++) if (elements[i](as[i]) === false) return false;
		return true;
	};
}
/**
* Creates a predicate for objects by applying predicates to named properties.
*
* When to use:
* - You want to validate a record shape at runtime.
* - You want to lift property predicates into an object predicate.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns a refinement if any field predicate is a refinement.
* - Checks only the specified keys; extra keys are ignored.
*
* **Example** (Struct predicate)
*
* ```ts
* import { Predicate } from "effect"
*
* const userCheck = Predicate.Struct({
*   id: Predicate.isNumber,
*   name: Predicate.isString
* })
*
* console.log(userCheck({ id: 1, name: "Ada" }))
* ```
*
* See also: {@link Tuple}, {@link hasProperty}
*
* @category combinators
* @since 4.0.0
*/
function Struct(fields) {
	const keys = Object.keys(fields);
	return (a) => {
		for (const key of keys) if (!fields[key](a[key])) return false;
		return true;
	};
}
/**
* Negates a predicate.
*
* When to use:
* - You want the inverse of an existing predicate.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns a new predicate that flips the boolean result.
*
* **Example** (Negate)
*
* ```ts
* import { Predicate } from "effect"
*
* const isNotString = Predicate.not(Predicate.isString)
*
* console.log(isNotString(1))
* ```
*
* See also: {@link and}, {@link or}, {@link xor}
*
* @category combinators
* @since 2.0.0
*/
function not(self) {
	return (a) => !self(a);
}
/**
* Creates a predicate that returns `true` if either predicate is `true`.
*
* When to use:
* - You want to accept values that satisfy at least one condition.
* - You want to combine refinements with union narrowing.
*
* Behavior:
* - Pure; does not mutate input.
* - Short-circuits on the first `true`.
* - For refinements, the output type is a union.
*
* **Example** (Either condition)
*
* ```ts
* import { Predicate } from "effect"
*
* const isStringOrNumber = Predicate.or(Predicate.isString, Predicate.isNumber)
*
* console.log(isStringOrNumber("a"))
* ```
*
* See also: {@link and}, {@link xor}
*
* @category combinators
* @since 2.0.0
*/
var or = /*#__PURE__*/ dual(2, (self, that) => (a) => self(a) || that(a));
/**
* Creates a predicate that returns `true` only if both predicates are `true`.
*
* When to use:
* - You want to accept values that satisfy multiple conditions.
* - You want to combine refinements with intersection narrowing.
*
* Behavior:
* - Pure; does not mutate input.
* - Short-circuits on the first `false`.
* - For refinements, the output type is an intersection.
*
* **Example** (Both conditions)
*
* ```ts
* import { Predicate } from "effect"
*
* const hasAAndB = Predicate.and(
*   Predicate.hasProperty("a"),
*   Predicate.hasProperty("b")
* )
*
* const input: unknown = JSON.parse(`{"a":1,"b":"ok"}`)
* if (hasAAndB(input)) {
*   // input has both properties at this point
*   const a = input.a
*   const b = input.b
* }
* ```
*
* See also: {@link or}, {@link not}
*
* @category combinators
* @since 2.0.0
*/
var and = /*#__PURE__*/ dual(2, (self, that) => (a) => self(a) && that(a));
/**
* Creates a predicate that returns `true` if exactly one predicate is `true`.
*
* When to use:
* - You want an exclusive-or between two conditions.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns `true` when results differ.
*
* **Example** (Exclusive or)
*
* ```ts
* import { Predicate } from "effect"
*
* const isEven = (n: number) => n % 2 === 0
* const isPositive = (n: number) => n > 0
* const either = Predicate.xor(isEven, isPositive)
*
* console.log(either(-2))
* ```
*
* See also: {@link or}, {@link and}
*
* @category combinators
* @since 2.0.0
*/
var xor = /*#__PURE__*/ dual(2, (self, that) => (a) => self(a) !== that(a));
/**
* Creates a predicate that returns `true` when both predicates agree.
*
* When to use:
* - You want to check equivalence of two predicates.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns `true` when both results are equal.
*
* **Example** (Equivalence)
*
* ```ts
* import { Predicate } from "effect"
*
* const isEven = (n: number) => n % 2 === 0
* const same = Predicate.eqv(isEven, isEven)
*
* console.log(same(3))
* ```
*
* See also: {@link xor}
*
* @category combinators
* @since 2.0.0
*/
var eqv = /*#__PURE__*/ dual(2, (self, that) => (a) => self(a) === that(a));
/**
* Creates a predicate representing logical implication: if `antecedent`, then `consequent`.
*
* When to use:
* - You want a rule that only applies when a precondition holds.
* - You model constraints like "if A then B".
*
* Behavior:
* - Pure; does not mutate input.
* - Returns `true` when the antecedent is `false`.
*
* **Example** (Implication)
*
* ```ts
* import { Predicate } from "effect"
*
* const isAdult = (age: number) => age >= 18
* const canVote = (age: number) => age >= 18
* const implies = Predicate.implies(isAdult, canVote)
*
* console.log(implies(16))
* ```
*
* See also: {@link and}, {@link or}
*
* @category combinators
* @since 2.0.0
*/
var implies = /*#__PURE__*/ dual(2, (antecedent, consequent) => (a) => antecedent(a) ? consequent(a) : true);
/**
* Creates a predicate that returns `true` when neither predicate is `true`.
*
* When to use:
* - You want the logical NOR of two conditions.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns the negation of {@link or}.
*
* **Example** (NOR)
*
* ```ts
* import { Predicate } from "effect"
*
* const neither = Predicate.nor(Predicate.isString, Predicate.isNumber)
*
* console.log(neither(true))
* ```
*
* See also: {@link or}, {@link not}
*
* @category combinators
* @since 2.0.0
*/
var nor = /*#__PURE__*/ dual(2, (self, that) => (a) => !(self(a) || that(a)));
/**
* Creates a predicate that returns `true` unless both predicates are `true`.
*
* When to use:
* - You want the logical NAND of two conditions.
*
* Behavior:
* - Pure; does not mutate input.
* - Returns the negation of {@link and}.
*
* **Example** (NAND)
*
* ```ts
* import { Predicate } from "effect"
*
* const notBoth = Predicate.nand(Predicate.isString, Predicate.isNumber)
*
* console.log(notBoth("a"))
* ```
*
* See also: {@link and}, {@link not}
*
* @category combinators
* @since 2.0.0
*/
var nand = /*#__PURE__*/ dual(2, (self, that) => (a) => !(self(a) && that(a)));
/**
* Creates a predicate that returns `true` if all predicates in the collection return `true`.
*
* When to use:
* - You have a dynamic list of predicates to apply.
*
* Behavior:
* - Pure; does not mutate input.
* - Short-circuits on the first `false`.
* - Iterates the collection each time the predicate is called.
*
* **Example** (All checks)
*
* ```ts
* import { Predicate } from "effect"
*
* const allChecks = Predicate.every([Predicate.isNumber, (n: number) => n > 0])
*
* console.log(allChecks(2))
* ```
*
* See also: {@link some}, {@link and}
*
* @category elements
* @since 2.0.0
*/
function every(collection) {
	return (a) => {
		for (const p of collection) if (!p(a)) return false;
		return true;
	};
}
/**
* Creates a predicate that returns `true` if any predicate in the collection returns `true`.
*
* When to use:
* - You have a dynamic list of predicates and only need one to pass.
*
* Behavior:
* - Pure; does not mutate input.
* - Short-circuits on the first `true`.
* - Iterates the collection each time the predicate is called.
*
* **Example** (Any check)
*
* ```ts
* import { Predicate } from "effect"
*
* const anyCheck = Predicate.some([Predicate.isString, Predicate.isNumber])
*
* console.log(anyCheck("ok"))
* ```
*
* See also: {@link every}, {@link or}
*
* @category elements
* @since 2.0.0
*/
function some(collection) {
	return (a) => {
		for (const p of collection) if (p(a)) return true;
		return false;
	};
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Hash.js
/**
* This module provides utilities for hashing values in TypeScript.
*
* Hashing is the process of converting data into a fixed-size numeric value,
* typically used for data structures like hash tables, equality comparisons,
* and efficient data storage.
*
* @since 2.0.0
*/
var Hash_exports = /* @__PURE__ */ __exportAll({
	array: () => array,
	combine: () => combine,
	hash: () => hash,
	isHash: () => isHash,
	number: () => number,
	optimize: () => optimize,
	random: () => random,
	string: () => string,
	structure: () => structure,
	structureKeys: () => structureKeys,
	symbol: () => symbol$1
});
/**
* The unique identifier used to identify objects that implement the Hash interface.
*
* @since 2.0.0
*/
var symbol$1 = "~effect/interfaces/Hash";
/**
* Computes a hash value for any given value.
*
* This function can hash primitives (numbers, strings, booleans, etc.) as well as
* objects, arrays, and other complex data structures. It automatically handles
* different types and provides a consistent hash value for equivalent inputs.
*
* **⚠️ CRITICAL IMMUTABILITY REQUIREMENT**: Objects being hashed must be treated as
* immutable after their first hash computation. Hash results are cached, so mutating
* an object after hashing will lead to stale cached values and broken hash-based
* operations. For mutable objects, use referential equality by implementing custom
* `Hash` interface that hashes the object reference, not its content.
*
* **FORBIDDEN**: Modifying objects after `Hash.hash()` has been called on them
* **ALLOWED**: Using immutable objects, or mutable objects with custom `Hash` interface
* that uses referential equality (hashes the object reference, not content)
*
* @example
* ```ts
* import { Hash } from "effect"
*
* // Hash primitive values
* console.log(Hash.hash(42)) // numeric hash
* console.log(Hash.hash("hello")) // string hash
* console.log(Hash.hash(true)) // boolean hash
*
* // Hash objects and arrays
* console.log(Hash.hash({ name: "John", age: 30 }))
* console.log(Hash.hash([1, 2, 3]))
* console.log(Hash.hash(new Date("2023-01-01")))
* ```
*
* @category hashing
* @since 2.0.0
*/
var hash = (self) => {
	switch (typeof self) {
		case "number": return number(self);
		case "bigint": return string(self.toString(10));
		case "boolean": return string(String(self));
		case "symbol": return string(String(self));
		case "string": return string(self);
		case "undefined": return string("undefined");
		case "function":
		case "object": if (self === null) return string("null");
		else if (self instanceof Date) return string(self.toISOString());
		else if (self instanceof RegExp) return string(self.toString());
		else {
			if (byReferenceInstances.has(self)) return random(self);
			if (hashCache.has(self)) return hashCache.get(self);
			const h = withVisitedTracking$1(self, () => {
				if (isHash(self)) return self[symbol$1]();
				else if (typeof self === "function") return random(self);
				else if (Array.isArray(self)) return array(self);
				else if (self instanceof Map) return hashMap(self);
				else if (self instanceof Set) return hashSet(self);
				return structure(self);
			});
			hashCache.set(self, h);
			return h;
		}
		default: throw new Error(`BUG: unhandled typeof ${typeof self} - please report an issue at https://github.com/Effect-TS/effect/issues`);
	}
};
/**
* Generates a random hash value for an object and caches it.
*
* This function creates a random hash value for objects that don't have their own
* hash implementation. The hash value is cached using a WeakMap, so the same object
* will always return the same hash value during its lifetime.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* const obj1 = { a: 1 }
* const obj2 = { a: 1 }
*
* // Same object always returns the same hash
* console.log(Hash.random(obj1) === Hash.random(obj1)) // true
*
* // Different objects get different hashes
* console.log(Hash.random(obj1) === Hash.random(obj2)) // false
* ```
*
* @category hashing
* @since 2.0.0
*/
var random = (self) => {
	if (!randomHashCache.has(self)) randomHashCache.set(self, number(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER)));
	return randomHashCache.get(self);
};
/**
* Combines two hash values into a single hash value.
*
* This function takes two hash values and combines them using a mathematical
* operation to produce a new hash value. It's useful for creating hash values
* of composite structures.
*
* @example
* ```ts
* import { Hash } from "effect" // combined hash value
*
* // Can also be used with pipe
* import { pipe } from "effect"
*
* const hash1 = Hash.hash("hello")
* const hash2 = Hash.hash("world")
*
* // Combine two hash values
* const combined = Hash.combine(hash2)(hash1)
* console.log(combined)
* const result = pipe(hash1, Hash.combine(hash2))
* ```
*
* @category hashing
* @since 2.0.0
*/
var combine = /*#__PURE__*/ dual(2, (self, b) => self * 53 ^ b);
/**
* Optimizes a hash value by applying bit manipulation techniques.
*
* This function takes a hash value and applies bitwise operations to improve
* the distribution of hash values, reducing the likelihood of collisions.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* const rawHash = 1234567890
* const optimizedHash = Hash.optimize(rawHash)
* console.log(optimizedHash) // optimized hash value
*
* // Often used internally by other hash functions
* const stringHash = Hash.optimize(Hash.string("hello"))
* ```
*
* @category hashing
* @since 2.0.0
*/
var optimize = (n) => n & 3221225471 | n >>> 1 & 1073741824;
/**
* Checks if a value implements the Hash interface.
*
* This function determines whether a given value has the Hash symbol property,
* indicating that it can provide its own hash value implementation.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* class MyHashable implements Hash.Hash {
*   [Hash.symbol]() {
*     return 42
*   }
* }
*
* const obj = new MyHashable()
* console.log(Hash.isHash(obj)) // true
* console.log(Hash.isHash({})) // false
* console.log(Hash.isHash("string")) // false
* ```
*
* @category guards
* @since 2.0.0
*/
var isHash = (u) => hasProperty(u, symbol$1);
/**
* Computes a hash value for a number.
*
* This function creates a hash value for numeric inputs, handling special cases
* like NaN, Infinity, and -Infinity with distinct hash values. It uses bitwise operations to ensure good distribution
* of hash values across different numeric inputs.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* console.log(Hash.number(42)) // hash of 42
* console.log(Hash.number(3.14)) // hash of 3.14
* console.log(Hash.number(NaN)) // hash of "NaN"
* console.log(Hash.number(Infinity)) // 0 (special case)
*
* // Same numbers produce the same hash
* console.log(Hash.number(100) === Hash.number(100)) // true
* ```
*
* @category hashing
* @since 2.0.0
*/
var number = (n) => {
	if (n !== n) return string("NaN");
	if (n === Infinity) return string("Infinity");
	if (n === -Infinity) return string("-Infinity");
	let h = n | 0;
	if (h !== n) h ^= n * 4294967295;
	while (n > 4294967295) h ^= n /= 4294967295;
	return optimize(h);
};
/**
* Computes a hash value for a string using the djb2 algorithm.
*
* This function implements a variation of the djb2 hash algorithm, which is
* known for its good distribution properties and speed. It processes each
* character of the string to produce a consistent hash value.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* console.log(Hash.string("hello")) // hash of "hello"
* console.log(Hash.string("world")) // hash of "world"
* console.log(Hash.string("")) // hash of empty string
*
* // Same strings produce the same hash
* console.log(Hash.string("test") === Hash.string("test")) // true
* ```
*
* @category hashing
* @since 2.0.0
*/
var string = (str) => {
	let h = 5381, i = str.length;
	while (i) h = h * 33 ^ str.charCodeAt(--i);
	return optimize(h);
};
/**
* Computes a hash value for an object using only the specified keys.
*
* This function allows you to hash an object by considering only specific keys,
* which is useful when you want to create a hash based on a subset of an object's
* properties.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* const person = { name: "John", age: 30, city: "New York" }
*
* // Hash only specific keys
* const hash1 = Hash.structureKeys(person, ["name", "age"])
* const hash2 = Hash.structureKeys(person, ["name", "city"])
*
* console.log(hash1) // hash based on name and age
* console.log(hash2) // hash based on name and city
*
* // Same keys produce the same hash
* const person2 = { name: "John", age: 30, city: "Boston" }
* const hash3 = Hash.structureKeys(person2, ["name", "age"])
* console.log(hash1 === hash3) // true
* ```
*
* @category hashing
* @since 2.0.0
*/
var structureKeys = (o, keys) => {
	let h = 12289;
	for (const key of keys) h ^= combine(hash(key), hash(o[key]));
	return optimize(h);
};
/**
* Computes a hash value for an object using all of its enumerable keys.
*
* This function creates a hash value based on all enumerable properties of an object.
* It's a convenient way to hash an entire object structure when you want to consider
* all its properties.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* const obj1 = { name: "John", age: 30 }
* const obj2 = { name: "Jane", age: 25 }
* const obj3 = { name: "John", age: 30 }
*
* console.log(Hash.structure(obj1)) // hash of obj1
* console.log(Hash.structure(obj2)) // different hash
* console.log(Hash.structure(obj3)) // same as obj1
*
* // Objects with same properties produce same hash
* console.log(Hash.structure(obj1) === Hash.structure(obj3)) // true
* ```
*
* @category hashing
* @since 2.0.0
*/
var structure = (o) => structureKeys(o, getAllObjectKeys(o));
var iterableWith = (seed, f) => (iter) => {
	let h = seed;
	for (const element of iter) h ^= f(element);
	return optimize(h);
};
/**
* Computes a hash value for an array by hashing all of its elements.
*
* This function creates a hash value based on all elements in the array.
* The order of elements matters, so arrays with the same elements in different
* orders will produce different hash values.
*
* @example
* ```ts
* import { Hash } from "effect"
*
* const arr1 = [1, 2, 3]
* const arr2 = [1, 2, 3]
* const arr3 = [3, 2, 1]
*
* console.log(Hash.array(arr1)) // hash of [1, 2, 3]
* console.log(Hash.array(arr2)) // same hash as arr1
* console.log(Hash.array(arr3)) // different hash (different order)
*
* // Arrays with same elements in same order produce same hash
* console.log(Hash.array(arr1) === Hash.array(arr2)) // true
* console.log(Hash.array(arr1) === Hash.array(arr3)) // false
* ```
*
* @category hashing
* @since 2.0.0
*/
var array = /*#__PURE__*/ iterableWith(6151, hash);
var hashMap = /*#__PURE__*/ iterableWith(/*#__PURE__*/ string("Map"), ([k, v]) => combine(hash(k), hash(v)));
var hashSet = /*#__PURE__*/ iterableWith(/*#__PURE__*/ string("Set"), hash);
var randomHashCache = /*#__PURE__*/ new WeakMap();
var hashCache = /*#__PURE__*/ new WeakMap();
var visitedObjects = /*#__PURE__*/ new WeakSet();
function withVisitedTracking$1(obj, fn) {
	if (visitedObjects.has(obj)) return string("[Circular]");
	visitedObjects.add(obj);
	const result = fn();
	visitedObjects.delete(obj);
	return result;
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Equal.js
var Equal_exports = /* @__PURE__ */ __exportAll({
	asEquivalence: () => asEquivalence,
	byReference: () => byReference,
	byReferenceUnsafe: () => byReferenceUnsafe,
	equals: () => equals,
	isEqual: () => isEqual,
	makeCompareMap: () => makeCompareMap,
	makeCompareSet: () => makeCompareSet,
	symbol: () => symbol
});
/**
* The unique string identifier for the {@link Equal} interface.
*
* Use this as a computed property key when implementing custom equality on a
* class or object literal.
*
* When to use:
* - As the method name when implementing the {@link Equal} interface.
* - To check manually whether an object carries an equality method (prefer
*   {@link isEqual} instead).
*
* Behavior:
* - Pure constant — no allocation or side effects.
*
* **Example** (implementing Equal on a class)
*
* ```ts
* import { Equal, Hash } from "effect"
*
* class UserId implements Equal.Equal {
*   constructor(readonly id: string) {}
*
*   [Equal.symbol](that: Equal.Equal): boolean {
*     return that instanceof UserId && this.id === that.id
*   }
*
*   [Hash.symbol](): number {
*     return Hash.string(this.id)
*   }
* }
* ```
*
* @see {@link Equal} — the interface that uses this symbol
* @see {@link isEqual} — type guard for `Equal` implementors
*
* @since 2.0.0
*/
var symbol = "~effect/interfaces/Equal";
function equals() {
	if (arguments.length === 1) return (self) => compareBoth(self, arguments[0]);
	return compareBoth(arguments[0], arguments[1]);
}
function compareBoth(self, that) {
	if (self === that) return true;
	if (self == null || that == null) return false;
	const selfType = typeof self;
	if (selfType !== typeof that) return false;
	if (selfType === "number" && self !== self && that !== that) return true;
	if (selfType !== "object" && selfType !== "function") return false;
	if (byReferenceInstances.has(self) || byReferenceInstances.has(that)) return false;
	return withCache(self, that, compareObjects);
}
/** Helper to run comparison with proper visited tracking */
function withVisitedTracking(self, that, fn) {
	const hasLeft = visitedLeft.has(self);
	const hasRight = visitedRight.has(that);
	if (hasLeft && hasRight) return true;
	if (hasLeft || hasRight) return false;
	visitedLeft.add(self);
	visitedRight.add(that);
	const result = fn();
	visitedLeft.delete(self);
	visitedRight.delete(that);
	return result;
}
var visitedLeft = /*#__PURE__*/ new WeakSet();
var visitedRight = /*#__PURE__*/ new WeakSet();
/** Helper to perform cached object comparison */
function compareObjects(self, that) {
	if (hash(self) !== hash(that)) return false;
	else if (self instanceof Date) {
		if (!(that instanceof Date)) return false;
		return self.toISOString() === that.toISOString();
	} else if (self instanceof RegExp) {
		if (!(that instanceof RegExp)) return false;
		return self.toString() === that.toString();
	}
	const selfIsEqual = isEqual(self);
	const thatIsEqual = isEqual(that);
	if (selfIsEqual !== thatIsEqual) return false;
	const bothEquals = selfIsEqual && thatIsEqual;
	if (typeof self === "function" && !bothEquals) return false;
	return withVisitedTracking(self, that, () => {
		if (bothEquals) return self[symbol](that);
		else if (Array.isArray(self)) {
			if (!Array.isArray(that) || self.length !== that.length) return false;
			return compareArrays(self, that);
		} else if (self instanceof Map) {
			if (!(that instanceof Map) || self.size !== that.size) return false;
			return compareMaps(self, that);
		} else if (self instanceof Set) {
			if (!(that instanceof Set) || self.size !== that.size) return false;
			return compareSets(self, that);
		}
		return compareRecords(self, that);
	});
}
function withCache(self, that, f) {
	let selfMap = equalityCache.get(self);
	if (!selfMap) {
		selfMap = /* @__PURE__ */ new WeakMap();
		equalityCache.set(self, selfMap);
	} else if (selfMap.has(that)) return selfMap.get(that);
	const result = f(self, that);
	selfMap.set(that, result);
	let thatMap = equalityCache.get(that);
	if (!thatMap) {
		thatMap = /* @__PURE__ */ new WeakMap();
		equalityCache.set(that, thatMap);
	}
	thatMap.set(self, result);
	return result;
}
var equalityCache = /*#__PURE__*/ new WeakMap();
function compareArrays(self, that) {
	for (let i = 0; i < self.length; i++) if (!compareBoth(self[i], that[i])) return false;
	return true;
}
function compareRecords(self, that) {
	const selfKeys = getAllObjectKeys(self);
	const thatKeys = getAllObjectKeys(that);
	if (selfKeys.size !== thatKeys.size) return false;
	for (const key of selfKeys) if (!thatKeys.has(key) || !compareBoth(self[key], that[key])) return false;
	return true;
}
/** @internal */
function makeCompareMap(keyEquivalence, valueEquivalence) {
	return function compareMaps(self, that) {
		for (const [selfKey, selfValue] of self) {
			let found = false;
			for (const [thatKey, thatValue] of that) if (keyEquivalence(selfKey, thatKey) && valueEquivalence(selfValue, thatValue)) {
				found = true;
				break;
			}
			if (!found) return false;
		}
		return true;
	};
}
var compareMaps = /*#__PURE__*/ makeCompareMap(compareBoth, compareBoth);
/** @internal */
function makeCompareSet(equivalence) {
	return function compareSets(self, that) {
		for (const selfValue of self) {
			let found = false;
			for (const thatValue of that) if (equivalence(selfValue, thatValue)) {
				found = true;
				break;
			}
			if (!found) return false;
		}
		return true;
	};
}
var compareSets = /*#__PURE__*/ makeCompareSet(compareBoth);
/**
* Checks whether a value implements the {@link Equal} interface.
*
* When to use:
* - To branch on whether a value supports custom equality before calling
*   its `[Equal.symbol]` method directly.
* - In generic utility code that needs to distinguish `Equal` implementors
*   from plain values.
*
* Behavior:
* - Pure function, no side effects.
* - Returns `true` if and only if `u` has a property keyed by
*   {@link symbol}.
* - Acts as a TypeScript type guard, narrowing the input to {@link Equal}.
*
* **Example** (type guard)
*
* ```ts
* import { Equal, Hash } from "effect"
*
* class Token implements Equal.Equal {
*   constructor(readonly value: string) {}
*   [Equal.symbol](that: Equal.Equal): boolean {
*     return that instanceof Token && this.value === that.value
*   }
*   [Hash.symbol](): number {
*     return Hash.string(this.value)
*   }
* }
*
* console.log(Equal.isEqual(new Token("abc"))) // true
* console.log(Equal.isEqual({ x: 1 }))         // false
* console.log(Equal.isEqual(42))                // false
* ```
*
* @see {@link Equal} — the interface being checked
* @see {@link symbol} — the property key that signals `Equal` support
*
* @category guards
* @since 2.0.0
*/
var isEqual = (u) => hasProperty(u, symbol);
/**
* Wraps {@link equals} as an `Equivalence<A>`.
*
* When to use:
* - When an API (e.g. `Array.dedupeWith`, `Equivalence.mapInput`) requires an
*   `Equivalence` and you want to reuse `Equal.equals`.
*
* Behavior:
* - Returns a function `(a: A, b: A) => boolean` that delegates to
*   {@link equals}.
* - Pure; allocates a thin wrapper on each call.
*
* **Example** (deduplicating with Equal semantics)
*
* ```ts
* import { Array, Equal } from "effect"
*
* const eq = Equal.asEquivalence<number>()
* const result = Array.dedupeWith([1, 2, 2, 3, 1], eq)
* console.log(result) // [1, 2, 3]
* ```
*
* @see {@link equals} — the underlying comparison function
*
* @category instances
* @since 2.0.0
*/
var asEquivalence = () => equals;
/**
* Creates a proxy that uses reference equality instead of structural equality.
*
* When to use:
* - When you have a plain object or array that should be compared by identity
*   (reference), not by contents.
* - When you want to preserve the original object unchanged and get a new
*   reference-equal handle.
*
* Behavior:
* - Returns a `Proxy` wrapping `obj`. The proxy reads through to the
*   original, so property access is unchanged.
* - The proxy is registered in an internal WeakSet; {@link equals} returns
*   `false` for any pair where at least one operand is in that set (unless
*   they are the same reference).
* - Each call creates a **new** proxy, so `byReference(x) !== byReference(x)`.
* - Does **not** mutate the original object (unlike {@link byReferenceUnsafe}).
*
* **Example** (opting out of structural equality)
*
* ```ts
* import { Equal } from "effect"
*
* const a = { x: 1 }
* const b = { x: 1 }
*
* console.log(Equal.equals(a, b)) // true  (structural)
*
* const aRef = Equal.byReference(a)
* console.log(Equal.equals(aRef, b))    // false (reference)
* console.log(Equal.equals(aRef, aRef)) // true  (same reference)
* console.log(aRef.x)                   // 1     (proxy reads through)
* ```
*
* @see {@link byReferenceUnsafe} — same effect without a proxy (mutates the
*   original)
* @see {@link equals} — the comparison function affected by this opt-out
*
* @category utility
* @since 2.0.0
*/
var byReference = (obj) => byReferenceUnsafe(new Proxy(obj, {}));
/**
* Permanently marks an object to use reference equality, without creating a
* proxy.
*
* When to use:
* - When you want reference equality semantics and can accept that the
*   original object is **permanently** modified.
* - When proxy overhead is unacceptable (hot paths, large collections).
*
* Behavior:
* - Adds `obj` to an internal WeakSet. From that point on, {@link equals}
*   treats it as reference-only.
* - Returns the **same** object (not a copy or proxy), so
*   `byReferenceUnsafe(x) === x`.
* - The marking is irreversible for the lifetime of the object.
* - Does **not** affect the object's prototype, properties, or behavior
*   beyond equality checks.
*
* **Example** (marking an object for reference equality)
*
* ```ts
* import { Equal } from "effect"
*
* const obj1 = { a: 1, b: 2 }
* const obj2 = { a: 1, b: 2 }
*
* Equal.byReferenceUnsafe(obj1)
*
* console.log(Equal.equals(obj1, obj2))   // false (reference)
* console.log(Equal.equals(obj1, obj1))   // true  (same reference)
* console.log(obj1 === Equal.byReferenceUnsafe(obj1)) // true (same object)
* ```
*
* @see {@link byReference} — safer alternative that creates a proxy
* @see {@link equals} — the comparison function affected by this opt-out
*
* @category utility
* @since 2.0.0
*/
var byReferenceUnsafe = (obj) => {
	byReferenceInstances.add(obj);
	return obj;
};
//#endregion
export { flow as $, isNull as A, isTupleOfAtLeast as B, isBoolean as C, isNever as D, isIterable as E, isRegExp as F, coerceUnsafe as G, isUnknown as H, isString as I, constTrue as J, constFalse as K, isSymbol as L, isObject as M, isObjectKeyword as N, isNotNullish as O, isPropertyKey as P, dual as Q, isTagged as R, isBigInt as S, isFunction as T, Function_exports as U, isUndefined as V, absurd as W, constVoid as X, constUndefined as Y, constant as Z, structure as _, equals as a, Pipeable_exports as at, Predicate_exports as b, makeCompareSet as c, array as d, hole as et, combine as f, string as g, random as h, byReferenceUnsafe as i, Class as it, isNumber as j, isNotUndefined as k, symbol as l, number as m, asEquivalence as n, memoize as nt, isEqual as o, pipeArguments as ot, hash as p, constNull as q, byReference as r, pipe as rt, makeCompareMap as s, Equal_exports as t, identity as tt, Hash_exports as u, structureKeys as v, isDate as w, hasProperty as x, symbol$1 as y, isTupleOf as z };
