import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { I as isString, Q as dual, V as isUndefined } from "./Equal-CgzkNqbP.js";
import { Oi as Random$1, Xr as withFiber, ur as succeed, yn as provideService } from "./Effect-DrBRDdmt.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Random.js
/**
* The Random module provides a service for generating random numbers in Effect
* programs. It offers a testable and composable way to work with randomness,
* supporting integers, floating-point numbers, and range-based generation.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const randomFloat = yield* Random.next
*   console.log("Random float:", randomFloat)
*
*   const randomInt = yield* Random.nextInt
*   console.log("Random integer:", randomInt)
*
*   const diceRoll = yield* Random.nextIntBetween(1, 6)
*   console.log("Dice roll:", diceRoll)
* })
* ```
*
* @since 4.0.0
*/
var Random_exports = /* @__PURE__ */ __exportAll({
	Random: () => Random,
	next: () => next,
	nextBetween: () => nextBetween,
	nextBoolean: () => nextBoolean,
	nextInt: () => nextInt,
	nextIntBetween: () => nextIntBetween,
	nextUUIDv4: () => nextUUIDv4,
	shuffle: () => shuffle,
	withSeed: () => withSeed
});
/**
* Represents a service for generating random numbers.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const float = yield* Random.next
*   const integer = yield* Random.nextInt
*   const inRange = yield* Random.nextIntBetween(1, 100)
*   const uuid = yield* Random.nextUUIDv4
*
*   console.log("Float:", float)
*   console.log("Integer:", integer)
*   console.log("In range:", inRange)
*   console.log("UUID:", uuid)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var Random = Random$1;
var randomWith = (f) => withFiber((fiber) => succeed(f(fiber.getRef(Random))));
/**
* Generates a random number between 0 (inclusive) and 1 (inclusive).
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const randomDouble = yield* Random.next
*   console.log("Random double:", randomDouble)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var next = /*#__PURE__*/ randomWith((r) => r.nextDoubleUnsafe());
/**
* Generates a random boolean value.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const value = yield* Random.nextBoolean
*   console.log("Random boolean:", value)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var nextBoolean = /*#__PURE__*/ randomWith((r) => r.nextDoubleUnsafe() > .5);
/**
* Generates a random integer between `Number.MIN_SAFE_INTEGER` (inclusive)
* and `Number.MAX_SAFE_INTEGER` (inclusive).
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const randomInt = yield* Random.nextInt
*   console.log("Random integer:", randomInt)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var nextInt = /*#__PURE__*/ randomWith((r) => r.nextIntUnsafe());
/**
* Generates a random number between `min` (inclusive) and `max` (inclusive).
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const randomDouble = yield* Random.nextBetween(0, 1)
*   console.log("Random double: ", randomDouble)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var nextBetween = (min, max) => randomWith((r) => r.nextDoubleUnsafe() * (max - min) + min);
/**
* Generates a random number between `min` (inclusive) and `max` (inclusive).
*
* Set `options.halfOpen: true` to generate in the half-open range
* `[min, max)`.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const diceRoll1 = yield* Random.nextIntBetween(1, 6)
*   const diceRoll2 = yield* Random.nextIntBetween(1, 6, {
*     halfOpen: true
*   })
*   const diceRoll3 = yield* Random.nextIntBetween(0, 10)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var nextIntBetween = (min, max, options) => {
	const extra = options?.halfOpen === true ? 0 : 1;
	return randomWith((r) => {
		const minInt = Math.ceil(min);
		const maxInt = Math.floor(max);
		return Math.floor(r.nextDoubleUnsafe() * (maxInt - minInt + extra)) + minInt;
	});
};
/**
* Uses the pseudo-random number generator to shuffle the specified iterable.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Random.shuffle([1, 2, 3, 4, 5])
*   console.log(values)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var shuffle = (elements) => randomWith((r) => {
	const buffer = Array.from(elements);
	for (let i = buffer.length - 1; i >= 1; i = i - 1) {
		const index = Math.min(i, Math.floor(r.nextDoubleUnsafe() * (i + 1)));
		const value = buffer[i];
		buffer[i] = buffer[index];
		buffer[index] = value;
	}
	return buffer;
});
/**
* Generates a random UUID (v4) string.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const uuid = yield* Random.nextUUIDv4
*   console.log("UUID:", uuid)
* })
* ```
*
* @since 4.0.0
* @category Random Number Generators
*/
var nextUUIDv4 = /*#__PURE__*/ randomWith((r) => {
	const bytes = [];
	for (let i = 0; i < 16; i++) bytes.push(r.nextIntUnsafe() >>> 0 & 255);
	bytes[6] = bytes[6] & 15 | 64;
	bytes[8] = bytes[8] & 63 | 128;
	const hex = (n) => n.toString(16).padStart(2, "0");
	return [
		bytes.slice(0, 4).map(hex).join(""),
		bytes.slice(4, 6).map(hex).join(""),
		bytes.slice(6, 8).map(hex).join(""),
		bytes.slice(8, 10).map(hex).join(""),
		bytes.slice(10, 16).map(hex).join("")
	].join("-");
});
/**
* Seeds the pseudorandom number generator with the specified value.
*
* Take care to select a seed wit hhigh entropy to avoid issues with the
* quality of random number generation.
*
* @example
* ```ts
* import { Effect, Random } from "effect"
*
* const program = Effect.gen(function*() {
*   const value1 = yield* Random.next
*   const value2 = yield* Random.next
*   console.log(value1, value2)
* })
*
* // Same seed produces same sequence
* const seeded1 = program.pipe(Random.withSeed("my-seed"))
* const seeded2 = program.pipe(Random.withSeed("my-seed"))
*
* // Both will output identical values
* Effect.runPromise(seeded1)
* Effect.runPromise(seeded2)
* ```
*
* @since 4.0.0
* @category Seeding
*/
var withSeed = /*#__PURE__*/ dual(2, (self, seed) => provideService(self, Random, ISAAC_CSPRNG(seed)));
function ISAAC_CSPRNG(userSeed) {
	const memory = new Array(256);
	const result = new Array(256);
	let accumulator = 0;
	let lastResult = 0;
	let generation = 0;
	let counter = 0;
	seed(isUndefined(userSeed) ? getInitialSeed() : userSeed);
	function getInitialSeed() {
		const uint32a = /* @__PURE__ */ new Uint32Array(2);
		crypto.getRandomValues(uint32a);
		return uint32a[0] + uint32a[1];
	}
	function reset() {
		accumulator = 0;
		lastResult = 0;
		counter = 0;
		for (let i = 0; i < 256; ++i) {
			memory[i] = 0;
			result[i] = 0;
		}
		generation = 0;
	}
	function seed(userSeed) {
		const magicNumber = 2654435769;
		let a = magicNumber;
		let b = magicNumber;
		let c = magicNumber;
		let d = magicNumber;
		let e = magicNumber;
		let f = magicNumber;
		let g = magicNumber;
		let h = magicNumber;
		let i = 0;
		let seed;
		if (isString(userSeed)) seed = toIntArray(userSeed);
		else seed = [userSeed];
		reset();
		for (i = 0; i < seed.length; i++) result[i & 255] += seed[i];
		function mix() {
			a ^= b << 11;
			d = add32(d, a);
			b = add32(b, c);
			b ^= c >>> 2;
			e = add32(e, b);
			c = add32(c, d);
			c ^= d << 8;
			f = add32(f, c);
			d = add32(d, e);
			d ^= e >>> 16;
			g = add32(g, d);
			e = add32(e, f);
			e ^= f << 10;
			h = add32(h, e);
			f = add32(f, g);
			f ^= g >>> 4;
			a = add32(a, f);
			g = add32(g, h);
			g ^= h << 8;
			b = add32(b, g);
			h = add32(h, a);
			h ^= a >>> 9;
			c = add32(c, h);
			a = add32(a, b);
		}
		for (i = 0; i < 4; i++) mix();
		for (i = 0; i < 256; i += 8) {
			a = add32(a, result[i]);
			b = add32(b, result[i + 1]);
			c = add32(c, result[i + 2]);
			d = add32(d, result[i + 3]);
			e = add32(e, result[i + 4]);
			f = add32(f, result[i + 5]);
			g = add32(g, result[i + 6]);
			h = add32(h, result[i + 7]);
			mix();
			memory[i] = a;
			memory[i + 1] = b;
			memory[i + 2] = c;
			memory[i + 3] = d;
			memory[i + 4] = e;
			memory[i + 5] = f;
			memory[i + 6] = g;
			memory[i + 7] = h;
		}
		for (i = 0; i < 256; i += 8) {
			a = add32(a, memory[i]);
			b = add32(b, memory[i + 1]);
			c = add32(c, memory[i + 2]);
			d = add32(d, memory[i + 3]);
			e = add32(e, memory[i + 4]);
			f = add32(f, memory[i + 5]);
			g = add32(g, memory[i + 6]);
			h = add32(h, memory[i + 7]);
			mix();
			memory[i] = a;
			memory[i + 1] = b;
			memory[i + 2] = c;
			memory[i + 3] = d;
			memory[i + 4] = e;
			memory[i + 5] = f;
			memory[i + 6] = g;
			memory[i + 7] = h;
		}
		pnrg();
		generation = 256;
	}
	function pnrg(n) {
		let i = 0;
		let x = 0;
		let y = 0;
		n = isUndefined(n) ? 1 : Math.abs(Math.floor(n));
		while (n--) {
			counter = add32(counter, 1);
			lastResult = add32(lastResult, counter);
			for (i = 0; i < 256; i++) {
				switch (i & 3) {
					case 0:
						accumulator ^= accumulator << 13;
						break;
					case 1:
						accumulator ^= accumulator >>> 6;
						break;
					case 2:
						accumulator ^= accumulator << 2;
						break;
					case 3:
						accumulator ^= accumulator >>> 16;
						break;
				}
				accumulator = add32(memory[i + 128 & 255], accumulator);
				x = memory[i];
				memory[i] = add32(memory[x >>> 2 & 255], add32(accumulator, lastResult));
				y = memory[i];
				result[i] = add32(memory[y >>> 10 & 255], x);
				lastResult = result[i];
			}
		}
	}
	/**
	* Returns a signed, random integer in the range [-2^31, 2^31].
	*/
	function nextInt32() {
		if (!generation--) {
			pnrg();
			generation = 255;
		}
		return result[generation];
	}
	function nextIntUnsafe() {
		const low = nextInt32() >>> 0;
		return (nextInt32() & 2097151) * 4294967296 + low - 4503599627370496;
	}
	/**
	* Returns a 53-bit fraction in the range [0, 1).
	*/
	function nextDoubleUnsafe() {
		const hi = nextInt32() >>> 0 & 2097151;
		const lo = nextInt32() >>> 0;
		return (hi * 4294967296 + lo) / 9007199254740991;
	}
	return {
		nextIntUnsafe,
		nextDoubleUnsafe
	};
}
/**
* 32-bit addition with overflow handling (JavaScript numbers are 53-bit).
*
* Example: add32(0xFFFFFFFF, 0x00000001) = 0x00000000 (wraps around)
*/
function add32(x, y) {
	const lsb = (x & 65535) + (y & 65535);
	return (x >>> 16) + (y >>> 16) + (lsb >>> 16) << 16 | lsb & 65535;
}
/**
* Convert a UTF-16 strings to UTF-8 encoded 32-bit integers (little-endian).
*/
function toIntArray(seed) {
	let c1 = 0;
	let c2 = 0;
	let unicode = 0;
	const result = [];
	const buffer = [];
	const length = seed.length - 1;
	let index = 0;
	while (index < length) {
		c1 = seed.charCodeAt(index++);
		c2 = seed.charCodeAt(index + 1);
		if (c1 < 128) buffer.push(c1);
		else if (c1 < 2048) {
			buffer.push(c1 >>> 6 & 31 | 192);
			buffer.push(c1 >>> 0 & 63 | 128);
		} else if ((c1 & 63488) != 55296) {
			buffer.push(c1 >>> 12 & 15 | 224);
			buffer.push(c1 >>> 6 & 63 | 128);
			buffer.push(c1 >>> 0 & 63 | 128);
		} else if ((c1 & 64512) == 55296 && (c2 & 64512) == 56320) {
			unicode = (c2 & 63 | (c1 & 63) << 10) + 65536;
			buffer.push(unicode >>> 18 & 7 | 240);
			buffer.push(unicode >>> 12 & 63 | 128);
			buffer.push(unicode >>> 6 & 63 | 128);
			buffer.push(unicode >>> 0 & 63 | 128);
			index++;
		}
		if (buffer.length > 3) result.push(buffer.shift() << 0 | buffer.shift() << 8 | buffer.shift() << 16 | buffer.shift() << 24);
	}
	return result;
}
//#endregion
export { Random, next, nextBetween, nextBoolean, nextInt, nextIntBetween, nextUUIDv4, shuffle, Random_exports as t, withSeed };
