import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalComposerContext.dev.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function formatDevErrorMessage(message) {
	throw new Error(message);
}
var LexicalComposerContext = /*#__PURE__*/ (0, import_react.createContext)(null);
function createLexicalComposerContext(parent, theme) {
	let parentContext = null;
	if (parent != null) parentContext = parent[1];
	function getTheme() {
		if (theme != null) return theme;
		return parentContext != null ? parentContext.getTheme() : null;
	}
	return { getTheme };
}
function useLexicalComposerContext() {
	const composerContext = (0, import_react.useContext)(LexicalComposerContext);
	if (composerContext == null) formatDevErrorMessage(`LexicalComposerContext.useLexicalComposerContext: cannot find a LexicalComposerContext`);
	return composerContext;
}
//#endregion
export { LexicalComposerContext, createLexicalComposerContext, useLexicalComposerContext };
