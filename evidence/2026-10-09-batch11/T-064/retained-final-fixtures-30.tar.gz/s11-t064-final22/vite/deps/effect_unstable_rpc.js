import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { $ as flow, J as constTrue, Q as dual, X as constVoid, Z as constant, _ as structure, d as array, l as symbol$1, ot as pipeArguments, tt as identity, x as hasProperty, y as symbol$2 } from "./Equal-CgzkNqbP.js";
import { C as makeEquivalence, Cr as strictEqual, E as map, Gn as BaseProto, Jn as NodeInspectSymbol, Q as isSuccess, Qn as format, Sr as make$9, ar as redact$1, bt as isSome, or as symbolRedactable, sn as PipeInspectableProto } from "./Record-BrB0racz.js";
import { $r as withParentSpan, Al as empty$6, Ao as provide$1, At as isEffect, B as delay, Bo as close, Br as updateService, C as callback, Ci as catchDone, Cl as externalSpan, Cr as timeout, D as catchDefect, Dl as Service$1, Do as effectDiscard, Ds as hasDies, Dt as interrupt$1, El as Reference, Eo as effect, Fu as makeEquivalence$1, Go as makeUnsafe$1, Gt as map$1, Hr as useSpan, Il as makeUnsafe, Io as Scope, It as logDebug, Jn as sandbox, Jo as _await, K as fail$1, Ko as provide$2, Kr as whileLoop, Ll as merge$1, Lt as logError, M as catchReason, Mo as succeed, Ms as interruptors, Nl as getUnsafe, Nn as retry, No as succeedServices, Oo as effectServices, Ot as interruptible, Rl as omit, Ro as addFinalizer, Rt as logFatal, So as CurrentMemoMap, Tn as raceFirst, Ts as findError, Tt as ignore, U as ensuring, Uo as forkUnsafe, V as die$1, Vo as closeUnsafe, Vr as updateServices, Vs as squash, Wo as make$10, Wr as void_, Wt as makeSpanScoped, Xc as reportCauseUnsafe, Xr as withFiber, Yt as mapError, _i as exponential, _t as forkDetach, _u as empty$7, an as onError, ar as services, as as fail, br as tapError, cn as onExit, d as annotateLogs, dr as succeedNone, ds as isFailure, ei as withSpan, en as matchCauseEffect, er as scope, es as make$11, fn as onInterrupt, ft as fnUntraced, gi as either, gr as tapCause, gt as forkChild, h as asSome, hr as tap, ht as forever, in as never, ir as serviceOption, is as die, jl as get, jo as provideMerge, kl as add, ks as hasInterrupts$1, l as andThen, ls as interrupt, mn as orDie, mr as sync, mt as forEach, ns as succeed$2, or as servicesWith, os as failCause, pr as suspend, rn as matchEffect, sd as makeEquivalence$2, st as flatMap, tr as scoped, ur as succeed$1, vn as provide, vt as forkIn, w as catchCause, wo as buildWithMemoMap, wt as gen, wu as fromIterable$1, xl as ParentSpan, xn as provideServices, yi as spaced, yn as provideService, yo as TaggedError, yt as forkScoped, zn as runForkWith, zo as addFinalizerExit, zs as map$3 } from "./Effect-DrBRDdmt.js";
import { E as ErrorClass, H as NonEmptyArray, R as Literals, Sn as encodeSync, So as make$12, V as Never, Vt as Union, _n as encodeEffect, dn as decodeUnknownEffect, ei as optional, ln as decodeSync, mi as tag, mt as String$1, n as Array$1, t as Any, wn as encodeUnknownEffect, y as Defect, yi as toCodecJson } from "./Schema-DuK_yWH0.js";
import { a as make$13, c as ignore$1, i as get$1, o as makeWithTTL, t as Stdio } from "./Stdio-Be9al6EE.js";
import { An as makeUnsafe$3, Bn as runIn, Jt as makeUnsafe$2, Nn as getCurrent, Pn as interrupt$2, Qt as end, Xt as bounded, Zt as collect, an as offerAll, en as failCause$1, in as offer, ln as take, qt as make$14, rn as make$15, sn as offerUnsafe, un as takeAll } from "./Channel-BalfMI2y.js";
import { C as unwrap, a as concat, b as runForEach, f as fromQueue, s as fromArray, x as runForEachArray, y as run } from "./PrimaryKey-BilJj_MP.js";
import { a as isWrapper, d as getStreamSchemas, f as isStreamSchema, l as ClientAbort$1, n as exitSchema, t as Rpc_exports, u as RpcSchema_exports } from "./Rpc-DrEN5nNz.js";
import { Socket, SocketCloseError, SocketError, SocketErrorReason, SocketOpenError } from "./effect_unstable_socket_Socket.js";
import { t as RpcGroup_exports } from "./effect_unstable_rpc_RpcGroup.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/Headers.js
/**
* @since 4.0.0
*/
/**
* This is a symbol to allow direct access of keys without conflicts.
*
* @since 4.0.0
* @category type ids
*/
var TypeId$15 = /*#__PURE__*/ Symbol.for("~effect/http/Headers");
var Proto$6 = /*#__PURE__*/ Object.create(null);
Object.defineProperties(Proto$6, {
	[TypeId$15]: { value: TypeId$15 },
	[symbolRedactable]: { value(context) {
		return redact(this, get(context, CurrentRedactedNames));
	} },
	toJSON: { value() {
		return redact$1(this);
	} },
	[symbol$1]: { value(that) {
		return Equivalence$1(this, that);
	} },
	[symbol$2]: { value() {
		return structure(this);
	} },
	toString: { value: BaseProto.toString },
	[NodeInspectSymbol]: { value: BaseProto[NodeInspectSymbol] }
});
var make$8 = (input) => Object.assign(Object.create(Proto$6), input);
/**
* @since 4.0.0
* @category Equivalence
*/
var Equivalence$1 = /*#__PURE__*/ makeEquivalence(/*#__PURE__*/ strictEqual());
/**
* @since 4.0.0
* @category constructors
*/
var empty$5 = /*#__PURE__*/ Object.create(Proto$6);
/**
* @since 4.0.0
* @category constructors
*/
var fromInput$1 = (input) => {
	if (input === void 0) return empty$5;
	else if (Symbol.iterator in input) {
		const out = Object.create(Proto$6);
		for (const [k, v] of input) out[k.toLowerCase()] = v;
		return out;
	}
	const out = Object.create(Proto$6);
	for (const [k, v] of Object.entries(input)) if (Array.isArray(v)) out[k.toLowerCase()] = v.join(", ");
	else if (v !== void 0) out[k.toLowerCase()] = v;
	return out;
};
/**
* @since 4.0.0
* @category constructors
*/
var fromRecordUnsafe = (input) => Object.setPrototypeOf(input, Proto$6);
/**
* @since 4.0.0
* @category combinators
*/
var set = /*#__PURE__*/ dual(3, (self, key, value) => {
	const out = make$8(self);
	out[key.toLowerCase()] = value;
	return out;
});
/**
* @since 4.0.0
* @category combinators
*/
var setAll$1 = /*#__PURE__*/ dual(2, (self, headers) => make$8({
	...self,
	...fromInput$1(headers)
}));
/**
* @since 4.0.0
* @category combinators
*/
var merge = /*#__PURE__*/ dual(2, (self, headers) => {
	const out = make$8(self);
	Object.assign(out, headers);
	return out;
});
/**
* @since 4.0.0
* @category combinators
*/
var remove = /*#__PURE__*/ dual(2, (self, key) => {
	const out = make$8(self);
	delete out[key.toLowerCase()];
	return out;
});
/**
* @since 4.0.0
* @category combinators
*/
var redact = /*#__PURE__*/ dual(2, (self, key) => {
	const out = { ...self };
	const modify = (key) => {
		if (typeof key === "string") {
			const k = key.toLowerCase();
			if (k in self) out[k] = make$12(self[k]);
		} else for (const name in self) if (key.test(name)) out[name] = make$12(self[name]);
	};
	if (Array.isArray(key)) for (let i = 0; i < key.length; i++) modify(key[i]);
	else modify(key);
	return out;
});
/**
* @since 4.0.0
* @category fiber refs
*/
var CurrentRedactedNames = /*#__PURE__*/ Reference("effect/Headers/CurrentRedactedNames", { defaultValue: () => [
	"authorization",
	"cookie",
	"set-cookie",
	"x-api-key"
] });
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/UrlParams.js
/**
* @since 4.0.0
*/
var TypeId$14 = "~effect/http/UrlParams";
var Proto$5 = {
	...PipeInspectableProto,
	[TypeId$14]: TypeId$14,
	[Symbol.iterator]() {
		return this.params[Symbol.iterator]();
	},
	toJSON() {
		return {
			_id: "UrlParams",
			params: Object.fromEntries(this.params)
		};
	},
	[symbol$1](that) {
		return Equivalence(this, that);
	},
	[symbol$2]() {
		return array(this.params.flat());
	}
};
/**
* @since 4.0.0
* @category constructors
*/
var make$7 = (params) => {
	const self = Object.create(Proto$5);
	self.params = params;
	return self;
};
/**
* @since 4.0.0
* @category constructors
*/
var fromInput = (input) => {
	const parsed = fromInputNested(input);
	const out = [];
	for (let i = 0; i < parsed.length; i++) if (Array.isArray(parsed[i][0])) {
		const [keys, value] = parsed[i];
		out.push([`${keys[0]}[${keys.slice(1).join("][")}]`, value]);
	} else out.push(parsed[i]);
	return make$7(out);
};
var fromInputNested = (input) => {
	const entries = typeof input[Symbol.iterator] === "function" ? fromIterable$1(input) : Object.entries(input);
	const out = [];
	for (const [key, value] of entries) if (Array.isArray(value)) {
		for (let i = 0; i < value.length; i++) if (value[i] !== void 0) out.push([key, String(value[i])]);
	} else if (typeof value === "object") {
		const nested = fromInputNested(value);
		for (const [k, v] of nested) out.push([[key, ...typeof k === "string" ? [k] : k], v]);
	} else if (value !== void 0) out.push([key, String(value)]);
	return out;
};
/**
* @since 4.0.0
* @category Equivalence
*/
var Equivalence = /*#__PURE__*/ make$9((a, b) => arrayEquivalence(a.params, b.params));
var arrayEquivalence = /*#__PURE__*/ makeEquivalence$1(/*#__PURE__*/ makeEquivalence$2([/*#__PURE__*/ strictEqual(), /*#__PURE__*/ strictEqual()]));
/**
* @since 4.0.0
* @category constructors
*/
var empty$4 = /*#__PURE__*/ make$7([]);
/**
* @since 4.0.0
* @category combinators
*/
var setAll = /*#__PURE__*/ dual(2, (self, input) => {
	const out = fromInput(input);
	const params = out.params;
	const keys = /* @__PURE__ */ new Set();
	for (let i = 0; i < params.length; i++) keys.add(params[i][0]);
	for (let i = 0; i < self.params.length; i++) {
		if (keys.has(self.params[i][0])) continue;
		params.push(self.params[i]);
	}
	return out;
});
TaggedError("UrlParamsError");
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpBody.js
/**
* @since 4.0.0
*/
var TypeId$13 = "~effect/http/HttpBody";
TaggedError("HttpBodyError");
var Proto$4 = class {
	[TypeId$13];
	constructor() {
		this[TypeId$13] = TypeId$13;
	}
	[NodeInspectSymbol]() {
		return this.toJSON();
	}
	toString() {
		return format(this, { ignoreToString: true });
	}
};
/**
* @since 4.0.0
* @category models
*/
var Empty = class extends Proto$4 {
	_tag = "Empty";
	toJSON() {
		return {
			_id: "effect/HttpBody",
			_tag: "Empty"
		};
	}
};
/**
* @since 4.0.0
* @category constructors
*/
var empty$3 = /*#__PURE__*/ new Empty();
/**
* @since 4.0.0
* @category models
*/
var Uint8Array$1 = class extends Proto$4 {
	_tag = "Uint8Array";
	body;
	contentType;
	contentLength;
	constructor(body, contentType, contentLength) {
		super();
		this.body = body;
		this.contentType = contentType;
		this.contentLength = contentLength;
	}
	toJSON() {
		return {
			_id: "effect/HttpBody",
			_tag: "Uint8Array",
			body: this.contentType.startsWith("text/") || this.contentType.endsWith("json") ? new TextDecoder().decode(this.body) : `Uint8Array(${this.body.length})`,
			contentType: this.contentType,
			contentLength: this.contentLength
		};
	}
};
/**
* @since 4.0.0
* @category constructors
*/
var uint8Array$1 = (body, contentType) => new Uint8Array$1(body, contentType ?? "application/octet-stream", body.length);
var encoder = /*#__PURE__*/ new TextEncoder();
/**
* @since 4.0.0
* @category constructors
*/
var text$1 = (body, contentType) => uint8Array$1(encoder.encode(body), contentType ?? "text/plain");
/**
* @since 4.0.0
* @category models
*/
var Stream = class extends Proto$4 {
	_tag = "Stream";
	stream;
	contentType;
	contentLength;
	constructor(stream, contentType, contentLength) {
		super();
		this.stream = stream;
		this.contentType = contentType;
		this.contentLength = contentLength;
	}
	toJSON() {
		return {
			_id: "effect/HttpBody",
			_tag: "Stream",
			contentType: this.contentType,
			contentLength: this.contentLength
		};
	}
};
/**
* @since 4.0.0
* @category constructors
*/
var stream$1 = (body, contentType, contentLength) => new Stream(body, contentType ?? "application/octet-stream", contentLength);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/Cookies.js
/**
* @since 4.0.0
*/
var TypeId$12 = "~effect/http/Cookies";
TaggedError("CookieError");
var Proto$3 = {
	[TypeId$12]: TypeId$12,
	...BaseProto,
	toJSON() {
		return {
			_id: "effect/Cookies",
			cookies: map(this.cookies, (cookie) => cookie.toJSON())
		};
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Create a Cookies object from an Iterable
*
* @since 4.0.0
* @category constructors
*/
var fromReadonlyRecord = (cookies) => {
	const self = Object.create(Proto$3);
	self.cookies = cookies;
	return self;
};
/**
* Create a Cookies object from an Iterable
*
* @since 4.0.0
* @category constructors
*/
var fromIterable = (cookies) => {
	const record = {};
	for (const cookie of cookies) record[cookie.name] = cookie;
	return fromReadonlyRecord(record);
};
/**
* An empty Cookies object
*
* @since 4.0.0
* @category constructors
*/
var empty$2 = /*#__PURE__*/ fromIterable([]);
({ ...BaseProto });
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpClientError.js
/**
* @since 4.0.0
*/
var TypeId$11 = "~effect/http/HttpClientError";
TaggedError("HttpClientError");
TaggedError("TransportError");
TaggedError("EncodeError");
TaggedError("InvalidUrlError");
TaggedError("StatusCodeError");
TaggedError("DecodeError");
TaggedError("EmptyBodyError");
/**
* @since 4.0.0
* @category Schema
*/
var HttpClientErrorSchema = class HttpClientErrorSchema extends ErrorClass(TypeId$11)({
	_tag: /*#__PURE__*/ tag("HttpError"),
	kind: /*#__PURE__*/ Literals([
		"EncodeError",
		"DecodeError",
		"TransportError",
		"InvalidUrlError",
		"StatusCodeError",
		"EmptyBodyError"
	]),
	cause: /*#__PURE__*/ optional(Defect)
}) {
	/**
	* @since 4.0.0
	*/
	static fromHttpClientError(error) {
		return new HttpClientErrorSchema({
			_tag: "HttpError",
			kind: error.reason._tag,
			cause: error.reason
		});
	}
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpClientRequest.js
var TypeId$10 = "~effect/http/HttpClientRequest";
var Proto$2 = {
	[TypeId$10]: TypeId$10,
	...BaseProto,
	toJSON() {
		return {
			_id: "HttpClientRequest",
			method: this.method,
			url: this.url,
			urlParams: this.urlParams,
			hash: this.hash,
			headers: redact$1(this.headers),
			body: this.body.toJSON()
		};
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
function makeProto(method, url, urlParams, hash, headers, body) {
	const self = Object.create(Proto$2);
	self.method = method;
	self.url = url;
	self.urlParams = urlParams;
	self.hash = hash;
	self.headers = headers;
	self.body = body;
	return self;
}
/**
* @since 4.0.0
* @category constructors
*/
var empty$1 = /*#__PURE__*/ makeProto("GET", "", empty$4, void 0, empty$5, empty$3);
/**
* @since 4.0.0
* @category constructors
*/
var make$6 = (method) => (url, options) => modify(empty$1, {
	method,
	url,
	...options ?? void 0
});
/**
* @since 4.0.0
* @category combinators
*/
var modify = /*#__PURE__*/ dual(2, (self, options) => {
	let result = self;
	if (options.method) result = setMethod(result, options.method);
	if (options.url) result = setUrl(result, options.url);
	if (options.headers) result = setHeaders(result, options.headers);
	if (options.urlParams) result = setUrlParams(result, options.urlParams);
	if (options.hash) result = setHash(result, options.hash);
	if (options.body) result = setBody(result, options.body);
	if (options.accept) result = accept(result, options.accept);
	if (options.acceptJson) result = acceptJson(result);
	return result;
});
/**
* @since 4.0.0
* @category combinators
*/
var setMethod = /*#__PURE__*/ dual(2, (self, method) => makeProto(method, self.url, self.urlParams, self.hash, self.headers, self.body));
/**
* @since 4.0.0
* @category combinators
*/
var setHeader = /*#__PURE__*/ dual(3, (self, key, value) => makeProto(self.method, self.url, self.urlParams, self.hash, set(self.headers, key, value), self.body));
/**
* @since 4.0.0
* @category combinators
*/
var setHeaders = /*#__PURE__*/ dual(2, (self, input) => makeProto(self.method, self.url, self.urlParams, self.hash, setAll$1(self.headers, input), self.body));
/**
* @since 4.0.0
* @category combinators
*/
var accept = /*#__PURE__*/ dual(2, (self, mediaType) => setHeader(self, "Accept", mediaType));
/**
* @since 4.0.0
* @category combinators
*/
var acceptJson = /*#__PURE__*/ accept("application/json");
/**
* @since 4.0.0
* @category combinators
*/
var setUrl = /*#__PURE__*/ dual(2, (self, url) => {
	if (typeof url === "string") return makeProto(self.method, url, self.urlParams, self.hash, self.headers, self.body);
	const clone = new URL(url.toString());
	const urlParams = fromInput(clone.searchParams);
	const hash = clone.hash ? clone.hash.slice(1) : void 0;
	clone.search = "";
	clone.hash = "";
	return makeProto(self.method, clone.toString(), urlParams, hash, self.headers, self.body);
});
/**
* @since 4.0.0
* @category combinators
*/
var prependUrl = /*#__PURE__*/ dual(2, (self, path) => {
	if (path === "") return self;
	return makeProto(self.method, joinSegments(path, self.url), self.urlParams, self.hash, self.headers, self.body);
});
var joinSegments = (first, second) => {
	const endsWithSlash = first.endsWith("/");
	const startsWithSlash = second.startsWith("/");
	return endsWithSlash && startsWithSlash ? first + second.slice(1) : !endsWithSlash && !startsWithSlash ? first + "/" + second : first + second;
};
/**
* @since 4.0.0
* @category combinators
*/
var setUrlParams = /*#__PURE__*/ dual(2, (self, input) => makeProto(self.method, self.url, setAll(self.urlParams, input), self.hash, self.headers, self.body));
/**
* @since 4.0.0
* @category combinators
*/
var setHash = /*#__PURE__*/ dual(2, (self, hash) => makeProto(self.method, self.url, self.urlParams, hash, self.headers, self.body));
/**
* @since 4.0.0
* @category combinators
*/
var setBody = /*#__PURE__*/ dual(2, (self, body) => {
	let headers = self.headers;
	if (body._tag === "Empty" || body._tag === "FormData") headers = remove(remove(headers, "Content-Type"), "Content-length");
	else {
		if (body.contentType) headers = set(headers, "content-type", body.contentType);
		if (body.contentLength !== void 0) headers = set(headers, "content-length", body.contentLength.toString());
	}
	return makeProto(self.method, self.url, self.urlParams, self.hash, headers, body);
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpMethod.js
/**
* @since 4.0.0
*/
var allShort = [
	["GET", "get"],
	["POST", "post"],
	["PUT", "put"],
	["DELETE", "del"],
	["PATCH", "patch"],
	["HEAD", "head"],
	["OPTIONS", "options"],
	["TRACE", "trace"]
];
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpClient.js
var TypeId$7 = "~effect/http/HttpClient";
/**
* @since 4.0.0
* @category tags
*/
var HttpClient = /*#__PURE__*/ Service$1("effect/HttpClient");
/**
* @since 4.0.0
* @category constructors
*/
var makeWith = (postprocess, preprocess) => {
	const self = Object.create(Proto$1);
	self.preprocess = preprocess;
	self.postprocess = postprocess;
	self.execute = function(request) {
		return postprocess(preprocess(request));
	};
	return self;
};
var Proto$1 = {
	[TypeId$7]: TypeId$7,
	pipe() {
		return pipeArguments(this, arguments);
	},
	...BaseProto,
	toJSON() {
		return { _id: "effect/HttpClient" };
	},
	.../*#__PURE__*/ Object.fromEntries(/*#__PURE__*/ allShort.map(([fullMethod, method]) => [method, function(url, options) {
		return this.execute(make$6(fullMethod)(url, options));
	}]))
};
/**
* Appends a transformation of the request object before sending it.
*
* @since 4.0.0
* @category mapping & sequencing
*/
var mapRequest = /*#__PURE__*/ dual(2, (self, f) => makeWith(self.postprocess, (request) => map$1(self.preprocess(request), f)));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/workers/Transferable.js
/**
* @since 1.0.0
*/
/**
* @since 1.0.0
* @category models
*/
var Collector = class extends Service$1()("effect/workers/Transferable/Collector") {};
/**
* @since 1.0.0
* @category constructors
*/
var makeCollectorUnsafe = () => {
	let tranferables = [];
	const unsafeAddAll = (transfers) => {
		tranferables.push(...transfers);
	};
	const unsafeRead = () => tranferables;
	const unsafeClear = () => {
		const prev = tranferables;
		tranferables = [];
		return prev;
	};
	return Collector.of({
		addAllUnsafe: unsafeAddAll,
		addAll: (transferables) => sync(() => unsafeAddAll(transferables)),
		readUnsafe: unsafeRead,
		read: sync(unsafeRead),
		clearUnsafe: unsafeClear,
		clear: sync(unsafeClear)
	});
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/workers/WorkerError.js
var TypeId$6 = "~effect/workers/WorkerError";
/**
* @since 4.0.0
* @category Models
*/
var WorkerSpawnError = class extends ErrorClass("effect/workers/WorkerError/WorkerSpawnError")({
	_tag: /*#__PURE__*/ tag("WorkerSpawnError"),
	message: String$1,
	cause: /*#__PURE__*/ optional(Defect)
}) {};
/**
* @since 4.0.0
* @category Models
*/
var WorkerSendError = class extends ErrorClass("effect/workers/WorkerError/WorkerSendError")({
	_tag: /*#__PURE__*/ tag("WorkerSendError"),
	message: String$1,
	cause: /*#__PURE__*/ optional(Defect)
}) {};
/**
* @since 4.0.0
* @category Models
*/
var WorkerReceiveError = class extends ErrorClass("effect/workers/WorkerError/WorkerReceiveError")({
	_tag: /*#__PURE__*/ tag("WorkerReceiveError"),
	message: String$1,
	cause: /*#__PURE__*/ optional(Defect)
}) {};
/**
* @since 4.0.0
* @category Models
*/
var WorkerUnknownError = class extends ErrorClass("effect/workers/WorkerError/WorkerUnknownError")({
	_tag: /*#__PURE__*/ tag("WorkerUnknownError"),
	message: String$1,
	cause: /*#__PURE__*/ optional(Defect)
}) {};
/**
* @since 4.0.0
* @category Models
*/
var WorkerErrorReason = /*#__PURE__*/ Union([
	WorkerSpawnError,
	WorkerSendError,
	WorkerReceiveError,
	WorkerUnknownError
]);
ErrorClass(TypeId$6)({
	_tag: /*#__PURE__*/ tag("WorkerError"),
	reason: WorkerErrorReason
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/workers/Worker.js
/**
* @since 4.0.0
* @category models
*/
var WorkerPlatform = class extends Service$1()("effect/workers/Worker/WorkerPlatform") {};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcClientError.js
/**
* @since 4.0.0
*/
var RpcClientError_exports = /* @__PURE__ */ __exportAll({
	RpcClientDefect: () => RpcClientDefect,
	RpcClientError: () => RpcClientError
});
var TypeId$5 = "~effect/rpc/RpcClientError";
/**
* @since 4.0.0
* @category Errors
*/
var RpcClientDefect = class extends ErrorClass("effect/rpc/RpcClientError/RpcClientDefect")({
	_tag: /*#__PURE__*/ tag("RpcClientDefect"),
	message: String$1,
	cause: Defect
}) {};
/**
* @since 4.0.0
* @category Errors
*/
var RpcClientError = class extends ErrorClass(TypeId$5)({
	_tag: /*#__PURE__*/ tag("RpcClientError"),
	reason: /*#__PURE__*/ Union([
		WorkerErrorReason,
		SocketErrorReason,
		HttpClientErrorSchema,
		RpcClientDefect
	])
}) {
	/**
	* @since 4.0.0
	*/
	[TypeId$5] = TypeId$5;
	get message() {
		return `${this.reason._tag}: ${this.reason.message}`;
	}
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcMessage.js
var RpcMessage_exports = /* @__PURE__ */ __exportAll({
	RequestId: () => RequestId,
	ResponseDefectEncoded: () => ResponseDefectEncoded,
	ResponseExitDieEncoded: () => ResponseExitDieEncoded,
	ResponseIdTypeId: () => ResponseIdTypeId,
	constEof: () => constEof,
	constPing: () => constPing,
	constPong: () => constPong
});
/**
* @since 4.0.0
* @category request
*/
var RequestId = (id) => typeof id === "bigint" ? id : BigInt(id);
/**
* @since 4.0.0
* @category request
*/
var constEof = { _tag: "Eof" };
/**
* @since 4.0.0
* @category request
*/
var constPing = { _tag: "Ping" };
/**
* @since 4.0.0
* @category response
*/
var ResponseIdTypeId = "~effect//rpc/RpcServer/ResponseId";
var encodeDefect = /*#__PURE__*/ encodeSync(Defect);
/**
* @since 4.0.0
* @category response
*/
var ResponseExitDieEncoded = (options) => ({
	_tag: "Exit",
	requestId: options.requestId.toString(),
	exit: {
		_tag: "Failure",
		cause: [{
			_tag: "Die",
			defect: encodeDefect(options.defect)
		}]
	}
});
/**
* @since 4.0.0
* @category response
*/
var ResponseDefectEncoded = (input) => ({
	_tag: "Defect",
	defect: encodeDefect(input)
});
/**
* @since 4.0.0
* @category response
*/
var constPong = { _tag: "Pong" };
//#endregion
//#region node_modules/.bun/msgpackr@1.11.9/node_modules/msgpackr/unpack.js
var decoder;
try {
	decoder = new TextDecoder();
} catch (error) {}
var src;
var srcEnd;
var position$1 = 0;
var EMPTY_ARRAY = [];
var strings = EMPTY_ARRAY;
var stringPosition = 0;
var currentUnpackr = {};
var currentStructures;
var srcString;
var srcStringStart = 0;
var srcStringEnd = 0;
var bundledStrings$1;
var referenceMap;
var currentExtensions = [];
var dataView;
var defaultOptions = {
	useRecords: false,
	mapsAsObjects: true
};
var C1Type = class {};
var C1 = new C1Type();
C1.name = "MessagePack 0xC1";
var sequentialMode = false;
var inlineObjectReadThreshold = 2;
var readStruct;
var onLoadedStructures;
var onSaveState;
try {
	new Function("");
} catch (error) {
	inlineObjectReadThreshold = Infinity;
}
var Unpackr = class Unpackr {
	constructor(options) {
		if (options) {
			if (options.useRecords === false && options.mapsAsObjects === void 0) options.mapsAsObjects = true;
			if (options.sequential && options.trusted !== false) {
				options.trusted = true;
				if (!options.structures && options.useRecords != false) {
					options.structures = [];
					if (!options.maxSharedStructures) options.maxSharedStructures = 0;
				}
			}
			if (options.structures) options.structures.sharedLength = options.structures.length;
			else if (options.getStructures) {
				(options.structures = []).uninitialized = true;
				options.structures.sharedLength = 0;
			}
			if (options.int64AsNumber) options.int64AsType = "number";
		}
		Object.assign(this, options);
	}
	unpack(source, options) {
		if (src) return saveState(() => {
			clearSource();
			return this ? this.unpack(source, options) : Unpackr.prototype.unpack.call(defaultOptions, source, options);
		});
		if (!source.buffer && source.constructor === ArrayBuffer) source = typeof Buffer !== "undefined" ? Buffer.from(source) : new Uint8Array(source);
		if (typeof options === "object") {
			srcEnd = options.end || source.length;
			position$1 = options.start || 0;
		} else {
			position$1 = 0;
			srcEnd = options > -1 ? options : source.length;
		}
		stringPosition = 0;
		srcStringEnd = 0;
		srcString = null;
		strings = EMPTY_ARRAY;
		bundledStrings$1 = null;
		src = source;
		try {
			dataView = source.dataView || (source.dataView = new DataView(source.buffer, source.byteOffset, source.byteLength));
		} catch (error) {
			src = null;
			if (source instanceof Uint8Array) throw error;
			throw new Error("Source must be a Uint8Array or Buffer but was a " + (source && typeof source == "object" ? source.constructor.name : typeof source));
		}
		if (this instanceof Unpackr) {
			currentUnpackr = this;
			if (this.structures) {
				currentStructures = this.structures;
				return checkedRead(options);
			} else if (!currentStructures || currentStructures.length > 0) currentStructures = [];
		} else {
			currentUnpackr = defaultOptions;
			if (!currentStructures || currentStructures.length > 0) currentStructures = [];
		}
		return checkedRead(options);
	}
	unpackMultiple(source, forEach) {
		let values, lastPosition = 0;
		try {
			sequentialMode = true;
			let size = source.length;
			let value = this ? this.unpack(source, size) : defaultUnpackr.unpack(source, size);
			if (forEach) {
				if (forEach(value, lastPosition, position$1) === false) return;
				while (position$1 < size) {
					lastPosition = position$1;
					if (forEach(checkedRead(), lastPosition, position$1) === false) return;
				}
			} else {
				values = [value];
				while (position$1 < size) {
					lastPosition = position$1;
					values.push(checkedRead());
				}
				return values;
			}
		} catch (error) {
			error.lastPosition = lastPosition;
			error.values = values;
			throw error;
		} finally {
			sequentialMode = false;
			clearSource();
		}
	}
	_mergeStructures(loadedStructures, existingStructures) {
		if (onLoadedStructures) loadedStructures = onLoadedStructures.call(this, loadedStructures);
		loadedStructures = loadedStructures || [];
		if (Object.isFrozen(loadedStructures)) loadedStructures = loadedStructures.map((structure) => structure.slice(0));
		for (let i = 0, l = loadedStructures.length; i < l; i++) {
			let structure = loadedStructures[i];
			if (structure) {
				structure.isShared = true;
				if (i >= 32) structure.highByte = i - 32 >> 5;
			}
		}
		loadedStructures.sharedLength = loadedStructures.length;
		for (let id in existingStructures || []) if (id >= 0) {
			let structure = loadedStructures[id];
			let existing = existingStructures[id];
			if (existing) {
				if (structure) (loadedStructures.restoreStructures || (loadedStructures.restoreStructures = []))[id] = structure;
				loadedStructures[id] = existing;
			}
		}
		return this.structures = loadedStructures;
	}
	decode(source, options) {
		return this.unpack(source, options);
	}
};
function checkedRead(options) {
	try {
		if (!currentUnpackr.trusted && !sequentialMode) {
			let sharedLength = currentStructures.sharedLength || 0;
			if (sharedLength < currentStructures.length) currentStructures.length = sharedLength;
		}
		let result;
		if (currentUnpackr.randomAccessStructure && src[position$1] < 64 && src[position$1] >= 32 && readStruct) {
			result = readStruct(src, position$1, srcEnd, currentUnpackr);
			src = null;
			if (!(options && options.lazy) && result) result = result.toJSON();
			position$1 = srcEnd;
		} else result = read();
		if (bundledStrings$1) {
			position$1 = bundledStrings$1.postBundlePosition;
			bundledStrings$1 = null;
		}
		if (sequentialMode) currentStructures.restoreStructures = null;
		if (position$1 == srcEnd) {
			if (currentStructures && currentStructures.restoreStructures) restoreStructures();
			currentStructures = null;
			src = null;
			if (referenceMap) referenceMap = null;
		} else if (position$1 > srcEnd) throw new Error("Unexpected end of MessagePack data");
		else if (!sequentialMode) {
			let jsonView;
			try {
				jsonView = JSON.stringify(result, (_, value) => typeof value === "bigint" ? `${value}n` : value).slice(0, 100);
			} catch (error) {
				jsonView = "(JSON view not available " + error + ")";
			}
			throw new Error("Data read, but end of buffer not reached " + jsonView);
		}
		return result;
	} catch (error) {
		if (currentStructures && currentStructures.restoreStructures) restoreStructures();
		clearSource();
		if (error instanceof RangeError || error.message.startsWith("Unexpected end of buffer") || position$1 > srcEnd) error.incomplete = true;
		throw error;
	}
}
function restoreStructures() {
	for (let id in currentStructures.restoreStructures) currentStructures[id] = currentStructures.restoreStructures[id];
	currentStructures.restoreStructures = null;
}
function read() {
	let token = src[position$1++];
	if (token < 160) if (token < 128) if (token < 64) return token;
	else {
		let structure = currentStructures[token & 63] || currentUnpackr.getStructures && loadStructures()[token & 63];
		if (structure) {
			if (!structure.read) structure.read = createStructureReader(structure, token & 63);
			return structure.read();
		} else return token;
	}
	else if (token < 144) {
		token -= 128;
		if (currentUnpackr.mapsAsObjects) {
			let object = {};
			for (let i = 0; i < token; i++) {
				let key = readKey();
				if (key === "__proto__") key = "__proto_";
				object[key] = read();
			}
			return object;
		} else {
			let map = /* @__PURE__ */ new Map();
			for (let i = 0; i < token; i++) map.set(read(), read());
			return map;
		}
	} else {
		token -= 144;
		let array = new Array(token);
		for (let i = 0; i < token; i++) array[i] = read();
		if (currentUnpackr.freezeData) return Object.freeze(array);
		return array;
	}
	else if (token < 192) {
		let length = token - 160;
		if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += length) - srcStringStart);
		if (srcStringEnd == 0 && srcEnd < 140) {
			let string = length < 16 ? shortStringInJS(length) : longStringInJS(length);
			if (string != null) return string;
		}
		return readFixedString(length);
	} else {
		let value;
		switch (token) {
			case 192: return null;
			case 193:
				if (bundledStrings$1) {
					value = read();
					if (value > 0) return bundledStrings$1[1].slice(bundledStrings$1.position1, bundledStrings$1.position1 += value);
					else return bundledStrings$1[0].slice(bundledStrings$1.position0, bundledStrings$1.position0 -= value);
				}
				return C1;
			case 194: return false;
			case 195: return true;
			case 196:
				value = src[position$1++];
				if (value === void 0) throw new Error("Unexpected end of buffer");
				return readBin(value);
			case 197:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readBin(value);
			case 198:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readBin(value);
			case 199: return readExt(src[position$1++]);
			case 200:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readExt(value);
			case 201:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readExt(value);
			case 202:
				value = dataView.getFloat32(position$1);
				if (currentUnpackr.useFloat32 > 2) {
					let multiplier = mult10[(src[position$1] & 127) << 1 | src[position$1 + 1] >> 7];
					position$1 += 4;
					return (multiplier * value + (value > 0 ? .5 : -.5) >> 0) / multiplier;
				}
				position$1 += 4;
				return value;
			case 203:
				value = dataView.getFloat64(position$1);
				position$1 += 8;
				return value;
			case 204: return src[position$1++];
			case 205:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return value;
			case 206:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return value;
			case 207:
				if (currentUnpackr.int64AsType === "number") {
					value = dataView.getUint32(position$1) * 4294967296;
					value += dataView.getUint32(position$1 + 4);
				} else if (currentUnpackr.int64AsType === "string") value = dataView.getBigUint64(position$1).toString();
				else if (currentUnpackr.int64AsType === "auto") {
					value = dataView.getBigUint64(position$1);
					if (value <= BigInt(2) << BigInt(52)) value = Number(value);
				} else value = dataView.getBigUint64(position$1);
				position$1 += 8;
				return value;
			case 208: return dataView.getInt8(position$1++);
			case 209:
				value = dataView.getInt16(position$1);
				position$1 += 2;
				return value;
			case 210:
				value = dataView.getInt32(position$1);
				position$1 += 4;
				return value;
			case 211:
				if (currentUnpackr.int64AsType === "number") {
					value = dataView.getInt32(position$1) * 4294967296;
					value += dataView.getUint32(position$1 + 4);
				} else if (currentUnpackr.int64AsType === "string") value = dataView.getBigInt64(position$1).toString();
				else if (currentUnpackr.int64AsType === "auto") {
					value = dataView.getBigInt64(position$1);
					if (value >= BigInt(-2) << BigInt(52) && value <= BigInt(2) << BigInt(52)) value = Number(value);
				} else value = dataView.getBigInt64(position$1);
				position$1 += 8;
				return value;
			case 212:
				value = src[position$1++];
				if (value == 114) return recordDefinition(src[position$1++] & 63);
				else {
					let extension = currentExtensions[value];
					if (extension) if (extension.read) {
						position$1++;
						return extension.read(read());
					} else if (extension.noBuffer) {
						position$1++;
						return extension();
					} else return extension(src.subarray(position$1, ++position$1));
					else throw new Error("Unknown extension " + value);
				}
			case 213:
				value = src[position$1];
				if (value == 114) {
					position$1++;
					return recordDefinition(src[position$1++] & 63, src[position$1++]);
				} else return readExt(2);
			case 214: return readExt(4);
			case 215: return readExt(8);
			case 216: return readExt(16);
			case 217:
				value = src[position$1++];
				if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += value) - srcStringStart);
				return readString8(value);
			case 218:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += value) - srcStringStart);
				return readString16(value);
			case 219:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += value) - srcStringStart);
				return readString32(value);
			case 220:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readArray(value);
			case 221:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readArray(value);
			case 222:
				value = dataView.getUint16(position$1);
				position$1 += 2;
				return readMap(value);
			case 223:
				value = dataView.getUint32(position$1);
				position$1 += 4;
				return readMap(value);
			default:
				if (token >= 224) return token - 256;
				if (token === void 0) {
					let error = /* @__PURE__ */ new Error("Unexpected end of MessagePack data");
					error.incomplete = true;
					throw error;
				}
				throw new Error("Unknown MessagePack token " + token);
		}
	}
}
var validName = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;
function createStructureReader(structure, firstId) {
	function readObject() {
		if (readObject.count++ > inlineObjectReadThreshold) {
			let readObject = structure.read = new Function("r", "return function(){return " + (currentUnpackr.freezeData ? "Object.freeze" : "") + "({" + structure.map((key) => key === "__proto__" ? "__proto_:r()" : validName.test(key) ? key + ":r()" : "[" + JSON.stringify(key) + "]:r()").join(",") + "})}")(read);
			if (structure.highByte === 0) structure.read = createSecondByteReader(firstId, structure.read);
			return readObject();
		}
		let object = {};
		for (let i = 0, l = structure.length; i < l; i++) {
			let key = structure[i];
			if (key === "__proto__") key = "__proto_";
			object[key] = read();
		}
		if (currentUnpackr.freezeData) return Object.freeze(object);
		return object;
	}
	readObject.count = 0;
	if (structure.highByte === 0) return createSecondByteReader(firstId, readObject);
	return readObject;
}
var createSecondByteReader = (firstId, read0) => {
	return function() {
		let highByte = src[position$1++];
		if (highByte === 0) return read0();
		let id = firstId < 32 ? -(firstId + (highByte << 5)) : firstId + (highByte << 5);
		let structure = currentStructures[id] || loadStructures()[id];
		if (!structure) throw new Error("Record id is not defined for " + id);
		if (!structure.read) structure.read = createStructureReader(structure, firstId);
		return structure.read();
	};
};
function loadStructures() {
	let loadedStructures = saveState(() => {
		src = null;
		return currentUnpackr.getStructures();
	});
	return currentStructures = currentUnpackr._mergeStructures(loadedStructures, currentStructures);
}
var readFixedString = readStringJS;
var readString8 = readStringJS;
var readString16 = readStringJS;
var readString32 = readStringJS;
function readStringJS(length) {
	let result;
	if (length < 16) {
		if (result = shortStringInJS(length)) return result;
	}
	if (length > 64 && decoder) return decoder.decode(src.subarray(position$1, position$1 += length));
	const end = position$1 + length;
	const units = [];
	result = "";
	while (position$1 < end) {
		const byte1 = src[position$1++];
		if ((byte1 & 128) === 0) units.push(byte1);
		else if ((byte1 & 224) === 192) {
			const byte2 = src[position$1++] & 63;
			const codePoint = (byte1 & 31) << 6 | byte2;
			if (codePoint < 128) units.push(65533);
			else units.push(codePoint);
		} else if ((byte1 & 240) === 224) {
			const byte2 = src[position$1++] & 63;
			const byte3 = src[position$1++] & 63;
			const codePoint = (byte1 & 31) << 12 | byte2 << 6 | byte3;
			if (codePoint < 2048 || codePoint >= 55296 && codePoint <= 57343) units.push(65533);
			else units.push(codePoint);
		} else if ((byte1 & 248) === 240) {
			const byte2 = src[position$1++] & 63;
			const byte3 = src[position$1++] & 63;
			const byte4 = src[position$1++] & 63;
			let unit = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
			if (unit < 65536 || unit > 1114111) units.push(65533);
			else if (unit > 65535) {
				unit -= 65536;
				units.push(unit >>> 10 & 1023 | 55296);
				unit = 56320 | unit & 1023;
				units.push(unit);
			} else units.push(unit);
		} else units.push(65533);
		if (units.length >= 4096) {
			result += fromCharCode.apply(String, units);
			units.length = 0;
		}
	}
	if (units.length > 0) result += fromCharCode.apply(String, units);
	return result;
}
function readArray(length) {
	let array = new Array(length);
	for (let i = 0; i < length; i++) array[i] = read();
	if (currentUnpackr.freezeData) return Object.freeze(array);
	return array;
}
function readMap(length) {
	if (currentUnpackr.mapsAsObjects) {
		let object = {};
		for (let i = 0; i < length; i++) {
			let key = readKey();
			if (key === "__proto__") key = "__proto_";
			object[key] = read();
		}
		return object;
	} else {
		let map = /* @__PURE__ */ new Map();
		for (let i = 0; i < length; i++) map.set(read(), read());
		return map;
	}
}
var fromCharCode = String.fromCharCode;
function longStringInJS(length) {
	let start = position$1;
	let bytes = new Array(length);
	for (let i = 0; i < length; i++) {
		const byte = src[position$1++];
		if ((byte & 128) > 0) {
			position$1 = start;
			return;
		}
		bytes[i] = byte;
	}
	return fromCharCode.apply(String, bytes);
}
function shortStringInJS(length) {
	if (length < 4) if (length < 2) if (length === 0) return "";
	else {
		let a = src[position$1++];
		if ((a & 128) > 1) {
			position$1 -= 1;
			return;
		}
		return fromCharCode(a);
	}
	else {
		let a = src[position$1++];
		let b = src[position$1++];
		if ((a & 128) > 0 || (b & 128) > 0) {
			position$1 -= 2;
			return;
		}
		if (length < 3) return fromCharCode(a, b);
		let c = src[position$1++];
		if ((c & 128) > 0) {
			position$1 -= 3;
			return;
		}
		return fromCharCode(a, b, c);
	}
	else {
		let a = src[position$1++];
		let b = src[position$1++];
		let c = src[position$1++];
		let d = src[position$1++];
		if ((a & 128) > 0 || (b & 128) > 0 || (c & 128) > 0 || (d & 128) > 0) {
			position$1 -= 4;
			return;
		}
		if (length < 6) if (length === 4) return fromCharCode(a, b, c, d);
		else {
			let e = src[position$1++];
			if ((e & 128) > 0) {
				position$1 -= 5;
				return;
			}
			return fromCharCode(a, b, c, d, e);
		}
		else if (length < 8) {
			let e = src[position$1++];
			let f = src[position$1++];
			if ((e & 128) > 0 || (f & 128) > 0) {
				position$1 -= 6;
				return;
			}
			if (length < 7) return fromCharCode(a, b, c, d, e, f);
			let g = src[position$1++];
			if ((g & 128) > 0) {
				position$1 -= 7;
				return;
			}
			return fromCharCode(a, b, c, d, e, f, g);
		} else {
			let e = src[position$1++];
			let f = src[position$1++];
			let g = src[position$1++];
			let h = src[position$1++];
			if ((e & 128) > 0 || (f & 128) > 0 || (g & 128) > 0 || (h & 128) > 0) {
				position$1 -= 8;
				return;
			}
			if (length < 10) if (length === 8) return fromCharCode(a, b, c, d, e, f, g, h);
			else {
				let i = src[position$1++];
				if ((i & 128) > 0) {
					position$1 -= 9;
					return;
				}
				return fromCharCode(a, b, c, d, e, f, g, h, i);
			}
			else if (length < 12) {
				let i = src[position$1++];
				let j = src[position$1++];
				if ((i & 128) > 0 || (j & 128) > 0) {
					position$1 -= 10;
					return;
				}
				if (length < 11) return fromCharCode(a, b, c, d, e, f, g, h, i, j);
				let k = src[position$1++];
				if ((k & 128) > 0) {
					position$1 -= 11;
					return;
				}
				return fromCharCode(a, b, c, d, e, f, g, h, i, j, k);
			} else {
				let i = src[position$1++];
				let j = src[position$1++];
				let k = src[position$1++];
				let l = src[position$1++];
				if ((i & 128) > 0 || (j & 128) > 0 || (k & 128) > 0 || (l & 128) > 0) {
					position$1 -= 12;
					return;
				}
				if (length < 14) if (length === 12) return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l);
				else {
					let m = src[position$1++];
					if ((m & 128) > 0) {
						position$1 -= 13;
						return;
					}
					return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m);
				}
				else {
					let m = src[position$1++];
					let n = src[position$1++];
					if ((m & 128) > 0 || (n & 128) > 0) {
						position$1 -= 14;
						return;
					}
					if (length < 15) return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n);
					let o = src[position$1++];
					if ((o & 128) > 0) {
						position$1 -= 15;
						return;
					}
					return fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o);
				}
			}
		}
	}
}
function readOnlyJSString() {
	let token = src[position$1++];
	let length;
	if (token < 192) length = token - 160;
	else switch (token) {
		case 217:
			length = src[position$1++];
			break;
		case 218:
			length = dataView.getUint16(position$1);
			position$1 += 2;
			break;
		case 219:
			length = dataView.getUint32(position$1);
			position$1 += 4;
			break;
		default: throw new Error("Expected string");
	}
	return readStringJS(length);
}
function readBin(length) {
	return currentUnpackr.copyBuffers ? Uint8Array.prototype.slice.call(src, position$1, position$1 += length) : src.subarray(position$1, position$1 += length);
}
function readExt(length) {
	let type = src[position$1++];
	if (currentExtensions[type]) {
		let end;
		return currentExtensions[type](src.subarray(position$1, end = position$1 += length), (readPosition) => {
			position$1 = readPosition;
			try {
				return read();
			} finally {
				position$1 = end;
			}
		});
	} else throw new Error("Unknown extension type " + type);
}
var keyCache = new Array(4096);
function readKey() {
	let length = src[position$1++];
	if (length >= 160 && length < 192) {
		length = length - 160;
		if (srcStringEnd >= position$1) return srcString.slice(position$1 - srcStringStart, (position$1 += length) - srcStringStart);
		else if (!(srcStringEnd == 0 && srcEnd < 180)) return readFixedString(length);
	} else {
		position$1--;
		return asSafeString(read());
	}
	let key = (length << 5 ^ (length > 1 ? dataView.getUint16(position$1) : length > 0 ? src[position$1] : 0)) & 4095;
	let entry = keyCache[key];
	let checkPosition = position$1;
	let end = position$1 + length - 3;
	let chunk;
	let i = 0;
	if (entry && entry.bytes == length) {
		while (checkPosition < end) {
			chunk = dataView.getUint32(checkPosition);
			if (chunk != entry[i++]) {
				checkPosition = 1879048192;
				break;
			}
			checkPosition += 4;
		}
		end += 3;
		while (checkPosition < end) {
			chunk = src[checkPosition++];
			if (chunk != entry[i++]) {
				checkPosition = 1879048192;
				break;
			}
		}
		if (checkPosition === end) {
			position$1 = checkPosition;
			return entry.string;
		}
		end -= 3;
		checkPosition = position$1;
	}
	entry = [];
	keyCache[key] = entry;
	entry.bytes = length;
	while (checkPosition < end) {
		chunk = dataView.getUint32(checkPosition);
		entry.push(chunk);
		checkPosition += 4;
	}
	end += 3;
	while (checkPosition < end) {
		chunk = src[checkPosition++];
		entry.push(chunk);
	}
	let string = length < 16 ? shortStringInJS(length) : longStringInJS(length);
	if (string != null) return entry.string = string;
	return entry.string = readFixedString(length);
}
function asSafeString(property) {
	if (typeof property === "string") return property;
	if (typeof property === "number" || typeof property === "boolean" || typeof property === "bigint") return property.toString();
	if (property == null) return property + "";
	if (currentUnpackr.allowArraysInMapKeys && Array.isArray(property) && property.flat().every((item) => [
		"string",
		"number",
		"boolean",
		"bigint"
	].includes(typeof item))) return property.flat().toString();
	throw new Error(`Invalid property type for record: ${typeof property}`);
}
var recordDefinition = (id, highByte) => {
	let structure = read().map(asSafeString);
	let firstByte = id;
	if (highByte !== void 0) {
		id = id < 32 ? -((highByte << 5) + id) : (highByte << 5) + id;
		structure.highByte = highByte;
	}
	let existingStructure = currentStructures[id];
	if (existingStructure && (existingStructure.isShared || sequentialMode)) (currentStructures.restoreStructures || (currentStructures.restoreStructures = []))[id] = existingStructure;
	currentStructures[id] = structure;
	structure.read = createStructureReader(structure, firstByte);
	return structure.read();
};
currentExtensions[0] = () => {};
currentExtensions[0].noBuffer = true;
currentExtensions[66] = (data) => {
	let headLength = data.byteLength % 8 || 8;
	let head = BigInt(data[0] & 128 ? data[0] - 256 : data[0]);
	for (let i = 1; i < headLength; i++) {
		head <<= BigInt(8);
		head += BigInt(data[i]);
	}
	if (data.byteLength !== headLength) {
		let view = new DataView(data.buffer, data.byteOffset, data.byteLength);
		let decode = (start, end) => {
			let length = end - start;
			if (length <= 40) {
				let out = view.getBigUint64(start);
				for (let i = start + 8; i < end; i += 8) {
					out <<= BigInt(64n);
					out |= view.getBigUint64(i);
				}
				return out;
			}
			let middle = start + (length >> 4 << 3);
			let left = decode(start, middle);
			let right = decode(middle, end);
			return left << BigInt((end - middle) * 8) | right;
		};
		head = head << BigInt((view.byteLength - headLength) * 8) | decode(headLength, view.byteLength);
	}
	return head;
};
var errors = {
	Error,
	EvalError,
	RangeError,
	ReferenceError,
	SyntaxError,
	TypeError,
	URIError,
	AggregateError: typeof AggregateError === "function" ? AggregateError : null
};
currentExtensions[101] = () => {
	let data = read();
	if (!errors[data[0]]) {
		let error = Error(data[1], { cause: data[2] });
		error.name = data[0];
		return error;
	}
	return errors[data[0]](data[1], { cause: data[2] });
};
currentExtensions[105] = (data) => {
	if (currentUnpackr.structuredClone === false) throw new Error("Structured clone extension is disabled");
	let id = dataView.getUint32(position$1 - 4);
	if (!referenceMap) referenceMap = /* @__PURE__ */ new Map();
	let token = src[position$1];
	let target;
	if (token >= 144 && token < 160 || token == 220 || token == 221) target = [];
	else if (token >= 128 && token < 144 || token == 222 || token == 223) target = /* @__PURE__ */ new Map();
	else if ((token >= 199 && token <= 201 || token >= 212 && token <= 216) && src[position$1 + 1] === 115) target = /* @__PURE__ */ new Set();
	else target = {};
	let refEntry = { target };
	referenceMap.set(id, refEntry);
	let targetProperties = read();
	if (!refEntry.used) return refEntry.target = targetProperties;
	else Object.assign(target, targetProperties);
	if (target instanceof Map) for (let [k, v] of targetProperties.entries()) target.set(k, v);
	if (target instanceof Set) for (let i of Array.from(targetProperties)) target.add(i);
	return target;
};
currentExtensions[112] = (data) => {
	if (currentUnpackr.structuredClone === false) throw new Error("Structured clone extension is disabled");
	let id = dataView.getUint32(position$1 - 4);
	let refEntry = referenceMap.get(id);
	refEntry.used = true;
	return refEntry.target;
};
currentExtensions[115] = () => new Set(read());
var typedArrays = [
	"Int8",
	"Uint8",
	"Uint8Clamped",
	"Int16",
	"Uint16",
	"Int32",
	"Uint32",
	"Float32",
	"Float64",
	"BigInt64",
	"BigUint64"
].map((type) => type + "Array");
var glbl = typeof globalThis === "object" ? globalThis : window;
currentExtensions[116] = (data) => {
	let typeCode = data[0];
	let buffer = Uint8Array.prototype.slice.call(data, 1).buffer;
	let typedArrayName = typedArrays[typeCode];
	if (!typedArrayName) {
		if (typeCode === 16) return buffer;
		if (typeCode === 17) return new DataView(buffer);
		throw new Error("Could not find typed array for code " + typeCode);
	}
	return new glbl[typedArrayName](buffer);
};
currentExtensions[120] = () => {
	let data = read();
	return new RegExp(data[0], data[1]);
};
var TEMP_BUNDLE = [];
currentExtensions[98] = (data) => {
	let dataSize = (data[0] << 24) + (data[1] << 16) + (data[2] << 8) + data[3];
	let dataPosition = position$1;
	position$1 += dataSize - data.length;
	bundledStrings$1 = TEMP_BUNDLE;
	bundledStrings$1 = [readOnlyJSString(), readOnlyJSString()];
	bundledStrings$1.position0 = 0;
	bundledStrings$1.position1 = 0;
	bundledStrings$1.postBundlePosition = position$1;
	position$1 = dataPosition;
	return read();
};
currentExtensions[255] = (data) => {
	if (data.length == 4) return /* @__PURE__ */ new Date((data[0] * 16777216 + (data[1] << 16) + (data[2] << 8) + data[3]) * 1e3);
	else if (data.length == 8) return /* @__PURE__ */ new Date(((data[0] << 22) + (data[1] << 14) + (data[2] << 6) + (data[3] >> 2)) / 1e6 + ((data[3] & 3) * 4294967296 + data[4] * 16777216 + (data[5] << 16) + (data[6] << 8) + data[7]) * 1e3);
	else if (data.length == 12) return /* @__PURE__ */ new Date(((data[0] << 24) + (data[1] << 16) + (data[2] << 8) + data[3]) / 1e6 + ((data[4] & 128 ? -281474976710656 : 0) + data[6] * 1099511627776 + data[7] * 4294967296 + data[8] * 16777216 + (data[9] << 16) + (data[10] << 8) + data[11]) * 1e3);
	else return /* @__PURE__ */ new Date("invalid");
};
function saveState(callback) {
	if (onSaveState) onSaveState();
	let savedSrcEnd = srcEnd;
	let savedPosition = position$1;
	let savedStringPosition = stringPosition;
	let savedSrcStringStart = srcStringStart;
	let savedSrcStringEnd = srcStringEnd;
	let savedSrcString = srcString;
	let savedStrings = strings;
	let savedReferenceMap = referenceMap;
	let savedBundledStrings = bundledStrings$1;
	let savedSrc = new Uint8Array(src.slice(0, srcEnd));
	let savedStructures = currentStructures;
	let savedStructuresContents = currentStructures.slice(0, currentStructures.length);
	let savedPackr = currentUnpackr;
	let savedSequentialMode = sequentialMode;
	let value = callback();
	srcEnd = savedSrcEnd;
	position$1 = savedPosition;
	stringPosition = savedStringPosition;
	srcStringStart = savedSrcStringStart;
	srcStringEnd = savedSrcStringEnd;
	srcString = savedSrcString;
	strings = savedStrings;
	referenceMap = savedReferenceMap;
	bundledStrings$1 = savedBundledStrings;
	src = savedSrc;
	sequentialMode = savedSequentialMode;
	currentStructures = savedStructures;
	currentStructures.splice(0, currentStructures.length, ...savedStructuresContents);
	currentUnpackr = savedPackr;
	dataView = new DataView(src.buffer, src.byteOffset, src.byteLength);
	return value;
}
function clearSource() {
	src = null;
	referenceMap = null;
	currentStructures = null;
}
var mult10 = new Array(147);
for (let i = 0; i < 256; i++) mult10[i] = +("1e" + Math.floor(45.15 - i * .30103));
var defaultUnpackr = new Unpackr({ useRecords: false });
defaultUnpackr.unpack;
defaultUnpackr.unpackMultiple;
defaultUnpackr.unpack;
var FLOAT32_OPTIONS = {
	NEVER: 0,
	ALWAYS: 1,
	DECIMAL_ROUND: 3,
	DECIMAL_FIT: 4
};
new Uint8Array((/* @__PURE__ */ new Float32Array(1)).buffer, 0, 4);
//#endregion
//#region node_modules/.bun/msgpackr@1.11.9/node_modules/msgpackr/pack.js
var textEncoder;
try {
	textEncoder = new TextEncoder();
} catch (error) {}
var extensions;
var extensionClasses;
var hasNodeBuffer = typeof Buffer !== "undefined";
var ByteArrayAllocate = hasNodeBuffer ? function(length) {
	return Buffer.allocUnsafeSlow(length);
} : Uint8Array;
var ByteArray = hasNodeBuffer ? Buffer : Uint8Array;
var MAX_BUFFER_SIZE = hasNodeBuffer ? 4294967296 : 2144337920;
var target;
var keysTarget;
var targetView;
var position = 0;
var safeEnd;
var bundledStrings = null;
var writeStructSlots;
var MAX_BUNDLE_SIZE = 21760;
var hasNonLatin = /[\u0080-\uFFFF]/;
var RECORD_SYMBOL = Symbol("record-id");
var Packr = class extends Unpackr {
	constructor(options) {
		super(options);
		this.offset = 0;
		let start;
		let hasSharedUpdate;
		let structures;
		let referenceMap;
		let encodeUtf8 = ByteArray.prototype.utf8Write ? function(string, position) {
			return target.utf8Write(string, position, target.byteLength - position);
		} : textEncoder && textEncoder.encodeInto ? function(string, position) {
			return textEncoder.encodeInto(string, target.subarray(position)).written;
		} : false;
		let packr = this;
		if (!options) options = {};
		let isSequential = options && options.sequential;
		let hasSharedStructures = options.structures || options.saveStructures;
		let maxSharedStructures = options.maxSharedStructures;
		if (maxSharedStructures == null) maxSharedStructures = hasSharedStructures ? 32 : 0;
		if (maxSharedStructures > 8160) throw new Error("Maximum maxSharedStructure is 8160");
		if (options.structuredClone && options.moreTypes == void 0) this.moreTypes = true;
		let maxOwnStructures = options.maxOwnStructures;
		if (maxOwnStructures == null) maxOwnStructures = hasSharedStructures ? 32 : 64;
		if (!this.structures && options.useRecords != false) this.structures = [];
		let useTwoByteRecords = maxSharedStructures > 32 || maxOwnStructures + maxSharedStructures > 64;
		let sharedLimitId = maxSharedStructures + 64;
		let maxStructureId = maxSharedStructures + maxOwnStructures + 64;
		if (maxStructureId > 8256) throw new Error("Maximum maxSharedStructure + maxOwnStructure is 8192");
		let recordIdsToRemove = [];
		let transitionsCount = 0;
		let serializationsSinceTransitionRebuild = 0;
		this.pack = this.encode = function(value, encodeOptions) {
			if (!target) {
				target = new ByteArrayAllocate(8192);
				targetView = target.dataView || (target.dataView = new DataView(target.buffer, 0, 8192));
				position = 0;
			}
			safeEnd = target.length - 10;
			if (safeEnd - position < 2048) {
				target = new ByteArrayAllocate(target.length);
				targetView = target.dataView || (target.dataView = new DataView(target.buffer, 0, target.length));
				safeEnd = target.length - 10;
				position = 0;
			} else position = position + 7 & 2147483640;
			start = position;
			if (encodeOptions & 2048) position += encodeOptions & 255;
			referenceMap = packr.structuredClone ? /* @__PURE__ */ new Map() : null;
			if (packr.bundleStrings && typeof value !== "string") {
				bundledStrings = [];
				bundledStrings.size = Infinity;
			} else bundledStrings = null;
			structures = packr.structures;
			if (structures) {
				if (structures.uninitialized) structures = packr._mergeStructures(packr.getStructures());
				let sharedLength = structures.sharedLength || 0;
				if (sharedLength > maxSharedStructures) throw new Error("Shared structures is larger than maximum shared structures, try increasing maxSharedStructures to " + structures.sharedLength);
				if (!structures.transitions) {
					structures.transitions = Object.create(null);
					for (let i = 0; i < sharedLength; i++) {
						let keys = structures[i];
						if (!keys) continue;
						let nextTransition, transition = structures.transitions;
						for (let j = 0, l = keys.length; j < l; j++) {
							let key = keys[j];
							nextTransition = transition[key];
							if (!nextTransition) nextTransition = transition[key] = Object.create(null);
							transition = nextTransition;
						}
						transition[RECORD_SYMBOL] = i + 64;
					}
					this.lastNamedStructuresLength = sharedLength;
				}
				if (!isSequential) structures.nextId = sharedLength + 64;
			}
			if (hasSharedUpdate) hasSharedUpdate = false;
			let encodingError;
			try {
				if (packr.randomAccessStructure && value && typeof value === "object") if (value.constructor === Object) writeStruct(value);
				else if (value.constructor !== Map && !Array.isArray(value) && !extensionClasses.some((extClass) => value instanceof extClass)) writeStruct(value.toJSON ? value.toJSON() : value);
				else pack(value);
				else pack(value);
				let lastBundle = bundledStrings;
				if (bundledStrings) writeBundles(start, pack, 0);
				if (referenceMap && referenceMap.idsToInsert) {
					let idsToInsert = referenceMap.idsToInsert.sort((a, b) => a.offset > b.offset ? 1 : -1);
					let i = idsToInsert.length;
					let incrementPosition = -1;
					while (lastBundle && i > 0) {
						let insertionPoint = idsToInsert[--i].offset + start;
						if (insertionPoint < lastBundle.stringsPosition + start && incrementPosition === -1) incrementPosition = 0;
						if (insertionPoint > lastBundle.position + start) {
							if (incrementPosition >= 0) incrementPosition += 6;
						} else {
							if (incrementPosition >= 0) {
								targetView.setUint32(lastBundle.position + start, targetView.getUint32(lastBundle.position + start) + incrementPosition);
								incrementPosition = -1;
							}
							lastBundle = lastBundle.previous;
							i++;
						}
					}
					if (incrementPosition >= 0 && lastBundle) targetView.setUint32(lastBundle.position + start, targetView.getUint32(lastBundle.position + start) + incrementPosition);
					position += idsToInsert.length * 6;
					if (position > safeEnd) makeRoom(position);
					packr.offset = position;
					let serialized = insertIds(target.subarray(start, position), idsToInsert);
					referenceMap = null;
					return serialized;
				}
				packr.offset = position;
				if (encodeOptions & 512) {
					target.start = start;
					target.end = position;
					return target;
				}
				return target.subarray(start, position);
			} catch (error) {
				encodingError = error;
				throw error;
			} finally {
				if (structures) {
					resetStructures();
					if (hasSharedUpdate && packr.saveStructures) {
						let sharedLength = structures.sharedLength || 0;
						let returnBuffer = target.subarray(start, position);
						let newSharedData = prepareStructures(structures, packr);
						if (!encodingError) {
							if (packr.saveStructures(newSharedData, newSharedData.isCompatible) === false) return packr.pack(value, encodeOptions);
							packr.lastNamedStructuresLength = sharedLength;
							if (target.length > 1073741824) target = null;
							return returnBuffer;
						}
					}
				}
				if (target.length > 1073741824) target = null;
				if (encodeOptions & 1024) position = start;
			}
		};
		const resetStructures = () => {
			if (serializationsSinceTransitionRebuild < 10) serializationsSinceTransitionRebuild++;
			let sharedLength = structures.sharedLength || 0;
			if (structures.length > sharedLength && !isSequential) structures.length = sharedLength;
			if (transitionsCount > 1e4) {
				structures.transitions = null;
				serializationsSinceTransitionRebuild = 0;
				transitionsCount = 0;
				if (recordIdsToRemove.length > 0) recordIdsToRemove = [];
			} else if (recordIdsToRemove.length > 0 && !isSequential) {
				for (let i = 0, l = recordIdsToRemove.length; i < l; i++) recordIdsToRemove[i][RECORD_SYMBOL] = 0;
				recordIdsToRemove = [];
			}
		};
		const packArray = (value) => {
			var length = value.length;
			if (length < 16) target[position++] = 144 | length;
			else if (length < 65536) {
				target[position++] = 220;
				target[position++] = length >> 8;
				target[position++] = length & 255;
			} else {
				target[position++] = 221;
				targetView.setUint32(position, length);
				position += 4;
			}
			for (let i = 0; i < length; i++) pack(value[i]);
		};
		const pack = (value) => {
			if (position > safeEnd) target = makeRoom(position);
			var type = typeof value;
			var length;
			if (type === "string") {
				let strLength = value.length;
				if (bundledStrings && strLength >= 4 && strLength < 4096) {
					if ((bundledStrings.size += strLength) > MAX_BUNDLE_SIZE) {
						let extStart;
						let maxBytes = (bundledStrings[0] ? bundledStrings[0].length * 3 + bundledStrings[1].length : 0) + 10;
						if (position + maxBytes > safeEnd) target = makeRoom(position + maxBytes);
						let lastBundle;
						if (bundledStrings.position) {
							lastBundle = bundledStrings;
							target[position] = 200;
							position += 3;
							target[position++] = 98;
							extStart = position - start;
							position += 4;
							writeBundles(start, pack, 0);
							targetView.setUint16(extStart + start - 3, position - start - extStart);
						} else {
							target[position++] = 214;
							target[position++] = 98;
							extStart = position - start;
							position += 4;
						}
						bundledStrings = ["", ""];
						bundledStrings.previous = lastBundle;
						bundledStrings.size = 0;
						bundledStrings.position = extStart;
					}
					let twoByte = hasNonLatin.test(value);
					bundledStrings[twoByte ? 0 : 1] += value;
					target[position++] = 193;
					pack(twoByte ? -strLength : strLength);
					return;
				}
				let headerSize;
				if (strLength < 32) headerSize = 1;
				else if (strLength < 256) headerSize = 2;
				else if (strLength < 65536) headerSize = 3;
				else headerSize = 5;
				let maxBytes = strLength * 3;
				if (position + maxBytes > safeEnd) target = makeRoom(position + maxBytes);
				if (strLength < 64 || !encodeUtf8) {
					let i, c1, c2, strPosition = position + headerSize;
					for (i = 0; i < strLength; i++) {
						c1 = value.charCodeAt(i);
						if (c1 < 128) target[strPosition++] = c1;
						else if (c1 < 2048) {
							target[strPosition++] = c1 >> 6 | 192;
							target[strPosition++] = c1 & 63 | 128;
						} else if ((c1 & 64512) === 55296 && ((c2 = value.charCodeAt(i + 1)) & 64512) === 56320) {
							c1 = 65536 + ((c1 & 1023) << 10) + (c2 & 1023);
							i++;
							target[strPosition++] = c1 >> 18 | 240;
							target[strPosition++] = c1 >> 12 & 63 | 128;
							target[strPosition++] = c1 >> 6 & 63 | 128;
							target[strPosition++] = c1 & 63 | 128;
						} else {
							target[strPosition++] = c1 >> 12 | 224;
							target[strPosition++] = c1 >> 6 & 63 | 128;
							target[strPosition++] = c1 & 63 | 128;
						}
					}
					length = strPosition - position - headerSize;
				} else length = encodeUtf8(value, position + headerSize);
				if (length < 32) target[position++] = 160 | length;
				else if (length < 256) {
					if (headerSize < 2) target.copyWithin(position + 2, position + 1, position + 1 + length);
					target[position++] = 217;
					target[position++] = length;
				} else if (length < 65536) {
					if (headerSize < 3) target.copyWithin(position + 3, position + 2, position + 2 + length);
					target[position++] = 218;
					target[position++] = length >> 8;
					target[position++] = length & 255;
				} else {
					if (headerSize < 5) target.copyWithin(position + 5, position + 3, position + 3 + length);
					target[position++] = 219;
					targetView.setUint32(position, length);
					position += 4;
				}
				position += length;
			} else if (type === "number") if (value >>> 0 === value) if (value < 32 || value < 128 && this.useRecords === false || value < 64 && !this.randomAccessStructure) target[position++] = value;
			else if (value < 256) {
				target[position++] = 204;
				target[position++] = value;
			} else if (value < 65536) {
				target[position++] = 205;
				target[position++] = value >> 8;
				target[position++] = value & 255;
			} else {
				target[position++] = 206;
				targetView.setUint32(position, value);
				position += 4;
			}
			else if (value >> 0 === value) if (value >= -32) target[position++] = 256 + value;
			else if (value >= -128) {
				target[position++] = 208;
				target[position++] = value + 256;
			} else if (value >= -32768) {
				target[position++] = 209;
				targetView.setInt16(position, value);
				position += 2;
			} else {
				target[position++] = 210;
				targetView.setInt32(position, value);
				position += 4;
			}
			else {
				let useFloat32;
				if ((useFloat32 = this.useFloat32) > 0 && value < 4294967296 && value >= -2147483648) {
					target[position++] = 202;
					targetView.setFloat32(position, value);
					let xShifted;
					if (useFloat32 < 4 || (xShifted = value * mult10[(target[position] & 127) << 1 | target[position + 1] >> 7]) >> 0 === xShifted) {
						position += 4;
						return;
					} else position--;
				}
				target[position++] = 203;
				targetView.setFloat64(position, value);
				position += 8;
			}
			else if (type === "object" || type === "function") if (!value) target[position++] = 192;
			else {
				if (referenceMap) {
					let referee = referenceMap.get(value);
					if (referee) {
						if (!referee.id) referee.id = (referenceMap.idsToInsert || (referenceMap.idsToInsert = [])).push(referee);
						target[position++] = 214;
						target[position++] = 112;
						targetView.setUint32(position, referee.id);
						position += 4;
						return;
					} else referenceMap.set(value, { offset: position - start });
				}
				let constructor = value.constructor;
				if (constructor === Object) writeObject(value);
				else if (constructor === Array) packArray(value);
				else if (constructor === Map) if (this.mapAsEmptyObject) target[position++] = 128;
				else {
					length = value.size;
					if (length < 16) target[position++] = 128 | length;
					else if (length < 65536) {
						target[position++] = 222;
						target[position++] = length >> 8;
						target[position++] = length & 255;
					} else {
						target[position++] = 223;
						targetView.setUint32(position, length);
						position += 4;
					}
					for (let [key, entryValue] of value) {
						pack(key);
						pack(entryValue);
					}
				}
				else {
					for (let i = 0, l = extensions.length; i < l; i++) {
						let extensionClass = extensionClasses[i];
						if (value instanceof extensionClass) {
							let extension = extensions[i];
							if (extension.write) {
								if (extension.type) {
									target[position++] = 212;
									target[position++] = extension.type;
									target[position++] = 0;
								}
								let writeResult = extension.write.call(this, value);
								if (writeResult === value) if (Array.isArray(value)) packArray(value);
								else writeObject(value);
								else pack(writeResult);
								return;
							}
							let currentTarget = target;
							let currentTargetView = targetView;
							let currentPosition = position;
							target = null;
							let result;
							try {
								result = extension.pack.call(this, value, (size) => {
									target = currentTarget;
									currentTarget = null;
									position += size;
									if (position > safeEnd) makeRoom(position);
									return {
										target,
										targetView,
										position: position - size
									};
								}, pack);
							} finally {
								if (currentTarget) {
									target = currentTarget;
									targetView = currentTargetView;
									position = currentPosition;
									safeEnd = target.length - 10;
								}
							}
							if (result) {
								if (result.length + position > safeEnd) makeRoom(result.length + position);
								position = writeExtensionData(result, target, position, extension.type);
							}
							return;
						}
					}
					if (Array.isArray(value)) packArray(value);
					else {
						if (value.toJSON) {
							const json = value.toJSON();
							if (json !== value) return pack(json);
						}
						if (type === "function") return pack(this.writeFunction && this.writeFunction(value));
						writeObject(value);
					}
				}
			}
			else if (type === "boolean") target[position++] = value ? 195 : 194;
			else if (type === "bigint") {
				if (value < 0x8000000000000000 && value >= -0x8000000000000000) {
					target[position++] = 211;
					targetView.setBigInt64(position, value);
				} else if (value < 0x10000000000000000 && value > 0) {
					target[position++] = 207;
					targetView.setBigUint64(position, value);
				} else if (this.largeBigIntToFloat) {
					target[position++] = 203;
					targetView.setFloat64(position, Number(value));
				} else if (this.largeBigIntToString) return pack(value.toString());
				else if (this.useBigIntExtension || this.moreTypes) {
					let empty = value < 0 ? BigInt(-1) : BigInt(0);
					let array;
					if (value >> BigInt(65536) === empty) {
						let mask = BigInt(0x10000000000000000) - BigInt(1);
						let chunks = [];
						while (true) {
							chunks.push(value & mask);
							if (value >> BigInt(63) === empty) break;
							value >>= BigInt(64);
						}
						array = new Uint8Array(new BigUint64Array(chunks).buffer);
						array.reverse();
					} else {
						let invert = value < 0;
						let string = (invert ? ~value : value).toString(16);
						if (string.length % 2) string = "0" + string;
						else if (parseInt(string.charAt(0), 16) >= 8) string = "00" + string;
						if (hasNodeBuffer) array = Buffer.from(string, "hex");
						else {
							array = new Uint8Array(string.length / 2);
							for (let i = 0; i < array.length; i++) array[i] = parseInt(string.slice(i * 2, i * 2 + 2), 16);
						}
						if (invert) for (let i = 0; i < array.length; i++) array[i] = ~array[i];
					}
					if (array.length + position > safeEnd) makeRoom(array.length + position);
					position = writeExtensionData(array, target, position, 66);
					return;
				} else throw new RangeError(value + " was too large to fit in MessagePack 64-bit integer format, use useBigIntExtension, or set largeBigIntToFloat to convert to float-64, or set largeBigIntToString to convert to string");
				position += 8;
			} else if (type === "undefined") if (this.encodeUndefinedAsNil) target[position++] = 192;
			else {
				target[position++] = 212;
				target[position++] = 0;
				target[position++] = 0;
			}
			else throw new Error("Unknown type: " + type);
		};
		const writePlainObject = this.variableMapSize || this.coercibleKeyAsNumber || this.skipValues ? (object) => {
			let keys;
			if (this.skipValues) {
				keys = [];
				for (let key in object) if ((typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) && !this.skipValues.includes(object[key])) keys.push(key);
			} else keys = Object.keys(object);
			let length = keys.length;
			if (length < 16) target[position++] = 128 | length;
			else if (length < 65536) {
				target[position++] = 222;
				target[position++] = length >> 8;
				target[position++] = length & 255;
			} else {
				target[position++] = 223;
				targetView.setUint32(position, length);
				position += 4;
			}
			let key;
			if (this.coercibleKeyAsNumber) for (let i = 0; i < length; i++) {
				key = keys[i];
				let num = Number(key);
				pack(isNaN(num) ? key : num);
				pack(object[key]);
			}
			else for (let i = 0; i < length; i++) {
				pack(key = keys[i]);
				pack(object[key]);
			}
		} : (object) => {
			target[position++] = 222;
			let objectOffset = position - start;
			position += 2;
			let size = 0;
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) {
				pack(key);
				pack(object[key]);
				size++;
			}
			if (size > 65535) throw new Error("Object is too large to serialize with fast 16-bit map size, use the \"variableMapSize\" option to serialize this object");
			target[objectOffset++ + start] = size >> 8;
			target[objectOffset + start] = size & 255;
		};
		const writeRecord = this.useRecords === false ? writePlainObject : options.progressiveRecords && !useTwoByteRecords ? (object) => {
			let nextTransition, transition = structures.transitions || (structures.transitions = Object.create(null));
			let objectOffset = position++ - start;
			let wroteKeys;
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) {
				nextTransition = transition[key];
				if (nextTransition) transition = nextTransition;
				else {
					let keys = Object.keys(object);
					let lastTransition = transition;
					transition = structures.transitions;
					let newTransitions = 0;
					for (let i = 0, l = keys.length; i < l; i++) {
						let key = keys[i];
						nextTransition = transition[key];
						if (!nextTransition) {
							nextTransition = transition[key] = Object.create(null);
							newTransitions++;
						}
						transition = nextTransition;
					}
					if (objectOffset + start + 1 == position) {
						position--;
						newRecord(transition, keys, newTransitions);
					} else insertNewRecord(transition, keys, objectOffset, newTransitions);
					wroteKeys = true;
					transition = lastTransition[key];
				}
				pack(object[key]);
			}
			if (!wroteKeys) {
				let recordId = transition[RECORD_SYMBOL];
				if (recordId) target[objectOffset + start] = recordId;
				else insertNewRecord(transition, Object.keys(object), objectOffset, 0);
			}
		} : (object) => {
			let nextTransition, transition = structures.transitions || (structures.transitions = Object.create(null));
			let newTransitions = 0;
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) {
				nextTransition = transition[key];
				if (!nextTransition) {
					nextTransition = transition[key] = Object.create(null);
					newTransitions++;
				}
				transition = nextTransition;
			}
			let recordId = transition[RECORD_SYMBOL];
			if (recordId) if (recordId >= 96 && useTwoByteRecords) {
				target[position++] = ((recordId -= 96) & 31) + 96;
				target[position++] = recordId >> 5;
			} else target[position++] = recordId;
			else newRecord(transition, transition.__keys__ || Object.keys(object), newTransitions);
			for (let key in object) if (typeof object.hasOwnProperty !== "function" || object.hasOwnProperty(key)) pack(object[key]);
		};
		const checkUseRecords = typeof this.useRecords == "function" && this.useRecords;
		const writeObject = checkUseRecords ? (object) => {
			checkUseRecords(object) ? writeRecord(object) : writePlainObject(object);
		} : writeRecord;
		const makeRoom = (end) => {
			let newSize;
			if (end > 16777216) {
				if (end - start > MAX_BUFFER_SIZE) throw new Error("Packed buffer would be larger than maximum buffer size");
				newSize = Math.min(MAX_BUFFER_SIZE, Math.round(Math.max((end - start) * (end > 67108864 ? 1.25 : 2), 4194304) / 4096) * 4096);
			} else newSize = (Math.max(end - start << 2, target.length - 1) >> 12) + 1 << 12;
			let newBuffer = new ByteArrayAllocate(newSize);
			targetView = newBuffer.dataView || (newBuffer.dataView = new DataView(newBuffer.buffer, 0, newSize));
			end = Math.min(end, target.length);
			if (target.copy) target.copy(newBuffer, 0, start, end);
			else newBuffer.set(target.slice(start, end));
			position -= start;
			start = 0;
			safeEnd = newBuffer.length - 10;
			return target = newBuffer;
		};
		const newRecord = (transition, keys, newTransitions) => {
			let recordId = structures.nextId;
			if (!recordId) recordId = 64;
			if (recordId < sharedLimitId && this.shouldShareStructure && !this.shouldShareStructure(keys)) {
				recordId = structures.nextOwnId;
				if (!(recordId < maxStructureId)) recordId = sharedLimitId;
				structures.nextOwnId = recordId + 1;
			} else {
				if (recordId >= maxStructureId) recordId = sharedLimitId;
				structures.nextId = recordId + 1;
			}
			let highByte = keys.highByte = recordId >= 96 && useTwoByteRecords ? recordId - 96 >> 5 : -1;
			transition[RECORD_SYMBOL] = recordId;
			transition.__keys__ = keys;
			structures[recordId - 64] = keys;
			if (recordId < sharedLimitId) {
				keys.isShared = true;
				structures.sharedLength = recordId - 63;
				hasSharedUpdate = true;
				if (highByte >= 0) {
					target[position++] = (recordId & 31) + 96;
					target[position++] = highByte;
				} else target[position++] = recordId;
			} else {
				if (highByte >= 0) {
					target[position++] = 213;
					target[position++] = 114;
					target[position++] = (recordId & 31) + 96;
					target[position++] = highByte;
				} else {
					target[position++] = 212;
					target[position++] = 114;
					target[position++] = recordId;
				}
				if (newTransitions) transitionsCount += serializationsSinceTransitionRebuild * newTransitions;
				if (recordIdsToRemove.length >= maxOwnStructures) recordIdsToRemove.shift()[RECORD_SYMBOL] = 0;
				recordIdsToRemove.push(transition);
				pack(keys);
			}
		};
		const insertNewRecord = (transition, keys, insertionOffset, newTransitions) => {
			let mainTarget = target;
			let mainPosition = position;
			let mainSafeEnd = safeEnd;
			let mainStart = start;
			target = keysTarget;
			position = 0;
			start = 0;
			if (!target) keysTarget = target = new ByteArrayAllocate(8192);
			safeEnd = target.length - 10;
			newRecord(transition, keys, newTransitions);
			keysTarget = target;
			let keysPosition = position;
			target = mainTarget;
			position = mainPosition;
			safeEnd = mainSafeEnd;
			start = mainStart;
			if (keysPosition > 1) {
				let newEnd = position + keysPosition - 1;
				if (newEnd > safeEnd) makeRoom(newEnd);
				let insertionPosition = insertionOffset + start;
				target.copyWithin(insertionPosition + keysPosition, insertionPosition + 1, position);
				target.set(keysTarget.slice(0, keysPosition), insertionPosition);
				position = newEnd;
			} else target[insertionOffset + start] = keysTarget[0];
		};
		const writeStruct = (object) => {
			let newPosition = writeStructSlots(object, target, start, position, structures, makeRoom, (value, newPosition, notifySharedUpdate) => {
				if (notifySharedUpdate) return hasSharedUpdate = true;
				position = newPosition;
				let startTarget = target;
				pack(value);
				resetStructures();
				if (startTarget !== target) return {
					position,
					targetView,
					target
				};
				return position;
			}, this);
			if (newPosition === 0) return writeObject(object);
			position = newPosition;
		};
	}
	useBuffer(buffer) {
		target = buffer;
		target.dataView || (target.dataView = new DataView(target.buffer, target.byteOffset, target.byteLength));
		targetView = target.dataView;
		position = 0;
	}
	set position(value) {
		position = value;
	}
	get position() {
		return position;
	}
	clearSharedData() {
		if (this.structures) this.structures = [];
		if (this.typedStructs) this.typedStructs = [];
	}
};
extensionClasses = [
	Date,
	Set,
	Error,
	RegExp,
	ArrayBuffer,
	Object.getPrototypeOf(Uint8Array.prototype).constructor,
	DataView,
	C1Type
];
extensions = [
	{ pack(date, allocateForWrite, pack) {
		let seconds = date.getTime() / 1e3;
		if ((this.useTimestamp32 || date.getMilliseconds() === 0) && seconds >= 0 && seconds < 4294967296) {
			let { target, targetView, position } = allocateForWrite(6);
			target[position++] = 214;
			target[position++] = 255;
			targetView.setUint32(position, seconds);
		} else if (seconds > 0 && seconds < 4294967296) {
			let { target, targetView, position } = allocateForWrite(10);
			target[position++] = 215;
			target[position++] = 255;
			targetView.setUint32(position, date.getMilliseconds() * 4e6 + (seconds / 1e3 / 4294967296 >> 0));
			targetView.setUint32(position + 4, seconds);
		} else if (isNaN(seconds)) {
			if (this.onInvalidDate) {
				allocateForWrite(0);
				return pack(this.onInvalidDate());
			}
			let { target, targetView, position } = allocateForWrite(3);
			target[position++] = 212;
			target[position++] = 255;
			target[position++] = 255;
		} else {
			let { target, targetView, position } = allocateForWrite(15);
			target[position++] = 199;
			target[position++] = 12;
			target[position++] = 255;
			targetView.setUint32(position, date.getMilliseconds() * 1e6);
			targetView.setBigInt64(position + 4, BigInt(Math.floor(seconds)));
		}
	} },
	{ pack(set, allocateForWrite, pack) {
		if (this.setAsEmptyObject) {
			allocateForWrite(0);
			return pack({});
		}
		let array = Array.from(set);
		let { target, position } = allocateForWrite(this.moreTypes ? 3 : 0);
		if (this.moreTypes) {
			target[position++] = 212;
			target[position++] = 115;
			target[position++] = 0;
		}
		pack(array);
	} },
	{ pack(error, allocateForWrite, pack) {
		let { target, position } = allocateForWrite(this.moreTypes ? 3 : 0);
		if (this.moreTypes) {
			target[position++] = 212;
			target[position++] = 101;
			target[position++] = 0;
		}
		pack([
			error.name,
			error.message,
			error.cause
		]);
	} },
	{ pack(regex, allocateForWrite, pack) {
		let { target, position } = allocateForWrite(this.moreTypes ? 3 : 0);
		if (this.moreTypes) {
			target[position++] = 212;
			target[position++] = 120;
			target[position++] = 0;
		}
		pack([regex.source, regex.flags]);
	} },
	{ pack(arrayBuffer, allocateForWrite) {
		if (this.moreTypes) writeExtBuffer(arrayBuffer, 16, allocateForWrite);
		else writeBuffer(hasNodeBuffer ? Buffer.from(arrayBuffer) : new Uint8Array(arrayBuffer), allocateForWrite);
	} },
	{ pack(typedArray, allocateForWrite) {
		let constructor = typedArray.constructor;
		if (constructor !== ByteArray && this.moreTypes) writeExtBuffer(typedArray, typedArrays.indexOf(constructor.name), allocateForWrite);
		else writeBuffer(typedArray, allocateForWrite);
	} },
	{ pack(arrayBuffer, allocateForWrite) {
		if (this.moreTypes) writeExtBuffer(arrayBuffer, 17, allocateForWrite);
		else writeBuffer(hasNodeBuffer ? Buffer.from(arrayBuffer) : new Uint8Array(arrayBuffer), allocateForWrite);
	} },
	{ pack(c1, allocateForWrite) {
		let { target, position } = allocateForWrite(1);
		target[position] = 193;
	} }
];
function writeExtBuffer(typedArray, type, allocateForWrite, encode) {
	let length = typedArray.byteLength;
	if (length + 1 < 256) {
		var { target, position } = allocateForWrite(4 + length);
		target[position++] = 199;
		target[position++] = length + 1;
	} else if (length + 1 < 65536) {
		var { target, position } = allocateForWrite(5 + length);
		target[position++] = 200;
		target[position++] = length + 1 >> 8;
		target[position++] = length + 1 & 255;
	} else {
		var { target, position, targetView } = allocateForWrite(7 + length);
		target[position++] = 201;
		targetView.setUint32(position, length + 1);
		position += 4;
	}
	target[position++] = 116;
	target[position++] = type;
	if (!typedArray.buffer) typedArray = new Uint8Array(typedArray);
	target.set(new Uint8Array(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength), position);
}
function writeBuffer(buffer, allocateForWrite) {
	let length = buffer.byteLength;
	var target, position;
	if (length < 256) {
		var { target, position } = allocateForWrite(length + 2);
		target[position++] = 196;
		target[position++] = length;
	} else if (length < 65536) {
		var { target, position } = allocateForWrite(length + 3);
		target[position++] = 197;
		target[position++] = length >> 8;
		target[position++] = length & 255;
	} else {
		var { target, position, targetView } = allocateForWrite(length + 5);
		target[position++] = 198;
		targetView.setUint32(position, length);
		position += 4;
	}
	target.set(buffer, position);
}
function writeExtensionData(result, target, position, type) {
	let length = result.length;
	switch (length) {
		case 1:
			target[position++] = 212;
			break;
		case 2:
			target[position++] = 213;
			break;
		case 4:
			target[position++] = 214;
			break;
		case 8:
			target[position++] = 215;
			break;
		case 16:
			target[position++] = 216;
			break;
		default: if (length < 256) {
			target[position++] = 199;
			target[position++] = length;
		} else if (length < 65536) {
			target[position++] = 200;
			target[position++] = length >> 8;
			target[position++] = length & 255;
		} else {
			target[position++] = 201;
			target[position++] = length >> 24;
			target[position++] = length >> 16 & 255;
			target[position++] = length >> 8 & 255;
			target[position++] = length & 255;
		}
	}
	target[position++] = type;
	target.set(result, position);
	position += length;
	return position;
}
function insertIds(serialized, idsToInsert) {
	let nextId;
	let distanceToMove = idsToInsert.length * 6;
	let lastEnd = serialized.length - distanceToMove;
	while (nextId = idsToInsert.pop()) {
		let offset = nextId.offset;
		let id = nextId.id;
		serialized.copyWithin(offset + distanceToMove, offset, lastEnd);
		distanceToMove -= 6;
		let position = offset + distanceToMove;
		serialized[position++] = 214;
		serialized[position++] = 105;
		serialized[position++] = id >> 24;
		serialized[position++] = id >> 16 & 255;
		serialized[position++] = id >> 8 & 255;
		serialized[position++] = id & 255;
		lastEnd = offset;
	}
	return serialized;
}
function writeBundles(start, pack, incrementPosition) {
	if (bundledStrings.length > 0) {
		targetView.setUint32(bundledStrings.position + start, position + incrementPosition - bundledStrings.position - start);
		bundledStrings.stringsPosition = position - start;
		let writeStrings = bundledStrings;
		bundledStrings = null;
		pack(writeStrings[0]);
		pack(writeStrings[1]);
	}
}
function prepareStructures(structures, packr) {
	structures.isCompatible = (existingStructures) => {
		let compatible = !existingStructures || (packr.lastNamedStructuresLength || 0) === existingStructures.length;
		if (!compatible) packr._mergeStructures(existingStructures);
		return compatible;
	};
	return structures;
}
var defaultPackr = new Packr({ useRecords: false });
defaultPackr.pack;
defaultPackr.pack;
var { NEVER, ALWAYS, DECIMAL_ROUND, DECIMAL_FIT } = FLOAT32_OPTIONS;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcSerialization.js
/**
* @since 4.0.0
*/
var RpcSerialization_exports = /* @__PURE__ */ __exportAll({
	RpcSerialization: () => RpcSerialization,
	json: () => json,
	jsonRpc: () => jsonRpc,
	layerJson: () => layerJson,
	layerJsonRpc: () => layerJsonRpc,
	layerMsgPack: () => layerMsgPack,
	layerNdJsonRpc: () => layerNdJsonRpc,
	layerNdjson: () => layerNdjson,
	msgPack: () => msgPack,
	ndJsonRpc: () => ndJsonRpc,
	ndjson: () => ndjson
});
/**
* @since 4.0.0
* @category serialization
*/
var RpcSerialization = class extends Service$1()("effect/rpc/RpcSerialization") {};
/**
* @since 4.0.0
* @category serialization
*/
var json = /*#__PURE__*/ RpcSerialization.of({
	contentType: "application/json",
	includesFraming: false,
	makeUnsafe: () => {
		const decoder = new TextDecoder();
		return {
			decode: (bytes) => [JSON.parse(typeof bytes === "string" ? bytes : decoder.decode(bytes))],
			encode: (response) => JSON.stringify(response)
		};
	}
});
/**
* @since 4.0.0
* @category serialization
*/
var ndjson = /*#__PURE__*/ RpcSerialization.of({
	contentType: "application/ndjson",
	includesFraming: true,
	makeUnsafe: () => {
		const decoder = new TextDecoder();
		let buffer = "";
		return {
			decode: (bytes) => {
				buffer += typeof bytes === "string" ? bytes : decoder.decode(bytes);
				let position = 0;
				let nlIndex = buffer.indexOf("\n", position);
				const items = [];
				while (nlIndex !== -1) {
					const item = JSON.parse(buffer.slice(position, nlIndex));
					items.push(item);
					position = nlIndex + 1;
					nlIndex = buffer.indexOf("\n", position);
				}
				buffer = buffer.slice(position);
				return items;
			},
			encode: (response) => {
				if (Array.isArray(response)) {
					if (response.length === 0) return void 0;
					let data = "";
					for (let i = 0; i < response.length; i++) data += JSON.stringify(response[i]) + "\n";
					return data;
				}
				return JSON.stringify(response) + "\n";
			}
		};
	}
});
/**
* @since 4.0.0
* @category serialization
*/
var jsonRpc = (options) => RpcSerialization.of({
	contentType: options?.contentType ?? "application/json",
	includesFraming: false,
	makeUnsafe: () => {
		const decoder = new TextDecoder();
		const batches = /* @__PURE__ */ new Map();
		return {
			decode: (bytes) => {
				return decodeJsonRpcRaw(JSON.parse(typeof bytes === "string" ? bytes : decoder.decode(bytes)), batches);
			},
			encode: (response) => {
				const encoded = encodeJsonRpcResponse(response, batches);
				return encoded && JSON.stringify(encoded);
			}
		};
	}
});
/**
* @since 4.0.0
* @category serialization
*/
var ndJsonRpc = (options) => RpcSerialization.of({
	contentType: options?.contentType ?? "application/json-rpc",
	includesFraming: true,
	makeUnsafe: () => {
		const parser = ndjson.makeUnsafe();
		const batches = /* @__PURE__ */ new Map();
		return {
			decode: (bytes) => {
				const frames = parser.decode(bytes);
				if (frames.length === 0) return [];
				const messages = [];
				for (let i = 0; i < frames.length; i++) {
					const frame = frames[i];
					messages.push(...decodeJsonRpcRaw(frame, batches));
				}
				return messages;
			},
			encode: (response) => {
				const encoded = encodeJsonRpcResponse(response, batches);
				return encoded && parser.encode(encoded);
			}
		};
	}
});
function decodeJsonRpcRaw(decoded, batches) {
	if (Array.isArray(decoded)) {
		const batch = {
			size: 0,
			responses: /* @__PURE__ */ new Map()
		};
		const messages = [];
		for (let i = 0; i < decoded.length; i++) {
			const message = decodeJsonRpcMessage(decoded[i]);
			messages.push(message);
			if (message._tag === "Request") {
				batch.size++;
				batches.set(message.id, batch);
			}
		}
		return messages;
	}
	return Array.isArray(decoded) ? decoded.map(decodeJsonRpcMessage) : [decodeJsonRpcMessage(decoded)];
}
function decodeJsonRpcMessage(decoded) {
	if ("method" in decoded) {
		if (!decoded.id && decoded.method.startsWith("@effect/rpc/")) {
			const tag = decoded.method.slice(12);
			const requestId = decoded.params?.requestId;
			return requestId ? {
				_tag: tag,
				requestId: String(requestId)
			} : { _tag: tag };
		}
		return {
			_tag: "Request",
			id: decoded.id ? String(decoded.id) : "",
			tag: decoded.method,
			payload: decoded.params ?? null,
			headers: decoded.headers ?? [],
			...decoded.spanId ? {
				traceId: decoded.traceId,
				spanId: decoded.spanId,
				sampled: decoded.sampled
			} : {}
		};
	} else if (decoded.error && decoded.error._tag === "Defect") return {
		_tag: "Defect",
		defect: decoded.error.data
	};
	else if (decoded.chunk === true) return {
		_tag: "Chunk",
		requestId: String(decoded.id),
		values: decoded.result
	};
	return {
		_tag: "Exit",
		requestId: String(decoded.id),
		exit: decoded.error != null ? {
			_tag: "Failure",
			cause: decoded.error._tag === "Cause" ? decoded.error.data : [{
				_tag: "Die",
				defect: decoded.error
			}]
		} : {
			_tag: "Success",
			value: decoded.result
		}
	};
}
function encodeJsonRpcRaw(response, batches) {
	if (!("requestId" in response)) return encodeJsonRpcMessage(response);
	const batch = batches.get(response.requestId);
	if (batch) {
		batches.delete(response.requestId);
		batch.responses.set(response.requestId, response);
		if (batch.size === batch.responses.size) return Array.from(batch.responses.values(), encodeJsonRpcMessage);
		return;
	}
	return encodeJsonRpcMessage(response);
}
function encodeJsonRpcResponse(response, batches) {
	if (Array.isArray(response) === false) return encodeJsonRpcRaw(response, batches);
	if (response.length === 0) return;
	const encoded = [];
	for (let i = 0; i < response.length; i++) {
		const current = encodeJsonRpcRaw(response[i], batches);
		if (current !== void 0) encoded.push(current);
	}
	if (encoded.length === 0) return;
	if (encoded.length === 1) return encoded[0];
	const messages = [];
	for (let i = 0; i < encoded.length; i++) {
		const current = encoded[i];
		if (Array.isArray(current)) messages.push(...current);
		else messages.push(current);
	}
	return messages;
}
function encodeJsonRpcMessage(response) {
	switch (response._tag) {
		case "Request": return {
			jsonrpc: "2.0",
			method: response.tag,
			params: response.payload,
			id: response.id && Number(response.id),
			headers: response.headers,
			traceId: response.traceId,
			spanId: response.spanId,
			sampled: response.sampled
		};
		case "Ping":
		case "Pong":
		case "Interrupt":
		case "Ack":
		case "Eof": return {
			jsonrpc: "2.0",
			method: `@effect/rpc/${response._tag}`,
			params: "requestId" in response ? { requestId: response.requestId } : void 0
		};
		case "Chunk": return {
			jsonrpc: "2.0",
			chunk: true,
			id: Number(response.requestId),
			result: response.values
		};
		case "Exit": {
			if (response.exit._tag === "Success") return {
				jsonrpc: "2.0",
				id: response.requestId ? Number(response.requestId) : void 0,
				result: response.exit.value
			};
			const error = response.exit.cause.find((failure) => failure._tag === "Fail");
			return {
				jsonrpc: "2.0",
				id: response.requestId ? Number(response.requestId) : void 0,
				error: response.exit._tag === "Failure" ? {
					_tag: "Cause",
					code: error && hasProperty(error, "code") ? Number(error.code) : 0,
					message: error && hasProperty(error, "message") ? error.message : JSON.stringify(response.exit.cause),
					data: response.exit.cause
				} : void 0
			};
		}
		case "Defect": return {
			jsonrpc: "2.0",
			id: jsonRpcInternalError,
			error: {
				_tag: "Defect",
				code: 1,
				message: "A defect occurred",
				data: response.defect
			}
		};
		case "ClientProtocolError": return {};
	}
}
var jsonRpcInternalError = -32603;
/**
* @since 4.0.0
* @category serialization
*/
var msgPack = /*#__PURE__*/ RpcSerialization.of({
	contentType: "application/msgpack",
	includesFraming: true,
	makeUnsafe: () => {
		const unpackr = new Unpackr({ useRecords: true });
		const packr = new Packr({ useRecords: true });
		const encoder = new TextEncoder();
		let incomplete = void 0;
		return {
			decode: (bytes) => {
				let buf = typeof bytes === "string" ? encoder.encode(bytes) : bytes;
				if (incomplete !== void 0) {
					const prev = buf;
					bytes = new Uint8Array(incomplete.length + buf.length);
					bytes.set(incomplete);
					bytes.set(prev, incomplete.length);
					buf = bytes;
					incomplete = void 0;
				}
				try {
					return unpackr.unpackMultiple(buf);
				} catch (error_) {
					const error = error_;
					if (error.incomplete) {
						incomplete = buf.subarray(error.lastPosition);
						return error.values ?? [];
					}
					return [];
				}
			},
			encode: (response) => packr.pack(response)
		};
	}
});
/**
* A rpc serialization layer that uses JSON for serialization.
*
* Use this if your protocol supports framing for messages, otherwise use
* {@link layerNdjson}.
*
* @since 4.0.0
* @category serialization
*/
var layerJson = /*#__PURE__*/ succeed(RpcSerialization)(json);
/**
* A rpc serialization layer that uses NDJSON for serialization.
*
* Use this if your protocol does not support framing for messages, otherwise
* use {@link layerJson}.
*
* @since 4.0.0
* @category serialization
*/
var layerNdjson = /*#__PURE__*/ succeed(RpcSerialization)(ndjson);
/**
* A rpc serialization layer that uses JSON-RPC for serialization.
*
* @since 4.0.0
* @category serialization
*/
var layerJsonRpc = (options) => succeed(RpcSerialization)(jsonRpc(options));
/**
* A rpc serialization layer that uses JSON-RPC for serialization seperated by
* new lines.
*
* @since 4.0.0
* @category serialization
*/
var layerNdJsonRpc = (options) => succeed(RpcSerialization)(ndJsonRpc(options));
/**
* A rpc serialization layer that uses MessagePack for serialization.
*
* MessagePack has a more compact binary format compared to JSON and NDJSON. It
* also has better support for binary data.
*
* @since 4.0.0
* @category serialization
*/
var layerMsgPack = /*#__PURE__*/ succeed(RpcSerialization)(msgPack);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcWorker.js
var RpcWorker_exports = /* @__PURE__ */ __exportAll({
	InitialMessage: () => InitialMessage,
	initialMessage: () => initialMessage,
	layerInitialMessage: () => layerInitialMessage,
	makeInitialMessage: () => makeInitialMessage
});
/**
* @since 4.0.0
* @category initial message
*/
var InitialMessage = class extends Service$1()("effect/rpc/RpcWorker/InitialMessage") {};
var ProtocolTag = /*#__PURE__*/ Service$1("@effect/rpc/RpcServer/Protocol");
/**
* @since 4.0.0
* @category initial message
*/
var makeInitialMessage = (schema, effect) => {
	const schemaJson = toCodecJson(schema);
	return flatMap(effect, (value) => {
		const collector = makeCollectorUnsafe();
		return encodeEffect(schemaJson)(value).pipe(provideService(Collector, collector), map$1((encoded) => [encoded, collector.clearUnsafe()]));
	});
};
/**
* @since 4.0.0
* @category initial message
*/
var layerInitialMessage = (schema, build) => effect(InitialMessage)(servicesWith((services) => succeed$1(provideServices(orDie(makeInitialMessage(schema, build)), services))));
/**
* @since 4.0.0
* @category initial message
*/
var initialMessage = (schema) => ProtocolTag.asEffect().pipe(flatMap((protocol) => protocol.initialMessage), flatMap((o) => o.asEffect()), flatMap(decodeUnknownEffect(toCodecJson(schema))));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/Utils.js
/**
* @since 4.0.0
*/
var Utils_exports = /* @__PURE__ */ __exportAll({ withRun: () => withRun });
/**
* @since 4.0.0
*/
var withRun = () => (f) => suspend(() => {
	const semaphore = makeUnsafe$2(1);
	let buffer = [];
	let write = (...args) => servicesWith((context) => {
		buffer.push([args, context]);
		return void_;
	});
	return map$1(f((...args) => write(...args)), (a) => ({
		...a,
		run(f) {
			return semaphore.withPermits(1)(gen(function* () {
				const prev = write;
				write = f;
				for (const [args, context] of buffer) yield* provide(write(...args), context);
				buffer = [];
				return yield* onExit(never, () => {
					write = prev;
					return void_;
				});
			}));
		}
	}));
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcClient.js
var RpcClient_exports = /* @__PURE__ */ __exportAll({
	CurrentHeaders: () => CurrentHeaders,
	Protocol: () => Protocol$1,
	layerProtocolHttp: () => layerProtocolHttp$1,
	layerProtocolSocket: () => layerProtocolSocket,
	layerProtocolWorker: () => layerProtocolWorker,
	make: () => make$5,
	makeNoSerialization: () => makeNoSerialization$1,
	makeProtocolHttp: () => makeProtocolHttp$1,
	makeProtocolSocket: () => makeProtocolSocket,
	makeProtocolWorker: () => makeProtocolWorker,
	withHeaders: () => withHeaders
});
var requestIdCounter = /*#__PURE__*/ BigInt(0);
/**
* @since 4.0.0
* @category client
*/
var makeNoSerialization$1 = /*#__PURE__*/ fnUntraced(function* (group, options) {
	const spanPrefix = options?.spanPrefix ?? "RpcClient";
	const supportsAck = options?.supportsAck ?? true;
	const disableTracing = options?.disableTracing ?? false;
	const generateRequestId = options?.generateRequestId ?? (() => requestIdCounter++);
	const services$4 = yield* services();
	const scope = get(services$4, Scope);
	const entries = /* @__PURE__ */ new Map();
	let isShutdown = false;
	yield* addFinalizer(scope, withFiber((parent) => {
		isShutdown = true;
		return clearEntries(interrupt(parent.id));
	}));
	const clearEntries = fnUntraced(function* (exit) {
		for (const [id, entry] of entries) {
			entries.delete(id);
			if (entry._tag === "Queue") yield* exit._tag === "Success" ? end(entry.queue) : failCause$1(entry.queue, exit.cause);
			else entry.resume(exit);
		}
	});
	const onRequest = (rpc) => {
		const isStream = isStreamSchema(rpc.successSchema);
		const middleware = getRpcClientMiddleware(rpc);
		return (payload, opts) => {
			const headers = opts?.headers ? fromInput$1(opts.headers) : empty$5;
			const context = opts?.context ?? empty$6();
			if (!isStream) {
				const onRequest = (span) => onEffectRequest(rpc, middleware, span, rpc.payloadSchema.makeUnsafe(payload), headers, context, opts?.discard ?? false);
				return disableTracing ? onRequest(void 0) : useSpan(`${spanPrefix}.${rpc._tag}`, { attributes: options.spanAttributes }, onRequest);
			}
			const queue = onStreamRequest(rpc, middleware, rpc.payloadSchema.makeUnsafe(payload), headers, opts?.streamBufferSize ?? 16, context);
			if (opts?.asQueue) return queue;
			return unwrap(map$1(queue, fromQueue));
		};
	};
	const onEffectRequest = (rpc, middleware, span, payload, headers, context, discard) => withFiber((parentFiber) => {
		if (isShutdown) return interrupt$1;
		const id = generateRequestId();
		const send = middleware((message) => options.onFromClient({
			message,
			context,
			discard
		}), {
			_tag: "Request",
			id,
			tag: rpc._tag,
			payload,
			...span ? {
				traceId: span.traceId,
				spanId: span.spanId,
				sampled: span.sampled
			} : {},
			headers: merge(parentFiber.getRef(CurrentHeaders), headers)
		});
		if (discard) return send;
		let fiber;
		return onInterrupt(callback((resume) => {
			const entry = {
				_tag: "Effect",
				rpc,
				context,
				resume(exit) {
					resume(exit);
					if (fiber && !fiber.pollUnsafe()) parentFiber.currentScheduler.scheduleTask(() => {
						fiber.interruptUnsafe(parentFiber.id);
					}, 0);
				}
			};
			entries.set(id, entry);
			fiber = send.pipe(span ? withParentSpan(span, { captureStackTrace: false }) : identity, runForkWith(parentFiber.services));
			fiber.addObserver((exit) => {
				if (exit._tag === "Failure") return resume(exit);
			});
		}), (interruptors) => {
			entries.delete(id);
			return andThen(interrupt$2(fiber), sendInterrupt(id, Array.from(interruptors), context));
		});
	});
	const onStreamRequest = fnUntraced(function* (rpc, middleware, payload, headers, streamBufferSize, context) {
		if (isShutdown) return yield* interrupt$1;
		const span = disableTracing ? void 0 : yield* makeSpanScoped(`${spanPrefix}.${rpc._tag}`, { attributes: options.spanAttributes });
		const fiber = getCurrent();
		const id = generateRequestId();
		const scope = getUnsafe(fiber.services, Scope);
		yield* addFinalizerExit(scope, (exit) => {
			if (!entries.has(id)) return void_;
			entries.delete(id);
			return sendInterrupt(id, isFailure(exit) ? Array.from(interruptors(exit.cause)) : [], context);
		});
		const queue = yield* bounded(streamBufferSize);
		entries.set(id, {
			_tag: "Queue",
			rpc,
			queue,
			scope,
			context
		});
		yield* middleware((message) => options.onFromClient({
			message,
			context,
			discard: false
		}), {
			_tag: "Request",
			id,
			tag: rpc._tag,
			payload,
			...span ? {
				traceId: span.traceId,
				spanId: span.spanId,
				sampled: span.sampled
			} : {},
			headers: merge(fiber.getRef(CurrentHeaders), headers)
		}).pipe(span ? withParentSpan(span, { captureStackTrace: false }) : identity, catchCause((error) => failCause$1(queue, error)), interruptible, forkIn(scope, { startImmediately: true }));
		return queue;
	});
	const getRpcClientMiddleware = (rpc) => {
		const middlewares = [];
		for (const tag of rpc.middlewares.values()) {
			const middleware = services$4.mapUnsafe.get(`${tag.key}/Client`);
			if (!middleware) continue;
			middlewares.push(middleware);
		}
		if (middlewares.length === 0) return (send, request) => send(request);
		return function loop(send, request, index = middlewares.length - 1) {
			if (index === -1) return send(request);
			return middlewares[index]({
				rpc,
				request,
				next(request) {
					return loop(send, request, index - 1);
				}
			});
		};
	};
	const sendInterrupt = (requestId, interruptors, context) => callback((resume) => {
		const parentFiber = getCurrent();
		options.onFromClient({
			message: {
				_tag: "Interrupt",
				requestId,
				interruptors
			},
			context,
			discard: false
		}).pipe(timeout(1e3), runForkWith(parentFiber.services)).addObserver(() => {
			resume(void_);
		});
	});
	const write = (message) => {
		switch (message._tag) {
			case "Chunk": {
				const requestId = message.requestId;
				const entry = entries.get(requestId);
				if (!entry || entry._tag !== "Queue") return void_;
				return offerAll(entry.queue, message.values).pipe(supportsAck ? flatMap(() => options.onFromClient({
					message: {
						_tag: "Ack",
						requestId: message.requestId
					},
					context: entry.context,
					discard: false
				})) : identity, catchCause((cause) => failCause$1(entry.queue, cause)));
			}
			case "Exit": {
				const requestId = message.requestId;
				const entry = entries.get(requestId);
				if (!entry) return void_;
				entries.delete(requestId);
				if (entry._tag === "Effect") {
					entry.resume(message.exit);
					return void_;
				}
				return message.exit._tag === "Success" ? end(entry.queue) : failCause$1(entry.queue, message.exit.cause);
			}
			case "Defect": return clearEntries(die(message.defect));
			case "ClientEnd": return void_;
		}
	};
	let client;
	if (options.flatten) {
		const fns = /* @__PURE__ */ new Map();
		client = function client(tag, payload, options) {
			let fn = fns.get(tag);
			if (!fn) {
				fn = onRequest(group.requests.get(tag));
				fns.set(tag, fn);
			}
			return fn(payload, options);
		};
	} else {
		client = {};
		group.requests.forEach((rpc) => {
			client[rpc._tag] = onRequest(rpc);
		});
	}
	return {
		client,
		write
	};
});
/**
* @since 4.0.0
* @category client
*/
var make$5 = /*#__PURE__*/ fnUntraced(function* (group, options) {
	const { run, send, supportsAck, supportsTransferables } = yield* Protocol$1;
	const entries = /* @__PURE__ */ new Map();
	const { client, write } = yield* makeNoSerialization$1(group, {
		...options,
		supportsAck,
		onFromClient({ message }) {
			switch (message._tag) {
				case "Request": {
					const rpc = group.requests.get(message.tag);
					const collector = supportsTransferables ? makeCollectorUnsafe() : void 0;
					const fiber = getCurrent();
					const entry = {
						rpc,
						context: collector ? add(fiber.services, Collector, collector) : fiber.services,
						schemas: rpcSchemas(rpc)
					};
					entries.set(message.id, entry);
					return entry.schemas.encodePayload(message.payload).pipe(provideServices(entry.context), orDie, flatMap((payload) => send({
						...message,
						id: String(message.id),
						payload,
						headers: Object.entries(message.headers)
					}, collector && collector.readUnsafe())));
				}
				case "Ack":
					if (!entries.get(message.requestId)) return void_;
					return send({
						_tag: "Ack",
						requestId: String(message.requestId)
					});
				case "Interrupt":
					if (!entries.get(message.requestId)) return void_;
					entries.delete(message.requestId);
					return send({
						_tag: "Interrupt",
						requestId: String(message.requestId)
					});
				case "Eof": return void_;
			}
		}
	});
	yield* run((message) => {
		switch (message._tag) {
			case "Chunk": {
				const requestId = RequestId(message.requestId);
				const entry = entries.get(requestId);
				if (!entry || !entry.schemas.decodeChunk) return void_;
				return entry.schemas.decodeChunk(message.values).pipe(provideServices(entry.context), orDie, flatMap((chunk) => write({
					_tag: "Chunk",
					clientId: 0,
					requestId: RequestId(message.requestId),
					values: chunk
				})), onError((cause) => write({
					_tag: "Exit",
					clientId: 0,
					requestId: RequestId(message.requestId),
					exit: failCause(cause)
				})));
			}
			case "Exit": {
				const requestId = RequestId(message.requestId);
				const entry = entries.get(requestId);
				if (!entry) return void_;
				entries.delete(requestId);
				return entry.schemas.decodeExit(message.exit).pipe(provideServices(entry.context), orDie, matchCauseEffect({
					onSuccess: (exit) => write({
						_tag: "Exit",
						clientId: 0,
						requestId,
						exit
					}),
					onFailure: (cause) => write({
						_tag: "Exit",
						clientId: 0,
						requestId,
						exit: failCause(cause)
					})
				}));
			}
			case "Defect": return write({
				_tag: "Defect",
				clientId: 0,
				defect: decodeDefect(message.defect)
			});
			case "ClientProtocolError": {
				const exit = fail(message.error);
				return forEach(entries.keys(), (requestId) => write({
					_tag: "Exit",
					clientId: 0,
					requestId,
					exit
				}));
			}
			default: return void_;
		}
	}).pipe(catchCause(logError), interruptible, forkScoped);
	return client;
});
var rpcSchemasCache = /*#__PURE__*/ new WeakMap();
var rpcSchemas = (rpc) => {
	let entry = rpcSchemasCache.get(rpc);
	if (entry !== void 0) return entry;
	const streamSchemas = getStreamSchemas(rpc.successSchema);
	entry = {
		decodeChunk: streamSchemas ? decodeUnknownEffect(toCodecJson(NonEmptyArray(streamSchemas.success))) : void 0,
		encodePayload: encodeEffect(toCodecJson(rpc.payloadSchema)),
		decodeExit: decodeUnknownEffect(toCodecJson(exitSchema(rpc)))
	};
	rpcSchemasCache.set(rpc, entry);
	return entry;
};
/**
* @since 4.0.0
* @category headers
*/
var CurrentHeaders = /*#__PURE__*/ Reference("effect/rpc/RpcClient/CurrentHeaders", { defaultValue: () => empty$5 });
/**
* @since 4.0.0
* @category headers
*/
var withHeaders = /*#__PURE__*/ dual(2, (effect, headers) => updateService(effect, CurrentHeaders, merge(fromInput$1(headers))));
/**
* @since 4.0.0
* @category protocol
*/
var Protocol$1 = class extends Service$1()("effect/rpc/RpcClient/Protocol") {
	/**
	* @since 4.0.0
	*/
	static make = /*#__PURE__*/ withRun();
};
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolHttp$1 = (client) => Protocol$1.make(fnUntraced(function* (writeResponse) {
	const serialization = yield* RpcSerialization;
	const isFramed = serialization.includesFraming;
	const send = (request) => {
		if (request._tag !== "Request") return void_;
		const parser = serialization.makeUnsafe();
		const encoded = parser.encode(request);
		const body = typeof encoded === "string" ? text$1(encoded, serialization.contentType) : uint8Array$1(encoded, serialization.contentType);
		if (!isFramed) return client.post("", { body }).pipe(flatMap((r) => r.text), mapError((cause) => new RpcClientError({ reason: HttpClientErrorSchema.fromHttpClientError(cause) })), flatMap((text) => {
			const u = parser.decode(text);
			if (!Array.isArray(u)) return die$1(`Expected an array of responses, but got: ${u}`);
			let i = 0;
			return whileLoop({
				while: () => i < u.length,
				body: () => writeResponse(u[i++]),
				step: constVoid
			});
		}));
		return client.post("", { body }).pipe(flatMap((r) => runForEachArray(r.stream, (chunk) => {
			const responses = chunk.flatMap(parser.decode);
			if (responses.length === 0) return void_;
			let i = 0;
			return whileLoop({
				while: () => i < responses.length,
				body: () => writeResponse(responses[i++]),
				step: constVoid
			});
		})), mapError((cause) => new RpcClientError({ reason: HttpClientErrorSchema.fromHttpClientError(cause) })));
	};
	return {
		send,
		supportsAck: false,
		supportsTransferables: false
	};
}));
/**
* @since 4.0.0
* @category protocol
*/
var layerProtocolHttp$1 = (options) => effect(Protocol$1)(flatMap(HttpClient.asEffect(), (client) => {
	client = mapRequest(client, prependUrl(options.url));
	return makeProtocolHttp$1(options.transformClient ? options.transformClient(client) : client);
}));
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolSocket = (options) => Protocol$1.make(fnUntraced(function* (writeResponse) {
	const socket = yield* Socket;
	const serialization = yield* RpcSerialization;
	const write = yield* socket.writer;
	let parser = serialization.makeUnsafe();
	const pinger = yield* makePinger(write(parser.encode(constPing)));
	let currentError;
	const clearCurrentError = sync(() => {
		currentError = void 0;
	});
	yield* suspend(() => {
		parser = serialization.makeUnsafe();
		pinger.reset();
		return socket.runRaw((message) => {
			try {
				const responses = parser.decode(message);
				if (responses.length === 0) return;
				let i = 0;
				return whileLoop({
					while: () => i < responses.length,
					body: () => {
						const response = responses[i++];
						if (response._tag === "Pong") pinger.onPong();
						return writeResponse(response);
					},
					step: constVoid
				});
			} catch (defect) {
				return writeResponse({
					_tag: "ClientProtocolError",
					error: new RpcClientError({ reason: new RpcClientDefect({
						message: "Error decoding message",
						cause: defect
					}) })
				});
			}
		}, { onOpen: clearCurrentError }).pipe(raceFirst(flatMap(pinger.timeout, () => fail$1(new SocketError({ reason: new SocketOpenError({
			kind: "Timeout",
			cause: /* @__PURE__ */ new Error("ping timeout")
		}) })))));
	}).pipe(flatMap(() => fail$1(new SocketError({ reason: new SocketCloseError({ code: 1e3 }) }))), tapCause((cause) => {
		const error = findError(cause);
		const hasError = isSuccess(error);
		if (options?.retryTransientErrors && hasError && error.success.reason._tag === "SocketOpenError") return void_;
		currentError = new RpcClientError({ reason: hasError ? error.success.reason : new RpcClientDefect({
			message: "Unknown socket error",
			cause: squash(cause)
		}) });
		return writeResponse({
			_tag: "ClientProtocolError",
			error: currentError
		});
	}), retry(options?.retryPolicy ?? defaultRetryPolicy), annotateLogs({
		module: "RpcClient",
		method: "makeProtocolSocket"
	}), forkScoped);
	return {
		send(request) {
			if (currentError) return fail$1(currentError);
			const encoded = parser.encode(request);
			if (encoded === void 0) return void_;
			return orDie(write(encoded));
		},
		supportsAck: true,
		supportsTransferables: false
	};
}));
var defaultRetryPolicy = /*#__PURE__*/ exponential(500, 1.5).pipe(/*#__PURE__*/ either(/*#__PURE__*/ spaced(5e3)));
var makePinger = /*#__PURE__*/ fnUntraced(function* (writePing) {
	let recievedPong = true;
	const latch = makeUnsafe$3();
	const reset = () => {
		recievedPong = true;
		latch.closeUnsafe();
	};
	const onPong = () => {
		recievedPong = true;
	};
	yield* suspend(() => {
		if (!recievedPong) return latch.open;
		recievedPong = false;
		return writePing;
	}).pipe(delay("5 seconds"), ignore, forever, interruptible, forkScoped);
	return {
		timeout: latch.await,
		reset,
		onPong
	};
});
/**
* @since 4.0.0
* @category protocol
*/
var layerProtocolSocket = (options) => effect(Protocol$1)(makeProtocolSocket(options));
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolWorker = (options) => Protocol$1.make(fnUntraced(function* (writeResponse) {
	const worker = yield* WorkerPlatform;
	const scope$2 = yield* scope;
	let workerId = 0;
	const initialMessage = yield* serviceOption(InitialMessage);
	const entries = /* @__PURE__ */ new Map();
	const acquire = gen(function* () {
		const id = workerId++;
		const backing = yield* worker.spawn(id);
		yield* backing.run((response) => {
			if (response._tag === "Exit") {
				const entry = entries.get(response.requestId);
				if (entry) {
					entries.delete(response.requestId);
					entry.latch.openUnsafe();
					return writeResponse(response);
				}
			} else if (response._tag === "Defect") {
				for (const [requestId, entry] of entries) {
					entries.delete(requestId);
					entry.latch.openUnsafe();
				}
				return writeResponse(response);
			}
			return writeResponse(response);
		}, { onSpawn: isSome(initialMessage) ? flatMap(initialMessage.value, ([value, transfers]) => orDie(backing.send({
			_tag: "InitialMessage",
			value
		}, transfers))) : void 0 }).pipe(tapCause((cause) => {
			const error = findError(cause);
			return writeResponse({
				_tag: "ClientProtocolError",
				error: new RpcClientError({ reason: isSuccess(error) ? error.success.reason : new RpcClientDefect({
					message: "Error in worker",
					cause: squash(cause)
				}) })
			});
		}), retry(spaced(1e3)), annotateLogs({
			module: "RpcClient",
			method: "makeProtocolWorker"
		}), interruptible, forkScoped);
		return backing;
	});
	const pool = "minSize" in options ? yield* makeWithTTL({
		acquire,
		min: options.minSize,
		max: options.maxSize,
		concurrency: options.concurrency,
		targetUtilization: options.targetUtilization,
		timeToLive: options.timeToLive
	}) : yield* make$13({
		acquire,
		size: options.size,
		concurrency: options.concurrency,
		targetUtilization: options.targetUtilization
	});
	yield* addFinalizer(scope$2, sync(() => {
		for (const entry of entries.values()) entry.latch.openUnsafe();
		entries.clear();
	}));
	const send = (request, transferables) => {
		switch (request._tag) {
			case "Request": return get$1(pool).pipe(flatMap((worker) => {
				const latch = makeUnsafe$3(false);
				entries.set(request.id, {
					worker,
					latch
				});
				return flatMap(worker.send(request, transferables), () => latch.await);
			}), scoped, orDie);
			case "Interrupt": {
				const entry = entries.get(request.requestId);
				if (!entry) return void_;
				entries.delete(request.requestId);
				entry.latch.openUnsafe();
				return orDie(entry.worker.send(request));
			}
			case "Ack": {
				const entry = entries.get(request.requestId);
				if (!entry) return void_;
				return orDie(entry.worker.send(request));
			}
		}
		return void_;
	};
	yield* scoped(get$1(pool));
	return {
		send,
		supportsAck: true,
		supportsTransferables: true
	};
}));
/**
* @since 4.0.0
* @category protocol
*/
var layerProtocolWorker = /*#__PURE__*/ flow(makeProtocolWorker, /*#__PURE__*/ effect(Protocol$1));
var decodeDefect = /*#__PURE__*/ decodeSync(Defect);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcMiddleware.js
/**
* @since 4.0.0
*/
var RpcMiddleware_exports = /* @__PURE__ */ __exportAll({
	Service: () => Service,
	TypeId: () => TypeId$4,
	layerClient: () => layerClient
});
/**
* @since 4.0.0
* @category Type IDs
*/
var TypeId$4 = "~effect/rpc/RpcMiddleware";
/**
* @since 4.0.0
* @category tags
*/
var Service = () => (id, options) => {
	const Err = globalThis.Error;
	const limit = Err.stackTraceLimit;
	Err.stackTraceLimit = 2;
	const creationError = new Err();
	Err.stackTraceLimit = limit;
	function ServiceClass() {}
	const ServiceClass_ = ServiceClass;
	Object.setPrototypeOf(ServiceClass, Object.getPrototypeOf(Service$1(id)));
	ServiceClass.key = id;
	Object.defineProperty(ServiceClass, "stack", { get() {
		return creationError.stack;
	} });
	ServiceClass_[TypeId$4] = TypeId$4;
	ServiceClass_.error = options?.error ?? Never;
	ServiceClass_.requiredForClient = options?.requiredForClient ?? false;
	return ServiceClass;
};
/**
* @since 4.0.0
* @category client
*/
var layerClient = (tag, service) => effectServices(gen(function* () {
	const services$3 = (yield* services()).pipe(omit(Scope));
	const middleware = isEffect(service) ? yield* service : service;
	return makeUnsafe(/* @__PURE__ */ new Map([[`${tag.key}/Client`, (options) => updateServices(middleware(options), (requestContext) => merge$1(services$3, requestContext))]]));
}));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpServerResponse.js
var TypeId$3 = "~effect/http/HttpServerResponse";
/**
* @since 4.0.0
* @category constructors
*/
var empty = (options) => makeResponse({
	status: options?.status ?? 204,
	statusText: options?.statusText,
	headers: options?.headers ? fromInput$1(options.headers) : void 0,
	cookies: options?.cookies
});
/**
* @since 4.0.0
* @category constructors
*/
var uint8Array = (body, options) => {
	const headers = options?.headers ? fromInput$1(options.headers) : empty$5;
	return makeResponse({
		status: options?.status ?? 200,
		statusText: options?.statusText,
		headers,
		cookies: options?.cookies ?? empty$2,
		body: uint8Array$1(body, getContentType(options, headers))
	});
};
var getContentType = (options, headers) => {
	if (options?.contentType) return options.contentType;
	else if (options?.headers) return headers["content-type"];
};
/**
* @since 4.0.0
* @category constructors
*/
var text = (body, options) => {
	const headers = options?.headers ? fromInput$1(options.headers) : empty$5;
	return makeResponse({
		status: options?.status ?? 200,
		statusText: options?.statusText,
		headers,
		cookies: options?.cookies ?? empty$2,
		body: text$1(body, getContentType(options, headers))
	});
};
/**
* @since 4.0.0
* @category constructors
*/
var stream = (body, options) => {
	const headers = options?.headers ? fromInput$1(options.headers) : empty$5;
	return makeResponse({
		status: options?.status ?? 200,
		statusText: options?.statusText,
		headers,
		cookies: options?.cookies,
		body: stream$1(body, getContentType(options, headers), options?.contentLength)
	});
};
var Proto = {
	...PipeInspectableProto,
	[TypeId$3]: TypeId$3,
	[ignore$1]: true,
	toJSON() {
		return {
			_id: "HttpServerResponse",
			status: this.status,
			statusText: this.statusText,
			headers: redact$1(this.headers),
			cookies: this.cookies.toJSON(),
			body: this.body.toJSON()
		};
	}
};
var makeResponse = (options) => {
	const self = Object.create(Proto);
	self.status = options.status;
	self.statusText = options.statusText;
	self.cookies = options.cookies ?? empty$2;
	self.body = options.body ?? empty$3;
	if (self.body._tag !== "Empty" && (self.body.contentType || self.body.contentLength)) {
		const newHeaders = fromRecordUnsafe({ ...options.headers });
		if (self.body.contentType) newHeaders["content-type"] = self.body.contentType;
		if (self.body.contentLength) newHeaders["content-length"] = self.body.contentLength.toString();
		self.headers = newHeaders;
	} else self.headers = options.headers ?? empty$5;
	return self;
};
TaggedError("HttpServerError");
TaggedError("RequestParseError");
TaggedError("RouteNotFound");
TaggedError("InternalError");
TaggedError("ResponseError");
TaggedError("ServeError");
Service$1()("effect/http/HttpServerError/ClientAbort");
var State$1;
(function(State) {
	State[State["key"] = 0] = "key";
	State[State["whitespace"] = 1] = "whitespace";
	State[State["value"] = 2] = "value";
})(State$1 || (State$1 = {}));
//#endregion
//#region node_modules/.bun/multipasta@0.2.7/node_modules/multipasta/dist/esm/internal/multipart.js
var State;
(function(State) {
	State[State["headers"] = 0] = "headers";
	State[State["body"] = 1] = "body";
})(State || (State = {}));
TaggedError("MultipartError");
/**
* @since 4.0.0
* @category context
*/
var HttpServerRequest = /*#__PURE__*/ Service$1("effect/http/HttpServerRequest");
Service$1()("effect/http/ParsedSearchParams");
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpMiddleware.js
var loggerDisabledRequests = /*#__PURE__*/ new WeakSet();
/**
* @since 4.0.0
* @category Logger
*/
var withLoggerDisabled = (self) => withFiber((fiber) => {
	const request = getUnsafe(fiber.services, HttpServerRequest);
	loggerDisabledRequests.add(request.source);
	return self;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/http/HttpRouter.js
/**
* @since 4.0.0
*/
/**
* @since 4.0.0
* @category HttpRouter
*/
var HttpRouter = /*#__PURE__*/ Service$1("effect/http/HttpRouter");
Service$1()("effect/http/HttpRouter/RouteContext");
var MiddlewareTypeId = "~effect/http/HttpRouter/Middleware";
/**
* Create a middleware layer that can be used to modify requests and responses.
*
* By default, the middleware only affects the routes that it is provided to.
*
* If you want to create a middleware that applies globally to all routes, pass
* the `global` option as `true`.
*
* ```ts
* import { Effect } from "effect"
* import * as Layer from "effect/Layer"
* import * as ServiceMap from "effect/ServiceMap"
* import * as HttpMiddleware from "effect/unstable/http/HttpMiddleware"
* import * as HttpRouter from "effect/unstable/http/HttpRouter"
* import * as HttpServerResponse from "effect/unstable/http/HttpServerResponse"
*
* // Here we are defining a CORS middleware
* const CorsMiddleware = HttpRouter.middleware(HttpMiddleware.cors()).layer
* // You can also use HttpRouter.cors() to create a CORS middleware
*
* class CurrentSession extends ServiceMap.Service<CurrentSession, {
*   readonly token: string
* }>()("CurrentSession") {}
*
* // You can create middleware that provides a service to the HTTP requests.
* const SessionMiddleware = HttpRouter.middleware<{
*   provides: CurrentSession
* }>()(
*   Effect.gen(function*() {
*     yield* Effect.log("SessionMiddleware initialized")
*
*     return (httpEffect) =>
*       Effect.provideService(httpEffect, CurrentSession, {
*         token: "dummy-token"
*       })
*   })
* ).layer
*
* Effect.gen(function*() {
*   const router = yield* HttpRouter.HttpRouter
*   yield* router.add(
*     "GET",
*     "/hello",
*     Effect.gen(function*() {
*       // Requests can now access the current session
*       const session = yield* CurrentSession
*       return HttpServerResponse.text(
*         `Hello, World! Your token is ${session.token}`
*       )
*     })
*   )
* }).pipe(
*   Layer.effectDiscard,
*   // Provide the SessionMiddleware & CorsMiddleware to some routes
*   Layer.provide([SessionMiddleware, CorsMiddleware])
* )
* ```
*
* @since 4.0.0
* @category Middleware
*/
var middleware = function() {
	if (arguments.length === 0) return makeMiddleware;
	return makeMiddleware(arguments[0], arguments[1]);
};
var makeMiddleware = (middleware, options) => options?.global ? effectDiscard(gen(function* () {
	const router = yield* HttpRouter;
	const fn = isEffect(middleware) ? yield* middleware : middleware;
	yield* router.addGlobalMiddleware(fn);
})) : new MiddlewareImpl(isEffect(middleware) ? effectServices(map$1(middleware, (fn) => makeUnsafe(/* @__PURE__ */ new Map([[fnContextKey, fn]])))) : succeedServices(makeUnsafe(/* @__PURE__ */ new Map([[fnContextKey, middleware]]))));
var middlewareId = 0;
var fnContextKey = "effect/http/HttpRouter/MiddlewareFn";
var MiddlewareImpl = class MiddlewareImpl {
	[MiddlewareTypeId] = {};
	layerFn;
	dependencies;
	constructor(layerFn, dependencies) {
		this.layerFn = layerFn;
		this.dependencies = dependencies;
		const contextKey = `effect/http/HttpRouter/Middleware-${++middlewareId}`;
		this.layer = effectServices(gen({ self: this }, function* () {
			const context = yield* services();
			const stack = [context.mapUnsafe.get(fnContextKey)];
			if (this.dependencies) {
				const memoMap = yield* CurrentMemoMap;
				const scope = get(context, Scope);
				const depsContext = yield* buildWithMemoMap(this.dependencies, memoMap, scope);
				stack.push(...getMiddleware(depsContext));
			}
			return makeUnsafe(/* @__PURE__ */ new Map([[contextKey, stack]]));
		})).pipe(provide$1(this.layerFn));
	}
	layer;
	combine(other) {
		return new MiddlewareImpl(this.layerFn, this.dependencies ? provideMerge(this.dependencies, other.layer) : other.layer);
	}
};
var middlewareCache = /*#__PURE__*/ new WeakMap();
var getMiddleware = (context) => {
	let arr = middlewareCache.get(context);
	if (arr) return arr;
	const topLevel = empty$7();
	let maxLength = 0;
	for (const [key, value] of context.mapUnsafe) if (key.startsWith("effect/http/HttpRouter/Middleware-")) {
		topLevel.push(value);
		if (value.length > maxLength) maxLength = value.length;
	}
	if (topLevel.length === 0) arr = [];
	else {
		const middleware = /* @__PURE__ */ new Set();
		for (let i = maxLength - 1; i >= 0; i--) for (const arr of topLevel) if (i < arr.length) middleware.add(arr[i]);
		arr = fromIterable$1(middleware).reverse();
	}
	middlewareCache.set(context, arr);
	return arr;
};
(/*#__PURE__*/ middleware(withLoggerDisabled)).layer;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/socket/SocketServer.js
/**
* @since 4.0.0
*/
/**
* @since 4.0.0
* @category tags
*/
var SocketServer = class extends Service$1()("@effect/platform/SocketServer") {};
TaggedError("SocketServerOpenError");
TaggedError("SocketServerUnknownError");
TaggedError("SocketServerError");
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/workers/WorkerRunner.js
/**
* @since 4.0.0
* @category models
*/
var WorkerRunnerPlatform = class extends Service$1()("effect/workers/WorkerRunner/WorkerRunnerPlatform") {};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcServer.js
var RpcServer_exports = /* @__PURE__ */ __exportAll({
	Protocol: () => Protocol,
	layer: () => layer,
	layerHttp: () => layerHttp,
	layerProtocolHttp: () => layerProtocolHttp,
	layerProtocolSocketServer: () => layerProtocolSocketServer,
	layerProtocolStdio: () => layerProtocolStdio,
	layerProtocolWebsocket: () => layerProtocolWebsocket,
	layerProtocolWorkerRunner: () => layerProtocolWorkerRunner,
	make: () => make,
	makeNoSerialization: () => makeNoSerialization,
	makeProtocolHttp: () => makeProtocolHttp,
	makeProtocolSocketServer: () => makeProtocolSocketServer,
	makeProtocolStdio: () => makeProtocolStdio,
	makeProtocolWebsocket: () => makeProtocolWebsocket,
	makeProtocolWithHttpEffect: () => makeProtocolWithHttpEffect,
	makeProtocolWithHttpEffectWebsocket: () => makeProtocolWithHttpEffectWebsocket,
	makeProtocolWorkerRunner: () => makeProtocolWorkerRunner,
	toHttpEffect: () => toHttpEffect,
	toHttpEffectWebsocket: () => toHttpEffectWebsocket
});
/**
* @since 4.0.0
* @category server
*/
var makeNoSerialization = /*#__PURE__*/ fnUntraced(function* (group, options) {
	const enableTracing = options.disableTracing !== true;
	const enableSpanPropagation = options.disableSpanPropagation !== true;
	const supportsAck = options.disableClientAcks !== true;
	const spanPrefix = options.spanPrefix ?? "RpcServer";
	const concurrency = options.concurrency ?? "unbounded";
	const disableFatalDefects = options.disableFatalDefects ?? false;
	const services$2 = yield* services();
	const scope = get(services$2, Scope);
	const trackFiber = runIn(forkUnsafe(scope, "parallel"));
	const concurrencySemaphore = concurrency === "unbounded" ? void 0 : yield* make$14(concurrency);
	const clients = /* @__PURE__ */ new Map();
	let isShutdown = false;
	const shutdownLatch = makeUnsafe$3(false);
	yield* addFinalizer(scope, withFiber((parent) => {
		isShutdown = true;
		for (const client of clients.values()) {
			client.ended = true;
			if (client.fibers.size === 0) {
				trackFiber(runForkWith(services$2)(endClient(client)));
				continue;
			}
			for (const fiber of client.fibers.values()) fiber.interruptUnsafe(parent.id);
		}
		if (clients.size === 0) return void_;
		return shutdownLatch.await;
	}));
	const disconnect = (clientId) => withFiber((parent) => {
		const client = clients.get(clientId);
		if (!client) return void_;
		for (const fiber of client.fibers.values()) fiber.interruptUnsafe(parent.id);
		clients.delete(clientId);
		return void_;
	});
	const write = (clientId, message) => catchDefect(withFiber((requestFiber) => {
		if (isShutdown) return interrupt$1;
		let client = clients.get(clientId);
		if (!client) {
			client = {
				id: clientId,
				latches: /* @__PURE__ */ new Map(),
				fibers: /* @__PURE__ */ new Map(),
				ended: false
			};
			clients.set(clientId, client);
		} else if (client.ended) return interrupt$1;
		switch (message._tag) {
			case "Request": return handleRequest(requestFiber, client, message);
			case "Ack": {
				const latch = client.latches.get(message.requestId);
				return latch ? latch.open : void_;
			}
			case "Interrupt": {
				const fiber = client.fibers.get(message.requestId);
				if (fiber) {
					fiber.interruptUnsafe(requestFiber.id, ClientAbort$1.annotation);
					return void_;
				}
				return options.onFromServer({
					_tag: "Exit",
					clientId,
					requestId: message.requestId,
					exit: interrupt()
				});
			}
			case "Eof":
				client.ended = true;
				if (client.fibers.size > 0) return void_;
				return endClient(client);
			default: return sendDefect(client, `Unknown request tag: ${message._tag}`);
		}
	}), (defect) => sendDefect(clients.get(clientId), defect));
	const endClient = (client) => {
		clients.delete(client.id);
		const write = options.onFromServer({
			_tag: "ClientEnd",
			clientId: client.id
		});
		if (isShutdown && clients.size === 0) return andThen(write, shutdownLatch.open);
		return write;
	};
	const handleRequest = (requestFiber, client, request) => {
		if (client.fibers.has(request.id)) return interrupt$1;
		const rpc = group.requests.get(request.tag);
		const entry = services$2.mapUnsafe.get(rpc?.key);
		if (!rpc || !entry) {
			const write = catchDefect(options.onFromServer({
				_tag: "Exit",
				clientId: client.id,
				requestId: request.id,
				exit: die(`Unknown request tag: ${request.tag}`)
			}), (defect) => sendDefect(client, defect));
			if (!client.ended || client.fibers.size > 0) return write;
			return ensuring(write, endClient(client));
		}
		const isStream = isStreamSchema(rpc.successSchema);
		const metadata = {
			rpc,
			clientId: client.id,
			requestId: request.id,
			headers: request.headers,
			payload: request.payload
		};
		const result = entry.handler(request.payload, metadata);
		const isWrapper$1 = isWrapper(result);
		const isFork = isWrapper$1 && result.fork;
		const isUninterruptible = isWrapper$1 && result.uninterruptible;
		const streamOrEffect = isWrapper$1 ? result.value : result;
		const handler = isStream ? streamEffect(client, request, streamOrEffect) : streamOrEffect;
		const withMiddleware = rpc.middlewares.size > 0 ? applyMiddleware(services$2, handler, metadata) : handler;
		let responded = false;
		const scope = makeUnsafe$1();
		let effect = onExit(withMiddleware, (exit) => {
			responded = true;
			const close = closeUnsafe(scope, exit);
			const write = exit._tag === "Failure" && !disableFatalDefects && hasDies(exit.cause) && !hasInterrupts$1(exit.cause) ? sendDefect(client, squash(exit.cause)) : options.onFromServer({
				_tag: "Exit",
				clientId: client.id,
				requestId: request.id,
				exit
			});
			if (exit._tag === "Failure") reportCauseUnsafe(getCurrent(), exit.cause);
			return close ? ensuring(write, close) : write;
		});
		if (enableTracing) {
			const parentSpan = requestFiber.services.mapUnsafe.get(ParentSpan.key);
			effect = withSpan(effect, `${spanPrefix}.${request.tag}`, {
				captureStackTrace: false,
				attributes: options.spanAttributes,
				parent: enableSpanPropagation && request.spanId ? externalSpan({
					traceId: request.traceId,
					spanId: request.spanId,
					sampled: request.sampled
				}) : void 0,
				links: enableSpanPropagation && parentSpan ? [{
					span: parentSpan,
					attributes: {}
				}] : void 0
			});
		}
		if (!isFork && concurrencySemaphore) effect = concurrencySemaphore.withPermits(1)(effect);
		const serviceMap = new Map(entry.services.mapUnsafe);
		serviceMap.forEach((value, key) => serviceMap.set(key, value));
		serviceMap.set(Scope.key, scope);
		const runFork = runForkWith(makeUnsafe(serviceMap));
		const fiber = trackFiber(runFork(effect, isUninterruptible ? { uninterruptible: true } : void 0));
		client.fibers.set(request.id, fiber);
		fiber.addObserver((exit) => {
			if (!responded && exit._tag === "Failure") trackFiber(runFork(options.onFromServer({
				_tag: "Exit",
				clientId: client.id,
				requestId: request.id,
				exit: interrupt()
			})));
			client.fibers.delete(request.id);
			client.latches.delete(request.id);
			if (client.ended && client.fibers.size === 0) trackFiber(runFork(endClient(client)));
		});
		return void_;
	};
	const streamEffect = (client, request, stream) => {
		let latch = client.latches.get(request.id);
		if (supportsAck && !latch) {
			latch = makeUnsafe$3(false);
			client.latches.set(request.id, latch);
		}
		if (isEffect(stream)) return stream.pipe(flatMap((queue) => whileLoop({
			while: constTrue,
			body: constant(flatMap(takeAll(queue), (values) => {
				const write = options.onFromServer({
					_tag: "Chunk",
					clientId: client.id,
					requestId: request.id,
					values
				});
				if (!latch) return write;
				latch.closeUnsafe();
				return flatMap(write, () => latch.await);
			})),
			step: constVoid
		})), catchDone(() => void_), scoped);
		return runForEachArray(stream, (values) => {
			const write = options.onFromServer({
				_tag: "Chunk",
				clientId: client.id,
				requestId: request.id,
				values
			});
			if (!latch) return write;
			latch.closeUnsafe();
			return andThen(write, latch.await);
		});
	};
	const sendDefect = (client, defect) => suspend(() => {
		const shouldEnd = client.ended && client.fibers.size === 0;
		const write = options.onFromServer({
			_tag: "Defect",
			clientId: client.id,
			defect
		});
		if (!shouldEnd) return write;
		return andThen(write, endClient(client));
	});
	return identity({
		write,
		disconnect
	});
});
var applyMiddleware = (services, handler, options) => {
	for (const service of options.rpc.middlewares) handler = getUnsafe(services, service)(handler, options);
	return handler;
};
/**
* @since 4.0.0
* @category server
*/
var make = /*#__PURE__*/ fnUntraced(function* (group, options) {
	const { disconnects, end, run, send, supportsAck, supportsSpanPropagation, supportsTransferables } = yield* Protocol;
	const services$1 = yield* services();
	const scope = yield* make$10();
	const server = yield* makeNoSerialization(group, {
		...options,
		disableClientAcks: !supportsAck,
		disableSpanPropagation: !supportsSpanPropagation,
		onFromServer(response) {
			const client = clients.get(response.clientId);
			if (!client) return void_;
			switch (response._tag) {
				case "Chunk": {
					const schemas = client.schemas.get(response.requestId);
					if (!schemas) return void_;
					return handleEncode(client, response.requestId, schemas.encodeDefect, schemas.collector, provideServices(schemas.encodeChunk(response.values), schemas.services), (values) => ({
						_tag: "Chunk",
						requestId: String(response.requestId),
						values
					}));
				}
				case "Exit": {
					const schemas = client.schemas.get(response.requestId);
					if (!schemas) return void_;
					client.schemas.delete(response.requestId);
					return handleEncode(client, response.requestId, schemas.encodeDefect, schemas.collector, provideServices(schemas.encodeExit(response.exit), schemas.services), (exit) => ({
						_tag: "Exit",
						requestId: String(response.requestId),
						exit
					}));
				}
				case "Defect": return sendDefect(client, response.defect);
				case "ClientEnd":
					clients.delete(response.clientId);
					return end(response.clientId);
			}
		}
	}).pipe(provide$2(scope));
	yield* forkChild(whileLoop({
		while: constTrue,
		body: constant(flatMap(take(disconnects), (clientId) => {
			clients.delete(clientId);
			return server.disconnect(clientId);
		})),
		step: constVoid
	}));
	const schemasCache = /* @__PURE__ */ new WeakMap();
	const getSchemas = (rpc) => {
		let schemas = schemasCache.get(rpc);
		if (!schemas) {
			const entry = services$1.mapUnsafe.get(rpc.key);
			const streamSchemas = getStreamSchemas(rpc.successSchema);
			schemas = {
				decode: decodeUnknownEffect(toCodecJson(rpc.payloadSchema)),
				encodeChunk: encodeUnknownEffect(toCodecJson(Array$1(streamSchemas ? streamSchemas.success : Any))),
				encodeExit: encodeUnknownEffect(toCodecJson(exitSchema(rpc))),
				encodeDefect: encodeUnknownEffect(toCodecJson(rpc.defectSchema)),
				services: entry.services
			};
			schemasCache.set(rpc, schemas);
		}
		return schemas;
	};
	const clients = /* @__PURE__ */ new Map();
	const handleEncode = (client, requestId, encodeDefect, collector, effect, onSuccess) => (collector ? provideService(effect, Collector, collector) : effect).pipe(flatMap((a) => send(client.id, onSuccess(a), collector && collector.clearUnsafe())), catchCause((cause) => {
		client.schemas.delete(requestId);
		const defect = squash(map$3(cause, (e) => e.issue.toString()));
		return andThen(sendRequestDefect(client, requestId, encodeDefect, defect), server.write(client.id, {
			_tag: "Interrupt",
			requestId,
			interruptors: []
		}));
	}));
	const sendRequestDefect = (client, requestId, encodeDefect, defect) => catchCause(flatMap(encodeDefect(defect), (encodedDefect) => send(client.id, {
		_tag: "Exit",
		requestId: String(requestId),
		exit: {
			_tag: "Failure",
			cause: [{
				_tag: "Die",
				defect: encodedDefect
			}]
		}
	})), (cause) => sendDefect(client, squash(cause)));
	const sendDefect = (client, defect) => catchCause(send(client.id, ResponseDefectEncoded(defect)), (cause) => annotateLogs(logDebug(cause), {
		module: "RpcServer",
		method: "sendDefect"
	}));
	return yield* run((clientId, request) => {
		let client = clients.get(clientId);
		if (!client) {
			client = {
				id: clientId,
				schemas: /* @__PURE__ */ new Map()
			};
			clients.set(clientId, client);
		}
		switch (request._tag) {
			case "Request": {
				const tag = hasProperty(request, "tag") ? request.tag : "";
				const rpc = group.requests.get(tag);
				if (!rpc) return sendDefect(client, `Unknown request tag: ${tag}`);
				let requestId;
				switch (typeof request.id) {
					case "bigint":
					case "string":
						requestId = RequestId(request.id);
						break;
					default: return sendDefect(client, `Invalid request id: ${request.id}`);
				}
				const schemas = getSchemas(rpc);
				return matchEffect(provideServices(schemas.decode(request.payload), schemas.services), {
					onFailure: (error) => sendRequestDefect(client, requestId, schemas.encodeDefect, error.issue.toString()),
					onSuccess: (payload) => {
						client.schemas.set(requestId, supportsTransferables ? {
							...schemas,
							collector: makeCollectorUnsafe()
						} : schemas);
						return server.write(clientId, {
							...request,
							id: requestId,
							payload,
							headers: fromInput$1(request.headers)
						});
					}
				});
			}
			case "Ping": return catchCause(send(client.id, constPong), (cause) => sendDefect(client, squash(cause)));
			case "Eof": return server.write(clientId, request);
			case "Ack": return server.write(clientId, {
				...request,
				requestId: RequestId(request.requestId)
			});
			case "Interrupt": return server.write(clientId, {
				...request,
				requestId: RequestId(request.requestId),
				interruptors: []
			});
			default: return sendDefect(client, `Unknown request tag: ${request._tag}`);
		}
	}).pipe(tapCause((cause) => logFatal("BUG: RpcServer protocol crashed", cause)), onExit((exit) => close(scope, exit)));
});
/**
* @since 4.0.0
* @category server
*/
var layer = (group, options) => effectDiscard(forkScoped(make(group, options)));
/**
* Create a RPC server that registers a HTTP route with a `HttpRouter`.
*
* It defaults to using websockets for communication, but can be configured to
* use HTTP.
*
* @since 4.0.0
* @category protocol
*/
var layerHttp = (options) => layer(options.group, options).pipe(provide$1(options.protocol === "http" ? layerProtocolHttp(options) : layerProtocolWebsocket(options)));
/**
* @since 4.0.0
* @category protocol
*/
var Protocol = class extends Service$1()("effect/rpc/RpcServer/Protocol") {
	/**
	* @since 4.0.0
	*/
	static make = /*#__PURE__*/ withRun();
};
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolSocketServer = /*#__PURE__*/ gen(function* () {
	const server = yield* SocketServer;
	const { onSocket, protocol } = yield* makeSocketProtocol;
	yield* forkScoped(server.run(fnUntraced(onSocket, scoped)));
	return protocol;
});
/**
* A rpc protocol that uses `SocketServer` for communication.
*
* @since 4.0.0
* @category protocol
*/
var layerProtocolSocketServer = /*#__PURE__*/ effect(Protocol)(makeProtocolSocketServer);
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolWithHttpEffectWebsocket = /*#__PURE__*/ gen(function* () {
	const { onSocket, protocol } = yield* makeSocketProtocol;
	return {
		protocol,
		httpEffect: gen(function* () {
			const request = yield* HttpServerRequest;
			const socket = yield* orDie(request.upgrade);
			yield* onSocket(socket, Object.entries(request.headers));
			return empty();
		})
	};
});
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolWebsocket = /*#__PURE__*/ fnUntraced(function* (options) {
	const { httpEffect, protocol } = yield* makeProtocolWithHttpEffectWebsocket;
	yield* (yield* HttpRouter).add("GET", options.path, httpEffect);
	return protocol;
});
/**
* A rpc protocol that uses websockets for communication.
*
* @since 4.0.0
* @category protocol
*/
var layerProtocolWebsocket = (options) => {
	return effect(Protocol)(makeProtocolWebsocket(options));
};
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolWithHttpEffect = /*#__PURE__*/ gen(function* () {
	const serialization = yield* RpcSerialization;
	const includesFraming = serialization.includesFraming;
	const isBinary = !serialization.contentType.includes("json");
	const disconnects = yield* make$15();
	let writeRequest;
	let clientId = 0;
	const clients = /* @__PURE__ */ new Map();
	const clientIds = /* @__PURE__ */ new Set();
	const encoder = new TextEncoder();
	const httpEffect = gen(function* () {
		const fiber = getCurrent();
		const request = getUnsafe(fiber.services, HttpServerRequest);
		const scope = getUnsafe(fiber.services, Scope);
		const requestHeaders = Object.entries(request.headers);
		const data = yield* orDie(isBinary ? map$1(request.arrayBuffer, (buf) => new Uint8Array(buf)) : request.text);
		const id = clientId++;
		const queue = yield* make$15();
		const parser = serialization.makeUnsafe();
		const offer$1 = (data) => typeof data === "string" ? offer(queue, encoder.encode(data)) : offer(queue, data);
		const client = {
			write: !includesFraming ? (response) => offer(queue, response) : (response) => {
				try {
					const encoded = parser.encode(response);
					if (encoded === void 0) return void_;
					return offer$1(encoded);
				} catch (cause) {
					return offer$1(parser.encode(ResponseDefectEncoded(cause)));
				}
			},
			end: end(queue)
		};
		yield* addFinalizerExit(scope, () => {
			clients.delete(id);
			clientIds.delete(id);
			offerUnsafe(disconnects, id);
			if (queue.state._tag === "Done") return void_;
			return forEach(requestIds, (requestId) => writeRequest(id, {
				_tag: "Interrupt",
				requestId: String(requestId)
			}), { discard: true });
		});
		clients.set(id, client);
		clientIds.add(id);
		const requestIds = [];
		try {
			const decoded = parser.decode(data);
			for (let i = 0; i < decoded.length; i++) {
				const message = decoded[i];
				if (message._tag === "Request") {
					requestIds.push(RequestId(message.id));
					message.headers = requestHeaders.concat(message.headers);
				}
				yield* writeRequest(id, message);
			}
		} catch (cause) {
			yield* client.write(ResponseDefectEncoded(cause));
		}
		yield* writeRequest(id, constEof);
		if (!includesFraming) {
			const responses = yield* collect(queue);
			return text(parser.encode(responses), { contentType: serialization.contentType });
		}
		const initialChunk = yield* takeAll(queue);
		if (queue.state._tag === "Done") return uint8Array(mergeUint8Arrays(initialChunk), { contentType: serialization.contentType });
		return stream(fromArray(initialChunk).pipe(concat(fromQueue(queue))), { contentType: serialization.contentType });
	});
	return {
		protocol: yield* Protocol.make((writeRequest_) => {
			writeRequest = writeRequest_;
			return succeed$1({
				disconnects,
				send(clientId, response) {
					const client = clients.get(clientId);
					if (!client) return void_;
					return client.write(response);
				},
				end(clientId) {
					const client = clients.get(clientId);
					if (!client) return void_;
					return client.end;
				},
				clientIds: sync(() => clientIds),
				initialMessage: succeedNone,
				supportsAck: false,
				supportsTransferables: false,
				supportsSpanPropagation: false
			});
		}),
		httpEffect
	};
});
var mergeUint8Arrays = (arrays) => {
	if (arrays.length === 0) return /* @__PURE__ */ new Uint8Array(0);
	if (arrays.length === 1) return arrays[0];
	const length = arrays.reduce((acc, arr) => acc + arr.length, 0);
	const result = new Uint8Array(length);
	let offset = 0;
	for (const arr of arrays) {
		result.set(arr, offset);
		offset += arr.length;
	}
	return result;
};
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolHttp = /*#__PURE__*/ fnUntraced(function* (options) {
	const { httpEffect, protocol } = yield* makeProtocolWithHttpEffect;
	yield* (yield* HttpRouter).add("POST", options.path, httpEffect);
	return protocol;
});
/**
* A rpc protocol that uses websockets for communication.
*
* @since 4.0.0
* @category protocol
*/
var layerProtocolHttp = (options) => {
	return effect(Protocol)(makeProtocolHttp(options));
};
/**
* @since 4.0.0
* @category http app
*/
var toHttpEffect = /*#__PURE__*/ fnUntraced(function* (group, options) {
	const { httpEffect, protocol } = yield* makeProtocolWithHttpEffect;
	yield* make(group, options).pipe(provideService(Protocol, protocol), forkScoped);
	return httpEffect;
});
/**
* @since 4.0.0
* @category http app
*/
var toHttpEffectWebsocket = /*#__PURE__*/ fnUntraced(function* (group, options) {
	const { httpEffect, protocol } = yield* makeProtocolWithHttpEffectWebsocket;
	yield* make(group, options).pipe(provideService(Protocol, protocol), forkScoped);
	return httpEffect;
});
/**
* Create a protocol that uses the provided `Stream` and `Sink` for communication.
*
* @since 4.0.0
* @category protocol
*/
var makeProtocolStdio = /*#__PURE__*/ gen(function* () {
	const stdio = yield* Stdio;
	const fiber = getCurrent();
	const serialization = yield* RpcSerialization;
	return yield* Protocol.make(fnUntraced(function* (writeRequest) {
		const queue = yield* make$15();
		const parser = serialization.makeUnsafe();
		yield* stdio.stdin.pipe(runForEach((data) => {
			const decoded = parser.decode(data);
			if (decoded.length === 0) return void_;
			let i = 0;
			return whileLoop({
				while: () => i < decoded.length,
				body: () => writeRequest(0, decoded[i++]),
				step: constVoid
			});
		}), sandbox, tapError(logError), retry(spaced(500)), ensuring(forkDetach(interrupt$2(fiber), { startImmediately: true })), forkScoped);
		yield* fromQueue(queue).pipe(run(stdio.stdout), retry(spaced(500)), forkScoped);
		return {
			disconnects: yield* make$15(),
			send(_clientId, response) {
				const responseEncoded = parser.encode(response);
				if (responseEncoded === void 0) return void_;
				return offer(queue, responseEncoded);
			},
			end(_clientId) {
				return end(queue);
			},
			clientIds: succeed$1(/* @__PURE__ */ new Set([0])),
			initialMessage: succeedNone,
			supportsAck: true,
			supportsTransferables: false,
			supportsSpanPropagation: true
		};
	}));
});
/**
* Create a protocol that uses the provided `Stream` and `Sink` for communication.
*
* @since 4.0.0
* @category protocol
*/
var layerProtocolStdio = /*#__PURE__*/ effect(Protocol, makeProtocolStdio);
/**
* @since 4.0.0
* @category protocol
*/
var makeProtocolWorkerRunner = /*#__PURE__*/ Protocol.make(/*#__PURE__*/ fnUntraced(function* (writeRequest) {
	const fiber = getCurrent();
	const backing = yield* (yield* WorkerRunnerPlatform).start();
	const initialMessage = yield* make$11();
	const clientIds = /* @__PURE__ */ new Set();
	const disconnects = yield* make$15();
	yield* backing.run((clientId, message) => {
		clientIds.add(clientId);
		if (message._tag === "InitialMessage") return succeed$2(initialMessage, message.value);
		return writeRequest(clientId, message);
	}).pipe(tapCause(logError), onExit(() => sync(() => {
		fiber.currentScheduler.scheduleTask(() => fiber.interruptUnsafe(fiber.id), 0);
	})), forkScoped);
	if (backing.disconnects) yield* take(backing.disconnects).pipe(tap((clientId) => {
		clientIds.delete(clientId);
		return offer(disconnects, clientId);
	}), forkScoped);
	return {
		disconnects,
		send: backing.send,
		end(_clientId) {
			return void_;
		},
		clientIds: sync(() => clientIds),
		initialMessage: asSome(_await(initialMessage)),
		supportsAck: true,
		supportsTransferables: true,
		supportsSpanPropagation: true
	};
}));
/**
* @since 4.0.0
* @category protocol
*/
var layerProtocolWorkerRunner = /*#__PURE__*/ effect(Protocol)(makeProtocolWorkerRunner);
var makeSocketProtocol = /*#__PURE__*/ gen(function* () {
	const serialization = yield* RpcSerialization;
	const disconnects = yield* make$15();
	let clientId = 0;
	const clients = /* @__PURE__ */ new Map();
	const clientIds = /* @__PURE__ */ new Set();
	let writeRequest;
	const onSocket = function* (socket, headers) {
		const scope$1 = yield* scope;
		const parser = serialization.makeUnsafe();
		const id = clientId++;
		yield* addFinalizerExit(scope$1, () => {
			clients.delete(id);
			clientIds.delete(id);
			return offer(disconnects, id);
		});
		const writeRaw = yield* socket.writer;
		const write = (response) => {
			try {
				const encoded = parser.encode(response);
				if (encoded === void 0) return void_;
				return orDie(writeRaw(encoded));
			} catch (cause) {
				return orDie(writeRaw(parser.encode(ResponseDefectEncoded(cause))));
			}
		};
		clients.set(id, { write });
		clientIds.add(id);
		yield* socket.runRaw((data) => {
			try {
				const decoded = parser.decode(data);
				if (decoded.length === 0) return void_;
				let i = 0;
				return whileLoop({
					while: () => i < decoded.length,
					body() {
						const message = decoded[i++];
						if (message._tag === "Request" && headers) message.headers = headers.concat(message.headers);
						return writeRequest(id, message);
					},
					step: constVoid
				});
			} catch (cause) {
				return writeRaw(parser.encode(ResponseDefectEncoded(cause)));
			}
		}).pipe(catchReason("SocketError", "SocketCloseError", (_) => void_), orDie);
	};
	return {
		protocol: yield* Protocol.make((writeRequest_) => {
			writeRequest = writeRequest_;
			return succeed$1({
				disconnects,
				send: (clientId, response) => {
					const client = clients.get(clientId);
					if (!client) return void_;
					return orDie(client.write(response));
				},
				end(_clientId) {
					return void_;
				},
				clientIds: sync(() => clientIds),
				initialMessage: succeedNone,
				supportsAck: true,
				supportsTransferables: false,
				supportsSpanPropagation: true
			});
		}),
		onSocket
	};
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcTest.js
/**
* @since 4.0.0
*/
var RpcTest_exports = /* @__PURE__ */ __exportAll({ makeClient: () => makeClient });
/**
* @since 4.0.0
* @category constructors
*/
var makeClient = /*#__PURE__*/ fnUntraced(function* (group, options) {
	let client;
	const server = yield* makeNoSerialization(group, { onFromServer(response) {
		return client.write(response);
	} });
	client = yield* makeNoSerialization$1(group, {
		supportsAck: true,
		flatten: options?.flatten,
		onFromClient({ message }) {
			return server.write(0, message);
		}
	});
	return client.client;
});
//#endregion
export { Rpc_exports as Rpc, RpcClient_exports as RpcClient, RpcClientError_exports as RpcClientError, RpcGroup_exports as RpcGroup, RpcMessage_exports as RpcMessage, RpcMiddleware_exports as RpcMiddleware, RpcSchema_exports as RpcSchema, RpcSerialization_exports as RpcSerialization, RpcServer_exports as RpcServer, RpcTest_exports as RpcTest, RpcWorker_exports as RpcWorker, Utils_exports as Utils };
