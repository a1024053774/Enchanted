//#region node_modules/.bun/@xterm+addon-clipboard@0.2.0/node_modules/@xterm/addon-clipboard/lib/addon-clipboard.mjs
/**
* Copyright (c) 2014-2024 The xterm.js authors. All rights reserved.
* @license MIT
*
* Copyright (c) 2012-2013, Christopher Jeffrey (MIT License)
* @license MIT
*
* Originally forked from (with the author's permission):
*   Fabrice Bellard's javascript vt100 for jslinux:
*   http://bellard.org/jslinux/
*   Copyright (c) 2011 Fabrice Bellard
*/
var U = "3.7.8";
var $ = U;
var f = typeof Buffer == "function";
var _ = typeof TextDecoder == "function" ? new TextDecoder() : void 0;
var C = typeof TextEncoder == "function" ? new TextEncoder() : void 0;
var c = Array.prototype.slice.call("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=");
var d = ((e) => {
	let t = {};
	return e.forEach((r, o) => t[r] = o), t;
})(c);
var k = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/;
var n = String.fromCharCode.bind(String);
var B = typeof Uint8Array.from == "function" ? Uint8Array.from.bind(Uint8Array) : (e) => new Uint8Array(Array.prototype.slice.call(e, 0));
var S = (e) => e.replace(/=/g, "").replace(/[+\/]/g, (t) => t == "+" ? "-" : "_");
var I = (e) => e.replace(/[^A-Za-z0-9\+\/]/g, "");
var F = (e) => {
	let t, r, o, i, s = "", l = e.length % 3;
	for (let a = 0; a < e.length;) {
		if ((r = e.charCodeAt(a++)) > 255 || (o = e.charCodeAt(a++)) > 255 || (i = e.charCodeAt(a++)) > 255) throw new TypeError("invalid character found");
		t = r << 16 | o << 8 | i, s += c[t >> 18 & 63] + c[t >> 12 & 63] + c[t >> 6 & 63] + c[t & 63];
	}
	return l ? s.slice(0, l - 3) + "===".substring(l) : s;
};
var m = typeof btoa == "function" ? (e) => btoa(e) : f ? (e) => Buffer.from(e, "binary").toString("base64") : F;
var b = f ? (e) => Buffer.from(e).toString("base64") : (e) => {
	let r = [];
	for (let o = 0, i = e.length; o < i; o += 4096) r.push(n.apply(null, e.subarray(o, o + 4096)));
	return m(r.join(""));
};
var x = (e, t = !1) => t ? S(b(e)) : b(e);
var H = (e) => {
	if (e.length < 2) {
		var t = e.charCodeAt(0);
		return t < 128 ? e : t < 2048 ? n(192 | t >>> 6) + n(128 | t & 63) : n(224 | t >>> 12 & 15) + n(128 | t >>> 6 & 63) + n(128 | t & 63);
	} else {
		var t = 65536 + (e.charCodeAt(0) - 55296) * 1024 + (e.charCodeAt(1) - 56320);
		return n(240 | t >>> 18 & 7) + n(128 | t >>> 12 & 63) + n(128 | t >>> 6 & 63) + n(128 | t & 63);
	}
};
var J = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;
var P = (e) => e.replace(J, H);
var T = f ? (e) => Buffer.from(e, "utf8").toString("base64") : C ? (e) => b(C.encode(e)) : (e) => m(P(e));
var p = (e, t = !1) => t ? S(T(e)) : T(e);
var v = (e) => p(e, !0);
var q = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g;
var G = (e) => {
	switch (e.length) {
		case 4:
			var r = ((7 & e.charCodeAt(0)) << 18 | (63 & e.charCodeAt(1)) << 12 | (63 & e.charCodeAt(2)) << 6 | 63 & e.charCodeAt(3)) - 65536;
			return n((r >>> 10) + 55296) + n((r & 1023) + 56320);
		case 3: return n((15 & e.charCodeAt(0)) << 12 | (63 & e.charCodeAt(1)) << 6 | 63 & e.charCodeAt(2));
		default: return n((31 & e.charCodeAt(0)) << 6 | 63 & e.charCodeAt(1));
	}
};
var D = (e) => e.replace(q, G);
var w = (e) => {
	if (e = e.replace(/\s+/g, ""), !k.test(e)) throw new TypeError("malformed base64.");
	e += "==".slice(2 - (e.length & 3));
	let t, r, o, i = [];
	for (let s = 0; s < e.length;) t = d[e.charAt(s++)] << 18 | d[e.charAt(s++)] << 12 | (r = d[e.charAt(s++)]) << 6 | (o = d[e.charAt(s++)]), r === 64 ? i.push(n(t >> 16 & 255)) : o === 64 ? i.push(n(t >> 16 & 255, t >> 8 & 255)) : i.push(n(t >> 16 & 255, t >> 8 & 255, t & 255));
	return i.join("");
};
var y = typeof atob == "function" ? (e) => atob(I(e)) : f ? (e) => Buffer.from(e, "base64").toString("binary") : w;
var R = f ? (e) => B(Buffer.from(e, "base64")) : (e) => B(y(e).split("").map((t) => t.charCodeAt(0)));
var E = (e) => R(O(e));
var K = f ? (e) => Buffer.from(e, "base64").toString("utf8") : _ ? (e) => _.decode(R(e)) : (e) => D(y(e));
var O = (e) => I(e.replace(/[-_]/g, (t) => t == "-" ? "+" : "/"));
var h = (e) => K(O(e));
var M = (e) => {
	if (typeof e != "string") return !1;
	let t = e.replace(/\s+/g, "").replace(/={0,2}$/, "");
	return !/[^\s0-9a-zA-Z\+/]/.test(t) || !/[^\s0-9a-zA-Z\-_]/.test(t);
};
var z = (e) => ({
	value: e,
	enumerable: !1,
	writable: !0,
	configurable: !0
});
var Z = function() {
	let e = (t, r) => Object.defineProperty(String.prototype, t, z(r));
	e("fromBase64", function() {
		return h(this);
	}), e("toBase64", function(t) {
		return p(this, t);
	}), e("toBase64URI", function() {
		return p(this, !0);
	}), e("toBase64URL", function() {
		return p(this, !0);
	}), e("toUint8Array", function() {
		return E(this);
	});
};
var V = function() {
	let e = (t, r) => Object.defineProperty(Uint8Array.prototype, t, z(r));
	e("toBase64", function(t) {
		return x(this, t);
	}), e("toBase64URI", function() {
		return x(this, !0);
	}), e("toBase64URL", function() {
		return x(this, !0);
	});
};
var Q = () => {
	Z(), V();
};
var u = {
	version: U,
	VERSION: $,
	atob: y,
	atobPolyfill: w,
	btoa: m,
	btoaPolyfill: F,
	fromBase64: h,
	toBase64: p,
	encode: p,
	encodeURI: v,
	encodeURL: v,
	utob: P,
	btou: D,
	decode: h,
	isValid: M,
	fromUint8Array: x,
	toUint8Array: E,
	extendString: Z,
	extendUint8Array: V,
	extendBuiltins: Q
};
var j = class {
	constructor(t = new A(), r = new g()) {
		this._base64 = t;
		this._provider = r;
	}
	activate(t) {
		this._terminal = t, this._disposable = t.parser.registerOscHandler(52, (r) => this._setOrReportClipboard(r));
	}
	dispose() {
		return this._disposable?.dispose();
	}
	_readText(t, r) {
		let o = this._base64.encodeText(r);
		this._terminal?.input(`\x1B]52;${t};${o}\x07`, !1);
	}
	_setOrReportClipboard(t) {
		let r = t.split(";");
		if (r.length < 2) return !0;
		let o = r[0], i = r[1];
		if (i === "?") {
			let a = this._provider.readText(o);
			return a instanceof Promise ? a.then((L) => (this._readText(o, L), !0)) : (this._readText(o, a), !0);
		}
		let s = "";
		try {
			s = this._base64.decodeText(i);
		} catch {}
		let l = this._provider.writeText(o, s);
		return l instanceof Promise ? l.then(() => !0) : !0;
	}
};
var g = class {
	async readText(t) {
		return t !== "c" ? Promise.resolve("") : navigator.clipboard.readText();
	}
	async writeText(t, r) {
		return t !== "c" ? Promise.resolve() : navigator.clipboard.writeText(r);
	}
};
var A = class {
	encodeText(t) {
		return u.encode(t);
	}
	decodeText(t) {
		let r = u.decode(t);
		return !u.isValid(t) || u.encode(r) !== t ? "" : r;
	}
};
//#endregion
export { A as Base64, g as BrowserClipboardProvider, j as ClipboardAddon };
