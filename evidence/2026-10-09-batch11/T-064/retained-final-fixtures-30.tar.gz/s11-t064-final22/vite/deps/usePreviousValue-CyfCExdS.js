import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
//#region node_modules/.bun/@base-ui+utils@0.3.2+0ea9ec2a211d4613/node_modules/@base-ui/utils/usePreviousValue.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Returns a previous value of its argument.
* @param value Current value.
* @returns Previous value, or null if there is no previous value.
*/
function usePreviousValue(value) {
	const [state, setState] = import_react.useState({
		current: value,
		previous: null
	});
	if (!Object.is(value, state.current)) setState({
		current: value,
		previous: state.current
	});
	return state.previous;
}
//#endregion
export { usePreviousValue as t };
