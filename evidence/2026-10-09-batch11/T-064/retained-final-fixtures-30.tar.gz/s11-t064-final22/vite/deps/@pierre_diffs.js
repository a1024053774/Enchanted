import { $ as UNSAFE_CSS_ATTRIBUTE, A as DEFAULT_TOKENIZE_MAX_LENGTH, B as GIT_DIFF_FILE_BREAK_REGEX, C as DEFAULT_CODE_VIEW_FILE_METRICS, D as DEFAULT_RENDER_RANGE, E as DEFAULT_EXPANDED_REGION, F as DIFFS_TAG_NAME, G as INDEX_LINE_METADATA, H as HEADER_METADATA_SLOT_ID, I as EMPTY_RENDER_RANGE, J as MERGE_CONFLICT_SEPARATOR_MARKER_REGEX, K as MERGE_CONFLICT_BASE_MARKER_REGEX, L as FILENAME_HEADER_REGEX, M as DIFFS_DEVELOPMENT_BUILD, N as DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY, O as DEFAULT_SMOOTH_SCROLL_SETTINGS, P as DIFFS_SCROLLBAR_MEASURE_ATTRIBUTE, Q as UNIFIED_DIFF_FILE_BREAK_REGEX, R as FILENAME_HEADER_REGEX_GIT, S as CUSTOM_HEADER_SLOT_ID, T as DEFAULT_COLLAPSED_CONTEXT_THRESHOLD, U as HEADER_PREFIX_SLOT_ID, V as HEADER_FILENAME_SUFFIX_SLOT_ID, W as HUNK_HEADER, X as SPLIT_WITH_NEWLINES, Y as MERGE_CONFLICT_START_MARKER_REGEX, Z as THEME_CSS_ATTRIBUTE, _ as ALTERNATE_FILE_NAMES_GIT, b as COMMIT_METADATA_SPLIT, c as getCustomExtensionsMap, d as replaceCustomExtensions, f as setCustomExtension, g as queueRender, h as dequeueRender, j as DEFAULT_VIRTUAL_FILE_METRICS, k as DEFAULT_THEMES, l as getCustomExtensionsVersion, m as clearRenderQueue, o as getLineAnnotationName, q as MERGE_CONFLICT_END_MARKER_REGEX, s as EXTENSION_TO_FILE_FORMAT, u as getFiletypeFromFileName, v as CODE_VIEW_FOOTER_ATTRIBUTE, w as DEFAULT_CODE_VIEW_LAYOUT, x as CORE_CSS_ATTRIBUTE, y as CODE_VIEW_HEADER_ATTRIBUTE, z as FILE_CONTEXT_BLOB } from "./platform-vkp1Dvjb.js";
import { $ as createUnsafeCSSStyleNode, $t as createGutterGap, A as pushOrJoinSpan, At as preloadHighlighter, B as cloneFileDiffMetadata, Bt as codeToHtml, C as FileDiff, Ct as getThemes, Dt as isHighlighterLoaded, E as DiffHunksRenderer, Et as getSharedHighlighter, F as createNoNewlineElement, Ft as attachResolvedThemes, G as setPreNodeProperties, Gt as AttachedLanguages, H as VirtualizedFile, Ht as cleanUpResolvedLanguages, I as createEmptyRowBuffer, It as themeResolver, J as patchScrollbarGutterSize, Jt as ResolvingLanguages, K as prerenderHTMLIfNecessary, Kt as RegisteredCustomLanguages, L as areDiffRenderOptionsEqual, Lt as AttachedThemes, M as getTotalLineCountFromHunks, Mt as resolveTheme, N as getHunkSeparatorSlotName, Nt as createTheme, O as renderDiffWithHighlighter, Ot as isHighlighterLoading, P as createSeparator, Pt as cleanUpResolvedThemes, Q as getMeasuredScrollbarGutter, Qt as createGutterUtilityElement, R as ScrollSyncManager, Rt as getResolvedOrResolveLanguage, S as VirtualizedFileDiff, St as areThemesAttached, T as areDiffLineAnnotationsEqual, Tt as getHighlighterIfLoaded, U as File, Ut as attachResolvedLanguages, V as areDiffTargetsEqual, Vt as isWorkerContext, W as upsertHostThemeStyle, Wt as areLanguagesAttached, X as wrapThemeCSS, Xt as InteractionManager, Y as wrapCoreCSS, Yt as ResizeManager, Z as wrapUnsafeCSS, Zt as pluckInteractionOptions, _ as CODE_VIEW_DIFF_OPTION_KEYS, _n as areOptionsEqual, _t as getIconForType, a as hasResolvedLanguages, an as findCodeElement, at as FileRenderer, bt as areFileRenderOptionsEqual, c as areVirtualWindowSpecsEqual, cn as parseDiffFromFile, ct as getLineNodes, dn as processPatch, dt as createTransformerWithState, en as createGutterItem, et as createGutterUtilityContentNode, fn as detachString, ft as processLine, g as resolveRegion, gn as areSelectionsEqual, gt as createFileHeaderElement, h as normalizeDiffResolution, hn as createWindowFromScrollPosition, ht as createPreWrapperProperties, i as resolveLanguages, in as createTextNodeElement, it as SVGSpriteSheet, j as isDefaultRenderRange, jt as getResolvedOrResolveTheme, k as createDiffSpanDecoration, kt as isHighlighterNull, l as UnresolvedFile, ln as parsePatchFiles, lt as getHighlighterThemeStyles, m as resolveConflict, mn as cleanLastNewline, mt as createPreElement, n as resolveThemes, nn as createHastElement, nt as arePrePropertiesEqual, o as getResolvedLanguages, on as areFilesEqual, pn as releaseStringDetachBuffer, pt as getHighlighterOptions, q as getOrCreateCodeNode, qt as ResolvedLanguages, r as getResolvedThemes, rn as createIconElement, rt as areLineAnnotationsEqual, s as Virtualizer, sn as prefersReducedMotion, st as renderFileWithHighlighter, t as getSingularPatch, tn as createGutterWrapper, tt as createAnnotationWrapperNode, u as getUnresolvedDiffHunksRendererOptions, un as processFile, ut as formatCSSVariablePrefix, v as CODE_VIEW_FILE_OPTION_KEYS, vn as areThemesEqual, vt as createAnnotationElement, w as areHunkDataEqual, wt as disposeHighlighter, x as VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL, xt as hasResolvedThemes, y as CodeView, yn as areObjectsEqual, yt as areRenderRangesEqual, z as hydratePartialDiff, zt as resolveLanguage } from "./getSingularPatch-BAVc3pWq.js";
import { f as getTokenStyleObject, l as createCssVariablesTheme, m as stringifyTokenStyle, r as DuplicateThemeError } from "./normalizeThemeColors-CKb5-BNW.js";
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/shiki-stream/tokenizer.js
var ShikiStreamTokenizer = class ShikiStreamTokenizer {
	options;
	tokensStable = [];
	tokensUnstable = [];
	lastUnstableCodeChunk = "";
	lastStableGrammarState;
	constructor(options) {
		this.options = options;
	}
	/**
	* Enqueue a chunk of code to the buffer.
	*/
	async enqueue(chunk) {
		const chunkLines = (this.lastUnstableCodeChunk + chunk).split("\n");
		const stable = [];
		let unstable = [];
		const recall = this.tokensUnstable.length;
		chunkLines.forEach((line, i) => {
			const isLastLine = i === chunkLines.length - 1;
			const result = this.options.highlighter.codeToTokens(line, {
				...this.options,
				grammarState: this.lastStableGrammarState
			});
			const tokens = result.tokens[0];
			if (!isLastLine) tokens.push({
				content: "\n",
				offset: 0
			});
			if (!isLastLine) {
				this.lastStableGrammarState = result.grammarState;
				stable.push(...tokens);
			} else {
				unstable = tokens;
				this.lastUnstableCodeChunk = line;
			}
		});
		this.tokensStable.push(...stable);
		this.tokensUnstable = unstable;
		return {
			recall,
			stable,
			unstable
		};
	}
	close() {
		const stable = this.tokensUnstable;
		this.tokensUnstable = [];
		this.lastUnstableCodeChunk = "";
		this.lastStableGrammarState = void 0;
		return { stable };
	}
	clear() {
		this.tokensStable = [];
		this.tokensUnstable = [];
		this.lastUnstableCodeChunk = "";
		this.lastStableGrammarState = void 0;
	}
	clone() {
		const clone = new ShikiStreamTokenizer(this.options);
		clone.lastUnstableCodeChunk = this.lastUnstableCodeChunk;
		clone.tokensUnstable = this.tokensUnstable;
		clone.tokensStable = this.tokensStable;
		clone.lastStableGrammarState = this.lastStableGrammarState;
		return clone;
	}
};
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/shiki-stream/stream.js
/**
* Create a transform stream that takes code chunks and emits themed tokens.
*/
var CodeToTokenTransformStream = class extends TransformStream {
	tokenizer;
	options;
	constructor(options) {
		const tokenizer = new ShikiStreamTokenizer(options);
		const { allowRecalls = false } = options;
		super({
			async transform(chunk, controller) {
				const { stable, unstable: buffer, recall } = await tokenizer.enqueue(chunk);
				if (allowRecalls && recall > 0) controller.enqueue({ recall });
				for (const token of stable) controller.enqueue(token);
				if (allowRecalls) for (const token of buffer) controller.enqueue(token);
			},
			async flush(controller) {
				const { stable } = tokenizer.close();
				if (!allowRecalls) for (const token of stable) controller.enqueue(token);
			}
		});
		this.tokenizer = tokenizer;
		this.options = options;
	}
};
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createSpanNodeFromToken.js
function createSpanFromToken(token) {
	const element = document.createElement("span");
	element.style = stringifyTokenStyle(token.htmlStyle ?? getTokenStyleObject(token));
	element.textContent = token.content;
	return element;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/components/FileStream.js
var instanceId = -1;
var FileStream = class {
	options;
	__id = `file-stream:${++instanceId}`;
	highlighter;
	stream;
	abortController;
	fileContainer;
	pre;
	code;
	gutterElement;
	contentElement;
	themeCSSStyle;
	appliedThemeCSS;
	currentRowCount = 0;
	constructor(options = { theme: DEFAULT_THEMES }) {
		this.options = options;
		this.currentLineIndex = this.options.startingLineIndex ?? 1;
	}
	cleanUp() {
		dequeueRender(this.render);
		this.abortController?.abort();
		this.abortController = void 0;
	}
	setThemeType(themeType) {
		if ((this.options.themeType ?? "system") === themeType) return;
		this.options = {
			...this.options,
			themeType
		};
		if (typeof this.options.theme === "string" || this.fileContainer == null || this.appliedThemeCSS == null) return;
		this.applyThemeState(this.fileContainer, this.appliedThemeCSS.themeStyles, themeType, this.appliedThemeCSS.baseThemeType);
	}
	async initializeHighlighter() {
		this.highlighter = await getSharedHighlighter(getHighlighterOptions(this.options.lang, this.options));
		return this.highlighter;
	}
	queuedSetupArgs;
	async setup(_source, _wrapper) {
		const isSettingUp = this.queuedSetupArgs != null;
		this.queuedSetupArgs = [_source, _wrapper];
		if (isSettingUp) return;
		this.highlighter ??= await this.initializeHighlighter();
		const [source, wrapper] = this.queuedSetupArgs;
		this.queuedSetupArgs = void 0;
		const stream = source;
		this.setupStream(stream, wrapper, this.highlighter);
	}
	setupStream(stream, wrapper, highlighter) {
		const { disableLineNumbers = false, overflow = "scroll", theme = DEFAULT_THEMES, themeType = "system" } = this.options;
		const fileContainer = this.getOrCreateFileContainer();
		if (fileContainer.parentElement == null) wrapper.appendChild(fileContainer);
		this.pre ??= document.createElement("pre");
		if (this.pre.parentElement == null) fileContainer.shadowRoot?.appendChild(this.pre);
		const baseThemeType = typeof theme === "string" ? highlighter.getTheme(theme).type : void 0;
		const themeStyles = getHighlighterThemeStyles({
			theme,
			highlighter
		});
		this.applyThemeState(fileContainer, themeStyles, themeType, baseThemeType);
		const pre = setPreNodeProperties(this.pre, {
			type: "file",
			diffIndicators: "none",
			disableBackground: true,
			disableLineNumbers,
			overflow,
			split: false,
			totalLines: 0
		});
		pre.textContent = "";
		this.pre = pre;
		this.code = getOrCreateCodeNode({
			code: this.code,
			pre
		});
		this.gutterElement = void 0;
		this.contentElement = void 0;
		this.currentRowCount = 0;
		this.currentLineElement = void 0;
		this.currentLineIndex = this.options.startingLineIndex ?? 1;
		this.abortController?.abort();
		this.abortController = new AbortController();
		const { onStreamStart, onStreamClose, onStreamAbort } = this.options;
		this.stream?.cancel().catch(() => {});
		this.stream = stream;
		this.stream.pipeThrough(typeof theme === "string" ? new CodeToTokenTransformStream({
			...this.options,
			theme,
			highlighter,
			allowRecalls: true,
			defaultColor: false,
			cssVariablePrefix: formatCSSVariablePrefix("token"),
			tokenizeTimeLimit: 0
		}) : new CodeToTokenTransformStream({
			...this.options,
			themes: theme,
			highlighter,
			allowRecalls: true,
			defaultColor: false,
			cssVariablePrefix: formatCSSVariablePrefix("token"),
			tokenizeTimeLimit: 0
		})).pipeTo(new WritableStream({
			start(controller) {
				onStreamStart?.(controller);
			},
			close() {
				onStreamClose?.();
			},
			abort(reason) {
				onStreamAbort?.(reason);
			},
			write: this.handleWrite
		}), { signal: this.abortController.signal }).catch((error) => {
			if (error.name !== "AbortError") console.error("FileStream pipe error:", error);
		});
	}
	queuedTokens = [];
	handleWrite = (token) => {
		if ("recall" in token && this.queuedTokens.length >= token.recall) this.queuedTokens.length = this.queuedTokens.length - token.recall;
		else this.queuedTokens.push(token);
		queueRender(this.render);
		this.options.onStreamWrite?.(token);
	};
	currentLineIndex;
	currentLineElement;
	render = () => {
		this.options.onPreRender?.(this);
		const { gutter, content } = this.getOrCreateStreamColumns();
		const gutterFragment = document.createDocumentFragment();
		const contentFragment = document.createDocumentFragment();
		for (const token of this.queuedTokens) if ("recall" in token) {
			if (this.currentLineElement == null) throw new Error("FileStream.render: no current line element, shouldnt be possible to get here");
			if (token.recall > this.currentLineElement.childNodes.length) throw new Error(`FileStream.render: Token recall exceed the current line, there's probably a bug...`);
			for (let i = 0; i < token.recall; i++) this.currentLineElement.lastChild?.remove();
		} else {
			const span = createSpanFromToken(token);
			if (this.currentLineElement == null) {
				const { gutterLine, contentLine } = this.createLine();
				gutterFragment.appendChild(gutterLine);
				contentFragment.appendChild(contentLine);
			}
			this.currentLineElement?.appendChild(span);
			if (token.content === "\n") {
				this.currentLineIndex++;
				const { gutterLine, contentLine } = this.createLine();
				gutterFragment.appendChild(gutterLine);
				contentFragment.appendChild(contentLine);
			}
		}
		if (gutterFragment.childNodes.length > 0) gutter.appendChild(gutterFragment);
		if (contentFragment.childNodes.length > 0) content.appendChild(contentFragment);
		this.queuedTokens.length = 0;
		this.options.onPostRender?.(this);
	};
	getOrCreateStreamColumns() {
		if (this.code == null) throw new Error("FileStream: expected code element to exist");
		if (this.gutterElement != null && this.contentElement != null) return {
			gutter: this.gutterElement,
			content: this.contentElement
		};
		const gutter = document.createElement("div");
		gutter.dataset.gutter = "";
		const content = document.createElement("div");
		content.dataset.content = "";
		this.code.appendChild(gutter);
		this.code.appendChild(content);
		this.gutterElement = gutter;
		this.contentElement = content;
		return {
			gutter,
			content
		};
	}
	updateRowSpan() {
		if (this.gutterElement != null) this.gutterElement.style.gridRow = `span ${this.currentRowCount}`;
		if (this.contentElement != null) this.contentElement.style.gridRow = `span ${this.currentRowCount}`;
	}
	createLine() {
		const lineNumber = this.currentLineIndex;
		const lineIndex = `${lineNumber - 1}`;
		const gutterLine = document.createElement("div");
		gutterLine.dataset.columnNumber = `${lineNumber}`;
		gutterLine.dataset.lineType = "context";
		gutterLine.dataset.lineIndex = lineIndex;
		const numberContent = document.createElement("span");
		numberContent.dataset.lineNumberContent = "";
		numberContent.textContent = `${lineNumber}`;
		gutterLine.appendChild(numberContent);
		const contentLine = document.createElement("div");
		contentLine.dataset.line = `${lineNumber}`;
		contentLine.dataset.lineType = "context";
		contentLine.dataset.lineIndex = lineIndex;
		this.currentRowCount += 1;
		this.updateRowSpan();
		this.currentLineElement = contentLine;
		return {
			gutterLine,
			contentLine
		};
	}
	getOrCreateFileContainer(fileContainer) {
		if (fileContainer != null && fileContainer === this.fileContainer || fileContainer == null && this.fileContainer != null) return this.fileContainer;
		if (this.fileContainer != null && fileContainer != null && fileContainer !== this.fileContainer) {
			this.themeCSSStyle = void 0;
			this.appliedThemeCSS = void 0;
		}
		this.fileContainer = fileContainer ?? document.createElement("diffs-container");
		return this.fileContainer;
	}
	applyThemeState(container, themeStyles, themeType, baseThemeType) {
		const shadowRoot = container.shadowRoot ?? container.attachShadow({ mode: "open" });
		const effectiveThemeType = baseThemeType ?? themeType;
		const currentTheme = this.options.theme ?? DEFAULT_THEMES;
		const theme = typeof currentTheme === "string" ? currentTheme : { ...currentTheme };
		const scrollbarGutter = getMeasuredScrollbarGutter(shadowRoot);
		if (this.themeCSSStyle?.parentNode === shadowRoot && this.appliedThemeCSS?.themeStyles === themeStyles && this.appliedThemeCSS.themeType === effectiveThemeType && this.appliedThemeCSS.scrollbarGutter === scrollbarGutter) {
			this.appliedThemeCSS.theme = theme;
			return;
		}
		this.themeCSSStyle = upsertHostThemeStyle({
			shadowRoot,
			currentNode: this.themeCSSStyle,
			themeCSS: wrapThemeCSS(themeStyles, effectiveThemeType, scrollbarGutter)
		});
		this.appliedThemeCSS = this.themeCSSStyle != null ? {
			theme,
			themeStyles,
			themeType: effectiveThemeType,
			baseThemeType,
			scrollbarGutter
		} : void 0;
	}
};
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/languages/registerCustomLanguage.js
/**
* Register a custom language loader and optionally map it to
* file names or extensions.
*/
function registerCustomLanguage(lang, loader, extensionsOrFilenames = []) {
	if (lang === "text" || lang === "ansi") throw new Error("registerCustomLanguage: 'text' and 'ansi' are reserved language names");
	if (RegisteredCustomLanguages.has(lang)) {
		console.error(`registerCustomLanguage: lang: ${lang} is already registered`);
		return;
	}
	RegisteredCustomLanguages.set(lang, loader);
	for (const extension of extensionsOrFilenames) setCustomExtension(extension, lang);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/registerCustomTheme.js
function registerCustomTheme(themeName, loader) {
	try {
		const descriptor = createTheme({
			name: themeName,
			load: loader
		});
		themeResolver.registerTheme(descriptor.name, descriptor.load);
	} catch (error) {
		if (error instanceof DuplicateThemeError) {
			console.error("SharedHighlight.registerCustomTheme: theme name already registered", themeName);
			return;
		}
		throw error;
	}
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/highlighter/themes/registerCustomCSSVariableTheme.js
function registerCustomCSSVariableTheme(name, variableDefaults, fontStyle = false) {
	const theme = createCssVariablesTheme({
		name,
		variablePrefix: formatCSSVariablePrefix("global"),
		variableDefaults,
		fontStyle
	});
	registerCustomTheme(name, () => Promise.resolve(theme));
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/annotationHelpers.js
/** Narrow an annotation to the side-tagged diff shape. */
function isDiffAnnotation(annotation) {
	return "side" in annotation;
}
/** Narrow an annotation to the side-less file shape. */
function isFileAnnotation(annotation) {
	return !isDiffAnnotation(annotation);
}
/**
* Narrow a homogeneous editor annotation collection to diff annotations.
* Empty collections return true because they are valid for either shape.
*/
function isDiffAnnotationCollection(annotations) {
	const first = annotations[0];
	return first == null || isDiffAnnotation(first);
}
/**
* Narrow a homogeneous editor annotation collection to file annotations.
* Empty collections return true because they are valid for either shape.
*/
function isFileAnnotationCollection(annotations) {
	const first = annotations[0];
	return first == null || isFileAnnotation(first);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/areWorkerStatsEqual.js
function areWorkerStatsEqual(statsA, statsB) {
	if (statsA == null || statsB == null) return statsA === statsB;
	return statsA.busyWorkers === statsB.busyWorkers && statsA.diffCacheSize === statsB.diffCacheSize && statsA.fileCacheSize === statsB.fileCacheSize && statsA.managerState === statsB.managerState && statsA.activeTasks === statsB.activeTasks && statsA.queuedTasks === statsB.queuedTasks && statsA.themeSubscribers === statsB.themeSubscribers && statsA.totalWorkers === statsB.totalWorkers && statsA.workersFailed === statsB.workersFailed;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createRowNodes.js
function createRowNodes(line) {
	const row = document.createElement("div");
	row.dataset.line = `${line}`;
	const lineColumn = document.createElement("div");
	lineColumn.dataset.columnNumber = "";
	lineColumn.textContent = `${line}`;
	const content = document.createElement("div");
	content.dataset.columnContent = "";
	row.appendChild(lineColumn);
	row.appendChild(content);
	return {
		row,
		content
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/createStyleElement.js
function createStyleElement(content, isCoreCSS = false) {
	return createHastElement({
		tagName: "style",
		children: [createTextNodeElement(isCoreCSS ? wrapCoreCSS(content) : wrapUnsafeCSS(content))],
		properties: {
			[CORE_CSS_ATTRIBUTE]: isCoreCSS ? "" : void 0,
			[UNSAFE_CSS_ATTRIBUTE]: !isCoreCSS ? "" : void 0
		}
	});
}
function createThemeStyleElement(content) {
	return createHastElement({
		tagName: "style",
		children: [createTextNodeElement(content)],
		properties: { [THEME_CSS_ATTRIBUTE]: "" }
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/diffAcceptRejectHunk.js
function diffAcceptRejectHunk(diff, hunkIndex, options) {
	const hunk = diff.hunks[hunkIndex];
	if (hunk == null) {
		console.error({
			hunkIndex,
			diff
		});
		throw new Error("diffAcceptRejectHunk: Invalid hunk index");
	}
	return resolveRegion(diff, {
		resolution: normalizeDiffResolution(options),
		hunkIndex,
		...(() => {
			if (typeof options === "object") return {
				startContentIndex: options.changeIndex,
				endContentIndex: options.changeIndex
			};
			return {
				startContentIndex: 0,
				endContentIndex: Math.max(0, (hunk.hunkContent.length ?? 1) - 1)
			};
		})()
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getLineEndingType.js
function getLineEndingType(content) {
	if (content.includes("\r\n")) return "CRLF";
	if (content.includes("\r")) return "CR";
	if (content.includes("\n")) return "LF";
	return "none";
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/parseLineType.js
function parseLineType(line) {
	const firstChar = line[0];
	if (firstChar !== "+" && firstChar !== "-" && firstChar !== " " && firstChar !== "\\") {
		console.error(`parseLineType: Invalid firstChar: "${firstChar}", full line: "${line}"`);
		return;
	}
	const processedLine = line.substring(1);
	return {
		line: processedLine === "" ? "\n" : processedLine,
		type: firstChar === " " ? "context" : firstChar === "\\" ? "metadata" : firstChar === "+" ? "addition" : "deletion"
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/setLanguageOverride.js
function setLanguageOverride(fileOrDiff, lang) {
	return {
		...fileOrDiff,
		lang
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/trimPatchContext.js
/**
* A utility function to trim out excess context lines from a patch file.  It
* will maintain line numbers, and properly update the hunk context markers, as
* well as be able to create new hunks where necessary if there's excessive
* context between changes
*/
function trimPatchContext(patch, contextSize = 10) {
	const lines = [];
	let currentHunk;
	for (const line of patch.split("\n")) {
		const parsedHunkHeader = line.match(HUNK_HEADER);
		if (parsedHunkHeader != null) {
			if (currentHunk != null) {
				if (currentHunk.hunkLines.length > 0) {
					flushContextLines(currentHunk, contextSize, "trailing");
					flushHunk(currentHunk, lines);
				}
				currentHunk = void 0;
			}
			const additionStart = parseInt(parsedHunkHeader[3]);
			const deletionStart = parseInt(parsedHunkHeader[1]);
			const additionCount = parseInt(parsedHunkHeader[4] ?? "1");
			const deletionCount = parseInt(parsedHunkHeader[2] ?? "1");
			if (isNaN(additionStart) || isNaN(deletionStart) || isNaN(additionCount) || isNaN(deletionCount)) lines.push(line);
			else currentHunk = {
				additionStart,
				deletionStart,
				additionCount: 0,
				deletionCount: 0,
				hunkLines: [],
				contextLines: []
			};
			continue;
		}
		if (currentHunk == null) {
			lines.push(line);
			continue;
		}
		if (line.startsWith(" ")) currentHunk.contextLines.push(line);
		else if (line !== "") {
			if (currentHunk.hunkLines.length > 0 && currentHunk.contextLines.length > contextSize * 2) {
				const omittedContextLineCount = currentHunk.contextLines.length - contextSize * 2;
				const nextContextLines = currentHunk.contextLines.slice(-contextSize);
				flushContextLines(currentHunk, contextSize, "trailing");
				const { additionCount: emittedAdditionCount, deletionCount: emittedDeletionCount } = currentHunk;
				flushHunk(currentHunk, lines);
				currentHunk = {
					additionStart: currentHunk.additionStart + emittedAdditionCount + omittedContextLineCount,
					deletionStart: currentHunk.deletionStart + emittedDeletionCount + omittedContextLineCount,
					deletionCount: 0,
					additionCount: 0,
					contextLines: nextContextLines,
					hunkLines: []
				};
			}
			flushContextLines(currentHunk, contextSize, currentHunk.hunkLines.length === 0 ? "leading" : "before-change");
			currentHunk.hunkLines.push(line);
			if (line.startsWith("+")) currentHunk.additionCount += 1;
			else if (line.startsWith("-")) currentHunk.deletionCount += 1;
		}
	}
	if (currentHunk != null && currentHunk.hunkLines.length > 0) {
		flushContextLines(currentHunk, contextSize, "trailing");
		flushHunk(currentHunk, lines);
	}
	const result = lines.join("\n");
	return patch.endsWith("\n") ? `${result}\n` : result;
}
function flushContextLines(hunk, contextSize, mode) {
	if (mode === "leading" && hunk.contextLines.length > contextSize) {
		const difference = hunk.contextLines.length - contextSize;
		hunk.contextLines.splice(0, difference);
		hunk.additionStart += difference;
		hunk.deletionStart += difference;
	}
	if (mode === "trailing" && hunk.contextLines.length > contextSize) hunk.contextLines.length = contextSize;
	if (hunk.contextLines.length > 0) {
		hunk.hunkLines.push(...hunk.contextLines);
		hunk.additionCount += hunk.contextLines.length;
		hunk.deletionCount += hunk.contextLines.length;
		hunk.contextLines.length = 0;
	}
	return hunk;
}
function flushHunk(hunk, lines) {
	lines.push(`@@ -${formatHunkRange(hunk.deletionStart, hunk.deletionCount)} +${formatHunkRange(hunk.additionStart, hunk.additionCount)} @@`);
	lines.push(...hunk.hunkLines);
}
function formatHunkRange(start, count) {
	return count === 1 ? `${start}` : `${start},${count}`;
}
//#endregion
export { ALTERNATE_FILE_NAMES_GIT, AttachedLanguages, AttachedThemes, CODE_VIEW_DIFF_OPTION_KEYS, CODE_VIEW_FILE_OPTION_KEYS, CODE_VIEW_FOOTER_ATTRIBUTE, CODE_VIEW_HEADER_ATTRIBUTE, COMMIT_METADATA_SPLIT, CORE_CSS_ATTRIBUTE, CUSTOM_HEADER_SLOT_ID, CodeToTokenTransformStream, CodeView, DEFAULT_CODE_VIEW_FILE_METRICS, DEFAULT_CODE_VIEW_LAYOUT, DEFAULT_COLLAPSED_CONTEXT_THRESHOLD, DEFAULT_EXPANDED_REGION, DEFAULT_RENDER_RANGE, DEFAULT_SMOOTH_SCROLL_SETTINGS, DEFAULT_THEMES, DEFAULT_TOKENIZE_MAX_LENGTH, DEFAULT_VIRTUAL_FILE_METRICS, DIFFS_DEVELOPMENT_BUILD, DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY, DIFFS_SCROLLBAR_MEASURE_ATTRIBUTE, DIFFS_TAG_NAME, DiffHunksRenderer, EMPTY_RENDER_RANGE, EXTENSION_TO_FILE_FORMAT, FILENAME_HEADER_REGEX, FILENAME_HEADER_REGEX_GIT, FILE_CONTEXT_BLOB, File, FileDiff, FileRenderer, FileStream, GIT_DIFF_FILE_BREAK_REGEX, HEADER_FILENAME_SUFFIX_SLOT_ID, HEADER_METADATA_SLOT_ID, HEADER_PREFIX_SLOT_ID, HUNK_HEADER, INDEX_LINE_METADATA, InteractionManager, MERGE_CONFLICT_BASE_MARKER_REGEX, MERGE_CONFLICT_END_MARKER_REGEX, MERGE_CONFLICT_SEPARATOR_MARKER_REGEX, MERGE_CONFLICT_START_MARKER_REGEX, RegisteredCustomLanguages, ResizeManager, ResolvedLanguages, ResolvingLanguages, SPLIT_WITH_NEWLINES, SVGSpriteSheet, ScrollSyncManager, ShikiStreamTokenizer, THEME_CSS_ATTRIBUTE, UNIFIED_DIFF_FILE_BREAK_REGEX, UNSAFE_CSS_ATTRIBUTE, UnresolvedFile, VIRTUALIZED_FILE_DIFF_LAYOUT_CHECKPOINT_INTERVAL, VirtualizedFile, VirtualizedFileDiff, Virtualizer, areDiffLineAnnotationsEqual, areDiffRenderOptionsEqual, areDiffTargetsEqual, areFileRenderOptionsEqual, areFilesEqual, areHunkDataEqual, areLanguagesAttached, areLineAnnotationsEqual, areObjectsEqual, areOptionsEqual, arePrePropertiesEqual, areRenderRangesEqual, areSelectionsEqual, areThemesAttached, areThemesEqual, areVirtualWindowSpecsEqual, areWorkerStatsEqual, attachResolvedLanguages, attachResolvedThemes, cleanLastNewline, cleanUpResolvedLanguages, cleanUpResolvedThemes, clearRenderQueue, cloneFileDiffMetadata, codeToHtml, createAnnotationElement, createAnnotationWrapperNode, createCssVariablesTheme as createCSSVariablesTheme, createDiffSpanDecoration, createEmptyRowBuffer, createFileHeaderElement, createGutterGap, createGutterItem, createGutterUtilityContentNode, createGutterUtilityElement, createGutterWrapper, createHastElement, createIconElement, createNoNewlineElement, createPreElement, createPreWrapperProperties, createRowNodes, createSeparator, createSpanFromToken, createStyleElement, createTextNodeElement, createThemeStyleElement, createTransformerWithState, createUnsafeCSSStyleNode, createWindowFromScrollPosition, dequeueRender, detachString, diffAcceptRejectHunk, disposeHighlighter, findCodeElement, formatCSSVariablePrefix, getCustomExtensionsMap, getCustomExtensionsVersion, getFiletypeFromFileName, getHighlighterIfLoaded, getHighlighterOptions, getHighlighterThemeStyles, getHunkSeparatorSlotName, getIconForType, getLineAnnotationName, getLineEndingType, getLineNodes, getOrCreateCodeNode, getResolvedLanguages, getResolvedOrResolveLanguage, getResolvedOrResolveTheme, getResolvedThemes, getSharedHighlighter, getSingularPatch, getThemes, getTotalLineCountFromHunks, getUnresolvedDiffHunksRendererOptions, hasResolvedLanguages, hasResolvedThemes, hydratePartialDiff, isDefaultRenderRange, isDiffAnnotation, isDiffAnnotationCollection, isFileAnnotation, isFileAnnotationCollection, isHighlighterLoaded, isHighlighterLoading, isHighlighterNull, isWorkerContext, parseDiffFromFile, parseLineType, parsePatchFiles, patchScrollbarGutterSize, pluckInteractionOptions, prefersReducedMotion, preloadHighlighter, prerenderHTMLIfNecessary, processFile, processLine, processPatch, pushOrJoinSpan, queueRender, registerCustomCSSVariableTheme, registerCustomLanguage, registerCustomTheme, releaseStringDetachBuffer, renderDiffWithHighlighter, renderFileWithHighlighter, replaceCustomExtensions, resolveConflict, resolveLanguage, resolveLanguages, resolveRegion, resolveTheme, resolveThemes, setCustomExtension, setLanguageOverride, setPreNodeProperties, trimPatchContext, wrapCoreCSS, wrapThemeCSS, wrapUnsafeCSS };
