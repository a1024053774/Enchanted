import { i as __toESM, n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { t as require_react_dom } from "./react-dom.js";
import { r as SafeReact } from "./useId-Cfrl5XdH.js";
import { ht as stopEvent, u as useStore } from "./inertValue-C-bH78NQ.js";
import { s as EMPTY_OBJECT, t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { _ as listNavigation, b as pointer, g as keyboard, i as chipRemovePress, t as createChangeEventDetails, v as none } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { n as transitionStatusMapping, r as useOpenChangeComplete } from "./stateAttributesMapping-DKWbKMwM.js";
import { t as useTransitionStatus } from "./useTransitionStatus-DmfddCng.js";
import { t as error } from "./error-scG2ld3p.js";
import { t as useButton } from "./useButton-vy-VFWTJ.js";
import { a as resolveSelectedLabel, i as resolveMultipleLabels, t as ListboxSeparator, u as findItemIndex } from "./ListboxSeparator-BERMPiEO.js";
import { C as ComboboxTrigger, D as useComboboxFilter, E as AriaCombobox, S as useComboboxChipsContext, T as getIndexAfterChipRemoval, _ as ComboboxIcon, a as useComboboxItemContext, b as ComboboxInput, c as ComboboxArrow, d as ComboboxBackdrop, f as ComboboxPortal, g as ComboboxClear, h as ComboboxCollection, i as ComboboxItem, j as useComboboxRootContext, k as selectors, l as ComboboxPopup, m as ComboboxList, n as ComboboxEmpty, o as ComboboxGroupLabel, p as ComboboxStatus, r as ComboboxRow, s as ComboboxGroup, t as useFilteredItems, u as ComboboxPositioner, v as ComboboxInputGroup, w as getChipNavigationKeys, x as ComboboxChipsContext, y as handleInputPress } from "./useFilteredItems-CKyPw-BX.js";
import { s as useFieldRootContext, u as fieldValidityMapping } from "./LabelableContext-CdYnDOEr.js";
import { t as getDefaultLabelId } from "./resolveAriaLabelledBy-D9b8XvNL.js";
import { t as useDirection } from "./DirectionContext-DRel_lZA.js";
import { t as useCompositeListItem } from "./useCompositeListItem-BYy-x-0E.js";
import { t as CompositeList } from "./CompositeList-BS4gmjlB.js";
import { n as useLabel } from "./useLabel-C0H9kumO.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/root/ComboboxRoot.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function ComboboxRoot(props) {
	const { multiple = false, defaultValue, value, onValueChange, autoComplete, ...other } = props;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(AriaCombobox, {
		...other,
		selectionMode: multiple ? "multiple" : "single",
		selectedValue: value,
		defaultSelectedValue: defaultValue,
		onSelectedValueChange: onValueChange,
		formAutoComplete: autoComplete
	});
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/label/ComboboxLabel.mjs
/**
* An accessible label that is automatically associated with the combobox trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxLabel = /*#__PURE__*/ import_react.forwardRef(function ComboboxLabel(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const elementPropsWithoutId = elementProps;
	delete elementPropsWithoutId.id;
	const fieldRootContext = useFieldRootContext();
	const store = useComboboxRootContext();
	const inputInsidePopup = useStore(store, selectors.inputInsidePopup);
	const triggerElement = useStore(store, selectors.triggerElement);
	const inputElement = useStore(store, selectors.inputElement);
	const rootId = useStore(store, selectors.id);
	const defaultLabelId = getDefaultLabelId(rootId);
	const localControlId = triggerElement?.id ?? (inputInsidePopup ? rootId : void 0);
	import_react.useEffect(() => {
		if (!inputElement || inputInsidePopup) return;
		error(`<Combobox.Label> labels <Combobox.Trigger> only. When <Combobox.Input> is the form control, use a native <label> or <Field.Label> instead.${SafeReact.captureOwnerStack?.() || ""}`);
	}, [inputElement, inputInsidePopup]);
	const labelProps = useLabel({
		id: defaultLabelId,
		fallbackControlId: localControlId,
		setLabelId(nextLabelId) {
			const resolvedLabelId = typeof nextLabelId === "function" ? nextLabelId(store.state.labelId) : nextLabelId;
			store.set("labelId", resolvedLabelId);
		}
	});
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		state: fieldRootContext.state,
		props: [labelProps, elementProps],
		stateAttributesMapping: fieldValidityMapping
	});
});
ComboboxLabel.displayName = "ComboboxLabel";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/value/ComboboxValue.mjs
/**
* The current value of the combobox.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
function ComboboxValue(props) {
	const { children: childrenProp, placeholder } = props;
	const store = useComboboxRootContext();
	const itemToStringLabel = useStore(store, selectors.itemToStringLabel);
	const selectedValue = useStore(store, selectors.selectedValue);
	const items = useStore(store, selectors.items);
	const multiple = useStore(store, selectors.selectionMode) === "multiple";
	const hasSelectedValue = useStore(store, selectors.hasSelectedValue);
	const shouldCheckNullItemLabel = !hasSelectedValue && placeholder != null && childrenProp == null;
	const hasNullLabel = useStore(store, selectors.hasNullItemLabel, shouldCheckNullItemLabel);
	let children = null;
	if (typeof childrenProp === "function") children = childrenProp(selectedValue);
	else if (childrenProp != null) children = childrenProp;
	else if (!hasSelectedValue && placeholder != null && !hasNullLabel) children = placeholder;
	else if (multiple && Array.isArray(selectedValue)) children = resolveMultipleLabels(selectedValue, items, itemToStringLabel);
	else children = resolveSelectedLabel(selectedValue, items, itemToStringLabel);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children });
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/item-indicator/ComboboxItemIndicator.mjs
/**
* Indicates whether the item is selected.
* Renders a `<span>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxItemIndicator = /*#__PURE__*/ import_react.forwardRef(function ComboboxItemIndicator(componentProps, forwardedRef) {
	const { selected } = useComboboxItemContext();
	if (!(componentProps.keepMounted || selected)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Inner, {
		...componentProps,
		ref: forwardedRef
	});
});
ComboboxItemIndicator.displayName = "ComboboxItemIndicator";
var Inner = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef((componentProps, forwardedRef) => {
	const { render, className, style, keepMounted, ...elementProps } = componentProps;
	const { selected } = useComboboxItemContext();
	const indicatorRef = import_react.useRef(null);
	const { transitionStatus, setMounted } = useTransitionStatus(selected);
	const element = useRenderElement("span", componentProps, {
		ref: [forwardedRef, indicatorRef],
		state: {
			selected,
			transitionStatus
		},
		props: [{
			"aria-hidden": true,
			children: "✔️"
		}, elementProps],
		stateAttributesMapping: transitionStatusMapping
	});
	useOpenChangeComplete({
		open: selected,
		ref: indicatorRef,
		onComplete() {
			if (!selected) setMounted(false);
		}
	});
	return element;
}));
Inner.displayName = "Inner";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/chips/ComboboxChips.mjs
/**
* A container for the chips in a multiselectable input.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxChips = /*#__PURE__*/ import_react.forwardRef(function ComboboxChips(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const open = useStore(store, selectors.open);
	const hasSelectionChips = useStore(store, selectors.hasSelectionChips);
	const [highlightedChipIndex, setHighlightedChipIndex] = import_react.useState(void 0);
	if (open && highlightedChipIndex !== void 0) setHighlightedChipIndex(void 0);
	const chipsRef = import_react.useRef([]);
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, store.state.chipsContainerRef],
		props: [
			hasSelectionChips ? { role: "toolbar" } : EMPTY_OBJECT,
			{ onMouseDown(event) {
				handleInputPress(event, store, store.state.disabled, store.state.readOnly);
			} },
			elementProps
		]
	});
	const contextValue = import_react.useMemo(() => ({
		highlightedChipIndex,
		setHighlightedChipIndex,
		chipsRef
	}), [
		highlightedChipIndex,
		setHighlightedChipIndex,
		chipsRef
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxChipsContext.Provider, {
		value: contextValue,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
			elementsRef: chipsRef,
			children: element
		})
	});
});
ComboboxChips.displayName = "ComboboxChips";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/chip/ComboboxChipContext.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var ComboboxChipContext = /*#__PURE__*/ import_react.createContext(void 0);
ComboboxChipContext.displayName = "ComboboxChipContext";
function useComboboxChipContext() {
	const context = import_react.useContext(ComboboxChipContext);
	if (!context) throw new Error("Base UI: ComboboxChipContext is missing. ComboboxChip parts must be placed within <Combobox.Chip>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/chip/ComboboxChip.mjs
/**
* An individual chip that represents a value in a multiselectable input.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxChip = /*#__PURE__*/ import_react.forwardRef(function ComboboxChip(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const { setHighlightedChipIndex, chipsRef } = useComboboxChipsContext();
	const direction = useDirection();
	const disabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const selectedValue = useStore(store, selectors.selectedValue);
	const { ref, index } = useCompositeListItem();
	function handleKeyDown(event) {
		let nextIndex = index;
		const [previousChipKey, nextChipKey] = getChipNavigationKeys(direction);
		if (event.key === previousChipKey) {
			event.preventDefault();
			if (index > 0) nextIndex = index - 1;
			else nextIndex = void 0;
		} else if (event.key === nextChipKey) {
			event.preventDefault();
			if (index < chipsRef.current.length - 1) nextIndex = index + 1;
			else nextIndex = void 0;
		} else if (event.key === "Backspace" || event.key === "Delete") {
			nextIndex = getIndexAfterChipRemoval(index, selectedValue.length);
			stopEvent(event);
			store.state.setIndices({
				activeIndex: null,
				selectedIndex: null,
				type: keyboard
			});
			store.state.setSelectedValue(selectedValue.filter((_, i) => i !== index), createChangeEventDetails(none, event.nativeEvent));
		} else if (event.key === "Enter" || event.key === " ") {
			stopEvent(event);
			nextIndex = void 0;
		} else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
			stopEvent(event);
			store.state.setOpen(true, createChangeEventDetails(listNavigation, event.nativeEvent));
			nextIndex = void 0;
		} else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) nextIndex = void 0;
		return nextIndex;
	}
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, ref],
		state: { disabled },
		props: [{
			tabIndex: -1,
			"aria-disabled": disabled || void 0,
			"aria-readonly": readOnly || void 0,
			onKeyDown(event) {
				if (disabled || readOnly) return;
				const nextIndex = handleKeyDown(event);
				import_react_dom.flushSync(() => {
					setHighlightedChipIndex(nextIndex);
				});
				if (nextIndex === void 0) store.state.inputRef.current?.focus();
				else chipsRef.current[nextIndex]?.focus();
			}
		}, elementProps]
	});
	const contextValue = import_react.useMemo(() => ({ index }), [index]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ComboboxChipContext.Provider, {
		value: contextValue,
		children: element
	});
});
ComboboxChip.displayName = "ComboboxChip";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/chip-remove/ComboboxChipRemove.mjs
/**
* A button to remove a chip.
* Renders a `<button>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxChipRemove = /*#__PURE__*/ import_react.forwardRef(function ComboboxChipRemove(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp = false, nativeButton = true, style, ...elementProps } = componentProps;
	const store = useComboboxRootContext();
	const { index } = useComboboxChipContext();
	const comboboxDisabled = useStore(store, selectors.disabled);
	const readOnly = useStore(store, selectors.readOnly);
	const selectedValue = useStore(store, selectors.selectedValue);
	const isItemEqualToValue = useStore(store, selectors.isItemEqualToValue);
	const disabled = comboboxDisabled || disabledProp;
	const { buttonRef, getButtonProps } = useButton({
		native: nativeButton,
		disabled: disabled || readOnly,
		focusableWhenDisabled: true
	});
	const state = { disabled };
	function clearActiveIndexForRemovedItem(removedItem) {
		const activeIndex = store.state.activeIndex;
		if (activeIndex == null) return;
		const removedIndex = findItemIndex(store.state.valuesRef.current, removedItem, isItemEqualToValue);
		if (removedIndex !== -1 && activeIndex === removedIndex) store.state.setIndices({
			activeIndex: null,
			type: store.state.keyboardActiveRef.current ? keyboard : pointer
		});
	}
	function removeChip(event) {
		const eventDetails = createChangeEventDetails(chipRemovePress, event.nativeEvent);
		const removedItem = selectedValue[index];
		clearActiveIndexForRemovedItem(removedItem);
		store.state.setSelectedValue(selectedValue.filter((_, i) => i !== index), eventDetails);
		store.state.inputRef.current?.focus();
		return eventDetails;
	}
	return useRenderElement("button", componentProps, {
		ref: [forwardedRef, buttonRef],
		state,
		props: [
			{
				tabIndex: -1,
				onMouseDown(event) {
					event.preventDefault();
				},
				onClick(event) {
					if (!removeChip(event).isPropagationAllowed) event.stopPropagation();
				},
				onKeyDown(event) {
					if (event.key === "Enter" || event.key === " ") {
						if (!removeChip(event).isPropagationAllowed) stopEvent(event);
					}
				}
			},
			elementProps,
			getButtonProps
		]
	});
});
ComboboxChipRemove.displayName = "ComboboxChipRemove";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/separator/ComboboxSeparator.mjs
/**
* A visual separator between items or groups.
* Renders a `<div>` element.
*
* Documentation: [Base UI Combobox](https://base-ui.com/react/components/combobox)
*/
var ComboboxSeparator = ListboxSeparator;
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/combobox/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Arrow: () => ComboboxArrow,
	Backdrop: () => ComboboxBackdrop,
	Chip: () => ComboboxChip,
	ChipRemove: () => ComboboxChipRemove,
	Chips: () => ComboboxChips,
	Clear: () => ComboboxClear,
	Collection: () => ComboboxCollection,
	Empty: () => ComboboxEmpty,
	Group: () => ComboboxGroup,
	GroupLabel: () => ComboboxGroupLabel,
	Icon: () => ComboboxIcon,
	Input: () => ComboboxInput,
	InputGroup: () => ComboboxInputGroup,
	Item: () => ComboboxItem,
	ItemIndicator: () => ComboboxItemIndicator,
	Label: () => ComboboxLabel,
	List: () => ComboboxList,
	Popup: () => ComboboxPopup,
	Portal: () => ComboboxPortal,
	Positioner: () => ComboboxPositioner,
	Root: () => ComboboxRoot,
	Row: () => ComboboxRow,
	Separator: () => ComboboxSeparator,
	Status: () => ComboboxStatus,
	Trigger: () => ComboboxTrigger,
	Value: () => ComboboxValue,
	useFilter: () => useComboboxFilter,
	useFilteredItems: () => useFilteredItems
});
//#endregion
export { index_parts_exports as Combobox };
