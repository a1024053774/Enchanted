import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { B as isTupleOfAtLeast, C as isBoolean, E as isIterable, I as isString$1, J as constTrue, K as constFalse, L as isSymbol, Q as dual, R as isTagged, S as isBigInt, X as constVoid, Y as constUndefined, Z as constant, _ as structure, a as equals$3, d as array, f as combine$1, g as string$1, h as random, i as byReferenceUnsafe, it as Class$2, j as isNumber$1, k as isNotUndefined, l as symbol$2, m as number$1, n as asEquivalence, ot as pipeArguments, p as hash, rt as pipe, tt as identity, w as isDate, x as hasProperty, y as symbol$1, z as isTupleOf } from "./Equal-CgzkNqbP.js";
import { $t as DoneTypeId$1, An as isCause$1, B as toEntries, Bn as makePrimitiveProto, Bt as isGreaterThan$3, Cn as contE, Cr as strictEqual, Dn as exitFail, Dt as toArray, En as exitDie, Et as some$2, Fn as isExit$1, G as fail$6, Gt as mapInput$1, Hn as SingleShotGen, Ht as isLessThan$3, In as isFailReason$1, It as Tuple$1, Jn as NodeInspectSymbol, Jt as CauseImpl, K as failVoid, Kt as max$4, Ln as isInterruptReason$1, Lt as clamp$4, Mn as isDieReason$1, Mt as Number$2, Nn as isDone$2, On as exitFailCause, Ot as Array$2, Pn as isEffect$1, Pt as String$2, Q as isSuccess$3, Qn as format$2, Qt as Done$1, Rn as isNoSuchElementError$1, Rt as combineAll, Sn as contAll, Sr as make$14, Tn as evaluate, Tr as make$12, Ut as isLessThanOrEqualTo$3, Vn as withFiber$1, Vt as isGreaterThanOrEqualTo$3, W as all$2, Wn as internalCall, Wt as make$13, X as isFailure$3, Xn as toStringUnknown, Xt as CauseTypeId, Y as getOrThrow$1, Yn as toJson, Yt as CauseReasonTypeId, Zt as Die, _n as causeEmpty, an as NoSuchElementError$1, ar as redact, at as succeed$6, bn as constEmptyAnnotations, bt as isSome, cn as ReasonBase, cr as make$11, dn as TaggedError$1, dr as bind$3, en as EffectTypeId, er as formatJson, et as map$9, fn as Yield, fr as bindTo$3, gn as causeDie, hn as causeAnnotate, in as InterruptorStackTrace$1, ir as currentFiberTypeId, it as merge$3, jn as isCauseReason, kn as exitSucceed, ln as StackTraceKey, lr as max$5, mn as args, mr as Array$3, nn as ExitTypeId, nt as mapError$3, on as NoSuchElementErrorTypeId$1, pn as YieldableProto, pr as let_$3, qt as min$4, rn as Fail, sn as PipeInspectableProto, tn as Error$2, un as StructuralProto, ur as min$5, vn as causeFail, vr as Number$3, vt as isNone, wn as done$2, wt as none, xn as contA, xr as Tuple, yn as causeFromReasons, yr as String$3, zn as makePrimitive, zt as isBetween } from "./Record-BrB0racz.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/array.js
/**
* @since 2.0.0
*/
/** @internal */
var isArrayNonEmpty$1 = (self) => self.length > 0;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Tuple.js
/**
* Utilities for creating, accessing, transforming, and comparing fixed-length
* arrays (tuples). Every function produces a new tuple — inputs are never
* mutated.
*
* ## Mental model
*
* - **Tuple**: A fixed-length readonly array where each position can have a
*   different type (e.g., `readonly [string, number, boolean]`).
* - **Index-based access**: Elements are accessed by numeric index, and the
*   type system tracks the type at each position.
* - **Dual API**: Most functions accept arguments in both data-first
*   (`Tuple.get(t, 0)`) and data-last (`pipe(t, Tuple.get(0))`) style.
* - **Immutability**: All operations return a new tuple; the original is
*   never modified.
* - **Lambda**: A type-level function interface (from {@link Struct}) used by
*   {@link map}, {@link mapPick}, and {@link mapOmit} so the compiler can
*   track how element types change.
*
* ## Common tasks
*
* - Create a tuple → {@link make}
* - Access an element by index → {@link get}
* - Select / remove elements by index → {@link pick}, {@link omit}
* - Append elements → {@link appendElement}, {@link appendElements}
* - Transform selected elements → {@link evolve}
* - Swap element positions → {@link renameIndices}
* - Map all elements with a typed lambda → {@link map}, {@link mapPick},
*   {@link mapOmit}
* - Compare tuples → {@link makeEquivalence}, {@link makeOrder}
* - Combine / reduce tuples → {@link makeCombiner}, {@link makeReducer}
* - Check tuple length at runtime → {@link isTupleOf},
*   {@link isTupleOfAtLeast}
*
* ## Gotchas
*
* - {@link pick} and {@link omit} use numeric indices, not string keys.
* - {@link renameIndices} takes an array of stringified source indices
*   (e.g., `["2", "1", "0"]`), not arbitrary names.
* - {@link map}, {@link mapPick}, {@link mapOmit} require a Lambda value
*   created with `Struct.lambda`; a plain function won't type-check.
* - {@link isTupleOf} and {@link isTupleOfAtLeast} only check length, not
*   element types.
*
* ## Quickstart
*
* **Example** (Creating and transforming a tuple)
*
* ```ts
* import { pipe, Tuple } from "effect"
*
* const point = Tuple.make(10, 20, "red")
*
* const result = pipe(
*   point,
*   Tuple.evolve([
*     (x) => x * 2,
*     (y) => y * 2
*   ])
* )
*
* console.log(result) // [20, 40, "red"]
* ```
*
* ## See also
*
* - {@link Struct} – similar utilities for objects with named keys
* - {@link Array} – operations on variable-length arrays
*
* @since 2.0.0
*/
var Tuple_exports = /* @__PURE__ */ __exportAll({
	appendElement: () => appendElement,
	appendElements: () => appendElements,
	evolve: () => evolve,
	get: () => get$2,
	isTupleOf: () => isTupleOf,
	isTupleOfAtLeast: () => isTupleOfAtLeast,
	make: () => make$10,
	makeCombiner: () => makeCombiner,
	makeEquivalence: () => makeEquivalence$1,
	makeOrder: () => makeOrder$1,
	makeReducer: () => makeReducer$1,
	map: () => map$8,
	mapOmit: () => mapOmit,
	mapPick: () => mapPick,
	omit: () => omit$1,
	pick: () => pick$1,
	renameIndices: () => renameIndices
});
/**
* Creates a tuple from the provided arguments.
*
* - Use instead of `[a, b, c] as const` to get a properly typed tuple
*   without a manual cast.
* - Returns the exact tuple type with each element's literal type preserved.
*
* **Example** (Creating a tuple)
*
* ```ts
* import { Tuple } from "effect"
*
* const point = Tuple.make(10, 20, "red")
* console.log(point) // [10, 20, "red"]
* ```
*
* @see {@link get} – access a single element by index
* @see {@link appendElement} – append an element to a tuple
*
* @category Constructors
* @since 2.0.0
*/
var make$10 = (...elements) => elements;
/**
* Retrieves the element at the specified index from a tuple.
*
* - Use in a pipeline when you need to extract a single element.
* - The index is constrained to valid tuple positions at the type level.
* - Does not mutate the input.
*
* **Example** (Extracting an element by index)
*
* ```ts
* import { pipe, Tuple } from "effect"
*
* const last = pipe(Tuple.make(1, true, "hello"), Tuple.get(2))
* console.log(last) // "hello"
* ```
*
* @see {@link make} – create a tuple
* @see {@link pick} – extract multiple elements into a new tuple
*
* @category Getters
* @since 4.0.0
*/
var get$2 = /*#__PURE__*/ dual(2, (self, index) => self[index]);
/**
* Creates a new tuple containing only the elements at the specified indices.
*
* - Use to select a subset of elements from a tuple by position.
* - The result order matches the order of the provided indices.
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Selecting elements by index)
*
* ```ts
* import { Tuple } from "effect"
*
* const result = Tuple.pick(["a", "b", "c", "d"], [0, 2, 3])
* console.log(result) // ["a", "c", "d"]
* ```
*
* @see {@link omit} – the inverse (exclude indices instead)
* @see {@link get} – extract a single element
*
* @category Utilities
* @since 4.0.0
*/
var pick$1 = /*#__PURE__*/ dual(2, (self, indices) => {
	return indices.map((i) => self[i]);
});
/**
* Creates a new tuple with the elements at the specified indices removed.
*
* - Use to drop elements from a tuple by position.
* - Elements not at the specified indices are kept in their original order.
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Removing elements by index)
*
* ```ts
* import { Tuple } from "effect"
*
* const result = Tuple.omit(["a", "b", "c", "d"], [1, 3])
* console.log(result) // ["a", "c"]
* ```
*
* @see {@link pick} – the inverse (keep only specified indices)
*
* @category Utilities
* @since 4.0.0
*/
var omit$1 = /*#__PURE__*/ dual(2, (self, indices) => {
	const toDrop = new Set(indices);
	return self.filter((_, i) => !toDrop.has(i));
});
/**
* Appends a single element to the end of a tuple.
*
* - The result type is `[...T, E]`, preserving all existing element types.
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Appending an element)
*
* ```ts
* import { pipe, Tuple } from "effect"
*
* const result = pipe(Tuple.make(1, 2), Tuple.appendElement("end"))
* console.log(result) // [1, 2, "end"]
* ```
*
* @see {@link appendElements} – append multiple elements (another tuple)
*
* @category Concatenating
* @since 2.0.0
*/
var appendElement = /*#__PURE__*/ dual(2, (self, element) => [...self, element]);
/**
* Concatenates two tuples into a single tuple.
*
* - The result type is `[...T1, ...T2]`, preserving all element types from
*   both tuples.
* - Does not mutate either input; returns a fresh tuple.
*
* **Example** (Concatenating tuples)
*
* ```ts
* import { pipe, Tuple } from "effect"
*
* const result = pipe(Tuple.make(1, 2), Tuple.appendElements(["a", "b"] as const))
* console.log(result) // [1, 2, "a", "b"]
* ```
*
* @see {@link appendElement} – append a single element
*
* @category Concatenating
* @since 2.0.0
*/
var appendElements = /*#__PURE__*/ dual(2, (self, that) => [...self, ...that]);
/**
* Transforms elements of a tuple by providing an array of transform functions.
* Each function applies to the element at the same position. Positions beyond
* the array's length are copied unchanged.
*
* - Use when you want to update the first N elements while keeping the rest.
* - Does not mutate the input; returns a fresh tuple.
* - Each transform function receives the current value and can return a
*   different type.
*
* **Example** (Transforming selected elements)
*
* ```ts
* import { pipe, Tuple } from "effect"
*
* const result = pipe(
*   Tuple.make("hello", 42, true),
*   Tuple.evolve([
*     (s) => s.toUpperCase(),
*     (n) => n * 2
*   ])
* )
* console.log(result) // ["HELLO", 84, true]
* ```
*
* @see {@link map} – apply the same transformation to all elements
* @see {@link renameIndices} – swap element positions
*
* @category Mapping
* @since 4.0.0
*/
var evolve = /*#__PURE__*/ dual(2, (self, evolver) => {
	return self.map((e, i) => evolver[i] !== void 0 ? evolver[i](e) : e);
});
/**
* Rearranges elements of a tuple by providing an array of stringified source
* indices. Each position in the array specifies which index to read from
* (e.g., `["2", "1", "0"]` reverses a 3-element tuple).
*
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Swapping elements)
*
* ```ts
* import { pipe, Tuple } from "effect"
*
* const result = pipe(
*   Tuple.make("a", "b", "c"),
*   Tuple.renameIndices(["2", "1", "0"])
* )
* console.log(result) // ["c", "b", "a"]
* ```
*
* @see {@link evolve} – transform element values instead of positions
*
* @category Index utilities
* @since 4.0.0
*/
var renameIndices = /*#__PURE__*/ dual(2, (self, mapping) => {
	return self.map((e, i) => mapping[i] !== void 0 ? self[mapping[i]] : e);
});
/**
* Applies a `Struct.Lambda` transformation to every element in a tuple.
*
* - Use when you want to apply the same function to every element.
* - The lambda must be created with `Struct.lambda` so the compiler can
*   track the output types per element.
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Wrapping every element in an array)
*
* ```ts
* import { pipe, Struct, Tuple } from "effect"
*
* interface AsArray extends Struct.Lambda {
*   <A>(self: A): Array<A>
*   readonly "~lambda.out": Array<this["~lambda.in"]>
* }
*
* const asArray = Struct.lambda<AsArray>((a) => [a])
* const result = pipe(Tuple.make(1, "hello", true), Tuple.map(asArray))
* console.log(result) // [[1], ["hello"], [true]]
* ```
*
* @see {@link mapPick} – apply a lambda only to selected indices
* @see {@link mapOmit} – apply a lambda to all indices except selected ones
* @see {@link evolve} – apply different functions to different indices
*
* @category Mapping
* @since 4.0.0
*/
var map$8 = /*#__PURE__*/ dual(2, (self, lambda) => {
	return self.map((e) => lambda(e));
});
/**
* Applies a `Struct.Lambda` transformation only to the elements at the
* specified indices; all other elements are copied unchanged.
*
* - Use when you want to apply the same transformation to a subset of
*   positions.
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Wrapping only selected elements in arrays)
*
* ```ts
* import { pipe, Struct, Tuple } from "effect"
*
* interface AsArray extends Struct.Lambda {
*   <A>(self: A): Array<A>
*   readonly "~lambda.out": Array<this["~lambda.in"]>
* }
*
* const asArray = Struct.lambda<AsArray>((a) => [a])
* const result = pipe(
*   Tuple.make(1, "hello", true),
*   Tuple.mapPick([0, 2], asArray)
* )
* console.log(result) // [[1], "hello", [true]]
* ```
*
* @see {@link map} – apply a lambda to all elements
* @see {@link mapOmit} – apply a lambda to all elements except selected ones
*
* @category Mapping
* @since 4.0.0
*/
var mapPick = /*#__PURE__*/ dual(3, (self, indices, lambda) => {
	const toPick = new Set(indices);
	return self.map((e, i) => toPick.has(i) ? lambda(e) : e);
});
/**
* Applies a `Struct.Lambda` transformation to all elements except those at the
* specified indices; the excluded elements are copied unchanged.
*
* - Use when most elements should be transformed but a few should be
*   preserved.
* - Does not mutate the input; returns a fresh tuple.
*
* **Example** (Wrapping all elements except one in arrays)
*
* ```ts
* import { pipe, Struct, Tuple } from "effect"
*
* interface AsArray extends Struct.Lambda {
*   <A>(self: A): Array<A>
*   readonly "~lambda.out": Array<this["~lambda.in"]>
* }
*
* const asArray = Struct.lambda<AsArray>((a) => [a])
* const result = pipe(
*   Tuple.make(1, "hello", true),
*   Tuple.mapOmit([1], asArray)
* )
* console.log(result) // [[1], "hello", [true]]
* ```
*
* @see {@link map} – apply a lambda to all elements
* @see {@link mapPick} – apply a lambda only to selected indices
*
* @category Mapping
* @since 4.0.0
*/
var mapOmit = /*#__PURE__*/ dual(3, (self, indices, lambda) => {
	const toOmit = new Set(indices);
	return self.map((e, i) => toOmit.has(i) ? e : lambda(e));
});
/**
* Creates an `Equivalence` for tuples by comparing corresponding elements
* using the provided per-position `Equivalence`s. Two tuples are equivalent
* when all their corresponding elements are equivalent.
*
* Alias of `Equivalence.Tuple`.
*
* - Use when you need to compare tuples element-by-element.
*
* **Example** (Comparing tuples for equivalence)
*
* ```ts
* import { Equivalence, Tuple } from "effect"
*
* const eq = Tuple.makeEquivalence([
*   Equivalence.strictEqual<string>(),
*   Equivalence.strictEqual<number>()
* ])
*
* console.log(eq(["Alice", 30], ["Alice", 30])) // true
* console.log(eq(["Alice", 30], ["Bob", 30]))   // false
* ```
*
* @see {@link makeOrder} – create an `Order` for tuples
*
* @category Equivalence
* @since 2.0.0
*/
var makeEquivalence$1 = Tuple;
/**
* Creates an `Order` for tuples by comparing corresponding elements using the
* provided per-position `Order`s. Elements are compared left-to-right; the
* first non-zero comparison determines the result.
*
* Alias of `Order.Tuple`.
*
* - Use to sort or compare tuples lexicographically by element position.
*
* **Example** (Ordering tuples)
*
* ```ts
* import { Number, String, Tuple } from "effect"
*
* const ord = Tuple.makeOrder([String.Order, Number.Order])
*
* console.log(ord(["Alice", 30], ["Bob", 25]))   // -1
* console.log(ord(["Alice", 30], ["Alice", 30])) // 0
* ```
*
* @see {@link makeEquivalence} – create an `Equivalence` for tuples
*
* @category Ordering
* @since 2.0.0
*/
var makeOrder$1 = Tuple$1;
/**
* Creates a `Combiner` for a tuple shape by providing a `Combiner` for each
* position. When two tuples are combined, each element is merged using its
* corresponding combiner.
*
* - Use when you need to merge two tuples of the same shape (e.g., summing
*   counters, concatenating strings).
* - Does not mutate the inputs; returns a fresh tuple.
*
* **Example** (Combining tuple elements)
*
* ```ts
* import { Number, String, Tuple } from "effect"
*
* const C = Tuple.makeCombiner<readonly [number, string]>([
*   Number.ReducerSum,
*   String.ReducerConcat
* ])
*
* const result = C.combine([1, "hello"], [2, " world"])
* console.log(result) // [3, "hello world"]
* ```
*
* @see {@link makeReducer} – like `makeCombiner` but with an initial value
*
* @since 4.0.0
*/
function makeCombiner(combiners) {
	return make$11((self, that) => {
		const out = [];
		for (let i = 0; i < self.length; i++) out.push(combiners[i].combine(self[i], that[i]));
		return out;
	});
}
/**
* Creates a `Reducer` for a tuple shape by providing a `Reducer` for each
* position. The initial value is derived from each position's
* `Reducer.initialValue`. When reducing a collection of tuples, each element
* is combined independently.
*
* - Use to fold a collection of tuples into a single summary tuple.
* - Does not mutate the inputs; returns a fresh tuple.
*
* **Example** (Reducing a collection of tuples)
*
* ```ts
* import { Number, String, Tuple } from "effect"
*
* const R = Tuple.makeReducer<readonly [number, string]>([
*   Number.ReducerSum,
*   String.ReducerConcat
* ])
*
* const result = R.combineAll([
*   [1, "a"],
*   [2, "b"],
*   [3, "c"]
* ])
* console.log(result) // [6, "abc"]
* ```
*
* @see {@link makeCombiner} – like `makeReducer` but without an initial value
*
* @since 4.0.0
*/
function makeReducer$1(reducers) {
	const combine = makeCombiner(reducers).combine;
	const initialValue = [];
	for (let i = 0; i < reducers.length; i++) initialValue.push(reducers[i].initialValue);
	return make$12(combine, initialValue);
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Iterable.js
/**
* This module provides utility functions for working with Iterables in TypeScript.
*
* Iterables are objects that implement the iterator protocol, allowing them to be
* consumed with `for...of` loops, spread syntax, and other iteration constructs.
* This module provides a comprehensive set of functions for creating, transforming,
* and working with iterables in a functional programming style.
*
* Unlike arrays, iterables can be lazy and potentially infinite, making them suitable
* for stream processing and memory-efficient data manipulation. All functions in this
* module preserve the lazy nature of iterables where possible.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Create iterables
* const numbers = Iterable.range(1, 5)
* const doubled = Iterable.map(numbers, (x) => x * 2)
* const filtered = Iterable.filter(doubled, (x) => x > 5)
*
* console.log(Array.from(filtered)) // [6, 8, 10]
*
* // Infinite iterables
* const fibonacci = Iterable.unfold([0, 1], ([a, b]) => [a, [b, a + b]])
* const first10 = Iterable.take(fibonacci, 10)
* console.log(Array.from(first10)) // [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
* ```
*
* @since 2.0.0
*/
var Iterable_exports = /* @__PURE__ */ __exportAll({
	append: () => append$1,
	appendAll: () => appendAll$1,
	cartesian: () => cartesian$1,
	cartesianWith: () => cartesianWith$1,
	chunksOf: () => chunksOf$1,
	contains: () => contains$1,
	containsWith: () => containsWith$1,
	countBy: () => countBy$1,
	dedupeAdjacent: () => dedupeAdjacent$1,
	dedupeAdjacentWith: () => dedupeAdjacentWith$1,
	drop: () => drop$1,
	empty: () => empty$5,
	filter: () => filter$3,
	filterMap: () => filterMap$3,
	filterMapWhile: () => filterMapWhile,
	findFirst: () => findFirst$3,
	findLast: () => findLast$1,
	flatMap: () => flatMap$4,
	flatMapNullishOr: () => flatMapNullishOr$1,
	flatten: () => flatten$3,
	forEach: () => forEach$3,
	forever: () => forever$3,
	fromRecord: () => fromRecord$1,
	getFailures: () => getFailures$1,
	getSomes: () => getSomes$1,
	getSuccesses: () => getSuccesses$1,
	group: () => group$1,
	groupBy: () => groupBy$1,
	groupWith: () => groupWith$1,
	head: () => head$1,
	headUnsafe: () => headUnsafe,
	intersperse: () => intersperse$1,
	isEmpty: () => isEmpty$1,
	makeBy: () => makeBy$1,
	map: () => map$7,
	of: () => of$2,
	prepend: () => prepend$1,
	prependAll: () => prependAll$1,
	range: () => range$1,
	reduce: () => reduce$2,
	repeat: () => repeat$3,
	replicate: () => replicate$3,
	scan: () => scan$1,
	size: () => size,
	some: () => some$1,
	take: () => take$2,
	takeWhile: () => takeWhile$1,
	unfold: () => unfold$2,
	zip: () => zip$4,
	zipWith: () => zipWith$4
});
/**
* Creates an iterable by applying a function to consecutive integers.
*
* This is a fundamental constructor that generates iterables by calling a function
* with each index starting from 0. If no length is specified, the iterable will
* be infinite. This is useful for generating sequences, patterns, or any indexed data.
*
* @param f - Function that receives the index and returns the element
* @param options - Configuration object with optional length
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Generate first 5 even numbers
* const evens = Iterable.makeBy((n) => n * 2, { length: 5 })
* console.log(Array.from(evens)) // [0, 2, 4, 6, 8]
*
* // Generate squares
* const squares = Iterable.makeBy((n) => n * n, { length: 4 })
* console.log(Array.from(squares)) // [0, 1, 4, 9]
*
* // Infinite sequence (be careful when consuming!)
* const naturals = Iterable.makeBy((n) => n)
* const first10 = Iterable.take(naturals, 10)
* console.log(Array.from(first10)) // [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
* ```
*
* @category constructors
* @since 2.0.0
*/
var makeBy$1 = (f, options) => {
	const max = options?.length !== void 0 ? Math.max(1, Math.floor(options.length)) : Infinity;
	return { [Symbol.iterator]() {
		let i = 0;
		return { next() {
			if (i < max) return {
				value: f(i++),
				done: false
			};
			return {
				done: true,
				value: void 0
			};
		} };
	} };
};
/**
* Return a `Iterable` containing a range of integers, including both endpoints.
*
* If `end` is omitted, the range will not have an upper bound.
*
* @example
* ```ts
* import { range } from "effect/Iterable"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Array.from(range(1, 3)), [1, 2, 3])
* ```
*
* @category constructors
* @since 2.0.0
*/
var range$1 = (start, end) => {
	if (end === void 0) return makeBy$1((i) => start + i);
	return makeBy$1((i) => start + i, { length: start <= end ? end - start + 1 : 1 });
};
/**
* Return a `Iterable` containing a value repeated the specified number of times.
*
* **Note**. `n` is normalized to an integer >= 1.
*
* @example
* ```ts
* import { replicate } from "effect/Iterable"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Array.from(replicate("a", 3)), ["a", "a", "a"])
* ```
*
* @category constructors
* @since 2.0.0
*/
var replicate$3 = /*#__PURE__*/ dual(2, (a, n) => makeBy$1(() => a, { length: n }));
/**
* @category constructors
* @since 4.0.0
*/
var repeat$3 = /*#__PURE__*/ dual(2, (self, n) => flatten$3(makeBy$1(() => self, { length: n })));
/**
* @category constructors
* @since 4.0.0
*/
var forever$3 = (self) => repeat$3(self, Infinity);
/**
* Takes a record and returns an Iterable of tuples containing its keys and values.
*
* @example
* ```ts
* import { fromRecord } from "effect/Iterable"
* import * as assert from "node:assert"
*
* const x = { a: 1, b: 2, c: 3 }
* assert.deepStrictEqual(Array.from(fromRecord(x)), [["a", 1], ["b", 2], [
*   "c",
*   3
* ]])
* ```
*
* @category conversions
* @since 2.0.0
*/
var fromRecord$1 = (self) => ({ *[Symbol.iterator]() {
	for (const key in self) if (Object.hasOwn(self, key)) yield [key, self[key]];
} });
/**
* Prepend an element to the front of an `Iterable`, creating a new `Iterable`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [2, 3, 4]
* const withOne = Iterable.prepend(numbers, 1)
* console.log(Array.from(withOne)) // [1, 2, 3, 4]
*
* // Works with any iterable
* const letters = "abc"
* const withZ = Iterable.prepend(letters, "z")
* console.log(Array.from(withZ)) // ["z", "a", "b", "c"]
* ```
*
* @category concatenating
* @since 2.0.0
*/
var prepend$1 = /*#__PURE__*/ dual(2, (self, head) => prependAll$1(self, [head]));
/**
* Prepends the specified prefix iterable to the beginning of the specified iterable.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Array.from(Iterable.prependAll([1, 2], ["a", "b"])),
*   ["a", "b", 1, 2]
* )
* ```
*
* @category concatenating
* @since 2.0.0
*/
var prependAll$1 = /*#__PURE__*/ dual(2, (self, that) => appendAll$1(that, self));
/**
* Append an element to the end of an `Iterable`, creating a new `Iterable`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3]
* const withFour = Iterable.append(numbers, 4)
* console.log(Array.from(withFour)) // [1, 2, 3, 4]
*
* // Chain multiple appends
* const result = Iterable.append(
*   Iterable.append([1, 2], 3),
*   4
* )
* console.log(Array.from(result)) // [1, 2, 3, 4]
* ```
*
* @category concatenating
* @since 2.0.0
*/
var append$1 = /*#__PURE__*/ dual(2, (self, last) => appendAll$1(self, [last]));
/**
* Concatenates two iterables, combining their elements.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const first = [1, 2, 3]
* const second = [4, 5, 6]
* const combined = Iterable.appendAll(first, second)
* console.log(Array.from(combined)) // [1, 2, 3, 4, 5, 6]
*
* // Works with different iterable types
* const numbers = [1, 2]
* const letters = "abc"
* const mixed = Iterable.appendAll(numbers, letters)
* console.log(Array.from(mixed)) // [1, 2, "a", "b", "c"]
*
* // Lazy evaluation - only consumes what's needed
* const infinite = Iterable.range(1)
* const finite = [0, -1, -2]
* const result = Iterable.take(Iterable.appendAll(finite, infinite), 5)
* console.log(Array.from(result)) // [0, -1, -2, 1, 2]
* ```
*
* @category concatenating
* @since 2.0.0
*/
var appendAll$1 = /*#__PURE__*/ dual(2, (self, that) => ({ [Symbol.iterator]() {
	const iterA = self[Symbol.iterator]();
	let doneA = false;
	let iterB;
	return { next() {
		if (!doneA) {
			const r = iterA.next();
			if (r.done) {
				doneA = true;
				iterB = that[Symbol.iterator]();
				return iterB.next();
			}
			return r;
		}
		return iterB.next();
	} };
} }));
/**
* Reduce an `Iterable` from the left, keeping all intermediate results instead of only the final result.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Running sum of numbers
* const numbers = [1, 2, 3, 4, 5]
* const runningSum = Iterable.scan(numbers, 0, (acc, n) => acc + n)
* console.log(Array.from(runningSum)) // [0, 1, 3, 6, 10, 15]
*
* // Build strings progressively
* const letters = ["a", "b", "c"]
* const progressive = Iterable.scan(letters, "", (acc, letter) => acc + letter)
* console.log(Array.from(progressive)) // ["", "a", "ab", "abc"]
*
* // Track maximum values seen so far
* const values = [3, 1, 4, 1, 5, 9, 2]
* const runningMax = Iterable.scan(values, -Infinity, Math.max)
* console.log(Array.from(runningMax)) // [-Infinity, 3, 3, 4, 4, 5, 9, 9]
* ```
*
* @category folding
* @since 2.0.0
*/
var scan$1 = /*#__PURE__*/ dual(3, (self, b, f) => ({ [Symbol.iterator]() {
	let acc = b;
	let iterator;
	function next() {
		if (iterator === void 0) {
			iterator = self[Symbol.iterator]();
			return {
				done: false,
				value: acc
			};
		}
		const result = iterator.next();
		if (result.done) return result;
		acc = f(acc, result.value);
		return {
			done: false,
			value: acc
		};
	}
	return { next };
} }));
/**
* Determine if an `Iterable` is empty
*
* @example
* ```ts
* import { isEmpty } from "effect/Iterable"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isEmpty([]), true)
* assert.deepStrictEqual(isEmpty([1, 2, 3]), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isEmpty$1 = (self) => {
	return self[Symbol.iterator]().next().done === true;
};
/**
* Return the number of elements in a `Iterable`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3, 4, 5]
* console.log(Iterable.size(numbers)) // 5
*
* const empty = Iterable.empty<number>()
* console.log(Iterable.size(empty)) // 0
*
* // Works with any iterable
* const letters = "hello"
* console.log(Iterable.size(letters)) // 5
*
* // Note: This consumes the entire iterable
* const range = Iterable.range(1, 100)
* console.log(Iterable.size(range)) // 100
* ```
*
* @category getters
* @since 2.0.0
*/
var size = (self) => {
	const iterator = self[Symbol.iterator]();
	let count = 0;
	while (!iterator.next().done) count++;
	return count;
};
/**
* Get the first element of a `Iterable`, or `None` if the `Iterable` is empty.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Option from "effect/Option"
*
* const numbers = [1, 2, 3]
* console.log(Iterable.head(numbers)) // Option.some(1)
*
* const empty = Iterable.empty<number>()
* console.log(Iterable.head(empty)) // Option.none()
*
* // Safe way to get first element
* const firstEven = Iterable.head(
*   Iterable.filter([1, 3, 4, 5], (x) => x % 2 === 0)
* )
* console.log(firstEven) // Option.some(4)
*
* // Use with Option methods
* const doubled = Option.map(Iterable.head([5, 10, 15]), (x) => x * 2)
* console.log(doubled) // Option.some(10)
* ```
*
* @category getters
* @since 2.0.0
*/
var head$1 = (self) => {
	const result = self[Symbol.iterator]().next();
	return result.done ? none() : some$2(result.value);
};
/**
* Get the first element of a `Iterable`, or throw an error if the `Iterable` is empty.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3]
* console.log(Iterable.headUnsafe(numbers)) // 1
*
* const letters = "hello"
* console.log(Iterable.headUnsafe(letters)) // "h"
*
* // This will throw an error!
* try {
*   const empty = Iterable.empty<number>()
*   Iterable.headUnsafe(empty) // throws Error: "headUnsafe: empty iterable"
* } catch (error) {
*   console.log((error as Error).message) // "headUnsafe: empty iterable"
* }
*
* // Use only when you're certain the iterable is non-empty
* const nonEmpty = Iterable.range(1, 10)
* console.log(Iterable.headUnsafe(nonEmpty)) // 1
* ```
*
* @category getters
* @since 3.3.0
*/
var headUnsafe = (self) => {
	const result = self[Symbol.iterator]().next();
	if (result.done) throw new Error("headUnsafe: empty iterable");
	return result.value;
};
/**
* Keep only a max number of elements from the start of an `Iterable`, creating a new `Iterable`.
*
* **Note**. `n` is normalized to a non negative integer.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3, 4, 5]
* const firstThree = Iterable.take(numbers, 3)
* console.log(Array.from(firstThree)) // [1, 2, 3]
*
* // Taking more than available returns all elements
* const firstTen = Iterable.take(numbers, 10)
* console.log(Array.from(firstTen)) // [1, 2, 3, 4, 5]
*
* // Taking 0 or negative returns empty
* const none = Iterable.take(numbers, 0)
* console.log(Array.from(none)) // []
*
* // Useful with infinite iterables
* const naturals = Iterable.range(1)
* const firstFive = Iterable.take(naturals, 5)
* console.log(Array.from(firstFive)) // [1, 2, 3, 4, 5]
* ```
*
* @category getters
* @since 2.0.0
*/
var take$2 = /*#__PURE__*/ dual(2, (self, n) => ({ [Symbol.iterator]() {
	let i = 0;
	const iterator = self[Symbol.iterator]();
	return { next() {
		if (i < n) {
			i++;
			return iterator.next();
		}
		return {
			done: true,
			value: void 0
		};
	} };
} }));
/**
* Calculate the longest initial Iterable for which all element satisfy the specified predicate, creating a new `Iterable`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [2, 4, 6, 8, 3, 10, 12]
* const evenPrefix = Iterable.takeWhile(numbers, (x) => x % 2 === 0)
* console.log(Array.from(evenPrefix)) // [2, 4, 6, 8]
*
* // With index
* const letters = ["a", "b", "c", "d", "e"]
* const firstThreeByIndex = Iterable.takeWhile(letters, (_, i) => i < 3)
* console.log(Array.from(firstThreeByIndex)) // ["a", "b", "c"]
*
* // Stops at first non-matching element
* const mixed = [1, 3, 5, 4, 7, 9]
* const oddPrefix = Iterable.takeWhile(mixed, (x) => x % 2 === 1)
* console.log(Array.from(oddPrefix)) // [1, 3, 5]
*
* // Type refinement
* const values: Array<string | number> = ["a", "b", "c", 1, "d"]
* const stringPrefix = Iterable.takeWhile(
*   values,
*   (x): x is string => typeof x === "string"
* )
* console.log(Array.from(stringPrefix)) // ["a", "b", "c"] (typed as string[])
* ```
*
* @category getters
* @since 2.0.0
*/
var takeWhile$1 = /*#__PURE__*/ dual(2, (self, predicate) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let i = 0;
	return { next() {
		const result = iterator.next();
		if (result.done || !predicate(result.value, i++)) return {
			done: true,
			value: void 0
		};
		return result;
	} };
} }));
/**
* Drop a max number of elements from the start of an `Iterable`
*
* **Note**. `n` is normalized to a non negative integer.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3, 4, 5]
* const withoutFirstTwo = Iterable.drop(numbers, 2)
* console.log(Array.from(withoutFirstTwo)) // [3, 4, 5]
*
* // Dropping more than available returns empty
* const withoutFirstTen = Iterable.drop(numbers, 10)
* console.log(Array.from(withoutFirstTen)) // []
*
* // Dropping 0 or negative returns all elements
* const all = Iterable.drop(numbers, 0)
* console.log(Array.from(all)) // [1, 2, 3, 4, 5]
*
* // Combine with take for slicing
* const slice = Iterable.take(Iterable.drop(numbers, 1), 3)
* console.log(Array.from(slice)) // [2, 3, 4]
* ```
*
* @category getters
* @since 2.0.0
*/
var drop$1 = /*#__PURE__*/ dual(2, (self, n) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let i = 0;
	return { next() {
		while (i < n) {
			if (iterator.next().done) return {
				done: true,
				value: void 0
			};
			i++;
		}
		return iterator.next();
	} };
} }));
/**
* Returns the first element that satisfies the specified
* predicate, or `None` if no such element exists.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Option from "effect/Option"
*
* const numbers = [1, 3, 4, 6, 8]
* const firstEven = Iterable.findFirst(numbers, (x) => x % 2 === 0)
* console.log(firstEven) // Option.some(4)
*
* const firstGreaterThan10 = Iterable.findFirst(numbers, (x) => x > 10)
* console.log(firstGreaterThan10) // Option.none()
*
* // With index
* const letters = ["a", "b", "c", "d"]
* const atEvenIndex = Iterable.findFirst(letters, (_, i) => i % 2 === 0)
* console.log(atEvenIndex) // Option.some("a")
*
* // Type refinement
* const mixed: Array<string | number> = [1, "hello", 2, "world"]
* const firstString = Iterable.findFirst(
*   mixed,
*   (x): x is string => typeof x === "string"
* )
* console.log(firstString) // Option.some("hello")
*
* // Transform during search
* const findSquareRoot = Iterable.findFirst([1, 4, 9, 16], (x) => {
*   const sqrt = Math.sqrt(x)
*   return Number.isInteger(sqrt) ? Option.some(sqrt) : Option.none()
* })
* console.log(findSquareRoot) // Option.some(1)
* ```
*
* @category elements
* @since 2.0.0
*/
var findFirst$3 = /*#__PURE__*/ dual(2, (self, f) => {
	let i = 0;
	for (const a of self) {
		const o = f(a, i);
		if (isBoolean(o)) {
			if (o) return some$2(a);
		} else if (isSome(o)) return o;
		i++;
	}
	return none();
});
/**
* Find the last element for which a predicate holds.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 3, 4, 6, 8, 2]
* const lastEven = Iterable.findLast(numbers, (x) => x % 2 === 0)
* console.log(lastEven) // Option.some(2)
*
* const lastGreaterThan10 = Iterable.findLast(numbers, (x) => x > 10)
* console.log(lastGreaterThan10) // Option.none()
*
* // With index
* const letters = ["a", "b", "c", "d", "e"]
* const lastAtEvenIndex = Iterable.findLast(letters, (_, i) => i % 2 === 0)
* console.log(lastAtEvenIndex) // Option.some("e") (index 4)
*
* // Type refinement
* const mixed: Array<string | number> = [1, "hello", 2, "world", 3]
* const lastString = Iterable.findLast(
*   mixed,
*   (x): x is string => typeof x === "string"
* )
* console.log(lastString) // Option.some("world")
* ```
*
* @category elements
* @since 2.0.0
*/
var findLast$1 = /*#__PURE__*/ dual(2, (self, f) => {
	let i = 0;
	let last = none();
	for (const a of self) {
		const o = f(a, i);
		if (isBoolean(o)) {
			if (o) last = some$2(a);
		} else if (isSome(o)) last = o;
		i++;
	}
	return last;
});
/**
* Takes two `Iterable`s and returns an `Iterable` of corresponding pairs.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3]
* const letters = ["a", "b", "c"]
* const zipped = Iterable.zip(numbers, letters)
* console.log(Array.from(zipped)) // [[1, "a"], [2, "b"], [3, "c"]]
*
* // Different lengths - shorter one determines result length
* const short = [1, 2]
* const long = ["a", "b", "c", "d"]
* const partial = Iterable.zip(short, long)
* console.log(Array.from(partial)) // [[1, "a"], [2, "b"]]
*
* // Works with any iterables
* const range = Iterable.range(1, 3)
* const word = "abc"
* const mixed = Iterable.zip(range, word)
* console.log(Array.from(mixed)) // [[1, "a"], [2, "b"], [3, "c"]]
*
* // Create indexed pairs
* const values = ["apple", "banana", "cherry"]
* const indices = Iterable.range(0, 2)
* const indexed = Iterable.zip(indices, values)
* console.log(Array.from(indexed)) // [[0, "apple"], [1, "banana"], [2, "cherry"]]
* ```
*
* @category zipping
* @since 2.0.0
*/
var zip$4 = /*#__PURE__*/ dual(2, (self, that) => zipWith$4(self, that, make$10));
/**
* Apply a function to pairs of elements at the same index in two `Iterable`s, collecting the results. If one
* input `Iterable` is short, excess elements of the longer `Iterable` are discarded.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Add corresponding elements
* const a = [1, 2, 3, 4]
* const b = [10, 20, 30, 40]
* const sums = Iterable.zipWith(a, b, (x, y) => x + y)
* console.log(Array.from(sums)) // [11, 22, 33, 44]
*
* // Combine strings
* const firstNames = ["John", "Jane", "Bob"]
* const lastNames = ["Doe", "Smith", "Johnson"]
* const fullNames = Iterable.zipWith(
*   firstNames,
*   lastNames,
*   (first, last) => `${first} ${last}`
* )
* console.log(Array.from(fullNames)) // ["John Doe", "Jane Smith", "Bob Johnson"]
*
* // Different lengths - stops at shorter
* const short = [1, 2]
* const long = ["a", "b", "c", "d"]
* const combined = Iterable.zipWith(
*   short,
*   long,
*   (num, letter) => `${num}${letter}`
* )
* console.log(Array.from(combined)) // ["1a", "2b"]
*
* // Complex transformations
* const prices = [10.99, 25.50, 5.00]
* const quantities = [2, 1, 3]
* const totals = Iterable.zipWith(prices, quantities, (price, qty) => {
*   return Math.round(price * qty * 100) / 100 // round to 2 decimal places
* })
* console.log(Array.from(totals)) // [21.98, 25.5, 15]
* ```
*
* @category zipping
* @since 2.0.0
*/
var zipWith$4 = /*#__PURE__*/ dual(3, (self, that, f) => ({ [Symbol.iterator]() {
	const selfIterator = self[Symbol.iterator]();
	const thatIterator = that[Symbol.iterator]();
	return { next() {
		const selfResult = selfIterator.next();
		const thatResult = thatIterator.next();
		if (selfResult.done || thatResult.done) return {
			done: true,
			value: void 0
		};
		return {
			done: false,
			value: f(selfResult.value, thatResult.value)
		};
	} };
} }));
/**
* Places an element in between members of an `Iterable`.
* If the input is a non-empty array, the result is also a non-empty array.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Join numbers with separator
* const numbers = [1, 2, 3, 4]
* const withCommas = Iterable.intersperse(numbers, ",")
* console.log(Array.from(withCommas)) // [1, ",", 2, ",", 3, ",", 4]
*
* // Join words with spaces
* const words = ["hello", "world", "from", "effect"]
* const sentence = Iterable.intersperse(words, " ")
* console.log(Array.from(sentence).join("")) // "hello world from effect"
*
* // Empty iterable remains empty
* const empty = Iterable.empty<string>()
* const stillEmpty = Iterable.intersperse(empty, "-")
* console.log(Array.from(stillEmpty)) // []
*
* // Single element has no separators added
* const single = [42]
* const noSeparator = Iterable.intersperse(single, "|")
* console.log(Array.from(noSeparator)) // [42]
*
* // Build CSS-like strings
* const styles = ["color: red", "font-size: 14px", "margin: 10px"]
* const css = Iterable.intersperse(styles, "; ")
* console.log(Array.from(css).join("")) // "color: red; font-size: 14px; margin: 10px"
* ```
*
* @category concatenating
* @since 2.0.0
*/
var intersperse$1 = /*#__PURE__*/ dual(2, (self, middle) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let next = iterator.next();
	let emitted = false;
	return { next() {
		if (next.done) return next;
		else if (emitted) {
			emitted = false;
			return {
				done: false,
				value: middle
			};
		}
		emitted = true;
		const result = next;
		next = iterator.next();
		return result;
	} };
} }));
/**
* Returns a function that checks if an `Iterable` contains a given value using a provided `isEquivalent` function.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Custom equivalence for objects
* const byId = (a: { id: number }, b: { id: number }) => a.id === b.id
* const containsById = Iterable.containsWith(byId)
*
* const users = [{ id: 1 }, { id: 2 }]
* const hasUser1 = containsById(users, { id: 1 })
* console.log(hasUser1) // true (same id)
*
* // Case-insensitive string comparison
* const caseInsensitive = (a: string, b: string) =>
*   a.toLowerCase() === b.toLowerCase()
* const containsCaseInsensitive = Iterable.containsWith(caseInsensitive)
*
* const words = ["Hello", "World"]
* const hasHello = containsCaseInsensitive(words, "hello")
* console.log(hasHello) // true
*
* // Approximate number comparison
* const approxEqual = (a: number, b: number) => Math.abs(a - b) < 0.1
* const containsApprox = Iterable.containsWith(approxEqual)
*
* const values = [1.0, 2.0, 3.0]
* const hasAlmostTwo = containsApprox(values, 2.05)
* console.log(hasAlmostTwo) // true
* ```
*
* @category elements
* @since 2.0.0
*/
var containsWith$1 = (isEquivalent) => dual(2, (self, a) => {
	for (const i of self) if (isEquivalent(a, i)) return true;
	return false;
});
/**
* Returns a function that checks if a `Iterable` contains a given value using the default `Equivalence`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3, 4, 5]
* console.log(Iterable.contains(numbers, 3)) // true
* console.log(Iterable.contains(numbers, 6)) // false
*
* const letters = "hello"
* console.log(Iterable.contains(letters, "l")) // true
* console.log(Iterable.contains(letters, "x")) // false
*
* // Works with any iterable
* const range = Iterable.range(1, 100)
* console.log(Iterable.contains(range, 50)) // true
* console.log(Iterable.contains(range, 150)) // false
*
* // Curried version
* const containsThree = Iterable.contains(3)
* console.log(containsThree([1, 2, 3])) // true
* console.log(containsThree([4, 5, 6])) // false
* ```
*
* @category elements
* @since 2.0.0
*/
var contains$1 = /*#__PURE__*/ containsWith$1(/*#__PURE__*/ asEquivalence());
/**
* Splits an `Iterable` into length-`n` pieces. The last piece will be shorter if `n` does not evenly divide the length of
* the `Iterable`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
* const chunks = Iterable.chunksOf(numbers, 3)
* console.log(Array.from(chunks).map((chunk) => Array.from(chunk)))
* // [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
*
* // Last chunk can be shorter
* const uneven = [1, 2, 3, 4, 5, 6, 7]
* const chunks2 = Iterable.chunksOf(uneven, 3)
* console.log(Array.from(chunks2).map((chunk) => Array.from(chunk)))
* // [[1, 2, 3], [4, 5, 6], [7]]
*
* // Chunk size larger than iterable
* const small = [1, 2]
* const chunks3 = Iterable.chunksOf(small, 5)
* console.log(Array.from(chunks3).map((chunk) => Array.from(chunk)))
* // [[1, 2]]
*
* // Process data in batches
* const data = Iterable.range(1, 100)
* const batches = Iterable.chunksOf(data, 10)
* const batchSums = Iterable.map(
*   batches,
*   (batch) => Iterable.reduce(batch, 0, (sum, n) => sum + n)
* )
* console.log(Array.from(Iterable.take(batchSums, 3))) // [55, 155, 255]
* ```
*
* @category splitting
* @since 2.0.0
*/
var chunksOf$1 = /*#__PURE__*/ dual(2, (self, n) => {
	const safeN = Math.max(1, Math.floor(n));
	return { [Symbol.iterator]() {
		let iterator = self[Symbol.iterator]();
		return { next() {
			if (iterator === void 0) return {
				done: true,
				value: void 0
			};
			const chunk = [];
			for (let i = 0; i < safeN; i++) {
				const result = iterator.next();
				if (result.done) {
					iterator = void 0;
					return chunk.length === 0 ? {
						done: true,
						value: void 0
					} : {
						done: false,
						value: chunk
					};
				}
				chunk.push(result.value);
			}
			return {
				done: false,
				value: chunk
			};
		} };
	} };
});
/**
* Group equal, consecutive elements of an `Iterable` into `NonEmptyArray`s using the provided `isEquivalent` function.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Group consecutive equal numbers
* const numbers = [1, 1, 2, 2, 2, 3, 1, 1]
* const grouped = Iterable.groupWith(numbers, (a, b) => a === b)
* console.log(Array.from(grouped))
* // [[1, 1], [2, 2, 2], [3], [1, 1]]
*
* // Case-insensitive grouping of strings
* const words = ["Apple", "APPLE", "banana", "Banana", "cherry"]
* const caseInsensitive = (a: string, b: string) =>
*   a.toLowerCase() === b.toLowerCase()
* const groupedWords = Iterable.groupWith(words, caseInsensitive)
* console.log(Array.from(groupedWords))
* // [["Apple", "APPLE"], ["banana", "Banana"], ["cherry"]]
*
* // Group by approximate equality
* const floats = [1.1, 1.12, 1.9, 2.01, 2.05, 3.5]
* const approxEqual = (a: number, b: number) => Math.abs(a - b) < 0.2
* const groupedFloats = Iterable.groupWith(floats, approxEqual)
* console.log(Array.from(groupedFloats))
* // [[1.1, 1.12], [1.9, 2.01, 2.05], [3.5]]
*
* // Only groups consecutive elements
* const scattered = [1, 2, 1, 2, 1]
* const scatteredGroups = Iterable.groupWith(scattered, (a, b) => a === b)
* console.log(Array.from(scatteredGroups))
* // [[1], [2], [1], [2], [1]] (no grouping since none are consecutive)
* ```
*
* @category grouping
* @since 2.0.0
*/
var groupWith$1 = /*#__PURE__*/ dual(2, (self, isEquivalent) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let nextResult;
	return { next() {
		let result;
		if (nextResult !== void 0) {
			if (nextResult.done) return {
				done: true,
				value: void 0
			};
			result = nextResult;
			nextResult = void 0;
		} else {
			result = iterator.next();
			if (result.done) return {
				done: true,
				value: void 0
			};
		}
		const chunk = [result.value];
		while (true) {
			const next = iterator.next();
			if (next.done || !isEquivalent(result.value, next.value)) {
				nextResult = next;
				return {
					done: false,
					value: chunk
				};
			}
			chunk.push(next.value);
		}
	} };
} }));
/**
* Group equal, consecutive elements of an `Iterable` into `NonEmptyArray`s.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 1, 2, 2, 2, 3, 1, 1]
* const grouped = Iterable.group(numbers)
* console.log(Array.from(grouped))
* // [[1, 1], [2, 2, 2], [3], [1, 1]]
*
* const letters = "aabbccaa"
* const groupedLetters = Iterable.group(letters)
* console.log(Array.from(groupedLetters))
* // [["a", "a"], ["b", "b"], ["c", "c"], ["a", "a"]]
*
* // Works with objects using deep equality
* const objects = [
*   { type: "A", value: 1 },
*   { type: "A", value: 1 },
*   { type: "B", value: 2 },
*   { type: "A", value: 1 }
* ]
* const groupedObjects = Iterable.group(objects)
* console.log(Array.from(groupedObjects).length) // 3 groups
* // Note: Only consecutive equal objects are grouped together
* ```
*
* @category grouping
* @since 2.0.0
*/
var group$1 = /*#__PURE__*/ groupWith$1(/*#__PURE__*/ asEquivalence());
/**
* Splits an `Iterable` into sub-non-empty-arrays stored in an object, based on the result of calling a `string`-returning
* function on each element, and grouping the results according to values returned
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Group by string length
* const words = ["a", "bb", "ccc", "dd", "eee", "f"]
* const byLength = Iterable.groupBy(words, (word) => word.length.toString())
* console.log(byLength)
* // { "1": ["a", "f"], "2": ["bb", "dd"], "3": ["ccc", "eee"] }
*
* // Group by first letter
* const names = ["Alice", "Bob", "Charlie", "David", "Anna", "Betty"]
* const byFirstLetter = Iterable.groupBy(names, (name) => name[0])
* console.log(byFirstLetter)
* // { "A": ["Alice", "Anna"], "B": ["Bob", "Betty"], "C": ["Charlie"], "D": ["David"] }
*
* // Group by category
* const items = [
*   { name: "apple", category: "fruit" },
*   { name: "carrot", category: "vegetable" },
*   { name: "banana", category: "fruit" },
*   { name: "broccoli", category: "vegetable" }
* ]
* const byCategory = Iterable.groupBy(items, (item) => item.category)
* console.log(byCategory)
* // {
* //   "fruit": [{ name: "apple", category: "fruit" }, { name: "banana", category: "fruit" }],
* //   "vegetable": [{ name: "carrot", category: "vegetable" }, { name: "broccoli", category: "vegetable" }]
* // }
*
* // Group numbers by even/odd
* const numbers = [1, 2, 3, 4, 5, 6]
* const evenOdd = Iterable.groupBy(numbers, (n) => n % 2 === 0 ? "even" : "odd")
* console.log(evenOdd)
* // { "odd": [1, 3, 5], "even": [2, 4, 6] }
* ```
*
* @category grouping
* @since 2.0.0
*/
var groupBy$1 = /*#__PURE__*/ dual(2, (self, f) => {
	const out = {};
	for (const a of self) {
		const k = f(a);
		if (Object.hasOwn(out, k)) out[k].push(a);
		else out[k] = [a];
	}
	return out;
});
var constEmpty = { [Symbol.iterator]() {
	return constEmptyIterator;
} };
var constEmptyIterator = { next() {
	return {
		done: true,
		value: void 0
	};
} };
/**
* Creates an empty iterable that yields no elements.
*
* This function returns a reusable empty iterable that can be used as a base case
* for operations or when you need to represent "no data" in a type-safe way.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const empty = Iterable.empty<string>()
* console.log(Array.from(empty)) // []
* console.log(Iterable.isEmpty(empty)) // true
*
* // Useful as base case for reductions
* const hasData = true
* const result = hasData
*   ? Iterable.range(1, 5)
*   : Iterable.empty<number>()
* ```
*
* @category constructors
* @since 2.0.0
*/
var empty$5 = () => constEmpty;
/**
* Creates an iterable containing a single element.
*
* This is useful for wrapping a single value in an iterable context,
* allowing it to be used with other iterable operations.
*
* @param a - The single element to wrap in an iterable
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const single = Iterable.of(42)
* console.log(Array.from(single)) // [42]
*
* // Useful for creating homogeneous sequences
* const sequences = [
*   Iterable.of("hello"),
*   Iterable.range(1, 3),
*   Iterable.empty<string>()
* ]
*
* // Can be used with flatMap for conditional inclusion
* const numbers = [1, 2, 3, 4, 5]
* const evensOnly = Iterable.flatMap(
*   numbers,
*   (n) => n % 2 === 0 ? Iterable.of(n) : Iterable.empty()
* )
* console.log(Array.from(evensOnly)) // [2, 4]
* ```
*
* @category constructors
* @since 2.0.0
*/
var of$2 = (a) => [a];
/**
* Transforms each element of an iterable using a function.
*
* This is one of the most fundamental operations for working with iterables.
* It applies a transformation function to each element, creating a new iterable
* with the transformed values. The operation is lazy - elements are only
* transformed when the iterable is consumed.
*
* @param self - The source iterable to transform
* @param f - Function that transforms each element (receives value and index)
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Transform numbers to their squares
* const numbers = [1, 2, 3, 4, 5]
* const squares = Iterable.map(numbers, (x) => x * x)
* console.log(Array.from(squares)) // [1, 4, 9, 16, 25]
*
* // Use index in transformation
* const indexed = Iterable.map(["a", "b", "c"], (char, i) => `${i}: ${char}`)
* console.log(Array.from(indexed)) // ["0: a", "1: b", "2: c"]
*
* // Chain transformations
* const result = Iterable.map(
*   Iterable.map([1, 2, 3], (x) => x * 2),
*   (x) => x + 1
* )
* console.log(Array.from(result)) // [3, 5, 7]
* ```
*
* @category mapping
* @since 2.0.0
*/
var map$7 = /*#__PURE__*/ dual(2, (self, f) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let i = 0;
	return { next() {
		const result = iterator.next();
		if (result.done) return {
			done: true,
			value: void 0
		};
		return {
			done: false,
			value: f(result.value, i++)
		};
	} };
} }));
/**
* Applies a function to each element in an Iterable and returns a new Iterable containing the concatenated mapped elements.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Expand each number to a range
* const numbers = [1, 2, 3]
* const expanded = Iterable.flatMap(numbers, (n) => Iterable.range(1, n))
* console.log(Array.from(expanded)) // [1, 1, 2, 1, 2, 3]
*
* // Split strings into characters
* const words = ["hi", "bye"]
* const chars = Iterable.flatMap(words, (word) => word)
* console.log(Array.from(chars)) // ["h", "i", "b", "y", "e"]
*
* // Conditional expansion with empty iterables
* const values = [1, 2, 3, 4, 5]
* const evenMultiples = Iterable.flatMap(
*   values,
*   (n) => n % 2 === 0 ? [n, n * 2, n * 3] : []
* )
* console.log(Array.from(evenMultiples)) // [2, 4, 6, 4, 8, 12]
*
* // Use index in transformation
* const letters = ["a", "b", "c"]
* const indexed = Iterable.flatMap(
*   letters,
*   (letter, i) => Iterable.replicate(letter, i + 1)
* )
* console.log(Array.from(indexed)) // ["a", "b", "b", "c", "c", "c"]
* ```
*
* @category sequencing
* @since 2.0.0
*/
var flatMap$4 = /*#__PURE__*/ dual(2, (self, f) => flatten$3(map$7(self, f)));
/**
* Flattens an Iterable of Iterables into a single Iterable
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Flatten nested arrays
* const nested = [[1, 2], [3, 4], [5, 6]]
* const flat = Iterable.flatten(nested)
* console.log(Array.from(flat)) // [1, 2, 3, 4, 5, 6]
*
* // Flatten different iterable types
* const mixed: Array<Iterable<string>> = ["ab", "cd"]
* const flatMixed = Iterable.flatten(mixed)
* console.log(Array.from(flatMixed)) // ["a", "b", "c", "d"]
*
* // Flatten deeply nested (only one level)
* const deepNested = [[[1, 2]], [[3, 4]]]
* const oneLevelFlat = Iterable.flatten(deepNested)
* console.log(Array.from(oneLevelFlat).map((arr) => Array.from(arr)))
* // [[1, 2], [3, 4]] (still contains arrays)
*
* // Empty iterables are handled correctly
* const withEmpty = [[1, 2], [], [3, 4], []]
* const flatWithEmpty = Iterable.flatten(withEmpty)
* console.log(Array.from(flatWithEmpty)) // [1, 2, 3, 4]
* ```
*
* @category sequencing
* @since 2.0.0
*/
var flatten$3 = (self) => ({ [Symbol.iterator]() {
	const outerIterator = self[Symbol.iterator]();
	let innerIterator;
	function next() {
		if (innerIterator === void 0) {
			const next = outerIterator.next();
			if (next.done) return next;
			innerIterator = next.value[Symbol.iterator]();
		}
		const result = innerIterator.next();
		if (result.done) {
			innerIterator = void 0;
			return next();
		}
		return result;
	}
	return { next };
} });
/**
* Transforms elements of an iterable using a function that returns a `Result`, keeping only successful values.
*
* This combines mapping and filtering in a single operation - the function is applied to each element,
* and only elements that result in `Result.succeed` are included in the result.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Result from "effect/Result"
*
* // Parse strings to numbers, keeping only valid ones
* const strings = ["1", "2", "invalid", "4", "not-a-number"]
* const numbers = Iterable.filterMap(strings, (s) => {
*   const num = parseInt(s)
*   return isNaN(num) ? Result.failVoid : Result.succeed(num)
* })
* console.log(Array.from(numbers)) // [1, 2, 4]
*
* // Extract specific properties from objects
* const users = [
*   { name: "Alice", age: 25, email: "alice@example.com" },
*   { name: "Bob", age: 17, email: undefined },
*   { name: "Charlie", age: 30, email: "charlie@example.com" },
*   { name: "David", age: 16, email: undefined }
* ]
* const adultEmails = Iterable.filterMap(
*   users,
*   (user) =>
*     user.age >= 18 && user.email ? Result.succeed(user.email) : Result.failVoid
* )
* console.log(Array.from(adultEmails)) // ["alice@example.com", "charlie@example.com"]
*
* // Use index in transformation
* const items = ["a", "b", "c", "d", "e"]
* const evenIndexItems = Iterable.filterMap(
*   items,
*   (item, i) => i % 2 === 0 ? Result.succeed(`${i}: ${item}`) : Result.failVoid
* )
* console.log(Array.from(evenIndexItems)) // ["0: a", "2: c", "4: e"]
* ```
*
* @category filtering
* @since 2.0.0
*/
var filterMap$3 = /*#__PURE__*/ dual(2, (self, f) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let i = 0;
	return { next() {
		let result = iterator.next();
		while (!result.done) {
			const next = f(result.value, i++);
			if (isSuccess$3(next)) return {
				done: false,
				value: next.success
			};
			result = iterator.next();
		}
		return {
			done: true,
			value: void 0
		};
	} };
} }));
/**
* Transforms all elements of the `Iterable` for as long as the specified function succeeds.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Result from "effect/Result"
*
* // Parse numbers until we hit an invalid one
* const strings = ["1", "2", "3", "invalid", "4", "5"]
* const numbers = Iterable.filterMapWhile(strings, (s) => {
*   const num = parseInt(s)
*   return isNaN(num) ? Result.failVoid : Result.succeed(num)
* })
* console.log(Array.from(numbers)) // [1, 2, 3] (stops at "invalid")
*
* // Take elements while they meet a condition and transform them
* const values = [2, 4, 6, 7, 8, 10]
* const doubledEvens = Iterable.filterMapWhile(
*   values,
*   (n) => n % 2 === 0 ? Result.succeed(n * 2) : Result.failVoid
* )
* console.log(Array.from(doubledEvens)) // [4, 8, 12] (stops at 7)
*
* // Process with index until condition fails
* const letters = ["a", "b", "c", "d", "e"]
* const indexedUntilC = Iterable.filterMapWhile(
*   letters,
*   (letter, i) => letter !== "c" ? Result.succeed(`${i}: ${letter}`) : Result.failVoid
* )
* console.log(Array.from(indexedUntilC)) // ["0: a", "1: b"] (stops at "c")
* ```
*
* @category filtering
* @since 2.0.0
*/
var filterMapWhile = /*#__PURE__*/ dual(2, (self, f) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let i = 0;
	return { next() {
		const result = iterator.next();
		if (result.done) return {
			done: true,
			value: void 0
		};
		const next = f(result.value, i++);
		if (isSuccess$3(next)) return {
			done: false,
			value: next.success
		};
		return {
			done: true,
			value: void 0
		};
	} };
} }));
/**
* Retrieves the `Some` values from an `Iterable` of `Option`s.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Option from "effect/Option"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Array.from(
*     Iterable.getSomes([Option.some(1), Option.none(), Option.some(2)])
*   ),
*   [1, 2]
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var getSomes$1 = (self) => {
	return { [Symbol.iterator]() {
		const iterator = self[Symbol.iterator]();
		return { next() {
			let result = iterator.next();
			while (!result.done) {
				if (isSome(result.value)) return {
					done: false,
					value: result.value.value
				};
				result = iterator.next();
			}
			return {
				done: true,
				value: void 0
			};
		} };
	} };
};
/**
* Retrieves the `Err` values from an `Iterable` of `Result`s.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Result from "effect/Result"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Array.from(
*     Iterable.getFailures([
*       Result.succeed(1),
*       Result.fail("err"),
*       Result.succeed(2)
*     ])
*   ),
*   ["err"]
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var getFailures$1 = (self) => {
	return { [Symbol.iterator]() {
		const iterator = self[Symbol.iterator]();
		return { next() {
			let result = iterator.next();
			while (!result.done) {
				if (isFailure$3(result.value)) return {
					done: false,
					value: result.value.failure
				};
				result = iterator.next();
			}
			return {
				done: true,
				value: void 0
			};
		} };
	} };
};
/**
* Retrieves the `Ok` values from an `Iterable` of `Result`s.
*
* @example
* ```ts
* import { Iterable } from "effect"
* import * as Result from "effect/Result"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Array.from(
*     Iterable.getSuccesses([
*       Result.succeed(1),
*       Result.fail("err"),
*       Result.succeed(2)
*     ])
*   ),
*   [1, 2]
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var getSuccesses$1 = (self) => {
	return { [Symbol.iterator]() {
		const iterator = self[Symbol.iterator]();
		return { next() {
			let result = iterator.next();
			while (!result.done) {
				if (isSuccess$3(result.value)) return {
					done: false,
					value: result.value.success
				};
				result = iterator.next();
			}
			return {
				done: true,
				value: void 0
			};
		} };
	} };
};
/**
* Filters an iterable to only include elements that match a predicate.
*
* This function creates a new iterable containing only the elements for which
* the predicate function returns true. Like map, this operation is lazy and
* elements are only tested when the iterable is consumed.
*
* @param self - The source iterable to filter
* @param predicate - Function that tests each element (receives value and index)
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Filter even numbers
* const numbers = [1, 2, 3, 4, 5, 6]
* const evens = Iterable.filter(numbers, (x) => x % 2 === 0)
* console.log(Array.from(evens)) // [2, 4, 6]
*
* // Filter with index
* const items = ["a", "b", "c", "d"]
* const oddPositions = Iterable.filter(items, (_, i) => i % 2 === 1)
* console.log(Array.from(oddPositions)) // ["b", "d"]
*
* // Type refinement
* const mixed: Array<string | number> = ["hello", 42, "world", 100]
* const onlyStrings = Iterable.filter(
*   mixed,
*   (x): x is string => typeof x === "string"
* )
* console.log(Array.from(onlyStrings)) // ["hello", "world"] (typed as string[])
*
* // Combine with map
* const processed = Iterable.map(
*   Iterable.filter([1, 2, 3, 4, 5], (x) => x > 2),
*   (x) => x * 10
* )
* console.log(Array.from(processed)) // [30, 40, 50]
* ```
*
* @category filtering
* @since 2.0.0
*/
var filter$3 = /*#__PURE__*/ dual(2, (self, predicate) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let i = 0;
	return { next() {
		let result = iterator.next();
		while (!result.done) {
			if (predicate(result.value, i++)) return {
				done: false,
				value: result.value
			};
			result = iterator.next();
		}
		return {
			done: true,
			value: void 0
		};
	} };
} }));
/**
* Transforms elements using a function that may return null or undefined, filtering out the null/undefined results.
*
* This is useful when working with APIs or functions that return nullable values,
* providing a clean way to filter out null/undefined while transforming.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Extract valid elements from nullable function results
* const data = ["1", "2", "invalid", "4"]
* const parsed = Iterable.flatMapNullishOr(data, (s) => {
*   const num = parseInt(s)
*   return isNaN(num) ? null : num * 2
* })
* console.log(Array.from(parsed)) // [2, 4, 8]
*
* // Safe property access
* const objects = [
*   { nested: { value: 10 } },
*   { nested: null },
*   { nested: { value: 20 } },
*   {}
* ]
* const values = Iterable.flatMapNullishOr(objects, (obj) => obj.nested?.value)
* console.log(Array.from(values)) // [10, 20]
*
* // Working with Map.get (returns undefined for missing keys)
* const map = new Map([
*   ["a", 1],
*   ["b", 2],
*   ["c", 3]
* ])
* const keys = ["a", "x", "b", "y", "c"]
* const foundValues = Iterable.flatMapNullishOr(keys, (key) => map.get(key))
* console.log(Array.from(foundValues)) // [1, 2, 3]
* ```
*
* @category sequencing
* @since 2.0.0
*/
var flatMapNullishOr$1 = /*#__PURE__*/ dual(2, (self, f) => filterMap$3(self, (a) => {
	const b = f(a);
	return b == null ? failVoid : succeed$6(b);
}));
/**
* Check if a predicate holds true for some `Iterable` element.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* const numbers = [1, 3, 5, 7, 8]
* const hasEven = Iterable.some(numbers, (x) => x % 2 === 0)
* console.log(hasEven) // true (because of 8)
*
* const allOdd = [1, 3, 5, 7]
* const hasEvenInAllOdd = Iterable.some(allOdd, (x) => x % 2 === 0)
* console.log(hasEvenInAllOdd) // false
*
* // With index
* const letters = ["a", "b", "c"]
* const hasElementAtIndex2 = Iterable.some(letters, (_, i) => i === 2)
* console.log(hasElementAtIndex2) // true
*
* // Early termination - stops at first match
* const infiniteOdds = Iterable.filter(Iterable.range(1), (x) => x % 2 === 1)
* const hasEvenInInfiniteOdds = Iterable.some(
*   Iterable.take(infiniteOdds, 1000),
*   (x) => x % 2 === 0
* )
* console.log(hasEvenInInfiniteOdds) // false (quickly, doesn't check all 1000)
*
* // Type guard usage
* const mixed: Array<string | number> = [1, 2, "hello"]
* const hasString = Iterable.some(
*   mixed,
*   (x): x is string => typeof x === "string"
* )
* console.log(hasString) // true
* ```
*
* @category elements
* @since 2.0.0
*/
var some$1 = /*#__PURE__*/ dual(2, (self, predicate) => {
	let i = 0;
	for (const a of self) if (predicate(a, i++)) return true;
	return false;
});
/**
* Generates an iterable by repeatedly applying a function that produces the
* next element and state.
*
* This is useful for creating iterables from a generating function that
* maintains state. The function should return `[value, nextState]` to continue
* or `undefined` to stop.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Generate Fibonacci sequence
* const fibonacci = Iterable.unfold([0, 1], ([a, b]) => [a, [b, a + b]])
* const first10Fib = Iterable.take(fibonacci, 10)
* console.log(Array.from(first10Fib)) // [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
*
* // Generate powers of 2 up to a limit
* const powersOf2 = Iterable.unfold(1, (n) => n <= 1000 ? [n, n * 2] : undefined)
* console.log(Array.from(powersOf2)) // [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]
*
* // Generate countdown
* const countdown = Iterable.unfold(5, (n) => n > 0 ? [n, n - 1] : undefined)
* console.log(Array.from(countdown)) // [5, 4, 3, 2, 1]
*
* // Generate collatz sequence
* const collatz = Iterable.unfold(7, (n) => {
*   if (n === 1) return undefined
*   const next = n % 2 === 0 ? n / 2 : n * 3 + 1
*   return [n, next]
* })
* console.log(Array.from(collatz)) // [7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2]
* ```
*
* @category constructors
* @since 2.0.0
*/
var unfold$2 = (b, f) => ({ [Symbol.iterator]() {
	let next = b;
	return { next() {
		const ab = f(next);
		if (ab === void 0) return {
			done: true,
			value: void 0
		};
		const [a, b] = ab;
		next = b;
		return {
			done: false,
			value: a
		};
	} };
} });
/**
* Iterate over the `Iterable` applying `f`.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Print each element
* const numbers = [1, 2, 3, 4, 5]
* Iterable.forEach(numbers, (n) => console.log(n))
* // Prints: 1, 2, 3, 4, 5
*
* // Use index in the callback
* const letters = ["a", "b", "c"]
* Iterable.forEach(letters, (letter, i) => {
*   console.log(`${i}: ${letter}`)
* })
* // Prints: "0: a", "1: b", "2: c"
*
* // Side effects with any iterable
* const results: Array<number> = []
* Iterable.forEach(Iterable.range(1, 5), (n) => {
*   results.push(n * n)
* })
* console.log(results) // [1, 4, 9, 16, 25]
*
* // Process in chunks
* const data = Iterable.chunksOf([1, 2, 3, 4, 5, 6], 2)
* Iterable.forEach(data, (chunk) => {
*   console.log(`Processing chunk: ${Array.from(chunk)}`)
* })
* // Prints: "Processing chunk: 1,2", "Processing chunk: 3,4", "Processing chunk: 5,6"
* ```
*
* @category elements
* @since 2.0.0
*/
var forEach$3 = /*#__PURE__*/ dual(2, (self, f) => {
	let i = 0;
	for (const a of self) f(a, i++);
});
/**
* Reduce an iterable to a single value by applying a function to each element and accumulating the result.
*
* This function applies a reducing function against an accumulator and each element
* of the iterable (from left to right) to reduce it to a single value.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Sum all numbers
* const numbers = [1, 2, 3, 4, 5]
* const sum = Iterable.reduce(numbers, 0, (acc, n) => acc + n)
* console.log(sum) // 15
*
* // Find maximum value
* const values = [3, 1, 4, 1, 5, 9, 2]
* const max = Iterable.reduce(values, -Infinity, Math.max)
* console.log(max) // 9
*
* // Build an object from key-value pairs
* const pairs = [["a", 1], ["b", 2], ["c", 3]] as const
* const obj = Iterable.reduce(
*   pairs,
*   {} as Record<string, number>,
*   (acc, [key, value]) => {
*     acc[key] = value
*     return acc
*   }
* )
* console.log(obj) // { a: 1, b: 2, c: 3 }
*
* // Use index in the reducer
* const letters = ["a", "b", "c"]
* const indexed = Iterable.reduce(
*   letters,
*   [] as Array<string>,
*   (acc, letter, i) => {
*     acc.push(`${i}: ${letter}`)
*     return acc
*   }
* )
* console.log(indexed) // ["0: a", "1: b", "2: c"]
* ```
*
* @category folding
* @since 2.0.0
*/
var reduce$2 = /*#__PURE__*/ dual(3, (self, b, f) => {
	if (Array.isArray(self)) return self.reduce(f, b);
	let i = 0;
	let result = b;
	for (const n of self) result = f(result, n, i++);
	return result;
});
/**
* Deduplicates adjacent elements that are identical using the provided `isEquivalent` function.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Remove adjacent duplicates with custom equality
* const numbers = [1, 1, 2, 2, 3, 1, 1]
* const dedupedNumbers = Iterable.dedupeAdjacentWith(numbers, (a, b) => a === b)
* console.log(Array.from(dedupedNumbers)) // [1, 2, 3, 1]
*
* // Case-insensitive deduplication
* const words = ["Hello", "HELLO", "world", "World", "test"]
* const caseInsensitive = (a: string, b: string) =>
*   a.toLowerCase() === b.toLowerCase()
* const dedupedWords = Iterable.dedupeAdjacentWith(words, caseInsensitive)
* console.log(Array.from(dedupedWords)) // ["Hello", "world", "test"]
*
* // Deduplication by object property
* const users = [
*   { id: 1, name: "Alice" },
*   { id: 1, name: "Alice Updated" }, // different name, same id
*   { id: 2, name: "Bob" },
*   { id: 2, name: "Bob" },
*   { id: 3, name: "Charlie" }
* ]
* const byId = (a: typeof users[0], b: typeof users[0]) => a.id === b.id
* const dedupedUsers = Iterable.dedupeAdjacentWith(users, byId)
* console.log(Array.from(dedupedUsers).map((u) => u.id)) // [1, 2, 3]
*
* // Approximate numeric equality
* const floats = [1.0, 1.01, 1.02, 2.0, 2.01, 3.0]
* const approxEqual = (a: number, b: number) => Math.abs(a - b) < 0.1
* const dedupedFloats = Iterable.dedupeAdjacentWith(floats, approxEqual)
* console.log(Array.from(dedupedFloats)) // [1.0, 2.0, 3.0]
* ```
*
* @category filtering
* @since 2.0.0
*/
var dedupeAdjacentWith$1 = /*#__PURE__*/ dual(2, (self, isEquivalent) => ({ [Symbol.iterator]() {
	const iterator = self[Symbol.iterator]();
	let first = true;
	let last;
	function next() {
		const result = iterator.next();
		if (result.done) return {
			done: true,
			value: void 0
		};
		if (first) {
			first = false;
			last = result.value;
			return result;
		}
		const current = result.value;
		if (isEquivalent(last, current)) return next();
		last = current;
		return result;
	}
	return { next };
} }));
/**
* Deduplicates adjacent elements that are identical.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Remove adjacent duplicate numbers
* const numbers = [1, 1, 2, 2, 2, 3, 1, 1]
* const deduped = Iterable.dedupeAdjacent(numbers)
* console.log(Array.from(deduped)) // [1, 2, 3, 1]
*
* // Remove adjacent duplicate characters
* const letters = "aabbccaa"
* const dedupedLetters = Iterable.dedupeAdjacent(letters)
* console.log(Array.from(dedupedLetters)) // ["a", "b", "c", "a"]
*
* // Works with objects using deep equality
* const objects = [
*   { type: "A" },
*   { type: "A" },
*   { type: "B" },
*   { type: "B" },
*   { type: "A" }
* ]
* const dedupedObjects = Iterable.dedupeAdjacent(objects)
* console.log(Array.from(dedupedObjects).map((o) => o.type)) // ["A", "B", "A"]
*
* // Clean up streaming data
* const sensorData = [100, 100, 100, 101, 101, 102, 102, 102, 100]
* const cleanedData = Iterable.dedupeAdjacent(sensorData)
* console.log(Array.from(cleanedData)) // [100, 101, 102, 100]
* ```
*
* @category filtering
* @since 2.0.0
*/
var dedupeAdjacent$1 = /*#__PURE__*/ dedupeAdjacentWith$1(/*#__PURE__*/ asEquivalence());
/**
* Zips this Iterable crosswise with the specified Iterable using the specified combiner.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // Create coordinate pairs
* const xs = [1, 2]
* const ys = ["a", "b", "c"]
* const coordinates = Iterable.cartesianWith(xs, ys, (x, y) => `(${x},${y})`)
* console.log(Array.from(coordinates)) // ["(1,a)", "(1,b)", "(1,c)", "(2,a)", "(2,b)", "(2,c)"]
*
* // Generate all combinations of options
* const sizes = ["S", "M", "L"]
* const colors = ["red", "blue"]
* const products = Iterable.cartesianWith(
*   sizes,
*   colors,
*   (size, color) => ({ size, color })
* )
* console.log(Array.from(products))
* // [
* //   { size: "S", color: "red" }, { size: "S", color: "blue" },
* //   { size: "M", color: "red" }, { size: "M", color: "blue" },
* //   { size: "L", color: "red" }, { size: "L", color: "blue" }
* // ]
*
* // Mathematical operations on all pairs
* const a = [1, 2, 3]
* const b = [10, 20]
* const mathProducts = Iterable.cartesianWith(a, b, (x, y) => x * y)
* console.log(Array.from(mathProducts)) // [10, 20, 20, 40, 30, 60]
*
* // Create test data combinations
* const userTypes = ["admin", "user"]
* const features = ["read", "write", "delete"]
* const testCases = Iterable.cartesianWith(
*   userTypes,
*   features,
*   (user, feature) => `${user}_can_${feature}`
* )
* console.log(Array.from(testCases))
* // ["admin_can_read", "admin_can_write", "admin_can_delete", "user_can_read", "user_can_write", "user_can_delete"]
* ```
*
* @since 2.0.0
* @category elements
*/
var cartesianWith$1 = /*#__PURE__*/ dual(3, (self, that, f) => flatMap$4(self, (a) => map$7(that, (b) => f(a, b))));
/**
* Zips this Iterable crosswise with the specified Iterable.
*
* @example
* ```ts
* import { Iterable } from "effect"
*
* // All pairs of numbers and letters
* const numbers = [1, 2, 3]
* const letters = ["a", "b"]
* const pairs = Iterable.cartesian(numbers, letters)
* console.log(Array.from(pairs))
* // [[1, "a"], [1, "b"], [2, "a"], [2, "b"], [3, "a"], [3, "b"]]
*
* // Generate coordinate grid
* const x = [0, 1, 2]
* const y = [0, 1]
* const grid = Iterable.cartesian(x, y)
* console.log(Array.from(grid))
* // [[0, 0], [0, 1], [1, 0], [1, 1], [2, 0], [2, 1]]
*
* // All combinations for testing
* const browsers = ["chrome", "firefox"]
* const devices = ["desktop", "mobile", "tablet"]
* const testMatrix = Iterable.cartesian(browsers, devices)
* console.log(Array.from(testMatrix))
* // [
* //   ["chrome", "desktop"], ["chrome", "mobile"], ["chrome", "tablet"],
* //   ["firefox", "desktop"], ["firefox", "mobile"], ["firefox", "tablet"]
* // ]
*
* // Empty iterable results in empty cartesian product
* const empty = Iterable.empty<number>()
* const withEmpty = Iterable.cartesian([1, 2], empty)
* console.log(Array.from(withEmpty)) // []
* ```
*
* @since 2.0.0
* @category elements
*/
var cartesian$1 = /*#__PURE__*/ dual(2, (self, that) => cartesianWith$1(self, that, (a, b) => [a, b]));
/**
* Counts all the element of the given iterable that pass the given predicate
*
* **Example**
*
* ```ts
* import { Iterable } from "effect"
*
* const result = Iterable.countBy([1, 2, 3, 4, 5], (n) => n % 2 === 0)
* console.log(result) // 2
* ```
*
* @category folding
* @since 3.16.0
*/
var countBy$1 = /*#__PURE__*/ dual(2, (self, f) => {
	let count = 0;
	let i = 0;
	for (const a of self) {
		if (f(a, i)) count++;
		i++;
	}
	return count;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Array.js
/**
* Utilities for working with immutable arrays (and non-empty arrays) in a
* functional style. All functions treat arrays as immutable — they return new
* arrays rather than mutating the input.
*
* ## Mental model
*
* - **`Array<A>`** is a standard JS array. All functions in this module return
*   new arrays; the input is never mutated.
* - **`NonEmptyReadonlyArray<A>`** (`readonly [A, ...Array<A>]`) is a readonly
*   array guaranteed to have at least one element. Many functions preserve or
*   require this guarantee at the type level.
* - **`NonEmptyArray<A>`** is the mutable counterpart: `[A, ...Array<A>]`.
* - Most functions are **dual** — they can be called either as
*   `Array.fn(array, arg)` (data-first) or piped as
*   `pipe(array, Array.fn(arg))` (data-last).
* - Functions that access elements by index return `Option<A>` for safety; use
*   the `*NonEmpty` variants (e.g. {@link headNonEmpty}) when you already know
*   the array is non-empty.
* - Set-like operations ({@link union}, {@link intersection},
*   {@link difference}) use `Equal.equivalence()` by default; use the `*With`
*   variants for custom equality.
*
* ## Common tasks
*
* - **Create** an array: {@link make}, {@link of}, {@link empty},
*   {@link fromIterable}, {@link range}, {@link makeBy}, {@link replicate},
*   {@link unfold}
* - **Access** elements: {@link head}, {@link last}, {@link get}, {@link tail},
*   {@link init}
* - **Transform**: {@link map}, {@link flatMap}, {@link flatten}
* - **Filter**: {@link filter}, {@link partition}, {@link dedupe}
* - **Combine**: {@link append}, {@link prepend}, {@link appendAll},
*   {@link prependAll}, {@link zip}, {@link cartesian}
* - **Split**: {@link splitAt}, {@link chunksOf}, {@link span}, {@link window}
* - **Search**: {@link findFirst}, {@link findLast}, {@link contains}
* - **Sort**: {@link sort}, {@link sortBy}, {@link sortWith}
* - **Fold**: {@link reduce}, {@link scan}, {@link join}
* - **Group**: {@link groupBy}, {@link group}, {@link groupWith}
* - **Set operations**: {@link union}, {@link intersection},
*   {@link difference}
* - **Match** on empty vs non-empty: {@link match}, {@link matchLeft},
*   {@link matchRight}
* - **Check** properties: {@link isArray}, {@link isArrayNonEmpty},
*   {@link every}, {@link some}
*
* ## Gotchas
*
* - {@link fromIterable} returns the original array reference when given an
*   array; if you need a copy, use {@link copy}.
* - `sort`, `reverse`, etc. always allocate a new array — the input is never
*   mutated.
* - {@link makeBy} and {@link replicate} normalize `n` to an integer >= 1 —
*   they never produce an empty array.
* - {@link range}`(start, end)` is inclusive on both ends. If `start > end` it
*   returns `[start]`.
* - Functions returning `Option` (e.g. {@link head}, {@link findFirst}) return
*   `Option.none()` for empty inputs — they never throw.
*
* ## Quickstart
*
* **Example** (Basic array operations)
*
* ```ts
* import { Array } from "effect"
*
* const numbers = Array.make(1, 2, 3, 4, 5)
*
* const doubled = Array.map(numbers, (n) => n * 2)
* console.log(doubled) // [2, 4, 6, 8, 10]
*
* const evens = Array.filter(numbers, (n) => n % 2 === 0)
* console.log(evens) // [2, 4]
*
* const sum = Array.reduce(numbers, 0, (acc, n) => acc + n)
* console.log(sum) // 15
* ```
*
* @see {@link make} — create a non-empty array from elements
* @see {@link map} — transform each element
* @see {@link filter} — keep elements matching a predicate
* @see {@link reduce} — fold an array to a single value
*
* @since 2.0.0
*/
var Array_exports = /* @__PURE__ */ __exportAll({
	Array: () => Array$1,
	Do: () => Do$2,
	allocate: () => allocate,
	append: () => append,
	appendAll: () => appendAll,
	bind: () => bind$2,
	bindTo: () => bindTo$2,
	cartesian: () => cartesian,
	cartesianWith: () => cartesianWith,
	chop: () => chop,
	chunksOf: () => chunksOf,
	contains: () => contains,
	containsWith: () => containsWith,
	copy: () => copy,
	countBy: () => countBy,
	dedupe: () => dedupe,
	dedupeAdjacent: () => dedupeAdjacent,
	dedupeAdjacentWith: () => dedupeAdjacentWith,
	dedupeWith: () => dedupeWith,
	difference: () => difference,
	differenceWith: () => differenceWith,
	drop: () => drop,
	dropRight: () => dropRight,
	dropWhile: () => dropWhile,
	dropWhileFilter: () => dropWhileFilter,
	empty: () => empty$4,
	ensure: () => ensure,
	every: () => every,
	extend: () => extend,
	filter: () => filter$2,
	filterMap: () => filterMap$2,
	findFirst: () => findFirst$2,
	findFirstIndex: () => findFirstIndex,
	findFirstWithIndex: () => findFirstWithIndex,
	findLast: () => findLast,
	findLastIndex: () => findLastIndex,
	flatMap: () => flatMap$3,
	flatMapNullishOr: () => flatMapNullishOr,
	flatten: () => flatten$2,
	forEach: () => forEach$2,
	fromIterable: () => fromIterable,
	fromNullishOr: () => fromNullishOr$2,
	fromOption: () => fromOption$2,
	fromRecord: () => fromRecord,
	get: () => get$1,
	getFailures: () => getFailures,
	getReadonlyReducerConcat: () => getReadonlyReducerConcat,
	getSomes: () => getSomes,
	getSuccesses: () => getSuccesses,
	getUnsafe: () => getUnsafe$1,
	group: () => group,
	groupBy: () => groupBy,
	groupWith: () => groupWith,
	head: () => head,
	headNonEmpty: () => headNonEmpty,
	init: () => init,
	initNonEmpty: () => initNonEmpty,
	insertAt: () => insertAt,
	intersection: () => intersection,
	intersectionWith: () => intersectionWith,
	intersperse: () => intersperse,
	isArray: () => isArray,
	isArrayEmpty: () => isArrayEmpty,
	isArrayNonEmpty: () => isArrayNonEmpty,
	isOutOfBounds: () => isOutOfBounds,
	isReadonlyArrayEmpty: () => isReadonlyArrayEmpty,
	isReadonlyArrayNonEmpty: () => isReadonlyArrayNonEmpty,
	join: () => join,
	last: () => last,
	lastNonEmpty: () => lastNonEmpty,
	length: () => length$1,
	let: () => let_$2,
	liftNullishOr: () => liftNullishOr,
	liftOption: () => liftOption,
	liftPredicate: () => liftPredicate,
	liftResult: () => liftResult,
	make: () => make$9,
	makeBy: () => makeBy,
	makeEquivalence: () => makeEquivalence,
	makeOrder: () => makeOrder,
	makeReducerConcat: () => makeReducerConcat,
	map: () => map$6,
	mapAccum: () => mapAccum,
	match: () => match$8,
	matchLeft: () => matchLeft,
	matchRight: () => matchRight,
	max: () => max$3,
	min: () => min$3,
	modify: () => modify$1,
	modifyHeadNonEmpty: () => modifyHeadNonEmpty,
	modifyLastNonEmpty: () => modifyLastNonEmpty,
	of: () => of$1,
	pad: () => pad,
	partition: () => partition$2,
	prepend: () => prepend,
	prependAll: () => prependAll,
	range: () => range,
	reduce: () => reduce$1,
	reduceRight: () => reduceRight,
	remove: () => remove,
	replace: () => replace$1,
	replicate: () => replicate$2,
	reverse: () => reverse,
	rotate: () => rotate,
	scan: () => scan,
	scanRight: () => scanRight,
	separate: () => separate,
	setHeadNonEmpty: () => setHeadNonEmpty,
	setLastNonEmpty: () => setLastNonEmpty,
	some: () => some,
	sort: () => sort,
	sortBy: () => sortBy,
	sortWith: () => sortWith,
	span: () => span$1,
	split: () => split$1,
	splitAt: () => splitAt,
	splitAtNonEmpty: () => splitAtNonEmpty,
	splitWhere: () => splitWhere,
	tail: () => tail,
	tailNonEmpty: () => tailNonEmpty,
	take: () => take$1,
	takeRight: () => takeRight$1,
	takeWhile: () => takeWhile,
	takeWhileFilter: () => takeWhileFilter,
	unappend: () => unappend,
	unfold: () => unfold$1,
	union: () => union,
	unionWith: () => unionWith,
	unprepend: () => unprepend,
	unzip: () => unzip,
	window: () => window,
	zip: () => zip$3,
	zipWith: () => zipWith$3
});
/**
* Reference to the global `Array` constructor.
*
* Use this when you need the native `Array` constructor while the `Array`
* namespace is in scope (e.g. `Array.Array.isArray`, `Array.Array.from`).
*
* **Example** (Using the Array constructor)
*
* ```ts
* import { Array } from "effect"
*
* const arr = new Array.Array(3)
* console.log(arr) // [undefined, undefined, undefined]
* ```
*
* @category constructors
* @since 4.0.0
*/
var Array$1 = globalThis.Array;
/**
* Creates a `NonEmptyArray` from one or more elements.
*
* - Use when you have literal values and want a typed non-empty array.
* - The element type is inferred as the union of all arguments.
* - Always returns a `NonEmptyArray` since at least one argument is required.
*
* **Example** (Creating an array from values)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.make(1, 2, 3)
* console.log(result) // [1, 2, 3]
* ```
*
* @see {@link of} — create a single-element array
* @see {@link fromIterable} — create from any iterable
*
* @category constructors
* @since 2.0.0
*/
var make$9 = (...elements) => elements;
/**
* Creates a new `Array` of the specified length with all slots uninitialized.
*
* - Use when you need a pre-sized array and will fill it imperatively.
* - Elements are typed as `A | undefined` since slots are empty.
* - Prefer {@link makeBy} when you can compute each element from its index.
*
* **Example** (Allocating a fixed-size array)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.allocate<number>(3)
* console.log(result.length) // 3
* ```
*
* @see {@link makeBy} — create an array by computing each element
*
* @category constructors
* @since 2.0.0
*/
var allocate = (n) => new Array$1(n);
/**
* Creates a `NonEmptyArray` of length `n` where element `i` is computed by `f(i)`.
*
* - Use when you need an array whose values depend on the index.
* - `n` is normalized to an integer >= 1 — always returns at least one element.
* - Dual: `Array.makeBy(5, f)` or `pipe(5, Array.makeBy(f))`.
*
* **Example** (Generating values from indices)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.makeBy(5, (n) => n * 2)
* console.log(result) // [0, 2, 4, 6, 8]
* ```
*
* @see {@link range} — create a range of integers
* @see {@link replicate} — repeat a single value
*
* @category constructors
* @since 2.0.0
*/
var makeBy = /*#__PURE__*/ dual(2, (n, f) => {
	const max = Math.max(1, Math.floor(n));
	const out = new Array$1(max);
	for (let i = 0; i < max; i++) out[i] = f(i);
	return out;
});
/**
* Creates a `NonEmptyArray` containing a range of integers, inclusive on both
* ends.
*
* - Use when you need a sequence of consecutive integers.
* - If `start > end`, returns `[start]`.
* - Always returns a `NonEmptyArray`.
*
* **Example** (Creating a range)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.range(1, 3)
* console.log(result) // [1, 2, 3]
* ```
*
* @see {@link makeBy} — generate values from a function
*
* @category constructors
* @since 2.0.0
*/
var range = (start, end) => start <= end ? makeBy(end - start + 1, (i) => start + i) : [start];
/**
* Creates a `NonEmptyArray` containing a value repeated `n` times.
*
* - Use when you need multiple copies of the same value.
* - `n` is normalized to an integer >= 1 — always returns at least one element.
* - Dual: `Array.replicate("a", 3)` or `pipe("a", Array.replicate(3))`.
*
* **Example** (Repeating a value)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.replicate("a", 3)
* console.log(result) // ["a", "a", "a"]
* ```
*
* @see {@link makeBy} — vary values based on index
*
* @category constructors
* @since 2.0.0
*/
var replicate$2 = /*#__PURE__*/ dual(2, (a, n) => makeBy(n, () => a));
/**
* Converts an `Iterable` to an `Array`.
*
* - If the input is already an array, returns it **by reference** (no copy).
* - Otherwise, creates a new array from the iterable.
* - Use {@link copy} if you need a fresh array even when the input is already
*   an array.
*
* **Example** (Converting a Set to an array)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.fromIterable(new Set([1, 2, 3]))
* console.log(result) // [1, 2, 3]
* ```
*
* @see {@link ensure} — wrap a single value or return an existing array
* @see {@link copy} — create a shallow copy of an array
*
* @category constructors
* @since 2.0.0
*/
var fromIterable = (collection) => Array$1.isArray(collection) ? collection : Array$1.from(collection);
/**
* Normalizes a value that is either a single element or an array into an array.
*
* - If the input is already an array, returns it by reference.
* - If the input is a single value, wraps it in a one-element array.
* - Useful for APIs that accept `A | Array<A>`.
*
* **Example** (Normalizing input)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.ensure("a")) // ["a"]
* console.log(Array.ensure(["a", "b", "c"])) // ["a", "b", "c"]
* ```
*
* @see {@link of} — always wrap in a single-element array
* @see {@link fromIterable} — convert any iterable
*
* @category constructors
* @since 3.3.0
*/
var ensure = (self) => Array$1.isArray(self) ? self : [self];
/**
* Converts a record into an array of `[key, value]` tuples.
*
* - Key order follows `Object.entries` semantics.
* - Returns an empty array for an empty record.
*
* **Example** (Record to entries)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.fromRecord({ a: 1, b: 2, c: 3 })
* console.log(result) // [["a", 1], ["b", 2], ["c", 3]]
* ```
*
* @category conversions
* @since 2.0.0
*/
var fromRecord = toEntries;
/**
* Converts an `Option` to an array: `Some(a)` becomes `[a]`, `None` becomes `[]`.
*
* **Example** (Option to array)
*
* ```ts
* import { Array, Option } from "effect"
*
* console.log(Array.fromOption(Option.some(1))) // [1]
* console.log(Array.fromOption(Option.none())) // []
* ```
*
* @see {@link getSomes} — extract `Some` values from an array of Options
*
* @category conversions
* @since 2.0.0
*/
var fromOption$2 = toArray;
/**
* Pattern-matches on an array, handling empty and non-empty cases separately.
*
* - Use when you need to branch on whether an array has elements.
* - `onNonEmpty` receives a `NonEmptyReadonlyArray`.
* - Dual: data-first or data-last.
*
* **Example** (Branching on emptiness)
*
* ```ts
* import { Array } from "effect"
*
* const describe = Array.match({
*   onEmpty: () => "empty",
*   onNonEmpty: ([head, ...tail]) => `head: ${head}, tail: ${tail.length}`
* })
* console.log(describe([])) // "empty"
* console.log(describe([1, 2, 3])) // "head: 1, tail: 2"
* ```
*
* @see {@link matchLeft} — destructures into head + tail
* @see {@link matchRight} — destructures into init + last
*
* @category pattern matching
* @since 2.0.0
*/
var match$8 = /*#__PURE__*/ dual(2, (self, { onEmpty, onNonEmpty }) => isReadonlyArrayNonEmpty(self) ? onNonEmpty(self) : onEmpty());
/**
* Pattern-matches on an array from the left, providing the first element and
* the remaining elements separately.
*
* - `onNonEmpty` receives `(head, tail)` where `tail` is the rest of the array.
* - Use when you want to process the first element differently from the rest.
*
* **Example** (Head and tail destructuring)
*
* ```ts
* import { Array } from "effect"
*
* const matchLeft = Array.matchLeft({
*   onEmpty: () => "empty",
*   onNonEmpty: (head, tail) => `head: ${head}, tail: ${tail.length}`
* })
* console.log(matchLeft([])) // "empty"
* console.log(matchLeft([1, 2, 3])) // "head: 1, tail: 2"
* ```
*
* @see {@link match} — receives the full non-empty array
* @see {@link matchRight} — destructures into init + last
*
* @category pattern matching
* @since 2.0.0
*/
var matchLeft = /*#__PURE__*/ dual(2, (self, { onEmpty, onNonEmpty }) => isReadonlyArrayNonEmpty(self) ? onNonEmpty(headNonEmpty(self), tailNonEmpty(self)) : onEmpty());
/**
* Pattern-matches on an array from the right, providing all elements except the
* last and the last element separately.
*
* - `onNonEmpty` receives `(init, last)` where `init` is everything but the last element.
* - Use when you want to process the last element differently from the rest.
*
* **Example** (Init and last destructuring)
*
* ```ts
* import { Array } from "effect"
*
* const matchRight = Array.matchRight({
*   onEmpty: () => "empty",
*   onNonEmpty: (init, last) => `init: ${init.length}, last: ${last}`
* })
* console.log(matchRight([])) // "empty"
* console.log(matchRight([1, 2, 3])) // "init: 2, last: 3"
* ```
*
* @see {@link match} — receives the full non-empty array
* @see {@link matchLeft} — destructures into head + tail
*
* @category pattern matching
* @since 2.0.0
*/
var matchRight = /*#__PURE__*/ dual(2, (self, { onEmpty, onNonEmpty }) => isReadonlyArrayNonEmpty(self) ? onNonEmpty(initNonEmpty(self), lastNonEmpty(self)) : onEmpty());
/**
* Adds a single element to the front of an iterable, returning a `NonEmptyArray`.
*
* - Always returns a non-empty array.
* - Does not mutate the input.
*
* **Example** (Prepending an element)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.prepend([2, 3, 4], 1)
* console.log(result) // [1, 2, 3, 4]
* ```
*
* @see {@link append} — add to the end
* @see {@link prependAll} — prepend multiple elements
*
* @category concatenating
* @since 2.0.0
*/
var prepend = /*#__PURE__*/ dual(2, (self, head) => [head, ...self]);
/**
* Prepends all elements from a prefix iterable to the front of an array.
*
* - If either input is non-empty, the result is a `NonEmptyArray`.
* - Does not mutate the input.
*
* **Example** (Prepending multiple elements)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.prependAll([2, 3], [0, 1])
* console.log(result) // [0, 1, 2, 3]
* ```
*
* @see {@link prepend} — add a single element to the front
* @see {@link appendAll} — add elements to the end
*
* @category concatenating
* @since 2.0.0
*/
var prependAll = /*#__PURE__*/ dual(2, (self, that) => fromIterable(that).concat(fromIterable(self)));
/**
* Adds a single element to the end of an iterable, returning a `NonEmptyArray`.
*
* - Always returns a non-empty array.
* - Does not mutate the input.
*
* **Example** (Appending an element)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.append([1, 2, 3], 4)
* console.log(result) // [1, 2, 3, 4]
* ```
*
* @see {@link prepend} — add to the front
* @see {@link appendAll} — append multiple elements
*
* @category concatenating
* @since 2.0.0
*/
var append = /*#__PURE__*/ dual(2, (self, last) => [...self, last]);
/**
* Concatenates two iterables into a single array.
*
* - If either input is non-empty, the result is a `NonEmptyArray`.
* - Does not mutate the inputs.
*
* **Example** (Concatenating arrays)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.appendAll([1, 2], [3, 4])
* console.log(result) // [1, 2, 3, 4]
* ```
*
* @see {@link append} — add a single element to the end
* @see {@link prependAll} — add elements to the front
*
* @category concatenating
* @since 2.0.0
*/
var appendAll = /*#__PURE__*/ dual(2, (self, that) => fromIterable(self).concat(fromIterable(that)));
/**
* Left-to-right fold that keeps every intermediate accumulator value.
*
* - The output length is `input.length + 1` (starts with the initial value).
* - Always returns a `NonEmptyArray` because the initial value is included.
* - Use {@link reduce} if you only need the final accumulated value.
*
* **Example** (Running totals)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.scan([1, 2, 3, 4], 0, (acc, value) => acc + value)
* console.log(result) // [0, 1, 3, 6, 10]
* ```
*
* @see {@link scanRight} — right-to-left scan
* @see {@link reduce} — fold without intermediate values
*
* @category folding
* @since 2.0.0
*/
var scan = /*#__PURE__*/ dual(3, (self, b, f) => {
	const out = [b];
	let i = 0;
	for (const a of self) {
		out[i + 1] = f(out[i], a);
		i++;
	}
	return out;
});
/**
* Right-to-left fold that keeps every intermediate accumulator value.
*
* - The output length is `input.length + 1` (ends with the initial value).
* - Always returns a `NonEmptyArray`.
*
* **Example** (Reverse running totals)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.scanRight([1, 2, 3, 4], 0, (acc, value) => acc + value)
* console.log(result) // [10, 9, 7, 4, 0]
* ```
*
* @see {@link scan} — left-to-right scan
* @see {@link reduceRight} — fold without intermediate values
*
* @category folding
* @since 2.0.0
*/
var scanRight = /*#__PURE__*/ dual(3, (self, b, f) => {
	const input = fromIterable(self);
	const out = new Array$1(input.length + 1);
	out[input.length] = b;
	for (let i = input.length - 1; i >= 0; i--) out[i] = f(out[i + 1], input[i]);
	return out;
});
/**
* Tests whether a value is an `Array`.
*
* - Acts as a type guard narrowing the input to `Array<unknown>`.
* - Delegates to `globalThis.Array.isArray`.
*
* **Example** (Type-guarding an unknown value)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.isArray(null)) // false
* console.log(Array.isArray([1, 2, 3])) // true
* ```
*
* @see {@link isArrayEmpty} — check for an empty array
* @see {@link isArrayNonEmpty} — check for a non-empty array
*
* @category guards
* @since 2.0.0
*/
var isArray = Array$1.isArray;
/**
* Tests whether a mutable `Array` is empty, narrowing the type to `[]`.
*
* **Example** (Checking for an empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.isArrayEmpty([])) // true
* console.log(Array.isArrayEmpty([1, 2, 3])) // false
* ```
*
* @see {@link isReadonlyArrayEmpty} — readonly variant
* @see {@link isArrayNonEmpty} — opposite check
*
* @category guards
* @since 2.0.0
*/
var isArrayEmpty = (self) => self.length === 0;
/**
* Tests whether a `ReadonlyArray` is empty, narrowing the type to `readonly []`.
*
* **Example** (Checking for an empty readonly array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.isReadonlyArrayEmpty([])) // true
* console.log(Array.isReadonlyArrayEmpty([1, 2, 3])) // false
* ```
*
* @see {@link isArrayEmpty} — mutable variant
* @see {@link isReadonlyArrayNonEmpty} — opposite check
*
* @category guards
* @since 2.0.0
*/
var isReadonlyArrayEmpty = isArrayEmpty;
/**
* Tests whether a mutable `Array` is non-empty, narrowing the type to
* `NonEmptyArray`.
*
* **Example** (Checking for a non-empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.isArrayNonEmpty([])) // false
* console.log(Array.isArrayNonEmpty([1, 2, 3])) // true
* ```
*
* @see {@link isReadonlyArrayNonEmpty} — readonly variant
* @see {@link isArrayEmpty} — opposite check
*
* @category guards
* @since 2.0.0
*/
var isArrayNonEmpty = isArrayNonEmpty$1;
/**
* Tests whether a `ReadonlyArray` is non-empty, narrowing the type to
* `NonEmptyReadonlyArray`.
*
* **Example** (Checking for a non-empty readonly array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.isReadonlyArrayNonEmpty([])) // false
* console.log(Array.isReadonlyArrayNonEmpty([1, 2, 3])) // true
* ```
*
* @see {@link isArrayNonEmpty} — mutable variant
* @see {@link isReadonlyArrayEmpty} — opposite check
*
* @category guards
* @since 2.0.0
*/
var isReadonlyArrayNonEmpty = isArrayNonEmpty$1;
/**
* Returns the number of elements in a `ReadonlyArray`.
*
* **Example** (Getting the length)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.length([1, 2, 3])) // 3
* ```
*
* @category getters
* @since 2.0.0
*/
var length$1 = (self) => self.length;
/** @internal */
function isOutOfBounds(i, as) {
	return i < 0 || i >= as.length;
}
var clamp$3 = (i, as) => Math.floor(Math.min(Math.max(0, i), as.length));
/**
* Safely reads an element at the given index, returning `Option.some` or
* `Option.none` if the index is out of bounds.
*
* - The index is floored to an integer.
* - Never throws.
*
* **Example** (Safe index access)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.get([1, 2, 3], 1)) // Some(2)
* console.log(Array.get([1, 2, 3], 10)) // None
* ```
*
* @see {@link getUnsafe} — throws on out of bounds
* @see {@link head} — get the first element
* @see {@link last} — get the last element
*
* @category getters
* @since 2.0.0
*/
var get$1 = /*#__PURE__*/ dual(2, (self, index) => {
	const i = Math.floor(index);
	return isOutOfBounds(i, self) ? none() : some$2(self[i]);
});
/**
* Reads an element at the given index, throwing if the index is out of bounds.
*
* - Throws an `Error` with the message `"Index out of bounds: <i>"`.
* - Prefer {@link get} for safe access.
*
* **Example** (Unsafe index access)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.getUnsafe([1, 2, 3], 1)) // 2
* // Array.getUnsafe([1, 2, 3], 10) // throws Error
* ```
*
* @see {@link get} — safe version returning `Option`
*
* @since 2.0.0
* @category unsafe
*/
var getUnsafe$1 = /*#__PURE__*/ dual(2, (self, index) => {
	const i = Math.floor(index);
	if (isOutOfBounds(i, self)) throw new Error(`Index out of bounds: ${i}`);
	return self[i];
});
/**
* Splits a non-empty array into its first element and the remaining elements.
*
* - Returns a tuple `[head, tail]`.
* - Requires a `NonEmptyReadonlyArray`.
*
* **Example** (Destructuring head and tail)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.unprepend([1, 2, 3, 4])
* console.log(result) // [1, [2, 3, 4]]
* ```
*
* @see {@link unappend} — split into init + last
* @see {@link headNonEmpty} — get only the head
* @see {@link tailNonEmpty} — get only the tail
*
* @category splitting
* @since 2.0.0
*/
var unprepend = (self) => [headNonEmpty(self), tailNonEmpty(self)];
/**
* Splits a non-empty array into all elements except the last, and the last
* element.
*
* - Returns a tuple `[init, last]`.
* - Requires a `NonEmptyReadonlyArray`.
*
* **Example** (Destructuring init and last)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.unappend([1, 2, 3, 4])
* console.log(result) // [[1, 2, 3], 4]
* ```
*
* @see {@link unprepend} — split into head + tail
* @see {@link initNonEmpty} — get only the init
* @see {@link lastNonEmpty} — get only the last
*
* @category splitting
* @since 2.0.0
*/
var unappend = (self) => [initNonEmpty(self), lastNonEmpty(self)];
/**
* Returns the first element of an array wrapped in `Option.some`, or
* `Option.none` if the array is empty.
*
* **Example** (Getting the first element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.head([1, 2, 3])) // Some(1)
* console.log(Array.head([])) // None
* ```
*
* @see {@link headNonEmpty} — direct access when array is known non-empty
* @see {@link last} — get the last element
*
* @category getters
* @since 2.0.0
*/
var head = /*#__PURE__*/ get$1(0);
/**
* Returns the first element of a `NonEmptyReadonlyArray` directly (no `Option`
* wrapper).
*
* **Example** (Getting the head of a non-empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.headNonEmpty([1, 2, 3, 4])) // 1
* ```
*
* @see {@link head} — safe version for possibly-empty arrays
*
* @category getters
* @since 2.0.0
*/
var headNonEmpty = /*#__PURE__*/ getUnsafe$1(0);
/**
* Returns the last element of an array wrapped in `Option.some`, or
* `Option.none` if the array is empty.
*
* **Example** (Getting the last element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.last([1, 2, 3])) // Some(3)
* console.log(Array.last([])) // None
* ```
*
* @see {@link lastNonEmpty} — direct access when array is known non-empty
* @see {@link head} — get the first element
*
* @category getters
* @since 2.0.0
*/
var last = (self) => isReadonlyArrayNonEmpty(self) ? some$2(lastNonEmpty(self)) : none();
/**
* Returns the last element of a `NonEmptyReadonlyArray` directly (no `Option`
* wrapper).
*
* **Example** (Getting the last of a non-empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.lastNonEmpty([1, 2, 3, 4])) // 4
* ```
*
* @see {@link last} — safe version for possibly-empty arrays
*
* @category getters
* @since 2.0.0
*/
var lastNonEmpty = (self) => self[self.length - 1];
/**
* Returns all elements except the first, or `undefined` if the array is empty.
*
* - Allocates a new array via `slice(1)`.
* - Returns `undefined` (not `Option`) for empty inputs.
*
* **Example** (Getting the tail)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.tail([1, 2, 3, 4])) // [2, 3, 4]
* console.log(Array.tail([])) // undefined
* ```
*
* @see {@link tailNonEmpty} — when the array is known non-empty
* @see {@link init} — all elements except the last
*
* @category getters
* @since 2.0.0
*/
function tail(self) {
	const as = fromIterable(self);
	return isReadonlyArrayNonEmpty(as) ? tailNonEmpty(as) : void 0;
}
/**
* Returns all elements except the first of a `NonEmptyReadonlyArray`.
*
* **Example** (Getting the tail of a non-empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.tailNonEmpty([1, 2, 3, 4])) // [2, 3, 4]
* ```
*
* @see {@link tail} — safe version for possibly-empty arrays
* @see {@link initNonEmpty} — all elements except the last
*
* @category getters
* @since 2.0.0
*/
var tailNonEmpty = (self) => self.slice(1);
/**
* Returns all elements except the last, or `undefined` if the array is empty.
*
* - Allocates a new array via `slice(0, -1)`.
* - Returns `undefined` (not `Option`) for empty inputs.
*
* **Example** (Getting init)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.init([1, 2, 3, 4])) // [1, 2, 3]
* console.log(Array.init([])) // undefined
* ```
*
* @see {@link initNonEmpty} — when the array is known non-empty
* @see {@link tail} — all elements except the first
*
* @category getters
* @since 2.0.0
*/
function init(self) {
	const as = fromIterable(self);
	return isReadonlyArrayNonEmpty(as) ? initNonEmpty(as) : void 0;
}
/**
* Returns all elements except the last of a `NonEmptyReadonlyArray`.
*
* **Example** (Getting init of a non-empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.initNonEmpty([1, 2, 3, 4])) // [1, 2, 3]
* ```
*
* @see {@link init} — safe version for possibly-empty arrays
* @see {@link tailNonEmpty} — all elements except the first
*
* @category getters
* @since 2.0.0
*/
var initNonEmpty = (self) => self.slice(0, -1);
/**
* Keeps the first `n` elements, creating a new array.
*
* - `n` is clamped to `[0, length]`.
* - Returns an empty array when `n <= 0`.
*
* **Example** (Taking from the start)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.take([1, 2, 3, 4, 5], 3)) // [1, 2, 3]
* ```
*
* @see {@link takeRight} — keep from the end
* @see {@link takeWhile} — keep while predicate holds
* @see {@link drop} — remove from the start
*
* @category getters
* @since 2.0.0
*/
var take$1 = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	return input.slice(0, clamp$3(n, input));
});
/**
* Keeps the last `n` elements, creating a new array.
*
* - `n` is clamped to `[0, length]`.
* - Returns an empty array when `n <= 0`.
*
* **Example** (Taking from the end)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.takeRight([1, 2, 3, 4, 5], 3)) // [3, 4, 5]
* ```
*
* @see {@link take} — keep from the start
* @see {@link dropRight} — remove from the end
*
* @category getters
* @since 2.0.0
*/
var takeRight$1 = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	const i = clamp$3(n, input);
	return i === 0 ? [] : input.slice(-i);
});
/**
* Takes elements from the start while the predicate holds, stopping at the
* first element that fails.
*
* - Supports refinements for type narrowing.
* - The predicate receives `(element, index)`.
*
* **Example** (Taking while condition holds)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.takeWhile([1, 3, 2, 4, 1, 2], (x) => x < 4)) // [1, 3, 2]
* ```
*
* @see {@link take} — take a fixed count
* @see {@link dropWhile} — drop while predicate holds
* @see {@link span} — split into matching prefix + rest
*
* @category getters
* @since 2.0.0
*/
var takeWhile = /*#__PURE__*/ dual(2, (self, predicate) => {
	let i = 0;
	const out = [];
	for (const a of self) {
		if (!predicate(a, i)) break;
		out.push(a);
		i++;
	}
	return out;
});
/**
* Takes elements from the start while a `Filter` succeeds, collecting transformed values.
*
* - The filter receives `(element, index)`.
* - Stops at the first filter failure.
*
* @category getters
* @since 4.0.0
*/
var takeWhileFilter = /*#__PURE__*/ dual(2, (self, f) => {
	let i = 0;
	const out = [];
	for (const a of self) {
		const result = f(a, i);
		if (isFailure$3(result)) break;
		out.push(result.success);
		i++;
	}
	return out;
});
var spanIndex = (self, predicate) => {
	let i = 0;
	for (const a of self) {
		if (!predicate(a, i)) break;
		i++;
	}
	return i;
};
/**
* Splits an iterable into two arrays: the longest prefix where the predicate
* holds, and the remaining elements.
*
* - Equivalent to `[takeWhile(pred), dropWhile(pred)]` but more efficient
*   (single pass).
* - Supports refinements for type narrowing of the prefix.
*
* **Example** (Splitting at predicate boundary)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.span([1, 3, 2, 4, 5], (x) => x % 2 === 1)) // [[1, 3], [2, 4, 5]]
* ```
*
* @see {@link takeWhile} — keep only the matching prefix
* @see {@link dropWhile} — keep only the rest
* @see {@link splitWhere} — split at the first element matching a predicate
*
* @category splitting
* @since 2.0.0
*/
var span$1 = /*#__PURE__*/ dual(2, (self, predicate) => {
	const input = fromIterable(self);
	return splitAt(input, spanIndex(input, predicate));
});
/**
* Removes the first `n` elements, creating a new array.
*
* - `n` is clamped to `[0, length]`.
* - Returns a copy of the full array when `n <= 0`.
*
* **Example** (Dropping from the start)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.drop([1, 2, 3, 4, 5], 2)) // [3, 4, 5]
* ```
*
* @see {@link dropRight} — remove from the end
* @see {@link dropWhile} — remove while predicate holds
* @see {@link take} — keep from the start
*
* @category getters
* @since 2.0.0
*/
var drop = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	return input.slice(clamp$3(n, input), input.length);
});
/**
* Removes the last `n` elements, creating a new array.
*
* - `n` is clamped to `[0, length]`.
*
* **Example** (Dropping from the end)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.dropRight([1, 2, 3, 4, 5], 2)) // [1, 2, 3]
* ```
*
* @see {@link drop} — remove from the start
* @see {@link takeRight} — keep from the end
*
* @category getters
* @since 2.0.0
*/
var dropRight = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	return input.slice(0, input.length - clamp$3(n, input));
});
/**
* Drops elements from the start while the predicate holds, returning the rest.
*
* - The predicate receives `(element, index)`.
*
* **Example** (Dropping while condition holds)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.dropWhile([1, 2, 3, 4, 5], (x) => x < 4)) // [4, 5]
* ```
*
* @see {@link takeWhile} — keep the matching prefix instead
* @see {@link drop} — drop a fixed count
*
* @category getters
* @since 2.0.0
*/
var dropWhile = /*#__PURE__*/ dual(2, (self, predicate) => {
	const input = fromIterable(self);
	let i = 0;
	while (i < input.length) {
		if (!predicate(input[i], i)) break;
		i++;
	}
	return input.slice(i);
});
/**
* Drops elements from the start while a `Filter` succeeds.
*
* - The filter receives `(element, index)`.
* - Returns the remaining original elements after the first filter failure.
*
* @category getters
* @since 4.0.0
*/
var dropWhileFilter = /*#__PURE__*/ dual(2, (self, f) => {
	const input = fromIterable(self);
	let i = 0;
	while (i < input.length) {
		if (isFailure$3(f(input[i], i))) break;
		i++;
	}
	return input.slice(i);
});
/**
* Returns the index of the first element matching the predicate, or `undefined`
* if none match.
*
* **Example** (Finding an index)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.findFirstIndex([5, 3, 8, 9], (x) => x > 5)) // 2
* ```
*
* @see {@link findLastIndex} — search from the end
* @see {@link findFirst} — get the element itself
*
* @category elements
* @since 2.0.0
*/
var findFirstIndex = /*#__PURE__*/ dual(2, (self, predicate) => {
	let i = 0;
	for (const a of self) {
		if (predicate(a, i)) return i;
		i++;
	}
});
/**
* Returns the index of the last element matching the predicate, or `undefined`
* if none match.
*
* **Example** (Finding the last matching index)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.findLastIndex([1, 3, 8, 9], (x) => x < 5)) // 1
* ```
*
* @see {@link findFirstIndex} — search from the start
* @see {@link findLast} — get the element itself
*
* @category elements
* @since 2.0.0
*/
var findLastIndex = /*#__PURE__*/ dual(2, (self, predicate) => {
	const input = fromIterable(self);
	for (let i = input.length - 1; i >= 0; i--) if (predicate(input[i], i)) return i;
});
/**
* Returns the first element matching a predicate, refinement, or mapping
* function, wrapped in `Option`.
*
* - Accepts a predicate `(a, i) => boolean`, a refinement, or a function
*   `(a, i) => Option<B>` for simultaneous find-and-transform.
* - Returns `Option.none()` if no element matches.
*
* **Example** (Finding the first match)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.findFirst([1, 2, 3, 4, 5], (x) => x > 3)) // Option.some(4)
* ```
*
* @see {@link findLast} — search from the end
* @see {@link findFirstIndex} — get the index instead
* @see {@link findFirstWithIndex} — get both element and index
*
* @category elements
* @since 2.0.0
*/
var findFirst$2 = findFirst$3;
/**
* Returns a tuple `[element, index]` of the first element matching a
* predicate, or `undefined` if none match.
*
* **Example** (Finding element with its index)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.findFirstWithIndex([1, 2, 3, 4, 5], (x) => x > 3)) // [4, 3]
* ```
*
* @see {@link findFirst} — get only the element
* @see {@link findFirstIndex} — get only the index
*
* @category elements
* @since 3.17.0
*/
var findFirstWithIndex = /*#__PURE__*/ dual(2, (self, f) => {
	let i = 0;
	for (const a of self) {
		const o = f(a, i);
		if (typeof o === "boolean") {
			if (o) return [a, i];
		} else if (isSome(o)) return [o.value, i];
		i++;
	}
});
/**
* Returns the last element matching a predicate, refinement, or mapping
* function, wrapped in `Option`.
*
* - Searches from the end of the array.
* - Returns `Option.none()` if no element matches.
*
* **Example** (Finding the last match)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.findLast([1, 2, 3, 4, 5], (n) => n % 2 === 0)) // Option.some(4)
* ```
*
* @see {@link findFirst} — search from the start
* @see {@link findLastIndex} — get the index instead
*
* @category elements
* @since 2.0.0
*/
var findLast = /*#__PURE__*/ dual(2, (self, f) => {
	const input = fromIterable(self);
	for (let i = input.length - 1; i >= 0; i--) {
		const a = input[i];
		const o = f(a, i);
		if (typeof o === "boolean") {
			if (o) return some$2(a);
		} else if (isSome(o)) return o;
	}
	return none();
});
/**
* Inserts an element at the specified index, returning a new `NonEmptyArray`,
* or `undefined` if the index is out of bounds.
*
* - Valid indices: `0` to `length` (inclusive — inserting at `length` appends).
* - Does not mutate the input.
*
* **Example** (Inserting at an index)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.insertAt(["a", "b", "c", "e"], 3, "d")) // ["a", "b", "c", "d", "e"]
* ```
*
* @see {@link replace} — replace an existing element
* @see {@link modify} — transform an element at an index
*
* @category elements
* @since 2.0.0
*/
var insertAt = /*#__PURE__*/ dual(3, (self, i, b) => {
	const out = Array$1.from(self);
	if (i < 0 || i > out.length) return;
	out.splice(i, 0, b);
	return out;
});
/**
* Replaces the element at the specified index with a new value, returning a new
* array, or `undefined` if the index is out of bounds.
*
* - Does not mutate the input.
*
* **Example** (Replacing an element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.replace([1, 2, 3], 1, 4)) // [1, 4, 3]
* ```
*
* @see {@link modify} — transform an element with a function
* @see {@link insertAt} — insert without removing
*
* @category elements
* @since 2.0.0
*/
var replace$1 = /*#__PURE__*/ dual(3, (self, i, b) => modify$1(self, i, () => b));
/**
* Applies a function to the element at the specified index, returning a new
* array, or `undefined` if the index is out of bounds.
*
* - Does not mutate the input.
*
* **Example** (Modifying an element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.modify([1, 2, 3, 4], 2, (n) => n * 2)) // [1, 2, 6, 4]
* console.log(Array.modify([1, 2, 3, 4], 5, (n) => n * 2)) // undefined
* ```
*
* @see {@link replace} — set a fixed value at an index
* @see {@link modifyHeadNonEmpty} — modify the first element
* @see {@link modifyLastNonEmpty} — modify the last element
*
* @category elements
* @since 2.0.0
*/
var modify$1 = /*#__PURE__*/ dual(3, (self, i, f) => {
	const arr = Array$1.from(self);
	if (isOutOfBounds(i, arr)) return;
	const out = arr;
	out[i] = f(arr[i]);
	return out;
});
/**
* Removes the element at the specified index, returning a new array. If the
* index is out of bounds, returns a copy of the original.
*
* - Does not mutate the input.
*
* **Example** (Removing an element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.remove([1, 2, 3, 4], 2)) // [1, 2, 4]
* console.log(Array.remove([1, 2, 3, 4], 5)) // [1, 2, 3, 4]
* ```
*
* @see {@link insertAt} — insert an element
* @see {@link filter} — remove elements by predicate
*
* @category elements
* @since 2.0.0
*/
var remove = /*#__PURE__*/ dual(2, (self, i) => {
	const out = Array$1.from(self);
	if (isOutOfBounds(i, out)) return out;
	out.splice(i, 1);
	return out;
});
/**
* Reverses an iterable into a new array.
*
* - Does not mutate the input.
* - Preserves `NonEmptyArray` in the return type.
*
* **Example** (Reversing an array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.reverse([1, 2, 3, 4])) // [4, 3, 2, 1]
* ```
*
* @category elements
* @since 2.0.0
*/
var reverse = (self) => Array$1.from(self).reverse();
/**
* Sorts an array by the given `Order`, returning a new array.
*
* - Does not mutate the input.
* - Preserves `NonEmptyArray` in the return type.
* - Use {@link sortWith} to sort by a derived key, or {@link sortBy} for
*   multi-key sorting.
*
* **Example** (Sorting numbers)
*
* ```ts
* import { Array, Order } from "effect"
*
* console.log(Array.sort([3, 1, 4, 1, 5], Order.Number)) // [1, 1, 3, 4, 5]
* ```
*
* @see {@link sortWith} — sort by a mapping function
* @see {@link sortBy} — sort by multiple orders
*
* @category sorting
* @since 2.0.0
*/
var sort = /*#__PURE__*/ dual(2, (self, O) => {
	const out = Array$1.from(self);
	out.sort(O);
	return out;
});
/**
* Sorts an array by a derived key using a mapping function and an `Order` for
* that key.
*
* - Equivalent to `sort(Order.mapInput(order, f))` but more convenient.
* - Does not mutate the input.
*
* **Example** (Sorting strings by length)
*
* ```ts
* import { Array, Order } from "effect"
*
* console.log(Array.sortWith(["aaa", "b", "cc"], (s) => s.length, Order.Number))
* // ["b", "cc", "aaa"]
* ```
*
* @see {@link sort} — sort by a direct `Order`
* @see {@link sortBy} — sort by multiple orders
*
* @since 2.0.0
* @category elements
*/
var sortWith = /*#__PURE__*/ dual(3, (self, f, order) => Array$1.from(self).map((a) => [a, f(a)]).sort(([, a], [, b]) => order(a, b)).map(([_]) => _));
/**
* Sorts an array by multiple `Order`s applied in sequence: the first order is
* used first; ties are broken by the second order, and so on.
*
* - Data-last only (returns a function).
* - Preserves `NonEmptyArray` in the return type.
*
* **Example** (Multi-key sorting)
*
* ```ts
* import { Array, Order, pipe } from "effect"
*
* const users = [
*   { name: "Alice", age: 30 },
*   { name: "Bob", age: 25 },
*   { name: "Charlie", age: 30 }
* ]
*
* const result = pipe(
*   users,
*   Array.sortBy(
*     Order.mapInput(Order.Number, (user: (typeof users)[number]) => user.age),
*     Order.mapInput(Order.String, (user: (typeof users)[number]) => user.name)
*   )
* )
* console.log(result)
* // [{ name: "Bob", age: 25 }, { name: "Alice", age: 30 }, { name: "Charlie", age: 30 }]
* ```
*
* @see {@link sort} — sort by a single `Order`
* @see {@link sortWith} — sort by a derived key
*
* @category sorting
* @since 2.0.0
*/
var sortBy = (...orders) => {
	const sortByAll = sort(combineAll(orders));
	return (self) => {
		const input = fromIterable(self);
		if (isReadonlyArrayNonEmpty(input)) return sortByAll(input);
		return [];
	};
};
/**
* Pairs elements from two iterables by position. If the iterables differ in
* length, the extra elements from the longer one are discarded.
*
* - Returns `NonEmptyArray` when both inputs are non-empty.
*
* **Example** (Zipping two arrays)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.zip([1, 2, 3], ["a", "b"])) // [[1, "a"], [2, "b"]]
* ```
*
* @see {@link zipWith} — zip with a combiner function
* @see {@link unzip} — inverse operation
*
* @category zipping
* @since 2.0.0
*/
var zip$3 = /*#__PURE__*/ dual(2, (self, that) => zipWith$3(self, that, make$10));
/**
* Combines elements from two iterables pairwise using a function. If the
* iterables differ in length, extra elements are discarded.
*
* **Example** (Zipping with addition)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.zipWith([1, 2, 3], [4, 5, 6], (a, b) => a + b)) // [5, 7, 9]
* ```
*
* @see {@link zip} — zip into tuples
*
* @category zipping
* @since 2.0.0
*/
var zipWith$3 = /*#__PURE__*/ dual(3, (self, that, f) => {
	const as = fromIterable(self);
	const bs = fromIterable(that);
	if (isReadonlyArrayNonEmpty(as) && isReadonlyArrayNonEmpty(bs)) {
		const out = [f(headNonEmpty(as), headNonEmpty(bs))];
		const len = Math.min(as.length, bs.length);
		for (let i = 1; i < len; i++) out[i] = f(as[i], bs[i]);
		return out;
	}
	return [];
});
/**
* Splits an array of pairs into two arrays. Inverse of {@link zip}.
*
* **Example** (Unzipping pairs)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.unzip([[1, "a"], [2, "b"], [3, "c"]])) // [[1, 2, 3], ["a", "b", "c"]]
* ```
*
* @see {@link zip} — combine two arrays into pairs
*
* @category zipping
* @since 2.0.0
*/
var unzip = (self) => {
	const input = fromIterable(self);
	if (isReadonlyArrayNonEmpty(input)) {
		const fa = [input[0][0]];
		const fb = [input[0][1]];
		for (let i = 1; i < input.length; i++) {
			fa[i] = input[i][0];
			fb[i] = input[i][1];
		}
		return [fa, fb];
	}
	return [[], []];
};
/**
* Places a separator element between every pair of elements.
*
* - Preserves `NonEmptyArray` in the return type.
* - An empty input produces an empty result.
*
* **Example** (Interspersing a separator)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.intersperse([1, 2, 3], 0)) // [1, 0, 2, 0, 3]
* ```
*
* @see {@link join} — intersperse and join into a string
*
* @category elements
* @since 2.0.0
*/
var intersperse = /*#__PURE__*/ dual(2, (self, middle) => {
	const input = fromIterable(self);
	if (isReadonlyArrayNonEmpty(input)) {
		const out = [headNonEmpty(input)];
		const tail = tailNonEmpty(input);
		for (let i = 0; i < tail.length; i++) {
			if (i < tail.length) out.push(middle);
			out.push(tail[i]);
		}
		return out;
	}
	return [];
});
/**
* Applies a function to the first element of a non-empty array, returning a
* new array.
*
* **Example** (Modifying the head)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.modifyHeadNonEmpty([1, 2, 3], (n) => n * 10)) // [10, 2, 3]
* ```
*
* @see {@link setHeadNonEmpty} — replace with a fixed value
* @see {@link modifyLastNonEmpty} — modify the last element
*
* @category elements
* @since 2.0.0
*/
var modifyHeadNonEmpty = /*#__PURE__*/ dual(2, (self, f) => [f(headNonEmpty(self)), ...tailNonEmpty(self)]);
/**
* Replaces the first element of a non-empty array with a new value.
*
* **Example** (Setting the head)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.setHeadNonEmpty([1, 2, 3], 10)) // [10, 2, 3]
* ```
*
* @see {@link modifyHeadNonEmpty} — transform the head with a function
* @see {@link setLastNonEmpty} — replace the last element
*
* @category elements
* @since 2.0.0
*/
var setHeadNonEmpty = /*#__PURE__*/ dual(2, (self, b) => modifyHeadNonEmpty(self, () => b));
/**
* Applies a function to the last element of a non-empty array, returning a
* new array.
*
* **Example** (Modifying the last element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.modifyLastNonEmpty([1, 2, 3], (n) => n * 2)) // [1, 2, 6]
* ```
*
* @see {@link setLastNonEmpty} — replace with a fixed value
* @see {@link modifyHeadNonEmpty} — modify the first element
*
* @category elements
* @since 2.0.0
*/
var modifyLastNonEmpty = /*#__PURE__*/ dual(2, (self, f) => append(initNonEmpty(self), f(lastNonEmpty(self))));
/**
* Replaces the last element of a non-empty array with a new value.
*
* **Example** (Setting the last element)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.setLastNonEmpty([1, 2, 3], 4)) // [1, 2, 4]
* ```
*
* @see {@link modifyLastNonEmpty} — transform the last element with a function
* @see {@link setHeadNonEmpty} — replace the first element
*
* @category elements
* @since 2.0.0
*/
var setLastNonEmpty = /*#__PURE__*/ dual(2, (self, b) => modifyLastNonEmpty(self, () => b));
/**
* Rotates an array by `n` steps. Positive `n` rotates left (front elements
* move to the back).
*
* - Preserves `NonEmptyArray` in the return type.
* - Returns a copy for empty arrays or `n === 0`.
*
* **Example** (Rotating elements)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.rotate(["a", "b", "c", "d"], 2)) // ["c", "d", "a", "b"]
* ```
*
* @category elements
* @since 2.0.0
*/
var rotate = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	if (isReadonlyArrayNonEmpty(input)) {
		const len = input.length;
		const m = Math.round(n) % len;
		if (isOutOfBounds(Math.abs(m), input) || m === 0) return copy(input);
		if (m < 0) {
			const [f, s] = splitAtNonEmpty(input, -m);
			return appendAll(s, f);
		} else return rotate(self, m - len);
	}
	return [];
});
/**
* Returns a membership-test function using a custom equivalence.
*
* **Example** (Custom equality check)
*
* ```ts
* import { Array, pipe } from "effect"
*
* const containsNumber = Array.containsWith((a: number, b: number) => a === b)
* console.log(pipe([1, 2, 3, 4], containsNumber(3))) // true
* ```
*
* @see {@link contains} — uses default `Equal.equivalence()`
*
* @category elements
* @since 2.0.0
*/
var containsWith = (isEquivalent) => dual(2, (self, a) => {
	for (const i of self) if (isEquivalent(a, i)) return true;
	return false;
});
/**
* Tests whether an array contains a value, using `Equal.equivalence()` for
* comparison.
*
* **Example** (Checking membership)
*
* ```ts
* import { Array, pipe } from "effect"
*
* console.log(pipe(["a", "b", "c", "d"], Array.contains("c"))) // true
* ```
*
* @see {@link containsWith} — use custom equality
*
* @category elements
* @since 2.0.0
*/
var contains = /*#__PURE__*/ containsWith(/*#__PURE__*/ asEquivalence());
/**
* Repeatedly applies a function that consumes a prefix of the array and
* produces a value plus the remaining elements, collecting the values.
*
* - The function receives a `NonEmptyReadonlyArray` and returns
*   `[value, rest]`.
* - Continues until the remaining array is empty.
* - Useful for custom splitting/grouping logic.
*
* **Example** (Chopping an array)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.chop(
*   [1, 2, 3, 4, 5],
*   (as): [number, Array<number>] => [as[0] * 2, as.slice(1)]
* )
* console.log(result) // [2, 4, 6, 8, 10]
* ```
*
* @see {@link chunksOf} — split into fixed-size chunks
* @see {@link splitAt} — split at an index
*
* @category elements
* @since 2.0.0
*/
var chop = /*#__PURE__*/ dual(2, (self, f) => {
	const input = fromIterable(self);
	if (isReadonlyArrayNonEmpty(input)) {
		const [b, rest] = f(input);
		const out = [b];
		let next = rest;
		while (isArrayNonEmpty$1(next)) {
			const [b, rest] = f(next);
			out.push(b);
			next = rest;
		}
		return out;
	}
	return [];
});
/**
* Splits an iterable into two arrays at the given index.
*
* - `n` can be `0` (all elements in the second array).
* - `n` is floored to an integer.
*
* **Example** (Splitting at an index)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.splitAt([1, 2, 3, 4, 5], 3)) // [[1, 2, 3], [4, 5]]
* ```
*
* @see {@link splitAtNonEmpty} — for non-empty arrays
* @see {@link splitWhere} — split at a predicate boundary
*
* @category splitting
* @since 2.0.0
*/
var splitAt = /*#__PURE__*/ dual(2, (self, n) => {
	const input = Array$1.from(self);
	const _n = Math.floor(n);
	if (isReadonlyArrayNonEmpty(input)) {
		if (_n >= 1) return splitAtNonEmpty(input, _n);
		return [[], input];
	}
	return [input, []];
});
/**
* Splits a non-empty array into two parts at the given index. The first part
* is guaranteed to be non-empty (`n` is clamped to >= 1).
*
* **Example** (Splitting a non-empty array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.splitAtNonEmpty(["a", "b", "c", "d", "e"], 3))
* // [["a", "b", "c"], ["d", "e"]]
* ```
*
* @see {@link splitAt} — for possibly-empty arrays
*
* @category splitting
* @since 2.0.0
*/
var splitAtNonEmpty = /*#__PURE__*/ dual(2, (self, n) => {
	const _n = Math.max(1, Math.floor(n));
	return _n >= self.length ? [copy(self), []] : [prepend(self.slice(1, _n), headNonEmpty(self)), self.slice(_n)];
});
/**
* Splits an iterable into `n` roughly equal-sized chunks.
*
* - Uses `chunksOf(ceil(length / n))` internally.
* - The last chunk may be shorter.
*
* **Example** (Splitting into groups)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.split([1, 2, 3, 4, 5, 6, 7, 8], 3)) // [[1, 2, 3], [4, 5, 6], [7, 8]]
* ```
*
* @see {@link chunksOf} — split into fixed-size chunks
*
* @since 2.0.0
* @category splitting
*/
var split$1 = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	return chunksOf(input, Math.ceil(input.length / Math.floor(n)));
});
/**
* Splits an iterable at the first element matching the predicate. The matching
* element is included in the second array.
*
* **Example** (Splitting at a condition)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.splitWhere([1, 2, 3, 4, 5], (n) => n > 3)) // [[1, 2, 3], [4, 5]]
* ```
*
* @see {@link span} — splits at the first element that fails the predicate
* @see {@link splitAt} — split at a fixed index
*
* @category splitting
* @since 2.0.0
*/
var splitWhere = /*#__PURE__*/ dual(2, (self, predicate) => span$1(self, (a, i) => !predicate(a, i)));
/**
* Creates a shallow copy of an array.
*
* - Preserves `NonEmptyArray` in the return type.
* - Useful when you need a distinct reference (e.g. before mutating).
*
* **Example** (Copying an array)
*
* ```ts
* import { Array } from "effect"
*
* const original = [1, 2, 3]
* const copied = Array.copy(original)
* console.log(copied) // [1, 2, 3]
* console.log(original === copied) // false
* ```
*
* @see {@link fromIterable} — returns the same reference for arrays
*
* @category elements
* @since 2.0.0
*/
var copy = (self) => self.slice();
/**
* Pads or truncates an array to exactly `n` elements, filling with `fill`
* if the array is shorter, or slicing if longer.
*
* - Returns an empty array when `n <= 0`.
*
* **Example** (Padding an array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.pad([1, 2, 3], 6, 0)) // [1, 2, 3, 0, 0, 0]
* ```
*
* @see {@link take} — truncate without padding
* @see {@link replicate} — create an array of a single repeated value
*
* @category elements
* @since 3.8.4
*/
var pad = /*#__PURE__*/ dual(3, (self, n, fill) => {
	if (self.length >= n) return take$1(self, n);
	return appendAll(self, makeBy(n - self.length, () => fill));
});
/**
* Splits an iterable into chunks of length `n`. The last chunk may be shorter
* if `n` does not evenly divide the length.
*
* - `chunksOf(n)([])` is `[]`, not `[[]]`.
* - Each chunk is a `NonEmptyArray`.
* - Preserves `NonEmptyArray` in the outer return type.
*
* **Example** (Chunking an array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.chunksOf([1, 2, 3, 4, 5], 2)) // [[1, 2], [3, 4], [5]]
* ```
*
* @see {@link split} — split into a given number of groups
* @see {@link window} — sliding windows
*
* @category splitting
* @since 2.0.0
*/
var chunksOf = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	if (isReadonlyArrayNonEmpty(input)) return chop(input, splitAtNonEmpty(n));
	return [];
});
/**
* Creates overlapping sliding windows of size `n`.
*
* - Returns an empty array if `n <= 0` or the array has fewer than `n` elements.
* - Each window is a tuple of exactly `n` elements.
*
* **Example** (Sliding windows)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.window([1, 2, 3, 4, 5], 3)) // [[1, 2, 3], [2, 3, 4], [3, 4, 5]]
* console.log(Array.window([1, 2, 3, 4, 5], 6)) // []
* ```
*
* @see {@link chunksOf} — non-overlapping chunks
*
* @category splitting
* @since 3.13.2
*/
var window = /*#__PURE__*/ dual(2, (self, n) => {
	const input = fromIterable(self);
	if (n > 0 && isReadonlyArrayNonEmpty(input)) return Array$1.from({ length: input.length - (n - 1) }, (_, index) => input.slice(index, index + n));
	return [];
});
/**
* Groups consecutive equal elements using a custom equivalence function.
*
* - Only groups **adjacent** elements — non-adjacent duplicates stay separate.
* - Requires a `NonEmptyReadonlyArray`.
*
* **Example** (Grouping consecutive equal elements)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.groupWith(["a", "a", "b", "b", "b", "c", "a"], (x, y) => x === y))
* // [["a", "a"], ["b", "b", "b"], ["c"], ["a"]]
* ```
*
* @see {@link group} — uses default equality
* @see {@link groupBy} — group by a key function into a record
*
* @category grouping
* @since 2.0.0
*/
var groupWith = /*#__PURE__*/ dual(2, (self, isEquivalent) => chop(self, (as) => {
	const h = headNonEmpty(as);
	const out = [h];
	let i = 1;
	for (; i < as.length; i++) {
		const a = as[i];
		if (isEquivalent(a, h)) out.push(a);
		else break;
	}
	return [out, as.slice(i)];
}));
/**
* Groups consecutive equal elements using `Equal.equivalence()`.
*
* - Only groups **adjacent** elements.
*
* **Example** (Grouping adjacent equal elements)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.group([1, 1, 2, 2, 2, 3, 1])) // [[1, 1], [2, 2, 2], [3], [1]]
* ```
*
* @see {@link groupWith} — use custom equality
* @see {@link groupBy} — group by a key function into a record
*
* @category grouping
* @since 2.0.0
*/
var group = /*#__PURE__*/ groupWith(/*#__PURE__*/ asEquivalence());
/**
* Groups elements into a record by a key-returning function. Each key maps
* to a `NonEmptyArray` of elements that produced that key.
*
* - Unlike {@link group}/{@link groupWith}, elements do not need to be
*   adjacent to be grouped together.
* - Key function must return a `string` or `symbol`.
*
* **Example** (Grouping by a property)
*
* ```ts
* import { Array } from "effect"
*
* const people = [
*   { name: "Alice", group: "A" },
*   { name: "Bob", group: "B" },
*   { name: "Charlie", group: "A" }
* ]
*
* const result = Array.groupBy(people, (person) => person.group)
* console.log(result)
* // { A: [{ name: "Alice", group: "A" }, { name: "Charlie", group: "A" }], B: [{ name: "Bob", group: "B" }] }
* ```
*
* @see {@link group} — group adjacent equal elements
* @see {@link groupWith} — group adjacent elements by custom equality
*
* @category grouping
* @since 2.0.0
*/
var groupBy = /*#__PURE__*/ dual(2, (self, f) => {
	const out = {};
	for (const a of self) {
		const k = f(a);
		if (Object.hasOwn(out, k)) out[k].push(a);
		else out[k] = [a];
	}
	return out;
});
/**
* Computes the union of two arrays using a custom equivalence, removing
* duplicates.
*
* **Example** (Union with custom equality)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.unionWith([1, 2], [2, 3], (a, b) => a === b)) // [1, 2, 3]
* ```
*
* @see {@link union} — uses default equality
* @see {@link intersection} — elements in both arrays
* @see {@link difference} — elements only in the first array
*
* @category elements
* @since 2.0.0
*/
var unionWith = /*#__PURE__*/ dual(3, (self, that, isEquivalent) => {
	const a = fromIterable(self);
	const b = fromIterable(that);
	if (isReadonlyArrayNonEmpty(a)) {
		if (isReadonlyArrayNonEmpty(b)) return dedupeWith(isEquivalent)(appendAll(a, b));
		return a;
	}
	return b;
});
/**
* Computes the union of two arrays, removing duplicates using
* `Equal.equivalence()`.
*
* **Example** (Array union)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.union([1, 2], [2, 3])) // [1, 2, 3]
* ```
*
* @see {@link unionWith} — use custom equality
* @see {@link intersection} — elements in both arrays
* @see {@link difference} — elements only in the first array
*
* @category elements
* @since 2.0.0
*/
var union = /*#__PURE__*/ dual(2, (self, that) => unionWith(self, that, asEquivalence()));
/**
* Computes the intersection of two arrays using a custom equivalence. Order is
* determined by the first array.
*
* **Example** (Intersection with custom equality)
*
* ```ts
* import { Array } from "effect"
*
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }]
* const array2 = [{ id: 3 }, { id: 4 }, { id: 1 }]
* const isEquivalent = (a: { id: number }, b: { id: number }) => a.id === b.id
* console.log(Array.intersectionWith(isEquivalent)(array2)(array1)) // [{ id: 1 }, { id: 3 }]
* ```
*
* @see {@link intersection} — uses default equality
* @see {@link union} — elements in either array
* @see {@link difference} — elements only in the first array
*
* @category elements
* @since 2.0.0
*/
var intersectionWith = (isEquivalent) => {
	const has = containsWith(isEquivalent);
	return dual(2, (self, that) => {
		const thatArray = fromIterable(that);
		return fromIterable(self).filter((a) => has(thatArray, a));
	});
};
/**
* Computes the intersection of two arrays using `Equal.equivalence()`. Order is
* determined by the first array.
*
* **Example** (Array intersection)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.intersection([1, 2, 3], [3, 4, 1])) // [1, 3]
* ```
*
* @see {@link intersectionWith} — use custom equality
* @see {@link union} — elements in either array
* @see {@link difference} — elements only in the first array
*
* @category elements
* @since 2.0.0
*/
var intersection = /*#__PURE__*/ intersectionWith(/*#__PURE__*/ asEquivalence());
/**
* Computes elements in the first array that are not in the second, using a
* custom equivalence.
*
* **Example** (Difference with custom equality)
*
* ```ts
* import { Array } from "effect"
*
* const diff = Array.differenceWith<number>((a, b) => a === b)([1, 2, 3], [2, 3, 4])
* console.log(diff) // [1]
* ```
*
* @see {@link difference} — uses default equality
* @see {@link union} — elements in either array
* @see {@link intersection} — elements in both arrays
*
* @category elements
* @since 2.0.0
*/
var differenceWith = (isEquivalent) => {
	const has = containsWith(isEquivalent);
	return dual(2, (self, that) => {
		const thatArray = fromIterable(that);
		return fromIterable(self).filter((a) => !has(thatArray, a));
	});
};
/**
* Computes elements in the first array that are not in the second, using
* `Equal.equivalence()`.
*
* **Example** (Array difference)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.difference([1, 2, 3], [2, 3, 4])) // [1]
* ```
*
* @see {@link differenceWith} — use custom equality
* @see {@link union} — elements in either array
* @see {@link intersection} — elements in both arrays
*
* @category elements
* @since 2.0.0
*/
var difference = /*#__PURE__*/ differenceWith(/*#__PURE__*/ asEquivalence());
/**
* Creates an empty array.
*
* **Example** (Creating an empty array)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.empty<number>()
* console.log(result) // []
* ```
*
* @see {@link of} — create a single-element array
* @see {@link make} — create from multiple values
*
* @category constructors
* @since 2.0.0
*/
var empty$4 = () => [];
/**
* Wraps a single value in a `NonEmptyArray`.
*
* **Example** (Creating a single-element array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.of(1)) // [1]
* ```
*
* @see {@link make} — create from multiple values
* @see {@link empty} — create an empty array
*
* @category constructors
* @since 2.0.0
*/
var of$1 = (a) => [a];
/**
* Transforms each element using a function, returning a new array.
*
* - The function receives `(element, index)`.
* - Preserves `NonEmptyArray` in the return type.
*
* **Example** (Doubling values)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.map([1, 2, 3], (x) => x * 2)) // [2, 4, 6]
* ```
*
* @see {@link flatMap} — map and flatten
*
* @category mapping
* @since 2.0.0
*/
var map$6 = /*#__PURE__*/ dual(2, (self, f) => self.map(f));
/**
* Maps each element to an array and flattens the results into a single array.
*
* - The function receives `(element, index)`.
* - Returns `NonEmptyArray` when both input and mapped arrays are non-empty.
*
* **Example** (FlatMapping an array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.flatMap([1, 2, 3], (x) => [x, x * 2])) // [1, 2, 2, 4, 3, 6]
* ```
*
* @see {@link map} — transform without flattening
* @see {@link flatten} — flatten without mapping
*
* @category sequencing
* @since 2.0.0
*/
var flatMap$3 = /*#__PURE__*/ dual(2, (self, f) => {
	if (isReadonlyArrayEmpty(self)) return [];
	const out = [];
	for (let i = 0; i < self.length; i++) {
		const inner = f(self[i], i);
		for (let j = 0; j < inner.length; j++) out.push(inner[j]);
	}
	return out;
});
/**
* Flattens a nested array of arrays into a single array.
*
* **Example** (Flattening nested arrays)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.flatten([[1, 2], [], [3, 4], [], [5, 6]])) // [1, 2, 3, 4, 5, 6]
* ```
*
* @see {@link flatMap} — map then flatten in one step
*
* @category sequencing
* @since 2.0.0
*/
var flatten$2 = /*#__PURE__*/ flatMap$3(identity);
/**
* Extracts all `Some` values from an iterable of `Option`s, discarding `None`s.
*
* **Example** (Extracting Some values)
*
* ```ts
* import { Array, Option } from "effect"
*
* console.log(Array.getSomes([Option.some(1), Option.none(), Option.some(2)])) // [1, 2]
* ```
*
* @see {@link fromOption} — convert a single Option
* @see {@link getSuccesses} — extract successes from Results
*
* @category filtering
* @since 2.0.0
*/
var getSomes = (self) => {
	const out = [];
	for (const a of self) if (isSome(a)) out.push(a.value);
	return out;
};
/**
* Extracts all failure values from an iterable of `Result`s, discarding
* successes.
*
* **Example** (Extracting failures)
*
* ```ts
* import { Array, Result } from "effect"
*
* console.log(Array.getFailures([Result.succeed(1), Result.fail("err"), Result.succeed(2)]))
* // ["err"]
* ```
*
* @see {@link getSuccesses} — extract success values
* @see {@link separate} — split into failures and successes
*
* @category filtering
* @since 2.0.0
*/
var getFailures = (self) => {
	const out = [];
	for (const a of self) if (isFailure$3(a)) out.push(a.failure);
	return out;
};
/**
* Extracts all success values from an iterable of `Result`s, discarding
* failures.
*
* **Example** (Extracting successes)
*
* ```ts
* import { Array, Result } from "effect"
*
* console.log(Array.getSuccesses([Result.succeed(1), Result.fail("err"), Result.succeed(2)]))
* // [1, 2]
* ```
*
* @see {@link getFailures} — extract failure values
* @see {@link separate} — split into failures and successes
*
* @category filtering
* @since 2.0.0
*/
var getSuccesses = (self) => {
	const out = [];
	for (const a of self) if (isSuccess$3(a)) out.push(a.success);
	return out;
};
/**
* Keeps transformed values for elements where a `Filter` succeeds.
*
* - The filter receives `(element, index)`.
* - Failures are discarded.
*
* **Example** (Filter and transform)
*
* ```ts
* import { Array, Result } from "effect"
*
* console.log(Array.filterMap([1, 2, 3, 4], (n) => n % 2 === 0 ? Result.succeed(n * 10) : Result.failVoid))
* // [20, 40]
* ```
*
* @see {@link filter} — keep original elements matching a predicate
*
* @category filtering
* @since 4.0.0
*/
var filterMap$2 = /*#__PURE__*/ dual(2, (self, f) => {
	const as = fromIterable(self);
	const out = [];
	for (let i = 0; i < as.length; i++) {
		const result = f(as[i], i);
		if (isSuccess$3(result)) out.push(result.success);
	}
	return out;
});
/**
* Keeps only elements satisfying a predicate (or refinement).
*
* - The predicate receives `(element, index)`.
* - Supports refinements for type narrowing.
*
* **Example** (Filtering even numbers)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.filter([1, 2, 3, 4], (x) => x % 2 === 0)) // [2, 4]
* ```
*
* @see {@link partition} — split into matching and non-matching
*
* @category filtering
* @since 2.0.0
*/
var filter$2 = /*#__PURE__*/ dual(2, (self, predicate) => {
	const as = fromIterable(self);
	const out = [];
	for (let i = 0; i < as.length; i++) if (predicate(as[i], i)) out.push(as[i]);
	return out;
});
/**
* Splits an iterable using a `Filter` into failures and successes.
*
* - Returns `[excluded, satisfying]`.
* - The filter receives `(element, index)`.
*
* **Example** (Partitioning with a filter)
*
* ```ts
* import { Array, Result } from "effect"
*
* console.log(Array.partition([1, -2, 3], (n, i) =>
*   n > 0 ? Result.succeed(n + i) : Result.fail(`negative:${n}`)
* ))
* // [["negative:-2"], [1, 5]]
* ```
*
* @see {@link filter} — keep only matching elements
* @see {@link partitionMap} — partition using a Result-returning function
*
* @category filtering
* @since 2.0.0
*/
var partition$2 = /*#__PURE__*/ dual(2, (self, f) => {
	const excluded = [];
	const satisfying = [];
	let i = 0;
	for (const a of self) {
		const result = f(a, i++);
		if (isSuccess$3(result)) satisfying.push(result.success);
		else excluded.push(result.failure);
	}
	return [excluded, satisfying];
});
/**
* Separates an iterable of `Result`s into two arrays: failures and successes.
*
* - Equivalent to `partitionMap(identity)`.
*
* **Example** (Separating Results)
*
* ```ts
* import { Array, Result } from "effect"
*
* const [failures, successes] = Array.separate([
*   Result.succeed(1), Result.fail("error"), Result.succeed(2)
* ])
* console.log(failures) // ["error"]
* console.log(successes) // [1, 2]
* ```
*
* @see {@link getFailures} — extract only failures
* @see {@link getSuccesses} — extract only successes
*
* @category filtering
* @since 2.0.0
*/
var separate = /*#__PURE__*/ partition$2(identity);
/**
* Folds an iterable from left to right into a single value.
*
* - The function receives `(accumulator, element, index)`.
*
* **Example** (Summing an array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.reduce([1, 2, 3], 0, (acc, n) => acc + n)) // 6
* ```
*
* @see {@link reduceRight} — fold from right to left
* @see {@link scan} — fold keeping intermediate values
*
* @category folding
* @since 2.0.0
*/
var reduce$1 = /*#__PURE__*/ dual(3, (self, b, f) => fromIterable(self).reduce((b, a, i) => f(b, a, i), b));
/**
* Folds an iterable from right to left into a single value.
*
* - The function receives `(accumulator, element, index)`.
*
* **Example** (Right-to-left fold)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.reduceRight([1, 2, 3], 0, (acc, n) => acc + n)) // 6
* ```
*
* @see {@link reduce} — fold from left to right
* @see {@link scanRight} — fold keeping intermediate values
*
* @category folding
* @since 2.0.0
*/
var reduceRight = /*#__PURE__*/ dual(3, (self, b, f) => fromIterable(self).reduceRight((b, a, i) => f(b, a, i), b));
/**
* Lifts a predicate into an array: returns `[value]` if the predicate holds,
* `[]` otherwise.
*
* **Example** (Conditional wrapping)
*
* ```ts
* import { Array } from "effect"
*
* const isEven = (n: number) => n % 2 === 0
* const to = Array.liftPredicate(isEven)
* console.log(to(1)) // []
* console.log(to(2)) // [2]
* ```
*
* @see {@link liftOption} — lift an Option-returning function
*
* @category lifting
* @since 2.0.0
*/
var liftPredicate = (predicate) => (b) => predicate(b) ? [b] : [];
/**
* Lifts an `Option`-returning function into one that returns an array:
* `Some(a)` becomes `[a]`, `None` becomes `[]`.
*
* **Example** (Lifting an Option function)
*
* ```ts
* import { Array, Option } from "effect"
*
* const parseNumber = Array.liftOption((s: string) => {
*   const n = Number(s)
*   return isNaN(n) ? Option.none() : Option.some(n)
* })
* console.log(parseNumber("123")) // [123]
* console.log(parseNumber("abc")) // []
* ```
*
* @see {@link liftPredicate} — lift a boolean predicate
* @see {@link liftResult} — lift a Result-returning function
*
* @category lifting
* @since 2.0.0
*/
var liftOption = (f) => (...a) => fromOption$2(f(...a));
/**
* Converts a nullable value to an array: `null`/`undefined` becomes `[]`,
* anything else becomes `[value]`.
*
* **Example** (Nullable to array)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.fromNullishOr(1)) // [1]
* console.log(Array.fromNullishOr(null)) // []
* console.log(Array.fromNullishOr(undefined)) // []
* ```
*
* @see {@link liftNullishOr} — lift a nullable-returning function
* @see {@link fromOption} — convert from Option
*
* @category conversions
* @since 2.0.0
*/
var fromNullishOr$2 = (a) => a == null ? empty$4() : [a];
/**
* Lifts a nullable-returning function into one that returns an array:
* `null`/`undefined` becomes `[]`, anything else becomes `[value]`.
*
* **Example** (Lifting a nullable function)
*
* ```ts
* import { Array } from "effect"
*
* const parseNumber = Array.liftNullishOr((s: string) => {
*   const n = Number(s)
*   return isNaN(n) ? null : n
* })
* console.log(parseNumber("123")) // [123]
* console.log(parseNumber("abc")) // []
* ```
*
* @see {@link fromNullishOr} — convert a single nullable value
* @see {@link liftOption} — lift an Option-returning function
*
* @category lifting
* @since 2.0.0
*/
var liftNullishOr = (f) => (...a) => fromNullishOr$2(f(...a));
/**
* Maps each element with a nullable-returning function, keeping only non-null /
* non-undefined results.
*
* **Example** (FlatMapping with nullable)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.flatMapNullishOr([1, 2, 3], (n) => (n % 2 === 0 ? null : n)))
* // [1, 3]
* ```
*
* @category sequencing
* @since 2.0.0
*/
var flatMapNullishOr = /*#__PURE__*/ dual(2, (self, f) => flatMap$3(self, (a) => fromNullishOr$2(f(a))));
/**
* Lifts a `Result`-returning function into one that returns an array: failures
* produce `[]`, successes produce `[value]`.
*
* **Example** (Lifting a Result function)
*
* ```ts
* import { Array, Result } from "effect"
*
* const parseNumber = (s: string): Result.Result<number, Error> =>
*   isNaN(Number(s))
*     ? Result.fail(new Error("Not a number"))
*     : Result.succeed(Number(s))
*
* const liftedParseNumber = Array.liftResult(parseNumber)
* console.log(liftedParseNumber("42")) // [42]
* console.log(liftedParseNumber("not a number")) // []
* ```
*
* @see {@link liftOption} — lift an Option-returning function
* @see {@link liftPredicate} — lift a boolean predicate
*
* @category lifting
* @since 2.0.0
*/
var liftResult = (f) => (...a) => {
	const e = f(...a);
	return isFailure$3(e) ? [] : [e.success];
};
/**
* Tests whether all elements satisfy the predicate. Supports refinements for
* type narrowing.
*
* **Example** (Testing all elements)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.every([2, 4, 6], (x) => x % 2 === 0)) // true
* console.log(Array.every([2, 3, 6], (x) => x % 2 === 0)) // false
* ```
*
* @see {@link some} — test if any element matches
*
* @category elements
* @since 2.0.0
*/
var every = /*#__PURE__*/ dual(2, (self, refinement) => self.every(refinement));
/**
* Tests whether at least one element satisfies the predicate. Narrows the type
* to `NonEmptyReadonlyArray` on success.
*
* **Example** (Testing for any match)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.some([1, 3, 4], (x) => x % 2 === 0)) // true
* console.log(Array.some([1, 3, 5], (x) => x % 2 === 0)) // false
* ```
*
* @see {@link every} — test if all elements match
* @see {@link contains} — test for a specific value
*
* @category elements
* @since 2.0.0
*/
var some = /*#__PURE__*/ dual(2, (self, predicate) => self.some(predicate));
/**
* Applies a function to each suffix of the array (starting from each index),
* collecting the results.
*
* - For index `i`, the function receives `self.slice(i)`.
*
* **Example** (Suffix lengths)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.extend([1, 2, 3], (as) => as.length)) // [3, 2, 1]
* ```
*
* @category mapping
* @since 2.0.0
*/
var extend = /*#__PURE__*/ dual(2, (self, f) => self.map((_, i, as) => f(as.slice(i))));
/**
* Returns the minimum element of a non-empty array according to the given
* `Order`.
*
* **Example** (Finding the minimum)
*
* ```ts
* import { Array, Order } from "effect"
*
* console.log(Array.min([3, 1, 2], Order.Number)) // 1
* ```
*
* @see {@link max} — find the maximum
* @see {@link sort} — sort the entire array
*
* @category elements
* @since 2.0.0
*/
var min$3 = /*#__PURE__*/ dual(2, (self, O) => self.reduce(min$4(O)));
/**
* Returns the maximum element of a non-empty array according to the given
* `Order`.
*
* **Example** (Finding the maximum)
*
* ```ts
* import { Array, Order } from "effect"
*
* console.log(Array.max([3, 1, 2], Order.Number)) // 3
* ```
*
* @see {@link min} — find the minimum
* @see {@link sort} — sort the entire array
*
* @category elements
* @since 2.0.0
*/
var max$3 = /*#__PURE__*/ dual(2, (self, O) => self.reduce(max$4(O)));
/**
* Builds an array by repeatedly applying a function to a seed value. The
* function returns `[element, nextSeed]` to continue, or `undefined` to stop.
*
* **Example** (Generating a sequence)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.unfold(1, (n) => n <= 5 ? [n, n + 1] : undefined))
* // [1, 2, 3, 4, 5]
* ```
*
* @see {@link makeBy} — generate from index
* @see {@link range} — generate a numeric range
*
* @category constructors
* @since 2.0.0
*/
var unfold$1 = (b, f) => {
	const out = [];
	let next = b;
	let o;
	while (o = f(next)) {
		const [a, b] = o;
		out.push(a);
		next = b;
	}
	return out;
};
/**
* Creates an `Order` for arrays based on an element `Order`. Arrays are
* compared element-wise; if all compared elements are equal, shorter arrays
* come first.
*
* **Example** (Comparing arrays)
*
* ```ts
* import { Array, Order } from "effect"
*
* const arrayOrder = Array.makeOrder(Order.Number)
* console.log(arrayOrder([1, 2], [1, 3])) // -1
* ```
*
* @see {@link makeEquivalence} — create an equivalence for arrays
*
* @category instances
* @since 2.0.0
*/
var makeOrder = Array$2;
/**
* Creates an `Equivalence` for arrays based on an element `Equivalence`. Two
* arrays are equivalent when they have the same length and all elements are
* pairwise equivalent.
*
* **Example** (Comparing arrays for equality)
*
* ```ts
* import { Array } from "effect"
*
* const eq = Array.makeEquivalence<number>((a, b) => a === b)
* console.log(eq([1, 2, 3], [1, 2, 3])) // true
* ```
*
* @see {@link makeOrder} — create an ordering for arrays
*
* @category instances
* @since 2.0.0
*/
var makeEquivalence = Array$3;
/**
* Runs a side-effect for each element. The callback receives `(element, index)`.
*
* **Example** (Iterating with side-effects)
*
* ```ts
* import { Array } from "effect"
*
* Array.forEach([1, 2, 3], (n) => console.log(n)) // 1, 2, 3
* ```
*
* @category elements
* @since 2.0.0
*/
var forEach$2 = /*#__PURE__*/ dual(2, (self, f) => fromIterable(self).forEach((a, i) => f(a, i)));
/**
* Removes duplicates using a custom equivalence, preserving the order of the
* first occurrence.
*
* **Example** (Deduplicating with custom equality)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.dedupeWith([1, 2, 2, 3, 3, 3], (a, b) => a === b)) // [1, 2, 3]
* ```
*
* @see {@link dedupe} — uses default equality
* @see {@link dedupeAdjacentWith} — only dedupes consecutive elements
*
* @category elements
* @since 2.0.0
*/
var dedupeWith = /*#__PURE__*/ dual(2, (self, isEquivalent) => {
	const input = fromIterable(self);
	if (isReadonlyArrayNonEmpty(input)) {
		const out = [headNonEmpty(input)];
		const rest = tailNonEmpty(input);
		for (const r of rest) if (out.every((a) => !isEquivalent(r, a))) out.push(r);
		return out;
	}
	return [];
});
/**
* Removes duplicates using `Equal.equivalence()`, preserving the order of the
* first occurrence.
*
* **Example** (Removing duplicates)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.dedupe([1, 2, 1, 3, 2, 4])) // [1, 2, 3, 4]
* ```
*
* @see {@link dedupeWith} — use custom equality
* @see {@link dedupeAdjacent} — only dedupes consecutive elements
*
* @category elements
* @since 2.0.0
*/
var dedupe = (self) => dedupeWith(self, asEquivalence());
/**
* Removes consecutive duplicate elements using a custom equivalence.
*
* - Non-adjacent duplicates are preserved.
*
* **Example** (Deduplicating adjacent elements)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.dedupeAdjacentWith([1, 1, 2, 2, 3, 3], (a, b) => a === b))
* // [1, 2, 3]
* ```
*
* @see {@link dedupeAdjacent} — uses default equality
* @see {@link dedupeWith} — dedupes all duplicates, not just adjacent
*
* @category elements
* @since 2.0.0
*/
var dedupeAdjacentWith = /*#__PURE__*/ dual(2, (self, isEquivalent) => {
	const out = [];
	let lastA = none();
	for (const a of self) if (isNone(lastA) || !isEquivalent(a, lastA.value)) {
		out.push(a);
		lastA = some$2(a);
	}
	return out;
});
/**
* Removes consecutive duplicate elements using `Equal.equivalence()`.
*
* **Example** (Removing adjacent duplicates)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.dedupeAdjacent([1, 1, 2, 2, 3, 3])) // [1, 2, 3]
* ```
*
* @see {@link dedupeAdjacentWith} — use custom equality
* @see {@link dedupe} — remove all duplicates
*
* @category elements
* @since 2.0.0
*/
var dedupeAdjacent = /*#__PURE__*/ dedupeAdjacentWith(/*#__PURE__*/ asEquivalence());
/**
* Joins string elements with a separator.
*
* **Example** (Joining strings)
*
* ```ts
* import { Array } from "effect"
*
* console.log(Array.join(["a", "b", "c"], "-")) // "a-b-c"
* ```
*
* @see {@link intersperse} — insert separator elements without joining
*
* @since 2.0.0
* @category folding
*/
var join = /*#__PURE__*/ dual(2, (self, sep) => fromIterable(self).join(sep));
/**
* Maps over an array while threading an accumulator through each step, returning both the final state and the mapped array.
*
* - Combines `map` and `reduce` in a single pass.
* - The callback receives the current state, element, and index, and returns `[nextState, mappedValue]`.
* - Returns `[finalState, mappedArray]`.
* - Dual: can be used in both data-first and data-last style.
*
* **Example** (Running sum alongside mapped values)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.mapAccum([1, 2, 3], 0, (acc, n) => [acc + n, acc + n])
* console.log(result) // [6, [1, 3, 6]]
* ```
*
* @see {@link scan} — when you only need the accumulated results (not the final state)
* @see {@link reduce} — when you only need the final accumulated value
*
* @since 2.0.0
* @category folding
*/
var mapAccum = /*#__PURE__*/ dual(3, (self, s, f) => {
	let i = 0;
	let s1 = s;
	const out = [];
	for (const a of self) {
		const r = f(s1, a, i);
		s1 = r[0];
		out.push(r[1]);
		i++;
	}
	return [s1, out];
});
/**
* Computes the cartesian product of two arrays, applying a combiner to each pair.
*
* - Produces every combination of an element from `self` with an element from `that`.
* - Result length is `self.length * that.length`.
* - Order: iterates `that` for each element of `self`.
*
* **Example** (Combining numbers and letters)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.cartesianWith([1, 2], ["a", "b"], (a, b) => `${a}-${b}`)
* console.log(result) // ["1-a", "1-b", "2-a", "2-b"]
* ```
*
* @see {@link cartesian} — returns tuples instead of applying a combiner
*
* @since 2.0.0
* @category elements
*/
var cartesianWith = /*#__PURE__*/ dual(3, (self, that, f) => flatMap$3(self, (a) => map$6(that, (b) => f(a, b))));
/**
* Computes the cartesian product of two arrays, returning all pairs as tuples.
*
* - Produces every `[a, b]` combination of an element from `self` with an element from `that`.
* - Result length is `self.length * that.length`.
*
* **Example** (All pairs of two arrays)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.cartesian([1, 2], ["a", "b"])
* console.log(result) // [[1, "a"], [1, "b"], [2, "a"], [2, "b"]]
* ```
*
* @see {@link cartesianWith} — apply a combiner to each pair
*
* @since 2.0.0
* @category elements
*/
var cartesian = /*#__PURE__*/ dual(2, (self, that) => cartesianWith(self, that, (a, b) => [a, b]));
/**
* Starting point for the "do simulation" — an array comprehension pattern.
*
* - Begin a pipeline with `Do`, then use {@link bind} to introduce array variables and {@link let_ let} for plain values.
* - Each `bind` produces the cartesian product of all bound variables (like nested loops).
* - Use `filter` and `map` in the pipeline to add conditions and transformations.
*
* **Example** (Array comprehension with do notation)
*
* ```ts
* import { Array, pipe } from "effect"
*
* const result = pipe(
*   Array.Do,
*   Array.bind("x", () => [1, 3, 5]),
*   Array.bind("y", () => [2, 4, 6]),
*   Array.filter(({ x, y }) => x < y),
*   Array.map(({ x, y }) => [x, y] as const)
* )
* console.log(result) // [[1, 2], [1, 4], [1, 6], [3, 4], [3, 6], [5, 6]]
* ```
*
* @see {@link bind} — introduce an array variable into the scope
* @see {@link bindTo} — start a pipeline by naming the first array
* @see {@link let_ let} — introduce a plain computed value
*
* @category do notation
* @since 3.2.0
*/
var Do$2 = /*#__PURE__*/ of$1({});
/**
* Introduces a new array variable into a do-notation scope, producing the cartesian product with all previous bindings.
*
* - Each `bind` call adds a named property to the accumulated object.
* - The callback receives the current scope and must return an array.
* - Equivalent to `flatMap` + merging the new value into the scope object.
*
* **Example** (Binding two arrays)
*
* ```ts
* import { Array, pipe } from "effect"
*
* const result = pipe(
*   Array.Do,
*   Array.bind("x", () => [1, 2]),
*   Array.bind("y", () => ["a", "b"])
* )
* console.log(result)
* // [{ x: 1, y: "a" }, { x: 1, y: "b" }, { x: 2, y: "a" }, { x: 2, y: "b" }]
* ```
*
* @see {@link Do} — start a do-notation pipeline
* @see {@link bindTo} — name the first array in a pipeline
* @see {@link let_ let} — add a plain computed value
*
* @category do notation
* @since 3.2.0
*/
var bind$2 = /*#__PURE__*/ bind$3(map$6, flatMap$3);
/**
* Names the elements of an array by wrapping each in an object with the given key, starting a do-notation scope.
*
* - Equivalent to `Array.map(self, (a) => ({ [tag]: a }))`.
* - Alternative to starting with `Do` + `bind`; useful when you already have an array.
*
* **Example** (Naming an existing array)
*
* ```ts
* import { Array, pipe } from "effect"
*
* const result = pipe(
*   [1, 2, 3],
*   Array.bindTo("x")
* )
* console.log(result) // [{ x: 1 }, { x: 2 }, { x: 3 }]
* ```
*
* @see {@link Do} — start with an empty scope
* @see {@link bind} — add another array variable to the scope
*
* @category do notation
* @since 3.2.0
*/
var bindTo$2 = /*#__PURE__*/ bindTo$3(map$6);
var let_$2 = /*#__PURE__*/ let_$3(map$6);
var reducer = /*#__PURE__*/ make$12((a, b) => a.concat(b), []);
/**
* Returns a `Reducer` that combines `ReadonlyArray` values by concatenation.
*
* @see {@link makeReducerConcat} — mutable `Array` variant
*
* @since 4.0.0
*/
function getReadonlyReducerConcat() {
	return reducer;
}
/**
* Returns a `Reducer` that combines `Array` values by concatenation.
*
* @see {@link getReadonlyReducerConcat} — readonly variant
*
* @since 4.0.0
*/
function makeReducerConcat() {
	return reducer;
}
/**
* Counts the elements in an iterable that satisfy a predicate.
*
* - The predicate receives both the element and its index.
* - Returns `0` for an empty iterable.
*
* **Example** (Counting even numbers)
*
* ```ts
* import { Array } from "effect"
*
* const result = Array.countBy([1, 2, 3, 4, 5], (n) => n % 2 === 0)
* console.log(result) // 2
* ```
*
* @see {@link filter} — when you need the matching elements, not just the count
*
* @category folding
* @since 3.16.0
*/
var countBy = /*#__PURE__*/ dual(2, (self, f) => {
	let count = 0;
	const as = fromIterable(self);
	for (let i = 0; i < as.length; i++) {
		const a = as[i];
		if (f(a, i)) count++;
	}
	return count;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/UndefinedOr.js
/**
* This module provides small, allocation-free utilities for working with values of type
* `A | undefined`, where `undefined` means "no value".
*
* Why not `Option<A>`?
* In TypeScript, `Option<A>` is often unnecessary. If `undefined` already models absence
* in your domain, using `A | undefined` keeps types simple, avoids extra wrappers, and
* reduces overhead. The key is that `A` itself must not include `undefined`; in this
* module `undefined` is reserved to mean "no value".
*
* When to use `A | undefined`:
* - Absence can be represented by `undefined` in your domain model.
* - You do not need to distinguish between "no value" and "value is undefined".
* - You want straightforward ergonomics and zero extra allocations.
*
* When to prefer `Option<A>`:
* - You must distinguish `None` from `Some(undefined)` (that is, `undefined` is a valid
*   payload and carries meaning on its own).
* - You need a tagged representation for serialization or pattern matching across
*   boundaries where `undefined` would be ambiguous.
* - You want the richer `Option` API and are comfortable with the extra wrapper.
*
* Lawfulness note:
* All helpers treat `undefined` as absence. Do not use these utilities with payloads
* where `A` can itself be `undefined`, or you will lose information. If you need to
* carry `undefined` as a valid payload, use `Option<A>` instead.
*
* @since 4.0.0
*/
var UndefinedOr_exports = /* @__PURE__ */ __exportAll({
	getOrThrow: () => getOrThrow,
	getOrThrowWith: () => getOrThrowWith,
	liftThrowable: () => liftThrowable,
	makeCombinerFailFast: () => makeCombinerFailFast,
	makeReducer: () => makeReducer,
	makeReducerFailFast: () => makeReducerFailFast,
	map: () => map$5,
	match: () => match$7
});
/**
* @since 4.0.0
*/
var map$5 = /*#__PURE__*/ dual(2, (self, f) => self === void 0 ? void 0 : f(self));
/**
* @since 4.0.0
*/
var match$7 = /*#__PURE__*/ dual(2, (self, { onDefined, onUndefined }) => self === void 0 ? onUndefined() : onDefined(self));
/**
* @since 4.0.0
*/
var getOrThrowWith = /*#__PURE__*/ dual(2, (self, onUndefined) => {
	if (self !== void 0) return self;
	throw onUndefined();
});
/**
* @since 4.0.0
*/
var getOrThrow = /*#__PURE__*/ getOrThrowWith(() => /* @__PURE__ */ new Error("getOrThrow called on a undefined"));
/**
* @since 4.0.0
*/
var liftThrowable = (f) => (...a) => {
	try {
		return f(...a);
	} catch {
		return;
	}
};
/**
* Creates a `Reducer` for `UndefinedOr<A>` that prioritizes the first non-`undefined`
* value and combines values when both operands are present.
*
* This `Reducer` is useful for scenarios where you want to:
* - Take the first available value (like a fallback chain)
* - Combine values when both are present
* - Maintain a `undefined` state only when all values are `undefined`
*
* The `initialValue` of the `Reducer` is `undefined`.
*
* **Behavior:**
* - `undefined` + `undefined` = `undefined`
* - `a` + `undefined` = `a` (first value wins)
* - `undefined` + `b` = `b` (second value wins)
* - `a` + `b` = `a + b` (values combined)
*
* @since 4.0.0
*/
function makeReducer(combiner) {
	return make$12((self, that) => {
		if (self === void 0) return that;
		if (that === void 0) return self;
		return combiner.combine(self, that);
	}, void 0);
}
/**
* Creates a `Combiner` for `UndefinedOr<A>` that only combines values when both
* operands are not `undefined`, failing fast if either is `undefined`.
*
* This `Combiner` is useful for scenarios where you need both values to be
* present to perform an operation, such as:
* - Mathematical operations that require two operands
* - Data validation that needs both fields
* - Operations that can't proceed with partial data
*
* **Behavior:**
* - `undefined` + `undefined` = `undefined`
* - `a` + `undefined` = `undefined` (fails fast)
* - `undefined` + `b` = `undefined` (fails fast)
* - `a` + `b` = `a + b` (values combined)
*
* @see {@link makeReducerFailFast} if you have a `Reducer` and want to lift it
* to `UndefinedOr` values.
*
* @since 4.0.0
*/
function makeCombinerFailFast(combiner) {
	return make$11((self, that) => {
		if (self === void 0 || that === void 0) return void 0;
		return combiner.combine(self, that);
	});
}
/**
* Creates a `Reducer` for `UndefinedOr<A>` by wrapping an existing `Reducer` with
* fail-fast semantics for `UndefinedOr` values.
*
* This function lifts a regular `Reducer` into the `UndefinedOr` context, allowing
* you to use existing `Reducer`s with `UndefinedOr` values while maintaining the
* fail-fast behavior where any `undefined` value causes the entire reduction to fail.
*
* The initial value is `some(reducer.initialValue)`, ensuring the `Reducer`
* starts with a valid `UndefinedOr` value.
*
* **Behavior:**
* - Fails fast (returns `undefined`) if any operand is `undefined`
* - Uses the underlying reducer's combine logic when both values are present
*
* @see {@link makeCombinerFailFast} if you only have a `Combiner` and want to
* lift it to `UndefinedOr` values.
*
* @since 4.0.0
*/
function makeReducerFailFast(reducer) {
	const combine = makeCombinerFailFast(reducer).combine;
	const initialValue = reducer.initialValue;
	return make$12(combine, initialValue, (collection) => {
		let out = initialValue;
		for (const value of collection) {
			out = combine(out, value);
			if (out === void 0) return out;
		}
		return out;
	});
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Duration.js
/**
* This module provides utilities for working with durations of time. A `Duration`
* is an immutable data type that represents a span of time with high precision,
* supporting operations from nanoseconds to weeks.
*
* Durations support:
* - **High precision**: Nanosecond-level accuracy using BigInt
* - **Multiple formats**: Numbers (millis), BigInt (nanos), tuples, strings
* - **Arithmetic operations**: Add, subtract, multiply, divide
* - **Comparisons**: Equal, less than, greater than
* - **Conversions**: Between different time units
* - **Human-readable formatting**: Pretty printing and parsing
*
* @since 2.0.0
*/
var Duration_exports = /* @__PURE__ */ __exportAll({
	CombinerMax: () => CombinerMax,
	CombinerMin: () => CombinerMin,
	Equivalence: () => Equivalence$4,
	Order: () => Order$3,
	ReducerSum: () => ReducerSum$1,
	abs: () => abs,
	between: () => between$2,
	clamp: () => clamp$2,
	days: () => days,
	divide: () => divide$1,
	divideUnsafe: () => divideUnsafe,
	equals: () => equals$2,
	format: () => format$1,
	fromInput: () => fromInput,
	fromInputUnsafe: () => fromInputUnsafe,
	hours: () => hours,
	infinity: () => infinity,
	isDuration: () => isDuration,
	isFinite: () => isFinite,
	isGreaterThan: () => isGreaterThan$2,
	isGreaterThanOrEqualTo: () => isGreaterThanOrEqualTo$2,
	isLessThan: () => isLessThan$2,
	isLessThanOrEqualTo: () => isLessThanOrEqualTo$2,
	isNegative: () => isNegative,
	isPositive: () => isPositive,
	isZero: () => isZero,
	match: () => match$6,
	matchPair: () => matchPair,
	max: () => max$2,
	micros: () => micros,
	millis: () => millis,
	min: () => min$2,
	minutes: () => minutes,
	nanos: () => nanos,
	negate: () => negate,
	negativeInfinity: () => negativeInfinity,
	parts: () => parts,
	seconds: () => seconds,
	subtract: () => subtract$2,
	sum: () => sum$1,
	times: () => times,
	toDays: () => toDays,
	toHours: () => toHours,
	toHrTime: () => toHrTime,
	toMillis: () => toMillis,
	toMinutes: () => toMinutes,
	toNanos: () => toNanos,
	toNanosUnsafe: () => toNanosUnsafe,
	toSeconds: () => toSeconds,
	toWeeks: () => toWeeks,
	weeks: () => weeks,
	zero: () => zero
});
var TypeId$10 = "~effect/time/Duration";
var bigint0$2 = /*#__PURE__*/ BigInt(0);
var bigint24 = /*#__PURE__*/ BigInt(24);
var bigint60 = /*#__PURE__*/ BigInt(60);
var bigint1e3 = /*#__PURE__*/ BigInt(1e3);
var bigint1e6 = /*#__PURE__*/ BigInt(1e6);
var bigint1e9 = /*#__PURE__*/ BigInt(1e9);
var DURATION_REGEXP = /^(-?\d+(?:\.\d+)?)\s+(nanos?|micros?|millis?|seconds?|minutes?|hours?|days?|weeks?)$/;
/**
* Decodes a `Duration.Input` into a `Duration`.
*
* If the input is not a valid `Duration.Input`, it throws an error.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration1 = Duration.fromInputUnsafe(1000) // 1000 milliseconds
* const duration2 = Duration.fromInputUnsafe("5 seconds")
* const duration3 = Duration.fromInputUnsafe([2, 500_000_000]) // 2 seconds and 500ms
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromInputUnsafe = (input) => {
	if (isDuration(input)) return input;
	if (isNumber$1(input)) return millis(input);
	if (isBigInt(input)) return nanos(input);
	if (Array.isArray(input) && input.length === 2 && input.every(isNumber$1)) {
		if (Number.isNaN(input[0]) || Number.isNaN(input[1])) return zero;
		if (input[0] === -Infinity || input[1] === -Infinity) return negativeInfinity;
		if (input[0] === Infinity || input[1] === Infinity) return infinity;
		return nanos(BigInt(Math.round(input[0] * 1e9)) + BigInt(Math.round(input[1])));
	}
	if (isString$1(input)) {
		const match = DURATION_REGEXP.exec(input);
		if (match) {
			const [_, valueStr, unit] = match;
			const value = Number(valueStr);
			switch (unit) {
				case "nano":
				case "nanos": return nanos(BigInt(valueStr));
				case "micro":
				case "micros": return micros(BigInt(valueStr));
				case "milli":
				case "millis": return millis(value);
				case "second":
				case "seconds": return seconds(value);
				case "minute":
				case "minutes": return minutes(value);
				case "hour":
				case "hours": return hours(value);
				case "day":
				case "days": return days(value);
				case "week":
				case "weeks": return weeks(value);
			}
		}
	}
	throw new Error(`Invalid Input: ${input}`);
};
/**
* Safely decodes a `Input` value into a `Duration`, returning
* `undefined` if decoding fails.
*
* **Example**
*
* ```ts
* import { Duration } from "effect"
*
* Duration.fromInput(1000)?.pipe(Duration.toSeconds) // 1
*
* Duration.fromInput("invalid" as any) // undefined
* ```
*
* @category constructors
* @since 4.0.0
*/
var fromInput = /*#__PURE__*/ liftThrowable(fromInputUnsafe);
var zeroDurationValue = {
	_tag: "Millis",
	millis: 0
};
var infinityDurationValue = { _tag: "Infinity" };
var negativeInfinityDurationValue = { _tag: "NegativeInfinity" };
var DurationProto = {
	[TypeId$10]: TypeId$10,
	[symbol$1]() {
		return structure(this.value);
	},
	[symbol$2](that) {
		return isDuration(that) && equals$2(this, that);
	},
	toString() {
		switch (this.value._tag) {
			case "Infinity": return "Infinity";
			case "NegativeInfinity": return "-Infinity";
			case "Nanos": return `${this.value.nanos} nanos`;
			case "Millis": return `${this.value.millis} millis`;
		}
	},
	toJSON() {
		switch (this.value._tag) {
			case "Millis": return {
				_id: "Duration",
				_tag: "Millis",
				millis: this.value.millis
			};
			case "Nanos": return {
				_id: "Duration",
				_tag: "Nanos",
				nanos: String(this.value.nanos)
			};
			case "Infinity": return {
				_id: "Duration",
				_tag: "Infinity"
			};
			case "NegativeInfinity": return {
				_id: "Duration",
				_tag: "NegativeInfinity"
			};
		}
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var make$8 = (input) => {
	const duration = Object.create(DurationProto);
	if (isNumber$1(input)) if (isNaN(input) || input === 0 || Object.is(input, -0)) duration.value = zeroDurationValue;
	else if (!Number.isFinite(input)) duration.value = input > 0 ? infinityDurationValue : negativeInfinityDurationValue;
	else if (!Number.isInteger(input)) duration.value = {
		_tag: "Nanos",
		nanos: BigInt(Math.round(input * 1e6))
	};
	else duration.value = {
		_tag: "Millis",
		millis: input
	};
	else if (input === bigint0$2) duration.value = zeroDurationValue;
	else duration.value = {
		_tag: "Nanos",
		nanos: input
	};
	return duration;
};
/**
* Checks if a value is a Duration.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.isDuration(Duration.seconds(1))) // true
* console.log(Duration.isDuration(1000)) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isDuration = (u) => hasProperty(u, TypeId$10);
/**
* Checks if a Duration is finite (not infinite).
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.isFinite(Duration.seconds(5))) // true
* console.log(Duration.isFinite(Duration.infinity)) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isFinite = (self) => self.value._tag !== "Infinity" && self.value._tag !== "NegativeInfinity";
/**
* Checks if a Duration is zero.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.isZero(Duration.zero)) // true
* console.log(Duration.isZero(Duration.seconds(1))) // false
* ```
*
* @since 3.5.0
* @category guards
*/
var isZero = (self) => {
	switch (self.value._tag) {
		case "Millis": return self.value.millis === 0;
		case "Nanos": return self.value.nanos === bigint0$2;
		case "Infinity":
		case "NegativeInfinity": return false;
	}
};
/**
* Returns `true` if the duration is negative (strictly less than zero).
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.isNegative(Duration.seconds(-5))) // true
* console.log(Duration.isNegative(Duration.zero)) // false
* console.log(Duration.isNegative(Duration.negativeInfinity)) // true
* ```
*
* @since 4.0.0
* @category guards
*/
var isNegative = (self) => {
	switch (self.value._tag) {
		case "Millis": return self.value.millis < 0;
		case "Nanos": return self.value.nanos < bigint0$2;
		case "NegativeInfinity": return true;
		case "Infinity": return false;
	}
};
/**
* Returns `true` if the duration is positive (strictly greater than zero).
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.isPositive(Duration.seconds(5))) // true
* console.log(Duration.isPositive(Duration.zero)) // false
* console.log(Duration.isPositive(Duration.infinity)) // true
* ```
*
* @since 4.0.0
* @category guards
*/
var isPositive = (self) => {
	switch (self.value._tag) {
		case "Millis": return self.value.millis > 0;
		case "Nanos": return self.value.nanos > bigint0$2;
		case "Infinity": return true;
		case "NegativeInfinity": return false;
	}
};
/**
* Returns the absolute value of the duration.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* Duration.toMillis(Duration.abs(Duration.seconds(-5))) // 5000
* Duration.abs(Duration.negativeInfinity) === Duration.infinity // true
* ```
*
* @since 4.0.0
* @category math
*/
var abs = (self) => {
	switch (self.value._tag) {
		case "Infinity":
		case "NegativeInfinity": return infinity;
		case "Millis": return self.value.millis < 0 ? make$8(-self.value.millis) : self;
		case "Nanos": return self.value.nanos < bigint0$2 ? make$8(-self.value.nanos) : self;
	}
};
/**
* Negates the duration.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* Duration.toMillis(Duration.negate(Duration.seconds(5))) // -5000
* Duration.negate(Duration.infinity) === Duration.negativeInfinity // true
* ```
*
* @since 4.0.0
* @category math
*/
var negate = (self) => {
	switch (self.value._tag) {
		case "Infinity": return negativeInfinity;
		case "NegativeInfinity": return infinity;
		case "Millis": return self.value.millis === 0 ? self : make$8(-self.value.millis);
		case "Nanos": return self.value.nanos === bigint0$2 ? self : make$8(-self.value.nanos);
	}
};
/**
* A Duration representing zero time.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toMillis(Duration.zero)) // 0
* ```
*
* @since 2.0.0
* @category constructors
*/
var zero = /*#__PURE__*/ make$8(0);
/**
* A Duration representing infinite time.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toMillis(Duration.infinity)) // Infinity
* ```
*
* @since 2.0.0
* @category constructors
*/
var infinity = /*#__PURE__*/ make$8(Infinity);
/**
* A Duration representing negative infinite time.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toMillis(Duration.negativeInfinity)) // -Infinity
* ```
*
* @since 4.0.0
* @category constructors
*/
var negativeInfinity = /*#__PURE__*/ make$8(-Infinity);
/**
* Creates a Duration from nanoseconds.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.nanos(BigInt(500_000_000))
* console.log(Duration.toMillis(duration)) // 500
* ```
*
* @since 2.0.0
* @category constructors
*/
var nanos = (nanos) => make$8(nanos);
/**
* Creates a Duration from microseconds.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.micros(BigInt(500_000))
* console.log(Duration.toMillis(duration)) // 500
* ```
*
* @since 2.0.0
* @category constructors
*/
var micros = (micros) => make$8(micros * bigint1e3);
/**
* Creates a Duration from milliseconds.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.millis(1000)
* console.log(Duration.toMillis(duration)) // 1000
* ```
*
* @since 2.0.0
* @category constructors
*/
var millis = (millis) => make$8(millis);
/**
* Creates a Duration from seconds.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.seconds(30)
* console.log(Duration.toMillis(duration)) // 30000
* ```
*
* @since 2.0.0
* @category constructors
*/
var seconds = (seconds) => make$8(seconds * 1e3);
/**
* Creates a Duration from minutes.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.minutes(5)
* console.log(Duration.toMillis(duration)) // 300000
* ```
*
* @since 2.0.0
* @category constructors
*/
var minutes = (minutes) => make$8(minutes * 6e4);
/**
* Creates a Duration from hours.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.hours(2)
* console.log(Duration.toMillis(duration)) // 7200000
* ```
*
* @since 2.0.0
* @category constructors
*/
var hours = (hours) => make$8(hours * 36e5);
/**
* Creates a Duration from days.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.days(1)
* console.log(Duration.toMillis(duration)) // 86400000
* ```
*
* @since 2.0.0
* @category constructors
*/
var days = (days) => make$8(days * 864e5);
/**
* Creates a Duration from weeks.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.weeks(1)
* console.log(Duration.toMillis(duration)) // 604800000
* ```
*
* @since 2.0.0
* @category constructors
*/
var weeks = (weeks) => make$8(weeks * 6048e5);
/**
* Converts a Duration to milliseconds.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toMillis(Duration.seconds(5))) // 5000
* console.log(Duration.toMillis(Duration.minutes(2))) // 120000
* ```
*
* @since 2.0.0
* @category getters
*/
var toMillis = (self) => match$6(self, {
	onMillis: identity,
	onNanos: (nanos) => Number(nanos) / 1e6,
	onInfinity: () => Infinity,
	onNegativeInfinity: () => -Infinity
});
/**
* Converts a Duration to seconds.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toSeconds(Duration.millis(5000))) // 5
* console.log(Duration.toSeconds(Duration.minutes(2))) // 120
* ```
*
* @since 2.0.0
* @category getters
*/
var toSeconds = (self) => match$6(self, {
	onMillis: (millis) => millis / 1e3,
	onNanos: (nanos) => Number(nanos) / 1e9,
	onInfinity: () => Infinity,
	onNegativeInfinity: () => -Infinity
});
/**
* Converts a Duration to minutes.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toMinutes(Duration.seconds(120))) // 2
* console.log(Duration.toMinutes(Duration.hours(1))) // 60
* ```
*
* @since 3.8.0
* @category getters
*/
var toMinutes = (self) => match$6(self, {
	onMillis: (millis) => millis / 6e4,
	onNanos: (nanos) => Number(nanos) / 6e10,
	onInfinity: () => Infinity,
	onNegativeInfinity: () => -Infinity
});
/**
* Converts a Duration to hours.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toHours(Duration.minutes(120))) // 2
* console.log(Duration.toHours(Duration.days(1))) // 24
* ```
*
* @since 3.8.0
* @category getters
*/
var toHours = (self) => match$6(self, {
	onMillis: (millis) => millis / 36e5,
	onNanos: (nanos) => Number(nanos) / 36e11,
	onInfinity: () => Infinity,
	onNegativeInfinity: () => -Infinity
});
/**
* Converts a Duration to days.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toDays(Duration.hours(48))) // 2
* console.log(Duration.toDays(Duration.weeks(1))) // 7
* ```
*
* @since 3.8.0
* @category getters
*/
var toDays = (self) => match$6(self, {
	onMillis: (millis) => millis / 864e5,
	onNanos: (nanos) => Number(nanos) / 864e11,
	onInfinity: () => Infinity,
	onNegativeInfinity: () => -Infinity
});
/**
* Converts a Duration to weeks.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* console.log(Duration.toWeeks(Duration.days(14))) // 2
* console.log(Duration.toWeeks(Duration.days(7))) // 1
* ```
*
* @since 3.8.0
* @category getters
*/
var toWeeks = (self) => match$6(self, {
	onMillis: (millis) => millis / 6048e5,
	onNanos: (nanos) => Number(nanos) / 6048e11,
	onInfinity: () => Infinity,
	onNegativeInfinity: () => -Infinity
});
/**
* Get the duration in nanoseconds as a bigint.
*
* If the duration is infinite, it throws an error.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.seconds(2)
* const nanos = Duration.toNanosUnsafe(duration)
* console.log(nanos) // 2000000000n
*
* // This will throw an error
* try {
*   Duration.toNanosUnsafe(Duration.infinity)
* } catch (error) {
*   console.log((error as Error).message) // "Cannot convert infinite duration to nanos"
* }
* ```
*
* @since 2.0.0
* @category getters
*/
var toNanosUnsafe = (self) => {
	switch (self.value._tag) {
		case "Infinity":
		case "NegativeInfinity": throw new Error("Cannot convert infinite duration to nanos");
		case "Nanos": return self.value.nanos;
		case "Millis": return BigInt(Math.round(self.value.millis * 1e6));
	}
};
/**
* Get the duration in nanoseconds as a bigint.
*
* If the duration is infinite, returns `undefined`.
*
* **Example**
*
* ```ts
* import { Duration } from "effect"
*
* Duration.toNanos(Duration.seconds(1)) // 1000000000n
*
* Duration.toNanos(Duration.infinity) // undefined
* ```
*
* @category getters
* @since 4.0.0
*/
var toNanos = /*#__PURE__*/ liftThrowable(toNanosUnsafe);
/**
* Converts a Duration to high-resolution time format [seconds, nanoseconds].
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const duration = Duration.millis(1500)
* const hrtime = Duration.toHrTime(duration)
* console.log(hrtime) // [1, 500000000]
* ```
*
* @since 2.0.0
* @category getters
*/
var toHrTime = (self) => {
	switch (self.value._tag) {
		case "Infinity": return [Infinity, 0];
		case "NegativeInfinity": return [-Infinity, 0];
		case "Nanos": {
			const n = self.value.nanos;
			const sign = n < bigint0$2 ? -1n : 1n;
			const a = n < bigint0$2 ? -n : n;
			return [Number(sign * (a / bigint1e9)), Number(sign * (a % bigint1e9))];
		}
		case "Millis": {
			const m = self.value.millis;
			const sign = m < 0 ? -1 : 1;
			const a = Math.abs(m);
			return [sign * Math.floor(a / 1e3), sign * Math.round(a % 1e3 * 1e6)];
		}
	}
};
/**
* Pattern matches on a Duration, providing different handlers for millis and nanos.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const result = Duration.match(Duration.seconds(5), {
*   onMillis: (millis) => `${millis} milliseconds`,
*   onNanos: (nanos) => `${nanos} nanoseconds`,
*   onInfinity: () => "infinite"
* })
* console.log(result) // "5000 milliseconds"
* ```
*
* @since 2.0.0
* @category pattern matching
*/
var match$6 = /*#__PURE__*/ dual(2, (self, options) => {
	switch (self.value._tag) {
		case "Millis": return options.onMillis(self.value.millis);
		case "Nanos": return options.onNanos(self.value.nanos);
		case "Infinity": return options.onInfinity();
		case "NegativeInfinity": return (options.onNegativeInfinity ?? options.onInfinity)();
	}
});
/**
* Pattern matches on two `Duration`s, providing handlers that receive both values.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const sum = Duration.matchPair(Duration.seconds(3), Duration.seconds(2), {
*   onMillis: (a, b) => a + b,
*   onNanos: (a, b) => Number(a + b),
*   onInfinity: () => Infinity
* })
* console.log(sum) // 5000
* ```
*
* @since 2.0.0
* @category pattern matching
*/
var matchPair = /*#__PURE__*/ dual(3, (self, that, options) => {
	if (self.value._tag === "Infinity" || self.value._tag === "NegativeInfinity" || that.value._tag === "Infinity" || that.value._tag === "NegativeInfinity") return options.onInfinity(self, that);
	if (self.value._tag === "Millis") return that.value._tag === "Millis" ? options.onMillis(self.value.millis, that.value.millis) : options.onNanos(toNanosUnsafe(self), that.value.nanos);
	else return options.onNanos(self.value.nanos, toNanosUnsafe(that));
});
/**
* Order instance for `Duration`, allowing comparison operations.
*
* `NegativeInfinity` < any finite value < `Infinity`.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const durations = [
*   Duration.seconds(3),
*   Duration.seconds(1),
*   Duration.seconds(2)
* ]
* const sorted = durations.sort((a, b) => Duration.Order(a, b))
* console.log(sorted.map(Duration.toSeconds)) // [1, 2, 3]
* ```
*
* @category instances
* @since 2.0.0
*/
var Order$3 = /*#__PURE__*/ make$13((self, that) => matchPair(self, that, {
	onMillis: (self, that) => self < that ? -1 : self > that ? 1 : 0,
	onNanos: (self, that) => self < that ? -1 : self > that ? 1 : 0,
	onInfinity: (self, that) => {
		if (self.value._tag === that.value._tag) return 0;
		if (self.value._tag === "Infinity") return 1;
		if (self.value._tag === "NegativeInfinity") return -1;
		if (that.value._tag === "Infinity") return -1;
		return 1;
	}
}));
/**
* Checks if a `Duration` is between a `minimum` and `maximum` value.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isInRange = Duration.between(Duration.seconds(3), {
*   minimum: Duration.seconds(2),
*   maximum: Duration.seconds(5)
* })
* console.log(isInRange) // true
* ```
*
* @category predicates
* @since 2.0.0
*/
var between$2 = /*#__PURE__*/ isBetween(Order$3);
/**
* Equivalence instance for `Duration`, allowing equality comparisons.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isEqual = Duration.Equivalence(Duration.seconds(5), Duration.millis(5000))
* console.log(isEqual) // true
* ```
*
* @category instances
* @since 2.0.0
*/
var Equivalence$4 = (self, that) => matchPair(self, that, {
	onMillis: (self, that) => self === that,
	onNanos: (self, that) => self === that,
	onInfinity: (self, that) => self.value._tag === that.value._tag
});
/**
* Returns the smaller of two Durations.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const shorter = Duration.min(Duration.seconds(5), Duration.seconds(3))
* console.log(Duration.toSeconds(shorter)) // 3
* ```
*
* @since 2.0.0
* @category order
*/
var min$2 = /*#__PURE__*/ min$4(Order$3);
/**
* Returns the larger of two Durations.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const longer = Duration.max(Duration.seconds(5), Duration.seconds(3))
* console.log(Duration.toSeconds(longer)) // 5
* ```
*
* @since 2.0.0
* @category order
*/
var max$2 = /*#__PURE__*/ max$4(Order$3);
/**
* Clamps a Duration between a minimum and maximum value.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const clamped = Duration.clamp(Duration.seconds(10), {
*   minimum: Duration.seconds(2),
*   maximum: Duration.seconds(5)
* })
* console.log(Duration.toSeconds(clamped)) // 5
* ```
*
* @since 2.0.0
* @category order
*/
var clamp$2 = /*#__PURE__*/ clamp$4(Order$3);
/**
* Divides a Duration by a number, returning `undefined` if division is invalid.
*
* **Example**
*
* ```ts
* import { Duration } from "effect"
*
* const d = Duration.divide(Duration.seconds(10), 2)
* console.log(d?.pipe(Duration.toSeconds)) // 5
*
* Duration.divide(Duration.seconds(10), 0) // undefined
* ```
*
* @since 4.0.0
* @category math
*/
var divide$1 = /*#__PURE__*/ dual(2, (self, by) => {
	if (!Number.isFinite(by)) return void 0;
	if (by === 0 || Object.is(by, -0)) return void 0;
	return match$6(self, {
		onMillis: (millis) => make$8(millis / by),
		onNanos: (nanos) => {
			try {
				return make$8(nanos / BigInt(by));
			} catch {
				return;
			}
		},
		onInfinity: () => by > 0 ? infinity : negativeInfinity,
		onNegativeInfinity: () => by > 0 ? negativeInfinity : infinity
	});
});
/**
* Divides a Duration by a number, potentially returning infinity or zero.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const half = Duration.divideUnsafe(Duration.seconds(10), 2)
* console.log(Duration.toSeconds(half)) // 5
*
* const infinite = Duration.divideUnsafe(Duration.seconds(10), 0)
* console.log(Duration.toMillis(infinite)) // Infinity
* ```
*
* @since 2.4.19
* @category math
*/
var divideUnsafe = /*#__PURE__*/ dual(2, (self, by) => {
	if (!Number.isFinite(by)) return zero;
	return match$6(self, {
		onMillis: (millis) => make$8(millis / by),
		onNanos: (nanos) => {
			if (Object.is(by, 0) || Object.is(by, -0)) {
				if (nanos === bigint0$2) return zero;
				return nanos > bigint0$2 === Object.is(by, 0) ? infinity : negativeInfinity;
			}
			try {
				return make$8(nanos / BigInt(by));
			} catch {
				return zero;
			}
		},
		onInfinity: () => by > 0 ? infinity : by < 0 ? negativeInfinity : zero,
		onNegativeInfinity: () => by > 0 ? negativeInfinity : by < 0 ? infinity : zero
	});
});
/**
* Multiplies a Duration by a number.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const doubled = Duration.times(Duration.seconds(5), 2)
* console.log(Duration.toSeconds(doubled)) // 10
* ```
*
* @since 2.0.0
* @category math
*/
var times = /*#__PURE__*/ dual(2, (self, times) => match$6(self, {
	onMillis: (millis) => make$8(millis * times),
	onNanos: (nanos) => make$8(nanos * BigInt(times)),
	onInfinity: () => times > 0 ? infinity : times < 0 ? negativeInfinity : zero,
	onNegativeInfinity: () => times > 0 ? negativeInfinity : times < 0 ? infinity : zero
}));
/**
* Subtracts one Duration from another. The result can be negative.
*
* **Infinity Subtraction Rules**
* - infinity - infinity = 0
* - infinity - negativeInfinity = infinity
* - infinity - finite = infinity
* - negativeInfinity - negativeInfinity = 0
* - negativeInfinity - infinity = negativeInfinity
* - negativeInfinity - finite = negativeInfinity
* - finite - infinity = negativeInfinity
* - finite - negativeInfinity = infinity
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const result = Duration.subtract(Duration.seconds(10), Duration.seconds(3))
* console.log(Duration.toSeconds(result)) // 7
* ```
*
* @since 2.0.0
* @category math
*/
var subtract$2 = /*#__PURE__*/ dual(2, (self, that) => matchPair(self, that, {
	onMillis: (self, that) => make$8(self - that),
	onNanos: (self, that) => make$8(self - that),
	onInfinity: (self, that) => {
		const s = self.value._tag;
		const t = that.value._tag;
		if (s === "Infinity") return t === "Infinity" ? zero : infinity;
		if (s === "NegativeInfinity") return t === "NegativeInfinity" ? zero : negativeInfinity;
		return t === "Infinity" ? negativeInfinity : infinity;
	}
}));
/**
* Adds two Durations together.
*
* **Infinity Addition Rules**
* - infinity + infinity = infinity
* - infinity + negativeInfinity = zero
* - infinity + finite = infinity
* - negativeInfinity + negativeInfinity = negativeInfinity
* - negativeInfinity + finite = negativeInfinity
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const total = Duration.sum(Duration.seconds(5), Duration.seconds(3))
* console.log(Duration.toSeconds(total)) // 8
* ```
*
* @since 2.0.0
* @category math
*/
var sum$1 = /*#__PURE__*/ dual(2, (self, that) => matchPair(self, that, {
	onMillis: (self, that) => make$8(self + that),
	onNanos: (self, that) => make$8(self + that),
	onInfinity: (self, that) => {
		const s = self.value._tag;
		const t = that.value._tag;
		if (s === "Infinity" && t === "NegativeInfinity") return zero;
		if (s === "NegativeInfinity" && t === "Infinity") return zero;
		if (s === "Infinity" || t === "Infinity") return infinity;
		if (s === "NegativeInfinity" || t === "NegativeInfinity") return negativeInfinity;
		return zero;
	}
}));
/**
* Checks if the first Duration is less than the second.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isLess = Duration.isLessThan(Duration.seconds(3), Duration.seconds(5))
* console.log(isLess) // true
* ```
*
* @since 2.0.0
* @category predicates
*/
var isLessThan$2 = /*#__PURE__*/ isLessThan$3(Order$3);
/**
* Checks if the first Duration is less than or equal to the second.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isLessOrEqual = Duration.isLessThanOrEqualTo(
*   Duration.seconds(5),
*   Duration.seconds(5)
* )
* console.log(isLessOrEqual) // true
* ```
*
* @since 2.0.0
* @category predicates
*/
var isLessThanOrEqualTo$2 = /*#__PURE__*/ isLessThanOrEqualTo$3(Order$3);
/**
* Checks if the first Duration is greater than the second.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isGreater = Duration.isGreaterThan(Duration.seconds(5), Duration.seconds(3))
* console.log(isGreater) // true
* ```
*
* @since 2.0.0
* @category predicates
*/
var isGreaterThan$2 = /*#__PURE__*/ isGreaterThan$3(Order$3);
/**
* Checks if the first Duration is greater than or equal to the second.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isGreaterOrEqual = Duration.isGreaterThanOrEqualTo(
*   Duration.seconds(5),
*   Duration.seconds(5)
* )
* console.log(isGreaterOrEqual) // true
* ```
*
* @since 2.0.0
* @category predicates
*/
var isGreaterThanOrEqualTo$2 = /*#__PURE__*/ isGreaterThanOrEqualTo$3(Order$3);
/**
* Checks if two Durations are equal.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* const isEqual = Duration.equals(Duration.seconds(5), Duration.millis(5000))
* console.log(isEqual) // true
* ```
*
* @since 2.0.0
* @category predicates
*/
var equals$2 = /*#__PURE__*/ dual(2, (self, that) => Equivalence$4(self, that));
/**
* Converts a `Duration` to its parts.
*
* @example
* ```ts
* import { Duration } from "effect"
*
* // Create a complex duration by adding multiple parts
* const duration = Duration.sum(
*   Duration.sum(
*     Duration.sum(Duration.days(1), Duration.hours(2)),
*     Duration.sum(Duration.minutes(30), Duration.seconds(45))
*   ),
*   Duration.millis(123)
* )
* const components = Duration.parts(duration)
* console.log(components)
* // {
* //   days: 1,
* //   hours: 2,
* //   minutes: 30,
* //   seconds: 45,
* //   millis: 123,
* //   nanos: 0
* // }
*
* const complex = Duration.sum(Duration.hours(25), Duration.minutes(90))
* const complexParts = Duration.parts(complex)
* console.log(complexParts)
* // {
* //   days: 1,
* //   hours: 2,
* //   minutes: 30,
* //   seconds: 0,
* //   millis: 0,
* //   nanos: 0
* // }
* ```
*
* @since 3.8.0
* @category conversions
*/
var parts = (self) => {
	if (self.value._tag === "Infinity") return {
		days: Infinity,
		hours: Infinity,
		minutes: Infinity,
		seconds: Infinity,
		millis: Infinity,
		nanos: Infinity
	};
	if (self.value._tag === "NegativeInfinity") return {
		days: -Infinity,
		hours: -Infinity,
		minutes: -Infinity,
		seconds: -Infinity,
		millis: -Infinity,
		nanos: -Infinity
	};
	const n = toNanosUnsafe(self);
	const neg = n < bigint0$2;
	const a = neg ? -n : n;
	const ms = a / bigint1e6;
	const sec = ms / bigint1e3;
	const min = sec / bigint60;
	const hr = min / bigint60;
	const d = hr / bigint24;
	const sign = neg ? -1 : 1;
	return {
		days: sign * Number(d),
		hours: sign * Number(hr % bigint24),
		minutes: sign * Number(min % bigint60),
		seconds: sign * Number(sec % bigint60),
		millis: sign * Number(ms % bigint1e3),
		nanos: sign * Number(a % bigint1e6)
	};
};
/**
* Converts a `Duration` to a human readable string.
*
* @since 2.0.0
* @category conversions
* @example
* ```ts
* import { Duration } from "effect"
*
* Duration.format(Duration.millis(1000)) // "1s"
* Duration.format(Duration.millis(1001)) // "1s 1ms"
* ```
*/
var format$1 = (self) => {
	if (self.value._tag === "Infinity") return "Infinity";
	if (self.value._tag === "NegativeInfinity") return "-Infinity";
	if (isZero(self)) return "0";
	if (isNegative(self)) return "-" + format$1(abs(self));
	const fragments = parts(self);
	const pieces = [];
	if (fragments.days !== 0) pieces.push(`${fragments.days}d`);
	if (fragments.hours !== 0) pieces.push(`${fragments.hours}h`);
	if (fragments.minutes !== 0) pieces.push(`${fragments.minutes}m`);
	if (fragments.seconds !== 0) pieces.push(`${fragments.seconds}s`);
	if (fragments.millis !== 0) pieces.push(`${fragments.millis}ms`);
	if (fragments.nanos !== 0) pieces.push(`${fragments.nanos}ns`);
	return pieces.join(" ");
};
/**
* A `Reducer` for summing `Duration`s.
*
* @since 4.0.0
*/
var ReducerSum$1 = /*#__PURE__*/ make$12(sum$1, zero);
/**
* A `Combiner` that returns the maximum `Duration`.
*
* @since 4.0.0
*/
var CombinerMax = /*#__PURE__*/ max$5(Order$3);
/**
* A `Combiner` that returns the minimum `Duration`.
*
* @since 4.0.0
*/
var CombinerMin = /*#__PURE__*/ min$5(Order$3);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Filter.js
var Filter_exports = /* @__PURE__ */ __exportAll({
	andLeft: () => andLeft,
	andRight: () => andRight,
	bigint: () => bigint,
	boolean: () => boolean,
	compose: () => compose$1,
	composePassthrough: () => composePassthrough,
	date: () => date,
	equals: () => equals$1,
	equalsStrict: () => equalsStrict,
	fromPredicate: () => fromPredicate,
	fromPredicateOption: () => fromPredicateOption,
	has: () => has,
	instanceOf: () => instanceOf,
	make: () => make$7,
	makeEffect: () => makeEffect,
	mapFail: () => mapFail,
	number: () => number,
	or: () => or,
	reason: () => reason,
	string: () => string,
	symbol: () => symbol,
	tagged: () => tagged$1,
	toOption: () => toOption,
	toPredicate: () => toPredicate,
	toResult: () => toResult,
	try: () => try_$2,
	zip: () => zip$2,
	zipWith: () => zipWith$2
});
/**
* Creates a Filter from a function that returns either a `pass` or `fail` value.
*
* This is the primary constructor for creating custom filters. The function
* should return either `Result.succeed(value)` or `Result.fail(value)`.
*
* @example
* ```ts
* import { Filter, Result } from "effect"
*
* // Create a filter for positive numbers
* const positiveFilter = Filter.make((n: number) => n > 0 ? Result.succeed(n) : Result.fail(n))
*
* // Create a filter that transforms strings to uppercase
* const uppercaseFilter = Filter.make((s: string) =>
*   s.length > 0 ? Result.succeed(s.toUpperCase()) : Result.fail(s)
* )
* ```
*
* @since 4.0.0
* @category Constructors
*/
var make$7 = (f) => f;
/**
* Creates an effectful Filter from a function that returns an Effect.
*
* This constructor is used when the filtering operation needs to perform
* effectful computations, such as async operations, error handling, or
* accessing services from the environment.
*
* @example
* ```ts
* import { Effect, Filter, Result } from "effect"
*
* // Create an effectful filter that validates async
* const asyncValidate = Filter.makeEffect((id: string) =>
*   Effect.gen(function*() {
*     const isValid = yield* Effect.succeed(id.length > 0)
*     return isValid ? Result.succeed(id) : Result.fail(id)
*   })
* )
* ```
*
* @since 4.0.0
* @category Constructors
*/
var makeEffect = (f) => f;
/**
* @since 4.0.0
* @category Mapping
*/
var mapFail = /*#__PURE__*/ dual(2, (self, f) => (input) => mapError$3(self(input), f));
var try_$2 = (f) => (input) => {
	try {
		return succeed$6(f(input));
	} catch {
		return fail$6(input);
	}
};
/**
* Creates a Filter from a predicate or refinement function.
*
* This is a convenient way to create filters from boolean-returning functions.
* When the predicate returns true, the input value is passed through unchanged.
* When it returns false, the `fail` type is returned.
*
* @example
* ```ts
* import { Filter, Result } from "effect"
*
* // Create filter from predicate
* const positiveNumbers = Filter.fromPredicate((n: number) => n > 0)
* const nonEmptyStrings = Filter.fromPredicate((s: string) => s.length > 0)
*
* // Type refinement
* const isString = Filter.fromPredicate((x: unknown): x is string =>
*   typeof x === "string"
* )
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromPredicate = (predicate) => (input) => predicate(input) ? succeed$6(input) : fail$6(input);
/**
* Creates a Filter from a function that returns an Option.
*
* @since 4.0.0
* @category Constructors
*/
var fromPredicateOption = (predicate) => (input) => {
	const o = predicate(input);
	return o._tag === "None" ? fail$6(input) : succeed$6(o.value);
};
/**
* Converts a Filter into a predicate function.
*
* @since 4.0.0
* @category Constructors
*/
var toPredicate = (self) => (input) => !isFailure$3(self(input));
/**
* A predefined filter that only passes through string values.
*
* @example
* ```ts
* import { Filter, Result } from "effect"
*
* console.log(Filter.string("hello")) // Result.succeed("hello")
* console.log(Filter.string(42)) // fail
* ```
*
* @since 4.0.0
* @category Constructors
*/
var string = /*#__PURE__*/ fromPredicate(isString$1);
/**
* @since 4.0.0
* @category Constructors
*/
var equalsStrict = (value) => (u) => u === value ? succeed$6(value) : fail$6(u);
/**
* @since 4.0.0
* @category Constructors
*/
var has = (key) => (input) => input.has(key) ? succeed$6(input) : fail$6(input);
/**
* Creates a filter that only passes instances of the given constructor.
*
* @since 4.0.0
* @category Constructors
*/
var instanceOf = (constructor) => (u) => u instanceof constructor ? succeed$6(u) : fail$6(u);
/**
* A predefined filter that only passes through number values.
*
* @example
* ```ts
* import { Filter, Result } from "effect"
*
* console.log(Filter.number(42)) // Result.succeed(42)
* console.log(Filter.number("42")) // fail
* ```
*
* @since 4.0.0
* @category Constructors
*/
var number = /*#__PURE__*/ fromPredicate(isNumber$1);
/**
* A predefined filter that only passes through boolean values.
*
* @since 4.0.0
* @category Constructors
*/
var boolean = /*#__PURE__*/ fromPredicate(isBoolean);
/**
* A predefined filter that only passes through BigInt values.
*
* @since 4.0.0
* @category Constructors
*/
var bigint = /*#__PURE__*/ fromPredicate(isBigInt);
/**
* A predefined filter that only passes through Symbol values.
*
* @since 4.0.0
* @category Constructors
*/
var symbol = /*#__PURE__*/ fromPredicate(isSymbol);
/**
* A predefined filter that only passes through Date objects.
*
* @since 4.0.0
* @category Constructors
*/
var date = /*#__PURE__*/ fromPredicate(isDate);
/**
* Creates a filter that checks if an input is tagged with a specific tag.
*
* @since 4.0.0
* @category Constructors
*/
var tagged$1 = function() {
	return arguments.length === 0 ? taggedImpl : taggedImpl(arguments[0]);
};
var taggedImpl = (tag) => (input) => isTagged(input, tag) ? succeed$6(input) : fail$6(input);
/**
* Creates a filter that extracts a reason from a tagged error.
*
* @since 4.0.0
* @category Constructors
*/
var reason = function() {
	return arguments.length === 0 ? reasonImpl : reasonImpl(arguments[0], arguments[1]);
};
var reasonImpl = (tag, reasonTag) => (input) => {
	if (isTagged(input, tag) && hasProperty(input, "reason") && isTagged(input.reason, reasonTag)) return succeed$6(input.reason);
	return fail$6(input);
};
/**
* Creates a filter that only passes values equal to the specified value using structural equality.
*
* @since 4.0.0
* @category Constructors
*/
var equals$1 = (value) => (u) => equals$3(u, value) ? succeed$6(value) : fail$6(u);
/**
* Combines two filters with logical OR semantics.
*
* @since 4.0.0
* @category Combinators
*/
var or = /*#__PURE__*/ dual(2, (self, that) => (input) => {
	const selfResult = self(input);
	return isSuccess$3(selfResult) ? selfResult : that(input);
});
/**
* Combines two filters and applies a function to their results.
*
* Both filters must succeed (not return `fail`) for the combination to succeed.
* If both filters pass, their outputs are combined using the provided function.
*
* @since 4.0.0
* @category Combinators
*/
var zipWith$2 = /*#__PURE__*/ dual(3, (left, right, f) => (input) => {
	const leftResult = left(input);
	if (isFailure$3(leftResult)) return leftResult;
	const rightResult = right(input);
	if (isFailure$3(rightResult)) return rightResult;
	return succeed$6(f(leftResult.success, rightResult.success));
});
/**
* Combines two filters into a tuple of their results.
*
* Both filters must succeed for the combination to succeed. If both pass,
* their outputs are combined into a tuple.
*
* @example
* ```ts
* import { Filter } from "effect"
*
* const positiveNumbers = Filter.fromPredicate((n: number) => n > 0)
* const evenNumbers = Filter.fromPredicate((n: number) => n % 2 === 0)
*
* const positiveAndEven = Filter.zip(positiveNumbers, evenNumbers)
* ```
*
* @since 4.0.0
* @category Combinators
*/
var zip$2 = /*#__PURE__*/ dual(2, (left, right) => zipWith$2(left, right, (leftResult, rightResult) => [leftResult, rightResult]));
/**
* Combines two filters but only returns the result of the left filter.
*
* @example
* ```ts
* import { Filter } from "effect"
*
* const positiveNumbers = Filter.fromPredicate((n: number) => n > 0)
* const evenNumbers = Filter.fromPredicate((n: number) => n % 2 === 0)
*
* const positiveEven = Filter.andLeft(positiveNumbers, evenNumbers)
* ```
*
* @since 4.0.0
* @category Combinators
*/
var andLeft = /*#__PURE__*/ dual(2, (left, right) => zipWith$2(left, right, (leftResult) => leftResult));
/**
* Combines two filters but only returns the result of the right filter.
*
* @example
* ```ts
* import { Filter, Result } from "effect"
*
* const positiveNumbers = Filter.fromPredicate((n: number) => n > 0)
* const doubleNumbers = Filter.make((n: number) =>
*   n > 0 ? Result.succeed(n * 2) : Result.fail(n)
* )
*
* const positiveDoubled = Filter.andRight(positiveNumbers, doubleNumbers)
* ```
*
* @since 4.0.0
* @category Combinators
*/
var andRight = /*#__PURE__*/ dual(2, (left, right) => zipWith$2(left, right, (_, rightResult) => rightResult));
/**
* Composes two filters sequentially, feeding the output of the first into the second.
*
* @example
* ```ts
* import { Filter, Result } from "effect"
*
* const stringFilter = Filter.string
* const nonEmptyUpper = Filter.make((s: string) =>
*   s.length > 0 ? Result.succeed(s.toUpperCase()) : Result.fail(s)
* )
*
* const stringToUpper = Filter.compose(stringFilter, nonEmptyUpper)
* ```
*
* @since 4.0.0
* @category Combinators
*/
var compose$1 = /*#__PURE__*/ dual(2, (left, right) => (input) => {
	const leftOut = left(input);
	if (isFailure$3(leftOut)) return leftOut;
	return right(leftOut.success);
});
/**
* Composes two filters sequentially, allowing the output of the first to be
* passed to the second.
*
* This is similar to `compose`, but it will always fail with the original
* input.
*
* @since 4.0.0
* @category Combinators
*/
var composePassthrough = /*#__PURE__*/ dual(2, (left, right) => (input) => {
	const leftOut = left(input);
	if (isFailure$3(leftOut)) return fail$6(input);
	const rightOut = right(leftOut.success);
	if (isFailure$3(rightOut)) return fail$6(input);
	return rightOut;
});
/**
* @since 4.0.0
* @category Conversions
*/
var toOption = (self) => (input) => {
	const result = self(input);
	return isFailure$3(result) ? none() : some$2(result.success);
};
/**
* @since 4.0.0
* @category Conversions
*/
var toResult = (self) => (input) => {
	const result = self(input);
	return isFailure$3(result) ? fail$6(result.failure) : succeed$6(result.success);
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ServiceMap.js
var ServiceMap_exports = /* @__PURE__ */ __exportAll({
	Reference: () => Reference,
	Service: () => Service,
	add: () => add$1,
	addOrOmit: () => addOrOmit,
	empty: () => empty$3,
	get: () => get,
	getOption: () => getOption,
	getOrElse: () => getOrElse,
	getOrUndefined: () => getOrUndefined,
	getReferenceUnsafe: () => getReferenceUnsafe,
	getUnsafe: () => getUnsafe,
	isKey: () => isKey,
	isReference: () => isReference,
	isServiceMap: () => isServiceMap,
	make: () => make$6,
	makeUnsafe: () => makeUnsafe$3,
	merge: () => merge$2,
	mergeAll: () => mergeAll$1,
	omit: () => omit,
	pick: () => pick
});
var ServiceTypeId = "~effect/ServiceMap/Service";
/**
* @example
* ```ts
* import { ServiceMap } from "effect"
*
* // Create a simple service
* const Database = ServiceMap.Service<{
*   query: (sql: string) => string
* }>("Database")
*
* // Create a service class
* class Config extends ServiceMap.Service<Config, {
*   port: number
* }>()("Config") {}
*
* // Use the services to create service maps
* const db = ServiceMap.make(Database, {
*   query: (sql) => `Result: ${sql}`
* })
* const config = ServiceMap.make(Config, { port: 8080 })
* ```
*
* @since 4.0.0
* @category Constructors
*/
var Service = function() {
	const prevLimit = Error.stackTraceLimit;
	Error.stackTraceLimit = 2;
	const err = /* @__PURE__ */ new Error();
	Error.stackTraceLimit = prevLimit;
	function KeyClass() {}
	const self = KeyClass;
	Object.setPrototypeOf(self, ServiceProto);
	Object.defineProperty(self, "stack", { get() {
		return err.stack;
	} });
	if (arguments.length > 0) {
		self.key = arguments[0];
		if (arguments[1]?.defaultValue) {
			self[ReferenceTypeId] = ReferenceTypeId;
			self.defaultValue = arguments[1].defaultValue;
		}
		return self;
	}
	return function(key, options) {
		self.key = key;
		if (options?.make) self.make = options.make;
		return self;
	};
};
var ServiceProto = {
	[ServiceTypeId]: {
		_Service: (_) => _,
		_Identifier: (_) => _
	},
	...PipeInspectableProto,
	...YieldableProto,
	toJSON() {
		return {
			_id: "Service",
			key: this.key,
			stack: this.stack
		};
	},
	asEffect() {
		return (this.asEffect = constant(withFiber$1((fiber) => exitSucceed(get(fiber.services, this)))))();
	},
	of(self) {
		return self;
	},
	serviceMap(self) {
		return make$6(this, self);
	},
	use(f) {
		return withFiber$1((fiber) => f(get(fiber.services, this)));
	},
	useSync(f) {
		return withFiber$1((fiber) => exitSucceed(f(get(fiber.services, this))));
	}
};
var ReferenceTypeId = "~effect/ServiceMap/Reference";
var TypeId$9 = "~effect/ServiceMap";
/**
* @example
* ```ts
* import { ServiceMap } from "effect"
*
* // Create a service map from a Map (unsafe)
* const map = new Map([
*   ["Logger", { log: (msg: string) => console.log(msg) }]
* ])
*
* const services = ServiceMap.makeUnsafe(map)
* ```
*
* @since 4.0.0
* @category Constructors
*/
var makeUnsafe$3 = (mapUnsafe) => {
	const self = Object.create(Proto$2);
	self.mapUnsafe = mapUnsafe;
	return self;
};
var Proto$2 = {
	...PipeInspectableProto,
	[TypeId$9]: { _Services: (_) => _ },
	toJSON() {
		return {
			_id: "ServiceMap",
			services: Array.from(this.mapUnsafe).map(([key, value]) => ({
				key,
				value
			}))
		};
	},
	[symbol$2](that) {
		if (!isServiceMap(that) || this.mapUnsafe.size !== that.mapUnsafe.size) return false;
		for (const k of this.mapUnsafe.keys()) if (!that.mapUnsafe.has(k) || !equals$3(this.mapUnsafe.get(k), that.mapUnsafe.get(k))) return false;
		return true;
	},
	[symbol$1]() {
		return number$1(this.mapUnsafe.size);
	}
};
/**
* Checks if the provided argument is a `ServiceMap`.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* assert.strictEqual(ServiceMap.isServiceMap(ServiceMap.empty()), true)
* ```
*
* @since 4.0.0
* @category Guards
*/
var isServiceMap = (u) => hasProperty(u, TypeId$9);
/**
* Checks if the provided argument is a `Key`.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* assert.strictEqual(ServiceMap.isKey(ServiceMap.Service("Service")), true)
* ```
*
* @since 4.0.0
* @category Guards
*/
var isKey = (u) => hasProperty(u, ServiceTypeId);
/**
* Checks if the provided argument is a `Reference`.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const LoggerRef = ServiceMap.Reference("Logger", {
*   defaultValue: () => ({ log: (msg: string) => console.log(msg) })
* })
*
* assert.strictEqual(ServiceMap.isReference(LoggerRef), true)
* assert.strictEqual(ServiceMap.isReference(ServiceMap.Service("Key")), false)
* ```
*
* @since 4.0.0
* @category Guards
*/
var isReference = (u) => hasProperty(u, ReferenceTypeId);
/**
* Returns an empty `ServiceMap`.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* assert.strictEqual(ServiceMap.isServiceMap(ServiceMap.empty()), true)
* ```
*
* @since 4.0.0
* @category Constructors
*/
var empty$3 = () => emptyServiceMap;
var emptyServiceMap = /*#__PURE__*/ makeUnsafe$3(/*#__PURE__*/ new Map());
/**
* Creates a new `ServiceMap` with a single service associated to the key.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
*
* const Services = ServiceMap.make(Port, { PORT: 8080 })
*
* assert.deepStrictEqual(ServiceMap.get(Services, Port), { PORT: 8080 })
* ```
*
* @since 4.0.0
* @category Constructors
*/
var make$6 = (key, service) => makeUnsafe$3(/* @__PURE__ */ new Map([[key.key, service]]));
/**
* Adds a service to a given `ServiceMap`.
*
* @example
* ```ts
* import { pipe, ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const someServiceMap = ServiceMap.make(Port, { PORT: 8080 })
*
* const Services = pipe(
*   someServiceMap,
*   ServiceMap.add(Timeout, { TIMEOUT: 5000 })
* )
*
* assert.deepStrictEqual(ServiceMap.get(Services, Port), { PORT: 8080 })
* assert.deepStrictEqual(ServiceMap.get(Services, Timeout), { TIMEOUT: 5000 })
* ```
*
* @since 4.0.0
* @category Adders
*/
var add$1 = /*#__PURE__*/ dual(3, (self, key, service) => {
	const map = new Map(self.mapUnsafe);
	map.set(key.key, service);
	return makeUnsafe$3(map);
});
/**
* @since 4.0.0
* @category Adders
*/
var addOrOmit = /*#__PURE__*/ dual(3, (self, key, service) => {
	const map = new Map(self.mapUnsafe);
	if (service._tag === "None") map.delete(key.key);
	else map.set(key.key, service.value);
	return makeUnsafe$3(map);
});
/**
* Get a service from the context that corresponds to the given key, or
* use the fallback value.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Logger = ServiceMap.Service<{ log: (msg: string) => void }>("Logger")
* const Database = ServiceMap.Service<{ query: (sql: string) => string }>(
*   "Database"
* )
*
* const services = ServiceMap.make(Logger, {
*   log: (msg: string) => console.log(msg)
* })
*
* const logger = ServiceMap.getOrElse(services, Logger, () => ({ log: () => {} }))
* const database = ServiceMap.getOrElse(
*   services,
*   Database,
*   () => ({ query: () => "fallback" })
* )
*
* assert.deepStrictEqual(logger, { log: (msg: string) => console.log(msg) })
* assert.deepStrictEqual(database, { query: () => "fallback" })
* ```
*
* @since 4.0.0
* @category Getters
*/
var getOrElse = /*#__PURE__*/ dual(3, (self, key, orElse) => {
	if (self.mapUnsafe.has(key.key)) return self.mapUnsafe.get(key.key);
	return isReference(key) ? getDefaultValue(key) : orElse();
});
/**
* @since 4.0.0
* @category Getters
*/
var getOrUndefined = /*#__PURE__*/ dual(2, (self, key) => self.mapUnsafe.get(key.key));
/**
* Get a service from the context that corresponds to the given key.
*
* This function is unsafe because if the key is not present in the context, a
* runtime error will be thrown.
*
* For a safer version see {@link getOption}.
*
* @param self - The `ServiceMap` to search for the service.
* @param service - The `Service` of the service to retrieve.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const Services = ServiceMap.make(Port, { PORT: 8080 })
*
* assert.deepStrictEqual(ServiceMap.getUnsafe(Services, Port), { PORT: 8080 })
* assert.throws(() => ServiceMap.getUnsafe(Services, Timeout))
* ```
*
* @since 4.0.0
* @category unsafe
*/
var getUnsafe = /*#__PURE__*/ dual(2, (self, service) => {
	if (!self.mapUnsafe.has(service.key)) {
		if (ReferenceTypeId in service) return getDefaultValue(service);
		throw serviceNotFoundError(service);
	}
	return self.mapUnsafe.get(service.key);
});
/**
* Get a service from the context that corresponds to the given key.
*
* @param self - The `ServiceMap` to search for the service.
* @param service - The `Service` of the service to retrieve.
*
* @example
* ```ts
* import { pipe, ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const Services = pipe(
*   ServiceMap.make(Port, { PORT: 8080 }),
*   ServiceMap.add(Timeout, { TIMEOUT: 5000 })
* )
*
* assert.deepStrictEqual(ServiceMap.get(Services, Timeout), { TIMEOUT: 5000 })
* ```
*
* @since 4.0.0
* @category Getters
*/
var get = getUnsafe;
/**
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const LoggerRef = ServiceMap.Reference("Logger", {
*   defaultValue: () => ({ log: (msg: string) => console.log(msg) })
* })
*
* const services = ServiceMap.empty()
* const logger = ServiceMap.getReferenceUnsafe(services, LoggerRef)
*
* assert.deepStrictEqual(logger, { log: (msg: string) => console.log(msg) })
* ```
*
* @since 4.0.0
* @category unsafe
*/
var getReferenceUnsafe = (self, service) => {
	if (!self.mapUnsafe.has(service.key)) return getDefaultValue(service);
	return self.mapUnsafe.get(service.key);
};
var defaultValueCacheKey = "~effect/ServiceMap/defaultValue";
var getDefaultValue = (ref) => {
	if (defaultValueCacheKey in ref) return ref[defaultValueCacheKey];
	return ref[defaultValueCacheKey] = ref.defaultValue();
};
var serviceNotFoundError = (service) => {
	const error = /* @__PURE__ */ new Error(`Service not found${service.key ? `: ${String(service.key)}` : ""}`);
	if (service.stack) {
		const lines = service.stack.split("\n");
		if (lines.length > 2) {
			const afterAt = lines[2].match(/at (.*)/);
			if (afterAt) error.message = error.message + ` (defined at ${afterAt[1]})`;
		}
	}
	if (error.stack) {
		const lines = error.stack.split("\n");
		lines.splice(1, 3);
		error.stack = lines.join("\n");
	}
	return error;
};
/**
* Get the value associated with the specified key from the context wrapped in
* an `Option` object. If the key is not found, the `Option` object will be
* `None`.
*
* @param self - The `ServiceMap` to search for the service.
* @param service - The `Service` of the service to retrieve.
*
* @example
* ```ts
* import { Option, ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const Services = ServiceMap.make(Port, { PORT: 8080 })
*
* assert.deepStrictEqual(
*   ServiceMap.getOption(Services, Port),
*   Option.some({ PORT: 8080 })
* )
* assert.deepStrictEqual(ServiceMap.getOption(Services, Timeout), Option.none())
* ```
*
* @since 4.0.0
* @category Getters
*/
var getOption = /*#__PURE__*/ dual(2, (self, service) => {
	if (self.mapUnsafe.has(service.key)) return some$2(self.mapUnsafe.get(service.key));
	return isReference(service) ? some$2(getDefaultValue(service)) : none();
});
/**
* Merges two `ServiceMap`s, returning a new `ServiceMap` containing the services of both.
*
* @param self - The first `ServiceMap` to merge.
* @param that - The second `ServiceMap` to merge.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const firstServiceMap = ServiceMap.make(Port, { PORT: 8080 })
* const secondServiceMap = ServiceMap.make(Timeout, { TIMEOUT: 5000 })
*
* const Services = ServiceMap.merge(firstServiceMap, secondServiceMap)
*
* assert.deepStrictEqual(ServiceMap.get(Services, Port), { PORT: 8080 })
* assert.deepStrictEqual(ServiceMap.get(Services, Timeout), { TIMEOUT: 5000 })
* ```
*
* @since 4.0.0
* @category Utils
*/
var merge$2 = /*#__PURE__*/ dual(2, (self, that) => {
	if (self.mapUnsafe.size === 0) return that;
	if (that.mapUnsafe.size === 0) return self;
	const map = new Map(self.mapUnsafe);
	that.mapUnsafe.forEach((value, key) => map.set(key, value));
	return makeUnsafe$3(map);
});
/**
* Merges any number of `ServiceMap`s, returning a new `ServiceMap` containing the services of all.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
* const Host = ServiceMap.Service<{ HOST: string }>("Host")
*
* const firstServiceMap = ServiceMap.make(Port, { PORT: 8080 })
* const secondServiceMap = ServiceMap.make(Timeout, { TIMEOUT: 5000 })
* const thirdServiceMap = ServiceMap.make(Host, { HOST: "localhost" })
*
* const Services = ServiceMap.mergeAll(
*   firstServiceMap,
*   secondServiceMap,
*   thirdServiceMap
* )
*
* assert.deepStrictEqual(ServiceMap.get(Services, Port), { PORT: 8080 })
* assert.deepStrictEqual(ServiceMap.get(Services, Timeout), { TIMEOUT: 5000 })
* assert.deepStrictEqual(ServiceMap.get(Services, Host), { HOST: "localhost" })
* ```
*
* @since 3.12.0
*/
var mergeAll$1 = (...ctxs) => {
	const map = /* @__PURE__ */ new Map();
	for (let i = 0; i < ctxs.length; i++) ctxs[i].mapUnsafe.forEach((value, key) => {
		map.set(key, value);
	});
	return makeUnsafe$3(map);
};
/**
* Returns a new `ServiceMap` that contains only the specified services.
*
* @param self - The `ServiceMap` to prune services from.
* @param services - The list of `Service`s to be included in the new `ServiceMap`.
*
* @example
* ```ts
* import { Option, pipe, ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const someServiceMap = pipe(
*   ServiceMap.make(Port, { PORT: 8080 }),
*   ServiceMap.add(Timeout, { TIMEOUT: 5000 })
* )
*
* const Services = pipe(someServiceMap, ServiceMap.pick(Port))
*
* assert.deepStrictEqual(
*   ServiceMap.getOption(Services, Port),
*   Option.some({ PORT: 8080 })
* )
* assert.deepStrictEqual(ServiceMap.getOption(Services, Timeout), Option.none())
* ```
*
* @since 4.0.0
* @category Utils
*/
var pick = (...services) => (self) => {
	const map = /* @__PURE__ */ new Map();
	const keySet = new Set(services.map((key) => key.key));
	self.mapUnsafe.forEach((value, key) => {
		if (keySet.has(key)) map.set(key, value);
	});
	return makeUnsafe$3(map);
};
/**
* @example
* ```ts
* import { Option, pipe, ServiceMap } from "effect"
* import * as assert from "node:assert"
*
* const Port = ServiceMap.Service<{ PORT: number }>("Port")
* const Timeout = ServiceMap.Service<{ TIMEOUT: number }>("Timeout")
*
* const someServiceMap = pipe(
*   ServiceMap.make(Port, { PORT: 8080 }),
*   ServiceMap.add(Timeout, { TIMEOUT: 5000 })
* )
*
* const Services = pipe(someServiceMap, ServiceMap.omit(Timeout))
*
* assert.deepStrictEqual(
*   ServiceMap.getOption(Services, Port),
*   Option.some({ PORT: 8080 })
* )
* assert.deepStrictEqual(ServiceMap.getOption(Services, Timeout), Option.none())
* ```
*
* @since 4.0.0
* @category Utils
*/
var omit = (...keys) => (self) => {
	const map = new Map(self.mapUnsafe);
	for (let i = 0; i < keys.length; i++) map.delete(keys[i].key);
	return makeUnsafe$3(map);
};
/**
* Creates a service map key with a default value.
*
* **Details**
*
* `ServiceMap.Reference` allows you to create a key that can hold a value. You
* can provide a default value for the service, which will automatically be used
* when the context is accessed, or override it with a custom implementation
* when needed.
*
* @example
* ```ts
* import { ServiceMap } from "effect"
*
* // Create a reference with a default value
* const LoggerRef = ServiceMap.Reference("Logger", {
*   defaultValue: () => ({ log: (msg: string) => console.log(msg) })
* })
*
* // The reference provides the default value when accessed from an empty context
* const services = ServiceMap.empty()
* const logger = ServiceMap.get(services, LoggerRef)
*
* // You can also override the default value
* const customServices = ServiceMap.make(LoggerRef, {
*   log: (msg: string) => `Custom: ${msg}`
* })
* const customLogger = ServiceMap.get(customServices, LoggerRef)
* ```
*
* @since 4.0.0
* @category References
*/
var Reference = Service;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Scheduler.js
var Scheduler_exports = /* @__PURE__ */ __exportAll({
	MaxOpsBeforeYield: () => MaxOpsBeforeYield,
	MixedScheduler: () => MixedScheduler,
	Scheduler: () => Scheduler
});
/**
* @since 4.0.0
* @category references
*/
var Scheduler = /*#__PURE__*/ Reference("effect/Scheduler", { defaultValue: () => new MixedScheduler() });
var setImmediate = "setImmediate" in globalThis ? (f) => {
	const timer = globalThis.setImmediate(f);
	return () => globalThis.clearImmediate(timer);
} : (f) => {
	const timer = setTimeout(f, 0);
	return () => clearTimeout(timer);
};
var PriorityBuckets = class {
	buckets = [];
	scheduleTask(task, priority) {
		const buckets = this.buckets;
		const len = buckets.length;
		let bucket;
		let index = 0;
		for (; index < len; index++) {
			if (buckets[index][0] > priority) break;
			bucket = buckets[index];
		}
		if (bucket && bucket[0] === priority) bucket[1].push(task);
		else if (index === len) buckets.push([priority, [task]]);
		else buckets.splice(index, 0, [priority, [task]]);
	}
	drain() {
		const buckets = this.buckets;
		this.buckets = [];
		return buckets;
	}
};
/**
* A scheduler implementation that provides efficient task scheduling
* with support for both synchronous and asynchronous execution modes.
*
* Features:
* - Batches tasks for efficient execution
* - Supports priority-based task scheduling
* - Configurable execution mode (sync/async)
* - Automatic yielding based on operation count
* - Optimized for high-throughput scenarios
*
* @example
* ```ts
* import { MixedScheduler } from "effect/Scheduler"
*
* // Create a mixed scheduler with async execution (default)
* const asyncScheduler = new MixedScheduler("async")
*
* // Create a mixed scheduler with sync execution
* const syncScheduler = new MixedScheduler("sync")
*
* // Schedule tasks with different priorities
* asyncScheduler.scheduleTask(() => console.log("High priority task"), 10)
* asyncScheduler.scheduleTask(() => console.log("Normal priority task"), 0)
* asyncScheduler.scheduleTask(() => console.log("Low priority task"), -1)
*
* // For sync scheduler, you can flush tasks immediately
* syncScheduler.scheduleTask(() => console.log("Task 1"), 0)
* syncScheduler.scheduleTask(() => console.log("Task 2"), 0)
*
* // Force flush all pending tasks in sync mode
* syncScheduler.flush()
* // Output: "Task 1", "Task 2"
*
* // Check execution mode
* console.log(asyncScheduler.executionMode) // "async"
* console.log(syncScheduler.executionMode) // "sync"
* ```
*
* @since 2.0.0
* @category schedulers
*/
var MixedScheduler = class {
	tasks = /*#__PURE__*/ new PriorityBuckets();
	running = void 0;
	executionMode;
	setImmediate;
	constructor(executionMode = "async", setImmediateFn = setImmediate) {
		this.executionMode = executionMode;
		this.setImmediate = setImmediateFn;
	}
	/**
	* @since 2.0.0
	*/
	scheduleTask(task, priority) {
		this.tasks.scheduleTask(task, priority);
		if (this.running === void 0) this.running = this.setImmediate(this.afterScheduled);
	}
	/**
	* @since 2.0.0
	*/
	afterScheduled = () => {
		this.running = void 0;
		this.runTasks();
	};
	/**
	* @since 2.0.0
	*/
	runTasks() {
		const buckets = this.tasks.drain();
		for (let i = 0; i < buckets.length; i++) {
			const toRun = buckets[i][1];
			for (let j = 0; j < toRun.length; j++) toRun[j]();
		}
	}
	/**
	* @since 2.0.0
	*/
	shouldYield(fiber) {
		return fiber.currentOpCount >= fiber.maxOpsBeforeYield;
	}
	/**
	* @since 2.0.0
	*/
	flush() {
		while (this.tasks.buckets.length > 0) {
			if (this.running !== void 0) {
				this.running();
				this.running = void 0;
			}
			this.runTasks();
		}
	}
};
/**
* A service reference that controls the maximum number of operations a fiber
* can perform before yielding control back to the scheduler. This helps
* prevent long-running fibers from monopolizing the execution thread.
*
* The default value is 2048 operations, which provides a good balance between
* performance and fairness in concurrent execution.
*
* @example
* ```ts
* import { Effect } from "effect"
* import { MaxOpsBeforeYield } from "effect/Scheduler"
*
* // Configure a fiber to yield more frequently
* const program = Effect.gen(function*() {
*   // Get current max ops setting (default is 2048)
*   const currentMax = yield* MaxOpsBeforeYield
*   yield* Effect.log(`Default max ops before yield: ${currentMax}`)
*
*   // Run with reduced max ops for more frequent yielding
*   return yield* Effect.provideService(
*     Effect.gen(function*() {
*       const maxOps = yield* MaxOpsBeforeYield
*       yield* Effect.log(`Max ops before yield: ${maxOps}`)
*
*       // Run a compute-intensive task that will yield frequently
*       let result = 0
*       for (let i = 0; i < 10000; i++) {
*         result += i
*         // This will cause yielding every 100 operations
*         yield* Effect.sync(() => result)
*       }
*       return result
*     }),
*     MaxOpsBeforeYield,
*     100
*   )
* })
*
* // Configure for high-performance scenarios
* const highPerformanceProgram = Effect.gen(function*() {
*   // Run with increased max ops for better performance (less yielding)
*   return yield* Effect.provideService(
*     Effect.gen(function*() {
*       const maxOps = yield* MaxOpsBeforeYield
*       yield* Effect.log(`High-performance max ops: ${maxOps}`)
*
*       // Run multiple concurrent tasks
*       const tasks = Array.from(
*         { length: 100 },
*         (_, i) =>
*           Effect.gen(function*() {
*             yield* Effect.sleep(`${i * 10} millis`)
*             return `Task ${i} completed`
*           })
*       )
*
*       return yield* Effect.all(tasks, { concurrency: "unbounded" })
*     }),
*     MaxOpsBeforeYield,
*     10000
*   )
* })
*
* // Configure for fair scheduling
* const fairSchedulingProgram = Effect.gen(function*() {
*   // Run with lower max ops for more frequent yielding
*   return yield* Effect.provideService(
*     Effect.gen(function*() {
*       const maxOps = yield* MaxOpsBeforeYield
*       yield* Effect.log(`Fair scheduling max ops: ${maxOps}`)
*
*       const longRunningTask = Effect.gen(function*() {
*         for (let i = 0; i < 1000; i++) {
*           yield* Effect.sync(() => Math.random())
*         }
*         return "Long task completed"
*       })
*
*       const quickTask = Effect.gen(function*() {
*         yield* Effect.sleep("10 millis")
*         return "Quick task completed"
*       })
*
*       // Both tasks will execute fairly due to frequent yielding
*       return yield* Effect.all([longRunningTask, quickTask], {
*         concurrency: "unbounded"
*       })
*     }),
*     MaxOpsBeforeYield,
*     50
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var MaxOpsBeforeYield = /*#__PURE__*/ Reference("effect/Scheduler/MaxOpsBeforeYield", { defaultValue: () => 2048 });
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Tracer.js
var Tracer_exports = /* @__PURE__ */ __exportAll({
	CurrentTraceLevel: () => CurrentTraceLevel,
	DisablePropagation: () => DisablePropagation,
	MinimumTraceLevel: () => MinimumTraceLevel,
	NativeSpan: () => NativeSpan,
	ParentSpan: () => ParentSpan,
	ParentSpanKey: () => ParentSpanKey,
	Tracer: () => Tracer,
	TracerKey: () => TracerKey,
	externalSpan: () => externalSpan,
	make: () => make$5
});
/**
* @since 2.0.0
* @category tags
* @example
* ```ts
* import { Tracer } from "effect"
*
* // The key used to identify parent spans in the service map
* console.log(Tracer.ParentSpanKey) // "effect/Tracer/ParentSpan"
* ```
*/
var ParentSpanKey = "effect/Tracer/ParentSpan";
/**
* @since 2.0.0
* @category tags
* @example
* ```ts
* import { Effect, Tracer } from "effect"
*
* // Access the parent span from the context
* const program = Effect.gen(function*() {
*   const parentSpan = yield* Effect.service(Tracer.ParentSpan)
*   console.log(`Parent span: ${parentSpan.spanId}`)
* })
* ```
*/
var ParentSpan = class extends Service()(ParentSpanKey) {};
/**
* @since 2.0.0
* @category constructors
*/
var make$5 = (options) => options;
/**
* @since 2.0.0
* @category constructors
* @example
* ```ts
* import { Effect, Tracer } from "effect"
*
* // Create an external span from another tracing system
* const span = Tracer.externalSpan({
*   spanId: "span-abc-123",
*   traceId: "trace-xyz-789",
*   sampled: true
* })
*
* // Use the external span as a parent
* const program = Effect.succeed("Hello").pipe(
*   Effect.withSpan("child-operation", { parent: span })
* )
* ```
*/
var externalSpan = (options) => ({
	_tag: "ExternalSpan",
	spanId: options.spanId,
	traceId: options.traceId,
	sampled: options.sampled ?? true,
	annotations: options.annotations ?? empty$3()
});
/**
* @since 3.12.0
* @category references
* @example
* ```ts
* import { Effect, Tracer } from "effect"
*
* // Disable span propagation for a specific effect
* const program = Effect.gen(function*() {
*   yield* Effect.log("This will not propagate parent span")
* }).pipe(
*   Effect.provideService(Tracer.DisablePropagation, true)
* )
* ```
*/
var DisablePropagation = /*#__PURE__*/ Reference("effect/Tracer/DisablePropagation", { defaultValue: constFalse });
/**
* Reference for controlling the current trace level for dynamic filtering.
*
* @category references
* @since 4.0.0
*/
var CurrentTraceLevel = /*#__PURE__*/ Reference("effect/Tracer/CurrentTraceLevel", { defaultValue: () => "Info" });
/**
* Reference for setting the minimum trace level threshold. Spans and their
* descendants below this level will have their sampling decision forced to
* false, preventing them from being exported.
*
* @category references
* @since 4.0.0
*/
var MinimumTraceLevel = /*#__PURE__*/ Reference("effect/Tracer/MinimumTraceLevel", { defaultValue: () => "All" });
/**
* @since 4.0.0
* @category references
*/
var TracerKey = "effect/Tracer";
/**
* @since 4.0.0
* @category references
* @example
* ```ts
* import { Effect, Tracer } from "effect"
*
* // Access the current tracer from the context
* const program = Effect.gen(function*() {
*   const tracer = yield* Effect.service(Tracer.Tracer)
*   console.log("Using current tracer")
* })
*
* // Or use the built-in tracer effect
* const tracerEffect = Effect.gen(function*() {
*   const tracer = yield* Effect.tracer
*   console.log("Current tracer obtained")
* })
* ```
*/
var Tracer = /*#__PURE__*/ Reference(TracerKey, { defaultValue: () => make$5({ span: (options) => new NativeSpan(options) }) });
/**
* @since 4.0.0
* @category native tracer
*/
var NativeSpan = class {
	_tag = "Span";
	spanId;
	traceId = "native";
	sampled;
	name;
	parent;
	annotations;
	links;
	startTime;
	kind;
	status;
	attributes;
	events = [];
	constructor(options) {
		this.name = options.name;
		this.parent = options.parent;
		this.annotations = options.annotations;
		this.links = options.links;
		this.startTime = options.startTime;
		this.kind = options.kind;
		this.sampled = options.sampled;
		this.status = {
			_tag: "Started",
			startTime: options.startTime
		};
		this.attributes = /* @__PURE__ */ new Map();
		this.traceId = options.parent?.traceId ?? randomHexString(32);
		this.spanId = randomHexString(16);
	}
	end(endTime, exit) {
		this.status = {
			_tag: "Ended",
			endTime,
			exit,
			startTime: this.status.startTime
		};
	}
	attribute(key, value) {
		this.attributes.set(key, value);
	}
	event(name, startTime, attributes) {
		this.events.push([
			name,
			startTime,
			attributes ?? {}
		]);
	}
	addLinks(links) {
		this.links.push(...links);
	}
};
var randomHexString = /*#__PURE__*/ function() {
	const characters = "abcdef0123456789";
	const charactersLength = 16;
	return function(length) {
		let result = "";
		for (let i = 0; i < length; i++) result += characters.charAt(Math.floor(Math.random() * charactersLength));
		return result;
	};
}();
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/References.js
/**
* This module provides a collection of reference implementations for commonly used
* Effect runtime configuration values. These references allow you to access and
* modify runtime behavior such as concurrency limits, scheduling policies,
* tracing configuration, and logging settings.
*
* References are special service instances that can be dynamically updated
* during runtime, making them ideal for configuration that may need to change
* based on application state or external conditions.
*
* @since 4.0.0
*/
var References_exports = /* @__PURE__ */ __exportAll({
	CurrentConcurrency: () => CurrentConcurrency,
	CurrentLogAnnotations: () => CurrentLogAnnotations,
	CurrentLogLevel: () => CurrentLogLevel,
	CurrentLogSpans: () => CurrentLogSpans,
	CurrentStackFrame: () => CurrentStackFrame,
	CurrentTraceLevel: () => CurrentTraceLevel,
	DisablePropagation: () => DisablePropagation,
	MaxOpsBeforeYield: () => MaxOpsBeforeYield,
	MinimumLogLevel: () => MinimumLogLevel,
	MinimumTraceLevel: () => MinimumTraceLevel,
	Scheduler: () => Scheduler,
	Tracer: () => Tracer,
	TracerEnabled: () => TracerEnabled,
	TracerSpanAnnotations: () => TracerSpanAnnotations,
	TracerSpanLinks: () => TracerSpanLinks,
	TracerTimingEnabled: () => TracerTimingEnabled,
	UnhandledLogLevel: () => UnhandledLogLevel
});
/**
* Reference for controlling the current concurrency limit. Can be set to "unbounded"
* for unlimited concurrency or a specific number to limit concurrent operations.
*
* @example
* ```ts
* import { Effect, References } from "effect"
*
* const limitConcurrency = Effect.gen(function*() {
*   // Get current setting
*   const current = yield* References.CurrentConcurrency
*   console.log(current) // "unbounded" (default)
*
*   // Run with limited concurrency
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const limited = yield* References.CurrentConcurrency
*       console.log(limited) // 10
*     }),
*     References.CurrentConcurrency,
*     10
*   )
*
*   // Run with unlimited concurrency
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const unlimited = yield* References.CurrentConcurrency
*       console.log(unlimited) // "unbounded"
*     }),
*     References.CurrentConcurrency,
*     "unbounded"
*   )
* })
* ```
*
* @category references
* @since 4.0.0
*/
var CurrentConcurrency = /*#__PURE__*/ Reference("effect/References/CurrentConcurrency", { defaultValue: () => "unbounded" });
/**
* @since 4.0.0
* @category references
*/
var CurrentStackFrame = /*#__PURE__*/ Reference("effect/References/CurrentStackFrame", { defaultValue: constUndefined });
/**
* Reference for controlling whether tracing is enabled globally. When set to false,
* spans will not be registered with the tracer and tracing overhead is minimized.
*
* @example
* ```ts
* import { Effect, References } from "effect"
*
* const tracingControl = Effect.gen(function*() {
*   // Check if tracing is enabled (default is true)
*   const current = yield* References.TracerEnabled
*   console.log(current) // true
*
*   // Disable tracing globally
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const isEnabled = yield* References.TracerEnabled
*       console.log(isEnabled) // false
*
*       // Spans will not be traced in this context
*       yield* Effect.log("This will not be traced")
*     }),
*     References.TracerEnabled,
*     false
*   )
*
*   // Re-enable tracing
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const isEnabled = yield* References.TracerEnabled
*       console.log(isEnabled) // true
*
*       // All subsequent spans will be traced
*       yield* Effect.log("This will be traced")
*     }),
*     References.TracerEnabled,
*     true
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var TracerEnabled = /*#__PURE__*/ Reference("effect/References/TracerEnabled", { defaultValue: constTrue });
/**
* Reference for controlling whether trace timing is enabled globally. When set
* to false, spans will not contain timing information (trace time will always
* be set to zero).
*
* @example
* ```ts
* import { Effect, References } from "effect"
*
* const tracingControl = Effect.gen(function*() {
*   // Check if trace timing is enabled (default is true)
*   const current = yield* References.TracerTimingEnabled
*   console.log(current) // true
*
*   // Disable trace timing globally
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       // Spans will not having timing information in this context
*       const isEnabled = yield* References.TracerTimingEnabled
*       console.log(isEnabled) // false
*     }),
*     References.TracerTimingEnabled,
*     false
*   )
*
*   // Re-enable trace timing
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       // Spans will have timing information in this context
*       const isEnabled = yield* References.TracerTimingEnabled
*       console.log(isEnabled) // true
*     }),
*     References.TracerTimingEnabled,
*     true
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var TracerTimingEnabled = /*#__PURE__*/ Reference("effect/References/TracerTimingEnabled", { defaultValue: constTrue });
/**
* Reference for managing span annotations that are automatically added to all new spans.
* These annotations provide context and metadata that applies across multiple spans.
*
* @example
* ```ts
* import { Effect, References } from "effect"
*
* const spanAnnotationExample = Effect.gen(function*() {
*   // Get current annotations (empty by default)
*   const current = yield* References.TracerSpanAnnotations
*   console.log(current) // {}
*
*   // Set global span annotations
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       // Get current annotations
*       const annotations = yield* References.TracerSpanAnnotations
*       console.log(annotations) // { service: "user-service", version: "1.2.3", environment: "production" }
*
*       // All spans created will include these annotations
*       yield* Effect.gen(function*() {
*         // Add more specific annotations for this span
*         yield* Effect.annotateCurrentSpan("userId", "123")
*         yield* Effect.log("Processing user")
*       })
*     }),
*     References.TracerSpanAnnotations,
*     {
*       service: "user-service",
*       version: "1.2.3",
*       environment: "production"
*     }
*   )
*
*   // Clear annotations
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const annotations = yield* References.TracerSpanAnnotations
*       console.log(annotations) // {}
*     }),
*     References.TracerSpanAnnotations,
*     {}
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var TracerSpanAnnotations = /*#__PURE__*/ Reference("effect/References/TracerSpanAnnotations", { defaultValue: () => ({}) });
/**
* Reference for managing span links that are automatically added to all new spans.
* Span links connect related spans that are not in a parent-child relationship.
*
* @example
* ```ts
* import { Effect, References, Tracer } from "effect"
*
* const spanLinksExample = Effect.gen(function*() {
*   // Get current links (empty by default)
*   const current = yield* References.TracerSpanLinks
*   console.log(current.length) // 0
*
*   // Create an external span for the example
*   const externalSpan = Tracer.externalSpan({
*     spanId: "external-span-123",
*     traceId: "trace-456"
*   })
*
*   // Create span links
*   const spanLink: Tracer.SpanLink = {
*     span: externalSpan,
*     attributes: {
*       relationship: "follows-from",
*       priority: "high"
*     }
*   }
*
*   // Set global span links
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       // Get current links
*       const links = yield* References.TracerSpanLinks
*       console.log(links.length) // 1
*
*       // All new spans will include these links
*       yield* Effect.gen(function*() {
*         yield* Effect.log("This span will have linked spans")
*         return "operation complete"
*       })
*     }),
*     References.TracerSpanLinks,
*     [spanLink]
*   )
*
*   // Clear links
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const links = yield* References.TracerSpanLinks
*       console.log(links.length) // 0
*     }),
*     References.TracerSpanLinks,
*     []
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var TracerSpanLinks = /*#__PURE__*/ Reference("effect/References/TracerSpanLinks", { defaultValue: () => [] });
/**
* Reference for managing log annotations that are automatically added to all log entries.
* These annotations provide contextual metadata that appears in every log message.
*
* @example
* ```ts
* import { Console, Effect, References } from "effect"
*
* const logAnnotationExample = Effect.gen(function*() {
*   // Get current annotations (empty by default)
*   const current = yield* References.CurrentLogAnnotations
*   console.log(current) // {}
*
*   // Run with custom log annotations
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const annotations = yield* References.CurrentLogAnnotations
*       console.log(annotations) // { requestId: "req-123", userId: "user-456", version: "1.0.0" }
*
*       // All log entries will include these annotations
*       yield* Console.log("Starting operation")
*       yield* Console.info("Processing data")
*     }),
*     References.CurrentLogAnnotations,
*     {
*       requestId: "req-123",
*       userId: "user-456",
*       version: "1.0.0"
*     }
*   )
*
*   // Run with extended annotations
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const extended = yield* References.CurrentLogAnnotations
*       console.log(extended) // { requestId: "req-123", userId: "user-456", version: "1.0.0", operation: "data-sync", timestamp: 1234567890 }
*
*       yield* Console.log("Operation completed with extended context")
*     }),
*     References.CurrentLogAnnotations,
*     {
*       requestId: "req-123",
*       userId: "user-456",
*       version: "1.0.0",
*       operation: "data-sync",
*       timestamp: 1234567890
*     }
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var CurrentLogAnnotations = /*#__PURE__*/ Reference("effect/References/CurrentLogAnnotations", { defaultValue: () => ({}) });
/**
* Reference for controlling the current log level for dynamic filtering.
*
* @example
* ```ts
* import { Console, Effect, References } from "effect"
*
* const dynamicLogging = Effect.gen(function*() {
*   // Get current log level (default is "Info")
*   const current = yield* References.CurrentLogLevel
*   console.log(current) // "Info"
*
*   // Set log level to Debug for detailed logging
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const level = yield* References.CurrentLogLevel
*       console.log(level) // "Debug"
*       yield* Console.debug("This debug message will be shown")
*     }),
*     References.CurrentLogLevel,
*     "Debug"
*   )
*
*   // Change to Error level to reduce noise
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const level = yield* References.CurrentLogLevel
*       console.log(level) // "Error"
*       yield* Console.info("This info message will be filtered out")
*       yield* Console.error("This error message will be shown")
*     }),
*     References.CurrentLogLevel,
*     "Error"
*   )
* })
* ```
*
* @category references
* @since 4.0.0
*/
var CurrentLogLevel = /*#__PURE__*/ Reference("effect/References/CurrentLogLevel", { defaultValue: () => "Info" });
/**
* Reference for setting the minimum log level threshold. Log entries below this
* level will be filtered out completely.
*
* @example
* ```ts
* import { Console, Effect, References } from "effect"
*
* const configureMinimumLogging = Effect.gen(function*() {
*   // Get current minimum level (default is "Info")
*   const current = yield* References.MinimumLogLevel
*   console.log(current) // "Info"
*
*   // Set minimum level to Warn - Debug and Info will be filtered
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const minLevel = yield* References.MinimumLogLevel
*       console.log(minLevel) // "Warn"
*
*       // These won't be processed at all
*       yield* Console.debug("Debug message") // Filtered out
*       yield* Console.info("Info message") // Filtered out
*
*       // These will be processed
*       yield* Console.warn("Warning message") // Shown
*       yield* Console.error("Error message") // Shown
*     }),
*     References.MinimumLogLevel,
*     "Warn"
*   )
*
*   // Reset to default Info level
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const minLevel = yield* References.MinimumLogLevel
*       console.log(minLevel) // "Info"
*
*       // Now info messages will be processed
*       yield* Console.info("Info message") // Shown
*     }),
*     References.MinimumLogLevel,
*     "Info"
*   )
* })
* ```
*
* @category references
* @since 4.0.0
*/
var MinimumLogLevel = /*#__PURE__*/ Reference("effect/References/MinimumLogLevel", { defaultValue: () => "Info" });
/**
* The log level for unhandled errors. This reference allows you to set the log
* level for unhandled errors that occur during Effect execution.
*
* @category references
* @since 4.0.0
*/
var UnhandledLogLevel = /*#__PURE__*/ Reference("effect/References/UnhandledLogLevel", { defaultValue: () => "Error" });
/**
* Reference for managing log spans that track the duration and hierarchy of operations.
* Each span represents a labeled time period for performance analysis and debugging.
*
* @example
* ```ts
* import { Console, Effect, References } from "effect"
*
* const logSpanExample = Effect.gen(function*() {
*   // Get current spans (empty by default)
*   const current = yield* References.CurrentLogSpans
*   console.log(current.length) // 0
*
*   // Add a log span manually
*   const startTime = Date.now()
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       // Simulate some work
*       yield* Effect.sleep("100 millis")
*       yield* Console.log("Database operation in progress")
*
*       const spans = yield* References.CurrentLogSpans
*       console.log("Active spans:", spans.map(([label]) => label)) // ["database-connection"]
*     }),
*     References.CurrentLogSpans,
*     [["database-connection", startTime]]
*   )
*
*   // Add another span
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const spans = yield* References.CurrentLogSpans
*       console.log("Active spans:", spans.map(([label]) => label)) // ["database-connection", "data-processing"]
*
*       yield* Console.log("Multiple operations in progress")
*     }),
*     References.CurrentLogSpans,
*     [
*       ["database-connection", startTime],
*       ["data-processing", Date.now()]
*     ]
*   )
*
*   // Clear spans when operations complete
*   yield* Effect.provideService(
*     Effect.gen(function*() {
*       const spans = yield* References.CurrentLogSpans
*       console.log("Active spans:", spans.length) // 0
*     }),
*     References.CurrentLogSpans,
*     []
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var CurrentLogSpans = /*#__PURE__*/ Reference("effect/References/CurrentLogSpans", { defaultValue: () => [] });
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/metric.js
/** @internal */
var FiberRuntimeMetricsKey$1 = "effect/observability/Metric/FiberRuntimeMetricsKey";
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/tracer.js
/** @internal */
var addSpanStackTrace = (options) => {
	if (options?.captureStackTrace === false) return options;
	else if (options?.captureStackTrace !== void 0 && typeof options.captureStackTrace !== "boolean") return options;
	const limit = Error.stackTraceLimit;
	Error.stackTraceLimit = 3;
	const traceError = /* @__PURE__ */ new Error();
	Error.stackTraceLimit = limit;
	return {
		...options,
		captureStackTrace: spanCleaner(() => traceError.stack)
	};
};
/** @internal */
var makeStackCleaner = (line) => (stack) => {
	let cache;
	return () => {
		if (cache !== void 0) return cache;
		const trace = stack();
		if (!trace) return void 0;
		const lines = trace.split("\n");
		if (lines[line] !== void 0) {
			cache = lines[line].trim();
			return cache;
		}
	};
};
var spanCleaner = /*#__PURE__*/ makeStackCleaner(3);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/effect.js
/** @internal */
var Interrupt = class extends ReasonBase {
	fiberId;
	constructor(fiberId, annotations = constEmptyAnnotations) {
		super("Interrupt", annotations, "Interrupted");
		this.fiberId = fiberId;
	}
	toString() {
		return `Interrupt(${this.fiberId})`;
	}
	toJSON() {
		return {
			_tag: "Interrupt",
			fiberId: this.fiberId
		};
	}
	[symbol$2](that) {
		return isInterruptReason$1(that) && this.fiberId === that.fiberId && this.annotations === that.annotations;
	}
	[symbol$1]() {
		return combine$1(string$1(`${this._tag}:${this.fiberId}`))(random(this.annotations));
	}
};
/** @internal */
var makeInterruptReason$1 = (fiberId) => new Interrupt(fiberId);
/** @internal */
var causeInterrupt = (fiberId) => new CauseImpl([new Interrupt(fiberId)]);
/** @internal */
var hasFails$2 = (self) => self.reasons.some(isFailReason$1);
/** @internal */
var findFail$1 = (self) => {
	const reason = self.reasons.find(isFailReason$1);
	return reason ? succeed$6(reason) : fail$6(self);
};
/** @internal */
var findError$2 = (self) => {
	for (let i = 0; i < self.reasons.length; i++) {
		const reason = self.reasons[i];
		if (reason._tag === "Fail") return succeed$6(reason.error);
	}
	return fail$6(self);
};
/** @internal */
var findErrorOption$2 = /*#__PURE__*/ toOption(findError$2);
/** @internal */
var hasDies$2 = (self) => self.reasons.some(isDieReason$1);
/** @internal */
var findDie$1 = (self) => {
	const reason = self.reasons.find(isDieReason$1);
	return reason ? succeed$6(reason) : fail$6(self);
};
/** @internal */
var findDefect$2 = (self) => {
	const reason = self.reasons.find(isDieReason$1);
	return reason ? succeed$6(reason.defect) : fail$6(self);
};
/** @internal */
var hasInterrupts$2 = (self) => self.reasons.some(isInterruptReason$1);
/** @internal */
var findInterrupt$1 = (self) => {
	const reason = self.reasons.find(isInterruptReason$1);
	return reason ? succeed$6(reason) : fail$6(self);
};
/** @internal */
var causeFilterInterruptors = (self) => {
	let interruptors;
	for (let i = 0; i < self.reasons.length; i++) {
		const f = self.reasons[i];
		if (f._tag !== "Interrupt") continue;
		interruptors ??= /* @__PURE__ */ new Set();
		if (f.fiberId !== void 0) interruptors.add(f.fiberId);
	}
	return interruptors ? succeed$6(interruptors) : fail$6(self);
};
/** @internal */
var causeInterruptors = (self) => {
	const result = causeFilterInterruptors(self);
	return isFailure$3(result) ? emptySet : result.success;
};
var emptySet = /*#__PURE__*/ new Set();
/** @internal */
var hasInterruptsOnly$1 = (self) => self.reasons.every(isInterruptReason$1);
/** @internal */
var reasonAnnotations$1 = (self) => makeUnsafe$3(self.annotations);
/** @internal */
var causeAnnotations = (self) => {
	const map = /* @__PURE__ */ new Map();
	for (const f of self.reasons) if (f.annotations.size > 0) for (const [key, value] of f.annotations) map.set(key, value);
	return makeUnsafe$3(map);
};
/** @internal */
var causeCombine = /*#__PURE__*/ dual(2, (self, that) => {
	if (self.reasons.length === 0) return that;
	else if (that.reasons.length === 0) return self;
	const newCause = new CauseImpl(union(self.reasons, that.reasons));
	return equals$3(self, newCause) ? self : newCause;
});
/** @internal */
var causeMap = /*#__PURE__*/ dual(2, (self, f) => {
	let hasFail = false;
	const failures = self.reasons.map((failure) => {
		if (isFailReason$1(failure)) {
			hasFail = true;
			return new Fail(f(failure.error));
		}
		return failure;
	});
	return hasFail ? causeFromReasons(failures) : self;
});
/** @internal */
var causePartition = (self) => {
	const obj = {
		Fail: [],
		Die: [],
		Interrupt: []
	};
	for (let i = 0; i < self.reasons.length; i++) obj[self.reasons[i]._tag].push(self.reasons[i]);
	return obj;
};
/** @internal */
var causeSquash = (self) => {
	const partitioned = causePartition(self);
	if (partitioned.Fail.length > 0) return partitioned.Fail[0].error;
	else if (partitioned.Die.length > 0) return partitioned.Die[0].defect;
	else if (partitioned.Interrupt.length > 0) return new globalThis.Error("All fibers interrupted without error");
	return new globalThis.Error("Empty cause");
};
/** @internal */
var causePrettyErrors = (self) => {
	const errors = [];
	const interrupts = [];
	if (self.reasons.length === 0) return errors;
	const prevStackLimit = Error.stackTraceLimit;
	Error.stackTraceLimit = 1;
	for (const failure of self.reasons) {
		if (failure._tag === "Interrupt") {
			interrupts.push(failure);
			continue;
		}
		errors.push(causePrettyError(failure._tag === "Die" ? failure.defect : failure.error, failure.annotations));
	}
	if (errors.length === 0) {
		const cause = /* @__PURE__ */ new Error("The fiber was interrupted by:");
		cause.name = "InterruptCause";
		cause.stack = interruptCauseStack(cause, interrupts);
		const error = new globalThis.Error("All fibers interrupted without error", { cause });
		error.name = "InterruptError";
		error.stack = `${error.name}: ${error.message}`;
		errors.push(causePrettyError(error, interrupts[0].annotations));
	}
	Error.stackTraceLimit = prevStackLimit;
	return errors;
};
/** @internal */
var causePrettyError = (original, annotations) => {
	const kind = typeof original;
	let error;
	if (original && kind === "object") {
		error = new globalThis.Error(causePrettyMessage(original), { cause: original.cause ? causePrettyError(original.cause) : void 0 });
		if (typeof original.name === "string") error.name = original.name;
		if (typeof original.stack === "string") error.stack = cleanErrorStack(original.stack, error, annotations);
		else {
			const stack = `${error.name}: ${error.message}`;
			error.stack = annotations ? addStackAnnotations(stack, annotations) : stack;
		}
		for (const key of Object.keys(original)) if (!(key in error)) error[key] = original[key];
	} else error = new globalThis.Error(!original ? `Unknown error: ${original}` : kind === "string" ? original : formatJson(original));
	return error;
};
var causePrettyMessage = (u) => {
	if (typeof u.message === "string") return u.message;
	else if (typeof u.toString === "function" && u.toString !== Object.prototype.toString && u.toString !== Array.prototype.toString) try {
		return u.toString();
	} catch {}
	return formatJson(u);
};
var locationRegExp = /\((.*)\)/g;
var cleanErrorStack = (stack, error, annotations) => {
	const message = `${error.name}: ${error.message}`;
	const lines = (stack.startsWith(message) ? stack.slice(message.length) : stack).split("\n");
	const out = [message];
	for (let i = 1; i < lines.length; i++) {
		if (/(?:Generator\.next|~effect\/Effect)/.test(lines[i])) break;
		out.push(lines[i]);
	}
	return annotations ? addStackAnnotations(out.join("\n"), annotations) : out.join("\n");
};
var addStackAnnotations = (stack, annotations) => {
	const frame = annotations?.get(StackTraceKey.key);
	if (frame) stack = `${stack}\n${currentStackTrace(frame)}`;
	return stack;
};
var interruptCauseStack = (error, interrupts) => {
	const out = [`${error.name}: ${error.message}`];
	for (const current of interrupts) {
		const fiberId = current.fiberId !== void 0 ? `#${current.fiberId}` : "unknown";
		const frame = current.annotations.get(InterruptorStackTrace$1.key);
		out.push(`    at fiber (${fiberId})`);
		if (frame) out.push(currentStackTrace(frame));
	}
	return out.join("\n");
};
var currentStackTrace = (frame) => {
	const out = [];
	let current = frame;
	let i = 0;
	while (current && i < 10) {
		const stack = current.stack();
		if (stack) {
			const locationMatchAll = stack.matchAll(locationRegExp);
			let match = false;
			for (const [, location] of locationMatchAll) {
				match = true;
				out.push(`    at ${current.name} (${location})`);
			}
			if (!match) out.push(`    at ${current.name} (${stack.replace(/^at /, "")})`);
		} else out.push(`    at ${current.name}`);
		current = current.parent;
		i++;
	}
	return out.join("\n");
};
/** @internal */
var causePretty = (cause) => causePrettyErrors(cause).map((e) => e.cause ? `${e.stack} {\n${renderErrorCause(e.cause, "  ")}\n}` : e.stack).join("\n");
var renderErrorCause = (cause, prefix) => {
	const lines = cause.stack.split("\n");
	let stack = `${prefix}[cause]: ${lines[0]}`;
	for (let i = 1, len = lines.length; i < len; i++) stack += `\n${prefix}${lines[i]}`;
	if (cause.cause) stack += ` {\n${renderErrorCause(cause.cause, `${prefix}  `)}\n${prefix}}`;
	return stack;
};
/** @internal */
var FiberTypeId = `~effect/Fiber/dev`;
var fiberVariance = {
	_A: identity,
	_E: identity
};
var fiberIdStore = { id: 0 };
/** @internal */
var getCurrentFiber = () => globalThis[currentFiberTypeId];
/** @internal */
var FiberImpl = class {
	constructor(services, interruptible = true) {
		this[FiberTypeId] = fiberVariance;
		this.setServices(services);
		this.id = ++fiberIdStore.id;
		this.currentOpCount = 0;
		this.currentLoopCount = 0;
		this.interruptible = interruptible;
		this._stack = [];
		this._observers = [];
		this._exit = void 0;
		this._children = void 0;
		this._interruptedCause = void 0;
		this._yielded = void 0;
	}
	[FiberTypeId];
	id;
	interruptible;
	currentOpCount;
	currentLoopCount;
	_stack;
	_observers;
	_exit;
	_currentExit;
	_children;
	_interruptedCause;
	_yielded;
	services;
	currentScheduler;
	currentTracerContext;
	currentSpan;
	currentLogLevel;
	minimumLogLevel;
	currentStackFrame;
	runtimeMetrics;
	maxOpsBeforeYield;
	getRef(ref) {
		return getReferenceUnsafe(this.services, ref);
	}
	addObserver(cb) {
		if (this._exit) {
			cb(this._exit);
			return constVoid;
		}
		this._observers.push(cb);
		return () => {
			const index = this._observers.indexOf(cb);
			if (index >= 0) this._observers.splice(index, 1);
		};
	}
	interruptUnsafe(fiberId, annotations) {
		if (this._exit) return;
		let cause = causeInterrupt(fiberId);
		if (this.currentStackFrame) cause = causeAnnotate(cause, make$6(StackTraceKey, this.currentStackFrame));
		if (annotations) cause = causeAnnotate(cause, annotations);
		this._interruptedCause = this._interruptedCause ? causeCombine(this._interruptedCause, cause) : cause;
		if (this.interruptible) this.evaluate(failCause$4(this._interruptedCause));
	}
	pollUnsafe() {
		return this._exit;
	}
	evaluate(effect) {
		this.runtimeMetrics?.recordFiberStart(this.services);
		if (this._exit) return;
		else if (this._yielded !== void 0) {
			const yielded = this._yielded;
			this._yielded = void 0;
			yielded();
		}
		const exit = this.runLoop(effect);
		if (exit === Yield) return;
		const interruptChildren = fiberMiddleware.interruptChildren && fiberMiddleware.interruptChildren(this);
		if (interruptChildren !== void 0) return this.evaluate(flatMap$2(interruptChildren, () => exit));
		this._exit = exit;
		this.runtimeMetrics?.recordFiberEnd(this.services, this._exit);
		for (let i = 0; i < this._observers.length; i++) this._observers[i](exit);
		this._observers.length = 0;
	}
	runLoop(effect) {
		const prevFiber = globalThis[currentFiberTypeId];
		globalThis[currentFiberTypeId] = this;
		let yielding = false;
		let current = effect;
		this.currentOpCount = 0;
		const currentLoop = ++this.currentLoopCount;
		try {
			while (true) {
				this.currentOpCount++;
				if (!yielding && this.currentScheduler.shouldYield(this)) {
					yielding = true;
					const prev = current;
					current = flatMap$2(yieldNow$1, () => prev);
				}
				current = this.currentTracerContext ? this.currentTracerContext(current, this) : current[evaluate](this);
				if (currentLoop !== this.currentLoopCount) return Yield;
				else if (current === Yield) {
					const yielded = this._yielded;
					if (ExitTypeId in yielded) {
						this._yielded = void 0;
						return yielded;
					}
					return Yield;
				}
			}
		} catch (error) {
			if (!hasProperty(current, evaluate)) return exitDie(`Fiber.runLoop: Not a valid effect: ${String(current)}`);
			return this.runLoop(exitDie(error));
		} finally {
			globalThis[currentFiberTypeId] = prevFiber;
		}
	}
	getCont(symbol) {
		while (true) {
			const op = this._stack.pop();
			if (!op) return void 0;
			const cont = op[contAll] && op[contAll](this);
			if (cont) {
				cont[symbol] = cont;
				return cont;
			}
			if (op[symbol]) return op;
		}
	}
	yieldWith(value) {
		this._yielded = value;
		return Yield;
	}
	children() {
		return this._children ??= /* @__PURE__ */ new Set();
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
	setServices(services) {
		this.services = services;
		this.currentScheduler = this.getRef(Scheduler);
		this.currentSpan = services.mapUnsafe.get(ParentSpanKey);
		this.currentLogLevel = this.getRef(CurrentLogLevel);
		this.minimumLogLevel = this.getRef(MinimumLogLevel);
		this.currentStackFrame = services.mapUnsafe.get(CurrentStackFrame.key);
		this.maxOpsBeforeYield = this.getRef(MaxOpsBeforeYield);
		this.runtimeMetrics = services.mapUnsafe.get(FiberRuntimeMetricsKey$1);
		const currentTracer = services.mapUnsafe.get(TracerKey);
		this.currentTracerContext = currentTracer ? currentTracer["context"] : void 0;
	}
	get currentSpanLocal() {
		return this.currentSpan?._tag === "Span" ? this.currentSpan : void 0;
	}
};
var fiberMiddleware = { interruptChildren: void 0 };
var fiberStackAnnotations = (fiber) => {
	if (!fiber.currentStackFrame) return void 0;
	const annotations = /* @__PURE__ */ new Map();
	annotations.set(StackTraceKey.key, fiber.currentStackFrame);
	return makeUnsafe$3(annotations);
};
var fiberInterruptChildren = (fiber) => {
	if (fiber._children === void 0 || fiber._children.size === 0) return;
	return fiberInterruptAll(fiber._children);
};
/** @internal */
var fiberAwait = (self) => {
	const impl = self;
	if (impl._exit) return succeed$5(impl._exit);
	return callback$1((resume) => {
		if (impl._exit) return resume(succeed$5(impl._exit));
		return sync$3(self.addObserver((exit) => resume(succeed$5(exit))));
	});
};
/** @internal */
var fiberAwaitAll = (self) => callback$1((resume) => {
	const iter = self[Symbol.iterator]();
	const exits = [];
	let cancel = void 0;
	function loop() {
		let result = iter.next();
		while (!result.done) {
			if (result.value._exit) {
				exits.push(result.value._exit);
				result = iter.next();
				continue;
			}
			cancel = result.value.addObserver((exit) => {
				exits.push(exit);
				loop();
			});
			return;
		}
		resume(succeed$5(exits));
	}
	loop();
	return sync$3(() => cancel?.());
});
/** @internal */
var fiberJoin = (self) => {
	const impl = self;
	if (impl._exit) return impl._exit;
	return callback$1((resume) => {
		if (impl._exit) return resume(impl._exit);
		return sync$3(self.addObserver(resume));
	});
};
/** @internal */
var fiberJoinAll = (self) => callback$1((resume) => {
	const fibers = Array.from(self);
	if (fibers.length === 0) return resume(succeed$5(empty$4()));
	const out = new Array(fibers.length);
	const cancels = empty$4();
	let done = 0;
	let failed = false;
	for (let i = 0; i < fibers.length; i++) {
		if (failed) break;
		cancels.push(fibers[i].addObserver((exit) => {
			done++;
			if (exit._tag === "Failure") {
				failed = true;
				cancels.forEach((cancel) => cancel());
				return resume(exit);
			}
			out[i] = exit.value;
			if (done === fibers.length) resume(succeed$5(out));
		}));
	}
});
/** @internal */
var fiberInterrupt = (self) => withFiber$1((fiber) => fiberInterruptAs(self, fiber.id));
/** @internal */
var fiberInterruptAs = /*#__PURE__*/ dual((args) => hasProperty(args[0], FiberTypeId), (self, fiberId, annotations) => withFiber$1((parent) => {
	let ann = fiberStackAnnotations(parent);
	ann = ann && annotations ? merge$2(ann, annotations) : ann ?? annotations;
	self.interruptUnsafe(fiberId, ann);
	return asVoid$2(fiberAwait(self));
}));
/** @internal */
var fiberInterruptAll = (fibers) => withFiber$1((parent) => {
	const annotations = fiberStackAnnotations(parent);
	for (const fiber of fibers) fiber.interruptUnsafe(parent.id, annotations);
	return asVoid$2(fiberAwaitAll(fibers));
});
/** @internal */
var fiberInterruptAllAs = /*#__PURE__*/ dual(2, (fibers, fiberId) => withFiber$1((parent) => {
	const annotations = fiberStackAnnotations(parent);
	for (const fiber of fibers) fiber.interruptUnsafe(fiberId, annotations);
	return asVoid$2(fiberAwaitAll(fibers));
}));
/** @internal */
var succeed$5 = exitSucceed;
/** @internal */
var failCause$4 = exitFailCause;
/** @internal */
var fail$5 = exitFail;
/** @internal */
var sync$3 = /*#__PURE__*/ makePrimitive({
	op: "Sync",
	[evaluate](fiber) {
		const value = this[args]();
		const cont = fiber.getCont(contA);
		return cont ? cont[contA](value, fiber) : fiber.yieldWith(exitSucceed(value));
	}
});
/** @internal */
var suspend$1 = /*#__PURE__*/ makePrimitive({
	op: "Suspend",
	[evaluate](_fiber) {
		return this[args]();
	}
});
/** @internal */
var fromYieldable$1 = (yieldable) => yieldable.asEffect();
/** @internal */
var fromOption$1 = fromYieldable$1;
/** @internal */
var fromResult$1 = fromYieldable$1;
/** @internal */
var fromNullishOr$1 = (value) => value == null ? fail$5(new NoSuchElementError$1()) : succeed$5(value);
/** @internal */
var yieldNowWith$1 = /*#__PURE__*/ makePrimitive({
	op: "Yield",
	[evaluate](fiber) {
		let resumed = false;
		fiber.currentScheduler.scheduleTask(() => {
			if (resumed) return;
			fiber.evaluate(exitVoid);
		}, this[args] ?? 0);
		return fiber.yieldWith(() => {
			resumed = true;
		});
	}
});
/** @internal */
var yieldNow$1 = /*#__PURE__*/ yieldNowWith$1(0);
/** @internal */
var succeedSome$1 = (a) => succeed$5(some$2(a));
/** @internal */
var succeedNone$1 = /*#__PURE__*/ succeed$5(/*#__PURE__*/ none());
/** @internal */
var failCauseSync$2 = (evaluate) => suspend$1(() => failCause$4(internalCall(evaluate)));
/** @internal */
var die$4 = (defect) => exitDie(defect);
/** @internal */
var failSync$2 = (error) => suspend$1(() => fail$5(internalCall(error)));
/** @internal */
var void_$2 = /*#__PURE__*/ succeed$5(void 0);
/** @internal */
var try_$1 = (options) => suspend$1(() => {
	try {
		return succeed$5(internalCall(options.try));
	} catch (err) {
		return fail$5(internalCall(() => options.catch(err)));
	}
});
/** @internal */
var promise$1 = (evaluate) => callbackOptions(function(resume, signal) {
	internalCall(() => evaluate(signal)).then((a) => resume(succeed$5(a)), (e) => resume(die$4(e)));
}, evaluate.length !== 0);
/** @internal */
var tryPromise$1 = (options) => {
	const f = typeof options === "function" ? options : options.try;
	const catcher = typeof options === "function" ? (cause) => new UnknownError$1(cause, "An error occurred in Effect.tryPromise") : options.catch;
	return callbackOptions(function(resume, signal) {
		try {
			internalCall(() => f(signal)).then((a) => resume(succeed$5(a)), (e) => resume(fail$5(internalCall(() => catcher(e)))));
		} catch (err) {
			resume(fail$5(internalCall(() => catcher(err))));
		}
	}, eval.length !== 0);
};
/** @internal */
var withFiberId = (f) => withFiber$1((fiber) => f(fiber.id));
/** @internal */
var fiber$1 = /*#__PURE__*/ withFiber$1(succeed$5);
/** @internal */
var fiberId$1 = /*#__PURE__*/ withFiberId(succeed$5);
var callbackOptions = /*#__PURE__*/ makePrimitive({
	op: "Async",
	single: false,
	[evaluate](fiber) {
		const register = internalCall(() => this[args][0].bind(fiber.currentScheduler));
		let resumed = false;
		let yielded = false;
		const controller = this[args][1] ? new AbortController() : void 0;
		const onCancel = register((effect) => {
			if (resumed) return;
			resumed = true;
			if (yielded) fiber.evaluate(effect);
			else yielded = effect;
		}, controller?.signal);
		if (yielded !== false) return yielded;
		yielded = true;
		fiber._yielded = () => {
			resumed = true;
		};
		if (controller === void 0 && onCancel === void 0) return Yield;
		fiber._stack.push(asyncFinalizer(() => {
			resumed = true;
			controller?.abort();
			return onCancel ?? exitVoid;
		}));
		return Yield;
	}
});
var asyncFinalizer = /*#__PURE__*/ makePrimitive({
	op: "AsyncFinalizer",
	[contAll](fiber) {
		if (fiber.interruptible) {
			fiber.interruptible = false;
			fiber._stack.push(setInterruptibleTrue);
		}
	},
	[contE](cause, _fiber) {
		return hasInterrupts$2(cause) ? flatMap$2(this[args](), () => failCause$4(cause)) : failCause$4(cause);
	}
});
/** @internal */
var callback$1 = (register) => callbackOptions(register, register.length >= 2);
/** @internal */
var never$1 = /*#__PURE__*/ callback$1(constVoid);
/** @internal */
var gen$1 = (...args) => suspend$1(() => fromIteratorUnsafe(args.length === 1 ? args[0]() : args[1].call(args[0].self)));
/** @internal */
var fnUntraced$1 = (body, ...pipeables) => {
	const fn = pipeables.length === 0 ? function() {
		return suspend$1(() => fromIteratorUnsafe(body.apply(this, arguments)));
	} : function() {
		let effect = suspend$1(() => fromIteratorUnsafe(body.apply(this, arguments)));
		for (let i = 0; i < pipeables.length; i++) effect = pipeables[i](effect, ...arguments);
		return effect;
	};
	return defineFunctionLength(body.length, fn);
};
var defineFunctionLength = (length, fn) => Object.defineProperty(fn, "length", {
	value: length,
	configurable: true
});
var fnStackCleaner = /*#__PURE__*/ makeStackCleaner(2);
/** @internal */
var fn$1 = function() {
	const nameFirst = typeof arguments[0] === "string";
	const name = nameFirst ? arguments[0] : "Effect.fn";
	const spanOptions = nameFirst ? arguments[1] : void 0;
	const prevLimit = globalThis.Error.stackTraceLimit;
	globalThis.Error.stackTraceLimit = 2;
	const defError = new globalThis.Error();
	globalThis.Error.stackTraceLimit = prevLimit;
	if (nameFirst) return (body, ...pipeables) => makeFn(name, body, defError, pipeables, nameFirst, spanOptions);
	return makeFn(name, arguments[0], defError, Array.prototype.slice.call(arguments, 1), nameFirst, spanOptions);
};
var makeFn = (name, bodyOrOptions, defError, pipeables, addSpan, spanOptions) => {
	const body = typeof bodyOrOptions === "function" ? bodyOrOptions : pipeables.pop().bind(bodyOrOptions.self);
	return defineFunctionLength(body.length, function(...args) {
		let result = suspend$1(() => {
			const iter = body.apply(this, arguments);
			return isEffect$1(iter) ? iter : fromIteratorUnsafe(iter);
		});
		for (let i = 0; i < pipeables.length; i++) result = pipeables[i](result, ...args);
		if (!isEffect$1(result)) return result;
		const prevLimit = globalThis.Error.stackTraceLimit;
		globalThis.Error.stackTraceLimit = 2;
		const callError = new globalThis.Error();
		globalThis.Error.stackTraceLimit = prevLimit;
		return updateService$2(addSpan ? useSpan$1(name, spanOptions, (span) => provideParentSpan(result, span)) : result, CurrentStackFrame, (prev) => ({
			name,
			stack: fnStackCleaner(() => callError.stack),
			parent: {
				name: `${name} (definition)`,
				stack: fnStackCleaner(() => defError.stack),
				parent: prev
			}
		}));
	});
};
/** @internal */
var fnUntracedEager$1 = (body, ...pipeables) => defineFunctionLength(body.length, pipeables.length === 0 ? function() {
	return fromIteratorEagerUnsafe(() => body.apply(this, arguments));
} : function() {
	let effect = fromIteratorEagerUnsafe(() => body.apply(this, arguments));
	for (const pipeable of pipeables) effect = pipeable(effect);
	return effect;
});
var fromIteratorEagerUnsafe = (evaluate) => {
	try {
		const iterator = evaluate();
		let value = void 0;
		while (true) {
			const state = iterator.next(value);
			if (state.done) return succeed$5(state.value);
			const effect = state.value.asEffect();
			const primitive = effect;
			if (primitive && primitive._tag === "Success") {
				value = primitive.value;
				continue;
			} else if (primitive && primitive._tag === "Failure") return effect;
			else {
				let isFirstExecution = true;
				return suspend$1(() => {
					if (isFirstExecution) {
						isFirstExecution = false;
						return flatMap$2(effect, (value) => fromIteratorUnsafe(iterator, value));
					} else return suspend$1(() => fromIteratorUnsafe(evaluate()));
				});
			}
		}
	} catch (error) {
		return die$4(error);
	}
};
var fromIteratorUnsafe = /*#__PURE__*/ makePrimitive({
	op: "Iterator",
	single: false,
	[contA](value, fiber) {
		const iter = this[args][0];
		while (true) {
			const state = iter.next(value);
			if (state.done) return succeed$5(state.value);
			const eff = state.value.asEffect();
			if (!effectIsExit(eff)) {
				fiber._stack.push(this);
				return eff;
			} else if (eff._tag === "Failure") return eff;
			value = eff.value;
		}
	},
	[evaluate](fiber) {
		return this[contA](this[args][1], fiber);
	}
});
/** @internal */
var as$1 = /*#__PURE__*/ dual(2, (self, value) => {
	const b = succeed$5(value);
	return flatMap$2(self, (_) => b);
});
/** @internal */
var asSome$1 = (self) => map$4(self, some$2);
/** @internal */
var flip$1 = (self) => matchEffect$2(self, {
	onFailure: succeed$5,
	onSuccess: fail$5
});
/** @internal */
var andThen$2 = /*#__PURE__*/ dual(2, (self, f) => flatMap$2(self, (a) => isEffect$1(f) ? f : internalCall(() => f(a))));
/** @internal */
var tap$1 = /*#__PURE__*/ dual(2, (self, f) => flatMap$2(self, (a) => as$1(isEffect$1(f) ? f : internalCall(() => f(a)), a)));
/** @internal */
var asVoid$2 = (self) => flatMap$2(self, (_) => exitVoid);
/** @internal */
var sandbox$1 = (self) => catchCause$2(self, fail$5);
/** @internal */
var raceAll$1 = (all, options) => withFiber$1((parent) => callback$1((resume) => {
	const effects = fromIterable(all);
	const len = effects.length;
	let doneCount = 0;
	let done = false;
	const fibers = /* @__PURE__ */ new Set();
	const failures = [];
	const onExit = (exit, fiber, i) => {
		doneCount++;
		if (exit._tag === "Failure") {
			failures.push(...exit.cause.reasons);
			if (doneCount >= len) resume(failCause$4(causeFromReasons(failures)));
			return;
		}
		const isWinner = !done;
		done = true;
		resume(fibers.size === 0 ? exit : flatMap$2(uninterruptible$1(fiberInterruptAll(fibers)), () => exit));
		if (isWinner && options?.onWinner) options.onWinner({
			fiber,
			index: i,
			parentFiber: parent
		});
	};
	for (let i = 0; i < len; i++) {
		const fiber = forkUnsafe$1(parent, effects[i], true, true, false);
		fibers.add(fiber);
		fiber.addObserver((exit) => {
			fibers.delete(fiber);
			onExit(exit, fiber, i);
		});
		if (done) break;
	}
	return fiberInterruptAll(fibers);
}));
/** @internal */
var raceAllFirst$1 = (all, options) => withFiber$1((parent) => callback$1((resume) => {
	let done = false;
	const fibers = /* @__PURE__ */ new Set();
	const onExit = (exit) => {
		done = true;
		resume(fibers.size === 0 ? exit : flatMap$2(uninterruptible$1(fiberInterruptAll(fibers)), () => exit));
	};
	let i = 0;
	for (const effect of all) {
		if (done) break;
		const index = i++;
		const fiber = forkUnsafe$1(parent, effect, true, true, false);
		fibers.add(fiber);
		fiber.addObserver((exit) => {
			fibers.delete(fiber);
			const isWinner = !done;
			onExit(exit);
			if (isWinner && options?.onWinner) options.onWinner({
				fiber,
				index,
				parentFiber: parent
			});
		});
	}
	return fiberInterruptAll(fibers);
}));
/** @internal */
var race$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[1]), (self, that, options) => raceAll$1([self, that], options));
/** @internal */
var raceFirst$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[1]), (self, that, options) => raceAllFirst$1([self, that], options));
/** @internal */
var flatMap$2 = /*#__PURE__*/ dual(2, (self, f) => {
	const onSuccess = Object.create(OnSuccessProto);
	onSuccess[args] = self;
	onSuccess[contA] = f.length !== 1 ? (a) => f(a) : f;
	return onSuccess;
});
var OnSuccessProto = /*#__PURE__*/ makePrimitiveProto({
	op: "OnSuccess",
	[evaluate](fiber) {
		fiber._stack.push(this);
		return this[args];
	}
});
/** @internal */
var matchCauseEffectEager$1 = /*#__PURE__*/ dual(2, (self, options) => {
	if (effectIsExit(self)) return self._tag === "Success" ? options.onSuccess(self.value) : options.onFailure(self.cause);
	return matchCauseEffect$1(self, options);
});
/** @internal */
var effectIsExit = (effect) => ExitTypeId in effect;
/** @internal */
var flatMapEager$1 = /*#__PURE__*/ dual(2, (self, f) => {
	if (effectIsExit(self)) return self._tag === "Success" ? f(self.value) : self;
	return flatMap$2(self, f);
});
/** @internal */
var flatten$1 = (self) => flatMap$2(self, identity);
/** @internal */
var map$4 = /*#__PURE__*/ dual(2, (self, f) => flatMap$2(self, (a) => succeed$5(internalCall(() => f(a)))));
/** @internal */
var mapEager$1 = /*#__PURE__*/ dual(2, (self, f) => effectIsExit(self) ? exitMap(self, f) : map$4(self, f));
/** @internal */
var mapErrorEager$1 = /*#__PURE__*/ dual(2, (self, f) => effectIsExit(self) ? exitMapError(self, f) : mapError$2(self, f));
/** @internal */
var mapBothEager$1 = /*#__PURE__*/ dual(2, (self, options) => effectIsExit(self) ? exitMapBoth(self, options) : mapBoth$2(self, options));
/** @internal */
var catchEager$1 = /*#__PURE__*/ dual(2, (self, f) => {
	if (effectIsExit(self)) {
		if (self._tag === "Success") return self;
		const error = findError$2(self.cause);
		if (isFailure$3(error)) return self;
		return f(error.success);
	}
	return catch_$2(self, f);
});
/** @internal */
var exitInterrupt = (fiberId) => exitFailCause(causeInterrupt(fiberId));
/** @internal */
var exitIsSuccess = (self) => self._tag === "Success";
/** @internal */
var exitFilterSuccess = (self) => self._tag === "Success" ? succeed$6(self) : fail$6(self);
/** @internal */
var exitFilterValue = (self) => self._tag === "Success" ? succeed$6(self.value) : fail$6(self);
/** @internal */
var exitIsFailure = (self) => self._tag === "Failure";
/** @internal */
var exitFilterFailure = (self) => self._tag === "Failure" ? succeed$6(self) : fail$6(self);
/** @internal */
var exitFilterCause = (self) => self._tag === "Failure" ? succeed$6(self.cause) : fail$6(self);
/** @internal */
var exitFindError = /*#__PURE__*/ composePassthrough(exitFilterCause, findError$2);
/** @internal */
var exitFindDefect = /*#__PURE__*/ composePassthrough(exitFilterCause, findDefect$2);
/** @internal */
var exitHasInterrupts = (self) => self._tag === "Failure" && hasInterrupts$2(self.cause);
/** @internal */
var exitHasDies = (self) => self._tag === "Failure" && hasDies$2(self.cause);
/** @internal */
var exitHasFails = (self) => self._tag === "Failure" && hasFails$2(self.cause);
/** @internal */
var exitVoid = /*#__PURE__*/ exitSucceed(void 0);
/** @internal */
var exitMap = /*#__PURE__*/ dual(2, (self, f) => self._tag === "Success" ? exitSucceed(f(self.value)) : self);
/** @internal */
var exitMapError = /*#__PURE__*/ dual(2, (self, f) => {
	if (self._tag === "Success") return self;
	const error = findError$2(self.cause);
	if (isFailure$3(error)) return self;
	return exitFail(f(error.success));
});
/** @internal */
var exitMapBoth = /*#__PURE__*/ dual(2, (self, options) => {
	if (self._tag === "Success") return exitSucceed(options.onSuccess(self.value));
	const error = findError$2(self.cause);
	if (isFailure$3(error)) return self;
	return exitFail(options.onFailure(error.success));
});
/** @internal */
var exitAs = /*#__PURE__*/ dual(2, (self, b) => exitIsSuccess(self) ? exitSucceed(b) : self);
/** @internal */
var exitZipRight = /*#__PURE__*/ dual(2, (self, that) => exitIsSuccess(self) ? that : self);
/** @internal */
var exitMatch = /*#__PURE__*/ dual(2, (self, options) => exitIsSuccess(self) ? options.onSuccess(self.value) : options.onFailure(self.cause));
/** @internal */
var exitAsVoid = /*#__PURE__*/ exitAs(void 0);
/** @internal */
var exitAsVoidAll = (exits) => {
	const failures = [];
	for (const exit of exits) if (exit._tag === "Failure") failures.push(...exit.cause.reasons);
	return failures.length === 0 ? exitVoid : exitFailCause(causeFromReasons(failures));
};
/** @internal */
var exitGetSuccess = (self) => exitIsSuccess(self) ? some$2(self.value) : none();
/** @internal */
var exitGetCause = (self) => exitIsFailure(self) ? some$2(self.cause) : none();
/** @internal */
var exitFindErrorOption = (self) => {
	const error = exitFindError(self);
	return isFailure$3(error) ? none() : some$2(error.success);
};
/** @internal */
var service$1 = fromYieldable$1;
/** @internal */
var serviceOption$1 = (service) => withFiber$1((fiber) => succeed$5(getOption(fiber.services, service)));
/** @internal */
var serviceOptional = (service) => withFiber$1((fiber) => fiber.services.mapUnsafe.has(service.key) ? succeed$5(getUnsafe(fiber.services, service)) : fail$5(new NoSuchElementError$1()));
/** @internal */
var updateServices$1 = /*#__PURE__*/ dual(2, (self, f) => withFiber$1((fiber) => {
	const prev = fiber.services;
	const nextServices = f(prev);
	if (prev === nextServices) return self;
	fiber.setServices(nextServices);
	return onExitPrimitive$1(self, () => {
		fiber.setServices(prev);
	});
}));
/** @internal */
var updateService$2 = /*#__PURE__*/ dual(3, (self, service, f) => updateServices$1(self, (s) => {
	const prev = getUnsafe(s, service);
	const next = f(prev);
	if (prev === next) return s;
	return add$1(s, service, next);
}));
/** @internal */
var services$1 = () => getServiceMap;
var getServiceMap = /*#__PURE__*/ withFiber$1((fiber) => succeed$5(fiber.services));
/** @internal */
var servicesWith$1 = (f) => withFiber$1((fiber) => f(fiber.services));
/** @internal */
var provideServices$1 = /*#__PURE__*/ dual(2, (self, services) => {
	if (effectIsExit(self)) return self;
	return updateServices$1(self, merge$2(services));
});
/** @internal */
var provideService$1 = function() {
	if (arguments.length === 1) return dual(2, (self, impl) => provideServiceImpl(self, arguments[0], impl));
	return dual(3, (self, service, impl) => provideServiceImpl(self, service, impl)).apply(this, arguments);
};
var provideServiceImpl = (self, service, implementation) => updateServices$1(self, (s) => {
	if (s.mapUnsafe.get(service.key) === implementation) return s;
	return add$1(s, service, implementation);
});
/** @internal */
var provideServiceEffect$1 = /*#__PURE__*/ dual(3, (self, service, acquire) => flatMap$2(acquire, (implementation) => provideService$1(self, service, implementation)));
/** @internal */
var withConcurrency$1 = /*#__PURE__*/ provideService$1(CurrentConcurrency);
/** @internal */
var zip$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[1]), (self, that, options) => zipWith$1(self, that, (a, a2) => [a, a2], options));
/** @internal */
var zipWith$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[1]), (self, that, f, options) => options?.concurrent ? map$4(all$1([self, that], { concurrency: 2 }), ([a, a2]) => internalCall(() => f(a, a2))) : flatMap$2(self, (a) => map$4(that, (a2) => internalCall(() => f(a, a2)))));
var filterOrFail$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, predicate, orFailWith) => filterOrElse$1(self, predicate, orFailWith ? (a) => fail$5(orFailWith(a)) : () => fail$5(new NoSuchElementError$1())));
/** @internal */
var when$1 = /*#__PURE__*/ dual(2, (self, condition) => flatMap$2(condition, (pass) => pass ? asSome$1(self) : succeedNone$1));
/** @internal */
var replicate$1 = /*#__PURE__*/ dual(2, (self, n) => Array.from({ length: n }, () => self));
/** @internal */
var replicateEffect$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, n, options) => all$1(replicate$1(self, n), options));
/** @internal */
var forever$2 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => whileLoop$1({
	while: constTrue,
	body: constant(options?.disableYield ? self : flatMap$2(self, (_) => yieldNow$1)),
	step: constVoid
}));
/** @internal */
var catchCause$2 = /*#__PURE__*/ dual(2, (self, f) => {
	const onFailure = Object.create(OnFailureProto);
	onFailure[args] = self;
	onFailure[contE] = f.length !== 1 ? (cause) => f(cause) : f;
	return onFailure;
});
var OnFailureProto = /*#__PURE__*/ makePrimitiveProto({
	op: "OnFailure",
	[evaluate](fiber) {
		fiber._stack.push(this);
		return this[args];
	}
});
/** @internal */
var catchCauseIf$1 = /*#__PURE__*/ dual(3, (self, predicate, f) => catchCause$2(self, (cause) => {
	if (!predicate(cause)) return failCause$4(cause);
	return internalCall(() => f(cause));
}));
/** @internal */
var catchCauseFilter$1 = /*#__PURE__*/ dual(3, (self, filter, f) => catchCause$2(self, (cause) => {
	const eb = filter(cause);
	return isFailure$3(eb) ? failCause$4(eb.failure) : internalCall(() => f(eb.success, cause));
}));
/** @internal */
var catch_$2 = /*#__PURE__*/ dual(2, (self, f) => catchCauseFilter$1(self, findError$2, (e) => f(e)));
/** @internal */
var catchNoSuchElement$1 = (self) => matchEffect$2(self, {
	onFailure: (error) => isNoSuchElementError$1(error) ? succeedNone$1 : fail$5(error),
	onSuccess: succeedSome$1
});
/** @internal */
var catchDefect$1 = /*#__PURE__*/ dual(2, (self, f) => catchCauseFilter$1(self, findDefect$2, f));
/** @internal */
var tapCause$1 = /*#__PURE__*/ dual(2, (self, f) => catchCause$2(self, (cause) => andThen$2(internalCall(() => f(cause)), failCause$4(cause))));
/** @internal */
var tapCauseIf$1 = /*#__PURE__*/ dual(3, (self, predicate, f) => catchCauseIf$1(self, predicate, (cause) => andThen$2(internalCall(() => f(cause)), failCause$4(cause))));
/** @internal */
var tapCauseFilter$1 = /*#__PURE__*/ dual(3, (self, filter, f) => catchCause$2(self, (cause) => {
	const result = filter(cause);
	if (isFailure$3(result)) return failCause$4(cause);
	return andThen$2(internalCall(() => f(result.success, cause)), failCause$4(cause));
}));
/** @internal */
var tapError$1 = /*#__PURE__*/ dual(2, (self, f) => tapCauseFilter$1(self, findError$2, (e) => f(e)));
/** @internal */
var tapErrorTag$1 = /*#__PURE__*/ dual(3, (self, k, f) => {
	const predicate = Array.isArray(k) ? (e) => hasProperty(e, "_tag") && k.includes(e._tag) : isTagged(k);
	return tapError$1(self, (error) => predicate(error) ? f(error) : void_$2);
});
/** @internal */
var tapDefect$1 = /*#__PURE__*/ dual(2, (self, f) => tapCauseFilter$1(self, findDefect$2, (_) => f(_)));
/** @internal */
var catchIf$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, predicate, f, orElse) => catchCause$2(self, (cause) => {
	const error = findError$2(cause);
	if (isFailure$3(error)) return failCause$4(error.failure);
	if (!predicate(error.success)) return orElse ? internalCall(() => orElse(error.success)) : failCause$4(cause);
	return internalCall(() => f(error.success));
}));
/** @internal */
var catchFilter$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, filter, f, orElse) => catchCause$2(self, (cause) => {
	const error = findError$2(cause);
	if (isFailure$3(error)) return failCause$4(error.failure);
	const result = filter(error.success);
	if (isFailure$3(result)) return orElse ? internalCall(() => orElse(result.failure)) : failCause$4(cause);
	return internalCall(() => f(result.success));
}));
/** @internal */
var catchTag$2 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, k, f, orElse) => {
	return catchIf$1(self, Array.isArray(k) ? (e) => hasProperty(e, "_tag") && k.includes(e._tag) : isTagged(k), f, orElse);
});
/** @internal */
var catchTags$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, cases, orElse) => {
	let keys;
	return catchFilter$1(self, (e) => {
		keys ??= Object.keys(cases);
		return hasProperty(e, "_tag") && isString$1(e["_tag"]) && keys.includes(e["_tag"]) ? succeed$6(e) : fail$6(e);
	}, (e) => internalCall(() => cases[e["_tag"]](e)), orElse);
});
/** @internal */
var catchReason$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, errorTag, reasonTag, f, orElse) => catchIf$1(self, (e) => isTagged(e, errorTag) && hasProperty(e, "reason"), (e) => {
	const reason = e.reason;
	if (isTagged(reason, reasonTag)) return f(reason, e);
	return orElse ? internalCall(() => orElse(reason, e)) : fail$5(e);
}));
/** @internal */
var catchReasons$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, errorTag, cases, orElse) => {
	let keys;
	return catchIf$1(self, (e) => isTagged(e, errorTag) && hasProperty(e, "reason") && hasProperty(e.reason, "_tag") && isString$1(e.reason._tag), (e) => {
		const reason = e.reason;
		keys ??= Object.keys(cases);
		if (keys.includes(reason._tag)) return internalCall(() => cases[reason._tag](reason, e));
		return orElse ? internalCall(() => orElse(reason, e)) : fail$5(e);
	});
});
/** @internal */
var unwrapReason$1 = /*#__PURE__*/ dual(2, (self, errorTag) => catchFilter$1(self, (e) => {
	if (isTagged(e, errorTag) && hasProperty(e, "reason")) return succeed$6(e.reason);
	return fail$6(e);
}, fail$5));
/** @internal */
var mapError$2 = /*#__PURE__*/ dual(2, (self, f) => catch_$2(self, (error) => failSync$2(() => f(error))));
var mapBoth$2 = /*#__PURE__*/ dual(2, (self, options) => matchEffect$2(self, {
	onFailure: (e) => failSync$2(() => options.onFailure(e)),
	onSuccess: (a) => sync$3(() => options.onSuccess(a))
}));
/** @internal */
var orDie$2 = (self) => catch_$2(self, die$4);
/** @internal */
var orElseSucceed$1 = /*#__PURE__*/ dual(2, (self, f) => catch_$2(self, (_) => sync$3(f)));
/** @internal */
var eventually$1 = (self) => catch_$2(self, (_) => flatMap$2(yieldNow$1, () => eventually$1(self)));
/** @internal */
var ignore$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => {
	if (!options?.log) return matchEffect$2(self, {
		onFailure: (_) => void_$2,
		onSuccess: (_) => void_$2
	});
	const logEffect = logWithLevel$1(options.log === true ? void 0 : options.log);
	return matchCauseEffect$1(self, {
		onFailure(cause) {
			const failure = findFail$1(cause);
			return isFailure$3(failure) ? failCause$4(failure.failure) : logEffect(cause);
		},
		onSuccess: (_) => void_$2
	});
});
/** @internal */
var ignoreCause$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => {
	if (!options?.log) return matchCauseEffect$1(self, {
		onFailure: (_) => void_$2,
		onSuccess: (_) => void_$2
	});
	return matchCauseEffect$1(self, {
		onFailure: logWithLevel$1(options.log === true ? void 0 : options.log),
		onSuccess: (_) => void_$2
	});
});
/** @internal */
var option$1 = (self) => match$5(self, {
	onFailure: none,
	onSuccess: some$2
});
/** @internal */
var result$1 = (self) => matchEager$1(self, {
	onFailure: fail$6,
	onSuccess: succeed$6
});
/** @internal */
var matchCauseEffect$1 = /*#__PURE__*/ dual(2, (self, options) => {
	const primitive = Object.create(OnSuccessAndFailureProto);
	primitive[args] = self;
	primitive[contA] = options.onSuccess.length !== 1 ? (a) => options.onSuccess(a) : options.onSuccess;
	primitive[contE] = options.onFailure.length !== 1 ? (cause) => options.onFailure(cause) : options.onFailure;
	return primitive;
});
var OnSuccessAndFailureProto = /*#__PURE__*/ makePrimitiveProto({
	op: "OnSuccessAndFailure",
	[evaluate](fiber) {
		fiber._stack.push(this);
		return this[args];
	}
});
/** @internal */
var matchCause$1 = /*#__PURE__*/ dual(2, (self, options) => matchCauseEffect$1(self, {
	onFailure: (cause) => sync$3(() => options.onFailure(cause)),
	onSuccess: (value) => sync$3(() => options.onSuccess(value))
}));
/** @internal */
var matchEffect$2 = /*#__PURE__*/ dual(2, (self, options) => matchCauseEffect$1(self, {
	onFailure: (cause) => {
		const fail = cause.reasons.find(isFailReason$1);
		return fail ? internalCall(() => options.onFailure(fail.error)) : failCause$4(cause);
	},
	onSuccess: options.onSuccess
}));
/** @internal */
var match$5 = /*#__PURE__*/ dual(2, (self, options) => matchEffect$2(self, {
	onFailure: (error) => sync$3(() => options.onFailure(error)),
	onSuccess: (value) => sync$3(() => options.onSuccess(value))
}));
/** @internal */
var matchEager$1 = /*#__PURE__*/ dual(2, (self, options) => {
	if (effectIsExit(self)) {
		if (self._tag === "Success") return exitSucceed(options.onSuccess(self.value));
		const error = findError$2(self.cause);
		if (isFailure$3(error)) return self;
		return exitSucceed(options.onFailure(error.success));
	}
	return match$5(self, options);
});
/** @internal */
var matchCauseEager$1 = /*#__PURE__*/ dual(2, (self, options) => {
	if (effectIsExit(self)) {
		if (self._tag === "Success") return exitSucceed(options.onSuccess(self.value));
		return exitSucceed(options.onFailure(self.cause));
	}
	return matchCause$1(self, options);
});
/** @internal */
var exit$1 = (self) => effectIsExit(self) ? exitSucceed(self) : exitPrimitive(self);
var exitPrimitive = /*#__PURE__*/ makePrimitive({
	op: "Exit",
	[evaluate](fiber) {
		fiber._stack.push(this);
		return this[args];
	},
	[contA](value, _, exit) {
		return succeed$5(exit ?? exitSucceed(value));
	},
	[contE](cause, _, exit) {
		return succeed$5(exit ?? exitFailCause(cause));
	}
});
/** @internal */
var isFailure$2 = /*#__PURE__*/ matchEager$1({
	onFailure: () => true,
	onSuccess: () => false
});
/** @internal */
var isSuccess$2 = /*#__PURE__*/ matchEager$1({
	onFailure: () => false,
	onSuccess: () => true
});
/** @internal */
var delay$1 = /*#__PURE__*/ dual(2, (self, duration) => andThen$2(sleep$1(duration), self));
/** @internal */
var timeoutOrElse$1 = /*#__PURE__*/ dual(2, (self, options) => raceFirst$1(self, flatMap$2(sleep$1(options.duration), options.onTimeout)));
/** @internal */
var timeout$1 = /*#__PURE__*/ dual(2, (self, duration) => timeoutOrElse$1(self, {
	duration,
	onTimeout: () => fail$5(new TimeoutError$1())
}));
/** @internal */
var timeoutOption$1 = /*#__PURE__*/ dual(2, (self, duration) => raceFirst$1(asSome$1(self), as$1(sleep$1(duration), none())));
/** @internal */
var timed$1 = (self) => clockWith$2((clock) => {
	const start = clock.currentTimeNanosUnsafe();
	return map$4(self, (a) => [nanos(clock.currentTimeNanosUnsafe() - start), a]);
});
/** @internal */
var ScopeTypeId = "~effect/Scope";
/** @internal */
var ScopeCloseableTypeId = "~effect/Scope/Closeable";
/** @internal */
var scopeTag = /*#__PURE__*/ Service("effect/Scope");
/** @internal */
var scopeClose = (self, exit_) => suspend$1(() => scopeCloseUnsafe(self, exit_) ?? void_$2);
/** @internal */
var scopeCloseUnsafe = (self, exit_) => {
	if (self.state._tag === "Closed") return;
	const closed = {
		_tag: "Closed",
		exit: exit_
	};
	if (self.state._tag === "Empty") {
		self.state = closed;
		return;
	}
	const { finalizers } = self.state;
	self.state = closed;
	if (finalizers.size === 0) return;
	else if (finalizers.size === 1) return finalizers.values().next().value(exit_);
	return scopeCloseFinalizers(self, finalizers, exit_);
};
var scopeCloseFinalizers = /*#__PURE__*/ fnUntraced$1(function* (self, finalizers, exit_) {
	let exits = [];
	const fibers = [];
	const arr = Array.from(finalizers.values());
	const parent = getCurrentFiber();
	for (let i = arr.length - 1; i >= 0; i--) {
		const finalizer = arr[i];
		if (self.strategy === "sequential") exits.push(yield* exit$1(finalizer(exit_)));
		else fibers.push(forkUnsafe$1(parent, finalizer(exit_), true, true, "inherit"));
	}
	if (fibers.length > 0) exits = yield* fiberAwaitAll(fibers);
	return yield* exitAsVoidAll(exits);
});
/** @internal */
var scopeFork = (scope, finalizerStrategy) => sync$3(() => scopeForkUnsafe(scope, finalizerStrategy));
/** @internal */
var scopeForkUnsafe = (scope, finalizerStrategy) => {
	const newScope = scopeMakeUnsafe(finalizerStrategy);
	if (scope.state._tag === "Closed") {
		newScope.state = scope.state;
		return newScope;
	}
	const key = {};
	scopeAddFinalizerUnsafe(scope, key, (exit) => scopeClose(newScope, exit));
	scopeAddFinalizerUnsafe(newScope, key, (_) => sync$3(() => scopeRemoveFinalizerUnsafe(scope, key)));
	return newScope;
};
/** @internal */
var scopeAddFinalizerExit = (scope, finalizer) => {
	return suspend$1(() => {
		if (scope.state._tag === "Closed") return finalizer(scope.state.exit);
		scopeAddFinalizerUnsafe(scope, {}, finalizer);
		return void_$2;
	});
};
/** @internal */
var scopeAddFinalizer = (scope, finalizer) => scopeAddFinalizerExit(scope, constant(finalizer));
/** @internal */
var scopeAddFinalizerUnsafe = (scope, key, finalizer) => {
	if (scope.state._tag === "Empty") scope.state = {
		_tag: "Open",
		finalizers: /* @__PURE__ */ new Map([[key, finalizer]])
	};
	else if (scope.state._tag === "Open") scope.state.finalizers.set(key, finalizer);
};
/** @internal */
var scopeRemoveFinalizerUnsafe = (scope, key) => {
	if (scope.state._tag === "Open") scope.state.finalizers.delete(key);
};
/** @internal */
var scopeMakeUnsafe = (finalizerStrategy = "sequential") => ({
	[ScopeCloseableTypeId]: ScopeCloseableTypeId,
	[ScopeTypeId]: ScopeTypeId,
	strategy: finalizerStrategy,
	state: constScopeEmpty
});
var constScopeEmpty = { _tag: "Empty" };
/** @internal */
var scopeMake = (finalizerStrategy) => sync$3(() => scopeMakeUnsafe(finalizerStrategy));
/** @internal */
var scope$1 = /*#__PURE__*/ scopeTag.asEffect();
/** @internal */
var provideScope = /*#__PURE__*/ provideService$1(scopeTag);
/** @internal */
var scoped$1 = (self) => withFiber$1((fiber) => {
	const prev = fiber.services;
	const scope = scopeMakeUnsafe();
	fiber.setServices(add$1(fiber.services, scopeTag, scope));
	return onExitPrimitive$1(self, (exit) => {
		fiber.setServices(prev);
		return scopeCloseUnsafe(scope, exit);
	});
});
/** @internal */
var scopeUse = /*#__PURE__*/ dual(2, (self, scope) => onExit$1(provideScope(self, scope), (exit) => suspend$1(() => scopeCloseUnsafe(scope, exit) ?? void_$2)));
/** @internal */
var scopedWith$1 = (f) => suspend$1(() => {
	const scope = scopeMakeUnsafe();
	return onExit$1(f(scope), (exit) => suspend$1(() => scopeCloseUnsafe(scope, exit) ?? void_$2));
});
/** @internal */
var acquireRelease$1 = (acquire, release) => uninterruptible$1(flatMap$2(scope$1, (scope) => tap$1(acquire, (a) => scopeAddFinalizerExit(scope, (exit) => internalCall(() => release(a, exit))))));
/** @internal */
var addFinalizer$2 = (finalizer) => flatMap$2(scope$1, (scope) => servicesWith$1((services) => scopeAddFinalizerExit(scope, (exit) => provideServices$1(finalizer(exit), services))));
/** @internal */
var onExitPrimitive$1 = /*#__PURE__*/ makePrimitive({
	op: "OnExit",
	single: false,
	[evaluate](fiber) {
		fiber._stack.push(this);
		return this[args][0];
	},
	[contAll](fiber) {
		if (fiber.interruptible && this[args][2] !== true) {
			fiber._stack.push(setInterruptibleTrue);
			fiber.interruptible = false;
		}
	},
	[contA](value, _, exit) {
		exit ??= exitSucceed(value);
		const eff = this[args][1](exit);
		return eff ? flatMap$2(eff, (_) => exit) : exit;
	},
	[contE](cause, _, exit) {
		exit ??= exitFailCause(cause);
		const eff = this[args][1](exit);
		return eff ? flatMap$2(eff, (_) => exit) : exit;
	}
});
/** @internal */
var onExit$1 = /*#__PURE__*/ dual(2, onExitPrimitive$1);
/** @internal */
var ensuring$1 = /*#__PURE__*/ dual(2, (self, finalizer) => onExit$1(self, (_) => finalizer));
/** @internal */
var onExitIf$1 = /*#__PURE__*/ dual(3, (self, predicate, f) => onExit$1(self, (exit) => {
	if (!predicate(exit)) return void_$2;
	return f(exit);
}));
/** @internal */
var onExitFilter$1 = /*#__PURE__*/ dual(3, (self, filter, f) => onExit$1(self, (exit) => {
	const b = filter(exit);
	return isFailure$3(b) ? void_$2 : f(b.success, exit);
}));
/** @internal */
var onError$1 = /*#__PURE__*/ dual(2, (self, f) => onExitFilter$1(self, exitFilterCause, f));
/** @internal */
var onErrorIf$1 = /*#__PURE__*/ dual(3, (self, predicate, f) => onExitIf$1(self, (exit) => {
	if (exit._tag !== "Failure") return false;
	return predicate(exit.cause);
}, (exit) => f(exit.cause)));
/** @internal */
var onErrorFilter$1 = /*#__PURE__*/ dual(3, (self, filter, f) => onExit$1(self, (exit) => {
	if (exit._tag !== "Failure") return void_$2;
	const result = filter(exit.cause);
	return isFailure$3(result) ? void_$2 : f(result.success, exit.cause);
}));
/** @internal */
var onInterrupt$1 = /*#__PURE__*/ dual(2, (self, finalizer) => onErrorFilter$1(causeFilterInterruptors, finalizer)(self));
/** @internal */
var acquireUseRelease$1 = (acquire, use, release) => uninterruptibleMask$1((restore) => flatMap$2(acquire, (a) => onExitPrimitive$1(restore(use(a)), (exit) => release(a, exit), true)));
/** @internal */
var cachedInvalidateWithTTL$1 = /*#__PURE__*/ dual(2, (self, ttl) => sync$3(() => {
	const ttlMillis = toMillis(fromInputUnsafe(ttl));
	const isFinite = Number.isFinite(ttlMillis);
	const latch = makeLatchUnsafe(false);
	let expiresAt = 0;
	let running = false;
	let exit;
	const wait = flatMap$2(latch.await, () => exit);
	return [withFiber$1((fiber) => {
		const now = isFinite ? fiber.getRef(ClockRef).currentTimeMillisUnsafe() : 0;
		if (running || now < expiresAt) return exit ?? wait;
		running = true;
		latch.closeUnsafe();
		exit = void 0;
		return onExit$1(self, (exit_) => sync$3(() => {
			running = false;
			expiresAt = now + ttlMillis;
			exit = exit_;
			latch.openUnsafe();
		}));
	}), sync$3(() => {
		expiresAt = 0;
		latch.closeUnsafe();
		exit = void 0;
	})];
}));
/** @internal */
var cachedWithTTL$1 = /*#__PURE__*/ dual(2, (self, timeToLive) => map$4(cachedInvalidateWithTTL$1(self, timeToLive), (tuple) => tuple[0]));
/** @internal */
var cached$1 = (self) => cachedWithTTL$1(self, infinity);
/** @internal */
var interrupt$4 = /*#__PURE__*/ withFiber$1((fiber) => failCause$4(causeInterrupt(fiber.id)));
/** @internal */
var uninterruptible$1 = (self) => withFiber$1((fiber) => {
	if (!fiber.interruptible) return self;
	fiber.interruptible = false;
	fiber._stack.push(setInterruptibleTrue);
	return self;
});
var setInterruptible = /*#__PURE__*/ makePrimitive({
	op: "SetInterruptible",
	[contAll](fiber) {
		fiber.interruptible = this[args];
		if (fiber._interruptedCause && fiber.interruptible) return () => failCause$4(fiber._interruptedCause);
	}
});
var setInterruptibleTrue = /*#__PURE__*/ setInterruptible(true);
var setInterruptibleFalse = /*#__PURE__*/ setInterruptible(false);
/** @internal */
var interruptible$1 = (self) => withFiber$1((fiber) => {
	if (fiber.interruptible) return self;
	fiber.interruptible = true;
	fiber._stack.push(setInterruptibleFalse);
	if (fiber._interruptedCause) return failCause$4(fiber._interruptedCause);
	return self;
});
/** @internal */
var uninterruptibleMask$1 = (f) => withFiber$1((fiber) => {
	if (!fiber.interruptible) return f(identity);
	fiber.interruptible = false;
	fiber._stack.push(setInterruptibleTrue);
	return f(interruptible$1);
});
/** @internal */
var interruptibleMask$1 = (f) => withFiber$1((fiber) => {
	if (fiber.interruptible) return f(identity);
	fiber.interruptible = true;
	fiber._stack.push(setInterruptibleFalse);
	return f(uninterruptible$1);
});
/** @internal */
var all$1 = (arg, options) => {
	if (isIterable(arg)) return options?.mode === "result" ? forEach$1(arg, result$1, options) : forEach$1(arg, identity, options);
	else if (options?.discard) return options.mode === "result" ? forEach$1(Object.values(arg), result$1, options) : forEach$1(Object.values(arg), identity, options);
	return suspend$1(() => {
		const out = {};
		return as$1(forEach$1(Object.entries(arg), ([key, effect]) => map$4(options?.mode === "result" ? result$1(effect) : effect, (value) => {
			out[key] = value;
		}), {
			discard: true,
			concurrency: options?.concurrency
		}), out);
	});
};
/** @internal */
var partition$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, f, options) => map$4(forEach$1(elements, (a, i) => result$1(f(a, i)), options), (results) => partition$2(results, identity)));
/** @internal */
var validate$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, f, options) => flatMap$2(partition$1(elements, f, { concurrency: options?.concurrency }), ([excluded, satisfying]) => {
	if (isArrayNonEmpty(excluded)) return fail$5(excluded);
	return options?.discard ? void_$2 : succeed$5(satisfying);
}));
/** @internal */
var findFirst$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, predicate) => suspend$1(() => {
	const iterator = elements[Symbol.iterator]();
	const next = iterator.next();
	if (!next.done) return findFirstLoop(iterator, 0, predicate, next.value);
	return succeed$5(none());
}));
var findFirstLoop = (iterator, index, predicate, value) => flatMap$2(predicate(value, index), (keep) => {
	if (keep) return succeed$5(some$2(value));
	const next = iterator.next();
	if (!next.done) return findFirstLoop(iterator, index + 1, predicate, next.value);
	return succeed$5(none());
});
/** @internal */
var findFirstFilter$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, filter) => suspend$1(() => {
	const iterator = elements[Symbol.iterator]();
	const next = iterator.next();
	if (!next.done) return findFirstFilterLoop(iterator, 0, filter, next.value);
	return succeed$5(none());
}));
var findFirstFilterLoop = (iterator, index, filter, value) => flatMap$2(filter(value, index), (result) => {
	if (isSuccess$3(result)) return succeed$5(some$2(result.success));
	const next = iterator.next();
	if (!next.done) return findFirstFilterLoop(iterator, index + 1, filter, next.value);
	return succeed$5(none());
});
/** @internal */
var whileLoop$1 = /*#__PURE__*/ makePrimitive({
	op: "While",
	[contA](value, fiber) {
		this[args].step(value);
		if (this[args].while()) {
			fiber._stack.push(this);
			return this[args].body();
		}
		return exitVoid;
	},
	[evaluate](fiber) {
		if (this[args].while()) {
			fiber._stack.push(this);
			return this[args].body();
		}
		return exitVoid;
	}
});
/** @internal */
var forEach$1 = /*#__PURE__*/ dual((args) => typeof args[1] === "function", (iterable, f, options) => withFiber$1((parent) => {
	const concurrencyOption = options?.concurrency === "inherit" ? parent.getRef(CurrentConcurrency) : options?.concurrency ?? 1;
	const concurrency = concurrencyOption === "unbounded" ? Number.POSITIVE_INFINITY : Math.max(1, concurrencyOption);
	if (concurrency === 1) return forEachSequential(iterable, f, options);
	const items = fromIterable(iterable);
	let length = items.length;
	if (length === 0) return options?.discard ? void_$2 : succeed$5([]);
	const out = options?.discard ? void 0 : new Array(length);
	let index = 0;
	const annotations = fiberStackAnnotations(parent);
	return callback$1((resume) => {
		const fibers = /* @__PURE__ */ new Set();
		const failures = [];
		let failed = false;
		let inProgress = 0;
		let doneCount = 0;
		let pumping = false;
		let interrupted = false;
		function pump() {
			pumping = true;
			while (inProgress < concurrency && index < length) {
				const currentIndex = index;
				const item = items[currentIndex];
				index++;
				inProgress++;
				try {
					const child = forkUnsafe$1(parent, f(item, currentIndex), true, true, "inherit");
					fibers.add(child);
					child.addObserver((exit) => {
						if (interrupted) return;
						fibers.delete(child);
						if (exit._tag === "Failure") if (!failed) {
							failed = true;
							length = index;
							failures.push(...exit.cause.reasons);
							fibers.forEach((fiber) => fiber.interruptUnsafe(parent.id, annotations));
						} else for (const f of exit.cause.reasons) {
							if (f._tag === "Interrupt") continue;
							failures.push(f);
						}
						else if (out !== void 0) out[currentIndex] = exit.value;
						doneCount++;
						inProgress--;
						if (doneCount === length) resume(failures.length > 0 ? exitFailCause(causeFromReasons(failures)) : succeed$5(out));
						else if (!pumping && !failed && inProgress < concurrency) pump();
					});
				} catch (err) {
					failed = true;
					length = index;
					failures.push(new Die(err));
					fibers.forEach((fiber) => fiber.interruptUnsafe(parent.id, annotations));
				}
			}
			pumping = false;
		}
		pump();
		return suspend$1(() => {
			interrupted = true;
			index = length;
			return fiberInterruptAll(fibers);
		});
	});
}));
var forEachSequential = (iterable, f, options) => suspend$1(() => {
	const out = options?.discard ? void 0 : [];
	const iterator = iterable[Symbol.iterator]();
	let state = iterator.next();
	let index = 0;
	return as$1(whileLoop$1({
		while: () => !state.done,
		body: () => f(state.value, index++),
		step: (b) => {
			if (out) out.push(b);
			state = iterator.next();
		}
	}), out);
});
var filterOrElse$1 = /*#__PURE__*/ dual(3, (self, predicate, orElse) => flatMap$2(self, (a) => predicate(a) ? succeed$5(a) : orElse(a)));
/** @internal */
var filterMapOrElse$1 = /*#__PURE__*/ dual(3, (self, filter, orElse) => flatMap$2(self, (a) => {
	const result = filter(a);
	return isFailure$3(result) ? orElse(result.failure) : succeed$5(result.success);
}));
var filterMapOrFail$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, filter, orFailWith) => filterMapOrElse$1(self, filter, orFailWith ? (x) => fail$5(orFailWith(x)) : () => fail$5(new NoSuchElementError$1())));
/** @internal */
var filter$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, predicate, options) => suspend$1(() => {
	const out = [];
	return as$1(forEach$1(elements, (a, i) => {
		const result = predicate(a, i);
		if (typeof result === "boolean") {
			if (result) out.push(a);
			return void_$2;
		}
		return map$4(result, (keep) => {
			if (keep) out.push(a);
		});
	}, {
		discard: true,
		concurrency: options?.concurrency
	}), out);
}));
/** @internal */
var filterMap$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, filter) => suspend$1(() => {
	const out = [];
	for (const a of elements) {
		const result = filter(a);
		if (isSuccess$3(result)) out.push(result.success);
	}
	return succeed$5(out);
}));
/** @internal */
var filterMapEffect$1 = /*#__PURE__*/ dual((args) => isIterable(args[0]) && !isEffect$1(args[0]), (elements, filter, options) => suspend$1(() => {
	const out = [];
	return as$1(forEach$1(elements, (a) => map$4(filter(a), (result) => {
		if (isSuccess$3(result)) out.push(result.success);
	}), {
		discard: true,
		concurrency: options?.concurrency
	}), out);
}));
/** @internal */
var Do$1 = /*#__PURE__*/ succeed$5({});
/** @internal */
var bindTo$1 = /*#__PURE__*/ bindTo$3(map$4);
/** @internal */
var bind$1 = /*#__PURE__*/ bind$3(map$4, flatMap$2);
/** @internal */
var let_$1 = /*#__PURE__*/ let_$3(map$4);
/** @internal */
var forkChild$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => withFiber$1((fiber) => {
	interruptChildrenPatch();
	return succeed$5(forkUnsafe$1(fiber, self, options?.startImmediately, false, options?.uninterruptible ?? false));
}));
/** @internal */
var forkUnsafe$1 = (parent, effect, immediate = false, daemon = false, uninterruptible = false) => {
	const interruptible = uninterruptible === "inherit" ? parent.interruptible : !uninterruptible;
	const child = new FiberImpl(parent.services, interruptible);
	if (immediate) child.evaluate(effect);
	else parent.currentScheduler.scheduleTask(() => child.evaluate(effect), 0);
	if (!daemon && !child._exit) {
		parent.children().add(child);
		child.addObserver(() => parent._children.delete(child));
	}
	return child;
};
/** @internal */
var forkDetach$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => withFiber$1((fiber) => succeed$5(forkUnsafe$1(fiber, self, options?.startImmediately, true, options?.uninterruptible))));
/** @internal */
var awaitAllChildren$1 = (self) => withFiber$1((fiber) => {
	const initialChildren = fiber._children && fromIterable(fiber._children);
	return onExit$1(self, (_) => {
		let children = fiber._children;
		if (children === void 0 || children.size === 0) return void_$2;
		else if (initialChildren) children = filter$3(children, (child) => !initialChildren.includes(child));
		return asVoid$2(fiberAwaitAll(children));
	});
});
/** @internal */
var forkIn$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, scope, options) => withFiber$1((parent) => {
	const fiber = forkUnsafe$1(parent, self, options?.startImmediately, true, options?.uninterruptible);
	if (!fiber._exit) if (scope.state._tag !== "Closed") {
		const key = {};
		const finalizer = () => withFiberId((interruptor) => interruptor === fiber.id ? void_$2 : fiberInterrupt(fiber));
		scopeAddFinalizerUnsafe(scope, key, finalizer);
		fiber.addObserver(() => scopeRemoveFinalizerUnsafe(scope, key));
	} else fiber.interruptUnsafe(parent.id, fiberStackAnnotations(parent));
	return succeed$5(fiber);
}));
/** @internal */
var forkScoped$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => flatMap$2(scope$1, (scope) => forkIn$1(self, scope, options)));
/** @internal */
var runForkWith$1 = (services) => (effect, options) => {
	const scheduler = options?.scheduler || !services.mapUnsafe.has(Scheduler.key) && new MixedScheduler();
	const fiber = new FiberImpl(scheduler ? add$1(services, Scheduler, scheduler) : services, options?.uninterruptible !== true);
	fiber.evaluate(effect);
	if (fiber._exit) return fiber;
	if (options?.signal) if (options.signal.aborted) fiber.interruptUnsafe();
	else {
		const abort = () => fiber.interruptUnsafe();
		options.signal.addEventListener("abort", abort, { once: true });
		fiber.addObserver(() => options.signal.removeEventListener("abort", abort));
	}
	return fiber;
};
/** @internal */
var fiberRunIn = /*#__PURE__*/ dual(2, (self, scope) => {
	if (self._exit) return self;
	else if (scope.state._tag === "Closed") {
		self.interruptUnsafe(self.id);
		return self;
	}
	const key = {};
	scopeAddFinalizerUnsafe(scope, key, () => fiberInterrupt(self));
	self.addObserver(() => scopeRemoveFinalizerUnsafe(scope, key));
	return self;
});
/** @internal */
var runFork$1 = /*#__PURE__*/ runForkWith$1(/*#__PURE__*/ empty$3());
/** @internal */
var runCallbackWith$1 = (services) => {
	const runFork = runForkWith$1(services);
	return (effect, options) => {
		const fiber = runFork(effect, options);
		if (options?.onExit) fiber.addObserver(options.onExit);
		return (interruptor) => {
			return fiber.interruptUnsafe(interruptor);
		};
	};
};
/** @internal */
var runCallback$1 = /*#__PURE__*/ runCallbackWith$1(/*#__PURE__*/ empty$3());
/** @internal */
var runPromiseExitWith$1 = (services) => {
	const runFork = runForkWith$1(services);
	return (effect, options) => {
		const fiber = runFork(effect, options);
		return new Promise((resolve) => {
			fiber.addObserver((exit) => resolve(exit));
		});
	};
};
/** @internal */
var runPromiseExit$1 = /*#__PURE__*/ runPromiseExitWith$1(/*#__PURE__*/ empty$3());
/** @internal */
var runPromiseWith$1 = (services) => {
	const runPromiseExit = runPromiseExitWith$1(services);
	return (effect, options) => runPromiseExit(effect, options).then((exit) => {
		if (exit._tag === "Failure") throw causeSquash(exit.cause);
		return exit.value;
	});
};
/** @internal */
var runPromise$1 = /*#__PURE__*/ runPromiseWith$1(/*#__PURE__*/ empty$3());
/** @internal */
var runSyncExitWith$1 = (services) => {
	const runFork = runForkWith$1(services);
	return (effect) => {
		if (effectIsExit(effect)) return effect;
		const scheduler = new MixedScheduler("sync");
		const fiber = runFork(effect, { scheduler });
		scheduler.flush();
		return fiber._exit ?? exitDie(fiber);
	};
};
/** @internal */
var runSyncExit$1 = /*#__PURE__*/ runSyncExitWith$1(/*#__PURE__*/ empty$3());
/** @internal */
var runSyncWith$1 = (services) => {
	const runSyncExit = runSyncExitWith$1(services);
	return (effect) => {
		const exit = runSyncExit(effect);
		if (exit._tag === "Failure") throw causeSquash(exit.cause);
		return exit.value;
	};
};
/** @internal */
var runSync$1 = /*#__PURE__*/ runSyncWith$1(/*#__PURE__*/ empty$3());
/** @internal */
var Semaphore = class {
	waiters = /*#__PURE__*/ new Set();
	taken = 0;
	permits;
	constructor(permits) {
		this.permits = permits;
	}
	get free() {
		return this.permits - this.taken;
	}
	take = (n) => {
		const take = suspend$1(() => {
			if (this.free < n) return callback$1((resume) => {
				if (this.free >= n) return resume(take);
				const observer = () => {
					if (this.free < n) return;
					this.waiters.delete(observer);
					resume(take);
				};
				this.waiters.add(observer);
				return sync$3(() => {
					this.waiters.delete(observer);
				});
			});
			this.taken += n;
			return succeed$5(n);
		});
		return take;
	};
	updateTakenUnsafe(fiber, f) {
		this.taken = f(this.taken);
		if (this.waiters.size > 0) fiber.currentScheduler.scheduleTask(() => {
			const iter = this.waiters.values();
			let item = iter.next();
			while (item.done === false && this.free > 0) {
				item.value();
				item = iter.next();
			}
		}, 0);
		return succeed$5(this.free);
	}
	updateTaken(f) {
		return withFiber$1((fiber) => this.updateTakenUnsafe(fiber, f));
	}
	resize = (permits) => asVoid$2(withFiber$1((fiber) => {
		this.permits = permits;
		if (this.free < 0) return void_$2;
		return this.updateTakenUnsafe(fiber, (taken) => taken);
	}));
	release = (n) => this.updateTaken((taken) => taken - n);
	releaseAll = /*#__PURE__*/ this.updateTaken((_) => 0);
	withPermits = (n) => (self) => uninterruptibleMask$1((restore) => flatMap$2(restore(this.take(n)), (permits) => onExitPrimitive$1(restore(self), () => this.release(permits), true)));
	withPermit = /*#__PURE__*/ this.withPermits(1);
	withPermitsIfAvailable = (n) => (self) => uninterruptibleMask$1((restore) => suspend$1(() => {
		if (this.free < n) return succeedNone$1;
		this.taken += n;
		return ensuring$1(restore(asSome$1(self)), this.release(n));
	}));
};
/** @internal */
var makeSemaphoreUnsafe = (permits) => new Semaphore(permits);
/** @internal */
var makeSemaphore = (permits) => sync$3(() => makeSemaphoreUnsafe(permits));
var succeedTrue = /*#__PURE__*/ succeed$5(true);
var succeedFalse = /*#__PURE__*/ succeed$5(false);
var Latch = class {
	waiters = [];
	scheduled = false;
	isOpen;
	constructor(isOpen) {
		this.isOpen = isOpen;
	}
	scheduleUnsafe(fiber) {
		if (this.scheduled || this.waiters.length === 0) return succeedTrue;
		this.scheduled = true;
		fiber.currentScheduler.scheduleTask(this.flushWaiters, 0);
		return succeedTrue;
	}
	flushWaiters = () => {
		this.scheduled = false;
		const waiters = this.waiters;
		this.waiters = [];
		for (let i = 0; i < waiters.length; i++) waiters[i](exitVoid);
	};
	open = /*#__PURE__*/ withFiber$1((fiber) => {
		if (this.isOpen) return succeedFalse;
		this.isOpen = true;
		return this.scheduleUnsafe(fiber);
	});
	release = /*#__PURE__*/ withFiber$1((fiber) => this.open ? succeedFalse : this.scheduleUnsafe(fiber));
	openUnsafe() {
		if (this.isOpen) return false;
		this.isOpen = true;
		this.flushWaiters();
		return true;
	}
	await = /*#__PURE__*/ callback$1((resume) => {
		if (this.isOpen) return resume(void_$2);
		this.waiters.push(resume);
		return sync$3(() => {
			const index = this.waiters.indexOf(resume);
			if (index !== -1) this.waiters.splice(index, 1);
		});
	});
	closeUnsafe() {
		if (!this.isOpen) return false;
		this.isOpen = false;
		return true;
	}
	close = /*#__PURE__*/ sync$3(() => this.closeUnsafe());
	whenOpen = (self) => andThen$2(this.await, self);
};
/** @internal */
var makeLatchUnsafe = (open) => new Latch(open ?? false);
/** @internal */
var makeLatch = (open) => sync$3(() => makeLatchUnsafe(open));
/** @internal */
var tracer$1 = /*#__PURE__*/ withFiber$1((fiber) => succeed$5(fiber.getRef(Tracer)));
/** @internal */
var withTracer$1 = /*#__PURE__*/ dual(2, (effect, tracer) => provideService$1(effect, Tracer, tracer));
/** @internal */
var withTracerEnabled$1 = /*#__PURE__*/ provideService$1(TracerEnabled);
/** @internal */
var withTracerTiming$1 = /*#__PURE__*/ provideService$1(TracerTimingEnabled);
var bigint0$1 = /*#__PURE__*/ BigInt(0);
var NoopSpanProto = {
	_tag: "Span",
	spanId: "noop",
	traceId: "noop",
	sampled: false,
	status: {
		_tag: "Ended",
		startTime: bigint0$1,
		endTime: bigint0$1,
		exit: exitVoid
	},
	attributes: /*#__PURE__*/ new Map(),
	links: [],
	kind: "internal",
	attribute() {},
	event() {},
	end() {},
	addLinks() {}
};
/** @internal */
var noopSpan = (options) => Object.assign(Object.create(NoopSpanProto), options);
var filterDisablePropagation = (span) => {
	if (span) return get(span.annotations, DisablePropagation) ? span._tag === "Span" ? filterDisablePropagation(span.parent) : void 0 : span;
};
/** @internal */
var makeSpanUnsafe = (fiber, name, options) => {
	const disablePropagation = !fiber.getRef(TracerEnabled) || options?.annotations && get(options.annotations, DisablePropagation);
	const parent = options?.parent ?? (options?.root ? void 0 : filterDisablePropagation(fiber.currentSpan));
	let span;
	if (disablePropagation) span = noopSpan({
		name,
		parent,
		annotations: add$1(options?.annotations ?? empty$3(), DisablePropagation, true)
	});
	else {
		const tracer = fiber.getRef(Tracer);
		const clock = fiber.getRef(ClockRef);
		const timingEnabled = fiber.getRef(TracerTimingEnabled);
		const annotationsFromEnv = fiber.getRef(TracerSpanAnnotations);
		const linksFromEnv = fiber.getRef(TracerSpanLinks);
		const level = options?.level ?? fiber.getRef(CurrentTraceLevel);
		const links = options?.links !== void 0 ? [...linksFromEnv, ...options.links] : linksFromEnv.slice();
		span = tracer.span({
			name,
			parent,
			annotations: options?.annotations ?? empty$3(),
			links,
			startTime: timingEnabled ? clock.currentTimeNanosUnsafe() : 0n,
			kind: options?.kind ?? "internal",
			root: options?.root ?? options?.parent === void 0,
			sampled: options?.sampled ?? (parent?.sampled === false ? false : !isLogLevelGreaterThan(fiber.getRef(MinimumTraceLevel), level))
		});
		for (const [key, value] of Object.entries(annotationsFromEnv)) span.attribute(key, value);
		if (options?.attributes !== void 0) for (const [key, value] of Object.entries(options.attributes)) span.attribute(key, value);
	}
	return span;
};
/** @internal */
var makeSpan$1 = (name, options) => withFiber$1((fiber) => succeed$5(makeSpanUnsafe(fiber, name, options)));
/** @internal */
var makeSpanScoped$1 = (name, options) => uninterruptible$1(withFiber$1((fiber) => {
	const scope = getUnsafe(fiber.services, scopeTag);
	const span = makeSpanUnsafe(fiber, name, options ?? {});
	const clock = fiber.getRef(ClockRef);
	const timingEnabled = fiber.getRef(TracerTimingEnabled);
	return as$1(scopeAddFinalizerExit(scope, (exit) => endSpan(span, exit, clock, timingEnabled)), span);
}));
/** @internal */
var withSpanScoped$1 = function() {
	const dataFirst = typeof arguments[0] !== "string";
	const name = dataFirst ? arguments[1] : arguments[0];
	const options = addSpanStackTrace(dataFirst ? arguments[2] : arguments[1]);
	if (dataFirst) {
		const self = arguments[0];
		return flatMap$2(makeSpanScoped$1(name, options), (span) => withParentSpan$2(self, span, options));
	}
	return (self) => flatMap$2(makeSpanScoped$1(name, options), (span) => withParentSpan$2(self, span, options));
};
var provideSpanStackFrame$1 = (name, stack) => {
	stack = typeof stack === "function" ? stack : constUndefined;
	return updateService$2(CurrentStackFrame, (parent) => ({
		name,
		stack,
		parent
	}));
};
/** @internal */
var spanAnnotations$1 = /*#__PURE__*/ TracerSpanAnnotations.asEffect();
/** @internal */
var spanLinks$1 = /*#__PURE__*/ TracerSpanLinks.asEffect();
/** @internal */
var linkSpans$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, span, attributes = {}) => {
	const links = (Array.isArray(span) ? span : [span]).map((span) => ({
		span,
		attributes
	}));
	return updateService$2(self, TracerSpanLinks, (current) => [...current, ...links]);
});
/** @internal */
var endSpan = (span, exit, clock, timingEnabled) => sync$3(() => {
	if (span.status._tag === "Ended") return;
	span.end(timingEnabled ? clock.currentTimeNanosUnsafe() : bigint0$1, exit);
});
/** @internal */
var useSpan$1 = (name, ...args) => {
	const options = args.length === 1 ? void 0 : args[0];
	const evaluate = args[args.length - 1];
	return withFiber$1((fiber) => {
		const span = makeSpanUnsafe(fiber, name, options);
		const clock = fiber.getRef(ClockRef);
		return onExit$1(internalCall(() => evaluate(span)), (exit) => sync$3(() => {
			if (span.status._tag === "Ended") return;
			span.end(clock.currentTimeNanosUnsafe(), exit);
		}));
	});
};
var provideParentSpan = /*#__PURE__*/ provideService$1(ParentSpan);
/** @internal */
var withParentSpan$2 = function() {
	const dataFirst = isEffect$1(arguments[0]);
	const span = dataFirst ? arguments[1] : arguments[0];
	let options = dataFirst ? arguments[2] : arguments[1];
	let provideStackFrame = identity;
	if (span._tag === "Span") {
		options = addSpanStackTrace(options);
		provideStackFrame = provideSpanStackFrame$1(span.name, options?.captureStackTrace);
	}
	if (dataFirst) return provideParentSpan(provideStackFrame(arguments[0]), span);
	return (self) => provideParentSpan(provideStackFrame(self), span);
};
/** @internal */
var withSpan$2 = function() {
	const dataFirst = typeof arguments[0] !== "string";
	const name = dataFirst ? arguments[1] : arguments[0];
	const traceOptions = addSpanStackTrace(arguments[2]);
	if (dataFirst) {
		const self = arguments[0];
		return useSpan$1(name, arguments[2], (span) => withParentSpan$2(self, span, traceOptions));
	}
	const fnArg = typeof arguments[1] === "function" ? arguments[1] : void 0;
	const options = fnArg ? void 0 : arguments[1];
	return (self, ...args) => useSpan$1(name, fnArg ? fnArg(...args) : options, (span) => withParentSpan$2(self, span, traceOptions));
};
/** @internal */
var annotateSpans$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (effect, ...args) => updateService$2(effect, TracerSpanAnnotations, (annotations) => {
	const newAnnotations = { ...annotations };
	if (args.length === 1) Object.assign(newAnnotations, args[0]);
	else newAnnotations[args[0]] = args[1];
	return newAnnotations;
}));
/** @internal */
var annotateCurrentSpan$1 = (...args) => withFiber$1((fiber) => {
	const span = fiber.currentSpanLocal;
	if (span) if (args.length === 1) for (const [key, value] of Object.entries(args[0])) span.attribute(key, value);
	else span.attribute(args[0], args[1]);
	return void_$2;
});
/** @internal */
var currentSpan$1 = /*#__PURE__*/ withFiber$1((fiber) => {
	const span = fiber.currentSpanLocal;
	return span ? succeed$5(span) : fail$5(new NoSuchElementError$1());
});
/** @internal */
var currentParentSpan$1 = /*#__PURE__*/ serviceOptional(ParentSpan);
/** @internal */
var ClockRef = /*#__PURE__*/ Reference("effect/Clock", { defaultValue: () => new ClockImpl() });
var MAX_TIMER_MILLIS = 2 ** 31 - 1;
var ClockImpl = class {
	currentTimeMillisUnsafe() {
		return Date.now();
	}
	currentTimeMillis = /*#__PURE__*/ sync$3(() => this.currentTimeMillisUnsafe());
	currentTimeNanosUnsafe() {
		return processOrPerformanceNow();
	}
	currentTimeNanos = /*#__PURE__*/ sync$3(() => this.currentTimeNanosUnsafe());
	sleep(duration) {
		const millis = toMillis(duration);
		if (millis <= 0) return yieldNow$1;
		return callback$1((resume) => {
			if (millis > MAX_TIMER_MILLIS) return;
			const handle = setTimeout(() => resume(void_$2), millis);
			return sync$3(() => clearTimeout(handle));
		});
	}
};
var performanceNowNanos = /*#__PURE__*/ function() {
	const bigint1e6 = /*#__PURE__*/ BigInt(1e6);
	if (typeof performance === "undefined" || typeof performance.now === "undefined") return () => BigInt(Date.now()) * bigint1e6;
	else if (typeof performance.timeOrigin === "number" && performance.timeOrigin === 0) return () => BigInt(Math.round(performance.now() * 1e6));
	const origin = /*#__PURE__*/ BigInt(/*#__PURE__*/ Date.now()) * bigint1e6 - /*#__PURE__*/ BigInt(/*#__PURE__*/ Math.round(/*#__PURE__*/ performance.now() * 1e6));
	return () => origin + BigInt(Math.round(performance.now() * 1e6));
}();
var processOrPerformanceNow = /*#__PURE__*/ function() {
	const processHrtime = typeof process === "object" && "hrtime" in process && typeof process.hrtime.bigint === "function" ? process.hrtime : void 0;
	if (!processHrtime) return performanceNowNanos;
	const origin = /*#__PURE__*/ performanceNowNanos() - /*#__PURE__*/ processHrtime.bigint();
	return () => origin + processHrtime.bigint();
}();
/** @internal */
var clockWith$2 = (f) => withFiber$1((fiber) => f(fiber.getRef(ClockRef)));
/** @internal */
var sleep$1 = (duration) => clockWith$2((clock) => clock.sleep(fromInputUnsafe(duration)));
/** @internal */
var currentTimeMillis$1 = /*#__PURE__*/ clockWith$2((clock) => clock.currentTimeMillis);
/** @internal */
var currentTimeNanos$1 = /*#__PURE__*/ clockWith$2((clock) => clock.currentTimeNanos);
/** @internal */
var TimeoutErrorTypeId$1 = "~effect/Cause/TimeoutError";
/** @internal */
var isTimeoutError$1 = (u) => hasProperty(u, TimeoutErrorTypeId$1);
/** @internal */
var TimeoutError$1 = class extends TaggedError$1("TimeoutError") {
	[TimeoutErrorTypeId$1] = TimeoutErrorTypeId$1;
	constructor(message) {
		super({ message });
	}
};
/** @internal */
var IllegalArgumentErrorTypeId$1 = "~effect/Cause/IllegalArgumentError";
/** @internal */
var isIllegalArgumentError$1 = (u) => hasProperty(u, IllegalArgumentErrorTypeId$1);
/** @internal */
var IllegalArgumentError$1 = class extends TaggedError$1("IllegalArgumentError") {
	[IllegalArgumentErrorTypeId$1] = IllegalArgumentErrorTypeId$1;
	constructor(message) {
		super({ message });
	}
};
/** @internal */
var ExceededCapacityErrorTypeId$1 = "~effect/Cause/ExceededCapacityError";
/** @internal */
var isExceededCapacityError$1 = (u) => hasProperty(u, ExceededCapacityErrorTypeId$1);
/** @internal */
var ExceededCapacityError$1 = class extends TaggedError$1("ExceededCapacityError") {
	[ExceededCapacityErrorTypeId$1] = ExceededCapacityErrorTypeId$1;
	constructor(message) {
		super({ message });
	}
};
/** @internal */
var UnknownErrorTypeId$1 = "~effect/Cause/UnknownError";
/** @internal */
var isUnknownError$1 = (u) => hasProperty(u, UnknownErrorTypeId$1);
/** @internal */
var UnknownError$1 = class extends TaggedError$1("UnknownError") {
	[UnknownErrorTypeId$1] = UnknownErrorTypeId$1;
	constructor(cause, message) {
		super({
			message,
			cause
		});
	}
};
/** @internal */
var ConsoleRef = /*#__PURE__*/ Reference("effect/Console/CurrentConsole", { defaultValue: () => globalThis.console });
/** @internal */
var logLevelToOrder = (level) => {
	switch (level) {
		case "All": return Number.MIN_SAFE_INTEGER;
		case "Fatal": return 5e4;
		case "Error": return 4e4;
		case "Warn": return 3e4;
		case "Info": return 2e4;
		case "Debug": return 1e4;
		case "Trace": return 0;
		case "None": return Number.MAX_SAFE_INTEGER;
	}
};
/** @internal */
var LogLevelOrder = /*#__PURE__*/ mapInput$1(Number$2, logLevelToOrder);
/** @internal */
var isLogLevelGreaterThan = /*#__PURE__*/ isGreaterThan$3(LogLevelOrder);
/** @internal */
var CurrentLoggers = /*#__PURE__*/ Reference("effect/Loggers/CurrentLoggers", { defaultValue: () => /* @__PURE__ */ new Set([defaultLogger, tracerLogger]) });
/** @internal */
var LogToStderr = /*#__PURE__*/ Reference("effect/Logger/LogToStderr", { defaultValue: constFalse });
/** @internal */
var annotateLogsScoped$1 = function() {
	const entries = typeof arguments[0] === "string" ? [[arguments[0], arguments[1]]] : Object.entries(arguments[0]);
	return uninterruptible$1(withFiber$1((fiber) => {
		const prev = fiber.getRef(CurrentLogAnnotations);
		const next = { ...prev };
		for (let i = 0; i < entries.length; i++) {
			const [key, value] = entries[i];
			next[key] = value;
		}
		fiber.setServices(add$1(fiber.services, CurrentLogAnnotations, next));
		return scopeAddFinalizerExit(getUnsafe(fiber.services, scopeTag), (_) => {
			const current = fiber.getRef(CurrentLogAnnotations);
			const next = { ...current };
			for (let i = 0; i < entries.length; i++) {
				const [key, value] = entries[i];
				if (current[key] !== value) continue;
				if (key in prev) next[key] = prev[key];
				else delete next[key];
			}
			fiber.setServices(add$1(fiber.services, CurrentLogAnnotations, next));
			return void_$2;
		});
	}));
};
var LoggerProto = {
	["~effect/Logger"]: {
		_Message: identity,
		_Output: identity
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/** @internal */
var loggerMake = (log) => {
	const self = Object.create(LoggerProto);
	self.log = log;
	return self;
};
/**
* Sanitize a given string by replacing spaces, equal signs, and double quotes
* with underscores.
*
* @internal
*/
var formatLabel = (key) => key.replace(/[\s="]/g, "_");
/**
* Formats a log span into a `<label>=<value>ms` string.
*
* @internal
*/
var formatLogSpan = (self, now) => {
	return `${formatLabel(self[0])}=${now - self[1]}ms`;
};
/** @internal */
var structuredMessage = (u) => {
	switch (typeof u) {
		case "bigint":
		case "function":
		case "symbol": return String(u);
		default: return toJson(u);
	}
};
/** @internal */
var logWithLevel$1 = (level) => (...message) => {
	let cause = void 0;
	for (let i = 0, len = message.length; i < len; i++) {
		const msg = message[i];
		if (isCause$1(msg)) {
			if (cause) message.splice(i, 1);
			else message = message.slice(0, i).concat(message.slice(i + 1));
			cause = cause ? causeFromReasons(cause.reasons.concat(msg.reasons)) : msg;
			i--;
		}
	}
	if (cause === void 0) cause = causeEmpty;
	return withFiber$1((fiber) => {
		const logLevel = level ?? fiber.currentLogLevel;
		if (isLogLevelGreaterThan(fiber.minimumLogLevel, logLevel)) return void_$2;
		const clock = fiber.getRef(ClockRef);
		const loggers = fiber.getRef(CurrentLoggers);
		if (loggers.size > 0) {
			const date = new Date(clock.currentTimeMillisUnsafe());
			for (const logger of loggers) logger.log({
				cause,
				fiber,
				date,
				logLevel,
				message
			});
		}
		return void_$2;
	});
};
var withColor = (text, ...colors) => {
	let out = "";
	for (let i = 0; i < colors.length; i++) out += `\x1b[${colors[i]}m`;
	return out + text + "\x1B[0m";
};
var withColorNoop = (text, ..._colors) => text;
var colors = {
	bold: "1",
	red: "31",
	green: "32",
	yellow: "33",
	blue: "34",
	cyan: "36",
	white: "37",
	gray: "90",
	black: "30",
	bgBrightRed: "101"
};
var logLevelColors = {
	None: [],
	All: [],
	Trace: [colors.gray],
	Debug: [colors.blue],
	Info: [colors.green],
	Warn: [colors.yellow],
	Error: [colors.red],
	Fatal: [colors.bgBrightRed, colors.black]
};
var logLevelStyle = {
	None: "",
	All: "",
	Trace: "color:gray",
	Debug: "color:blue",
	Info: "color:green",
	Warn: "color:orange",
	Error: "color:red",
	Fatal: "background-color:red;color:white"
};
var defaultDateFormat = (date) => `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}:${date.getSeconds().toString().padStart(2, "0")}.${date.getMilliseconds().toString().padStart(3, "0")}`;
var hasProcessStdout = typeof process === "object" && process !== null && typeof process.stdout === "object" && process.stdout !== null;
var processStdoutIsTTY = hasProcessStdout && process.stdout.isTTY === true;
var hasProcessStdoutOrDeno = hasProcessStdout || "Deno" in globalThis;
/** @internal */
var consolePretty = (options) => {
	const mode_ = options?.mode ?? "auto";
	const isBrowser = (mode_ === "auto" ? hasProcessStdoutOrDeno ? "tty" : "browser" : mode_) === "browser";
	const showColors = typeof options?.colors === "boolean" ? options.colors : processStdoutIsTTY || isBrowser;
	const formatDate = options?.formatDate ?? defaultDateFormat;
	return isBrowser ? prettyLoggerBrowser({
		colors: showColors,
		formatDate
	}) : prettyLoggerTty({
		colors: showColors,
		formatDate
	});
};
var prettyLoggerTty = (options) => {
	const processIsBun = typeof process === "object" && "isBun" in process && process.isBun === true;
	const color = options.colors && processStdoutIsTTY ? withColor : withColorNoop;
	return loggerMake(({ cause, date, fiber, logLevel, message: message_ }) => {
		const console = fiber.getRef(ConsoleRef);
		const log = fiber.getRef(LogToStderr) ? console.error : console.log;
		const message = Array.isArray(message_) ? message_.slice() : [message_];
		let firstLine = color(`[${options.formatDate(date)}]`, colors.white) + ` ${color(logLevel.toUpperCase(), ...logLevelColors[logLevel])} (#${fiber.id})`;
		const now = date.getTime();
		const spans = fiber.getRef(CurrentLogSpans);
		for (const span of spans) firstLine += " " + formatLogSpan(span, now);
		firstLine += ":";
		let messageIndex = 0;
		if (message.length > 0) {
			const firstMaybeString = structuredMessage(message[0]);
			if (typeof firstMaybeString === "string") {
				firstLine += " " + color(firstMaybeString, colors.bold, colors.cyan);
				messageIndex++;
			}
		}
		log(firstLine);
		if (!processIsBun) console.group();
		if (cause.reasons.length > 0) log(causePretty(cause));
		if (messageIndex < message.length) for (; messageIndex < message.length; messageIndex++) log(redact(message[messageIndex]));
		const annotations = fiber.getRef(CurrentLogAnnotations);
		for (const [key, value] of Object.entries(annotations)) log(color(`${key}:`, colors.bold, colors.white), redact(value));
		if (!processIsBun) console.groupEnd();
	});
};
var prettyLoggerBrowser = (options) => {
	const color = options.colors ? "%c" : "";
	return loggerMake(({ cause, date, fiber, logLevel, message: message_ }) => {
		const console = fiber.getRef(ConsoleRef);
		const message = Array.isArray(message_) ? message_.slice() : [message_];
		let firstLine = `${color}[${options.formatDate(date)}]`;
		const firstParams = [];
		if (options.colors) firstParams.push("color:gray");
		firstLine += ` ${color}${logLevel.toUpperCase()}${color} (#${fiber.id})`;
		if (options.colors) firstParams.push(logLevelStyle[logLevel], "");
		const now = date.getTime();
		const spans = fiber.getRef(CurrentLogSpans);
		for (const span of spans) firstLine += " " + formatLogSpan(span, now);
		firstLine += ":";
		let messageIndex = 0;
		if (message.length > 0) {
			const firstMaybeString = structuredMessage(message[0]);
			if (typeof firstMaybeString === "string") {
				firstLine += ` ${color}${firstMaybeString}`;
				if (options.colors) firstParams.push("color:deepskyblue");
				messageIndex++;
			}
		}
		console.groupCollapsed(firstLine, ...firstParams);
		if (cause.reasons.length > 0) console.error(causePretty(cause));
		if (messageIndex < message.length) for (; messageIndex < message.length; messageIndex++) console.log(redact(message[messageIndex]));
		const annotations = fiber.getRef(CurrentLogAnnotations);
		for (const [key, value] of Object.entries(annotations)) {
			const redacted = redact(value);
			if (options.colors) console.log(`%c${key}:`, "color:gray", redacted);
			else console.log(`${key}:`, redacted);
		}
		console.groupEnd();
	});
};
/** @internal */
var defaultLogger = /*#__PURE__*/ loggerMake(({ cause, date, fiber, logLevel, message }) => {
	const message_ = Array.isArray(message) ? message.slice() : [message];
	if (cause.reasons.length > 0) message_.unshift(causePretty(cause));
	const now = date.getTime();
	const spans = fiber.getRef(CurrentLogSpans);
	let spanString = "";
	for (const span of spans) spanString += ` ${formatLogSpan(span, now)}`;
	const annotations = fiber.getRef(CurrentLogAnnotations);
	if (Object.keys(annotations).length > 0) message_.push(annotations);
	const console = fiber.getRef(ConsoleRef);
	(fiber.getRef(LogToStderr) ? console.error : console.log)(`[${defaultDateFormat(date)}] ${logLevel.toUpperCase()} (#${fiber.id})${spanString}:`, ...message_);
});
/** @internal */
var tracerLogger = /*#__PURE__*/ loggerMake(({ cause, fiber, logLevel, message }) => {
	const clock = fiber.getRef(ClockRef);
	const annotations = fiber.getRef(CurrentLogAnnotations);
	const span = fiber.currentSpan;
	if (span === void 0 || span._tag === "ExternalSpan") return;
	const attributes = {};
	for (const [key, value] of Object.entries(annotations)) attributes[key] = value;
	attributes["effect.fiberId"] = fiber.id;
	attributes["effect.logLevel"] = logLevel.toUpperCase();
	if (cause.reasons.length > 0) attributes["effect.cause"] = causePretty(cause);
	span.event(toStringUnknown(Array.isArray(message) && message.length === 1 ? message[0] : message), clock.currentTimeNanosUnsafe(), attributes);
});
/** @internal */
function interruptChildrenPatch() {
	fiberMiddleware.interruptChildren ??= fiberInterruptChildren;
}
/** @internal */
var undefined_$1 = /*#__PURE__*/ succeed$5(void 0);
/** @internal */
var CurrentErrorReporters = /*#__PURE__*/ Reference("effect/ErrorReporter/CurrentErrorReporters", { defaultValue: () => /* @__PURE__ */ new Set() });
/** @internal */
var withErrorReporting$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, options) => onError$1(self, (cause) => withFiber$1((fiber) => {
	reportCauseUnsafe(fiber, cause, options?.defectsOnly);
	return void_$2;
})));
/** @internal */
var reportCauseUnsafe = (fiber, cause, defectsOnly) => {
	const reporters = fiber.getRef(CurrentErrorReporters);
	if (reporters.size === 0) return;
	if (defectsOnly && !hasDies$2(cause)) return;
	const opts = {
		cause,
		fiber,
		timestamp: fiber.getRef(ClockRef).currentTimeNanosUnsafe()
	};
	reporters.forEach((reporter) => reporter.report(opts));
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Cause.js
var Cause_exports = /* @__PURE__ */ __exportAll({
	Done: () => Done,
	DoneTypeId: () => DoneTypeId,
	ExceededCapacityError: () => ExceededCapacityError,
	ExceededCapacityErrorTypeId: () => ExceededCapacityErrorTypeId,
	IllegalArgumentError: () => IllegalArgumentError,
	IllegalArgumentErrorTypeId: () => IllegalArgumentErrorTypeId,
	InterruptorStackTrace: () => InterruptorStackTrace,
	NoSuchElementError: () => NoSuchElementError,
	NoSuchElementErrorTypeId: () => NoSuchElementErrorTypeId,
	ReasonTypeId: () => ReasonTypeId,
	StackTrace: () => StackTrace,
	TimeoutError: () => TimeoutError,
	TimeoutErrorTypeId: () => TimeoutErrorTypeId,
	TypeId: () => TypeId$8,
	UnknownError: () => UnknownError,
	UnknownErrorTypeId: () => UnknownErrorTypeId,
	annotate: () => annotate,
	annotations: () => annotations,
	combine: () => combine,
	die: () => die$3,
	done: () => done$1,
	empty: () => empty$2,
	fail: () => fail$4,
	filterInterruptors: () => filterInterruptors,
	findDefect: () => findDefect$1,
	findDie: () => findDie,
	findError: () => findError$1,
	findErrorOption: () => findErrorOption$1,
	findFail: () => findFail,
	findInterrupt: () => findInterrupt,
	fromReasons: () => fromReasons,
	hasDies: () => hasDies$1,
	hasFails: () => hasFails$1,
	hasInterrupts: () => hasInterrupts$1,
	hasInterruptsOnly: () => hasInterruptsOnly,
	interrupt: () => interrupt$3,
	interruptors: () => interruptors,
	isCause: () => isCause,
	isDieReason: () => isDieReason,
	isDone: () => isDone$1,
	isExceededCapacityError: () => isExceededCapacityError,
	isFailReason: () => isFailReason,
	isIllegalArgumentError: () => isIllegalArgumentError,
	isInterruptReason: () => isInterruptReason,
	isNoSuchElementError: () => isNoSuchElementError,
	isReason: () => isReason,
	isTimeoutError: () => isTimeoutError,
	isUnknownError: () => isUnknownError,
	makeDieReason: () => makeDieReason,
	makeFailReason: () => makeFailReason,
	makeInterruptReason: () => makeInterruptReason,
	map: () => map$3,
	pretty: () => pretty,
	prettyErrors: () => prettyErrors,
	reasonAnnotations: () => reasonAnnotations,
	squash: () => squash
});
/**
* Unique brand for `Cause` values, used for runtime type checks via {@link isCause}.
*
* @since 2.0.0
* @category symbols
*/
var TypeId$8 = CauseTypeId;
/**
* Unique brand for `Reason` values, used for runtime type checks via {@link isReason}.
*
* @since 2.0.0
* @category symbols
*/
var ReasonTypeId = CauseReasonTypeId;
/**
* Tests if an arbitrary value is a {@link Cause}.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isCause(Cause.fail("error"))) // true
* console.log(Cause.isCause("not a cause")) // false
* ```
*
* @category guards
* @since 2.0.0
*/
var isCause = isCause$1;
/**
* Tests if an arbitrary value is a {@link Reason} (`Fail`, `Die`, or `Interrupt`).
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* const reason = Cause.fail("error").reasons[0]
* console.log(Cause.isReason(reason)) // true
* console.log(Cause.isReason("not a reason")) // false
* ```
*
* @category guards
* @since 2.0.0
*/
var isReason = isCauseReason;
/**
* Narrows a {@link Reason} to {@link Fail}.
*
* Useful as a predicate for `Array.filter` when iterating over `cause.reasons`.
*
* **Example** (filtering fail reasons)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.fail("error")
* const fails = cause.reasons.filter(Cause.isFailReason)
* console.log(fails[0].error) // "error"
* ```
*
* @see {@link isDieReason} — narrow to `Die`
* @see {@link isInterruptReason} — narrow to `Interrupt`
*
* @category guards
* @since 4.0.0
*/
var isFailReason = isFailReason$1;
/**
* Narrows a {@link Reason} to {@link Die}.
*
* Useful as a predicate for `Array.filter` when iterating over `cause.reasons`.
*
* **Example** (filtering die reasons)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.die("defect")
* const dies = cause.reasons.filter(Cause.isDieReason)
* console.log(dies[0].defect) // "defect"
* ```
*
* @see {@link isFailReason} — narrow to `Fail`
* @see {@link isInterruptReason} — narrow to `Interrupt`
*
* @category guards
* @since 4.0.0
*/
var isDieReason = isDieReason$1;
/**
* Narrows a {@link Reason} to {@link Interrupt}.
*
* Useful as a predicate for `Array.filter` when iterating over `cause.reasons`.
*
* **Example** (filtering interrupt reasons)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.interrupt(123)
* const interrupts = cause.reasons.filter(Cause.isInterruptReason)
* console.log(interrupts[0].fiberId) // 123
* ```
*
* @see {@link isFailReason} — narrow to `Fail`
* @see {@link isDieReason} — narrow to `Die`
*
* @category guards
* @since 4.0.0
*/
var isInterruptReason = isInterruptReason$1;
/**
* Creates a {@link Cause} from an array of {@link Reason} values.
*
* Use this when you already have individual reasons (e.g. from filtering or
* transforming another cause's `reasons` array) and need to wrap them back
* into a `Cause`.
*
* - Returns a new `Cause`; does not mutate the input array.
* - An empty array produces a cause equivalent to {@link empty}.
*
* **Example** (building a cause from reasons)
*
* ```ts
* import { Cause } from "effect"
*
* const reasons = [
*   Cause.makeFailReason("err1"),
*   Cause.makeFailReason("err2")
* ]
* const cause = Cause.fromReasons(reasons)
* console.log(cause.reasons.length) // 2
* ```
*
* @see {@link combine} — merge two existing causes
*
* @category constructors
* @since 2.0.0
*/
var fromReasons = causeFromReasons;
/**
* A {@link Cause} with an empty `reasons` array.
*
* Represents the absence of failure. Combining any cause with `empty` via
* {@link combine} returns the original cause unchanged.
*
* @see {@link combine}
*
* @category constructors
* @since 2.0.0
*/
var empty$2 = causeEmpty;
/**
* Creates a {@link Cause} containing a single {@link Fail} reason with the
* given typed error.
*
* **Example** (creating a fail cause)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.fail("Something went wrong")
* console.log(cause.reasons.length) // 1
* console.log(Cause.isFailReason(cause.reasons[0])) // true
* ```
*
* @see {@link die} — for untyped defects
* @see {@link interrupt} — for fiber interruptions
*
* @category constructors
* @since 2.0.0
*/
var fail$4 = causeFail;
/**
* Creates a {@link Cause} containing a single {@link Die} reason with the
* given defect.
*
* **Example** (creating a die cause)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.die(new Error("Unexpected"))
* console.log(cause.reasons.length) // 1
* console.log(Cause.isDieReason(cause.reasons[0])) // true
* ```
*
* @see {@link fail} — for typed errors
* @see {@link interrupt} — for fiber interruptions
*
* @category constructors
* @since 2.0.0
*/
var die$3 = causeDie;
/**
* Creates a {@link Cause} containing a single {@link Interrupt} reason,
* optionally carrying the interrupting fiber's ID.
*
* **Example** (creating an interrupt cause)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.interrupt(123)
* console.log(cause.reasons.length) // 1
* console.log(Cause.isInterruptReason(cause.reasons[0])) // true
* ```
*
* @see {@link fail} — for typed errors
* @see {@link die} — for untyped defects
*
* @category constructors
* @since 2.0.0
*/
var interrupt$3 = causeInterrupt;
/**
* Creates a standalone {@link Fail} reason (not wrapped in a {@link Cause}).
*
* Use this when you need to construct individual reasons for
* {@link fromReasons} or for direct comparison.
*
* **Example** (creating a Fail reason)
*
* ```ts
* import { Cause } from "effect"
*
* const reason = Cause.makeFailReason("error")
* console.log(reason._tag) // "Fail"
* console.log(reason.error) // "error"
* ```
*
* @see {@link makeDieReason} — create a `Die` reason
* @see {@link makeInterruptReason} — create an `Interrupt` reason
*
* @category constructors
* @since 4.0.0
*/
var makeFailReason = (error) => new Fail(error);
/**
* Creates a standalone {@link Die} reason (not wrapped in a {@link Cause}).
*
* **Example** (creating a Die reason)
*
* ```ts
* import { Cause } from "effect"
*
* const reason = Cause.makeDieReason(new Error("bug"))
* console.log(reason._tag) // "Die"
* ```
*
* @see {@link makeFailReason} — create a `Fail` reason
* @see {@link makeInterruptReason} — create an `Interrupt` reason
*
* @category constructors
* @since 4.0.0
*/
var makeDieReason = (defect) => new Die(defect);
/**
* Creates a standalone {@link Interrupt} reason (not wrapped in a {@link Cause}),
* optionally carrying the interrupting fiber's ID.
*
* **Example** (creating an Interrupt reason)
*
* ```ts
* import { Cause } from "effect"
*
* const reason = Cause.makeInterruptReason(42)
* console.log(reason._tag) // "Interrupt"
* console.log(reason.fiberId) // 42
* ```
*
* @see {@link makeFailReason} — create a `Fail` reason
* @see {@link makeDieReason} — create a `Die` reason
*
* @category constructors
* @since 4.0.0
*/
var makeInterruptReason = makeInterruptReason$1;
/**
* Returns `true` if every reason in the cause is an {@link Interrupt} (and
* there is at least one reason).
*
* Useful for deciding whether a failure was entirely due to interruption and
* can be silently discarded.
*
* **Example** (checking interrupt-only causes)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.hasInterruptsOnly(Cause.interrupt(123))) // true
* console.log(Cause.hasInterruptsOnly(Cause.fail("error")))  // false
* console.log(Cause.hasInterruptsOnly(Cause.empty))          // false
* ```
*
* @see {@link hasInterrupts} — `true` if the cause contains *any* interrupts
*
* @category predicates
* @since 2.0.0
*/
var hasInterruptsOnly = hasInterruptsOnly$1;
/**
* Transforms the typed error values inside a {@link Cause} using the
* provided function. Only {@link Fail} reasons are affected; {@link Die}
* and {@link Interrupt} reasons pass through unchanged.
*
* Returns a new `Cause`; does not mutate the original.
*
* **Example** (mapping errors to uppercase)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.fail("error")
* const mapped = Cause.map(cause, (e) => e.toUpperCase())
* const reason = mapped.reasons[0]
* if (Cause.isFailReason(reason)) {
*   console.log(reason.error) // "ERROR"
* }
* ```
*
* @category mapping
* @since 4.0.0
*/
var map$3 = causeMap;
/**
* Merges two causes into a single cause whose `reasons` array is the union
* of both inputs (de-duplicated by value equality).
*
* - Combining with {@link empty} returns the other cause unchanged.
* - If the result is structurally equal to `self`, `self` is returned
*   (referential shortcut).
*
* **Example** (combining two causes)
*
* ```ts
* import { Cause } from "effect"
*
* const cause1 = Cause.fail("error1")
* const cause2 = Cause.fail("error2")
* const combined = Cause.combine(cause1, cause2)
* console.log(combined.reasons.length) // 2
* ```
*
* @see {@link fromReasons} — build a cause from an array of reasons
*
* @category combining
* @since 4.0.0
*/
var combine = causeCombine;
/**
* Collapses a {@link Cause} into a single `unknown` value, picking the "most
* important" failure in this order:
*
* 1. First {@link Fail} error (the `E` value)
* 2. First {@link Die} defect
* 3. A generic `Error("All fibers interrupted without error")` for interrupt-only causes
* 4. A generic `Error("Empty cause")` for {@link empty}
*
* This is the function used by `Effect.runPromise` and `Effect.runSync` to
* decide what to throw. It is lossy — use {@link prettyErrors} or iterate
* `cause.reasons` when you need all failures.
*
* **Example** (squashing a cause)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.squash(Cause.fail("error")))    // "error"
* console.log(Cause.squash(Cause.die("defect")))    // "defect"
* ```
*
* @see {@link prettyErrors} — non-lossy conversion to `Array<Error>`
* @see {@link pretty} — human-readable string rendering
*
* @category destructors
* @since 2.0.0
*/
var squash = causeSquash;
/**
* Returns `true` if the cause contains at least one {@link Fail} reason.
*
* **Example** (checking for typed errors)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.hasFails(Cause.fail("error"))) // true
* console.log(Cause.hasFails(Cause.die("defect"))) // false
* ```
*
* @see {@link hasDies} — check for defects
* @see {@link hasInterrupts} — check for interruptions
*
* @category predicates
* @since 2.0.0
*/
var hasFails$1 = hasFails$2;
/**
* Returns the first {@link Fail} reason from a cause, including its
* annotations. Returns `Filter.fail` with the remaining cause when no
* `Fail` is found.
*
* Use {@link findError} if you only need the unwrapped error value `E`.
*
* **Example** (extracting the first Fail reason)
*
* ```ts
* import { Cause, Result } from "effect"
*
* const result = Cause.findFail(Cause.fail("error"))
* if (!Result.isFailure(result)) {
*   console.log(result.success.error) // "error"
* }
* ```
*
* @see {@link findError} — extract the unwrapped `E` value
* @see {@link findDie} — extract the first `Die` reason
*
* @category filters
* @since 4.0.0
*/
var findFail = findFail$1;
/**
* Returns the first typed error value `E` from a cause.
* Returns `Filter.fail` with the remaining cause when no `Fail` is found.
*
* Use {@link findFail} if you need the full {@link Fail} reason (including
* annotations). Use {@link findErrorOption} if you prefer an `Option`.
*
* **Example** (extracting the first error value)
*
* ```ts
* import { Cause, Result } from "effect"
*
* const result = Cause.findError(Cause.fail("error"))
* if (!Result.isFailure(result)) {
*   console.log(result.success) // "error"
* }
* ```
*
* @see {@link findFail} — extract the full `Fail` reason
* @see {@link findErrorOption} — `Option`-based variant
*
* @category filters
* @since 4.0.0
*/
var findError$1 = findError$2;
/**
* Returns the first typed error value `E` from a cause wrapped in
* `Option.some`, or `Option.none` if no {@link Fail} reason exists.
*
* This is a convenience wrapper around {@link findError} for code that
* already works with `Option` instead of `Filter`.
*
* **Example** (extracting an error as Option)
*
* ```ts
* import { Cause, Option } from "effect"
*
* const some = Cause.findErrorOption(Cause.fail("error"))
* console.log(Option.isSome(some)) // true
*
* const none = Cause.findErrorOption(Cause.die("defect"))
* console.log(Option.isNone(none)) // true
* ```
*
* @see {@link findError} — `Filter`-based variant
*
* @category filters
* @since 4.0.0
*/
var findErrorOption$1 = findErrorOption$2;
/**
* Returns `true` if the cause contains at least one {@link Die} reason.
*
* **Example** (checking for defects)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.hasDies(Cause.die("defect"))) // true
* console.log(Cause.hasDies(Cause.fail("error"))) // false
* ```
*
* @see {@link hasFails} — check for typed errors
* @see {@link hasInterrupts} — check for interruptions
*
* @category predicates
* @since 2.0.0
*/
var hasDies$1 = hasDies$2;
/**
* Returns the first {@link Die} reason from a cause, including its
* annotations. Returns `Filter.fail` with the original cause when no
* `Die` is found.
*
* Use {@link findDefect} if you only need the unwrapped defect value.
*
* **Example** (extracting the first Die reason)
*
* ```ts
* import { Cause, Result } from "effect"
*
* const result = Cause.findDie(Cause.die("defect"))
* if (!Result.isFailure(result)) {
*   console.log(result.success.defect) // "defect"
* }
* ```
*
* @see {@link findDefect} — extract the unwrapped defect value
* @see {@link findFail} — extract the first `Fail` reason
*
* @category filters
* @since 4.0.0
*/
var findDie = findDie$1;
/**
* Returns the first defect value (`unknown`) from a cause.
* Returns `Filter.fail` with the original cause when no {@link Die} reason
* is found.
*
* Use {@link findDie} if you need the full `Die` reason (including
* annotations).
*
* **Example** (extracting the first defect)
*
* ```ts
* import { Cause, Result } from "effect"
*
* const result = Cause.findDefect(Cause.die("defect"))
* if (!Result.isFailure(result)) {
*   console.log(result.success) // "defect"
* }
* ```
*
* @see {@link findDie} — extract the full `Die` reason
* @see {@link findError} — extract the first typed error
*
* @category filters
* @since 4.0.0
*/
var findDefect$1 = findDefect$2;
/**
* Returns `true` if the cause contains at least one {@link Interrupt} reason.
*
* **Example** (checking for interruptions)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.hasInterrupts(Cause.interrupt(123))) // true
* console.log(Cause.hasInterrupts(Cause.fail("error")))  // false
* ```
*
* @see {@link hasInterruptsOnly} — `true` only when *all* reasons are interrupts
* @see {@link hasFails} — check for typed errors
* @see {@link hasDies} — check for defects
*
* @category predicates
* @since 2.0.0
*/
var hasInterrupts$1 = hasInterrupts$2;
/**
* Returns the first {@link Interrupt} reason from a cause, including its
* annotations. Returns `Filter.fail` with the original cause when no
* `Interrupt` is found.
*
* **Example** (extracting the first interrupt)
*
* ```ts
* import { Cause, Result } from "effect"
*
* const result = Cause.findInterrupt(Cause.interrupt(42))
* if (!Result.isFailure(result)) {
*   console.log(result.success.fiberId) // 42
* }
* ```
*
* @see {@link interruptors} — collect all interrupting fiber IDs as a `Set`
*
* @category filters
* @since 4.0.0
*/
var findInterrupt = findInterrupt$1;
/**
* Collects the fiber IDs of all {@link Interrupt} reasons in the cause into
* a `ReadonlySet`. Returns an empty set when the cause has no interrupts.
*
* This always succeeds (no `Filter.fail`). Use {@link filterInterruptors}
* for the `Filter`-based variant.
*
* **Example** (collecting interruptors)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.combine(
*   Cause.interrupt(1),
*   Cause.interrupt(2)
* )
* console.log(Cause.interruptors(cause)) // Set { 1, 2 }
* ```
*
* @see {@link filterInterruptors} — `Filter`-based variant
*
* @category accessors
* @since 4.0.0
*/
var interruptors = causeInterruptors;
/**
* Extracts the set of interrupting fiber IDs from a cause.
* Returns `Filter.fail` with the original cause when no {@link Interrupt}
* reason is found.
*
* Use {@link interruptors} if you always want a `Set` (possibly empty)
* without `Filter` wrapping.
*
* **Example** (extracting interruptors with Filter)
*
* ```ts
* import { Cause, Result } from "effect"
*
* const result = Cause.filterInterruptors(Cause.interrupt(1))
* if (!Result.isFailure(result)) {
*   console.log(result.success) // Set { 1 }
* }
* ```
*
* @see {@link interruptors} — always-succeeding variant
*
* @category filters
* @since 4.0.0
*/
var filterInterruptors = causeFilterInterruptors;
/**
* Converts a {@link Cause} into an `Array<Error>` suitable for logging or
* rethrowing.
*
* Each {@link Fail} and {@link Die} reason is converted into a standard
* `Error`:
*
* - **Objects / Error instances** — `message`, `name`, `stack`, and `cause`
*   are preserved. Extra enumerable properties are copied. Stack traces are
*   cleaned up and enriched with span annotations when available.
* - **Strings** — used directly as the `Error` message.
* - **Other primitives** (`null`, `undefined`, numbers, …) — wrapped in an
*   `Error` with message `"Unknown error: <value>"`.
*
* {@link Interrupt} reasons are collected separately. If the cause contains
* **only** interrupts (no `Fail` or `Die`), a single `InterruptError` is
* returned whose `cause` lists the interrupting fiber IDs.
*
* **Example** (converting a cause to errors)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.fail(new Error("boom"))
* const errors = Cause.prettyErrors(cause)
* console.log(errors[0].message) // "boom"
* ```
*
* @see {@link pretty} — renders the cause as a single string
* @see {@link squash} — lossy collapse to a single thrown value
*
* @since 4.0.0
* @category rendering
*/
var prettyErrors = causePrettyErrors;
/**
* Renders a {@link Cause} as a human-readable string for logging or
* debugging.
*
* Delegates to {@link prettyErrors} to convert each reason to an `Error`,
* then joins their stack traces with newlines. Nested `Error.cause` chains
* are rendered inline with indentation:
*
* ```text
* ErrorName: message
*     at ...
*     at ... {
*   [cause]: NestedError: message
*       at ...
* }
* ```
*
* Span annotations are appended to the relevant stack frames when available.
*
* **Example** (rendering a cause)
*
* ```ts
* import { Cause } from "effect"
*
* const cause = Cause.fail("something went wrong")
* console.log(Cause.pretty(cause))
* // Error: something went wrong
* //     at ...
* ```
*
* @see {@link prettyErrors} — get the individual `Error` instances
*
* @since 4.0.0
* @category rendering
*/
var pretty = causePretty;
/**
* Tests if an arbitrary value is a {@link NoSuchElementError}.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isNoSuchElementError(new Cause.NoSuchElementError())) // true
* console.log(Cause.isNoSuchElementError("nope")) // false
* ```
*
* @category guards
* @since 4.0.0
*/
var isNoSuchElementError = isNoSuchElementError$1;
/**
* Unique brand for {@link NoSuchElementError}.
*
* @since 4.0.0
* @category symbols
*/
var NoSuchElementErrorTypeId = NoSuchElementErrorTypeId$1;
/**
* Constructs a {@link NoSuchElementError} with an optional message.
*
* **Example** (creating a NoSuchElementError)
*
* ```ts
* import { Cause } from "effect"
*
* const error = new Cause.NoSuchElementError("Element not found")
* console.log(error.message) // "Element not found"
* ```
*
* @category constructors
* @since 4.0.0
*/
var NoSuchElementError = NoSuchElementError$1;
/**
* Tests if an arbitrary value is a {@link Done} signal.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isDone(Cause.Done())) // true
* console.log(Cause.isDone("not done"))   // false
* ```
*
* @category guards
* @since 4.0.0
*/
var isDone$1 = isDone$2;
/**
* Unique brand for {@link Done} values.
*
* @since 4.0.0
* @category symbols
*/
var DoneTypeId = DoneTypeId$1;
/**
* Creates a {@link Done} signal with an optional value.
*
* @see {@link done} — create a failing `Effect` with `Done`
*
* @category constructors
* @since 4.0.0
*/
var Done = Done$1;
/**
* Creates an Effect that fails with a {@link Done} error. Shorthand for
* `Effect.fail(Cause.Done(value))`.
*
* @see {@link Done:var | Done} — create the signal value without an Effect
*
* @category constructors
* @since 4.0.0
*/
var done$1 = done$2;
/**
* Unique brand for {@link TimeoutError}.
*
* @since 4.0.0
* @category symbols
*/
var TimeoutErrorTypeId = TimeoutErrorTypeId$1;
/**
* Tests if an arbitrary value is a {@link TimeoutError}.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isTimeoutError(new Cause.TimeoutError())) // true
* console.log(Cause.isTimeoutError("nope")) // false
* ```
*
* @category guards
* @since 4.0.0
*/
var isTimeoutError = isTimeoutError$1;
/**
* Constructs a {@link TimeoutError} with an optional message.
*
* **Example** (creating a TimeoutError)
*
* ```ts
* import { Cause } from "effect"
*
* const error = new Cause.TimeoutError("Operation timed out")
* console.log(error.message) // "Operation timed out"
* ```
*
* @category constructors
* @since 4.0.0
*/
var TimeoutError = TimeoutError$1;
/**
* Unique brand for {@link IllegalArgumentError}.
*
* @since 4.0.0
* @category symbols
*/
var IllegalArgumentErrorTypeId = IllegalArgumentErrorTypeId$1;
/**
* Tests if an arbitrary value is an {@link IllegalArgumentError}.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isIllegalArgumentError(new Cause.IllegalArgumentError())) // true
* console.log(Cause.isIllegalArgumentError("nope")) // false
* ```
*
* @category guards
* @since 4.0.0
*/
var isIllegalArgumentError = isIllegalArgumentError$1;
/**
* Constructs an {@link IllegalArgumentError} with an optional message.
*
* **Example** (creating an IllegalArgumentError)
*
* ```ts
* import { Cause } from "effect"
*
* const error = new Cause.IllegalArgumentError("Invalid argument")
* console.log(error.message) // "Invalid argument"
* ```
*
* @category constructors
* @since 4.0.0
*/
var IllegalArgumentError = IllegalArgumentError$1;
/**
* Tests if an arbitrary value is an {@link ExceededCapacityError}.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isExceededCapacityError(new Cause.ExceededCapacityError())) // true
* console.log(Cause.isExceededCapacityError("nope")) // false
* ```
*
* @category guards
* @since 4.0.0
*/
var isExceededCapacityError = isExceededCapacityError$1;
/**
* Unique brand for {@link ExceededCapacityError}.
*
* @since 4.0.0
* @category symbols
*/
var ExceededCapacityErrorTypeId = ExceededCapacityErrorTypeId$1;
/**
* Constructs an {@link ExceededCapacityError} with an optional message.
*
* **Example** (creating an ExceededCapacityError)
*
* ```ts
* import { Cause } from "effect"
*
* const error = new Cause.ExceededCapacityError("Queue full")
* console.log(error.message) // "Queue full"
* ```
*
* @category constructors
* @since 4.0.0
*/
var ExceededCapacityError = ExceededCapacityError$1;
/**
* Unique brand for {@link UnknownError}.
*
* @since 4.0.0
* @category symbols
*/
var UnknownErrorTypeId = UnknownErrorTypeId$1;
/**
* Tests if an arbitrary value is an {@link UnknownError}.
*
* **Example** (runtime type check)
*
* ```ts
* import { Cause } from "effect"
*
* console.log(Cause.isUnknownError(new Cause.UnknownError("x"))) // true
* console.log(Cause.isUnknownError("nope")) // false
* ```
*
* @category guards
* @since 4.0.0
*/
var isUnknownError = isUnknownError$1;
/**
* Constructs an {@link UnknownError}. The first argument is the original
* cause (stored in `Error.cause`); the second is an optional human-readable
* message.
*
* **Example** (creating an UnknownError)
*
* ```ts
* import { Cause } from "effect"
*
* const error = new Cause.UnknownError({ raw: true }, "Unexpected value")
* console.log(error.message) // "Unexpected value"
* ```
*
* @category constructors
* @since 4.0.0
*/
var UnknownError = UnknownError$1;
/**
* Attaches metadata to every reason in a {@link Cause}.
*
* Annotations are stored as a `ServiceMap` on each reason and can be
* retrieved later via {@link reasonAnnotations} or {@link annotations}.
* The runtime uses this to attach stack traces and spans.
*
* - Returns a new `Cause`; does not mutate the input.
* - By default, existing keys are preserved. Pass `{ overwrite: true }` to
*   replace them.
*
* **Example** (annotating a cause)
*
* ```ts
* import { Cause, ServiceMap } from "effect"
*
* const cause = Cause.fail("error")
* const annotated = Cause.annotate(cause, ServiceMap.empty())
* ```
*
* @see {@link annotations} — read merged annotations from a cause
* @see {@link reasonAnnotations} — read annotations from a single reason
*
* @category annotations
* @since 4.0.0
*/
var annotate = causeAnnotate;
/**
* Reads the annotations from a single {@link Reason} as a `ServiceMap`.
*
* Use this when you need tracing metadata (e.g. {@link StackTrace}) from
* a specific reason rather than the whole cause.
*
* @see {@link annotations} — merged annotations from all reasons in a cause
* @see {@link annotate} — attach annotations
*
* @category annotations
* @since 4.0.0
*/
var reasonAnnotations = reasonAnnotations$1;
/**
* Reads the merged annotations from all reasons in a {@link Cause}.
*
* Annotations from later reasons overwrite earlier ones when keys collide.
*
* @see {@link reasonAnnotations} — annotations from a single reason
* @see {@link annotate} — attach annotations
*
* @category annotations
* @since 4.0.0
*/
var annotations = causeAnnotations;
/**
* `ServiceMap` key for the stack frame captured at the point of failure.
*
* The runtime annotates every reason with this when a stack frame is
* available. Retrieve it via
* `ServiceMap.get(Cause.reasonAnnotations(reason), Cause.StackTrace)`.
*
* @category annotations
* @since 4.0.0
*/
var StackTrace = class extends Service()("effect/Cause/StackTrace") {};
/**
* `ServiceMap` key for the stack frame captured at the point of
* interruption.
*
* Similar to {@link StackTrace} but specific to {@link Interrupt} reasons.
*
* @category annotations
* @since 4.0.0
*/
var InterruptorStackTrace = class extends Service()("effect/Cause/InterruptorStackTrace") {};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Exit.js
var Exit_exports = /* @__PURE__ */ __exportAll({
	asVoid: () => asVoid$1,
	asVoidAll: () => asVoidAll,
	die: () => die$2,
	fail: () => fail$3,
	failCause: () => failCause$3,
	filterCause: () => filterCause,
	filterFailure: () => filterFailure,
	filterSuccess: () => filterSuccess,
	filterValue: () => filterValue,
	findDefect: () => findDefect,
	findError: () => findError,
	findErrorOption: () => findErrorOption,
	getCause: () => getCause,
	getSuccess: () => getSuccess,
	hasDies: () => hasDies,
	hasFails: () => hasFails,
	hasInterrupts: () => hasInterrupts,
	interrupt: () => interrupt$2,
	isExit: () => isExit,
	isFailure: () => isFailure$1,
	isSuccess: () => isSuccess$1,
	map: () => map$2,
	mapBoth: () => mapBoth$1,
	mapError: () => mapError$1,
	match: () => match$4,
	succeed: () => succeed$4,
	void: () => void_$1
});
/**
* Tests whether an unknown value is an Exit.
*
* - Use to validate unknown values at system boundaries
* - Works as a type guard, narrowing to `Exit<unknown, unknown>`
*
* Does not inspect the contents of the Exit. Returns `true` for both Success
* and Failure exits.
*
* **Example** (Checking if a value is an Exit)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.isExit(Exit.succeed(42))) // true
* console.log(Exit.isExit(Exit.fail("err"))) // true
* console.log(Exit.isExit("not an exit"))    // false
* ```
*
* @see {@link isSuccess} to check for a successful Exit
* @see {@link isFailure} to check for a failed Exit
*
* @category guards
* @since 2.0.0
*/
var isExit = isExit$1;
/**
* Creates a successful Exit containing the given value.
*
* - Use to wrap a known success value into an Exit
* - Use when constructing test data or returning explicit results
*
* Returns a `Success<A>` with the provided value. Does not perform any
* computation.
*
* **Example** (Creating a successful Exit)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.succeed(42)
* console.log(Exit.isSuccess(exit)) // true
* ```
*
* @see {@link fail} to create a failed Exit
* @see {@link void} for a pre-allocated success with no value
*
* @category constructors
* @since 2.0.0
*/
var succeed$4 = exitSucceed;
/**
* Creates a failed Exit from a Cause.
*
* - Use when you already have a `Cause<E>` and want to wrap it in an Exit
* - Use for advanced error handling where you need full control over the Cause structure
*
* Returns a `Failure<never, E>`. If you only have an error value, use
* {@link fail} instead.
*
* **Example** (Creating a failed Exit from a Cause)
*
* ```ts
* import { Cause, Exit } from "effect"
*
* const cause = Cause.fail("Something went wrong")
* const exit = Exit.failCause(cause)
* console.log(Exit.isFailure(exit)) // true
* ```
*
* @see {@link fail} to create a Failure from a plain error value
* @see {@link die} to create a Failure from a defect
*
* @category constructors
* @since 2.0.0
*/
var failCause$3 = exitFailCause;
/**
* Creates a failed Exit from a typed error value.
*
* - Use for expected, recoverable failures
* - The error is wrapped in a `Cause.Fail` internally
*
* Returns a `Failure<never, E>`.
*
* **Example** (Creating a failed Exit)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.fail("Something went wrong")
* console.log(Exit.isFailure(exit)) // true
* ```
*
* @see {@link succeed} to create a successful Exit
* @see {@link die} to create a Failure from an unexpected defect
* @see {@link failCause} to create a Failure from a full Cause
*
* @category constructors
* @since 2.0.0
*/
var fail$3 = exitFail;
/**
* Creates a failed Exit from a defect (unexpected error).
*
* - Use for unexpected, unrecoverable errors that should not appear in the typed error channel
* - The defect is wrapped in a `Cause.Die` internally
*
* Returns a `Failure<never>` with `E = never`, since defects do not appear in
* the typed error channel.
*
* **Example** (Creating a defect Exit)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.die(new Error("Unexpected error"))
* console.log(Exit.isFailure(exit)) // true
* ```
*
* @see {@link fail} to create a Failure from a typed error
* @see {@link hasDies} to check whether an Exit contains defects
*
* @category constructors
* @since 2.0.0
*/
var die$2 = exitDie;
/**
* Creates a failed Exit representing fiber interruption.
*
* - Use to signal that a fiber was interrupted
* - Optionally pass a fiber ID to identify which fiber was interrupted
*
* Returns a `Failure<never>` with an `Interrupt` cause.
*
* **Example** (Creating an interruption Exit)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.interrupt(123)
* console.log(Exit.isFailure(exit)) // true
* console.log(Exit.hasInterrupts(exit)) // true
* ```
*
* @see {@link hasInterrupts} to check whether an Exit contains interruptions
*
* @category constructors
* @since 2.0.0
*/
var interrupt$2 = exitInterrupt;
var void_$1 = exitVoid;
/**
* Tests whether an Exit is a Success.
*
* - Use as a type guard to narrow `Exit<A, E>` to `Success<A, E>`
* - After narrowing, the `value` property becomes accessible
*
* **Example** (Narrowing to Success)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.succeed(42)
*
* if (Exit.isSuccess(exit)) {
*   console.log(exit.value) // 42
* }
* ```
*
* @see {@link isFailure} for the opposite check
* @see {@link match} for exhaustive pattern matching
*
* @category guards
* @since 2.0.0
*/
var isSuccess$1 = exitIsSuccess;
/**
* Tests whether an Exit is a Failure.
*
* - Use as a type guard to narrow `Exit<A, E>` to `Failure<A, E>`
* - After narrowing, the `cause` property becomes accessible
*
* **Example** (Narrowing to Failure)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.fail("error")
*
* if (Exit.isFailure(exit)) {
*   console.log(exit.cause)
* }
* ```
*
* @see {@link isSuccess} for the opposite check
* @see {@link match} for exhaustive pattern matching
*
* @category guards
* @since 2.0.0
*/
var isFailure$1 = exitIsFailure;
/**
* Tests whether a failed Exit contains typed errors (Fail reasons).
*
* - Use to distinguish typed failures from defects or interruptions
* - Returns `false` for successful exits
*
* Only checks for `Fail` reasons in the Cause. A Cause with only `Die` or
* `Interrupt` reasons returns `false`.
*
* **Example** (Checking for typed errors)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.hasFails(Exit.fail("err")))           // true
* console.log(Exit.hasFails(Exit.die(new Error("bug")))) // false
* console.log(Exit.hasFails(Exit.succeed(42)))            // false
* ```
*
* @see {@link hasDies} to check for defects
* @see {@link hasInterrupts} to check for interruptions
*
* @category guards
* @since 4.0.0
*/
var hasFails = exitHasFails;
/**
* Tests whether a failed Exit contains defects (Die reasons).
*
* - Use to check for unexpected errors
* - Returns `false` for successful exits
*
* Only checks for `Die` reasons in the Cause. A Cause with only `Fail` or
* `Interrupt` reasons returns `false`.
*
* **Example** (Checking for defects)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.hasDies(Exit.die(new Error("bug")))) // true
* console.log(Exit.hasDies(Exit.fail("err")))           // false
* console.log(Exit.hasDies(Exit.succeed(42)))            // false
* ```
*
* @see {@link hasFails} to check for typed errors
* @see {@link hasInterrupts} to check for interruptions
*
* @category guards
* @since 4.0.0
*/
var hasDies = exitHasDies;
/**
* Tests whether a failed Exit contains interruptions (Interrupt reasons).
*
* - Use to check if a fiber was interrupted
* - Returns `false` for successful exits
*
* Only checks for `Interrupt` reasons in the Cause. A Cause with only `Fail`
* or `Die` reasons returns `false`.
*
* **Example** (Checking for interruptions)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.hasInterrupts(Exit.interrupt(1))) // true
* console.log(Exit.hasInterrupts(Exit.fail("err")))  // false
* console.log(Exit.hasInterrupts(Exit.succeed(42)))   // false
* ```
*
* @see {@link hasFails} to check for typed errors
* @see {@link hasDies} to check for defects
*
* @category guards
* @since 4.0.0
*/
var hasInterrupts = exitHasInterrupts;
/**
* Extracts the Success variant from an Exit for use in filter pipelines.
*
* - Use with Filter-based composition
* - Returns the `Success<A>` if the Exit succeeded, or a `Filter.fail` wrapping the Failure otherwise
*
* **Example** (Filtering for success)
*
* ```ts
* import { Exit, Filter } from "effect"
*
* const exit = Exit.succeed(42)
* const result = Exit.filterSuccess(exit)
* // If exit is a success, result is the Success object
* // If exit is a failure, result is a Filter.fail marker
* ```
*
* @see {@link filterFailure} for the inverse
* @see {@link filterValue} to extract the raw value instead of the Success object
*
* @category filters
* @since 4.0.0
*/
var filterSuccess = exitFilterSuccess;
/**
* Extracts the success value from an Exit for use in filter pipelines.
*
* - Use with Filter-based composition when you want the raw value, not the Success wrapper
* - Returns the value `A` if the Exit succeeded, or a `Filter.fail` wrapping the Failure otherwise
*
* **Example** (Filtering for the value)
*
* ```ts
* import { Exit, Filter } from "effect"
*
* const exit = Exit.succeed(42)
* const result = Exit.filterValue(exit)
* // If exit is a success, result is 42
* // If exit is a failure, result is a Filter.fail marker
* ```
*
* @see {@link filterSuccess} to get the full Success object
* @see {@link getSuccess} to get the value as an Option instead
*
* @category filters
* @since 4.0.0
*/
var filterValue = exitFilterValue;
/**
* Extracts the Failure variant from an Exit for use in filter pipelines.
*
* - Use with Filter-based composition
* - Returns the `Failure<never, E>` if the Exit failed, or a `Filter.fail` wrapping the Success otherwise
*
* **Example** (Filtering for failure)
*
* ```ts
* import { Exit, Filter } from "effect"
*
* const exit = Exit.fail("err")
* const result = Exit.filterFailure(exit)
* // If exit is a failure, result is the Failure object
* // If exit is a success, result is a Filter.fail marker
* ```
*
* @see {@link filterSuccess} for the inverse
* @see {@link filterCause} to extract the Cause directly
*
* @category filters
* @since 4.0.0
*/
var filterFailure = exitFilterFailure;
/**
* Extracts the Cause from a failed Exit for use in filter pipelines.
*
* - Use with Filter-based composition when you want the raw Cause, not the Failure wrapper
* - Returns the `Cause<E>` if the Exit failed, or a `Filter.fail` wrapping the Success otherwise
*
* **Example** (Filtering for the cause)
*
* ```ts
* import { Exit, Filter } from "effect"
*
* const exit = Exit.fail("err")
* const result = Exit.filterCause(exit)
* // If exit is a failure, result is the Cause
* // If exit is a success, result is a Filter.fail marker
* ```
*
* @see {@link filterFailure} to get the full Failure object
* @see {@link getCause} to get the Cause as an Option instead
*
* @category filters
* @since 4.0.0
*/
var filterCause = exitFilterCause;
/**
* Extracts the first typed error value from a failed Exit for use in filter
* pipelines.
*
* - Use when you need just the first `E` from the Cause
* - Returns the error `E` if one exists, or `Filter.fail` wrapping the original Exit if the Exit has no typed errors
*
* Only finds the first Fail reason. If the Cause has multiple errors, the rest
* are ignored.
*
* **Example** (Finding the first typed error)
*
* ```ts
* import { Exit, Filter } from "effect"
*
* const exit = Exit.fail("not found")
* const result = Exit.findError(exit)
* // result is "not found"
*
* const defect = Exit.die(new Error("bug"))
* const noError = Exit.findError(defect)
* // noError is a Filter.fail marker
* ```
*
* @see {@link findErrorOption} to get the error as an Option instead
* @see {@link findDefect} to find defects instead
*
* @category filters
* @since 4.0.0
*/
var findError = exitFindError;
/**
* Extracts the first defect from a failed Exit for use in filter pipelines.
*
* - Use when you need to inspect unexpected errors
* - Returns the defect value if one exists, or `Filter.fail` wrapping the original Exit if the Exit has no defects
*
* Only finds the first Die reason. If the Cause has multiple defects, the rest
* are ignored.
*
* **Example** (Finding the first defect)
*
* ```ts
* import { Exit, Filter } from "effect"
*
* const exit = Exit.die("boom")
* const result = Exit.findDefect(exit)
* // result is "boom"
*
* const typed = Exit.fail("err")
* const noDefect = Exit.findDefect(typed)
* // noDefect is a Filter.fail marker
* ```
*
* @see {@link findError} to find typed errors instead
* @see {@link hasDies} to check for defects without extracting them
*
* @category filters
* @since 4.0.0
*/
var findDefect = exitFindDefect;
/**
* Pattern matches on an Exit, handling both success and failure cases.
*
* - Use for exhaustive handling of both outcomes
* - Calls `onSuccess` with the value if the Exit is a Success
* - Calls `onFailure` with the Cause if the Exit is a Failure
*
* Supports both curried and direct call styles (data-last and data-first).
*
* **Example** (Matching on an Exit)
*
* ```ts
* import { Exit } from "effect"
*
* const success = Exit.succeed(42)
*
* const result = Exit.match(success, {
*   onSuccess: (value) => `Got: ${value}`,
*   onFailure: () => "Failed"
* })
* console.log(result) // "Got: 42"
* ```
*
* @see {@link isSuccess} and {@link isFailure} for simple boolean checks
*
* @category pattern matching
* @since 2.0.0
*/
var match$4 = exitMatch;
/**
* Transforms the success value of an Exit using the given function.
*
* - Use to apply a transformation to the value inside a successful Exit
* - Has no effect on failures, which pass through unchanged
*
* Allocates a new Exit if successful. Does not mutate the input.
* Supports both curried and direct call styles.
*
* **Example** (Mapping over a success)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.succeed(21)
* const doubled = Exit.map(exit, (x) => x * 2)
* console.log(Exit.isSuccess(doubled) && doubled.value) // 42
* ```
*
* @see {@link mapError} to transform the error
* @see {@link mapBoth} to transform both success and error
*
* @category combinators
* @since 2.0.0
*/
var map$2 = exitMap;
/**
* Transforms the typed error of a failed Exit using the given function.
*
* - Use to remap typed errors while preserving the Exit structure
* - Has no effect on successes, which pass through unchanged
* - Only transforms typed errors (Fail reasons). If the Cause contains only defects or interruptions, the failure passes through unchanged.
*
* Allocates a new Exit if the error is transformed. Does not mutate the input.
* Supports both curried and direct call styles.
*
* **Example** (Mapping over an error)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.fail("bad input")
* const mapped = Exit.mapError(exit, (e) => new Error(e))
* console.log(Exit.isFailure(mapped)) // true
* ```
*
* @see {@link map} to transform the success value
* @see {@link mapBoth} to transform both success and error
*
* @category combinators
* @since 2.0.0
*/
var mapError$1 = exitMapError;
/**
* Transforms both the success value and typed error of an Exit.
*
* - Use when you need to remap both channels in one step
* - `onSuccess` transforms the value if the Exit is a Success
* - `onFailure` transforms the typed error if the Exit is a Failure with a Fail reason
* - If the Cause contains only defects or interruptions, the failure passes through unchanged
*
* Allocates a new Exit. Does not mutate the input.
* Supports both curried and direct call styles.
*
* **Example** (Mapping both channels)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.succeed(42)
* const mapped = Exit.mapBoth(exit, {
*   onSuccess: (x) => String(x),
*   onFailure: (e: string) => new Error(e)
* })
* console.log(Exit.isSuccess(mapped) && mapped.value) // "42"
* ```
*
* @see {@link map} to transform only the success value
* @see {@link mapError} to transform only the error
*
* @category combinators
* @since 2.0.0
*/
var mapBoth$1 = exitMapBoth;
/**
* Discards the success value of an Exit, replacing it with `void`.
*
* - Use when you only care about whether the computation succeeded or failed, not the value
* - Failures pass through unchanged
*
* Allocates a new Exit if successful. Does not mutate the input.
*
* **Example** (Discarding the success value)
*
* ```ts
* import { Exit } from "effect"
*
* const exit = Exit.succeed(42)
* const voided = Exit.asVoid(exit)
* console.log(Exit.isSuccess(voided)) // true
* ```
*
* @see {@link void} for a pre-allocated void success
* @see {@link asVoidAll} to combine multiple exits into a single void Exit
*
* @category combinators
* @since 2.0.0
*/
var asVoid$1 = exitAsVoid;
/**
* Combines multiple Exit values into a single `Exit<void, E>`.
*
* - Use to validate that all exits in a collection succeeded
* - If all exits are successful, returns a void success
* - If any exit is a failure, returns a single failure with all error causes combined
*
* Iterates over the entire collection. Collects all failure causes, not just
* the first.
*
* **Example** (Combining exits)
*
* ```ts
* import { Exit } from "effect"
*
* const exits = [Exit.succeed(1), Exit.succeed(2), Exit.succeed(3)]
* console.log(Exit.isSuccess(Exit.asVoidAll(exits))) // true
*
* const mixed = [Exit.succeed(1), Exit.fail("err"), Exit.succeed(3)]
* console.log(Exit.isFailure(Exit.asVoidAll(mixed))) // true
* ```
*
* @see {@link asVoid} to discard the value of a single Exit
*
* @category combinators
* @since 4.0.0
*/
var asVoidAll = exitAsVoidAll;
/**
* Returns the success value of an Exit as an Option.
*
* - Use when you want to optionally extract the value without pattern matching
* - Returns `Option.some(value)` for a Success, `Option.none()` for a Failure
*
* **Example** (Getting the success value)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.getSuccess(Exit.succeed(42))) // { _tag: "Some", value: 42 }
* console.log(Exit.getSuccess(Exit.fail("err"))) // { _tag: "None" }
* ```
*
* @see {@link getCause} to extract the Cause of a failure
* @see {@link filterValue} for filter-pipeline usage
*
* @category Accessors
* @since 4.0.0
*/
var getSuccess = exitGetSuccess;
/**
* Returns the Cause of a failed Exit as an Option.
*
* - Use when you want to optionally inspect the failure cause
* - Returns `Option.some(cause)` for a Failure, `Option.none()` for a Success
*
* **Example** (Getting the failure cause)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.getCause(Exit.fail("err"))) // { _tag: "Some", value: ... }
* console.log(Exit.getCause(Exit.succeed(42))) // { _tag: "None" }
* ```
*
* @see {@link getSuccess} to extract the success value
* @see {@link filterCause} for filter-pipeline usage
*
* @category Accessors
* @since 4.0.0
*/
var getCause = exitGetCause;
/**
* Returns the first typed error from a failed Exit as an Option.
*
* - Use when you want to optionally extract a typed error without dealing with the full Cause
* - Returns `Option.some(error)` if the Cause contains a Fail reason, `Option.none()` otherwise
* - Returns `Option.none()` for successes, defect-only failures, and interrupt-only failures
*
* **Example** (Getting the first error)
*
* ```ts
* import { Exit } from "effect"
*
* console.log(Exit.findErrorOption(Exit.fail("err")))           // { _tag: "Some", value: "err" }
* console.log(Exit.findErrorOption(Exit.die(new Error("bug")))) // { _tag: "None" }
* console.log(Exit.findErrorOption(Exit.succeed(42)))            // { _tag: "None" }
* ```
*
* @see {@link findError} for filter-pipeline usage
* @see {@link getCause} to get the full Cause as an Option
*
* @category Accessors
* @since 4.0.0
*/
var findErrorOption = exitFindErrorOption;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Deferred.js
var Deferred_exports = /* @__PURE__ */ __exportAll({
	await: () => _await,
	complete: () => complete$1,
	completeWith: () => completeWith,
	die: () => die$1,
	dieSync: () => dieSync,
	done: () => done,
	doneUnsafe: () => doneUnsafe,
	fail: () => fail$2,
	failCause: () => failCause$2,
	failCauseSync: () => failCauseSync$1,
	failSync: () => failSync$1,
	interrupt: () => interrupt$1,
	interruptWith: () => interruptWith,
	into: () => into,
	isDone: () => isDone,
	isDoneUnsafe: () => isDoneUnsafe,
	make: () => make$4,
	makeUnsafe: () => makeUnsafe$2,
	poll: () => poll,
	succeed: () => succeed$3,
	sync: () => sync$2
});
var DeferredProto = {
	["~effect/Deferred"]: {
		_A: identity,
		_E: identity
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Unsafely creates a new `Deferred`
*
* @example
* ```ts
* import { Deferred } from "effect"
*
* const deferred = Deferred.makeUnsafe<number>()
* console.log(deferred)
* ```
*
* @since 2.0.0
* @category unsafe
*/
var makeUnsafe$2 = () => {
	const self = Object.create(DeferredProto);
	self.resumes = void 0;
	self.effect = void 0;
	return self;
};
/**
* Creates a new `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   yield* Deferred.succeed(deferred, 42)
*   const value = yield* Deferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$4 = () => sync$3(() => makeUnsafe$2());
var _await = (self) => callback$1((resume) => {
	if (self.effect) return resume(self.effect);
	self.resumes ??= [];
	self.resumes.push(resume);
	return sync$3(() => {
		const index = self.resumes.indexOf(resume);
		self.resumes.splice(index, 1);
	});
});
/**
* Completes the deferred with the result of the specified effect. If the
* deferred has already been completed, the method will produce false.
*
* Note that `Deferred.completeWith` will be much faster, so consider using
* that if you do not need to memoize the result of the specified effect.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const completed = yield* Deferred.complete(deferred, Effect.succeed(42))
*   console.log(completed) // true
*
*   const value = yield* Deferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var complete$1 = /*#__PURE__*/ dual(2, (self, effect) => suspend$1(() => self.effect ? succeed$5(false) : into(effect, self)));
/**
* Completes the deferred with the result of the specified effect. If the
* deferred has already been completed, the method will produce false.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const completed = yield* Deferred.completeWith(deferred, Effect.succeed(42))
*   console.log(completed) // true
*
*   const value = yield* Deferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var completeWith = /*#__PURE__*/ dual(2, (self, effect) => sync$3(() => doneUnsafe(self, effect)));
/**
* Exits the `Deferred` with the specified `Exit` value, which will be
* propagated to all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect, Exit } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   yield* Deferred.done(deferred, Exit.succeed(42))
*
*   const value = yield* Deferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var done = completeWith;
/**
* Fails the `Deferred` with the specified error, which will be propagated to
* all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number, string>()
*   const success = yield* Deferred.fail(deferred, "Operation failed")
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var fail$2 = /*#__PURE__*/ dual(2, (self, error) => done(self, exitFail(error)));
/**
* Fails the `Deferred` with the specified error, which will be propagated to
* all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number, string>()
*   const success = yield* Deferred.failSync(deferred, () => "Lazy error")
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var failSync$1 = /*#__PURE__*/ dual(2, (self, evaluate) => suspend$1(() => fail$2(self, evaluate())));
/**
* Fails the `Deferred` with the specified `Cause`, which will be propagated to
* all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Cause, Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number, string>()
*   const success = yield* Deferred.failCause(
*     deferred,
*     Cause.fail("Operation failed")
*   )
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var failCause$2 = /*#__PURE__*/ dual(2, (self, cause) => done(self, exitFailCause(cause)));
/**
* Fails the `Deferred` with the specified `Cause`, which will be propagated to
* all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Cause, Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number, string>()
*   const success = yield* Deferred.failCauseSync(
*     deferred,
*     () => Cause.fail("Lazy error")
*   )
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var failCauseSync$1 = /*#__PURE__*/ dual(2, (self, evaluate) => suspend$1(() => failCause$2(self, evaluate())));
/**
* Kills the `Deferred` with the specified defect, which will be propagated to
* all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const success = yield* Deferred.die(
*     deferred,
*     new Error("Something went wrong")
*   )
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var die$1 = /*#__PURE__*/ dual(2, (self, defect) => done(self, exitDie(defect)));
/**
* Kills the `Deferred` with the specified defect, which will be propagated to
* all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const success = yield* Deferred.dieSync(
*     deferred,
*     () => new Error("Lazy error")
*   )
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var dieSync = /*#__PURE__*/ dual(2, (self, evaluate) => suspend$1(() => die$1(self, evaluate())));
/**
* Completes the `Deferred` with interruption. This will interrupt all fibers
* waiting on the value of the `Deferred` with the `FiberId` of the fiber
* calling this method.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const success = yield* Deferred.interrupt(deferred)
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var interrupt$1 = (self) => withFiber$1((fiber) => interruptWith(self, fiber.id));
/**
* Completes the `Deferred` with interruption. This will interrupt all fibers
* waiting on the value of the `Deferred` with the specified `FiberId`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const success = yield* Deferred.interruptWith(deferred, 42)
*   console.log(success) // true
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var interruptWith = /*#__PURE__*/ dual(2, (self, fiberId) => failCause$2(self, causeInterrupt(fiberId)));
/**
* Returns `true` if this `Deferred` has already been completed with a value or
* an error, `false` otherwise.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const beforeCompletion = yield* Deferred.isDone(deferred)
*   console.log(beforeCompletion) // false
*
*   yield* Deferred.succeed(deferred, 42)
*   const afterCompletion = yield* Deferred.isDone(deferred)
*   console.log(afterCompletion) // true
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var isDone = (self) => sync$3(() => isDoneUnsafe(self));
/**
* Returns `true` if this `Deferred` has already been completed with a value or
* an error, `false` otherwise.
*
* @since 2.0.0
* @category getters
*/
var isDoneUnsafe = (self) => self.effect !== void 0;
/**
* Returns a `Effect<A, E, R>` from the `Deferred` if this `Deferred` has
* already been completed, `undefined` otherwise.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   const beforeCompletion = yield* Deferred.poll(deferred)
*   console.log(beforeCompletion === undefined) // true
*
*   yield* Deferred.succeed(deferred, 42)
*   const afterCompletion = yield* Deferred.poll(deferred)
*   console.log(afterCompletion !== undefined) // true
* })
* ```
*
* @since 2.0.0
* @category getters
*/
function poll(self) {
	return sync$3(() => self.effect);
}
/**
* Completes the `Deferred` with the specified value.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   yield* Deferred.succeed(deferred, 42)
*
*   const value = yield* Deferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var succeed$3 = /*#__PURE__*/ dual(2, (self, value) => done(self, exitSucceed(value)));
/**
* Completes the `Deferred` with the specified lazily evaluated value.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<number>()
*   yield* Deferred.sync(deferred, () => 42)
*
*   const value = yield* Deferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var sync$2 = /*#__PURE__*/ dual(2, (self, evaluate) => suspend$1(() => succeed$3(self, evaluate())));
/**
* Unsafely exits the `Deferred` with the specified `Exit` value, which will be
* propagated to all fibers waiting on the value of the `Deferred`.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* const deferred = Deferred.makeUnsafe<number>()
* const success = Deferred.doneUnsafe(deferred, Effect.succeed(42))
* console.log(success) // true
* ```
*
* @since 2.0.0
* @category unsafe
*/
var doneUnsafe = (self, effect) => {
	if (self.effect) return false;
	self.effect = effect;
	if (self.resumes) {
		for (let i = 0; i < self.resumes.length; i++) self.resumes[i](effect);
		self.resumes = void 0;
	}
	return true;
};
/**
* Converts an `Effect` into an operation that completes a `Deferred` with its result.
*
* **Details**
*
* The `into` function takes an effect and a `Deferred` and ensures that the `Deferred`
* is completed based on the outcome of the effect. If the effect succeeds, the `Deferred` is
* completed with the success value. If the effect fails, the `Deferred` is completed with the
* failure. Additionally, if the effect is interrupted, the `Deferred` will also be interrupted.
*
* @example
* ```ts
* import { Deferred, Effect } from "effect"
*
* // Define an effect that succeeds
* const successEffect = Effect.succeed(42)
*
* const program = Effect.gen(function*() {
*   // Create a deferred
*   const deferred = yield* Deferred.make<number, string>()
*
*   // Complete the deferred using the successEffect
*   const isCompleted = yield* Deferred.into(successEffect, deferred)
*
*   // Access the value of the deferred
*   const value = yield* Deferred.await(deferred)
*   console.log(value)
*
*   return isCompleted
* })
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // 42
* // true
* ```
*
* @since 2.0.0
* @category Synchronization Utilities
*/
var into = /*#__PURE__*/ dual(2, (self, deferred) => uninterruptibleMask$1((restore) => flatMap$2(exit$1(restore(self)), (exit) => done(deferred, exit))));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Scope.js
/**
* The `Scope` module provides functionality for managing resource lifecycles
* and cleanup operations in a functional and composable manner.
*
* A `Scope` represents a context where resources can be acquired and automatically
* cleaned up when the scope is closed. This is essential for managing resources
* like file handles, database connections, or any other resources that need
* proper cleanup.
*
* Scopes support both sequential and parallel finalization strategies:
* - Sequential: Finalizers run one after another in reverse order of registration
* - Parallel: Finalizers run concurrently for better performance
*
* @since 2.0.0
*/
var Scope_exports = /* @__PURE__ */ __exportAll({
	Scope: () => Scope,
	addFinalizer: () => addFinalizer$1,
	addFinalizerExit: () => addFinalizerExit,
	close: () => close,
	closeUnsafe: () => closeUnsafe,
	fork: () => fork,
	forkUnsafe: () => forkUnsafe,
	make: () => make$3,
	makeUnsafe: () => makeUnsafe$1,
	provide: () => provide$3,
	use: () => use
});
/**
* The service tag for `Scope`, used for dependency injection in the Effect system.
*
* @example
* ```ts
* import { Effect, Scope } from "effect"
*
* const program = Effect.gen(function*() {
*   // Access the scope from the context
*   const scope = yield* Scope.Scope
*
*   // Use the scope for resource management
*   yield* Scope.addFinalizer(scope, Effect.log("Cleanup"))
* })
*
* // Provide a scope to the program
* const scoped = Effect.scoped(program)
* ```
*
* @since 2.0.0
* @category tags
*/
var Scope = scopeTag;
/**
* Creates a new `Scope` with the specified finalizer strategy.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a scope with sequential cleanup
*   const scope = yield* Scope.make("sequential")
*
*   // Add finalizers
*   yield* Scope.addFinalizer(scope, Console.log("Cleanup 1"))
*   yield* Scope.addFinalizer(scope, Console.log("Cleanup 2"))
*
*   // Close the scope (finalizers run in reverse order)
*   yield* Scope.close(scope, Exit.void)
*   // Output: "Cleanup 2", then "Cleanup 1"
* })
* ```
*
* @category constructors
* @since 2.0.0
*/
var make$3 = scopeMake;
/**
* Creates a new `Scope` synchronously without wrapping it in an `Effect`.
* This is useful when you need a scope immediately but should be used with caution
* as it doesn't provide the same safety guarantees as the `Effect`-wrapped version.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* // Create a scope immediately
* const scope = Scope.makeUnsafe("sequential")
*
* // Use it in an Effect program
* const program = Effect.gen(function*() {
*   yield* Scope.addFinalizer(scope, Console.log("Cleanup"))
*   yield* Scope.close(scope, Exit.void)
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var makeUnsafe$1 = scopeMakeUnsafe;
/**
* Provides a `Scope` to an `Effect`, removing the `Scope` requirement from its context.
* This allows you to run effects that require a scope by explicitly providing one.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Scope.extend`
*
* @example
* ```ts
* import { Console, Effect, Scope } from "effect"
*
* // An effect that requires a Scope
* const program = Effect.gen(function*() {
*   const scope = yield* Scope.Scope
*   yield* Scope.addFinalizer(scope, Console.log("Cleanup"))
*   yield* Console.log("Working...")
* })
*
* // Provide a scope to the program
* const withScope = Effect.gen(function*() {
*   const scope = yield* Scope.make()
*   yield* Scope.provide(scope)(program)
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var provide$3 = provideScope;
/**
* Adds a finalizer to a scope that will be executed when the scope is closed.
* Finalizers are cleanup functions that receive the exit value of the scope.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* const withResource = Effect.gen(function*() {
*   const scope = yield* Scope.make()
*
*   // Add a finalizer for cleanup
*   yield* Scope.addFinalizerExit(
*     scope,
*     (exit) =>
*       Console.log(
*         `Cleaning up resource. Exit: ${
*           Exit.isSuccess(exit) ? "Success" : "Failure"
*         }`
*       )
*   )
*
*   // Use the resource
*   yield* Console.log("Using resource")
*
*   // Close the scope
*   yield* Scope.close(scope, Exit.void)
* })
* ```
*
* @category combinators
* @since 4.0.0
*/
var addFinalizerExit = scopeAddFinalizerExit;
/**
* Adds a finalizer to a scope. The finalizer is a simple `Effect` that will be
* executed when the scope is closed, regardless of whether the scope closes
* successfully or with an error.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* const program = Effect.gen(function*() {
*   const scope = yield* Scope.make()
*
*   // Add simple finalizers
*   yield* Scope.addFinalizer(scope, Console.log("Cleanup task 1"))
*   yield* Scope.addFinalizer(scope, Console.log("Cleanup task 2"))
*   yield* Scope.addFinalizer(scope, Effect.log("Cleanup task 3"))
*
*   // Do some work
*   yield* Console.log("Doing work...")
*
*   // Close the scope
*   yield* Scope.close(scope, Exit.void)
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var addFinalizer$1 = scopeAddFinalizer;
/**
* Creates a child scope from a parent scope. The child scope inherits the
* parent's finalization strategy unless overridden.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* const nestedScopes = Effect.gen(function*() {
*   const parentScope = yield* Scope.make("sequential")
*
*   // Add finalizer to parent
*   yield* Scope.addFinalizer(parentScope, Console.log("Parent cleanup"))
*
*   // Create child scope
*   const childScope = yield* Scope.fork(parentScope, "parallel")
*
*   // Add finalizer to child
*   yield* Scope.addFinalizer(childScope, Console.log("Child cleanup"))
*
*   // Close child first, then parent
*   yield* Scope.close(childScope, Exit.void)
*   yield* Scope.close(parentScope, Exit.void)
* })
* ```
*
* @category combinators
* @since 4.0.0
*/
var fork = scopeFork;
/**
* Creates a child scope from a parent scope synchronously without wrapping it in an `Effect`.
* The child scope inherits the parent's finalization strategy unless overridden.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* const program = Effect.gen(function*() {
*   const parentScope = Scope.makeUnsafe("sequential")
*   const childScope = Scope.forkUnsafe(parentScope, "parallel")
*
*   // Add finalizers to both scopes
*   yield* Scope.addFinalizer(parentScope, Console.log("Parent cleanup"))
*   yield* Scope.addFinalizer(childScope, Console.log("Child cleanup"))
*
*   // Close child first, then parent
*   yield* Scope.close(childScope, Exit.void)
*   yield* Scope.close(parentScope, Exit.void)
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var forkUnsafe = scopeForkUnsafe;
/**
* Closes a scope, running all registered finalizers in the appropriate order.
* The exit value is passed to each finalizer.
*
* @example
* ```ts
* import { Console, Effect, Exit, Scope } from "effect"
*
* const resourceManagement = Effect.gen(function*() {
*   const scope = yield* Scope.make("sequential")
*
*   // Add multiple finalizers
*   yield* Scope.addFinalizer(scope, Console.log("Close database connection"))
*   yield* Scope.addFinalizer(scope, Console.log("Close file handle"))
*   yield* Scope.addFinalizer(scope, Console.log("Release memory"))
*
*   // Do some work...
*   yield* Console.log("Performing operations...")
*
*   // Close scope - finalizers run in reverse order of registration
*   yield* Scope.close(scope, Exit.succeed("Success!"))
*   // Output: "Release memory", "Close file handle", "Close database connection"
* })
* ```
*
* @category combinators
* @since 4.0.0
*/
var close = scopeClose;
/**
* @since 4.0.0
*/
var closeUnsafe = scopeCloseUnsafe;
/**
* @category combinators
* @since 4.0.0
*/
var use = scopeUse;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Layer.js
var Layer_exports = /* @__PURE__ */ __exportAll({
	CurrentMemoMap: () => CurrentMemoMap,
	build: () => build,
	buildWithMemoMap: () => buildWithMemoMap,
	buildWithScope: () => buildWithScope,
	catch: () => catch_$1,
	catchCause: () => catchCause$1,
	catchTag: () => catchTag$1,
	effect: () => effect,
	effectDiscard: () => effectDiscard,
	effectServices: () => effectServices,
	empty: () => empty$1,
	flatMap: () => flatMap$1,
	fresh: () => fresh,
	fromBuild: () => fromBuild,
	fromBuildMemo: () => fromBuildMemo,
	isLayer: () => isLayer,
	launch: () => launch,
	makeMemoMap: () => makeMemoMap,
	makeMemoMapUnsafe: () => makeMemoMapUnsafe,
	merge: () => merge$1,
	mergeAll: () => mergeAll,
	mock: () => mock,
	orDie: () => orDie$1,
	parentSpan: () => parentSpan,
	provide: () => provide$2,
	provideMerge: () => provideMerge,
	satisfiesErrorType: () => satisfiesErrorType$2,
	satisfiesServicesType: () => satisfiesServicesType$2,
	satisfiesSuccessType: () => satisfiesSuccessType$1,
	span: () => span,
	succeed: () => succeed$2,
	succeedServices: () => succeedServices,
	sync: () => sync$1,
	syncServices: () => syncServices,
	unwrap: () => unwrap,
	updateService: () => updateService$1,
	withParentSpan: () => withParentSpan$1,
	withSpan: () => withSpan$1
});
var TypeId$7 = "~effect/Layer";
var MemoMapTypeId = "~effect/Layer/MemoMap";
/**
* Returns `true` if the specified value is a `Layer`, `false` otherwise.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const dbLayer = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed("result")
* })
* const notALayer = { someProperty: "value" }
*
* console.log(Layer.isLayer(dbLayer)) // true
* console.log(Layer.isLayer(notALayer)) // false
* ```
*
* @since 2.0.0
* @category getters
*/
var isLayer = (u) => hasProperty(u, TypeId$7);
var LayerProto = {
	[TypeId$7]: {
		_ROut: identity,
		_E: identity,
		_RIn: identity
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var fromBuildUnsafe = (build) => {
	const self = Object.create(LayerProto);
	self.build = build;
	return self;
};
/**
* Constructs a Layer from a function that uses a `MemoMap` and `Scope` to build the layer.
*
* The function receives a `MemoMap` for memoization and a `Scope` for resource management.
* A child scope is created, and if the build fails, the child scope is closed.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const databaseLayer = Layer.fromBuild(() =>
*   Effect.sync(() =>
*     ServiceMap.make(Database, {
*       query: (sql: string) => Effect.succeed("result")
*     })
*   )
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromBuild = (build) => fromBuildUnsafe((memoMap, scope) => {
	const layerScope = forkUnsafe(scope);
	return onExit$1(build(memoMap, layerScope), (exit) => exit._tag === "Failure" ? close(layerScope, exit) : void_$2);
});
/**
* Constructs a Layer from a function that uses a `MemoMap` and `Scope` to build the layer,
* with automatic memoization.
*
* This is similar to `fromBuild` but provides automatic memoization of the layer construction.
* The layer will be memoized based on the provided `MemoMap`.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const databaseLayer = Layer.fromBuildMemo(() =>
*   Effect.sync(() =>
*     ServiceMap.make(Database, {
*       query: (sql: string) => Effect.succeed("result")
*     })
*   )
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromBuildMemo = (build) => {
	const self = fromBuild((memoMap, scope) => memoMap.getOrElseMemoize(self, scope, build));
	return self;
};
var MemoMapImpl = class {
	get [MemoMapTypeId]() {
		return MemoMapTypeId;
	}
	map = /*#__PURE__*/ new Map();
	getOrElseMemoize(layer, scope, build) {
		if (this.map.has(layer)) {
			const entry = this.map.get(layer);
			entry.observers++;
			return andThen$2(scopeAddFinalizerExit(scope, (exit) => entry.finalizer(exit)), entry.effect);
		}
		const layerScope = makeUnsafe$1();
		const deferred = makeUnsafe$2();
		const entry = {
			observers: 1,
			effect: _await(deferred),
			finalizer: (exit) => suspend$1(() => {
				entry.observers--;
				if (entry.observers === 0) {
					this.map.delete(layer);
					return close(layerScope, exit);
				}
				return void_$2;
			})
		};
		this.map.set(layer, entry);
		return scopeAddFinalizerExit(scope, entry.finalizer).pipe(flatMap$2(() => build(this, layerScope)), onExit$1((exit) => {
			entry.effect = exit;
			return done(deferred, exit);
		}));
	}
};
/**
* Constructs a `MemoMap` that can be used to build additional layers.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Create a memo map for manual layer building
* const program = Effect.gen(function*() {
*   const memoMap = Layer.makeMemoMapUnsafe()
*   const scope = yield* Effect.scope
*
*   const dbLayer = Layer.succeed(Database)({
*     query: (sql: string) => Effect.succeed("result")
*   })
*   const services = yield* Layer.buildWithMemoMap(dbLayer, memoMap, scope)
*
*   return ServiceMap.get(services, Database)
* })
* ```
*
* @since 4.0.0
* @category memo map
*/
var makeMemoMapUnsafe = () => new MemoMapImpl();
/**
* Constructs a `MemoMap` that can be used to build additional layers.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Create a memo map safely within an Effect
* const program = Effect.gen(function*() {
*   const memoMap = yield* Layer.makeMemoMap
*   const scope = yield* Effect.scope
*
*   const dbLayer = Layer.succeed(Database)({
*     query: (sql: string) => Effect.succeed("result")
*   })
*   const services = yield* Layer.buildWithMemoMap(dbLayer, memoMap, scope)
*
*   return ServiceMap.get(services, Database)
* })
* ```
*
* @since 2.0.0
* @category memo map
*/
var makeMemoMap = /*#__PURE__*/ sync$3(makeMemoMapUnsafe);
/**
* A service reference for the current `MemoMap` used in layer construction.
*
* This service provides access to the current memoization map during layer building,
* allowing layers to share memoized results.
*
* @since 3.13.0
* @category models
*/
var CurrentMemoMap = class extends Service()("effect/Layer/CurrentMemoMap") {
	static getOrCreate = /*#__PURE__*/ getOrElse(this, makeMemoMapUnsafe);
};
/**
* Builds a layer into an `Effect` value, using the specified `MemoMap` to memoize
* the layer construction.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Build layers with explicit memoization control
* const program = Effect.gen(function*() {
*   const memoMap = yield* Layer.makeMemoMap
*   const scope = yield* Effect.scope
*
*   // Build database layer with memoization
*   const dbLayer = Layer.succeed(Database)({
*     query: (sql: string) => Effect.succeed("result")
*   })
*   const dbServices = yield* Layer.buildWithMemoMap(dbLayer, memoMap, scope)
*
*   // Build logger layer with same memoization (reuses memo if same layer)
*   const loggerLayer = Layer.succeed(Logger)({
*     log: (msg: string) => Effect.sync(() => console.log(msg))
*   })
*   const loggerServices = yield* Layer.buildWithMemoMap(
*     loggerLayer,
*     memoMap,
*     scope
*   )
*
*   return {
*     database: ServiceMap.get(dbServices, Database),
*     logger: ServiceMap.get(loggerServices, Logger)
*   }
* })
* ```
*
* @since 2.0.0
* @category memo map
*/
var buildWithMemoMap = /*#__PURE__*/ dual(3, (self, memoMap, scope) => provideService$1(map$4(self.build(memoMap, scope), add$1(CurrentMemoMap, memoMap)), CurrentMemoMap, memoMap));
/**
* Builds a layer into a scoped value.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Build a layer to get its services
* const program = Effect.gen(function*() {
*   const dbLayer = Layer.succeed(Database)({
*     query: (sql: string) => Effect.succeed("result")
*   })
*
*   // Build the layer into ServiceMap - automatically manages scope and memoization
*   const services = yield* Layer.build(dbLayer)
*
*   // Extract the specific service from the built layer
*   const database = ServiceMap.get(services, Database)
*
*   return yield* database.query("SELECT * FROM users")
* })
* ```
*
* @since 2.0.0
* @category destructors
*/
var build = (self) => withFiber$1((fiber) => buildWithMemoMap(self, CurrentMemoMap.getOrCreate(fiber.services), getUnsafe(fiber.services, Scope)));
/**
* Builds a layer into an `Effect` value. Any resources associated with this
* layer will be released when the specified scope is closed unless their scope
* has been extended. This allows building layers where the lifetime of some of
* the services output by the layer exceed the lifetime of the effect the
* layer is provided to.
*
* @example
* ```ts
* import { Effect, Layer, Scope, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Build a layer with explicit scope control
* const program = Effect.gen(function*() {
*   const scope = yield* Effect.scope
*
*   const dbLayer = Layer.effect(Database)(Effect.gen(function*() {
*     console.log("Initializing database...")
*     yield* Scope.addFinalizer(
*       scope,
*       Effect.sync(() => console.log("Database closed"))
*     )
*     return { query: (sql: string) => Effect.succeed(`Result: ${sql}`) }
*   }))
*
*   // Build with specific scope - resources tied to this scope
*   const services = yield* Layer.buildWithScope(dbLayer, scope)
*   const database = ServiceMap.get(services, Database)
*
*   return yield* database.query("SELECT * FROM users")
*   // Database will be closed when scope is closed
* })
* ```
*
* @since 2.0.0
* @category destructors
*/
var buildWithScope = /*#__PURE__*/ dual(2, (self, scope) => withFiber$1((fiber) => buildWithMemoMap(self, CurrentMemoMap.getOrCreate(fiber.services), scope)));
/**
* Constructs a layer from the specified value.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Create layers from concrete service implementations
* const databaseLayer = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed(`Query result: ${sql}`)
* })
*
* const loggerLayer = Layer.succeed(Logger)({
*   log: (msg: string) => Effect.sync(() => console.log(`[LOG] ${msg}`))
* })
*
* // Use the layers in a program
* const program = Effect.gen(function*() {
*   const database = yield* Database
*   const logger = yield* Logger
*
*   yield* logger.log("Starting database query")
*   const result = yield* database.query("SELECT * FROM users")
*   yield* logger.log(`Query completed: ${result}`)
*
*   return result
* }).pipe(
*   Effect.provide(Layer.mergeAll(databaseLayer, loggerLayer))
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var succeed$2 = function() {
	if (arguments.length === 1) return (resource) => succeedServices(make$6(arguments[0], resource));
	return succeedServices(make$6(arguments[0], arguments[1]));
};
/**
* Constructs a layer from the specified value, which must return one or more
* services.
*
* This is a more general version of `succeed` that allows you to provide multiple
* services at once through a `ServiceMap`.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* const services = ServiceMap.make(Database, {
*   query: (sql: string) => Effect.succeed("result")
* })
*   .pipe(
*     ServiceMap.add(Logger, {
*       log: (msg: string) => Effect.sync(() => console.log(msg))
*     })
*   )
*
* const layer = Layer.succeedServices(services)
* ```
*
* @since 2.0.0
* @category constructors
*/
var succeedServices = (services) => fromBuildUnsafe(constant(succeed$5(services)));
/**
* A Layer that constructs an empty ServiceMap.
*
* This layer provides no services and can be used as a neutral element
* in layer composition or as a starting point for building layers.
*
* @example
* ```ts
* import { Layer } from "effect"
*
* const emptyLayer = Layer.empty
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty$1 = /*#__PURE__*/ succeedServices(/*#__PURE__*/ empty$3());
/**
* Lazily constructs a layer from the specified value.
*
* This is a lazy version of `succeed` where the service value is computed
* synchronously only when the layer is built.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const layer = Layer.sync(Database)(() => ({
*   query: (sql: string) => Effect.succeed(`Query: ${sql}`)
* }))
* ```
*
* @since 2.0.0
* @category constructors
*/
var sync$1 = function() {
	if (arguments.length === 1) return (evaluate) => syncServices(() => make$6(arguments[0], evaluate()));
	return syncServices(() => make$6(arguments[0], arguments[1]()));
};
/**
* Lazily constructs a layer from the specified value, which must return one or more
* services.
*
* This is a lazy version of `succeedServices` where the ServiceMap is computed
* synchronously only when the layer is built.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const layer = Layer.syncServices(() =>
*   ServiceMap.make(Database, {
*     query: (sql: string) => Effect.succeed(`Query: ${sql}`)
*   })
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var syncServices = (evaluate) => fromBuildMemo(constant(sync$3(evaluate)));
/**
* Constructs a layer from the specified scoped effect.
*
* This allows you to create a Layer from an Effect that produces a service.
* The Effect is executed in the scope of the layer, allowing for proper
* resource management.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Layer.scoped`
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const layer = Layer.effect(Database)(
*   Effect.sync(() => ({
*     query: (sql: string) => Effect.succeed(`Query: ${sql}`)
*   }))
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var effect = function() {
	if (arguments.length === 1) return (effect) => effectImpl(arguments[0], effect);
	return effectImpl(arguments[0], arguments[1]);
};
var effectImpl = (service, effect) => effectServices(map$4(effect, (value) => make$6(service, value)));
/**
* Constructs a layer from the specified scoped effect, which must return one
* or more services.
*
* This allows you to create a Layer from an effectful computation that returns
* multiple services. The Effect is executed in the scope of the layer.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<
*   Database,
*   { readonly query: (sql: string) => Effect.Effect<string> }
* >()("Database") {}
*
* const layer = Layer.effectServices(
*   Effect.succeed(ServiceMap.make(Database, {
*     query: (sql: string) => Effect.succeed(`Query: ${sql}`)
*   }))
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var effectServices = (effect) => fromBuildMemo((_, scope) => provide$3(effect, scope));
/**
* Constructs a layer from the specified scoped effect.
*
* This is useful when you want to run an Effect for its side effects during
* layer construction, but don't need to provide any services.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Layer.scopedDiscard`
*
* @example
* ```ts
* import { Effect, Layer } from "effect"
*
* const initLayer = Layer.effectDiscard(
*   Effect.sync(() => {
*     console.log("Initializing application...")
*   })
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var effectDiscard = (effect) => effectServices(as$1(effect, empty$3()));
/**
* Unwraps a Layer from an Effect, flattening the nested structure.
*
* This is useful when you have an Effect that produces a Layer, and you want to
* use that Layer directly. The resulting Layer will have the combined error and
* dependency types from both the outer Effect and the inner Layer.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* const layerEffect = Effect.succeed(
*   Layer.succeed(Database)({ query: (sql: string) => Effect.succeed("result") })
* )
*
* const unwrappedLayer = Layer.unwrap(layerEffect)
* ```
*
* @since 4.0.0
* @category utils
*/
var unwrap = (self) => {
	const service = Service("effect/Layer/unwrap");
	return flatMap$1(effect(service)(self), get(service));
};
var mergeAllEffect = (layers, memoMap, scope) => {
	const parentScope = forkUnsafe(scope, "parallel");
	return forEach$1(layers, (layer) => layer.build(memoMap, forkUnsafe(parentScope, "sequential")), { concurrency: layers.length }).pipe(map$4((services) => mergeAll$1(...services)));
};
/**
* Combines all the provided layers concurrently, creating a new layer with merged input, error, and output types.
*
* All layers are built concurrently, and their outputs are merged into a single layer.
* This is useful when you need to combine multiple independent layers.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* const dbLayer = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed("result")
* })
* const loggerLayer = Layer.succeed(Logger)({
*   log: (msg: string) => Effect.sync(() => console.log(msg))
* })
*
* const mergedLayer = Layer.mergeAll(dbLayer, loggerLayer)
* ```
*
* @since 2.0.0
* @category zipping
*/
var mergeAll = (...layers) => fromBuild((memoMap, scope) => mergeAllEffect(layers, memoMap, scope));
/**
* Merges this layer with the specified layer concurrently, producing a new layer with combined input and output types.
*
* This is a binary version of `mergeAll` that merges exactly two layers or one layer with an array of layers.
* The layers are built concurrently and their outputs are combined.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* const dbLayer = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed("result")
* })
* const loggerLayer = Layer.succeed(Logger)({
*   log: (msg: string) => Effect.sync(() => console.log(msg))
* })
*
* const mergedLayer = Layer.merge(dbLayer, loggerLayer)
* ```
*
* @since 2.0.0
* @category zipping
*/
var merge$1 = /*#__PURE__*/ dual(2, (self, that) => mergeAll(self, ...Array.isArray(that) ? that : [that]));
var provideWith = (self, that, f) => fromBuild((memoMap, scope) => flatMap$2(Array.isArray(that) ? mergeAllEffect(that, memoMap, scope) : that.build(memoMap, scope), (context) => self.build(memoMap, scope).pipe(provideServices$1(context), map$4((merged) => f(merged, context)))));
/**
* Feeds the output services of this builder into the input of the specified
* builder, resulting in a new builder with the inputs of this builder as
* well as any leftover inputs, and the outputs of the specified builder.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class UserService extends ServiceMap.Service<UserService, {
*   readonly getUser: (id: string) => Effect.Effect<{
*     id: string
*     name: string
*   }>
* }>()("UserService") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Create dependency layers
* const databaseLayer = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed(`DB: ${sql}`)
* })
*
* const loggerLayer = Layer.succeed(Logger)({
*   log: (msg: string) => Effect.sync(() => console.log(`[LOG] ${msg}`))
* })
*
* // UserService depends on Database and Logger
* const userServiceLayer = Layer.effect(UserService)(Effect.gen(function*() {
*   const database = yield* Database
*   const logger = yield* Logger
*
*   return {
*     getUser: (id: string) =>
*       Effect.gen(function*() {
*         yield* logger.log(`Looking up user ${id}`)
*         const result = yield* database.query(
*           `SELECT * FROM users WHERE id = ${id}`
*         )
*         return { id, name: result }
*       })
*   }
* }))
*
* // Provide dependencies to UserService layer
* const userServiceWithDependencies = userServiceLayer.pipe(
*   Layer.provide(Layer.mergeAll(databaseLayer, loggerLayer))
* )
*
* // Now UserService layer has no dependencies
* const program = Effect.gen(function*() {
*   const userService = yield* UserService
*   return yield* userService.getUser("123")
* }).pipe(
*   Effect.provide(userServiceWithDependencies)
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var provide$2 = /*#__PURE__*/ dual(2, (self, that) => provideWith(self, that, identity));
/**
* Feeds the output services of this layer into the input of the specified
* layer, resulting in a new layer with the inputs of this layer, and the
* outputs of both layers.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* class UserService extends ServiceMap.Service<UserService, {
*   readonly getUser: (id: string) => Effect.Effect<{
*     id: string
*     name: string
*   }>
* }>()("UserService") {}
*
* // Create dependency layers
* const databaseLayer = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed(`DB: ${sql}`)
* })
*
* const loggerLayer = Layer.succeed(Logger)({
*   log: (msg: string) => Effect.sync(() => console.log(`[LOG] ${msg}`))
* })
*
* // UserService depends on Database and Logger
* const userServiceLayer = Layer.effect(UserService)(Effect.gen(function*() {
*   const database = yield* Database
*   const logger = yield* Logger
*
*   return {
*     getUser: (id: string) =>
*       Effect.gen(function*() {
*         yield* logger.log(`Looking up user ${id}`)
*         const result = yield* database.query(
*           `SELECT * FROM users WHERE id = ${id}`
*         )
*         return { id, name: result }
*       })
*   }
* }))
*
* // Provide dependencies and merge all services together
* const allServicesLayer = userServiceLayer.pipe(
*   Layer.provideMerge(Layer.mergeAll(databaseLayer, loggerLayer))
* )
*
* // Now the resulting layer provides UserService, Database, AND Logger
* const program = Effect.gen(function*() {
*   const userService = yield* UserService
*   const logger = yield* Logger // Still available!
*   const database = yield* Database // Still available!
*
*   const user = yield* userService.getUser("123")
*   yield* logger.log(`Found user: ${user.name}`)
*
*   return user
* }).pipe(
*   Effect.provide(allServicesLayer)
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var provideMerge = /*#__PURE__*/ dual(2, (self, that) => provideWith(self, that, (self, that) => merge$2(that, self)));
/**
* Constructs a layer dynamically based on the output of this layer.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Config extends ServiceMap.Service<Config, {
*   readonly dbUrl: string
*   readonly logLevel: string
* }>()("Config") {}
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Base config layer
* const configLayer = Layer.succeed(Config)({
*   dbUrl: "postgres://localhost:5432/mydb",
*   logLevel: "debug"
* })
*
* // Dynamically create services based on config
* const dynamicServiceLayer = configLayer.pipe(
*   Layer.flatMap((services) => {
*     const config = ServiceMap.get(services, Config)
*
*     // Create database layer based on config
*     const dbLayer = Layer.succeed(Database)({
*       query: (sql: string) =>
*         Effect.succeed(
*           `Querying ${config.dbUrl}: ${sql}`
*         )
*     })
*
*     // Create logger layer based on config
*     const loggerLayer = Layer.succeed(Logger)({
*       log: (msg: string) =>
*         config.logLevel === "debug"
*           ? Effect.sync(() => console.log(`[DEBUG] ${msg}`))
*           : Effect.sync(() => console.log(msg))
*     })
*
*     // Return combined layer
*     return Layer.mergeAll(dbLayer, loggerLayer)
*   })
* )
*
* // Use the dynamic services
* const program = Effect.gen(function*() {
*   const database = yield* Database
*   const logger = yield* Logger
*
*   yield* logger.log("Starting database query")
*   const result = yield* database.query("SELECT * FROM users")
*
*   return result
* }).pipe(
*   Effect.provide(dynamicServiceLayer)
* )
* ```
*
* @since 2.0.0
* @category sequencing
*/
var flatMap$1 = /*#__PURE__*/ dual(2, (self, f) => fromBuild((memoMap, scope) => flatMap$2(self.build(memoMap, scope), (context) => f(context).build(memoMap, scope))));
/**
* Translates effect failure into death of the fiber, making all failures
* unchecked and not a part of the type of the layer.
*
* @example
* ```ts
* import { Data, Effect, Layer, ServiceMap } from "effect"
*
* class DatabaseError extends Data.TaggedError("DatabaseError")<{
*   message: string
* }> {}
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Layer that can fail during construction
* const flakyDatabaseLayer = Layer.effect(Database)(Effect.gen(function*() {
*   // Simulate a database connection that might fail
*   const shouldFail = Math.random() > 0.5
*   if (shouldFail) {
*     yield* Effect.fail(new DatabaseError({ message: "Connection failed" }))
*   }
*
*   return { query: (sql: string) => Effect.succeed(`Result: ${sql}`) }
* }))
*
* // Convert failures to fiber death - removes error from type
* const reliableDatabaseLayer = flakyDatabaseLayer.pipe(Layer.orDie)
*
* // Now the layer type is Layer<Database, never, never> - no error in type
* const program = Effect.gen(function*() {
*   const database = yield* Database
*   return yield* database.query("SELECT * FROM users")
* }).pipe(
*   Effect.provide(reliableDatabaseLayer)
* )
*
* // If the database layer fails, the entire fiber will die
* // instead of the effect failing with DatabaseError
* ```
*
* @since 2.0.0
* @category error handling
*/
var orDie$1 = (self) => fromBuildUnsafe((memoMap, scope) => orDie$2(self.build(memoMap, scope)));
var catch_$1 = /*#__PURE__*/ dual(2, (self, onError) => fromBuildUnsafe((memoMap, scope) => catch_$2(self.build(memoMap, scope), (e) => onError(e).build(memoMap, scope))));
/**
* Recovers from specific tagged errors.
*
* @example
* ```ts
* import { Data, Effect, Layer, ServiceMap } from "effect"
*
* class ConfigError extends Data.TaggedError("ConfigError") {}
*
* class Config extends ServiceMap.Service<Config, {
*   readonly apiUrl: string
* }>()("Config") {}
*
* const configLayer = Layer.effect(Config)(Effect.fail(new ConfigError()))
*
* const fallbackLayer = Layer.succeed(Config)({ apiUrl: "http://localhost" })
*
* const recovered = configLayer.pipe(
*   Layer.catchTag("ConfigError", () => fallbackLayer)
* )
* ```
*
* @since 4.0.0
* @category error handling
*/
var catchTag$1 = /*#__PURE__*/ dual(3, (self, k, f) => fromBuildUnsafe((memoMap, scope) => catchTag$2(self.build(memoMap, scope), k, (error) => f(error).build(memoMap, scope))));
/**
* Recovers from all errors.
*
* @example
* ```ts
* import { Data, Effect, Layer, ServiceMap } from "effect"
*
* class DatabaseError extends Data.TaggedError("DatabaseError")<{
*   message: string
* }> {}
*
* class NetworkError extends Data.TaggedError("NetworkError")<{
*   reason: string
* }> {}
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Primary database layer that might fail
* const primaryDatabaseLayer = Layer.effect(Database)(Effect.gen(function*() {
*   yield* Effect.fail(new DatabaseError({ message: "Primary DB unreachable" }))
*   return { query: (sql: string) => Effect.succeed(`Primary: ${sql}`) }
* }))
*
* // Fallback layers for different error causes
* const databaseWithFallback = primaryDatabaseLayer.pipe(
*   Layer.catchCause(() => {
*     // For any cause/error, fallback to in-memory database
*     return Layer.mergeAll(
*       Layer.succeed(Database)({
*         query: (sql: string) => Effect.succeed(`Memory: ${sql}`)
*       }),
*       Layer.succeed(Logger)({
*         log: (msg: string) =>
*           Effect.sync(() => console.log(`[FALLBACK] ${msg}`))
*       })
*     )
*   })
* )
*
* const program = Effect.gen(function*() {
*   const database = yield* Database
*   return yield* database.query("SELECT * FROM users")
* }).pipe(
*   Effect.provide(databaseWithFallback)
* )
* ```
*
* @since 2.0.0
* @category error handling
*/
var catchCause$1 = /*#__PURE__*/ dual(2, (self, onError) => fromBuildUnsafe((memoMap, scope) => catchCause$2(self.build(memoMap, scope), (cause) => onError(cause).build(memoMap, scope))));
/**
* Updates a service in the context with a new implementation.
*
* **Details**
*
* This function modifies the existing implementation of a service in the
* context. It retrieves the current service, applies the provided
* transformation function `f`, and replaces the old service with the
* transformed one.
*
* **When to Use**
*
* This is useful for adapting or extending a service's behavior during the
* creation of a layer.
*
* @since 3.13.0
* @category utils
*/
var updateService$1 = /*#__PURE__*/ dual(3, (layer, service, f) => provide$2(layer, effect(service)(map$4(service.asEffect(), f))));
/**
* Creates a fresh version of this layer that will not be shared.
*
* @example
* ```ts
* import { Effect, Layer, Ref, ServiceMap } from "effect"
*
* class Counter extends ServiceMap.Service<Counter, {
*   readonly count: number
*   readonly increment: () => Effect.Effect<number>
* }>()("Counter") {}
*
* // Layer that creates a counter with shared state
* const counterLayer = Layer.effect(Counter)(Effect.gen(function*() {
*   const ref = yield* Ref.make(0)
*   return {
*     count: 0,
*     increment: () =>
*       Ref.update(ref, (n) => n + 1).pipe(
*         Effect.flatMap(() => Ref.get(ref))
*       )
*   }
* }))
*
* // By default, layers are shared - same instance used everywhere
* const sharedProgram = Effect.gen(function*() {
*   const counter1 = yield* Counter
*   const counter2 = yield* Counter
*
*   // Both counter1 and counter2 refer to the same instance
*   console.log("Shared layer - same instance")
* }).pipe(
*   Effect.provide(counterLayer)
* )
*
* // Fresh layer creates a new instance each time
* const freshProgram = Effect.gen(function*() {
*   const counter1 = yield* Counter
*   const counter2 = yield* Counter
*
*   // counter1 and counter2 are different instances
*   console.log("Fresh layer - different instances")
* }).pipe(
*   Effect.provide(Layer.fresh(counterLayer))
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var fresh = (self) => fromBuildUnsafe((_, scope) => self.build(makeMemoMapUnsafe(), scope));
/**
* Builds this layer and uses it until it is interrupted. This is useful when
* your entire application is a layer, such as an HTTP server.
*
* @example
* ```ts
* import { Console, Effect, Layer, ServiceMap } from "effect"
*
* class HttpServer extends ServiceMap.Service<HttpServer, {
*   readonly start: () => Effect.Effect<string>
*   readonly stop: () => Effect.Effect<string>
* }>()("HttpServer") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Server layer that starts an HTTP server
* const serverLayer = Layer.effect(HttpServer)(Effect.gen(function*() {
*   yield* Console.log("Starting HTTP server...")
*
*   return {
*     start: () =>
*       Effect.gen(function*() {
*         yield* Console.log("Server listening on port 3000")
*         return "Server started"
*       }),
*     stop: () =>
*       Effect.gen(function*() {
*         yield* Console.log("Server stopped gracefully")
*         return "Server stopped"
*       })
*   }
* }))
*
* const loggerLayer = Layer.succeed(Logger)({
*   log: (msg: string) => Console.log(`[LOG] ${msg}`)
* })
*
* // Application layer combining all services
* const appLayer = Layer.mergeAll(serverLayer, loggerLayer)
*
* // Launch the application - runs until interrupted
* const application = appLayer.pipe(
*   Layer.launch,
*   Effect.tapError((error) => Console.log(`Application failed: ${error}`)),
*   Effect.tap(() => Console.log("Application completed"))
* )
*
* // This will run forever until externally interrupted
* // Effect.runFork(application)
* ```
*
* @since 2.0.0
* @category conversions
*/
var launch = (self) => scoped$1(andThen$2(build(self), never$1));
/**
* Creates a mock layer for testing purposes. You can provide a partial
* implementation of the service, and any methods not provided will
* throw an unimplemented defect when called.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class UserService extends ServiceMap.Service<UserService, {
*   readonly config: { apiUrl: string }
*   readonly getUser: (
*     id: string
*   ) => Effect.Effect<{ id: string; name: string }, Error>
*   readonly deleteUser: (id: string) => Effect.Effect<void, Error>
*   readonly updateUser: (
*     id: string,
*     data: object
*   ) => Effect.Effect<{ id: string; name: string }, Error>
* }>()("UserService") {}
*
* // Create a partial mock - only implement what you need for testing
* const testUserLayer = Layer.mock(UserService)({
*   config: { apiUrl: "https://test-api.com" }, // Required - non-Effect property
*   getUser: (id: string) => Effect.succeed({ id, name: "Test User" }) // Mock implementation
*   // deleteUser and updateUser are omitted - will throw UnimplementedError if called
* })
*
* // Use in tests
* const testProgram = Effect.gen(function*() {
*   const userService = yield* UserService
*
*   // This works - we provided an implementation
*   const user = yield* userService.getUser("123")
*   console.log(user.name) // "Test User"
*
*   // This would throw - we didn't implement deleteUser
*   // yield* userService.deleteUser("123") // UnimplementedError
* }).pipe(
*   Effect.provide(testUserLayer)
* )
* ```
*
* @since 4.0.0
* @category Testing
*/
var mock = (service) => (implementation) => succeed$2(service)(new Proxy({ ...implementation }, {
	get(target, prop, _receiver) {
		if (prop in target) return target[prop];
		const prevLimit = Error.stackTraceLimit;
		Error.stackTraceLimit = 2;
		const error = /* @__PURE__ */ new Error(`${service.key}: Unimplemented method "${prop.toString()}"`);
		Error.stackTraceLimit = prevLimit;
		error.name = "UnimplementedError";
		return makeUnimplemented(error);
	},
	has: constTrue
}));
var makeUnimplemented = (error) => {
	const dead = die$4(error);
	function unimplemented() {
		return dead;
	}
	Object.assign(unimplemented, dead);
	Object.setPrototypeOf(unimplemented, Object.getPrototypeOf(dead));
	return unimplemented;
};
/**
* Ensures that an layer's success type extends a given type `ROut`.
*
* This function provides compile-time type checking to ensure that the success
* value of an layer conforms to a specific type constraint.
*
* @example
* ```ts
* import { Layer } from "effect"
*
* declare const FortyTwoLayer: Layer.Layer<42, never, never>
* declare const StringLayer: Layer.Layer<string, never, never>
*
* // Define a constraint that the success type must be a number
* const satisfiesNumber = Layer.satisfiesSuccessType<number>()
*
* // This works - Layer<42, never, never> extends Layer<number, never, never>
* const validLayer = satisfiesNumber(FortyTwoLayer)
*
* // This would cause a TypeScript compilation error:
* // const invalidLayer = satisfiesNumber(StringLayer)
* //                                     ^^^^^^^^^^^
* // Type 'number' is not assignable to type 'string'
* ```
*
* @since 4.0.0
* @category Type constraints
*/
var satisfiesSuccessType$1 = () => (layer) => layer;
/**
* Ensures that an layer's error type extends a given type `E`.
*
* This function provides compile-time type checking to ensure that the error
* type of an layer conforms to a specific type constraint.
*
* @example
* ```ts
* import { Layer } from "effect"
*
* declare const ErrorLayer: Layer.Layer<never, Error, never>
* declare const TypeErrorLayer: Layer.Layer<never, TypeError, never>
* declare const StringLayer: Layer.Layer<never, string, never>
*
* // Define a constraint that the error type must be an Error
* const satisfiesError = Layer.satisfiesErrorType<Error>()
*
* // This works - Layer<never, TypeError, never> extends Layer<never, Error, never>
* const validLayer = satisfiesError(TypeErrorLayer)
*
* // This would cause a TypeScript compilation error:
* // const invalidLayer = satisfiesError(StringLayer)
* //                                     ^^^^^^^^^^^
* // Type 'string' is not assignable to type 'Error'
* ```
*
* @since 4.0.0
* @category Type constraints
*/
var satisfiesErrorType$2 = () => (layer) => layer;
/**
* Ensures that an layer's requirements type extends a given type `R`.
*
* This function provides compile-time type checking to ensure that the
* requirements (context) type of an layer conforms to a specific type constraint.
*
* @example
* ```ts
* import { Layer } from "effect"
*
* declare const FortyTwoLayer: Layer.Layer<never, never, 42>
* declare const StringLayer: Layer.Layer<never, never, string>
*
* // Define a constraint that the success type must be a number
* const satisfiesNumber = Layer.satisfiesServicesType<number>()
*
* // This works - Layer<never, never, 42> extends Layer<never, never, number>
* const validLayer = satisfiesNumber(FortyTwoLayer)
*
* // This would cause a TypeScript compilation error:
* // const invalidLayer = satisfiesNumber(StringLayer)
* //                                     ^^^^^^^^^^^
* // Type 'string' is not assignable to type 'number'
* ```
*
* @since 4.0.0
* @category Type constraints
*/
var satisfiesServicesType$2 = () => (layer) => layer;
/**
* Constructs a new `Layer` which creates a span and registers it as the current
* parent span.
*
* This allows you to create a traced scope for layer construction, making all
* operations within the layer constructor part of the same trace span. The span
* is automatically closed when the layer's scope is closed.
*
* @example
* ```ts
* import { Console, Effect, Layer, ServiceMap, type Tracer } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Create a traced layer - all operations performed during construction of
* // the `Database` service are part of the "database-init" span
* const databaseLayer = Layer.effect(Database, Effect.gen(function*() {
*   // These operations are traced under "database-init" span
*   yield* Effect.log("Connecting to database")
*   yield* Effect.sleep("100 millis")
*   yield* Effect.log("Database connected")
*
*   const parentSpan = yield* Effect.currentParentSpan
*   yield* Console.log((parentSpan as Tracer.Span).name) // "database-init"
*
*   return {
*     query: (sql: string) => Effect.succeed(`Result: ${sql}`)
*   }
* })).pipe(Layer.provide(Layer.span("database-init")))
*
* // Can also use the `onEnd` callback to execute logic when the span ends
* const tracedLayer = Layer.span("service-initialization", {
*   attributes: { version: "1.0.0" },
*   onEnd: (span, exit) =>
*     Effect.sync(() => {
*       console.log(`Span ${span.name} ended with:`, exit._tag)
*     })
* })
* ```
*
* @since 4.0.0
* @category tracing
*/
var span = (name, options) => {
	options = addSpanStackTrace(options);
	return effect(ParentSpan, options?.onEnd ? tap$1(makeSpanScoped$1(name, options), (span) => addFinalizer$2((exit) => options.onEnd(span, exit))) : makeSpanScoped$1(name, options));
};
/**
* Constructs a new `Layer` which takes an existing span and registers it as the
* current parent span.
*
* This allows you to create a traced scope for layer construction, making all
* operations within the layer constructor part of the same trace span. The span
* is automatically closed when the layer's scope is closed.
*
* @example
* ```ts
* import { Console, Effect, Layer, ServiceMap, Tracer } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* // Create a layer that uses an existing span as parent
* const databaseLayer = Layer.effect(
*   Database,
*   Effect.gen(function*() {
*     yield* Effect.log("Initializing database")
*
*     const parentSpan = yield* Effect.currentParentSpan
*     yield* Console.log(parentSpan.spanId) // "42"
*
*     return {
*       query: (sql: string) => Effect.succeed(`Result: ${sql}`)
*     }
*   })
* ).pipe(Layer.provide(Layer.parentSpan(Tracer.externalSpan({
*   spanId: "42",
*   traceId: "000"
* }))))
* ```
*
* @since 4.0.0
* @category tracing
*/
var parentSpan = (span) => succeedServices(ParentSpan.serviceMap(span));
/**
* Wraps a Layer with a new tracing span, making all operations in the layer
* constructor part of the named trace span.
*
* This creates a new span for the layer's construction and execution. The span
* is automatically ended when the layer's scope is closed. This is useful for
* tracking the lifecycle and performance of layer initialization.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Logger extends ServiceMap.Service<Logger, {
*   readonly log: (msg: string) => Effect.Effect<void>
* }>()("Logger") {}
*
* // Create layers with tracing
* const databaseLayer = Layer.effect(Database, Effect.gen(function*() {
*   yield* Effect.log("Connecting to database")
*   yield* Effect.sleep("100 millis")
*   return {
*     query: (sql: string) => Effect.succeed(`Result: ${sql}`)
*   }
* })).pipe(Layer.withSpan("database-initialization", {
*   attributes: { dbType: "postgres" }
* }))
*
* const loggerLayer = Layer.succeed(Logger, {
*   log: (msg: string) => Effect.sync(() => console.log(msg))
* }).pipe(Layer.withSpan("logger-initialization"))
*
* // Combine traced layers
* const appLayer = Layer.mergeAll(databaseLayer, loggerLayer).pipe(
*   Layer.withSpan("app-initialization", {
*     onEnd: (span, exit) =>
*       Effect.sync(() => {
*         console.log(`Application initialization completed: ${exit._tag}`)
*       })
*   })
* )
*
* const program = Effect.gen(function*() {
*   const database = yield* Database
*   const logger = yield* Logger
*
*   yield* logger.log("Application ready")
*   return yield* database.query("SELECT * FROM users")
* }).pipe(Effect.provide(appLayer)
* )
* ```
*
* @since 4.0.0
* @category tracing
*/
var withSpan$1 = function() {
	const dataFirst = typeof arguments[0] !== "string";
	const name = dataFirst ? arguments[1] : arguments[0];
	const options = addSpanStackTrace(dataFirst ? arguments[2] : arguments[1]);
	if (dataFirst) {
		const self = arguments[0];
		return unwrap(map$4(options?.onEnd !== void 0 ? tap$1(makeSpanScoped$1(name, options), (span) => addFinalizer$2((exit) => options.onEnd(span, exit))) : makeSpanScoped$1(name, options), (span) => withParentSpan$1(self, span)));
	}
	return (self) => unwrap(map$4(options?.onEnd !== void 0 ? tap$1(makeSpanScoped$1(name, options), (span) => addFinalizer$2((exit) => options.onEnd(span, exit))) : makeSpanScoped$1(name, options), (span) => withParentSpan$1(self, span)));
};
/**
* Wraps a `Layer` with a new tracing span and sets the span as the parent span.
*
* This attaches a layer to an existing trace span, making all operations within
* the layer children of the provided parent span. This is useful for integrating
* layer construction into an existing trace hierarchy.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap, Tracer } from "effect"
*
* class Database extends ServiceMap.Service<Database, {
*   readonly query: (sql: string) => Effect.Effect<string>
* }>()("Database") {}
*
* class Cache extends ServiceMap.Service<Cache, {
*   readonly get: (key: string) => Effect.Effect<string | null>
* }>()("Cache") {}
*
* // Create layers
* const DatabaseLayer = Layer.effect(Database, Effect.gen(function*() {
*   yield* Effect.log("Connecting to database")
*   return {
*     query: (sql: string) => Effect.succeed(`DB: ${sql}`)
*   }
* }))
*
* const CacheLayer = Layer.effect(Cache, Effect.gen(function*() {
*   yield* Effect.log("Connecting to cache")
*   return {
*     get: (key: string) => Effect.succeed(`Cache: ${key}`)
*   }
* }))
*
* // Use with an existing parent span from Effect.withSpan
* const program = Effect.withSpan("application-startup")(
*   Effect.gen(function*() {
*     const parentSpan = yield* Tracer.ParentSpan
*
*     // Both layers will be children of "application-startup" span
*     const AppLayer = Layer.mergeAll(DatabaseLayer, CacheLayer).pipe(
*       Layer.withParentSpan(parentSpan)
*     )
*
*     const services = yield* Layer.build(AppLayer)
*     const database = ServiceMap.get(services, Database)
*     const cache = ServiceMap.get(services, Cache)
*
*     const dbResult = yield* database.query("SELECT * FROM users")
*     const cacheResult = yield* cache.get("user:123")
*
*     return { dbResult, cacheResult }
*   })
* )
* ```
*
* @since 4.0.0
* @category tracing
*/
var withParentSpan$1 = function() {
	const dataFirst = isLayer(arguments[0]);
	const span = dataFirst ? arguments[1] : arguments[0];
	let options = dataFirst ? arguments[2] : arguments[1];
	let provideStackFrame = identity;
	if (span._tag === "Span") {
		options = addSpanStackTrace(options);
		provideStackFrame = provideSpanStackFrame(span.name, options?.captureStackTrace);
	}
	const parentSpanLayer = parentSpan(span);
	if (dataFirst) return provide$2(provideStackFrame(arguments[0]), parentSpanLayer);
	return (self) => provide$2(provideStackFrame(self), parentSpanLayer);
};
var provideSpanStackFrame = (name, stack) => {
	stack = typeof stack === "function" ? stack : constUndefined;
	return updateService$1(CurrentStackFrame, (parent) => ({
		name,
		stack,
		parent
	}));
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ExecutionPlan.js
var ExecutionPlan_exports = /* @__PURE__ */ __exportAll({
	CurrentMetadata: () => CurrentMetadata$1,
	TypeId: () => TypeId$6,
	isExecutionPlan: () => isExecutionPlan,
	make: () => make$2,
	merge: () => merge
});
/**
* @since 3.16.0
* @category Type IDs
*/
var TypeId$6 = "~effect/ExecutionPlan";
/**
* @since 3.16.0
* @category Guards
*/
var isExecutionPlan = (u) => hasProperty(u, TypeId$6);
/**
* Create an `ExecutionPlan`, which can be used with `Effect.withExecutionPlan` or `Stream.withExecutionPlan`, allowing you to provide different resources for each step of execution until the effect succeeds or the plan is exhausted.
*
* ```ts
* import type { Layer } from "effect"
* import { Effect, ExecutionPlan, Schedule } from "effect"
* import type { LanguageModel } from "effect/unstable/ai"
*
* declare const layerBad: Layer.Layer<LanguageModel.LanguageModel>
* declare const layerGood: Layer.Layer<LanguageModel.LanguageModel>
*
* const ThePlan = ExecutionPlan.make(
*   {
*     // First try with the bad layer 2 times with a 3 second delay between attempts
*     provide: layerBad,
*     attempts: 2,
*     schedule: Schedule.spaced(3000)
*   },
*   // Then try with the bad layer 3 times with a 1 second delay between attempts
*   {
*     provide: layerBad,
*     attempts: 3,
*     schedule: Schedule.spaced(1000)
*   },
*   // Finally try with the good layer.
*   //
*   // If `attempts` is omitted, the plan will only attempt once, unless a schedule is provided.
*   {
*     provide: layerGood
*   }
* )
*
* declare const effect: Effect.Effect<
*   void,
*   never,
*   LanguageModel.LanguageModel
* >
* const withPlan: Effect.Effect<void> = Effect.withExecutionPlan(effect, ThePlan)
* ```
*
* @since 3.16.0
* @category Constructors
*/
var make$2 = (...steps) => makeProto(steps.map((options, i) => {
	if (options.attempts && options.attempts < 1) throw new Error(`ExecutionPlan.make: step[${i}].attempts must be greater than 0`);
	return {
		schedule: options.schedule,
		attempts: options.attempts,
		while: options.while ? (input) => suspend$1(() => {
			const result = options.while(input);
			return typeof result === "boolean" ? succeed$5(result) : result;
		}) : void 0,
		provide: options.provide
	};
}));
var Proto$1 = {
	[TypeId$6]: TypeId$6,
	get withRequirements() {
		const self = this;
		return servicesWith$1((services) => succeed$5(makeProto(self.steps.map((step) => ({
			...step,
			provide: isLayer(step.provide) ? provide$2(step.provide, succeedServices(services)) : step.provide
		})))));
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeProto = (steps) => {
	const self = Object.create(Proto$1);
	self.steps = steps;
	return self;
};
/**
* @since 3.16.0
* @category Combining
*/
var merge = (...plans) => makeProto(plans.flatMap((plan) => plan.steps));
/**
* @since 4.0.0
* @category Metadata
*/
var CurrentMetadata$1 = /*#__PURE__*/ Reference("effect/ExecutionPlan/CurrentMetadata", { defaultValue: /*#__PURE__*/ constant({
	attempt: 0,
	stepIndex: 0
}) });
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Data.js
var Data_exports = /* @__PURE__ */ __exportAll({
	Class: () => Class$1,
	Error: () => Error$1,
	TaggedClass: () => TaggedClass$1,
	TaggedError: () => TaggedError,
	taggedEnum: () => taggedEnum
});
/**
* Base class for immutable data types.
*
* Extend `Class` with a type parameter to declare fields. The constructor
* accepts those fields as a single object argument. When there are no fields
* the argument is optional.
*
* - Use when you need a lightweight immutable value type with `.pipe()` support.
* - Instances are `Readonly` and `Pipeable`.
* - If you also need a `_tag` discriminator, use {@link TaggedClass} instead.
* - If you need a yieldable error, use {@link Error} or {@link TaggedError}.
*
* **Example** (defining a value class)
*
* ```ts
* import { Data, Equal } from "effect"
*
* class Person extends Data.Class<{ readonly name: string }> {}
*
* const mike1 = new Person({ name: "Mike" })
* const mike2 = new Person({ name: "Mike" })
*
* console.log(Equal.equals(mike1, mike2))
* // true
* ```
*
* @see {@link TaggedClass} — adds a `_tag` field
* @see {@link Error} — yieldable error variant
*
* @category constructors
* @since 2.0.0
*/
var Class$1 = class extends Class$2 {
	constructor(props) {
		super();
		if (props) Object.assign(this, props);
	}
};
/**
* Base class for immutable data types with a `_tag` discriminator.
*
* Like {@link Class}, but the resulting instances also carry a
* `readonly _tag: Tag` property. The `_tag` is excluded from the constructor
* argument.
*
* - Use when you need a single-variant tagged type or an ad-hoc discriminator.
* - For multi-variant unions, prefer {@link TaggedEnum} + {@link taggedEnum}.
* - For yieldable errors, use {@link TaggedError}.
*
* **Example** (defining a tagged class)
*
* ```ts
* import { Data } from "effect"
*
* class Person extends Data.TaggedClass("Person")<{
*   readonly name: string
* }> {}
*
* const mike = new Person({ name: "Mike" })
* console.log(mike._tag)
* // "Person"
* ```
*
* @see {@link Class} — without a `_tag`
* @see {@link TaggedError} — tagged error variant
* @see {@link TaggedEnum} — multi-variant unions
*
* @category constructors
* @since 2.0.0
*/
var TaggedClass$1 = (tag) => class extends Class$1 {
	_tag = tag;
};
/**
* Creates runtime constructors, type guards, and pattern matching for a
* {@link TaggedEnum} type.
*
* Returns an object with:
* - One constructor per variant (keyed by tag name)
* - `$is(tag)` — returns a type-guard function
* - `$match` — exhaustive pattern matching (data-first or data-last)
*
* - Use when you have a `TaggedEnum` type and need to construct/inspect values.
* - Constructors produce **plain objects** (not class instances).
* - For generic enums, pass a {@link TaggedEnum.WithGenerics} interface.
*
* **Example** (basic usage)
*
* ```ts
* import { Data } from "effect"
*
* type HttpError = Data.TaggedEnum<{
*   BadRequest: { readonly message: string }
*   NotFound: { readonly url: string }
* }>
*
* const { BadRequest, NotFound, $is, $match } = Data.taggedEnum<HttpError>()
*
* const err = NotFound({ url: "/missing" })
*
* // Type guard
* console.log($is("NotFound")(err)) // true
*
* // Pattern matching
* const msg = $match(err, {
*   BadRequest: (e) => e.message,
*   NotFound: (e) => `${e.url} not found`
* })
* console.log(msg) // "/missing not found"
* ```
*
* **Example** (generic tagged enum)
*
* ```ts
* import { Data } from "effect"
*
* type MyResult<E, A> = Data.TaggedEnum<{
*   Failure: { readonly error: E }
*   Success: { readonly value: A }
* }>
* interface MyResultDef extends Data.TaggedEnum.WithGenerics<2> {
*   readonly taggedEnum: MyResult<this["A"], this["B"]>
* }
* const { Failure, Success } = Data.taggedEnum<MyResultDef>()
*
* const ok = Success({ value: 42 })
* // ok: { readonly _tag: "Success"; readonly value: number }
* ```
*
* @see {@link TaggedEnum} — the type-level companion
* @see {@link TaggedEnum.Constructor} — the returned object type
* @see {@link TaggedEnum.WithGenerics} — generic enum support
*
* @category constructors
* @since 2.0.0
*/
var taggedEnum = () => new Proxy({}, { get(_target, tag, _receiver) {
	if (tag === "$is") return isTagged;
	else if (tag === "$match") return taggedMatch;
	return (props) => ({
		_tag: tag,
		...props
	});
} });
function taggedMatch() {
	if (arguments.length === 1) {
		const cases = arguments[0];
		return function(value) {
			return cases[value._tag](value);
		};
	}
	const value = arguments[0];
	return arguments[1][value._tag](value);
}
/**
* Base class for yieldable errors.
*
* Extends `Cause.YieldableError`, so instances can be yielded inside
* `Effect.gen` to fail the enclosing effect. Fields are passed as a single
* object; when there are no fields the argument is optional.
*
* - Use for errors that do **not** need tag-based discrimination.
* - If you need `Effect.catchTag` support, use {@link TaggedError} instead.
* - If a `message` field is provided, it becomes the error's `.message`.
*
* **Example** (defining a yieldable error)
*
* ```ts
* import { Data, Effect } from "effect"
*
* class NetworkError extends Data.Error<{
*   readonly code: number
*   readonly message: string
* }> {}
*
* const program = Effect.gen(function*() {
*   yield* new NetworkError({ code: 500, message: "timeout" })
* })
*
* // The effect fails with a NetworkError
* Effect.runSync(Effect.exit(program))
* ```
*
* @see {@link TaggedError} — adds a `_tag` for `Effect.catchTag`
* @see {@link Class} — non-error data class
*
* @category constructors
* @since 2.0.0
*/
var Error$1 = Error$2;
/**
* Creates a tagged error class with a `_tag` discriminator.
*
* Like {@link Error}, but instances also carry a `readonly _tag` property,
* enabling `Effect.catchTag` and `Effect.catchTags` for tag-based recovery.
* The `_tag` is excluded from the constructor argument.
*
* - Use for domain errors in Effect applications where you want
*   discriminated-union error handling.
* - Yielding an instance inside `Effect.gen` fails the effect with this error.
*
* **Example** (tag-based error recovery)
*
* ```ts
* import { Data, Effect } from "effect"
*
* class NotFound extends Data.TaggedError("NotFound")<{
*   readonly resource: string
* }> {}
*
* class Forbidden extends Data.TaggedError("Forbidden")<{
*   readonly reason: string
* }> {}
*
* const program = Effect.gen(function*() {
*   yield* new NotFound({ resource: "/users/42" })
* })
*
* const recovered = program.pipe(
*   Effect.catchTag("NotFound", (e) =>
*     Effect.succeed(`missing: ${e.resource}`))
* )
* ```
*
* @see {@link Error} — without a `_tag`
* @see {@link TaggedClass} — tagged class that is not an error
*
* @category constructors
* @since 2.0.0
*/
var TaggedError = TaggedError$1;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Clock.js
var Clock_exports = /* @__PURE__ */ __exportAll({
	Clock: () => Clock,
	clockWith: () => clockWith$1,
	currentTimeMillis: () => currentTimeMillis,
	currentTimeNanos: () => currentTimeNanos
});
/**
* A reference to the current Clock service in the environment.
*
* @example
* ```ts
* import { Clock, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const clock = yield* Clock.Clock
*   return clock.currentTimeMillisUnsafe()
* })
* ```
*
* @category references
* @since 4.0.0
*/
var Clock = ClockRef;
/**
* Accesses the current Clock service and uses it to run the provided function.
*
* @example
* ```ts
* import { Clock, Effect } from "effect"
*
* const program = Clock.clockWith((clock) =>
*   Effect.sync(() => {
*     const currentTime = clock.currentTimeMillisUnsafe()
*     console.log(`Current time: ${currentTime}`)
*     return currentTime
*   })
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var clockWith$1 = clockWith$2;
/**
* Returns an Effect that succeeds with the current time in milliseconds.
*
* @example
* ```ts
* import { Clock, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const currentTime = yield* Clock.currentTimeMillis
*   console.log(`Current time: ${currentTime}ms`)
*   return currentTime
* })
* ```
*
* @category constructors
* @since 2.0.0
*/
var currentTimeMillis = currentTimeMillis$1;
/**
* Returns an Effect that succeeds with the current time in nanoseconds.
*
* @example
* ```ts
* import { Clock, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const currentTime = yield* Clock.currentTimeNanos
*   console.log(`Current time: ${currentTime}ns`)
*   return currentTime
* })
* ```
*
* @category constructors
* @since 2.0.0
*/
var currentTimeNanos = currentTimeNanos$1;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/dateTime.js
/** @internal */
var TypeId$5 = "~effect/time/DateTime";
/** @internal */
var TimeZoneTypeId = "~effect/time/DateTime/TimeZone";
var Proto = {
	[TypeId$5]: TypeId$5,
	pipe() {
		return pipeArguments(this, arguments);
	},
	[NodeInspectSymbol]() {
		return this.toString();
	},
	toJSON() {
		return toDateUtc(this).toJSON();
	}
};
var ProtoUtc = {
	...Proto,
	_tag: "Utc",
	[symbol$1]() {
		return number$1(this.epochMillis);
	},
	[symbol$2](that) {
		return isDateTime(that) && that._tag === "Utc" && this.epochMillis === that.epochMillis;
	},
	toString() {
		return `DateTime.Utc(${toDateUtc(this).toJSON()})`;
	}
};
var ProtoZoned = {
	...Proto,
	_tag: "Zoned",
	[symbol$1]() {
		return combine$1(number$1(this.epochMillis))(hash(this.zone));
	},
	[symbol$2](that) {
		return isDateTime(that) && that._tag === "Zoned" && this.epochMillis === that.epochMillis && equals$3(this.zone, that.zone);
	},
	toString() {
		return `DateTime.Zoned(${formatIsoZoned(this)})`;
	}
};
var ProtoTimeZone = {
	[TimeZoneTypeId]: TimeZoneTypeId,
	[NodeInspectSymbol]() {
		return this.toString();
	}
};
var ProtoTimeZoneNamed = {
	...ProtoTimeZone,
	_tag: "Named",
	[symbol$1]() {
		return string$1(`Named:${this.id}`);
	},
	[symbol$2](that) {
		return isTimeZone(that) && that._tag === "Named" && this.id === that.id;
	},
	toString() {
		return `TimeZone.Named(${this.id})`;
	},
	toJSON() {
		return {
			_id: "TimeZone",
			_tag: "Named",
			id: this.id
		};
	}
};
var ProtoTimeZoneOffset = {
	...ProtoTimeZone,
	_tag: "Offset",
	[symbol$1]() {
		return string$1(`Offset:${this.offset}`);
	},
	[symbol$2](that) {
		return isTimeZone(that) && that._tag === "Offset" && this.offset === that.offset;
	},
	toString() {
		return `TimeZone.Offset(${offsetToString(this.offset)})`;
	},
	toJSON() {
		return {
			_id: "TimeZone",
			_tag: "Offset",
			offset: this.offset
		};
	}
};
/** @internal */
var makeZonedProto = (epochMillis, zone, partsUtc) => {
	const self = Object.create(ProtoZoned);
	self.epochMillis = epochMillis;
	self.zone = zone;
	Object.defineProperty(self, "partsUtc", {
		value: partsUtc,
		enumerable: false,
		writable: true
	});
	Object.defineProperty(self, "adjustedEpochMillis", {
		value: void 0,
		enumerable: false,
		writable: true
	});
	Object.defineProperty(self, "partsAdjusted", {
		value: void 0,
		enumerable: false,
		writable: true
	});
	return self;
};
/** @internal */
var isDateTime = (u) => hasProperty(u, TypeId$5);
var isDateTimeArgs = (args) => isDateTime(args[0]);
/** @internal */
var isTimeZone = (u) => hasProperty(u, TimeZoneTypeId);
/** @internal */
var isTimeZoneOffset = (u) => isTimeZone(u) && u._tag === "Offset";
/** @internal */
var isTimeZoneNamed = (u) => isTimeZone(u) && u._tag === "Named";
/** @internal */
var isUtc = (self) => self._tag === "Utc";
/** @internal */
var isZoned = (self) => self._tag === "Zoned";
/** @internal */
var Equivalence$3 = /*#__PURE__*/ make$14((a, b) => a.epochMillis === b.epochMillis);
/** @internal */
var Order$2 = /*#__PURE__*/ make$13((self, that) => self.epochMillis < that.epochMillis ? -1 : self.epochMillis > that.epochMillis ? 1 : 0);
/** @internal */
var clamp$1 = /*#__PURE__*/ clamp$4(Order$2);
var makeUtc = (epochMillis) => {
	const self = Object.create(ProtoUtc);
	self.epochMillis = epochMillis;
	Object.defineProperty(self, "partsUtc", {
		value: void 0,
		enumerable: false,
		writable: true
	});
	return self;
};
/** @internal */
var fromDateUnsafe = (date) => {
	const epochMillis = date.getTime();
	if (Number.isNaN(epochMillis)) throw new IllegalArgumentError("Invalid date");
	return makeUtc(epochMillis);
};
/** @internal */
var makeUnsafe = (input) => {
	if (isDateTime(input)) return input;
	else if (input instanceof Date) return fromDateUnsafe(input);
	else if (typeof input === "object") {
		const date = /* @__PURE__ */ new Date(0);
		setPartsDate(date, input);
		return fromDateUnsafe(date);
	} else if (typeof input === "string" && !hasZone(input)) return fromDateUnsafe(/* @__PURE__ */ new Date(input + "Z"));
	return fromDateUnsafe(new Date(input));
};
var hasZone = (input) => /Z|[+-]\d{2}$|[+-]\d{2}:?\d{2}$|\]$/.test(input);
var minEpochMillis = -86399999568e5;
var maxEpochMillis = 864e13 - 840 * 60 * 1e3;
/** @internal */
var makeZonedUnsafe = (input, options) => {
	if (options?.timeZone === void 0 && isDateTime(input) && isZoned(input)) return input;
	const self = makeUnsafe(input);
	if (self.epochMillis < minEpochMillis || self.epochMillis > maxEpochMillis) throw new RangeError(`Epoch millis out of range: ${self.epochMillis}`);
	let zone;
	if (options?.timeZone === void 0) zone = zoneMakeOffset(new Date(self.epochMillis).getTimezoneOffset() * -60 * 1e3);
	else if (isTimeZone(options?.timeZone)) zone = options.timeZone;
	else if (typeof options?.timeZone === "number") zone = zoneMakeOffset(options.timeZone);
	else {
		const parsedZone = zoneFromString(options.timeZone);
		if (parsedZone === void 0) throw new IllegalArgumentError(`Invalid time zone: ${options.timeZone}`);
		zone = parsedZone;
	}
	if (options?.adjustForTimeZone !== true) return makeZonedProto(self.epochMillis, zone, self.partsUtc);
	return makeZonedFromAdjusted(self.epochMillis, zone, options?.disambiguation ?? "compatible");
};
/** @internal */
var makeZoned = /*#__PURE__*/ liftThrowable(makeZonedUnsafe);
/** @internal */
var make$1 = /*#__PURE__*/ liftThrowable(makeUnsafe);
var zonedStringRegExp = /^(.{17,35})\[(.+)\]$/;
/** @internal */
var makeZonedFromString = (input) => {
	const match = zonedStringRegExp.exec(input);
	if (match === null) {
		const offset = parseOffset(input);
		return offset !== null ? makeZoned(input, { timeZone: offset }) : void 0;
	}
	const [, isoString, timeZone] = match;
	return makeZoned(isoString, { timeZone });
};
/** @internal */
var now = /*#__PURE__*/ map$4(currentTimeMillis, makeUtc);
/** @internal */
var nowAsDate = /*#__PURE__*/ map$4(currentTimeMillis, (millis) => new Date(millis));
/** @internal */
var nowUnsafe = () => makeUtc(Date.now());
/** @internal */
var toUtc = (self) => makeUtc(self.epochMillis);
/** @internal */
var setZone = /*#__PURE__*/ dual(isDateTimeArgs, (self, zone, options) => options?.adjustForTimeZone === true ? makeZonedFromAdjusted(self.epochMillis, zone, options?.disambiguation ?? "compatible") : makeZonedProto(self.epochMillis, zone, self.partsUtc));
/** @internal */
var setZoneOffset = /*#__PURE__*/ dual(isDateTimeArgs, (self, offset, options) => setZone(self, zoneMakeOffset(offset), options));
var validZoneCache = /*#__PURE__*/ new Map();
var formatOptions = {
	day: "numeric",
	month: "numeric",
	year: "numeric",
	hour: "numeric",
	minute: "numeric",
	second: "numeric",
	timeZoneName: "longOffset",
	fractionalSecondDigits: 3,
	hourCycle: "h23"
};
var zoneMakeIntl = (format) => {
	const zoneId = format.resolvedOptions().timeZone;
	if (validZoneCache.has(zoneId)) return validZoneCache.get(zoneId);
	const zone = Object.create(ProtoTimeZoneNamed);
	zone.id = zoneId;
	zone.format = format;
	validZoneCache.set(zoneId, zone);
	return zone;
};
/** @internal */
var zoneMakeNamedUnsafe = (zoneId) => {
	if (validZoneCache.has(zoneId)) return validZoneCache.get(zoneId);
	try {
		return zoneMakeIntl(new Intl.DateTimeFormat("en-US", {
			...formatOptions,
			timeZone: zoneId
		}));
	} catch {
		throw new IllegalArgumentError(`Invalid time zone: ${zoneId}`);
	}
};
/** @internal */
var zoneMakeOffset = (offset) => {
	const zone = Object.create(ProtoTimeZoneOffset);
	zone.offset = offset;
	return zone;
};
/** @internal */
var zoneMakeNamed = /*#__PURE__*/ liftThrowable(zoneMakeNamedUnsafe);
/** @internal */
var zoneMakeNamedEffect = (zoneId) => try_$1({
	try: () => zoneMakeNamedUnsafe(zoneId),
	catch: (e) => e
});
/** @internal */
var zoneMakeLocal = () => zoneMakeIntl(new Intl.DateTimeFormat("en-US", formatOptions));
var offsetZoneRegExp = /^(?:GMT|[+-])/;
/** @internal */
var zoneFromString = (zone) => {
	if (offsetZoneRegExp.test(zone)) {
		const offset = parseOffset(zone);
		return offset === null ? void 0 : zoneMakeOffset(offset);
	}
	return zoneMakeNamed(zone);
};
/** @internal */
var zoneToString = (self) => {
	if (self._tag === "Offset") return offsetToString(self.offset);
	return self.id;
};
/** @internal */
var setZoneNamed = /*#__PURE__*/ dual(isDateTimeArgs, (self, zoneId, options) => map$5(zoneMakeNamed(zoneId), (zone) => setZone(self, zone, options)));
/** @internal */
var setZoneNamedUnsafe = /*#__PURE__*/ dual(isDateTimeArgs, (self, zoneId, options) => setZone(self, zoneMakeNamedUnsafe(zoneId), options));
/** @internal */
var distance = /*#__PURE__*/ dual(2, (self, other) => millis(toEpochMillis(other) - toEpochMillis(self)));
/** @internal */
var min$1 = /*#__PURE__*/ min$4(Order$2);
/** @internal */
var max$1 = /*#__PURE__*/ max$4(Order$2);
/** @internal */
var isGreaterThan$1 = /*#__PURE__*/ isGreaterThan$3(Order$2);
/** @internal */
var isGreaterThanOrEqualTo$1 = /*#__PURE__*/ isGreaterThanOrEqualTo$3(Order$2);
/** @internal */
var isLessThan$1 = /*#__PURE__*/ isLessThan$3(Order$2);
/** @internal */
var isLessThanOrEqualTo$1 = /*#__PURE__*/ isLessThanOrEqualTo$3(Order$2);
/** @internal */
var between$1 = /*#__PURE__*/ isBetween(Order$2);
/** @internal */
var isFuture = (self) => map$4(now, isLessThan$1(self));
/** @internal */
var isFutureUnsafe = (self) => isLessThan$1(nowUnsafe(), self);
/** @internal */
var isPast = (self) => map$4(now, isGreaterThan$1(self));
/** @internal */
var isPastUnsafe = (self) => isGreaterThan$1(nowUnsafe(), self);
/** @internal */
var toDateUtc = (self) => new Date(self.epochMillis);
/** @internal */
var toDate = (self) => {
	if (self._tag === "Utc") return new Date(self.epochMillis);
	else if (self.zone._tag === "Offset") return new Date(self.epochMillis + self.zone.offset);
	else if (self.adjustedEpochMillis !== void 0) return new Date(self.adjustedEpochMillis);
	const parts = self.zone.format.formatToParts(self.epochMillis).filter((_) => _.type !== "literal");
	const date = /* @__PURE__ */ new Date(0);
	date.setUTCFullYear(Number(parts[2].value), Number(parts[0].value) - 1, Number(parts[1].value));
	date.setUTCHours(Number(parts[3].value), Number(parts[4].value), Number(parts[5].value), Number(parts[6].value));
	self.adjustedEpochMillis = date.getTime();
	return date;
};
/** @internal */
var zonedOffset = (self) => {
	return toDate(self).getTime() - toEpochMillis(self);
};
var offsetToString = (offset) => {
	const abs = Math.abs(offset);
	let hours = Math.floor(abs / (3600 * 1e3));
	let minutes = Math.round(abs % (3600 * 1e3) / (60 * 1e3));
	if (minutes === 60) {
		hours += 1;
		minutes = 0;
	}
	return `${offset < 0 ? "-" : "+"}${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
};
/** @internal */
var zonedOffsetIso = (self) => offsetToString(zonedOffset(self));
/** @internal */
var toEpochMillis = (self) => self.epochMillis;
/** @internal */
var removeTime = (self) => withDate(self, (date) => {
	date.setUTCHours(0, 0, 0, 0);
	return makeUtc(date.getTime());
});
var dateToParts = (date) => ({
	millis: date.getUTCMilliseconds(),
	seconds: date.getUTCSeconds(),
	minutes: date.getUTCMinutes(),
	hours: date.getUTCHours(),
	day: date.getUTCDate(),
	weekDay: date.getUTCDay(),
	month: date.getUTCMonth() + 1,
	year: date.getUTCFullYear()
});
/** @internal */
var toParts = (self) => {
	if (self._tag === "Utc") return toPartsUtc(self);
	else if (self.partsAdjusted !== void 0) return self.partsAdjusted;
	self.partsAdjusted = withDate(self, dateToParts);
	return self.partsAdjusted;
};
/** @internal */
var toPartsUtc = (self) => {
	if (self.partsUtc !== void 0) return self.partsUtc;
	self.partsUtc = withDateUtc(self, dateToParts);
	return self.partsUtc;
};
/** @internal */
var getPartUtc = /*#__PURE__*/ dual(2, (self, part) => toPartsUtc(self)[part]);
/** @internal */
var getPart = /*#__PURE__*/ dual(2, (self, part) => toParts(self)[part]);
var setPartsDate = (date, parts) => {
	if (parts.year !== void 0) date.setUTCFullYear(parts.year);
	if (parts.month !== void 0) date.setUTCMonth(parts.month - 1);
	if (parts.day !== void 0) date.setUTCDate(parts.day);
	if (parts.weekDay !== void 0) {
		const diff = parts.weekDay - date.getUTCDay();
		date.setUTCDate(date.getUTCDate() + diff);
	}
	if (parts.hours !== void 0) date.setUTCHours(parts.hours);
	if (parts.minutes !== void 0) date.setUTCMinutes(parts.minutes);
	if (parts.seconds !== void 0) date.setUTCSeconds(parts.seconds);
	if (parts.millis !== void 0) date.setUTCMilliseconds(parts.millis);
};
/** @internal */
var setParts = /*#__PURE__*/ dual(2, (self, parts) => mutate(self, (date) => setPartsDate(date, parts)));
/** @internal */
var setPartsUtc = /*#__PURE__*/ dual(2, (self, parts) => mutateUtc(self, (date) => setPartsDate(date, parts)));
var constDayMillis = 1440 * 60 * 1e3;
var makeZonedFromAdjusted = (adjustedMillis, zone, disambiguation) => {
	if (zone._tag === "Offset") return makeZonedProto(adjustedMillis - zone.offset, zone);
	const beforeOffset = calculateNamedOffset(adjustedMillis - constDayMillis, adjustedMillis, zone);
	const afterOffset = calculateNamedOffset(adjustedMillis + constDayMillis, adjustedMillis, zone);
	if (beforeOffset === afterOffset) return makeZonedProto(adjustedMillis - beforeOffset, zone);
	const isForwards = beforeOffset < afterOffset;
	const transitionMillis = beforeOffset - afterOffset;
	if (isForwards) {
		if (calculateNamedOffset(adjustedMillis - afterOffset, adjustedMillis, zone) === afterOffset) return makeZonedProto(adjustedMillis - afterOffset, zone);
		const before = makeZonedProto(adjustedMillis - beforeOffset, zone);
		if (adjustedMillis !== toDate(before).getTime()) switch (disambiguation) {
			case "reject": {
				const formatted = new Date(adjustedMillis).toISOString();
				throw new RangeError(`Gap time: ${formatted} does not exist in time zone ${zone.id}`);
			}
			case "earlier": return makeZonedProto(adjustedMillis - afterOffset, zone);
			case "compatible":
			case "later": return before;
		}
		return before;
	}
	if (calculateNamedOffset(adjustedMillis - beforeOffset, adjustedMillis, zone) === beforeOffset) {
		if (disambiguation === "earlier" || disambiguation === "compatible") return makeZonedProto(adjustedMillis - beforeOffset, zone);
		if (calculateNamedOffset(adjustedMillis - beforeOffset + transitionMillis, adjustedMillis + transitionMillis, zone) === beforeOffset) return makeZonedProto(adjustedMillis - beforeOffset, zone);
		if (disambiguation === "reject") {
			const formatted = new Date(adjustedMillis).toISOString();
			throw new RangeError(`Ambiguous time: ${formatted} occurs twice in time zone ${zone.id}`);
		}
	}
	return makeZonedProto(adjustedMillis - afterOffset, zone);
};
var offsetRegExp = /([+-])(\d{2}):(\d{2})$/;
var parseOffset = (offset) => {
	const match = offsetRegExp.exec(offset);
	if (match === null) return null;
	const [, sign, hours, minutes] = match;
	return (sign === "+" ? 1 : -1) * (Number(hours) * 60 + Number(minutes)) * 60 * 1e3;
};
var calculateNamedOffset = (utcMillis, adjustedMillis, zone) => {
	const offset = zone.format.formatToParts(utcMillis).find((_) => _.type === "timeZoneName")?.value ?? "";
	if (offset === "GMT") return 0;
	const result = parseOffset(offset);
	if (result === null) return zonedOffset(makeZonedProto(adjustedMillis, zone));
	return result;
};
/** @internal */
var mutate = /*#__PURE__*/ dual(isDateTimeArgs, (self, f, options) => {
	if (self._tag === "Utc") {
		const date = toDateUtc(self);
		f(date);
		return makeUtc(date.getTime());
	}
	const adjustedDate = toDate(self);
	const newAdjustedDate = new Date(adjustedDate.getTime());
	f(newAdjustedDate);
	return makeZonedFromAdjusted(newAdjustedDate.getTime(), self.zone, options?.disambiguation ?? "compatible");
});
/** @internal */
var mutateUtc = /*#__PURE__*/ dual(2, (self, f) => mapEpochMillis(self, (millis) => {
	const date = new Date(millis);
	f(date);
	return date.getTime();
}));
/** @internal */
var mapEpochMillis = /*#__PURE__*/ dual(2, (self, f) => {
	const millis = f(toEpochMillis(self));
	return self._tag === "Utc" ? makeUtc(millis) : makeZonedProto(millis, self.zone);
});
/** @internal */
var withDate = /*#__PURE__*/ dual(2, (self, f) => f(toDate(self)));
/** @internal */
var withDateUtc = /*#__PURE__*/ dual(2, (self, f) => f(toDateUtc(self)));
/** @internal */
var match$3 = /*#__PURE__*/ dual(2, (self, options) => self._tag === "Utc" ? options.onUtc(self) : options.onZoned(self));
/** @internal */
var addDuration = /*#__PURE__*/ dual(2, (self, duration) => mapEpochMillis(self, (millis) => millis + toMillis(fromInputUnsafe(duration))));
/** @internal */
var subtractDuration = /*#__PURE__*/ dual(2, (self, duration) => mapEpochMillis(self, (millis) => millis - toMillis(fromInputUnsafe(duration))));
var addMillis = (date, amount) => {
	date.setTime(date.getTime() + amount);
};
/** @internal */
var add = /*#__PURE__*/ dual(2, (self, parts) => mutate(self, (date) => {
	if (parts.millis) addMillis(date, parts.millis);
	if (parts.seconds) addMillis(date, parts.seconds * 1e3);
	if (parts.minutes) addMillis(date, parts.minutes * 60 * 1e3);
	if (parts.hours) addMillis(date, parts.hours * 60 * 60 * 1e3);
	if (parts.days) date.setUTCDate(date.getUTCDate() + parts.days);
	if (parts.weeks) date.setUTCDate(date.getUTCDate() + parts.weeks * 7);
	if (parts.months) {
		const day = date.getUTCDate();
		date.setUTCMonth(date.getUTCMonth() + parts.months + 1, 0);
		if (day < date.getUTCDate()) date.setUTCDate(day);
	}
	if (parts.years) {
		const day = date.getUTCDate();
		const month = date.getUTCMonth();
		date.setUTCFullYear(date.getUTCFullYear() + parts.years, month + 1, 0);
		if (day < date.getUTCDate()) date.setUTCDate(day);
	}
}));
/** @internal */
var subtract$1 = /*#__PURE__*/ dual(2, (self, parts) => {
	const newParts = {};
	for (const key in parts) newParts[key] = -1 * parts[key];
	return add(self, newParts);
});
var startOfDate = (date, part, options) => {
	switch (part) {
		case "second":
			date.setUTCMilliseconds(0);
			break;
		case "minute":
			date.setUTCSeconds(0, 0);
			break;
		case "hour":
			date.setUTCMinutes(0, 0, 0);
			break;
		case "day":
			date.setUTCHours(0, 0, 0, 0);
			break;
		case "week": {
			const weekStartsOn = options?.weekStartsOn ?? 0;
			const diff = (date.getUTCDay() - weekStartsOn + 7) % 7;
			date.setUTCDate(date.getUTCDate() - diff);
			date.setUTCHours(0, 0, 0, 0);
			break;
		}
		case "month":
			date.setUTCDate(1);
			date.setUTCHours(0, 0, 0, 0);
			break;
		case "year":
			date.setUTCMonth(0, 1);
			date.setUTCHours(0, 0, 0, 0);
			break;
	}
};
/** @internal */
var startOf = /*#__PURE__*/ dual(isDateTimeArgs, (self, part, options) => mutate(self, (date) => startOfDate(date, part, options)));
var endOfDate = (date, part, options) => {
	switch (part) {
		case "second":
			date.setUTCMilliseconds(999);
			break;
		case "minute":
			date.setUTCSeconds(59, 999);
			break;
		case "hour":
			date.setUTCMinutes(59, 59, 999);
			break;
		case "day":
			date.setUTCHours(23, 59, 59, 999);
			break;
		case "week": {
			const weekStartsOn = options?.weekStartsOn ?? 0;
			const diff = (date.getUTCDay() - weekStartsOn + 7) % 7;
			date.setUTCDate(date.getUTCDate() - diff + 6);
			date.setUTCHours(23, 59, 59, 999);
			break;
		}
		case "month":
			date.setUTCMonth(date.getUTCMonth() + 1, 0);
			date.setUTCHours(23, 59, 59, 999);
			break;
		case "year":
			date.setUTCMonth(11, 31);
			date.setUTCHours(23, 59, 59, 999);
			break;
	}
};
/** @internal */
var endOf = /*#__PURE__*/ dual(isDateTimeArgs, (self, part, options) => mutate(self, (date) => endOfDate(date, part, options)));
/** @internal */
var nearest = /*#__PURE__*/ dual(isDateTimeArgs, (self, part, options) => mutate(self, (date) => {
	if (part === "milli") return;
	const millis = date.getTime();
	const start = new Date(millis);
	startOfDate(start, part, options);
	const startMillis = start.getTime();
	const end = new Date(millis);
	endOfDate(end, part, options);
	const endMillis = end.getTime() + 1;
	if (millis - startMillis < endMillis - millis) date.setTime(startMillis);
	else date.setTime(endMillis);
}));
var intlTimeZone = (self) => {
	if (self._tag === "Named") return self.id;
	return offsetToString(self.offset);
};
/** @internal */
var format = /*#__PURE__*/ dual(isDateTimeArgs, (self, options) => {
	try {
		return new Intl.DateTimeFormat(options?.locale, {
			timeZone: self._tag === "Utc" ? "UTC" : intlTimeZone(self.zone),
			...options
		}).format(self.epochMillis);
	} catch {
		return new Intl.DateTimeFormat(options?.locale, {
			timeZone: "UTC",
			...options
		}).format(toDate(self));
	}
});
/** @internal */
var formatLocal = /*#__PURE__*/ dual(isDateTimeArgs, (self, options) => new Intl.DateTimeFormat(options?.locale, options).format(self.epochMillis));
/** @internal */
var formatUtc = /*#__PURE__*/ dual(isDateTimeArgs, (self, options) => new Intl.DateTimeFormat(options?.locale, {
	...options,
	timeZone: "UTC"
}).format(self.epochMillis));
/** @internal */
var formatIntl = /*#__PURE__*/ dual(2, (self, format) => format.format(self.epochMillis));
/** @internal */
var formatIso = (self) => toDateUtc(self).toISOString();
/** @internal */
var formatIsoDate = (self) => toDate(self).toISOString().slice(0, 10);
/** @internal */
var formatIsoDateUtc = (self) => toDateUtc(self).toISOString().slice(0, 10);
/** @internal */
var formatIsoOffset = (self) => {
	const date = toDate(self);
	return self._tag === "Utc" ? date.toISOString() : `${date.toISOString().slice(0, -1)}${zonedOffsetIso(self)}`;
};
/** @internal */
var formatIsoZoned = (self) => self.zone._tag === "Offset" ? formatIsoOffset(self) : `${formatIsoOffset(self)}[${self.zone.id}]`;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Number.js
/**
* This module provides utility functions and type class instances for working with the `number` type in TypeScript.
* It includes functions for basic arithmetic operations.
*
* @since 2.0.0
*/
var Number_exports = /* @__PURE__ */ __exportAll({
	Equivalence: () => Equivalence$2,
	Number: () => Number$1,
	Order: () => Order$1,
	ReducerMax: () => ReducerMax,
	ReducerMin: () => ReducerMin,
	ReducerMultiply: () => ReducerMultiply,
	ReducerSum: () => ReducerSum,
	between: () => between,
	clamp: () => clamp,
	decrement: () => decrement,
	divide: () => divide,
	increment: () => increment,
	isGreaterThan: () => isGreaterThan,
	isGreaterThanOrEqualTo: () => isGreaterThanOrEqualTo,
	isLessThan: () => isLessThan,
	isLessThanOrEqualTo: () => isLessThanOrEqualTo,
	isNumber: () => isNumber,
	max: () => max,
	min: () => min,
	multiply: () => multiply,
	multiplyAll: () => multiplyAll,
	nextPow2: () => nextPow2,
	parse: () => parse$1,
	remainder: () => remainder,
	round: () => round,
	sign: () => sign,
	subtract: () => subtract,
	sum: () => sum,
	sumAll: () => sumAll
});
/**
* The global `Number` constructor.
*
* @example
* ```ts
* import * as N from "effect/Number"
*
* const num = N.Number("42")
* console.log(num) // 42
*
* const float = N.Number("3.14")
* console.log(float) // 3.14
* ```
*
* @category constructors
* @since 4.0.0
*/
var Number$1 = globalThis.Number;
/**
* Tests if a value is a `number`.
*
* @example
* ```ts
* import { isNumber } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isNumber(2), true)
* assert.deepStrictEqual(isNumber("2"), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isNumber = isNumber$1;
/**
* Provides an addition operation on `number`s.
*
* @example
* ```ts
* import { sum } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sum(2, 3), 5)
* ```
*
* @category math
* @since 2.0.0
*/
var sum = /*#__PURE__*/ dual(2, (self, that) => self + that);
/**
* Provides a multiplication operation on `number`s.
*
* @example
* ```ts
* import { multiply } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(multiply(2, 3), 6)
* ```
*
* @category math
* @since 2.0.0
*/
var multiply = /*#__PURE__*/ dual(2, (self, that) => self * that);
/**
* Provides a subtraction operation on `number`s.
*
* @example
* ```ts
* import { subtract } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(subtract(2, 3), -1)
* ```
*
* @category math
* @since 2.0.0
*/
var subtract = /*#__PURE__*/ dual(2, (self, that) => self - that);
/**
* Provides a division operation on `number`s.
*
* Returns `undefined` if the divisor is `0`.
*
* **Example**
*
* ```ts
* import { Number } from "effect"
*
* Number.divide(6, 3) // 2
* Number.divide(6, 0) // undefined
* ```
*
* @category math
* @since 2.0.0
*/
var divide = /*#__PURE__*/ dual(2, (self, that) => that === 0 ? void 0 : self / that);
/**
* Returns the result of adding `1` to a given number.
*
* @example
* ```ts
* import { increment } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(increment(2), 3)
* ```
*
* @category math
* @since 2.0.0
*/
var increment = (n) => n + 1;
/**
* Decrements a number by `1`.
*
* @example
* ```ts
* import { decrement } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(decrement(3), 2)
* ```
*
* @category math
* @since 2.0.0
*/
var decrement = (n) => n - 1;
/**
* An `Order` instance for `number` values.
*
* @example
* ```ts
* import * as Number from "effect/Number"
*
* console.log(Number.Order(1, 2)) // -1
* console.log(Number.Order(2, 1)) // 1
* console.log(Number.Order(1, 1)) // 0
* ```
*
* @category instances
* @since 2.0.0
*/
var Order$1 = Number$2;
/**
* An `Equivalence` instance for numbers.
*
* `NaN` is considered equal to `NaN`.
*
* @example
* ```ts
* import { Number } from "effect"
*
* console.log(Number.Equivalence(1, 1)) // true
* console.log(Number.Equivalence(1, 2)) // false
* console.log(Number.Equivalence(NaN, NaN)) // true
* ```
*
* @category instances
* @since 4.0.0
*/
var Equivalence$2 = Number$3;
/**
* Returns `true` if the first argument is less than the second, otherwise `false`.
*
* @example
* ```ts
* import { isLessThan } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isLessThan(2, 3), true)
* assert.deepStrictEqual(isLessThan(3, 3), false)
* assert.deepStrictEqual(isLessThan(4, 3), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isLessThan = /*#__PURE__*/ isLessThan$3(Order$1);
/**
* Returns a function that checks if a given `number` is less than or equal to the provided one.
*
* @example
* ```ts
* import { isLessThanOrEqualTo } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isLessThanOrEqualTo(2, 3), true)
* assert.deepStrictEqual(isLessThanOrEqualTo(3, 3), true)
* assert.deepStrictEqual(isLessThanOrEqualTo(4, 3), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isLessThanOrEqualTo = /*#__PURE__*/ isLessThanOrEqualTo$3(Order$1);
/**
* Returns `true` if the first argument is greater than the second, otherwise `false`.
*
* @example
* ```ts
* import { isGreaterThan } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isGreaterThan(2, 3), false)
* assert.deepStrictEqual(isGreaterThan(3, 3), false)
* assert.deepStrictEqual(isGreaterThan(4, 3), true)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isGreaterThan = /*#__PURE__*/ isGreaterThan$3(Order$1);
/**
* Returns a function that checks if a given `number` is greater than or equal to the provided one.
*
* @example
* ```ts
* import { isGreaterThanOrEqualTo } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isGreaterThanOrEqualTo(2, 3), false)
* assert.deepStrictEqual(isGreaterThanOrEqualTo(3, 3), true)
* assert.deepStrictEqual(isGreaterThanOrEqualTo(4, 3), true)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isGreaterThanOrEqualTo = /*#__PURE__*/ isGreaterThanOrEqualTo$3(Order$1);
/**
* Checks if a `number` is between a `minimum` and `maximum` value (inclusive).
*
* @example
* ```ts
* import * as Number from "effect/Number"
* import * as assert from "node:assert"
*
* const between = Number.between({ minimum: 0, maximum: 5 })
*
* assert.deepStrictEqual(between(3), true)
* assert.deepStrictEqual(between(-1), false)
* assert.deepStrictEqual(between(6), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var between = /*#__PURE__*/ isBetween(Order$1);
/**
* Restricts the given `number` to be within the range specified by the `minimum` and `maximum` values.
*
* - If the `number` is less than the `minimum` value, the function returns the `minimum` value.
* - If the `number` is greater than the `maximum` value, the function returns the `maximum` value.
* - Otherwise, it returns the original `number`.
*
* @example
* ```ts
* import * as Number from "effect/Number"
* import * as assert from "node:assert"
*
* const clamp = Number.clamp({ minimum: 1, maximum: 5 })
*
* assert.equal(clamp(3), 3)
* assert.equal(clamp(0), 1)
* assert.equal(clamp(6), 5)
* ```
*
* @category math
* @since 2.0.0
*/
var clamp = /*#__PURE__*/ clamp$4(Order$1);
/**
* Returns the minimum between two `number`s.
*
* @example
* ```ts
* import { min } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(min(2, 3), 2)
* ```
*
* @category math
* @since 2.0.0
*/
var min = /*#__PURE__*/ min$4(Order$1);
/**
* Returns the maximum between two `number`s.
*
* @example
* ```ts
* import { max } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(max(2, 3), 3)
* ```
*
* @category math
* @since 2.0.0
*/
var max = /*#__PURE__*/ max$4(Order$1);
/**
* Determines the sign of a given `number`.
*
* @example
* ```ts
* import { sign } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sign(-5), -1)
* assert.deepStrictEqual(sign(0), 0)
* assert.deepStrictEqual(sign(5), 1)
* ```
*
* @category math
* @since 2.0.0
*/
var sign = (n) => Order$1(n, 0);
/**
* Takes an `Iterable` of `number`s and returns their sum as a single `number`.
*
* @example
* ```ts
* import { sumAll } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sumAll([2, 3, 4]), 9)
* ```
*
* @category math
* @since 2.0.0
*/
var sumAll = (collection) => {
	let out = 0;
	for (const n of collection) out += n;
	return out;
};
/**
* Takes an `Iterable` of `number`s and returns their multiplication as a single `number`.
*
* @example
* ```ts
* import { multiplyAll } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(multiplyAll([2, 3, 4]), 24)
* ```
*
* @category math
* @since 2.0.0
*/
var multiplyAll = (collection) => {
	let out = 1;
	for (const n of collection) {
		if (n === 0) return 0;
		out *= n;
	}
	return out;
};
/**
* Returns the remainder left over when one operand is divided by a second operand.
*
* It always takes the sign of the dividend.
*
* @example
* ```ts
* import { remainder } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(remainder(2, 2), 0)
* assert.deepStrictEqual(remainder(3, 2), 1)
* assert.deepStrictEqual(remainder(-4, 2), -0)
* ```
*
* @category math
* @since 2.0.0
*/
var remainder = /*#__PURE__*/ dual(2, (self, divisor) => {
	const selfDecCount = (self.toString().split(".")[1] || "").length;
	const divisorDecCount = (divisor.toString().split(".")[1] || "").length;
	const decCount = selfDecCount > divisorDecCount ? selfDecCount : divisorDecCount;
	return parseInt(self.toFixed(decCount).replace(".", "")) % parseInt(divisor.toFixed(decCount).replace(".", "")) / Math.pow(10, decCount);
});
/**
* Returns the next power of 2 from the given number.
*
* @example
* ```ts
* import { nextPow2 } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(nextPow2(5), 8)
* assert.deepStrictEqual(nextPow2(17), 32)
* ```
*
* @category math
* @since 2.0.0
*/
var nextPow2 = (n) => {
	const nextPow = Math.ceil(Math.log(n) / Math.log(2));
	return Math.max(Math.pow(2, nextPow), 2);
};
/**
* Tries to parse a `number` from a `string` using the `Number()` function.
* The following special string values are supported: "NaN", "Infinity", "-Infinity".
*
* **Example**
*
* ```ts
* import { Number } from "effect"
*
* Number.parse("42") // 42
* Number.parse("3.14") // 3.14
* Number.parse("NaN") // NaN
* Number.parse("Infinity") // Infinity
* Number.parse("-Infinity") // -Infinity
* Number.parse("not a number") // undefined
* ```
*
* @category constructors
* @since 2.0.0
*/
var parse$1 = (s) => {
	if (s === "NaN") return NaN;
	if (s === "Infinity") return Infinity;
	if (s === "-Infinity") return -Infinity;
	if (s.trim() === "") return;
	const n = Number$1(s);
	return Number$1.isNaN(n) ? void 0 : n;
};
/**
* Returns the number rounded with the given precision.
*
* @example
* ```ts
* import { round } from "effect/Number"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(round(1.1234, 2), 1.12)
* assert.deepStrictEqual(round(1.567, 2), 1.57)
* ```
*
* @category math
* @since 3.8.0
*/
var round = /*#__PURE__*/ dual(2, (self, precision) => {
	const factor = Math.pow(10, precision);
	return Math.round(self * factor) / factor;
});
/**
* A `Reducer` for combining `number`s using addition.
*
* @since 4.0.0
*/
var ReducerSum = /*#__PURE__*/ make$12((a, b) => a + b, 0);
/**
* A `Reducer` for combining `number`s using multiplication.
*
* @since 4.0.0
*/
var ReducerMultiply = /*#__PURE__*/ make$12((a, b) => a * b, 1, (collection) => {
	let acc = 1;
	for (const n of collection) {
		if (n === 0) return 0;
		acc *= n;
	}
	return acc;
});
/**
* A `Combiner` that returns the maximum `number`.
*
* @since 4.0.0
*/
var ReducerMax = /*#__PURE__*/ make$12((a, b) => Math.max(a, b), -Infinity);
/**
* A `Combiner` that returns the minimum `number`.
*
* @since 4.0.0
*/
var ReducerMin = /*#__PURE__*/ make$12((a, b) => Math.min(a, b), Infinity);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/String.js
/**
* This module provides utility functions and type class instances for working with the `string` type in TypeScript.
* It includes functions for basic string manipulation.
*
* @since 2.0.0
*/
var String_exports = /* @__PURE__ */ __exportAll({
	Equivalence: () => Equivalence$1,
	Order: () => Order,
	ReducerConcat: () => ReducerConcat,
	String: () => String$1,
	at: () => at,
	camelCase: () => camelCase,
	camelToSnake: () => camelToSnake,
	capitalize: () => capitalize,
	charAt: () => charAt,
	charCodeAt: () => charCodeAt,
	codePointAt: () => codePointAt,
	concat: () => concat,
	constantCase: () => constantCase,
	empty: () => "",
	endsWith: () => endsWith,
	includes: () => includes,
	indexOf: () => indexOf,
	isEmpty: () => isEmpty,
	isNonEmpty: () => isNonEmpty,
	isString: () => isString,
	kebabCase: () => kebabCase,
	kebabToSnake: () => kebabToSnake,
	lastIndexOf: () => lastIndexOf,
	length: () => length,
	linesIterator: () => linesIterator,
	linesWithSeparators: () => linesWithSeparators,
	localeCompare: () => localeCompare,
	match: () => match$2,
	matchAll: () => matchAll,
	noCase: () => noCase,
	normalize: () => normalize,
	padEnd: () => padEnd,
	padStart: () => padStart,
	pascalCase: () => pascalCase,
	pascalToSnake: () => pascalToSnake,
	repeat: () => repeat$2,
	replace: () => replace,
	replaceAll: () => replaceAll,
	search: () => search,
	slice: () => slice,
	snakeCase: () => snakeCase,
	snakeToCamel: () => snakeToCamel,
	snakeToKebab: () => snakeToKebab,
	snakeToPascal: () => snakeToPascal,
	split: () => split,
	startsWith: () => startsWith,
	stripMargin: () => stripMargin,
	stripMarginWith: () => stripMarginWith,
	substring: () => substring,
	takeLeft: () => takeLeft,
	takeRight: () => takeRight,
	toLocaleLowerCase: () => toLocaleLowerCase,
	toLocaleUpperCase: () => toLocaleUpperCase,
	toLowerCase: () => toLowerCase,
	toUpperCase: () => toUpperCase,
	trim: () => trim,
	trimEnd: () => trimEnd,
	trimStart: () => trimStart,
	uncapitalize: () => uncapitalize
});
/**
* Reference to the global `String` constructor.
*
* @category constructors
* @since 4.0.0
*/
var String$1 = globalThis.String;
/**
* Tests if a value is a `string`.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.isString("a"), true)
* assert.deepStrictEqual(String.isString(1), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isString = isString$1;
/**
* `Order` instance for comparing strings using lexicographic ordering.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.Order("apple", "banana")) // -1
* console.log(String.Order("banana", "apple")) // 1
* console.log(String.Order("apple", "apple")) // 0
* ```
*
* @category instances
* @since 2.0.0
*/
var Order = String$2;
/**
* An `Equivalence` instance for strings using strict equality (`===`).
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.Equivalence("hello", "hello")) // true
* console.log(String.Equivalence("hello", "world")) // false
* ```
*
* @category instances
* @since 4.0.0
*/
var Equivalence$1 = String$3;
/**
* Concatenates two strings at runtime.
*
* @example
* ```ts
* import { pipe, String } from "effect"
*
* const result1 = String.concat("hello", "world")
* console.log(result1) // "helloworld"
*
* const result2 = pipe("hello", String.concat("world"))
* console.log(result2) // "helloworld"
* ```
*
* @category concatenating
* @since 2.0.0
*/
var concat = /*#__PURE__*/ dual(2, (self, that) => self + that);
/**
* Converts a string to uppercase.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("a", String.toUpperCase), "A")
* assert.deepStrictEqual(String.toUpperCase("hello"), "HELLO")
* ```
*
* @category transforming
* @since 2.0.0
*/
var toUpperCase = (self) => self.toUpperCase();
/**
* Converts a string to lowercase.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("A", String.toLowerCase), "a")
* assert.deepStrictEqual(String.toLowerCase("HELLO"), "hello")
* ```
*
* @category transforming
* @since 2.0.0
*/
var toLowerCase = (self) => self.toLowerCase();
/**
* Capitalizes the first character of a string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("abc", String.capitalize), "Abc")
* assert.deepStrictEqual(String.capitalize("hello"), "Hello")
* ```
*
* @category transforming
* @since 2.0.0
*/
var capitalize = (self) => {
	if (self.length === 0) return self;
	return toUpperCase(self[0]) + self.slice(1);
};
/**
* Uncapitalizes the first character of a string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("ABC", String.uncapitalize), "aBC")
* assert.deepStrictEqual(String.uncapitalize("Hello"), "hello")
* ```
*
* @category transforming
* @since 2.0.0
*/
var uncapitalize = (self) => {
	if (self.length === 0) return self;
	return toLowerCase(self[0]) + self.slice(1);
};
/**
* Replaces the first occurrence of a substring or pattern in a string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("abc", String.replace("b", "d")), "adc")
* assert.deepStrictEqual(
*   pipe("hello world", String.replace("world", "Effect")),
*   "hello Effect"
* )
* ```
*
* @category transforming
* @since 2.0.0
*/
var replace = (searchValue, replaceValue) => (self) => self.replace(searchValue, replaceValue);
/**
* Removes whitespace from both ends of a string.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.trim(" a "), "a")
* assert.deepStrictEqual(String.trim("  hello world  "), "hello world")
* ```
*
* @category transforming
* @since 2.0.0
*/
var trim = (self) => self.trim();
/**
* Removes whitespace from the start of a string.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.trimStart(" a "), "a ")
* assert.deepStrictEqual(String.trimStart("  hello world"), "hello world")
* ```
*
* @category transforming
* @since 2.0.0
*/
var trimStart = (self) => self.trimStart();
/**
* Removes whitespace from the end of a string.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.trimEnd(" a "), " a")
* assert.deepStrictEqual(String.trimEnd("hello world  "), "hello world")
* ```
*
* @category transforming
* @since 2.0.0
*/
var trimEnd = (self) => self.trimEnd();
/**
* Extracts a section of a string and returns it as a new string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("abcd", String.slice(1, 3)), "bc")
* assert.deepStrictEqual(pipe("hello world", String.slice(0, 5)), "hello")
* ```
*
* @category transforming
* @since 2.0.0
*/
var slice = (start, end) => (self) => self.slice(start, end);
/**
* Test whether a `string` is empty.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.isEmpty(""), true)
* assert.deepStrictEqual(String.isEmpty("a"), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isEmpty = (self) => self.length === 0;
/**
* Test whether a `string` is non empty.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.isNonEmpty(""), false)
* assert.deepStrictEqual(String.isNonEmpty("a"), true)
* ```
*
* @category guards
* @since 2.0.0
*/
var isNonEmpty = (self) => self.length > 0;
/**
* Calculate the number of characters in a `string`.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.length("abc"), 3)
* ```
*
* @category utilities
* @since 2.0.0
*/
var length = (self) => self.length;
/**
* Splits a string into an array of substrings using a separator.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("abc", String.split("")), ["a", "b", "c"])
* assert.deepStrictEqual(pipe("", String.split("")), [""])
* assert.deepStrictEqual(String.split("hello,world", ","), ["hello", "world"])
* ```
*
* @category transforming
* @since 2.0.0
*/
var split = /*#__PURE__*/ dual(2, (self, separator) => {
	const out = self.split(separator);
	return isArrayNonEmpty$1(out) ? out : [self];
});
/**
* Returns `true` if `searchString` appears as a substring of `self`, at one or more positions that are
* greater than or equal to `position`; otherwise, returns `false`.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("hello world", String.includes("world")), true)
* assert.deepStrictEqual(pipe("hello world", String.includes("foo")), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var includes = (searchString, position) => (self) => self.includes(searchString, position);
/**
* Returns `true` if the string starts with the specified search string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("hello world", String.startsWith("hello")), true)
* assert.deepStrictEqual(pipe("hello world", String.startsWith("world")), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var startsWith = (searchString, position) => (self) => self.startsWith(searchString, position);
/**
* Returns `true` if the string ends with the specified search string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("hello world", String.endsWith("world")), true)
* assert.deepStrictEqual(pipe("hello world", String.endsWith("hello")), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var endsWith = (searchString, position) => (self) => self.endsWith(searchString, position);
/**
* Returns the character code at the specified index, or `undefined` if the index is out of bounds.
*
* **Example**
*
* ```ts
* import { String } from "effect"
*
* String.charCodeAt("abc", 1) // 98
* String.charCodeAt("abc", 4) // undefined
* ```
*
* @category elements
* @since 2.0.0
*/
var charCodeAt = /*#__PURE__*/ dual(2, (self, index) => {
	const out = self.charCodeAt(index);
	return isNaN(out) ? void 0 : out;
});
/**
* Extracts characters from a string between two specified indices.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("abcd", String.substring(1)) // "bcd"
* pipe("abcd", String.substring(1, 3)) // "bc"
* ```
*
* @category transforming
* @since 2.0.0
*/
var substring = (start, end) => (self) => self.substring(start, end);
/**
* A `pipe`-able version of the native `charAt` method.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("abc", String.at(1)) // "b"
* pipe("abc", String.at(4)) // undefined
* ```
*
* @category elements
* @since 2.0.0
*/
var at = (index) => (self) => {
	return self.charAt(index);
};
/**
* Returns the character at the specified index, or `None` if the index is out of bounds.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("abc", String.charAt(1)) // "b"
* pipe("abc", String.charAt(4)) // undefined
* ```
*
* @category elements
* @since 2.0.0
*/
var charAt = /*#__PURE__*/ dual(2, (self, index) => {
	const out = self.charAt(index);
	return isNonEmpty(out) ? out : void 0;
});
/**
* A `pipe`-able version of the native `codePointAt` method.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("abc", String.codePointAt(1)) // 98
* pipe("abc", String.codePointAt(10)) // undefined
* ```
*
* @category elements
* @since 2.0.0
*/
var codePointAt = (index) => (self) => {
	return self.codePointAt(index);
};
/**
* Returns the index of the first occurrence of a substring, or `None` if not found.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("abbbc", String.indexOf("b")) // 1
* pipe("abbbc", String.indexOf("z")) // undefined
* ```
*
* @category searching
* @since 2.0.0
*/
var indexOf = (searchString) => (self) => {
	const out = self.indexOf(searchString);
	return out >= 0 ? out : void 0;
};
/**
* Returns the index of the last occurrence of a substring, or `None` if not found.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("abbbc", String.lastIndexOf("b")) // 3
* pipe("abbbc", String.lastIndexOf("d")) // undefined
* ```
*
* @category searching
* @since 2.0.0
*/
var lastIndexOf = (searchString) => (self) => {
	const out = self.lastIndexOf(searchString);
	return out >= 0 ? out : void 0;
};
/**
* Compares two strings according to the current locale.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("a", String.localeCompare("b")), -1)
* assert.deepStrictEqual(pipe("b", String.localeCompare("a")), 1)
* assert.deepStrictEqual(pipe("a", String.localeCompare("a")), 0)
* ```
*
* @category comparing
* @since 2.0.0
*/
var localeCompare = (that, locales, options) => (self) => sign(self.localeCompare(that, locales, options));
/**
* A `pipe`-able version of the native `match` method.
*
* **Example**
*
* ```ts
* import { pipe, String } from "effect"
*
* pipe("hello", String.match(/l+/)) // ["ll"]
* pipe("hello", String.match(/x/)) // null
* ```
*
* @category searching
* @since 2.0.0
*/
var match$2 = (regExp) => (self) => self.match(regExp);
/**
* It is the `pipe`-able version of the native `matchAll` method.
*
* @example
* ```ts
* import { pipe, String } from "effect"
*
* const matches = pipe("hello world", String.matchAll(/l/g))
* console.log(Array.from(matches)) // [["l"], ["l"], ["l"]]
* ```
*
* @category searching
* @since 2.0.0
*/
var matchAll = (regExp) => (self) => self.matchAll(regExp);
/**
* Normalizes a string according to the specified Unicode normalization form.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* const str = "\u1E9B\u0323"
* assert.deepStrictEqual(pipe(str, String.normalize()), "\u1E9B\u0323")
* assert.deepStrictEqual(pipe(str, String.normalize("NFC")), "\u1E9B\u0323")
* assert.deepStrictEqual(pipe(str, String.normalize("NFD")), "\u017F\u0323\u0307")
* assert.deepStrictEqual(pipe(str, String.normalize("NFKC")), "\u1E69")
* assert.deepStrictEqual(
*   pipe(str, String.normalize("NFKD")),
*   "\u0073\u0323\u0307"
* )
* ```
*
* @category transforming
* @since 2.0.0
*/
var normalize = (form) => (self) => self.normalize(form);
/**
* Pads the string from the end with a given fill string to a specified length.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("a", String.padEnd(5)), "a    ")
* assert.deepStrictEqual(pipe("a", String.padEnd(5, "_")), "a____")
* ```
*
* @category transforming
* @since 2.0.0
*/
var padEnd = (maxLength, fillString) => (self) => self.padEnd(maxLength, fillString);
/**
* Pads the string from the start with a given fill string to a specified length.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("a", String.padStart(5)), "    a")
* assert.deepStrictEqual(pipe("a", String.padStart(5, "_")), "____a")
* ```
*
* @category transforming
* @since 2.0.0
*/
var padStart = (maxLength, fillString) => (self) => self.padStart(maxLength, fillString);
/**
* Repeats the string the specified number of times.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("a", String.repeat(5)), "aaaaa")
* assert.deepStrictEqual(pipe("hello", String.repeat(3)), "hellohellohello")
* ```
*
* @category transforming
* @since 2.0.0
*/
var repeat$2 = (count) => (self) => self.repeat(count);
/**
* Replaces all occurrences of a substring or pattern in a string.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(pipe("ababb", String.replaceAll("b", "c")), "acacc")
* assert.deepStrictEqual(pipe("ababb", String.replaceAll(/ba/g, "cc")), "accbb")
* ```
*
* @category transforming
* @since 2.0.0
*/
var replaceAll = (searchValue, replaceValue) => (self) => self.replaceAll(searchValue, replaceValue);
/**
* Searches for a match between a regular expression and the string.
*
* **Example**
*
* ```ts
* import { String } from "effect"
*
* String.search("ababb", "b") // 1
* String.search("ababb", "/abb/") // 2
* String.search("ababb", "d") // undefined
* ```
*
* @category searching
* @since 2.0.0
*/
var search = /*#__PURE__*/ dual(2, (self, regExp) => {
	const out = self.search(regExp);
	return out >= 0 ? out : void 0;
});
/**
* Converts the string to lowercase according to the specified locale.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* const str = "\u0130"
* assert.deepStrictEqual(pipe(str, String.toLocaleLowerCase("tr")), "i")
* ```
*
* @category transforming
* @since 2.0.0
*/
var toLocaleLowerCase = (locale) => (self) => self.toLocaleLowerCase(locale);
/**
* Converts the string to uppercase according to the specified locale.
*
* @example
* ```ts
* import { pipe, String } from "effect"
* import * as assert from "node:assert"
*
* const str = "i\u0307"
* assert.deepStrictEqual(pipe(str, String.toLocaleUpperCase("lt-LT")), "I")
* ```
*
* @category transforming
* @since 2.0.0
*/
var toLocaleUpperCase = (locale) => (self) => self.toLocaleUpperCase(locale);
/**
* Keep the specified number of characters from the start of a string.
*
* If `n` is larger than the available number of characters, the string will
* be returned whole.
*
* If `n` is not a positive number, an empty string will be returned.
*
* If `n` is a float, it will be rounded down to the nearest integer.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.takeLeft("Hello World", 5), "Hello")
* ```
*
* @category transforming
* @since 2.0.0
*/
var takeLeft = /*#__PURE__*/ dual(2, (self, n) => self.slice(0, Math.max(n, 0)));
/**
* Keep the specified number of characters from the end of a string.
*
* If `n` is larger than the available number of characters, the string will
* be returned whole.
*
* If `n` is not a positive number, an empty string will be returned.
*
* If `n` is a float, it will be rounded down to the nearest integer.
*
* @example
* ```ts
* import { String } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(String.takeRight("Hello World", 5), "World")
* ```
*
* @category transforming
* @since 2.0.0
*/
var takeRight = /*#__PURE__*/ dual(2, (self, n) => self.slice(Math.max(0, self.length - Math.floor(n)), Infinity));
var CR = 13;
var LF = 10;
/**
* Returns an `IterableIterator` which yields each line contained within the
* string, trimming off the trailing newline character.
*
* @example
* ```ts
* import { String } from "effect"
*
* const lines = String.linesIterator("hello\nworld\n")
* console.log(Array.from(lines)) // ["hello", "world"]
* ```
*
* @category splitting
* @since 2.0.0
*/
var linesIterator = (self) => linesSeparated(self, true);
/**
* Returns an `IterableIterator` which yields each line contained within the
* string as well as the trailing newline character.
*
* @example
* ```ts
* import { String } from "effect"
*
* const lines = String.linesWithSeparators("hello\nworld\n")
* console.log(Array.from(lines)) // ["hello\n", "world\n"]
* ```
*
* @category splitting
* @since 2.0.0
*/
var linesWithSeparators = (s) => linesSeparated(s, false);
/**
* For every line in this string, strip a leading prefix consisting of blanks
* or control characters followed by the character specified by `marginChar`
* from the line.
*
* @example
* ```ts
* import { String } from "effect"
*
* const text = "  |hello\n  |world"
* const result = String.stripMarginWith(text, "|")
* console.log(result) // "hello\nworld"
* ```
*
* @category transforming
* @since 2.0.0
*/
var stripMarginWith = /*#__PURE__*/ dual(2, (self, marginChar) => {
	let out = "";
	for (const line of linesWithSeparators(self)) {
		let index = 0;
		while (index < line.length && line.charAt(index) <= " ") index = index + 1;
		const stripped = index < line.length && line.charAt(index) === marginChar ? line.substring(index + 1) : line;
		out = out + stripped;
	}
	return out;
});
/**
* For every line in this string, strip a leading prefix consisting of blanks
* or control characters followed by the `"|"` character from the line.
*
* @example
* ```ts
* import { String } from "effect"
*
* const text = "  |hello\n  |world"
* const result = String.stripMargin(text)
* console.log(result) // "hello\nworld"
* ```
*
* @category transforming
* @since 2.0.0
*/
var stripMargin = (self) => stripMarginWith(self, "|");
/**
* Converts a snake_case string to camelCase.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.snakeToCamel("hello_world")) // "helloWorld"
* console.log(String.snakeToCamel("foo_bar_baz")) // "fooBarBaz"
* ```
*
* @category transforming
* @since 2.0.0
*/
var snakeToCamel = (self) => {
	let str = self[0];
	for (let i = 1; i < self.length; i++) str += self[i] === "_" ? self[++i].toUpperCase() : self[i];
	return str;
};
/**
* Converts a snake_case string to PascalCase.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.snakeToPascal("hello_world")) // "HelloWorld"
* console.log(String.snakeToPascal("foo_bar_baz")) // "FooBarBaz"
* ```
*
* @category transforming
* @since 2.0.0
*/
var snakeToPascal = (self) => {
	let str = self[0].toUpperCase();
	for (let i = 1; i < self.length; i++) str += self[i] === "_" ? self[++i].toUpperCase() : self[i];
	return str;
};
/**
* Converts a snake_case string to kebab-case.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.snakeToKebab("hello_world")) // "hello-world"
* console.log(String.snakeToKebab("foo_bar_baz")) // "foo-bar-baz"
* ```
*
* @category transforming
* @since 2.0.0
*/
var snakeToKebab = (self) => self.replace(/_/g, "-");
/**
* Converts a camelCase string to snake_case.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.camelToSnake("helloWorld")) // "hello_world"
* console.log(String.camelToSnake("fooBarBaz")) // "foo_bar_baz"
* ```
*
* @category transforming
* @since 2.0.0
*/
var camelToSnake = (self) => self.replace(/([A-Z])/g, "_$1").toLowerCase();
/**
* Converts a PascalCase string to snake_case.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.pascalToSnake("HelloWorld")) // "hello_world"
* console.log(String.pascalToSnake("FooBarBaz")) // "foo_bar_baz"
* ```
*
* @category transforming
* @since 2.0.0
*/
var pascalToSnake = (self) => (self.slice(0, 1) + self.slice(1).replace(/([A-Z])/g, "_$1")).toLowerCase();
/**
* Converts a kebab-case string to snake_case.
*
* @example
* ```ts
* import { String } from "effect"
*
* console.log(String.kebabToSnake("hello-world")) // "hello_world"
* console.log(String.kebabToSnake("foo-bar-baz")) // "foo_bar_baz"
* ```
*
* @category transforming
* @since 2.0.0
*/
var kebabToSnake = (self) => self.replace(/-/g, "_");
var LinesIterator = class LinesIterator {
	index;
	length;
	s;
	stripped;
	constructor(s, stripped = false) {
		this.s = s;
		this.stripped = stripped;
		this.index = 0;
		this.length = s.length;
	}
	next() {
		if (this.done) return {
			done: true,
			value: void 0
		};
		const start = this.index;
		while (!this.done && !isLineBreak(this.s[this.index])) this.index = this.index + 1;
		let end = this.index;
		if (!this.done) {
			const char = this.s[this.index];
			this.index = this.index + 1;
			if (!this.done && isLineBreak2(char, this.s[this.index])) this.index = this.index + 1;
			if (!this.stripped) end = this.index;
		}
		return {
			done: false,
			value: this.s.substring(start, end)
		};
	}
	[Symbol.iterator]() {
		return new LinesIterator(this.s, this.stripped);
	}
	get done() {
		return this.index >= this.length;
	}
};
/**
* Test if the provided character is a line break character (i.e. either `"\r"`
* or `"\n"`).
*/
var isLineBreak = (char) => {
	const code = char.charCodeAt(0);
	return code === CR || code === LF;
};
/**
* Test if the provided characters combine to form a carriage return/line-feed
* (i.e. `"\r\n"`).
*/
var isLineBreak2 = (char0, char1) => char0.charCodeAt(0) === CR && char1.charCodeAt(0) === LF;
var linesSeparated = (self, stripped) => new LinesIterator(self, stripped);
/**
* Normalize a string to a specific case format
*
* @category transforming
* @since 4.0.0
*/
var noCase = /*#__PURE__*/ dual((args) => typeof args[0] === "string", (input, options) => {
	const delimiter = options?.delimiter ?? " ";
	const transform = options?.transform ?? toLowerCase;
	const result = input.replace(SPLIT_REGEXP[0], "$1\0$2").replace(SPLIT_REGEXP[1], "$1\0$2").replace(STRIP_REGEXP, "\0");
	let start = 0;
	let end = result.length;
	while (result.charAt(start) === "\0") start++;
	while (result.charAt(end - 1) === "\0") end--;
	return result.slice(start, end).split("\0").map(transform).join(delimiter);
});
var SPLIT_REGEXP = [/([a-z0-9])([A-Z])/g, /([A-Z])([A-Z][a-z])/g];
var STRIP_REGEXP = /[^A-Z0-9]+/gi;
var pascalCaseTransform = (input, index) => {
	const firstChar = input.charAt(0);
	const lowerChars = input.substring(1).toLowerCase();
	if (index > 0 && firstChar >= "0" && firstChar <= "9") return `_${firstChar}${lowerChars}`;
	return `${firstChar.toUpperCase()}${lowerChars}`;
};
/**
* Converts a string to PascalCase.
*
* @since 4.0.0
* @category transforming
*/
var pascalCase = /*#__PURE__*/ noCase({
	delimiter: "",
	transform: pascalCaseTransform
});
var camelCaseTransform = (input, index) => index === 0 ? input.toLowerCase() : pascalCaseTransform(input, index);
/**
* Converts a string to camelCase.
*
* @since 4.0.0
* @category transforming
*/
var camelCase = /*#__PURE__*/ noCase({
	delimiter: "",
	transform: camelCaseTransform
});
/**
* Converts a string to CONSTANT_CASE (uppercase with underscores).
*
* @since 4.0.0
* @category transforming
*/
var constantCase = /*#__PURE__*/ noCase({
	delimiter: "_",
	transform: toUpperCase
});
/**
* Converts a string to kebab-case (lowercase with hyphens).
*
* @since 4.0.0
* @category transforming
*/
var kebabCase = /*#__PURE__*/ noCase({ delimiter: "-" });
/**
* Converts a string to snake_case (lowercase with underscores).
*
* @since 4.0.0
* @category transforming
*/
var snakeCase = /*#__PURE__*/ noCase({ delimiter: "_" });
/**
* A `Reducer` for concatenating `string`s.
*
* @since 4.0.0
*/
var ReducerConcat = /*#__PURE__*/ make$12((a, b) => a + b, "");
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Cron.js
/**
* @since 2.0.0
*/
var Cron_exports = /* @__PURE__ */ __exportAll({
	CronParseError: () => CronParseError,
	Equivalence: () => Equivalence,
	equals: () => equals,
	isCron: () => isCron,
	isCronParseError: () => isCronParseError,
	make: () => make,
	match: () => match$1,
	next: () => next,
	parse: () => parse,
	parseUnsafe: () => parseUnsafe,
	sequence: () => sequence
});
var TypeId$4 = "~effect/time/Cron";
function toPojo(cron) {
	return {
		tz: cron.tz,
		seconds: fromIterable(cron.seconds),
		minutes: fromIterable(cron.minutes),
		hours: fromIterable(cron.hours),
		days: fromIterable(cron.days),
		months: fromIterable(cron.months),
		weekdays: fromIterable(cron.weekdays)
	};
}
var CronProto = {
	[TypeId$4]: TypeId$4,
	[symbol$2](that) {
		return isCron(that) && equals(this, that);
	},
	[symbol$1]() {
		return pipe(hash(this.tz), combine$1(array(fromIterable(this.seconds))), combine$1(array(fromIterable(this.minutes))), combine$1(array(fromIterable(this.hours))), combine$1(array(fromIterable(this.days))), combine$1(array(fromIterable(this.months))), combine$1(array(fromIterable(this.weekdays))));
	},
	toObject() {
		return {
			tz: this.tz,
			seconds: fromIterable(this.seconds),
			minutes: fromIterable(this.minutes),
			hours: fromIterable(this.hours),
			days: fromIterable(this.days),
			months: fromIterable(this.months),
			weekdays: fromIterable(this.weekdays)
		};
	},
	toString() {
		return `Cron(${format$2(toPojo(this))})`;
	},
	toJSON() {
		const out = toPojo(this);
		out["_id"] = "Cron";
		return out;
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Checks if a given value is a Cron instance.
*
* This function is a type guard that determines whether the provided
* value is a valid Cron instance by checking for the presence of the
* Cron type identifier.
*
* @example
* ```ts
* import { Cron } from "effect"
*
* const cron = Cron.make({
*   minutes: [0],
*   hours: [9],
*   days: [1, 15],
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [1, 2, 3, 4, 5]
* })
*
* console.log(Cron.isCron(cron)) // true
* console.log(Cron.isCron({})) // false
* console.log(Cron.isCron("not a cron")) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isCron = (u) => hasProperty(u, TypeId$4);
/**
* Creates a Cron instance from time constraints.
*
* Constructs a cron schedule by specifying which seconds, minutes, hours,
* days, months, and weekdays the schedule should match. Empty arrays mean
* "match all" for that time unit.
*
* @example
* ```ts
* import { Cron } from "effect"
*
* // Every day at midnight
* const midnight = Cron.make({
*   minutes: [0],
*   hours: [0],
*   days: [
*     1,
*     2,
*     3,
*     4,
*     5,
*     6,
*     7,
*     8,
*     9,
*     10,
*     11,
*     12,
*     13,
*     14,
*     15,
*     16,
*     17,
*     18,
*     19,
*     20,
*     21,
*     22,
*     23,
*     24,
*     25,
*     26,
*     27,
*     28,
*     29,
*     30,
*     31
*   ],
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [0, 1, 2, 3, 4, 5, 6]
* })
*
* // Every 15 minutes during business hours on weekdays
* const businessHours = Cron.make({
*   minutes: [0, 15, 30, 45],
*   hours: [9, 10, 11, 12, 13, 14, 15, 16, 17],
*   days: [
*     1,
*     2,
*     3,
*     4,
*     5,
*     6,
*     7,
*     8,
*     9,
*     10,
*     11,
*     12,
*     13,
*     14,
*     15,
*     16,
*     17,
*     18,
*     19,
*     20,
*     21,
*     22,
*     23,
*     24,
*     25,
*     26,
*     27,
*     28,
*     29,
*     30,
*     31
*   ],
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [1, 2, 3, 4, 5] // Monday to Friday
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var make = (values) => {
	const o = Object.create(CronProto);
	o.seconds = new Set(sort(values.seconds ?? [0], Order$1));
	o.minutes = new Set(sort(values.minutes, Order$1));
	o.hours = new Set(sort(values.hours, Order$1));
	o.days = new Set(sort(values.days, Order$1));
	o.months = new Set(sort(values.months, Order$1));
	o.weekdays = new Set(sort(values.weekdays, Order$1));
	o.tz = values.tz;
	const seconds = Array.from(o.seconds);
	const minutes = Array.from(o.minutes);
	const hours = Array.from(o.hours);
	const days = Array.from(o.days);
	const months = Array.from(o.months);
	const weekdays = Array.from(o.weekdays);
	o.first = {
		second: seconds[0] ?? 0,
		minute: minutes[0] ?? 0,
		hour: hours[0] ?? 0,
		day: days[0] ?? 1,
		month: (months[0] ?? 1) - 1,
		weekday: weekdays[0] ?? 0
	};
	o.next = {
		second: nextLookupTable(seconds, 60),
		minute: nextLookupTable(minutes, 60),
		hour: nextLookupTable(hours, 24),
		day: nextLookupTable(days, 32),
		month: nextLookupTable(months, 13),
		weekday: nextLookupTable(weekdays, 7)
	};
	return o;
};
var nextLookupTable = (values, size) => {
	const result = new Array(size).fill(void 0);
	if (values.length === 0) return result;
	let current = void 0;
	let index = values.length - 1;
	for (let i = size - 1; i >= 0; i--) {
		while (index >= 0 && values[index] >= i) current = values[index--];
		result[i] = current;
	}
	return result;
};
var CronParseErrorTypeId = "~effect/time/Cron/CronParseError";
/**
* Represents an error that occurs when parsing a cron expression fails.
*
* This error provides detailed information about what went wrong during
* the parsing process, including the error message and optionally the
* input that caused the error.
*
* @example
* ```ts
* import { Cron, Result } from "effect"
*
* const result = Cron.parse("invalid expression")
* if (Result.isFailure(result)) {
*   const error: Cron.CronParseError = result.failure
*   console.log(error.message) // "Invalid number of segments in cron expression"
*   console.log(error.input) // "invalid expression"
* }
* ```
*
* @since 4.0.0
* @category models
*/
/**
* @category Models
* @since 4.0.0
*/
var CronParseError = class extends TaggedError("CronParseError") {
	[CronParseErrorTypeId] = CronParseErrorTypeId;
};
/**
* Checks if a given value is a CronParseError instance.
*
* This function is a type guard that determines whether the provided
* value is a CronParseError by checking for the presence of the
* CronParseError type identifier.
*
* @example
* ```ts
* import { Cron, Result } from "effect"
*
* const result = Cron.parse("invalid cron expression")
* if (Result.isFailure(result)) {
*   const error = result.failure
*   console.log(Cron.isCronParseError(error)) // true
* }
*
* console.log(Cron.isCronParseError(new Error("regular error"))) // false
* console.log(Cron.isCronParseError("not an error")) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isCronParseError = (u) => hasProperty(u, CronParseErrorTypeId);
/**
* Parses a cron expression into a `Cron` instance.
*
* @param cron - The cron expression to parse.
*
* @example
* ```ts
* import { Cron, Result } from "effect"
* import * as assert from "node:assert"
*
* // At 04:00 on every day-of-month from 8 through 14.
* assert.deepStrictEqual(
*   Cron.parse("0 0 4 8-14 * *"),
*   Result.succeed(Cron.make({
*     seconds: [0],
*     minutes: [0],
*     hours: [4],
*     days: [8, 9, 10, 11, 12, 13, 14],
*     months: [],
*     weekdays: []
*   }))
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var parse = (cron, tz) => {
	const segments = cron.split(" ").filter(isNonEmpty);
	if (segments.length !== 5 && segments.length !== 6) return fail$6(new CronParseError({
		message: `Invalid number of segments in cron expression`,
		input: cron
	}));
	if (segments.length === 5) segments.unshift("0");
	const [seconds, minutes, hours, days, months, weekdays] = segments;
	return all$2({
		tz: tz === void 0 || isTimeZone(tz) ? succeed$6(tz) : match$7(zoneFromString(tz), {
			onUndefined: () => fail$6(new CronParseError({
				message: `Invalid time zone in cron expression`,
				input: tz
			})),
			onDefined: (zone) => succeed$6(zone)
		}),
		seconds: parseSegment(seconds, secondOptions),
		minutes: parseSegment(minutes, minuteOptions),
		hours: parseSegment(hours, hourOptions),
		days: parseSegment(days, dayOptions),
		months: parseSegment(months, monthOptions),
		weekdays: parseSegment(weekdays, weekdayOptions)
	}).pipe(map$9(make));
};
/**
* Parses a cron expression into a Cron instance, throwing on failure.
*
* This function provides a convenience method for parsing cron expressions
* when you're confident the input is valid and want to avoid handling
* the Result type.
*
* @example
* ```ts
* import { Cron } from "effect"
*
* // At 04:00 on every day-of-month from 8 through 14
* const cron = Cron.parseUnsafe("0 0 4 8-14 * *")
*
* // With timezone
* const cronWithTz = Cron.parseUnsafe("0 0 9 * * *", "America/New_York")
*
* // This would throw an error
* // const invalid = Cron.parseUnsafe("invalid expression")
* ```
*
* @since 2.0.0
* @category constructors
*/
var parseUnsafe = (cron, tz) => getOrThrow$1(parse(cron, tz));
/**
* Checks if a given date/time falls within an active Cron time window.
*
* This function determines whether a specific date and time matches
* the cron schedule, taking into account all time constraints and
* the optional timezone.
*
* @example
* ```ts
* import { Cron, Result } from "effect"
*
* const cron = Result.getOrThrow(Cron.parse("0 0 4 8-14 * *"))
*
* // Check if specific dates match
* const matches1 = Cron.match(cron, new Date("2021-01-08T04:00:00Z"))
* console.log(matches1) // true - 4 AM on the 8th
*
* const matches2 = Cron.match(cron, new Date("2021-01-08T05:00:00Z"))
* console.log(matches2) // false - wrong hour
*
* const matches3 = Cron.match(cron, new Date("2021-01-07T04:00:00Z"))
* console.log(matches3) // false - wrong day
* ```
*
* @since 2.0.0
* @category utils
*/
var match$1 = (cron, date) => {
	const parts = makeZonedUnsafe(date, { timeZone: cron.tz }).pipe(toParts);
	if (cron.seconds.size !== 0 && !cron.seconds.has(parts.seconds)) return false;
	if (cron.minutes.size !== 0 && !cron.minutes.has(parts.minutes)) return false;
	if (cron.hours.size !== 0 && !cron.hours.has(parts.hours)) return false;
	if (cron.months.size !== 0 && !cron.months.has(parts.month)) return false;
	if (cron.days.size === 0 && cron.weekdays.size === 0) return true;
	if (cron.weekdays.size === 0) return cron.days.has(parts.day);
	if (cron.days.size === 0) return cron.weekdays.has(parts.weekDay);
	return cron.days.has(parts.day) || cron.weekdays.has(parts.weekDay);
};
var daysInMonth = (date) => new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0)).getUTCDate();
/**
* Returns the next scheduled date/time for the given Cron instance.
*
* This function calculates the next date and time when the cron schedule
* should trigger, starting from the specified date (or current time if
* not provided).
*
* @example
* ```ts
* import { Cron, Result } from "effect"
*
* const cron = Result.getOrThrow(Cron.parse("0 0 4 8-14 * *"))
*
* // Get next run after a specific date
* const after = new Date("2021-01-01T00:00:00Z")
* const nextRun = Cron.next(cron, after)
* console.log(nextRun) // 2021-01-08T04:00:00.000Z
*
* // Get next run from current time
* const nextFromNow = Cron.next(cron)
* console.log(nextFromNow) // Next occurrence from now
* ```
*
* @since 2.0.0
* @category utils
*/
var next = (cron, now) => {
	const tz = cron.tz;
	const zoned = makeZonedUnsafe(now ?? /* @__PURE__ */ new Date(), { timeZone: tz });
	const adjustDst = tz !== void 0 && isTimeZoneNamed(tz) && tz.id === "UTC" ? constVoid : (current) => {
		const adjusted = makeZonedUnsafe(current, {
			timeZone: zoned.zone,
			adjustForTimeZone: true
		}).pipe(toDate);
		const drift = current.getTime() - adjusted.getTime();
		if (drift > 0) current.setTime(current.getTime() + drift);
	};
	return toDateUtc(mutate(zoned, (current) => {
		current.setUTCSeconds(current.getUTCSeconds() + 1, 0);
		for (let i = 0; i < 1e4; i++) {
			if (cron.seconds.size !== 0) {
				const currentSecond = current.getUTCSeconds();
				const nextSecond = cron.next.second[currentSecond];
				if (nextSecond === void 0) {
					current.setUTCMinutes(current.getUTCMinutes() + 1, cron.first.second);
					adjustDst(current);
					continue;
				}
				if (nextSecond > currentSecond) {
					current.setUTCSeconds(nextSecond);
					adjustDst(current);
					continue;
				}
			}
			if (cron.minutes.size !== 0) {
				const currentMinute = current.getUTCMinutes();
				const nextMinute = cron.next.minute[currentMinute];
				if (nextMinute === void 0) {
					current.setUTCHours(current.getUTCHours() + 1, cron.first.minute, cron.first.second);
					adjustDst(current);
					continue;
				}
				if (nextMinute > currentMinute) {
					current.setUTCMinutes(nextMinute, cron.first.second);
					adjustDst(current);
					continue;
				}
			}
			if (cron.hours.size !== 0) {
				const currentHour = current.getUTCHours();
				const nextHour = cron.next.hour[currentHour];
				if (nextHour === void 0) {
					current.setUTCDate(current.getUTCDate() + 1);
					current.setUTCHours(cron.first.hour, cron.first.minute, cron.first.second);
					adjustDst(current);
					continue;
				}
				if (nextHour > currentHour) {
					current.setUTCHours(nextHour, cron.first.minute, cron.first.second);
					adjustDst(current);
					continue;
				}
			}
			if (cron.weekdays.size !== 0 || cron.days.size !== 0) {
				let a = Infinity;
				let b = Infinity;
				if (cron.weekdays.size !== 0) {
					const currentWeekday = current.getUTCDay();
					const nextWeekday = cron.next.weekday[currentWeekday];
					a = nextWeekday === void 0 ? 7 - currentWeekday + cron.first.weekday : nextWeekday - currentWeekday;
				}
				if (cron.days.size !== 0 && a !== 0) {
					const currentDay = current.getUTCDate();
					const nextDay = cron.next.day[currentDay];
					b = nextDay === void 0 ? daysInMonth(current) - currentDay + cron.first.day : nextDay - currentDay;
				}
				const addDays = Math.min(a, b);
				if (addDays !== 0) {
					current.setUTCDate(current.getUTCDate() + addDays);
					current.setUTCHours(cron.first.hour, cron.first.minute, cron.first.second);
					adjustDst(current);
					continue;
				}
			}
			if (cron.months.size !== 0) {
				const currentMonth = current.getUTCMonth() + 1;
				const nextMonth = cron.next.month[currentMonth];
				if (nextMonth === void 0) {
					current.setUTCFullYear(current.getUTCFullYear() + 1);
					current.setUTCMonth(cron.first.month, cron.first.day);
					current.setUTCHours(cron.first.hour, cron.first.minute, cron.first.second);
					adjustDst(current);
					continue;
				}
				if (nextMonth > currentMonth) {
					current.setUTCMonth(nextMonth - 1, cron.first.day);
					current.setUTCHours(cron.first.hour, cron.first.minute, cron.first.second);
					adjustDst(current);
					continue;
				}
			}
			return;
		}
		throw new Error("Unable to find next cron date");
	}));
};
/**
* Returns an infinite iterator that yields dates matching the Cron schedule.
*
* This function creates an iterator that generates an infinite sequence
* of dates when the cron schedule should trigger, starting from the
* specified date.
*
* @example
* ```ts
* import { Cron, Result } from "effect"
*
* const cron = Result.getOrThrow(Cron.parse("0 0 9 * * 1-5")) // 9 AM weekdays
*
* // Get first 5 occurrences
* const iterator = Cron.sequence(cron, new Date("2023-01-01"))
* const next5 = Array.from({ length: 5 }, () => iterator.next().value)
*
* console.log(next5)
* // [Mon Jan 02 2023 09:00:00, Tue Jan 03 2023 09:00:00, ...]
* ```
*
* @since 2.0.0
* @category utils
*/
var sequence = function* (cron, now) {
	while (true) yield now = next(cron, now);
};
/**
* An Equivalence instance for comparing Cron schedules.
*
* This equivalence compares two Cron instances by checking if their
* time constraints (seconds, minutes, hours, days, months, weekdays)
* are equivalent, regardless of the internal order.
*
* @example
* ```ts
* import { Cron } from "effect"
*
* const cron1 = Cron.make({
*   minutes: [0, 30],
*   hours: [9],
*   days: [1, 15],
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [1, 2, 3, 4, 5]
* })
*
* const cron2 = Cron.make({
*   minutes: [30, 0], // Different order
*   hours: [9],
*   days: [15, 1], // Different order
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [1, 2, 3, 4, 5]
* })
*
* console.log(Cron.Equivalence(cron1, cron2)) // true
* ```
*
* @since 2.0.0
* @category instances
*/
var Equivalence = /*#__PURE__*/ make$14((self, that) => restrictionsEquals(self.seconds, that.seconds) && restrictionsEquals(self.minutes, that.minutes) && restrictionsEquals(self.hours, that.hours) && restrictionsEquals(self.days, that.days) && restrictionsEquals(self.months, that.months) && restrictionsEquals(self.weekdays, that.weekdays));
var restrictionsArrayEquals = /*#__PURE__*/ Array$3(/*#__PURE__*/ strictEqual());
var restrictionsEquals = (self, that) => restrictionsArrayEquals(fromIterable(self), fromIterable(that));
/**
* Checks if two Cron instances are equal.
*
* This function compares two Cron instances to determine if they represent
* the same schedule by checking all their time constraints for equality.
*
* @example
* ```ts
* import { Cron } from "effect"
*
* const cron1 = Cron.make({
*   minutes: [0],
*   hours: [9],
*   days: [1, 15],
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [1, 2, 3, 4, 5]
* })
*
* const cron2 = Cron.make({
*   minutes: [0],
*   hours: [9],
*   days: [1, 15],
*   months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
*   weekdays: [1, 2, 3, 4, 5]
* })
*
* console.log(Cron.equals(cron1, cron2)) // true
* console.log(Cron.equals(cron1)(cron2)) // true (curried form)
* ```
*
* @since 2.0.0
* @category predicates
*/
var equals = /*#__PURE__*/ dual(2, (self, that) => Equivalence(self, that));
var secondOptions = {
	min: 0,
	max: 59
};
var minuteOptions = {
	min: 0,
	max: 59
};
var hourOptions = {
	min: 0,
	max: 23
};
var dayOptions = {
	min: 1,
	max: 31
};
var monthOptions = {
	min: 1,
	max: 12,
	aliases: {
		jan: 1,
		feb: 2,
		mar: 3,
		apr: 4,
		may: 5,
		jun: 6,
		jul: 7,
		aug: 8,
		sep: 9,
		oct: 10,
		nov: 11,
		dec: 12
	}
};
var weekdayOptions = {
	min: 0,
	max: 6,
	aliases: {
		sun: 0,
		mon: 1,
		tue: 2,
		wed: 3,
		thu: 4,
		fri: 5,
		sat: 6
	}
};
var parseSegment = (input, options) => {
	const capacity = options.max - options.min + 1;
	const values = /* @__PURE__ */ new Set();
	const fields = input.split(",");
	for (const field of fields) {
		const [raw, step] = splitStep(field);
		if (raw === "*" && step === void 0) return succeed$6(/* @__PURE__ */ new Set());
		if (step !== void 0) {
			if (!Number.isInteger(step)) return fail$6(new CronParseError({
				message: `Expected step value to be a positive integer`,
				input
			}));
			if (step < 1) return fail$6(new CronParseError({
				message: `Expected step value to be greater than 0`,
				input
			}));
			if (step > options.max) return fail$6(new CronParseError({
				message: `Expected step value to be less than ${options.max}`,
				input
			}));
		}
		if (raw === "*") for (let i = options.min; i <= options.max; i += step ?? 1) values.add(i);
		else {
			const [left, right] = splitRange(raw, options.aliases);
			if (!Number.isInteger(left)) return fail$6(new CronParseError({
				message: `Expected a positive integer`,
				input
			}));
			if (left < options.min || left > options.max) return fail$6(new CronParseError({
				message: `Expected a value between ${options.min} and ${options.max}`,
				input
			}));
			if (right === void 0) values.add(left);
			else {
				if (!Number.isInteger(right)) return fail$6(new CronParseError({
					message: `Expected a positive integer`,
					input
				}));
				if (right < options.min || right > options.max) return fail$6(new CronParseError({
					message: `Expected a value between ${options.min} and ${options.max}`,
					input
				}));
				if (left > right) return fail$6(new CronParseError({
					message: `Invalid value range`,
					input
				}));
				for (let i = left; i <= right; i += step ?? 1) values.add(i);
			}
		}
		if (values.size >= capacity) return succeed$6(/* @__PURE__ */ new Set());
	}
	return succeed$6(values);
};
var splitStep = (input) => {
	const separator = input.indexOf("/");
	if (separator !== -1) return [input.slice(0, separator), Number(input.slice(separator + 1))];
	return [input, void 0];
};
var splitRange = (input, aliases) => {
	const separator = input.indexOf("-");
	if (separator !== -1) return [aliasOrValue(input.slice(0, separator), aliases), aliasOrValue(input.slice(separator + 1), aliases)];
	return [aliasOrValue(input, aliases), void 0];
};
function aliasOrValue(field, aliases) {
	return aliases?.[field.toLocaleLowerCase()] ?? Number(field);
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/random.js
/** @internal */
var Random = /*#__PURE__*/ Reference("effect/Random", { defaultValue: () => ({
	nextIntUnsafe() {
		return Math.floor(Math.random() * (Number.MAX_SAFE_INTEGER - Number.MIN_SAFE_INTEGER + 1)) + Number.MIN_SAFE_INTEGER;
	},
	nextDoubleUnsafe() {
		return Math.random();
	}
}) });
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Pull.js
/**
* @since 4.0.0
*/
var Pull_exports = /* @__PURE__ */ __exportAll({
	catchDone: () => catchDone,
	doneExitFromCause: () => doneExitFromCause,
	filterDone: () => filterDone,
	filterDoneLeftover: () => filterDoneLeftover,
	filterDoneVoid: () => filterDoneVoid,
	filterNoDone: () => filterNoDone,
	isDoneCause: () => isDoneCause,
	isDoneFailure: () => isDoneFailure,
	matchEffect: () => matchEffect$1
});
/**
* @since 4.0.0
* @category Done
*/
var catchDone = /*#__PURE__*/ dual(2, (effect, f) => catchCauseFilter$1(effect, filterDoneLeftover, (l) => f(l)));
/**
* Checks if a Cause contains any done errors.
*
* @since 4.0.0
* @category Done
*/
var isDoneCause = (cause) => cause.reasons.some(isDoneFailure);
/**
* Checks if a Cause failure is a done error.
*
* @since 4.0.0
* @category Done
*/
var isDoneFailure = (failure) => failure._tag === "Fail" && isDone$1(failure.error);
/**
* Filters a Cause to extract only halt errors.
*
* @since 4.0.0
* @category Done
*/
var filterDone = /*#__PURE__*/ composePassthrough(findError$1, (e) => isDone$1(e) ? succeed$6(e) : fail$6(e));
/**
* Filters a Cause to extract only halt errors.
*
* @since 4.0.0
* @category Done
*/
var filterDoneVoid = /*#__PURE__*/ composePassthrough(findError$1, (e) => isDone$1(e) ? succeed$6(e) : fail$6(e));
/**
* @since 4.0.0
* @category Done
*/
var filterNoDone = /*#__PURE__*/ fromPredicate((cause) => cause.reasons.every((failure) => !isDoneFailure(failure)));
/**
* Filters a Cause to extract the leftover value from done errors.
*
* @since 4.0.0
* @category Done
*/
var filterDoneLeftover = /*#__PURE__*/ composePassthrough(findError$1, (e) => isDone$1(e) ? succeed$6(e.value) : fail$6(e));
/**
* Converts a Cause into an Exit, extracting halt leftovers as success values.
*
* @since 4.0.0
* @category Done
*/
var doneExitFromCause = (cause) => {
	const halt = filterDone(cause);
	return !isFailure$3(halt) ? succeed$4(halt.success.value) : failCause$3(halt.failure);
};
/**
* Pattern matches on a Pull, handling success, failure, and done cases.
*
* @example
* ```ts
* import { Cause, Effect, Pull } from "effect"
*
* const pull = Cause.done("stream ended")
*
* const result = Pull.matchEffect(pull, {
*   onSuccess: (value) => Effect.succeed(`Got value: ${value}`),
*   onFailure: (cause) => Effect.succeed(`Got error: ${cause}`),
*   onDone: (leftover) => Effect.succeed(`Stream halted with: ${leftover}`)
* })
* ```
*
* @since 4.0.0
* @category pattern matching
*/
var matchEffect$1 = /*#__PURE__*/ dual(2, (self, options) => matchCauseEffect$1(self, {
	onSuccess: options.onSuccess,
	onFailure: (cause) => {
		const halt = filterDone(cause);
		return !isFailure$3(halt) ? options.onDone(halt.success.value) : options.onFailure(halt.failure);
	}
}));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Schedule.js
/**
* This module provides utilities for creating and composing schedules for retrying operations,
* repeating effects, and implementing various timing strategies.
*
* A Schedule is a function that takes an input and returns a decision whether to continue or halt,
* along with a delay duration. Schedules can be combined, transformed, and used to implement
* sophisticated retry and repetition logic.
*
* @example
* ```ts
* import { Effect, Schedule } from "effect"
*
* // Retry with exponential backoff
* const retryPolicy = Schedule.exponential("100 millis", 2.0)
*   .pipe(Schedule.compose(Schedule.recurs(3)))
*
* const program = Effect.gen(function*() {
*   // This will retry up to 3 times with exponential backoff
*   const result = yield* Effect.retry(
*     Effect.fail("Network error"),
*     retryPolicy
*   )
* })
*
* // Repeat on a fixed schedule
* const heartbeat = Effect.log("heartbeat")
*   .pipe(Effect.repeat(Schedule.spaced("30 seconds")))
* ```
*
* @since 2.0.0
*/
var Schedule_exports = /* @__PURE__ */ __exportAll({
	CurrentMetadata: () => CurrentMetadata,
	addDelay: () => addDelay,
	andThen: () => andThen$1,
	andThenResult: () => andThenResult,
	both: () => both,
	bothLeft: () => bothLeft,
	bothRight: () => bothRight,
	bothWith: () => bothWith,
	collectInputs: () => collectInputs,
	collectOutputs: () => collectOutputs,
	collectWhile: () => collectWhile,
	compose: () => compose,
	cron: () => cron,
	delays: () => delays,
	duration: () => duration,
	during: () => during,
	either: () => either,
	eitherLeft: () => eitherLeft,
	eitherRight: () => eitherRight,
	eitherWith: () => eitherWith,
	elapsed: () => elapsed,
	exponential: () => exponential,
	fibonacci: () => fibonacci,
	fixed: () => fixed,
	forever: () => forever$1,
	fromStep: () => fromStep,
	fromStepWithMetadata: () => fromStepWithMetadata,
	identity: () => identity_,
	isSchedule: () => isSchedule,
	jittered: () => jittered,
	map: () => map$1,
	modifyDelay: () => modifyDelay,
	passthrough: () => passthrough,
	recurs: () => recurs,
	reduce: () => reduce,
	satisfiesErrorType: () => satisfiesErrorType$1,
	satisfiesInputType: () => satisfiesInputType,
	satisfiesOutputType: () => satisfiesOutputType,
	satisfiesServicesType: () => satisfiesServicesType$1,
	setInputType: () => setInputType,
	spaced: () => spaced,
	take: () => take,
	tapInput: () => tapInput,
	tapOutput: () => tapOutput,
	toStep: () => toStep,
	toStepWithMetadata: () => toStepWithMetadata,
	toStepWithSleep: () => toStepWithSleep,
	unfold: () => unfold,
	while: () => while_,
	windowed: () => windowed
});
var TypeId$3 = "~effect/Schedule";
var randomNext = /*#__PURE__*/ Random.useSync((random) => random.nextDoubleUnsafe());
/**
* @since 4.0.0
* @category Metadata
*/
var CurrentMetadata = /*#__PURE__*/ Reference("effect/Schedule/CurrentMetadata", { defaultValue: /*#__PURE__*/ constant({
	input: void 0,
	output: void 0,
	duration: zero,
	attempt: 0,
	start: 0,
	now: 0,
	elapsed: 0,
	elapsedSincePrevious: 0
}) });
var ScheduleProto = {
	[TypeId$3]: {
		_Out: identity,
		_In: identity,
		_Env: identity
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Type guard that checks if a value is a Schedule.
*
* @example
* ```ts
* import { Schedule } from "effect"
*
* const schedule = Schedule.exponential("100 millis")
* const notSchedule = { foo: "bar" }
*
* console.log(Schedule.isSchedule(schedule)) // true
* console.log(Schedule.isSchedule(notSchedule)) // false
* console.log(Schedule.isSchedule(null)) // false
* console.log(Schedule.isSchedule(undefined)) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isSchedule = (u) => hasProperty(u, TypeId$3);
/**
* Creates a Schedule from a step function that returns a Pull.
*
* @example
* ```ts
* import { Schedule } from "effect"
*
* // fromStep is an advanced function for creating custom schedules
* // It requires a step function that returns a Pull value
*
* // Most users should use simpler schedule constructors like:
* const simpleSchedule = Schedule.exponential("100 millis")
* const spacedSchedule = Schedule.spaced("1 second")
* const recurringSchedule = Schedule.recurs(5)
*
* // These can be combined and transformed as needed
* const complexSchedule = simpleSchedule.pipe(
*   Schedule.compose(Schedule.recurs(3))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromStep = (step) => {
	const self = Object.create(ScheduleProto);
	self.step = step;
	return self;
};
var metadataFn = () => {
	let n = 0;
	let previous;
	let start;
	return (now, input) => {
		if (start === void 0) start = now;
		const elapsed = now - start;
		const elapsedSincePrevious = previous === void 0 ? 0 : now - previous;
		previous = now;
		return {
			input,
			attempt: ++n,
			start,
			now,
			elapsed,
			elapsedSincePrevious
		};
	};
};
/**
* Creates a Schedule from a step function that receives metadata about the schedule's execution.
*
* @example
* ```ts
* import { Effect, Schedule } from "effect"
*
* // fromStepWithMetadata is an advanced function for creating schedules
* // that need access to execution metadata like timing and recurrence count
*
* // Most users should use simpler metadata-aware functions like:
* const metadataSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.collectWhile((metadata) => Effect.succeed(metadata.attempt <= 5))
* )
*
* // Or use existing schedules with metadata transformations:
* const conditionalSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.tapOutput((output) => Effect.log(`Output: ${output}`))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromStepWithMetadata = (step) => fromStep(map$4(step, (f) => {
	const meta = metadataFn();
	return (now, input) => f(meta(now, input));
}));
/**
* Extracts the step function from a Schedule.
*
* @example
* ```ts
* import { Effect, Schedule } from "effect"
*
* // Extract step function from an existing schedule
* const schedule = Schedule.exponential("100 millis").pipe(Schedule.take(3))
*
* const program = Effect.gen(function*() {
*   const stepFn = yield* Schedule.toStep(schedule)
*
*   // Use the step function directly for custom logic
*   const now = Date.now()
*   const result = yield* stepFn(now, "input")
*
*   console.log(`Step result: ${result}`)
* })
* ```
*
* @since 4.0.0
* @category destructors
*/
var toStep = (schedule) => catchCause$2(schedule.step, (cause) => succeed$5(() => failCause$4(cause)));
/**
* Extracts a step function from a Schedule that provides metadata about each
* execution. It will also handle sleeping for the computed delay.
*
* @since 4.0.0
* @category destructors
*/
var toStepWithMetadata = (schedule) => clockWith$2((clock) => map$4(toStep(schedule), (step) => {
	const metaFn = metadataFn();
	return (input) => suspend$1(() => {
		const now = clock.currentTimeMillisUnsafe();
		return flatMap$2(step(now, input), ([output, duration]) => {
			const meta = metaFn(now, input);
			meta.output = output;
			meta.duration = duration;
			return as$1(sleep$1(duration), meta);
		});
	});
}));
/**
* Extracts a step function from a Schedule that automatically handles sleep delays.
*
* @example
* ```ts
* import { Effect, Schedule } from "effect"
*
* // Convert schedule to step function with automatic sleeping
* const schedule = Schedule.spaced("1 second").pipe(Schedule.take(3))
*
* const program = Effect.gen(function*() {
*   const stepWithSleep = yield* Schedule.toStepWithSleep(schedule)
*
*   // Each call will automatically sleep for the scheduled delay
*   console.log("Starting...")
*   const result1 = yield* stepWithSleep("first")
*   console.log(`First result: ${result1}`)
*
*   const result2 = yield* stepWithSleep("second")
*   console.log(`Second result: ${result2}`)
*
*   const result3 = yield* stepWithSleep("third")
*   console.log(`Third result: ${result3}`)
* })
* ```
*
* @since 4.0.0
* @category destructors
*/
var toStepWithSleep = (schedule) => map$4(toStepWithMetadata(schedule), (step) => (input) => map$4(step(input), (meta) => meta.output));
/**
* Returns a new `Schedule` that adds the delay computed by the specified
* effectful function to the the next recurrence of the schedule.
*
* @example
* ```ts
* import { Console, Duration, Effect, Schedule } from "effect"
*
* // Add random jitter to schedule delays
* const jitteredSchedule = Schedule.addDelay(
*   Schedule.exponential("100 millis").pipe(Schedule.take(5)),
*   (output) =>
*     // Add random jitter between 0-50ms
*     Effect.succeed(Duration.millis(Math.random() * 50))
* )
*
* const jitterProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log(`Task executed at ${new Date().toISOString()}`)
*       return "jittered task"
*     }),
*     jitteredSchedule.pipe(
*       Schedule.tapOutput((delay) =>
*         Console.log(`Base delay with jitter applied`)
*       )
*     )
*   )
* })
*
* // Add adaptive delay based on execution count
* const adaptiveSchedule = Schedule.addDelay(
*   Schedule.recurs(6),
*   (executionCount) =>
*     // Increase delay as execution count grows
*     Effect.succeed(Duration.millis(executionCount * 200))
* )
*
* const adaptiveProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Adaptive delay task")
*       return "adaptive"
*     }),
*     adaptiveSchedule.pipe(
*       Schedule.tapOutput((count) =>
*         Console.log(`Execution ${count + 1} with adaptive delay`)
*       )
*     )
*   )
* })
*
* // Add effectful delay computation
* const dynamicSchedule = Schedule.addDelay(
*   Schedule.spaced("1 second").pipe(Schedule.take(4)),
*   (executionNumber) =>
*     // Simulate checking system load and return additional delay
*     Effect.succeed(Duration.millis(Math.random() > 0.7 ? 2000 : 500))
* )
*
* const dynamicProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Dynamic delay task")
*       return "dynamic"
*     }),
*     dynamicSchedule
*   )
* })
*
* // Add delay based on previous execution results (30% extra)
* const resultBasedSchedule = Schedule.addDelay(
*   Schedule.fibonacci("200 millis").pipe(Schedule.take(5)),
*   (fibonacciDelay) =>
*     Effect.succeed(Duration.millis(Duration.toMillis(fibonacciDelay) * 0.3))
* )
*
* const resultProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Result-based delay task")
*       return Math.random()
*     }),
*     resultBasedSchedule.pipe(
*       Schedule.tapOutput((delay) => Console.log(`Fibonacci delay: ${delay}`))
*     )
*   )
* })
*
* // Combine with retry for progressive backoff
* const progressiveRetrySchedule = Schedule.addDelay(
*   Schedule.exponential("50 millis").pipe(Schedule.take(4)),
*   () => Effect.succeed(Duration.millis(100)) // Fixed additional delay
* )
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       if (attempt < 5) {
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*       return `Success on attempt ${attempt}`
*     }),
*     progressiveRetrySchedule
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var addDelay = /*#__PURE__*/ dual(2, (self, f) => modifyDelay(self, (output, delay) => map$4(f(output), (d) => sum$1(fromInputUnsafe(d), fromInputUnsafe(delay)))));
/**
* Returns a new `Schedule` that will first execute the left (i.e. `self`)
* schedule to completion. Once the left schedule is complete, the right (i.e.
* `other`) schedule will be executed to completion.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // First retry 3 times quickly, then switch to slower retries
* const quickRetries = Schedule.exponential("100 millis").pipe(
*   Schedule.take(3)
* )
* const slowRetries = Schedule.exponential("1 second").pipe(
*   Schedule.take(2)
* )
*
* const combinedRetries = Schedule.andThen(quickRetries, slowRetries)
*
* const program = Effect.gen(function*() {
*   let attempt = 0
*   yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Attempt ${attempt}`)
*       if (attempt < 6) {
*         yield* Effect.fail(new Error(`Failure ${attempt}`))
*       }
*       return `Success on attempt ${attempt}`
*     }),
*     combinedRetries
*   )
* })
* ```
*
* @since 2.0.0
* @category sequencing
*/
var andThen$1 = /*#__PURE__*/ dual(2, (self, other) => map$1(andThenResult(self, other), (result) => succeed$5(merge$3(result))));
/**
* Returns a new `Schedule` that will first execute the left (i.e. `self`)
* schedule to completion. Once the left schedule is complete, the right (i.e.
* `other`) schedule will be executed to completion.
*
* The output of the resulting schedule is a `Result` where outputs of the
* left schedule are emitted as `Result.Err<Output>` and outputs of the right
* schedule are emitted as `Result.Ok<Output>`.
*
* @example
* ```ts
* import { Console, Effect, Result, Schedule } from "effect"
*
* // Track which phase of the schedule we're in
* const phaseTracker = Schedule.andThenResult(
*   Schedule.exponential("100 millis").pipe(Schedule.take(2)),
*   Schedule.spaced("500 millis").pipe(Schedule.take(2))
* )
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-result"
*     }),
*     phaseTracker.pipe(
*       Schedule.tapOutput((result) =>
*         Result.match(result, {
*           onFailure: (phase1Output) => Console.log(`Phase 1: ${phase1Output}`),
*           onSuccess: (phase2Output) => Console.log(`Phase 2: ${phase2Output}`)
*         })
*       )
*     )
*   )
* })
* ```
*
* @since 2.0.0
* @category sequencing
*/
var andThenResult = /*#__PURE__*/ dual(2, (self, other) => fromStep(sync$3(() => {
	let currentSide = 0;
	let currentStep;
	const left = map$1(self, succeed$6);
	const right = map$1(other, fail$6);
	return function recur(now, input) {
		if (currentStep) return currentStep(now, input);
		return toStep(currentSide === 0 ? left : right).pipe(flatMap$2((step) => {
			currentSide++;
			if (currentSide === 1) {
				currentStep = (now, input) => catchDone(step(now, input), (_) => {
					currentStep = void 0;
					return recur(now, input);
				});
				return currentStep(now, input);
			}
			currentStep = step;
			return currentStep(now, input);
		}));
	};
})));
/**
* Combines two `Schedule`s by recurring if both of the two schedules want
* to recur, using the maximum of the two durations between recurrences and
* outputting a tuple of the outputs of both schedules.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Both schedules must want to continue for the combined schedule to continue
* const timeLimit = Schedule.spaced("1 second").pipe(Schedule.take(5)) // max 5 times
* const attemptLimit = Schedule.recurs(3) // max 3 attempts
*
* // Continues only while BOTH schedules want to continue (intersection/AND logic)
* const bothSchedule = Schedule.both(timeLimit, attemptLimit)
* // Outputs: [time_result, attempt_count] tuple
*
* const program = Effect.gen(function*() {
*   const results = yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log(`Task executed at ${new Date().toISOString()}`)
*       return "task completed"
*     }),
*     bothSchedule.pipe(
*       Schedule.tapOutput(([timeResult, attemptResult]) =>
*         Console.log(`Time: ${timeResult}, Attempts: ${attemptResult}`)
*       )
*     )
*   )
*
*   yield* Console.log("Completed all executions")
* })
*
* // Both with different delay strategies - uses maximum delay
* const fastSchedule = Schedule.fixed("500 millis").pipe(Schedule.take(4))
* const slowSchedule = Schedule.spaced("2 seconds").pipe(Schedule.take(6))
*
* // Will use the slower (maximum) delay and stop when first schedule exhausts
* const conservativeSchedule = Schedule.both(fastSchedule, slowSchedule)
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Retry attempt ${attempt}`)
*
*       if (attempt < 3) {
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     conservativeSchedule
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Both provides intersection semantics (AND logic)
* // Compare with either which provides union semantics (OR logic)
* ```
*
* @since 2.0.0
* @category utilities
*/
var both = /*#__PURE__*/ dual(2, (self, other) => bothWith(self, other, (left, right) => [left, right]));
/**
* Combines two `Schedule`s by recurring if both of the two schedules want
* to recur, using the maximum of the two durations between recurrences and
* outputting the result of the left schedule (i.e. `self`).
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Combine two schedules, keeping left output
* const leftSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("left-result"))
* )
* const rightSchedule = Schedule.spaced("50 millis")
*
* const combined = Schedule.bothLeft(leftSchedule, rightSchedule)
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-done"
*     }),
*     combined.pipe(Schedule.take(3))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var bothLeft = /*#__PURE__*/ dual(2, (self, other) => bothWith(self, other, (output) => output));
/**
* Combines two `Schedule`s by recurring if both of the two schedules want
* to recur, using the maximum of the two durations between recurrences and
* outputting the result of the right schedule (i.e. `other`).
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Combine two schedules, keeping right output
* const leftSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("left-result"))
* )
* const rightSchedule = Schedule.spaced("50 millis").pipe(
*   Schedule.map(() => Effect.succeed("right-result"))
* )
*
* const combined = Schedule.bothRight(leftSchedule, rightSchedule)
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-done"
*     }),
*     combined.pipe(Schedule.take(3))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var bothRight = /*#__PURE__*/ dual(2, (self, other) => bothWith(self, other, (_, output) => output));
/**
* Combines two `Schedule`s by recurring if both of the two schedules want
* to recur, using the maximum of the two durations between recurrences and
* outputting the result of the combination of both schedule outputs using the
* specified `combine` function.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Combine two schedules with custom output combination
* const leftSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("left"))
* )
* const rightSchedule = Schedule.spaced("50 millis").pipe(
*   Schedule.map(() => Effect.succeed("right"))
* )
*
* const combined = Schedule.bothWith(
*   leftSchedule,
*   rightSchedule,
*   (left, right) => `${left}-${right}`
* )
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-result"
*     }),
*     combined.pipe(Schedule.take(3))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var bothWith = /*#__PURE__*/ dual(3, (self, other, combine) => fromStep(map$4(zip$1(toStep(self), toStep(other)), ([stepLeft, stepRight]) => (now, input) => matchEffect$1(stepLeft(now, input), {
	onSuccess: (leftResult) => stepRight(now, input).pipe(map$4((rightResult) => [combine(leftResult[0], rightResult[0]), max$2(leftResult[1], rightResult[1])]), catchDone((rightDone) => done$1(combine(leftResult[0], rightDone)))),
	onDone: (leftDone) => stepRight(now, input).pipe(flatMap$2((rightResult) => done$1(combine(leftDone, rightResult[0]))), catchDone((rightDone) => done$1(combine(leftDone, rightDone)))),
	onFailure: failCause$4
}))));
/**
* Returns a new `Schedule` that combines two schedules by running them
* sequentially. First the current schedule runs to completion, then the
* other schedule runs to completion. The output is a tuple of both results.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Compose a quick retry phase followed by slower retry phase
* const fastRetries = Schedule.exponential("100 millis").pipe(
*   Schedule.compose(Schedule.recurs(3)) // 3 fast retries
* )
*
* const slowRetries = Schedule.exponential("2 seconds").pipe(
*   Schedule.compose(Schedule.recurs(2)) // 2 slow retries
* )
*
* // Sequential composition: fast retries first, then slow retries
* const composedRetry = Schedule.compose(fastRetries, slowRetries)
* // Outputs: [number_from_fast_phase, number_from_slow_phase]
*
* const program = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Attempt ${attempt}`)
*
*       if (attempt < 7) { // Needs both phases to succeed
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     composedRetry.pipe(
*       Schedule.tapOutput(([fastResult, slowResult]) =>
*         Console.log(`Fast phase: ${fastResult}, Slow phase: ${slowResult}`)
*       )
*     )
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Compose different schedule types
* const warmupAndMaintenance = Schedule.compose(
*   Schedule.fixed("500 millis").pipe(Schedule.take(5)), // 5 warmup cycles
*   Schedule.spaced("5 seconds") // then regular maintenance
* )
*
* // Progressive backoff: fixed first, then exponential
* const progressiveBackoff = Schedule.compose(
*   Schedule.fixed("100 millis").pipe(Schedule.take(3)), // Fixed: 100ms, 100ms, 100ms
*   Schedule.exponential("500 millis").pipe(Schedule.take(3)) // Then exponential: 500ms, 1s, 2s
* )
* ```
*
* @since 2.0.0
* @category sequencing
*/
var compose = /*#__PURE__*/ dual(2, (self, other) => both(self, other));
/**
* Returns a new `Schedule` that always recurs, collecting all inputs of the
* schedule into an array.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Collect all inputs passed to the schedule
* const inputCollector = Schedule.collectInputs(
*   Schedule.spaced("100 millis")
* )
*
* const program = Effect.gen(function*() {
*   let counter = 0
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       counter++
*       yield* Console.log(`Iteration ${counter}`)
*       return `result-${counter}`
*     }),
*     inputCollector.pipe(Schedule.take(4))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var collectInputs = (self) => collectWhile(passthrough(self), () => succeed$5(true));
/**
* Returns a new `Schedule` that always recurs, collecting all outputs of the
* schedule into an array.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Collect all outputs from the schedule
* const outputCollector = Schedule.collectOutputs(
*   Schedule.recurs(4)
* )
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-result"
*     }),
*     outputCollector.pipe(Schedule.take(4))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var collectOutputs = (self) => collectWhile(self, () => succeed$5(true));
/**
* Returns a new `Schedule` that recurs as long as the specified `predicate`
* returns `true`, collecting all outputs of the schedule into an array.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Collect outputs while under time limit
* const collectForTime = Schedule.collectWhile(
*   Schedule.spaced("500 millis"),
*   (metadata) => Effect.succeed(metadata.elapsed < 3000) // Stop after 3 seconds
* )
*
* const timeBasedProgram = Effect.gen(function*() {
*   const results = yield* Effect.repeat(
*     Effect.gen(function*() {
*       const value = Math.floor(Math.random() * 100)
*       yield* Console.log(`Generated value: ${value}`)
*       return value
*     }),
*     collectForTime
*   )
*
*   yield* Console.log(
*     `Collected ${results.length} values: [${results.join(", ")}]`
*   )
* })
*
* // Collect outputs while condition is met
* const collectWhileSmall = Schedule.collectWhile(
*   Schedule.exponential("100 millis"),
*   (metadata) =>
*     Effect.succeed(metadata.attempt <= 5 && metadata.elapsed < 2000)
* )
*
* const conditionalProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const delays = yield* Effect.repeat(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Retry attempt ${attempt}`)
*       return `${Date.now()}`
*     }),
*     collectWhileSmall
*   )
*
*   yield* Console.log(`Collected attempts: [${delays.join(", ")}]`)
* })
*
* // Collect with effectful predicate
* const collectWithCheck = Schedule.collectWhile(
*   Schedule.fixed("1 second"),
*   (metadata) =>
*     Effect.gen(function*() {
*       const shouldContinue = metadata.attempt < 5
*       yield* Console.log(
*         `Check ${metadata.attempt}: continue = ${shouldContinue}`
*       )
*       return shouldContinue
*     })
* )
*
* const effectfulProgram = Effect.gen(function*() {
*   const timestamps = yield* Effect.repeat(
*     Effect.gen(function*() {
*       const now = new Date().toISOString()
*       yield* Console.log(`Task at ${now}`)
*       return now
*     }),
*     collectWithCheck
*   )
*
*   yield* Console.log(`Final collection: ${timestamps.length} items`)
* })
*
* // Collect samples with condition
* const collectSamples = Schedule.collectWhile(
*   Schedule.spaced("200 millis"),
*   (metadata) =>
*     Effect.succeed(metadata.attempt <= 5 && metadata.elapsed < 2000)
* )
*
* const samplingProgram = Effect.gen(function*() {
*   const samples = yield* Effect.repeat(
*     Effect.gen(function*() {
*       const sample = Math.random() * 100
*       yield* Console.log(`Sample: ${sample.toFixed(1)}`)
*       return sample
*     }),
*     collectSamples
*   )
*
*   const average = samples.reduce((sum, s) => sum + s, 0) / samples.length
*   yield* Console.log(
*     `Collected ${samples.length} samples, average: ${average.toFixed(1)}`
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var collectWhile = /*#__PURE__*/ dual(2, (self, predicate) => reduce(while_(self, predicate), () => [], (outputs, output) => {
	outputs.push(output);
	return outputs;
}));
/**
* Returns a new `Schedule` that recurs on the specified `Cron` schedule and
* outputs the duration between recurrences.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Run every minute
* const everyMinute = Schedule.cron("* * * * *")
*
* const minutelyProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log(`Minutely task at ${new Date().toISOString()}`)
*       return "minute"
*     }),
*     everyMinute.pipe(
*       Schedule.take(3), // Run only 3 times for demo
*       Schedule.tapOutput((duration) =>
*         Console.log(`Next execution in: ${duration}`)
*       )
*     )
*   )
* })
*
* // Run every day at 2:30 AM
* const dailyBackup = Schedule.cron("30 2 * * *")
*
* const backupProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Running daily backup...")
*       // Simulate backup process
*       yield* Effect.sleep("2 seconds")
*       yield* Console.log("Backup completed")
*       return "backup-done"
*     }),
*     dailyBackup.pipe(
*       Schedule.take(2) // Run 2 times for demo
*     )
*   )
* })
*
* // Run every Monday at 9:00 AM with timezone
* const weeklyReport = Schedule.cron("0 9 * * 1", "America/New_York")
*
* const reportProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Generating weekly report...")
*       const report = {
*         week: Math.floor(Date.now() / (7 * 24 * 60 * 60 * 1000)),
*         timestamp: new Date().toISOString()
*       }
*       yield* Console.log(`Report generated: ${JSON.stringify(report)}`)
*       return report
*     }),
*     weeklyReport.pipe(Schedule.take(1))
*   )
* })
*
* // Run every 15 minutes during business hours (9 AM - 5 PM)
* const businessHoursCheck = Schedule.cron("0,15,30,45 9-17 * * 1-5")
*
* const businessProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Business hours health check...")
*       const status = Math.random() > 0.1 ? "healthy" : "degraded"
*       yield* Console.log(`System status: ${status}`)
*       return status
*     }),
*     businessHoursCheck.pipe(
*       Schedule.take(4) // Demo with 4 checks
*     )
*   )
* })
*
* // Run on specific days of the month
* const monthlyInvoice = Schedule.cron("0 10 1,15 * *") // 1st and 15th at 10 AM
*
* const invoiceProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Processing monthly invoices...")
*       const invoiceCount = Math.floor(Math.random() * 100) + 50
*       yield* Console.log(`Processed ${invoiceCount} invoices`)
*       return { count: invoiceCount, date: new Date().toISOString() }
*     }),
*     monthlyInvoice.pipe(Schedule.take(1))
*   )
* })
*
* // Complex cron with error handling
* const complexCron = Schedule.cron("0 2,4,6 * * *").pipe(
*   Schedule.tapOutput((duration) =>
*     Console.log(`Scheduled to run again in ${duration}`)
*   )
* )
*
* const robustProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Complex scheduled task...")
*       // Simulate occasional failures
*       if (Math.random() < 0.3) {
*         yield* Effect.fail(new Error("Scheduled task failed"))
*       }
*       return "success"
*     }),
*     complexCron.pipe(Schedule.take(3))
*   ).pipe(
*     Effect.catch((error: unknown) =>
*       Console.log(`Cron task error: ${String(error)}`)
*     )
*   )
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var cron = (expression, tz) => {
	return fromStep(map$4((isCron(expression) ? succeed$6(expression) : parse(expression, tz)).asEffect(), (cron) => (now, _) => sync$3(() => {
		const duration = millis(next(cron, now).getTime() - now);
		return [duration, duration];
	})));
};
/**
* Returns a new schedule that outputs the delay between each occurence.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Extract delays from an exponential backoff schedule
* const exponentialDelays = Schedule.delays(
*   Schedule.exponential("100 millis").pipe(Schedule.take(5))
* )
*
* const delayProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task result"
*     }),
*     exponentialDelays.pipe(
*       Schedule.tapOutput((delay) =>
*         Console.log(`Waiting ${delay} before next execution`)
*       )
*     )
*   )
* })
*
* // Monitor delays from a fibonacci schedule
* const fibonacciDelays = Schedule.delays(
*   Schedule.fibonacci("200 millis").pipe(Schedule.take(8))
* )
*
* const fibDelayProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Console.log("Fibonacci task"),
*     fibonacciDelays.pipe(
*       Schedule.tapOutput((delay) => Console.log(`Fibonacci delay: ${delay}`))
*     )
*   )
* })
*
* // Extract delays for analysis or logging
* const analyzeDelays = Schedule.delays(
*   Schedule.spaced("1 second").pipe(Schedule.take(3))
* ).pipe(
*   Schedule.tapOutput((delay) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Recorded delay: ${delay}`)
*       // In real applications, might send to metrics system
*     })
*   )
* )
*
* // Combine delays with other schedules for complex timing
* const adaptiveSchedule = Schedule.unfold(100, (delay) => Effect.succeed(delay * 1.5)).pipe(
*   Schedule.take(6)
* )
*
* const adaptiveDelays = Schedule.delays(adaptiveSchedule)
*
* const adaptiveProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Adaptive task execution")
*       return Date.now()
*     }),
*     adaptiveDelays.pipe(
*       Schedule.tapOutput((delay) => Console.log(`Adaptive delay: ${delay}`))
*     )
*   )
* })
*
* // Use delays to implement custom timing logic
* const customTimingSchedule = Schedule.delays(
*   Schedule.exponential("50 millis").pipe(Schedule.take(4))
* ).pipe(
*   Schedule.map((delay) => Effect.succeed(`Next execution in ${delay}`)),
*   Schedule.tapOutput((message) => Console.log(message))
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var delays = (self) => fromStep(map$4(toStep(self), (step) => (now, input) => catchDone(map$4(step(now, input), ([_, duration]) => [duration, duration]), (_) => done$1(zero))));
/**
* Returns a schedule that recurs once after the specified duration.
*
* The schedule outputs the configured duration for its first recurrence and
* then completes.
*
* @since 2.0.0
* @category constructors
*/
var duration = (durationInput) => {
	const duration = fromInputUnsafe(durationInput);
	return fromStepWithMetadata(succeed$5((meta) => meta.attempt === 1 ? succeed$5([duration, duration]) : done$1(zero)));
};
/**
* Returns a new `Schedule` that will always recur, but only during the
* specified `duration` of time.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Run a task for exactly 5 seconds, regardless of how many iterations
* const fiveSecondSchedule = Schedule.during("5 seconds")
*
* const timedProgram = Effect.gen(function*() {
*   const startTime = Date.now()
*
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       const elapsed = Date.now() - startTime
*       yield* Console.log(`Task executed after ${elapsed}ms`)
*       yield* Effect.sleep("500 millis") // Each task takes 500ms
*       return "task done"
*     }),
*     fiveSecondSchedule.pipe(
*       Schedule.tapOutput((elapsedDuration) =>
*         Console.log(`Total elapsed: ${elapsedDuration}`)
*       )
*     )
*   )
*
*   yield* Console.log("Time limit reached!")
* })
*
* // Combine with other schedules for time-bounded execution
* const timeAndCountLimited = Schedule.spaced("1 second").pipe(
*   Schedule.both(Schedule.during("10 seconds")), // Stop after 10 seconds OR
*   Schedule.both(Schedule.recurs(15)) // 15 attempts, whichever comes first
* )
*
* // Burst execution within time window
* const burstWindow = Schedule.during("3 seconds")
*
* const burstProgram = Effect.gen(function*() {
*   yield* Console.log("Starting burst execution...")
*
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log(`Burst task at ${new Date().toISOString()}`)
*       return Math.random()
*     }),
*     burstWindow
*   )
*
*   yield* Console.log("Burst window completed")
* })
*
* // Timed retry window - retry for up to 30 seconds
* const timedRetry = Schedule.exponential("200 millis").pipe(
*   Schedule.both(Schedule.during("30 seconds"))
* )
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Retry attempt ${attempt}`)
*
*       if (Math.random() < 0.8) { // 80% failure rate
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     timedRetry
*   )
*
*   yield* Console.log(`Result: ${result}`)
* }).pipe(
*   Effect.catch((error: unknown) => Console.log(`Timed out: ${String(error)}`))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var during = (duration) => while_(elapsed, ({ output }) => succeed$5(isLessThanOrEqualTo$2(output, fromInputUnsafe(duration))));
/**
* Combines two `Schedule`s by recurring if either of the two schedules wants
* to recur, using the minimum of the two durations between recurrences and
* outputting a tuple of the outputs of both schedules.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Either continues as long as at least one schedule wants to continue
* const timeBasedSchedule = Schedule.spaced("2 seconds").pipe(Schedule.take(3))
* const countBasedSchedule = Schedule.recurs(5)
*
* // Continues until both schedules are exhausted (either still wants to recur)
* const eitherSchedule = Schedule.either(timeBasedSchedule, countBasedSchedule)
* // Outputs: [time_result, count_result] tuple
*
* const program = Effect.gen(function*() {
*   const results = yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log(`Task executed at ${new Date().toISOString()}`)
*       return "task completed"
*     }),
*     eitherSchedule.pipe(
*       Schedule.tapOutput(([timeResult, countResult]) =>
*         Console.log(`Time: ${timeResult}, Count: ${countResult}`)
*       )
*     )
*   )
*
*   yield* Console.log(`Total executions: ${results.length}`)
* })
*
* // Either with different delay strategies
* const aggressiveRetry = Schedule.exponential("100 millis").pipe(
*   Schedule.take(3)
* )
* const fallbackRetry = Schedule.fixed("5 seconds").pipe(Schedule.take(2))
*
* // Will use the more aggressive retry until it's exhausted, then fallback
* const combinedRetry = Schedule.either(aggressiveRetry, fallbackRetry)
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Retry attempt ${attempt}`)
*
*       if (attempt < 6) {
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     combinedRetry
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Either provides union semantics (OR logic)
* // Compare with intersect which provides intersection semantics (AND logic)
* ```
*
* @since 2.0.0
* @category utilities
*/
var either = /*#__PURE__*/ dual(2, (self, other) => eitherWith(self, other, (left, right) => [left, right]));
/**
* Combines two `Schedule`s by recurring if either of the two schedules wants
* to recur, using the minimum of the two durations between recurrences and
* outputting the result of the left schedule (i.e. `self`).
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Combine two schedules with either semantics, keeping left output
* const primarySchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("primary-result")),
*   Schedule.take(2)
* )
* const backupSchedule = Schedule.spaced("500 millis").pipe(
*   Schedule.map(() => Effect.succeed("backup-result"))
* )
*
* const combined = Schedule.eitherLeft(primarySchedule, backupSchedule)
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-done"
*     }),
*     combined.pipe(Schedule.take(5))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var eitherLeft = /*#__PURE__*/ dual(2, (self, other) => eitherWith(self, other, (output) => output));
/**
* Combines two `Schedule`s by recurring if either of the two schedules wants
* to recur, using the minimum of the two durations between recurrences and
* outputting the result of the right schedule (i.e. `other`).
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Combine two schedules with either semantics, keeping right output
* const primarySchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("primary-result")),
*   Schedule.take(2)
* )
* const backupSchedule = Schedule.spaced("500 millis").pipe(
*   Schedule.map(() => Effect.succeed("backup-result"))
* )
*
* const combined = Schedule.eitherRight(primarySchedule, backupSchedule)
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-done"
*     }),
*     combined.pipe(Schedule.take(5))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var eitherRight = /*#__PURE__*/ dual(2, (self, other) => eitherWith(self, other, (_, output) => output));
/**
* Combines two `Schedule`s by recurring if either of the two schedules wants
* to recur, using the minimum of the two durations between recurrences and
* outputting the result of the combination of both schedule outputs using the
* specified `combine` function.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Combine schedules with either semantics and custom combination
* const primarySchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("primary")),
*   Schedule.take(2)
* )
* const fallbackSchedule = Schedule.spaced("500 millis").pipe(
*   Schedule.map(() => Effect.succeed("fallback"))
* )
*
* const combined = Schedule.eitherWith(
*   primarySchedule,
*   fallbackSchedule,
*   (primary, fallback) => `${primary}+${fallback}`
* )
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task-result"
*     }),
*     combined.pipe(Schedule.take(5))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var eitherWith = /*#__PURE__*/ dual(3, (self, other, combine) => fromStep(map$4(zip$1(toStep(self), toStep(other)), ([stepLeft, stepRight]) => (now, input) => matchEffect$1(stepLeft(now, input), {
	onSuccess: (leftResult) => stepRight(now, input).pipe(map$4((rightResult) => [combine(leftResult[0], rightResult[0]), min$2(leftResult[1], rightResult[1])]), catchDone((rightDone) => succeed$5([combine(leftResult[0], rightDone), leftResult[1]]))),
	onFailure: failCause$4,
	onDone: (leftDone) => stepRight(now, input).pipe(map$4((rightResult) => [combine(leftDone, rightResult[0]), rightResult[1]]), catchDone((rightDone) => done$1(combine(leftDone, rightDone))))
}))));
/**
* A schedule that always recurs and returns the total elapsed duration since the first recurrence.
*
* This schedule never stops and outputs the cumulative time that has passed since the schedule
* started executing. Useful for tracking execution time or implementing time-based logic.
*
* @returns A schedule that outputs the elapsed duration and never stops
*
* @example
* ```ts
* import { Console, Duration, Effect, Schedule } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Console.log("Running task..."),
*     Schedule.spaced("1 second").pipe(
*       Schedule.both(Schedule.elapsed),
*       Schedule.tapOutput(([count, duration]) =>
*         Console.log(`Run ${count}, elapsed: ${Duration.toMillis(duration)}ms`)
*       ),
*       Schedule.take(5)
*     )
*   )
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var elapsed = /*#__PURE__*/ fromStepWithMetadata(/*#__PURE__*/ succeed$5((meta) => succeed$5([millis(meta.elapsed), zero])));
/**
* A schedule that always recurs, but will wait a certain amount between
* repetitions, given by `base * factor.pow(n)`, where `n` is the number of
* repetitions so far. Returns the current duration between recurrences.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Basic exponential backoff with default factor of 2
* const basicExponential = Schedule.exponential("100 millis")
* // Delays: 100ms, 200ms, 400ms, 800ms, 1600ms, ...
*
* // Custom exponential backoff with factor 1.5
* const gentleExponential = Schedule.exponential("200 millis", 1.5)
* // Delays: 200ms, 300ms, 450ms, 675ms, 1012ms, ...
*
* // Retry with exponential backoff (limited to 5 attempts)
* const retryPolicy = Schedule.exponential("50 millis").pipe(
*   Schedule.compose(Schedule.recurs(5))
* )
*
* const program = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       if (attempt < 4) {
*         yield* Console.log(`Attempt ${attempt} failed, retrying...`)
*         yield* Effect.fail(new Error(`Failure ${attempt}`))
*       }
*       return `Success on attempt ${attempt}`
*     }),
*     retryPolicy
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Will retry with delays: 50ms, 100ms, 200ms before success
* ```
*
* @since 2.0.0
* @category constructors
*/
var exponential = (base, factor = 2) => {
	const baseMillis = toMillis(fromInputUnsafe(base));
	return fromStepWithMetadata(succeed$5((meta) => {
		const duration = millis(baseMillis * Math.pow(factor, meta.attempt - 1));
		return succeed$5([duration, duration]);
	}));
};
/**
* A schedule that always recurs, increasing delays by summing the preceding
* two delays (similar to the fibonacci sequence). Returns the current
* duration between recurrences.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Basic fibonacci schedule starting with 100ms
* const fibSchedule = Schedule.fibonacci("100 millis")
* // Delays: 100ms, 100ms, 200ms, 300ms, 500ms, 800ms, 1300ms, ...
*
* // Retry with fibonacci backoff for gradual increase
* const retryWithFib = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Attempt ${attempt}`)
*
*       if (attempt < 5) {
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     Schedule.fibonacci("50 millis").pipe(
*       Schedule.compose(Schedule.recurs(6)), // Maximum 6 retries
*       Schedule.tapOutput((delay) => Console.log(`Next retry in ${delay}`))
*     )
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Heartbeat with fibonacci intervals (starts fast, gets slower)
* const adaptiveHeartbeat = Effect.gen(function*() {
*   yield* Console.log(`Heartbeat at ${new Date().toISOString()}`)
*   return "pulse"
* }).pipe(
*   Effect.repeat(
*     Schedule.fibonacci("200 millis").pipe(
*       Schedule.take(8) // First 8 heartbeats
*     )
*   )
* )
*
* // Fibonacci vs exponential comparison
* const compareSchedules = Effect.gen(function*() {
*   yield* Console.log("=== Fibonacci Delays ===")
*   // 100ms, 100ms, 200ms, 300ms, 500ms, 800ms
*
*   yield* Console.log("=== Exponential Delays ===")
*   // 100ms, 200ms, 400ms, 800ms, 1600ms, 3200ms
*
*   // Fibonacci grows more slowly than exponential
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fibonacci = (one) => {
	const oneMillis = toMillis(fromInputUnsafe(one));
	return fromStep(sync$3(() => {
		let a = 0;
		let b = oneMillis;
		return constant(sync$3(() => {
			const next = a + b;
			a = b;
			b = next;
			const duration = millis(next);
			return [duration, duration];
		}));
	}));
};
/**
* Returns a `Schedule` that recurs on the specified fixed `interval` and
* outputs the number of repetitions of the schedule so far.
*
* If the action run between updates takes longer than the interval, then the
* action will be run immediately, but re-runs will not "pile up".
*
* ```
* |-----interval-----|-----interval-----|-----interval-----|
* |---------action--------||action|-----|action|-----------|
* ```
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Fixed interval schedule - runs exactly every 1 second
* const everySecond = Schedule.fixed("1 second")
*
* // Health check that runs at fixed intervals
* const healthCheck = Effect.gen(function*() {
*   yield* Console.log(`Health check at ${new Date().toISOString()}`)
*   yield* Effect.sleep("200 millis") // simulate health check work
*   return "healthy"
* }).pipe(
*   Effect.repeat(Schedule.fixed("2 seconds").pipe(Schedule.take(5)))
* )
*
* // Difference between fixed and spaced:
* // - fixed: maintains constant rate regardless of action duration
* // - spaced: waits for the duration AFTER each action completes
*
* const longRunningTask = Effect.gen(function*() {
*   yield* Console.log("Task started")
*   yield* Effect.sleep("1.5 seconds") // Longer than interval
*   yield* Console.log("Task completed")
*   return "done"
* })
*
* // Fixed schedule: if task takes 1.5s but interval is 1s,
* // next execution happens immediately (no pile-up)
* const fixedSchedule = longRunningTask.pipe(
*   Effect.repeat(Schedule.fixed("1 second").pipe(Schedule.take(3)))
* )
*
* // Comparing with spaced (waits 1s AFTER each task)
* const spacedSchedule = longRunningTask.pipe(
*   Effect.repeat(Schedule.spaced("1 second").pipe(Schedule.take(3)))
* )
*
* const program = Effect.gen(function*() {
*   yield* Console.log("=== Fixed Schedule Demo ===")
*   yield* fixedSchedule
*
*   yield* Console.log("=== Spaced Schedule Demo ===")
*   yield* spacedSchedule
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fixed = (interval) => {
	const window = toMillis(fromInputUnsafe(interval));
	return fromStepWithMetadata(succeed$5((meta) => succeed$5([meta.attempt - 1, window === 0 ? zero : millis(window - meta.elapsed % window)])));
};
/**
* Returns a new `Schedule` that maps the output of this schedule using the
* specified function.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Transform schedule output from number to string
* const countSchedule = Schedule.recurs(5).pipe(
*   Schedule.map((count) => Effect.succeed(`Execution #${count + 1}`))
* )
*
* // Map schedule delays to human-readable format
* const readableDelays = Schedule.exponential("100 millis").pipe(
*   Schedule.map((duration) => Effect.succeed(`Next retry in ${duration}`))
* )
*
* // Transform numeric output to structured data
* const structuredSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.map((recurrence) => Effect.succeed({
*     iteration: recurrence + 1,
*     timestamp: new Date().toISOString(),
*     phase: recurrence < 5 ? "warmup" as const : "steady" as const
*   }))
* )
*
* const program = Effect.gen(function*() {
*   const results = yield* Effect.repeat(
*     Effect.succeed("task completed"),
*     structuredSchedule.pipe(
*       Schedule.take(8),
*       Schedule.tapOutput((info) =>
*         Console.log(
*           `${info.phase} phase - iteration ${info.iteration} at ${info.timestamp}`
*         )
*       )
*     )
*   )
*
*   yield* Console.log(`Completed iterations`)
* })
*
* // Map with effectful transformation
* const effectfulMap = Schedule.fixed("2 seconds").pipe(
*   Schedule.map((count) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Processing count: ${count}`)
*       return count * 10
*     })
*   )
* )
*
* // Combine mapping with other schedule operations
* const complexSchedule = Schedule.fibonacci("100 millis").pipe(
*   Schedule.map((delay) => Effect.succeed(`Delay: ${delay}`))
* )
* ```
*
* @since 2.0.0
* @category mapping
*/
var map$1 = /*#__PURE__*/ dual(2, (self, f) => {
	const handle = matchEffect$1({
		onSuccess: ([output, duration]) => {
			const result = f(output);
			if (!isEffect$1(result)) return succeed$5([result, duration]);
			return map$4(result, (output) => [output, duration]);
		},
		onFailure: failCause$4,
		onDone: (output) => {
			const result = f(output);
			if (!isEffect$1(result)) return done$1(result);
			return flatMap$2(result, done$1);
		}
	});
	return fromStep(map$4(toStep(self), (step) => (now, input) => handle(step(now, input))));
});
/**
* Returns a new `Schedule` that modifies the delay of the next recurrence
* of the schedule using the specified effectual function.
*
* @example
* ```ts
* import { Console, Duration, Effect, Schedule } from "effect"
*
* // Modify delays based on output - increase delay on high iteration counts
* const adaptiveDelay = Schedule.recurs(10).pipe(
*   Schedule.modifyDelay((output, delay) => {
*     // Double the delay if we're seeing high iteration counts
*     return Effect.succeed(output > 5 ? Duration.times(delay, 2) : delay)
*   })
* )
*
* const program = Effect.gen(function*() {
*   let counter = 0
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       counter++
*       yield* Console.log(`Attempt ${counter}`)
*       return counter
*     }),
*     adaptiveDelay.pipe(Schedule.take(8))
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var modifyDelay = /*#__PURE__*/ dual(2, (self, f) => fromStep(map$4(toStep(self), (step) => (now, input) => flatMap$2(step(now, input), ([output, delay]) => map$4(f(output, delay), (delay) => [output, fromInputUnsafe(delay)])))));
/**
* Returns a new `Schedule` that randomly adjusts each recurrence delay.
*
* Delays are jittered between `80%` and `120%` of the original delay.
*
* @since 2.0.0
* @category utilities
*/
var jittered = (self) => modifyDelay(self, (_, delay) => map$4(randomNext, (random) => {
	const millis$1 = toMillis(fromInputUnsafe(delay));
	return millis(millis$1 * .8 * (1 - random) + millis$1 * 1.2 * random);
}));
/**
* Returns a new `Schedule` that outputs the inputs of the specified schedule.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Create a schedule that outputs the inputs instead of original outputs
* const inputSchedule = Schedule.passthrough(
*   Schedule.exponential("100 millis").pipe(Schedule.take(3))
* )
*
* const program = Effect.gen(function*() {
*   let counter = 0
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       counter++
*       yield* Console.log(`Task ${counter} executed`)
*       return `result-${counter}`
*     }),
*     inputSchedule
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var passthrough = (self) => fromStep(map$4(toStep(self), (step) => (now, input) => matchEffect$1(step(now, input), {
	onSuccess: (result) => succeed$5([input, result[1]]),
	onFailure: failCause$4,
	onDone: () => done$1(input)
})));
/**
* Returns a `Schedule` which can only be stepped the specified number of
* `times` before it terminates.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Basic recurs - retry at most 3 times
* const maxThreeAttempts = Schedule.recurs(3)
*
* // Retry a failing operation at most 5 times
* const program = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Attempt ${attempt}`)
*
*       if (attempt < 4) {
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     Schedule.recurs(5) // Will retry up to 5 times
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Combining recurs with other schedules for sophisticated retry logic
* const complexRetry = Schedule.exponential("100 millis").pipe(
*   Schedule.compose(Schedule.recurs(3)) // At most 3 attempts
* )
*
* // Repeat an effect exactly 10 times
* const exactlyTenTimes = Effect.gen(function*() {
*   yield* Console.log("Executing task...")
*   return Math.random()
* }).pipe(
*   Effect.repeat(Schedule.recurs(10))
* )
*
* // The schedule outputs the current recurrence count (0-based)
* const countingSchedule = Schedule.recurs(3).pipe(
*   Schedule.tapOutput((count) => Console.log(`Execution #${count + 1}`))
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var recurs = (times) => while_(forever$1, ({ attempt }) => succeed$5(attempt <= times));
/**
* Returns a new `Schedule` that combines the outputs of the provided schedule
* using the specified effectful `combine` function and starting from the
* specified `initial` state.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Sum up execution counts from a counter schedule
* const sumSchedule = Schedule.reduce(
*   Schedule.recurs(5),
*   () => 0, // Initial sum
*   (sum, count) => Effect.succeed(sum + count) // Add each count to the sum
* )
*
* const sumProgram = Effect.gen(function*() {
*   const finalSum = yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "task"
*     }),
*     sumSchedule.pipe(
*       Schedule.tapOutput((sum) => Console.log(`Running sum: ${sum}`))
*     )
*   )
*
*   yield* Console.log(`Final sum: ${finalSum}`)
* })
*
* // Build a history of execution times
* const historySchedule = Schedule.reduce(
*   Schedule.spaced("1 second").pipe(Schedule.take(4)),
*   () => [] as Array<number>, // Initial empty array
*   (history, executionNumber) => Effect.succeed([...history, Date.now()])
* )
*
* const historyProgram = Effect.gen(function*() {
*   const timeline = yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Recording timestamp...")
*       return "recorded"
*     }),
*     historySchedule
*   )
*
*   yield* Console.log(
*     `Execution timeline: ${timeline.length} timestamps recorded`
*   )
* })
*
* // Accumulate metrics with effectful combination
* const metricsAccumulator = Schedule.reduce(
*   Schedule.recurs(6),
*   () => ({ total: 0, count: 0, max: 0 }),
*   (metrics, executionCount) => Effect.succeed({
*     total: metrics.total + executionCount + 1,
*     count: metrics.count + 1,
*     max: Math.max(metrics.max, executionCount + 1)
*   })
* )
*
* const metricsProgram = Effect.gen(function*() {
*   const finalMetrics = yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Processing...")
*       return "processed"
*     }),
*     metricsAccumulator
*   )
*
*   const average = finalMetrics.total / finalMetrics.count
*   yield* Console.log(`Final metrics: ${finalMetrics.count} executions`)
*   yield* Console.log(
*     `Average delay: ${average.toFixed(1)}ms, Max delay: ${finalMetrics.max}ms`
*   )
* })
*
* // Build configuration state over time
* const configBuilder = Schedule.reduce(
*   Schedule.fixed("500 millis").pipe(Schedule.take(3)),
*   () => ({ retries: 1, timeout: 1000, backoff: 100 }),
*   (config, executionNumber) => Effect.succeed({
*     retries: config.retries + 1,
*     timeout: config.timeout * 1.5,
*     backoff: Math.min(config.backoff * 2, 5000)
*   })
* )
*
* const configProgram = Effect.gen(function*() {
*   const finalConfig = yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Updating configuration...")
*       return "updated"
*     }),
*     configBuilder.pipe(
*       Schedule.tapOutput((config) =>
*         Console.log(
*           `Config: retries=${config.retries}, timeout=${config.timeout}ms`
*         )
*       )
*     )
*   )
*
*   yield* Console.log(`Final config: ${JSON.stringify(finalConfig)}`)
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var reduce = /*#__PURE__*/ dual(3, (self, initial, combine) => fromStep(map$4(toStep(self), (step) => {
	let state = initial();
	return (now, input) => matchEffect$1(step(now, input), {
		onSuccess([output, delay]) {
			const next = combine(state, output);
			if (!isEffect$1(next)) {
				state = next;
				return succeed$5([next, delay]);
			}
			return map$4(next, (nextState) => {
				state = nextState;
				return [nextState, delay];
			});
		},
		onFailure: failCause$4,
		onDone(output) {
			const next = combine(state, output);
			return isEffect$1(next) ? flatMap$2(next, done$1) : done$1(next);
		}
	});
})));
/**
* Returns a schedule that recurs continuously, each repetition spaced the
* specified duration from the last run.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Basic spaced schedule - runs every 2 seconds
* const everyTwoSeconds = Schedule.spaced("2 seconds")
*
* // Heartbeat that runs indefinitely with fixed spacing
* const heartbeat = Effect.gen(function*() {
*   yield* Console.log(`Heartbeat at ${new Date().toISOString()}`)
* }).pipe(
*   Effect.repeat(everyTwoSeconds)
* )
*
* // Limited repeat - run only 5 times with 1-second spacing
* const limitedTask = Effect.gen(function*() {
*   yield* Console.log("Executing scheduled task...")
*   yield* Effect.sleep("500 millis") // simulate work
*   return "Task completed"
* }).pipe(
*   Effect.repeat(
*     Schedule.spaced("1 second").pipe(Schedule.take(5))
*   )
* )
*
* // Simple spaced schedule with limited repetitions
* const limitedSpaced = Schedule.spaced("100 millis").pipe(
*   Schedule.compose(Schedule.recurs(5)) // at most 5 times
* )
*
* const program = Effect.gen(function*() {
*   yield* Console.log("Starting spaced execution...")
*
*   yield* Effect.repeat(
*     Effect.succeed("work item"),
*     limitedSpaced
*   )
*
*   yield* Console.log("Completed executions")
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var spaced = (duration) => {
	const decoded = fromInputUnsafe(duration);
	return fromStepWithMetadata(succeed$5((meta) => succeed$5([meta.attempt - 1, decoded])));
};
/**
* Returns a new `Schedule` that allows execution of an effectful function for
* every input to the schedule, but does not alter the inputs and outputs of
* the schedule.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Log retry errors for debugging
* const errorLoggingSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.take(3),
*   Schedule.tapInput((error: Error) =>
*     Console.log(`Retry triggered by error: ${String(error)}`)
*   )
* )
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       if (attempt < 4) {
*         yield* Effect.fail(new Error(`Network timeout on attempt ${attempt}`))
*       }
*       return `Success on attempt ${attempt}`
*     }),
*     errorLoggingSchedule
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Monitor input frequency for metrics
* const inputMonitoringSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.take(5),
*   Schedule.tapInput((input: unknown) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Processing input at ${new Date().toISOString()}`)
*       yield* Console.log(`Input type: ${typeof input}`)
*       // In real applications, might send metrics to monitoring system
*     })
*   )
* )
*
* // Input validation with side effects
* const validatingSchedule = Schedule.fixed("500 millis").pipe(
*   Schedule.take(4),
*   Schedule.tapInput((input: any) =>
*     Effect.gen(function*() {
*       if (typeof input === "object" && input !== null) {
*         yield* Console.log(`Valid object input: ${JSON.stringify(input)}`)
*       } else {
*         yield* Console.log(`Warning: Non-object input received: ${input}`)
*       }
*     })
*   )
* )
*
* const validationProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task with validation")
*       return { data: Math.random(), timestamp: Date.now() }
*     }),
*     validatingSchedule
*   )
* })
*
* // Conditional alerting based on input
* const alertingSchedule = Schedule.exponential("200 millis").pipe(
*   Schedule.take(6),
*   Schedule.tapInput((error: Error) =>
*     Effect.gen(function*() {
*       if (String(error).includes("critical")) {
*         yield* Console.log(`🚨 CRITICAL ERROR: ${String(error)}`)
*         // In real applications, might trigger alerts or notifications
*       } else {
*         yield* Console.log(`ℹ️ Regular error: ${String(error)}`)
*       }
*     })
*   )
* )
*
* const alertProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       const isCritical = attempt === 3
*       const errorType = isCritical
*         ? "critical database failure"
*         : "temporary network issue"
*       yield* Effect.fail(new Error(errorType))
*     }),
*     alertingSchedule
*   ).pipe(
*     Effect.catch((error: unknown) =>
*       Console.log(`All retries exhausted: ${String(error)}`)
*     )
*   )
* })
*
* // Chain multiple input taps for different purposes
* const comprehensiveSchedule = Schedule.fibonacci("100 millis").pipe(
*   Schedule.take(5),
*   Schedule.tapInput((error: Error) =>
*     Console.log(`Error occurred: ${error.name}`)
*   ),
*   Schedule.tapInput((error: Error) =>
*     String(error).length > 20
*       ? Console.log("📝 Long error message detected")
*       : Effect.void
*   )
* )
* ```
*
* @since 2.0.0
* @category sequencing
*/
var tapInput = /*#__PURE__*/ dual(2, (self, f) => fromStep(map$4(toStep(self), (step) => (now, input) => andThen$2(f(input), step(now, input)))));
/**
* Returns a new `Schedule` that allows execution of an effectful function for
* every output of the schedule, but does not alter the inputs and outputs of
* the schedule.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Log schedule outputs for debugging/monitoring
* const monitoredSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.take(5),
*   Schedule.tapOutput((delay) => Console.log(`Next delay will be: ${delay}`))
* )
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       if (attempt < 4) {
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*       return `Success on attempt ${attempt}`
*     }),
*     monitoredSchedule
*   )
*
*   yield* Console.log(`Final result: ${result}`)
* })
*
* // Tap output for metrics collection
* const metricsSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.take(10),
*   Schedule.tapOutput((executionCount) =>
*     Effect.gen(function*() {
*       // Simulate metrics collection
*       yield* Console.log(`Recording metric: execution_count=${executionCount}`)
*       // In real code, this might send to monitoring system
*     })
*   )
* )
*
* // Tap output with conditional side effects
* const alertingSchedule = Schedule.fibonacci("200 millis").pipe(
*   Schedule.take(8),
*   Schedule.tapOutput((delay) =>
*     Effect.gen(function*() {
*       const delayMs = delay.toString()
*       if (delayMs.includes("1000")) { // Alert on delays >= 1 second
*         yield* Console.log(`🚨 High delay detected: ${delay}`)
*       }
*     })
*   )
* )
*
* const healthCheckProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Performing health check...")
*       // Simulate health check
*       return Math.random() > 0.7 ? "healthy" : "degraded"
*     }),
*     alertingSchedule
*   )
* })
*
* // Chain multiple taps for different purposes
* const comprehensiveSchedule = Schedule.fixed("500 millis").pipe(
*   Schedule.take(6),
*   Schedule.tapOutput((count) => Console.log(`Execution ${count + 1}`)),
*   Schedule.tapOutput((count) =>
*     count % 3 === 0
*       ? Console.log("🎯 Checkpoint reached!")
*       : Effect.void
*   )
* )
* ```
*
* @since 2.0.0
* @category sequencing
*/
var tapOutput = /*#__PURE__*/ dual(2, (self, f) => fromStep(map$4(toStep(self), (step) => (now, input) => tap$1(step(now, input), ([output]) => f(output)))));
/**
* Returns a new `Schedule` that takes at most the specified number of outputs
* from the schedule. Once the specified number of outputs is reached, the
* schedule will stop.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Limit an infinite schedule to run only 5 times
* const limitedHeartbeat = Schedule.spaced("1 second").pipe(
*   Schedule.take(5) // Will stop after 5 executions
* )
*
* const heartbeatProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log(`Heartbeat at ${new Date().toISOString()}`)
*       return "pulse"
*     }),
*     limitedHeartbeat
*   )
*
*   yield* Console.log("Heartbeat sequence completed")
* })
*
* // Limit retry attempts to a specific number
* const limitedRetry = Schedule.exponential("100 millis").pipe(
*   Schedule.take(3) // At most 3 retry attempts
* )
*
* const retryProgram = Effect.gen(function*() {
*   let attempt = 0
*
*   const result = yield* Effect.retry(
*     Effect.gen(function*() {
*       attempt++
*       yield* Console.log(`Attempt ${attempt}`)
*
*       if (attempt < 5) { // Will fail more than 3 times
*         yield* Effect.fail(new Error(`Attempt ${attempt} failed`))
*       }
*
*       return `Success on attempt ${attempt}`
*     }),
*     limitedRetry
*   )
*
*   yield* Console.log(`Result: ${result}`)
* }).pipe(
*   Effect.catch((error: unknown) =>
*     Console.log(`Failed after limited retries: ${String(error)}`)
*   )
* )
*
* // Combine take with other schedule operations
* const samplingSchedule = Schedule.fixed("500 millis").pipe(
*   Schedule.take(10), // Sample exactly 10 times
*   Schedule.map((count) => Effect.succeed(`Sample #${count + 1}`))
* )
*
* const samplingProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       const value = Math.random()
*       yield* Console.log(`Sampled value: ${value.toFixed(3)}`)
*       return value
*     }),
*     samplingSchedule.pipe(
*       Schedule.tapOutput((label) => Console.log(`Completed: ${label}`))
*     )
*   )
* })
* ```
*
* @since 2.0.0
* @category utilities
*/
var take = /*#__PURE__*/ dual(2, (self, n) => while_(self, ({ attempt }) => succeed$5(attempt <= n)));
/**
* Creates a schedule that unfolds a state by repeatedly applying a function,
* outputting the current state and computing the next state.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Counter schedule that increments by 1 each time
* const counterSchedule = Schedule.unfold(0, (n) => Effect.succeed(n + 1))
* // Outputs: 0, 1, 2, 3, 4, 5, ...
*
* const countingProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Task executed")
*       return "done"
*     }),
*     counterSchedule.pipe(
*       Schedule.take(5),
*       Schedule.tapOutput((count) => Console.log(`Count: ${count}`))
*     )
*   )
* })
*
* // Fibonacci sequence schedule
* const fibonacciSchedule = Schedule.unfold(
*   [0, 1] as [number, number],
*   ([a, b]) => Effect.succeed([b, a + b] as [number, number])
* )
* // Outputs: [0,1], [1,1], [1,2], [2,3], [3,5], [5,8], ...
*
* const fibProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Console.log("Fibonacci step"),
*     fibonacciSchedule.pipe(
*       Schedule.take(8),
*       Schedule.tapOutput(([a, b]) => Console.log(`Fib: ${a}, next: ${b}`))
*     )
*   )
* })
*
* // Effectful unfold - exponential backoff with state
* const exponentialState = Schedule.unfold(
*   100,
*   (delayMs) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Current delay: ${delayMs}ms`)
*       return Math.min(delayMs * 2, 5000) // Cap at 5 seconds
*     })
* )
*
* // Random jitter schedule
* const jitteredSchedule = Schedule.unfold(
*   1000,
*   (baseDelay) =>
*     Effect.gen(function*() {
*       const jitter = Math.random() * 200 - 100 // ±100ms jitter
*       const nextDelay = Math.max(100, baseDelay + jitter)
*       yield* Console.log(`Jittered delay: ${nextDelay.toFixed(0)}ms`)
*       return nextDelay
*     })
* )
*
* // State machine schedule
* type State = "init" | "warming" | "active" | "cooling"
* const stateMachineSchedule = Schedule.unfold("init" as State, (state) => {
*   switch (state) {
*     case "init":
*       return Effect.succeed("warming" as State)
*     case "warming":
*       return Effect.succeed("active" as State)
*     case "active":
*       return Effect.succeed("cooling" as State)
*     case "cooling":
*       return Effect.succeed("active" as State)
*   }
* })
*
* const stateMachineProgram = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("State machine step")
*       return "step"
*     }),
*     stateMachineSchedule.pipe(
*       Schedule.take(10),
*       Schedule.tapOutput((state) => Console.log(`State: ${state}`))
*     )
*   )
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var unfold = (initial, next) => fromStep(sync$3(() => {
	let state = initial;
	return constant(map$4(suspend$1(() => next(state)), (nextState) => {
		const prev = state;
		state = nextState;
		return [prev, zero];
	}));
}));
var while_ = /*#__PURE__*/ dual(2, (self, predicate) => fromStep(map$4(toStep(self), (step) => {
	const meta = metadataFn();
	return (now, input) => flatMap$2(step(now, input), (result) => {
		const [output, duration] = result;
		const eff = predicate({
			...meta(now, input),
			output,
			duration
		});
		return flatMap$2(isEffect$1(eff) ? eff : succeed$5(eff), (check) => check ? succeed$5(result) : done$1(output));
	});
})));
/**
* A schedule that divides the timeline to `interval`-long windows, and sleeps
* until the nearest window boundary every time it recurs.
*
* For example, `Schedule.windowed("10 seconds")` would produce a schedule as
* follows:
*
* ```
*      10s        10s        10s       10s
* |----------|----------|----------|----------|
* |action------|sleep---|act|-sleep|action----|
* ```
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // Execute tasks at regular intervals aligned to window boundaries
* const windowSchedule = Schedule.windowed("5 seconds")
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       const now = new Date().toISOString()
*       yield* Console.log(`Window task executed at: ${now}`)
*       return "window-task"
*     }),
*     windowSchedule.pipe(Schedule.take(4))
*   )
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var windowed = (interval) => {
	const window = toMillis(fromInputUnsafe(interval));
	return fromStepWithMetadata(succeed$5((meta) => sync$3(() => [meta.attempt - 1, window === 0 ? zero : millis(window - meta.elapsed % window)])));
};
/**
* Returns a new `Schedule` that will recur forever.
*
* The output of the schedule is the current count of its repetitions thus far
* (i.e. `0, 1, 2, ...`).
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* // A schedule that runs forever with no delay
* const infiniteSchedule = Schedule.forever
*
* const program = Effect.gen(function*() {
*   yield* Effect.repeat(
*     Effect.gen(function*() {
*       yield* Console.log("Running forever...")
*       return "continuous-task"
*     }),
*     infiniteSchedule.pipe(Schedule.take(5)) // Limit for demo
*   )
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var forever$1 = /*#__PURE__*/ spaced(zero);
var constIdentity = /*#__PURE__*/ fromStep(/*#__PURE__*/ succeed$5((_now, input) => succeed$5([input, zero])));
var identity_ = () => constIdentity;
/**
* Ensures that the provided schedule respects a specified input type.
*
* @example
* ```ts
* import { Schedule } from "effect"
*
* // Ensure schedule accepts string inputs
* const stringSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.satisfiesInputType<string>()
* )
*
* // Ensure schedule accepts number inputs
* const numberSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.satisfiesInputType<number>()
* )
*
* // Type-level constraint - this would be a compile error:
* // Schedule.recurs(3).pipe(Schedule.satisfiesInputType<CustomType>())
* // where CustomType doesn't match the schedule's input type
* ```
*
* @since 2.0.0
* @category ensuring types
*/
var satisfiesInputType = () => (self) => self;
/**
* Sets the input type of the provided schedule to a specified type, without
* altering the schedule's behavior.
*
* @since 2.0.0
* @category ensuring types
*/
var setInputType = () => (self) => self;
/**
* Ensures that the provided schedule respects a specified output type.
*
* @example
* ```ts
* import { Effect, Schedule } from "effect"
*
* // satisfiesOutputType is a type-level function for compile-time constraints
* // It ensures that a schedule's output type matches the specified type
*
* // Example with string output
* const stringSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.map(() => Effect.succeed("hello")),
*   Schedule.satisfiesOutputType<string>()
* )
* ```
*
* @since 2.0.0
* @category ensuring types
*/
var satisfiesOutputType = () => (self) => self;
/**
* Ensures that the provided schedule respects a specified error type.
*
* @example
* ```ts
* import { Data, Schedule } from "effect"
*
* // Create a custom error using Data.TaggedError
* class CustomError extends Data.TaggedError("CustomError")<{
*   message: string
* }> {}
*
* // Ensure schedule handles CustomError types
* const errorSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.satisfiesErrorType<CustomError>()
* )
*
* // Ensure schedule handles never errors (no errors)
* const safeSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.satisfiesErrorType<never>()
* )
* ```
*
* @since 2.0.0
* @category ensuring types
*/
var satisfiesErrorType$1 = () => (self) => self;
/**
* Ensures that the provided schedule respects a specified context type.
*
* @example
* ```ts
* import { Schedule } from "effect"
*
* // Define service interfaces (type-level only)
* interface Logger {
*   readonly log: (message: string) => void
* }
*
* interface Database {
*   readonly query: (sql: string) => Promise<unknown>
* }
*
* // Ensure schedule requires Logger service
* const loggerSchedule = Schedule.spaced("1 second").pipe(
*   Schedule.satisfiesServicesType<Logger>()
* )
*
* // Ensure schedule requires both Logger and Database services
* const multiServiceSchedule = Schedule.exponential("100 millis").pipe(
*   Schedule.satisfiesServicesType<Logger | Database>()
* )
* ```
*
* @since 2.0.0
* @category ensuring types
*/
var satisfiesServicesType$1 = () => (self) => self;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/layer.js
var provideLayer = (self, layer, options) => scopedWith$1((scope) => flatMap$2(options?.local ? buildWithMemoMap(layer, makeMemoMapUnsafe(), scope) : buildWithScope(layer, scope), (context) => provideServices$1(self, context)));
/** @internal */
var provide$1 = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (self, source, options) => isServiceMap(source) ? provideServices$1(self, source) : provideLayer(self, Array.isArray(source) ? mergeAll(...source) : source, options));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/schedule.js
/** @internal */
var repeatOrElse$1 = /*#__PURE__*/ dual(3, (self, schedule, orElse) => flatMap$2(toStepWithMetadata(schedule), (step) => {
	let meta = CurrentMetadata.defaultValue();
	return catch_$2(forever$2(tap$1(flatMap$2(suspend$1(() => provideService$1(self, CurrentMetadata, meta)), step), (meta_) => sync$3(() => {
		meta = meta_;
	})), { disableYield: true }), (error) => isDone$2(error) ? succeed$5(error.value) : orElse(error, meta.attempt === 0 ? none() : some$2(meta)));
}));
/** @internal */
var retryOrElse$1 = /*#__PURE__*/ dual(3, (self, policy, orElse) => flatMap$2(toStepWithMetadata(policy), (step) => {
	let meta = CurrentMetadata.defaultValue();
	let lastError;
	const loop = catch_$2(suspend$1(() => provideService$1(self, CurrentMetadata, meta)), (error) => {
		lastError = error;
		return flatMap$2(step(error), (meta_) => {
			meta = meta_;
			return loop;
		});
	});
	return catchDone(loop, (out) => internalCall(() => orElse(lastError, out)));
}));
/** @internal */
var repeat$1 = /*#__PURE__*/ dual(2, (self, options) => {
	return repeatOrElse$1(self, typeof options === "function" ? options(identity) : isSchedule(options) ? options : buildFromOptions(options), fail$5);
});
/** @internal */
var retry$1 = /*#__PURE__*/ dual(2, (self, options) => {
	return retryOrElse$1(self, typeof options === "function" ? options(identity) : isSchedule(options) ? options : buildFromOptions(options), fail$5);
});
/** @internal */
var scheduleFrom$1 = /*#__PURE__*/ dual(3, (self, initial, schedule) => flatMap$2(toStepWithMetadata(schedule), (step) => {
	let meta = CurrentMetadata.defaultValue();
	const selfWithMeta = suspend$1(() => provideService$1(self, CurrentMetadata, meta));
	return catch_$2(flatMap$2(step(initial), (meta_) => {
		meta = meta_;
		return whileLoop$1({
			while: constTrue,
			body: constant(flatMap$2(selfWithMeta, step)),
			step(meta_) {
				meta = meta_;
			}
		});
	}), (error) => isDone$2(error) ? succeed$5(error.value) : fail$5(error));
}));
var passthroughForever = /*#__PURE__*/ passthrough(forever$1);
/** @internal */
var buildFromOptions = (options) => {
	let schedule = options.schedule ?? passthroughForever;
	if (options.while) schedule = while_(schedule, ({ input }) => {
		const applied = options.while(input);
		return isEffect$1(applied) ? applied : succeed$5(applied);
	});
	if (options.until) schedule = while_(schedule, ({ input }) => {
		const applied = options.until(input);
		return isEffect$1(applied) ? map$4(applied, (b) => !b) : succeed$5(!applied);
	});
	if (options.times !== void 0) schedule = while_(schedule, ({ attempt }) => succeed$5(attempt <= options.times));
	return schedule;
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/executionPlan.js
/** @internal */
var withExecutionPlan$1 = /*#__PURE__*/ dual(2, (self, plan) => suspend$1(() => {
	let i = 0;
	let meta = {
		attempt: 0,
		stepIndex: 0
	};
	const provideMeta = provideServiceEffect$1(CurrentMetadata$1, sync$3(() => {
		meta = {
			attempt: meta.attempt + 1,
			stepIndex: i
		};
		return meta;
	}));
	let result;
	return flatMap$2(whileLoop$1({
		while: () => i < plan.steps.length && (result === void 0 || isFailure$3(result)),
		body() {
			const step = plan.steps[i];
			let nextEffect = provideMeta(provide$1(self, step.provide));
			if (result) {
				let attempted = false;
				const wrapped = nextEffect;
				nextEffect = suspend$1(() => {
					if (attempted) return wrapped;
					attempted = true;
					return result.asEffect();
				});
				nextEffect = retry$1(nextEffect, scheduleFromStep(step, false));
			} else {
				const schedule = scheduleFromStep(step, true);
				nextEffect = schedule ? retry$1(nextEffect, schedule) : nextEffect;
			}
			return result$1(nextEffect);
		},
		step(result_) {
			result = result_;
			i++;
		}
	}), () => result.asEffect());
}));
/** @internal */
var scheduleFromStep = (step, first) => {
	if (!first) return buildFromOptions({
		schedule: step.schedule ? step.schedule : step.attempts ? void 0 : scheduleOnce,
		times: step.attempts,
		while: step.while
	});
	else if (step.attempts === 1 || !(step.schedule || step.attempts)) return;
	return buildFromOptions({
		schedule: step.schedule,
		while: step.while,
		times: step.attempts ? step.attempts - 1 : void 0
	});
};
var scheduleOnce = /*#__PURE__*/ recurs(1);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Request.js
var Request_exports = /* @__PURE__ */ __exportAll({
	Class: () => Class,
	RequestPrototype: () => RequestPrototype,
	TaggedClass: () => TaggedClass,
	complete: () => complete,
	completeEffect: () => completeEffect,
	fail: () => fail$1,
	failCause: () => failCause$1,
	isRequest: () => isRequest,
	makeEntry: () => makeEntry,
	of: () => of,
	succeed: () => succeed$1,
	tagged: () => tagged
});
var TypeId$2 = "~effect/Request";
var requestVariance = /*#__PURE__*/ byReferenceUnsafe({
	/* c8 ignore next */
	_E: (_) => _,
	/* c8 ignore next */
	_A: (_) => _,
	/* c8 ignore next */
	_R: (_) => _
});
/**
* @since 4.0.0
*/
var RequestPrototype = {
	...StructuralProto,
	[TypeId$2]: requestVariance
};
/**
* Tests if a value is a `Request`.
*
* @example
* ```ts
* import { Request } from "effect"
*
* declare const User: unique symbol
* declare const UserNotFound: unique symbol
* type User = typeof User
* type UserNotFound = typeof UserNotFound
*
* interface GetUser extends Request.Request<User, UserNotFound> {
*   readonly _tag: "GetUser"
*   readonly id: string
* }
* const GetUser = Request.tagged<GetUser>("GetUser")
*
* const request = GetUser({ id: "123" })
* console.log(Request.isRequest(request)) // true
* console.log(Request.isRequest("not a request")) // false
* ```
*
* @category guards
* @since 2.0.0
*/
var isRequest = (u) => hasProperty(u, TypeId$2);
/**
* Creates a constructor function for a specific Request type.
*
* @example
* ```ts
* import { Request } from "effect"
*
* declare const UserProfile: unique symbol
* declare const ProfileError: unique symbol
* type UserProfile = typeof UserProfile
* type ProfileError = typeof ProfileError
*
* interface GetUserProfile extends Request.Request<UserProfile, ProfileError> {
*   readonly id: string
*   readonly includeSettings: boolean
* }
*
* const GetUserProfile = Request.of<GetUserProfile>()
*
* const request = GetUserProfile({
*   id: "user-123",
*   includeSettings: true
* })
* ```
*
* @category constructors
* @since 2.0.0
*/
var of = () => (args) => Object.assign(Object.create(RequestPrototype), args);
/**
* Creates a constructor function for a tagged Request type. The tag is automatically
* added to the request, making it useful for discriminated unions.
*
* @example
* ```ts
* import { Request } from "effect"
*
* declare const User: unique symbol
* declare const UserNotFound: unique symbol
* declare const Post: unique symbol
* declare const PostNotFound: unique symbol
* type User = typeof User
* type UserNotFound = typeof UserNotFound
* type Post = typeof Post
* type PostNotFound = typeof PostNotFound
*
* interface GetUser extends Request.Request<User, UserNotFound> {
*   readonly _tag: "GetUser"
*   readonly id: string
* }
*
* interface GetPost extends Request.Request<Post, PostNotFound> {
*   readonly _tag: "GetPost"
*   readonly id: string
* }
*
* const GetUser = Request.tagged<GetUser>("GetUser")
* const GetPost = Request.tagged<GetPost>("GetPost")
*
* const userRequest = GetUser({ id: "user-123" })
* const postRequest = GetPost({ id: "post-456" })
*
* // _tag is automatically set
* console.log(userRequest._tag) // "GetUser"
* console.log(postRequest._tag) // "GetPost"
* ```
*
* @category constructors
* @since 2.0.0
*/
var tagged = (tag) => (args) => {
	const request = Object.create(RequestPrototype);
	if (args) Object.assign(request, args);
	request._tag = tag;
	return request;
};
/**
* @example
* ```ts
* import { Request } from "effect"
*
* class GetUser extends Request.Class<{ id: number }, string, Error> {
*   constructor(readonly id: number) {
*     super({ id })
*   }
* }
*
* const getUserRequest = new GetUser(123)
* console.log(getUserRequest.id) // 123
* ```
*
* @since 2.0.0
* @category constructors
*/
var Class = /*#__PURE__*/ function() {
	function Class(args) {
		if (args) Object.assign(this, args);
	}
	Class.prototype = RequestPrototype;
	return Class;
}();
/**
* @example
* ```ts
* import { Request } from "effect"
*
* class GetUserById
*   extends Request.TaggedClass("GetUserById")<{ id: number }, string, Error>
* {}
*
* const request = new GetUserById({ id: 123 })
* console.log(request._tag) // "GetUserById"
* console.log(request.id) // 123
* ```
*
* @since 2.0.0
* @category constructors
*/
var TaggedClass = (tag) => {
	return class TaggedClass extends Class {
		_tag = tag;
	};
};
/**
* Completes a request entry with the provided result. This is typically used
* within RequestResolver implementations to fulfill pending requests.
*
* @category completion
* @since 2.0.0
*/
var complete = /*#__PURE__*/ dual(2, (self, result) => sync$3(() => self.completeUnsafe(result)));
/**
* @since 2.0.0
* @category completion
*/
var completeEffect = /*#__PURE__*/ dual(2, (self, effect) => matchEffect$2(effect, {
	onFailure: (error) => complete(self, exitFail(error)),
	onSuccess: (value) => complete(self, exitSucceed(value))
}));
/**
* @since 2.0.0
* @category completion
*/
var fail$1 = /*#__PURE__*/ dual(2, (self, error) => complete(self, exitFail(error)));
/**
* @since 2.0.0
* @category completion
*/
var failCause$1 = /*#__PURE__*/ dual(2, (self, cause) => complete(self, exitFailCause(cause)));
/**
* @since 2.0.0
* @category completion
*/
var succeed$1 = /*#__PURE__*/ dual(2, (self, value) => complete(self, exitSucceed(value)));
/**
* @since 2.0.0
* @category entry
*/
var makeEntry = (options) => options;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/request.js
/** @internal */
var request$1 = /*#__PURE__*/ dual(2, (self, resolver) => {
	const withResolver = (resolver) => callback$1((resume) => {
		return maybeRemoveEntry(resolver, addEntry(resolver, self, resume, getCurrentFiber()));
	});
	return isEffect$1(resolver) ? flatMap$2(resolver, withResolver) : withResolver(resolver);
});
/** @internal */
var requestUnsafe$1 = (self, options) => {
	const entry = addEntry(options.resolver, self, options.onExit, {
		services: options.services,
		currentScheduler: get(options.services, Scheduler)
	});
	return () => removeEntryUnsafe(options.resolver, entry);
};
var batchPool = [];
var pendingBatches = /*#__PURE__*/ new Map();
var addEntry = (resolver, request, resume, fiber) => {
	let batchMap = pendingBatches.get(resolver);
	if (!batchMap) {
		batchMap = /* @__PURE__ */ new Map();
		pendingBatches.set(resolver, batchMap);
	}
	let batch;
	let completed = false;
	const entry = makeEntry({
		request,
		services: fiber.services,
		uninterruptible: false,
		completeUnsafe(effect) {
			if (completed) return;
			completed = true;
			resume(effect);
			batch?.entrySet.delete(entry);
		}
	});
	if (resolver.preCheck !== void 0 && !resolver.preCheck(entry)) return entry;
	const key = resolver.batchKey(entry);
	batch = batchMap.get(key);
	if (!batch) {
		if (batchPool.length > 0) {
			batch = batchPool.pop();
			batch.key = key;
			batch.resolver = resolver;
			batch.map = batchMap;
		} else {
			const newBatch = {
				key,
				resolver,
				map: batchMap,
				entrySet: /* @__PURE__ */ new Set(),
				entries: /* @__PURE__ */ new Set(),
				delayEffect: flatMap$2(suspend$1(() => newBatch.resolver.delay), (_) => runBatch(newBatch)),
				run: onExit$1(suspend$1(() => newBatch.resolver.runAll(Array.from(newBatch.entries), newBatch.key)), (exit) => {
					for (const entry of newBatch.entrySet) entry.completeUnsafe(exit._tag === "Success" ? exitDie(new Error("Effect.request: RequestResolver did not complete request", { cause: entry.request })) : exit);
					newBatch.entries.clear();
					if (batchPool.length < 128) {
						newBatch.entrySet.clear();
						newBatch.key = void 0;
						newBatch.fiber = void 0;
						batchPool.push(newBatch);
					}
					return void_$2;
				})
			};
			batch = newBatch;
		}
		batchMap.set(key, batch);
		batch.fiber = runForkWith$1(fiber.services)(batch.delayEffect, { scheduler: fiber.currentScheduler });
	}
	batch.entrySet.add(entry);
	batch.entries.add(entry);
	if (batch.resolver.collectWhile(batch.entries)) return entry;
	batch.fiber.interruptUnsafe(fiber.id);
	batch.fiber = runForkWith$1(fiber.services)(runBatch(batch), { scheduler: fiber.currentScheduler });
	return entry;
};
var removeEntryUnsafe = (resolver, entry) => {
	if (entry.uninterruptible) return;
	const batchMap = pendingBatches.get(resolver);
	if (!batchMap) return;
	const key = resolver.batchKey(entry.request);
	const batch = batchMap.get(key);
	if (!batch) return;
	batch.entries.delete(entry);
	batch.entrySet.delete(entry);
	if (batch.entries.size === 0) {
		batchMap.delete(key);
		batch.fiber?.interruptUnsafe();
	}
};
var maybeRemoveEntry = (resolver, entry) => sync$3(() => removeEntryUnsafe(resolver, entry));
function runBatch(batch) {
	if (!batch.map.has(batch.key)) return void_$2;
	batch.map.delete(batch.key);
	return batch.run;
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Metric.js
/**
* @since 2.0.0
*
* The `Metric` module provides a comprehensive system for collecting, aggregating, and observing
* application metrics in Effect applications. It offers type-safe, concurrent metrics that can
* be used to monitor performance, track business metrics, and gain insights into application behavior.
*
* ## Key Features
*
* - **Five Metric Types**: Counters, Gauges, Frequencies, Histograms, and Summaries
* - **Type Safety**: Fully typed metrics with compile-time guarantees
* - **Concurrency Safe**: Thread-safe metrics that work with Effect's concurrency model
* - **Attributes**: Tag metrics with key-value attributes for filtering and grouping
* - **Snapshots**: Take point-in-time snapshots of all metrics for reporting
* - **Runtime Integration**: Automatic fiber runtime metrics collection
*
* ## Metric Types
*
* ### Counter
* Tracks cumulative values that only increase or can be reset to zero.
* Perfect for counting events, requests, errors, etc.
*
* ### Gauge
* Represents a single numerical value that can go up or down.
* Ideal for current resource usage, temperature, queue sizes, etc.
*
* ### Frequency
* Counts occurrences of discrete string values.
* Useful for tracking categorical data like HTTP status codes, user actions, etc.
*
* ### Histogram
* Records observations in configurable buckets to analyze distribution.
* Great for response times, request sizes, and other measured values.
*
* ### Summary
* Calculates quantiles over a sliding time window.
* Provides statistical insights into value distributions over time.
*
* ## Basic Usage
*
* ```ts
* import { Effect, Metric } from "effect"
*
* // Create metrics
* const requestCount = Metric.counter("http_requests_total", {
*   description: "Total number of HTTP requests"
* })
*
* const responseTime = Metric.histogram("http_response_time", {
*   description: "HTTP response time in milliseconds",
*   boundaries: Metric.linearBoundaries({ start: 0, width: 50, count: 20 })
* })
*
* // Use metrics in your application
* const handleRequest = Effect.gen(function*() {
*   yield* Metric.update(requestCount, 1)
*
*   const startTime = yield* Effect.clockWith((clock) => clock.currentTimeMillis)
*
*   // Process request...
*   yield* Effect.sleep("100 millis")
*
*   const endTime = yield* Effect.clockWith((clock) => clock.currentTimeMillis)
*   yield* Metric.update(responseTime, endTime - startTime)
* })
* ```
*
* ## Attributes and Tagging
*
* ```ts
* import { Effect, Metric } from "effect"
*
* const requestCount = Metric.counter("requests", {
*   description: "Number of requests by endpoint and method"
* })
*
* const program = Effect.gen(function*() {
*   // Add attributes to metrics
*   yield* Metric.update(
*     Metric.withAttributes(requestCount, {
*       endpoint: "/api/users",
*       method: "GET"
*     }),
*     1
*   )
*
*   // Or use withAttributes for compile-time attributes
*   const taggedCounter = Metric.withAttributes(requestCount, {
*     endpoint: "/api/posts",
*     method: "POST"
*   })
*   yield* Metric.update(taggedCounter, 1)
* })
* ```
*
* ## Advanced Examples
*
* ```ts
* import { Effect, Metric } from "effect"
*
* // Business metrics
* const userSignups = Metric.counter("user_signups_total")
* const activeUsers = Metric.gauge("active_users_current")
* const featureUsage = Metric.frequency("feature_usage")
*
* // Performance metrics
* const dbQueryTime = Metric.summary("db_query_duration", {
*   maxAge: "5 minutes",
*   maxSize: 1000,
*   quantiles: [0.5, 0.9, 0.95, 0.99]
* })
*
* const program = Effect.gen(function*() {
*   // Track user signup
*   yield* Metric.update(userSignups, 1)
*
*   // Update active user count
*   yield* Metric.update(activeUsers, 1250)
*
*   // Record feature usage
*   yield* Metric.update(featureUsage, "dashboard_view")
*
*   // Measure database query time
*   yield* Effect.timed(performDatabaseQuery).pipe(
*     Effect.tap(([duration]) => Metric.update(dbQueryTime, duration))
*   )
* })
*
* // Get metric snapshots
* const getMetrics = Effect.gen(function*() {
*   const snapshots = yield* Metric.snapshot
*
*   for (const metric of snapshots) {
*     console.log(`${metric.id}: ${JSON.stringify(metric.state)}`)
*   }
* })
* ```
*/
var Metric_exports = /* @__PURE__ */ __exportAll({
	CurrentMetricAttributes: () => CurrentMetricAttributes,
	CurrentMetricAttributesKey: () => CurrentMetricAttributesKey,
	FiberRuntimeMetrics: () => FiberRuntimeMetrics,
	FiberRuntimeMetricsImpl: () => FiberRuntimeMetricsImpl,
	FiberRuntimeMetricsKey: () => FiberRuntimeMetricsKey,
	MetricRegistry: () => MetricRegistry,
	boundariesFromIterable: () => boundariesFromIterable,
	counter: () => counter,
	disableRuntimeMetrics: () => disableRuntimeMetrics,
	disableRuntimeMetricsLayer: () => disableRuntimeMetricsLayer,
	dump: () => dump,
	enableRuntimeMetrics: () => enableRuntimeMetrics,
	enableRuntimeMetricsLayer: () => enableRuntimeMetricsLayer,
	exponentialBoundaries: () => exponentialBoundaries,
	frequency: () => frequency,
	gauge: () => gauge,
	histogram: () => histogram,
	isMetric: () => isMetric,
	linearBoundaries: () => linearBoundaries,
	mapInput: () => mapInput,
	modify: () => modify,
	snapshot: () => snapshot,
	snapshotUnsafe: () => snapshotUnsafe,
	summary: () => summary,
	summaryWithTimestamp: () => summaryWithTimestamp,
	timer: () => timer,
	update: () => update,
	value: () => value,
	withAttributes: () => withAttributes,
	withConstantInput: () => withConstantInput
});
/**
* Service key for the current metric attributes context.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class AttributesKeyError extends Data.TaggedError("AttributesKeyError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // The key is used internally by the Effect runtime to manage metric attributes
*   const key = Metric.CurrentMetricAttributesKey
*
*   // Create metrics with base attributes
*   const requestCounter = Metric.counter("requests_total", {
*     description: "Total HTTP requests"
*   })
*
*   // The CurrentMetricAttributes service provides default attributes
*   // that get applied to all metrics in the current context
*   const baseAttributes = { service: "api", version: "1.0" }
*
*   // Use withAttributes to apply attributes to metrics
*   const taggedCounter1 = Metric.withAttributes(requestCounter, baseAttributes)
*   const program1 = Metric.update(taggedCounter1, 1)
*
*   const taggedCounter2 = Metric.withAttributes(requestCounter, {
*     ...baseAttributes,
*     endpoint: "/users"
*   })
*   const program2 = Metric.update(taggedCounter2, 5)
*
*   yield* program1
*   yield* program2
*
*   return {
*     keyValue: key, // "effect/Metric/CurrentMetricAttributes"
*     keyType: typeof key, // "string"
*     isConstant: key === "effect/Metric/CurrentMetricAttributes" // true
*   }
* })
* ```
*
* @since 4.0.0
* @category References
*/
var CurrentMetricAttributesKey = "effect/Metric/CurrentMetricAttributes";
/**
* Service class for managing the current metric attributes context.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class AttributesError extends Data.TaggedError("AttributesError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Access current metric attributes
*   const attributes = yield* Metric.CurrentMetricAttributes
*   console.log("Current attributes:", attributes)
*
*   // Set new attributes context
*   const newAttributes = { service: "api", version: "1.0" }
*   const result = yield* Effect.provideService(
*     Effect.gen(function*() {
*       const updatedAttributes = yield* Metric.CurrentMetricAttributes
*       return updatedAttributes
*     }),
*     Metric.CurrentMetricAttributes,
*     newAttributes
*   )
*
*   return result
* })
* ```
*
* @since 4.0.0
* @category References
*/
var CurrentMetricAttributes = /*#__PURE__*/ Reference(CurrentMetricAttributesKey, { defaultValue: () => ({}) });
/**
* Service class for accessing the current metric registry.
*
* @since 4.0.0
* @category References
*/
var MetricRegistry = /*#__PURE__*/ Reference("~effect/observability/Metric/MetricRegistryKey", { defaultValue: () => /* @__PURE__ */ new Map() });
var TypeId$1 = "~effect/observability/Metric";
var Metric$ = class {
	[TypeId$1] = TypeId$1;
	#metadataCache = /*#__PURE__*/ new WeakMap();
	#metadata;
	id;
	description;
	attributes;
	constructor(id, description, attributes) {
		this.id = id;
		this.description = description;
		this.attributes = attributes;
	}
	valueUnsafe(context) {
		return this.hook(context).get(context);
	}
	modifyUnsafe(input, context) {
		return this.hook(context).modify(input, context);
	}
	updateUnsafe(input, context) {
		return this.hook(context).update(input, context);
	}
	hook(context) {
		const extraAttributes = get(context, CurrentMetricAttributes);
		if (Object.keys(extraAttributes).length === 0) {
			if (isNotUndefined(this.#metadata)) return this.#metadata.hooks;
			this.#metadata = this.getOrCreate(context, this.attributes);
			return this.#metadata.hooks;
		}
		const mergedAttributes = mergeAttributes(this.attributes, extraAttributes);
		let metadata = this.#metadataCache.get(mergedAttributes);
		if (isNotUndefined(metadata)) return metadata.hooks;
		metadata = this.getOrCreate(context, mergedAttributes);
		this.#metadataCache.set(mergedAttributes, metadata);
		return metadata.hooks;
	}
	getOrCreate(context, attributes) {
		const key = makeKey(this, attributes);
		const registry = get(context, MetricRegistry);
		if (registry.has(key)) return registry.get(key);
		const hooks = this.createHooks();
		const meta = {
			id: this.id,
			type: this.type,
			description: this.description,
			attributes: attributesToRecord(attributes),
			hooks
		};
		registry.set(key, meta);
		return meta;
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var bigint0 = /*#__PURE__*/ BigInt(0);
var CounterMetric = class extends Metric$ {
	type = "Counter";
	#bigint;
	#incremental;
	constructor(id, options) {
		super(id, options?.description, attributesToRecord(options?.attributes));
		this.#bigint = options?.bigint ?? false;
		this.#incremental = options?.incremental ?? false;
	}
	createHooks() {
		let count = this.#bigint ? bigint0 : 0;
		const canUpdate = this.#incremental ? this.#bigint ? (value) => value >= bigint0 : (value) => value >= 0 : (_value) => true;
		const update = (value) => {
			if (canUpdate(value)) count = count + value;
		};
		return makeHooks(() => ({
			count,
			incremental: this.#incremental
		}), update);
	}
};
var GaugeMetric = class extends Metric$ {
	type = "Gauge";
	#bigint;
	constructor(id, options) {
		super(id, options?.description, attributesToRecord(options?.attributes));
		this.#bigint = options?.bigint ?? false;
	}
	createHooks() {
		let value = this.#bigint ? BigInt(0) : 0;
		const update = (input) => {
			value = input;
		};
		const modify = (input) => {
			value = value + input;
		};
		return makeHooks(() => ({ value }), update, modify);
	}
};
var FrequencyMetric = class extends Metric$ {
	type = "Frequency";
	#preregisteredWords;
	constructor(id, options) {
		super(id, options?.description, attributesToRecord(options?.attributes));
		this.#preregisteredWords = options?.preregisteredWords;
	}
	createHooks() {
		const occurrences = /* @__PURE__ */ new Map();
		if (isNotUndefined(this.#preregisteredWords)) for (const word of this.#preregisteredWords) occurrences.set(word, 0);
		const update = (word) => {
			const count = occurrences.get(word) ?? 0;
			occurrences.set(word, count + 1);
		};
		return makeHooks(() => ({ occurrences }), update);
	}
};
var HistogramMetric = class extends Metric$ {
	type = "Histogram";
	#boundaries;
	constructor(id, options) {
		super(id, options?.description, attributesToRecord(options?.attributes));
		this.#boundaries = options.boundaries;
	}
	createHooks() {
		const bounds = this.#boundaries;
		const size = bounds.length;
		const values = new Uint32Array(size + 1);
		const boundaries = new Float64Array(size);
		let count = 0;
		let sum = 0;
		let min = Number.MAX_VALUE;
		let max = Number.MIN_VALUE;
		map$6(sort(bounds, Number$2), (n, i) => {
			boundaries[i] = n;
		});
		const update = (value) => {
			let from = 0;
			let to = size;
			while (from !== to) {
				const mid = Math.floor(from + (to - from) / 2);
				if (value <= boundaries[mid]) to = mid;
				else from = mid;
				if (to === from + 1) if (value <= boundaries[from]) to = from;
				else from = to;
			}
			values[from] = values[from] + 1;
			count = count + 1;
			sum = sum + value;
			if (value < min) min = value;
			if (value > max) max = value;
		};
		const getBuckets = () => {
			const builder = allocate(size);
			let cumulated = 0;
			for (let i = 0; i < size; i++) {
				const boundary = boundaries[i];
				const value = values[i];
				cumulated = cumulated + value;
				builder[i] = [boundary, cumulated];
			}
			return builder;
		};
		return makeHooks(() => ({
			buckets: getBuckets(),
			count,
			min,
			max,
			sum
		}), update);
	}
};
var SummaryMetric = class extends Metric$ {
	type = "Summary";
	#maxAge;
	#maxSize;
	#quantiles;
	constructor(id, options) {
		super(id, options?.description, attributesToRecord(options?.attributes));
		this.#maxAge = Math.max(toMillis(fromInputUnsafe(options.maxAge)), 0);
		this.#maxSize = options.maxSize;
		this.#quantiles = options.quantiles;
	}
	createHooks() {
		const sortedQuantiles = sort(this.#quantiles, Number$2);
		const observations = allocate(this.#maxSize);
		for (const quantile of this.#quantiles) if (quantile < 0 || quantile > 1) throw new Error(`Quantile must be between 0 and 1, found: ${quantile}`);
		let head = 0;
		let count = 0;
		let sum = 0;
		let min = Number.MAX_VALUE;
		let max = Number.MIN_VALUE;
		const snapshot = (now) => {
			const builder = [];
			let i = 0;
			while (i < this.#maxSize) {
				const observation = observations[i];
				if (isNotUndefined(observation)) {
					const [timestamp, value] = observation;
					const age = now - timestamp;
					if (age >= 0 && age <= this.#maxAge) builder.push(value);
				}
				i = i + 1;
			}
			const samples = sort(builder, Number$2);
			const sampleSize = samples.length;
			if (sampleSize === 0) return sortedQuantiles.map((q) => [q, void 0]);
			return sortedQuantiles.map((q) => {
				if (q <= 0) return [q, samples[0]];
				if (q >= 1) return [q, samples[sampleSize - 1]];
				const index = Math.ceil(q * sampleSize) - 1;
				return [q, samples[index]];
			});
		};
		const observe = (value, timestamp) => {
			if (this.#maxSize > 0) {
				const target = head % this.#maxSize;
				observations[target] = [timestamp, value];
				head = head + 1;
			}
			count = count + 1;
			sum = sum + value;
			if (value < min) min = value;
			if (value > max) max = value;
		};
		const get$3 = (context) => {
			const clock = get(context, ClockRef);
			return {
				quantiles: snapshot(clock.currentTimeMillisUnsafe()),
				count,
				min,
				max,
				sum
			};
		};
		const update = ([value, timestamp]) => observe(value, timestamp);
		return makeHooks(get$3, update);
	}
};
var MetricTransform = class extends Metric$ {
	type;
	metric;
	valueUnsafe;
	updateUnsafe;
	modifyUnsafe;
	constructor(metric, valueUnsafe, updateUnsafe, modifyUnsafe) {
		super(metric.id, metric.description, metric.attributes);
		this.metric = metric;
		this.valueUnsafe = valueUnsafe;
		this.updateUnsafe = updateUnsafe;
		this.modifyUnsafe = modifyUnsafe;
		this.type = metric.type;
	}
	createHooks() {
		return this.metric.createHooks();
	}
};
/**
* Returns `true` if the specified value is a `Metric`, otherwise returns `false`.
*
* This function is useful for runtime type checking and ensuring that a value
* conforms to the Metric interface before performing metric operations.
*
* @example
* ```ts
* import { Metric } from "effect"
*
* const counter = Metric.counter("requests")
* const gauge = Metric.gauge("temperature")
* const notAMetric = { name: "fake-metric" }
*
* console.log(Metric.isMetric(counter)) // true
* console.log(Metric.isMetric(gauge)) // true
* console.log(Metric.isMetric(notAMetric)) // false
* console.log(Metric.isMetric(null)) // false
* ```
*
* @since 4.0.0
* @category Guards
*/
var isMetric = (u) => hasProperty(u, "~effect/Metric") && u["~effect/Metric"] === "~effect/Metric";
/**
* Represents a Counter metric that tracks cumulative numerical values over
* time. Counters can be incremented and decremented and provide a running total
* of changes.
*
* **Options**
*
* - `description` - A description of the `Counter`.
* - `attributes`  - The attributes to associate with the `Counter`.
* - `bigint`      - Indicates if the `Counter` should use the `bigint` type.
* - `incremental` - Set to `true` to create a `Counter` that can only ever be
*                   incremented.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class CounterError extends Data.TaggedError("CounterError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a basic counter for tracking requests
*   const requestCounter = Metric.counter("http_requests_total", {
*     description: "Total number of HTTP requests processed"
*   })
*
*   // Create an incremental-only counter for events
*   const eventCounter = Metric.counter("events_processed", {
*     description: "Events processed (increment only)",
*     incremental: true
*   })
*
*   // Create a bigint counter for large values
*   const bytesCounter = Metric.counter("bytes_transferred", {
*     description: "Total bytes transferred",
*     bigint: true,
*     attributes: { service: "file-transfer" }
*   })
*
*   // Update counters with values
*   yield* Metric.update(requestCounter, 1) // Increment by 1
*   yield* Metric.update(requestCounter, 5) // Increment by 5 (total: 6)
*   yield* Metric.update(eventCounter, 1) // Increment by 1
*   yield* Metric.update(bytesCounter, 1024n) // Add 1024 bytes
*
*   // Get current counter values
*   const requestValue = yield* Metric.value(requestCounter)
*   const eventValue = yield* Metric.value(eventCounter)
*   const bytesValue = yield* Metric.value(bytesCounter)
*
*   return { requestValue, eventValue, bytesValue }
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var counter = (name, options) => new CounterMetric(name, options);
/**
* Represents a `Gauge` metric that tracks and reports a single numerical value
* at a specific moment.
*
* Gauges are most suitable for metrics that represent instantaneous values,
* such as memory usage or CPU load.
*
* **Options**
*
* - `description` - A description of the `Gauge`.
* - `attributes`  - The attributes to associate with the `Gauge`.
* - `bigint`      - Indicates if the `Gauge` should use the `bigint` type.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class GaugeError extends Data.TaggedError("GaugeError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a gauge for tracking memory usage
*   const memoryGauge = Metric.gauge("memory_usage_mb", {
*     description: "Current memory usage in megabytes"
*   })
*
*   // Create a gauge for CPU utilization
*   const cpuGauge = Metric.gauge("cpu_utilization", {
*     description: "Current CPU utilization percentage",
*     attributes: { host: "server-01" }
*   })
*
*   // Create a bigint gauge for large values
*   const diskSpaceGauge = Metric.gauge("disk_free_bytes", {
*     description: "Free disk space in bytes",
*     bigint: true
*   })
*
*   // Set gauge values (replaces current value)
*   yield* Metric.update(memoryGauge, 512) // Set to 512 MB
*   yield* Metric.update(cpuGauge, 85.5) // Set to 85.5%
*   yield* Metric.update(diskSpaceGauge, 1024000000n) // Set to ~1GB
*
*   // Modify gauge values (adds to current value)
*   yield* Metric.modify(memoryGauge, 128) // Increase by 128 MB (total: 640)
*   yield* Metric.modify(cpuGauge, -10.5) // Decrease by 10.5% (total: 75%)
*
*   // Update with new absolute values
*   yield* Metric.update(memoryGauge, 800) // Set to 800 MB (replaces 640)
*
*   // Get current gauge values
*   const memoryValue = yield* Metric.value(memoryGauge)
*   const cpuValue = yield* Metric.value(cpuGauge)
*   const diskValue = yield* Metric.value(diskSpaceGauge)
*
*   return { memoryValue, cpuValue, diskValue }
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var gauge = (name, options) => new GaugeMetric(name, options);
/**
* Creates a `Frequency` metric which can be used to count the number of
* occurrences of a string.
*
* Frequency metrics are most suitable for counting the number of times a
* specific event or incident occurs.
*
* **Options**
*
* - `description` - A description of the `Frequency`.
* - `attributes`  - The attributes to associate with the `Frequency`.
* - `preregisteredWords` - Occurrences which are pre-registered with the
*                          `Frequency` metric occurrences.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class FrequencyError extends Data.TaggedError("FrequencyError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a frequency metric for HTTP status codes
*   const statusFrequency = Metric.frequency("http_status_codes", {
*     description: "Frequency of HTTP response status codes",
*     preregisteredWords: ["200", "404", "500"] // Pre-register common codes
*   })
*
*   // Create a frequency metric for user actions
*   const userActionFrequency = Metric.frequency("user_actions", {
*     description: "Frequency of user actions performed",
*     attributes: { application: "web-app" }
*   })
*
*   // Create a frequency metric for error types
*   const errorTypeFrequency = Metric.frequency("error_types", {
*     description: "Frequency of different error types"
*   })
*
*   // Record different occurrences
*   yield* Metric.update(statusFrequency, "200") // Success response
*   yield* Metric.update(statusFrequency, "200") // Another success
*   yield* Metric.update(statusFrequency, "404") // Not found error
*   yield* Metric.update(statusFrequency, "500") // Server error
*   yield* Metric.update(statusFrequency, "200") // Another success
*
*   yield* Metric.update(userActionFrequency, "login")
*   yield* Metric.update(userActionFrequency, "view_dashboard")
*   yield* Metric.update(userActionFrequency, "login")
*   yield* Metric.update(userActionFrequency, "logout")
*
*   yield* Metric.update(errorTypeFrequency, "ValidationError")
*   yield* Metric.update(errorTypeFrequency, "NetworkError")
*   yield* Metric.update(errorTypeFrequency, "ValidationError")
*
*   // Get frequency counts
*   const statusCounts = yield* Metric.value(statusFrequency)
*   const actionCounts = yield* Metric.value(userActionFrequency)
*   const errorCounts = yield* Metric.value(errorTypeFrequency)
*
*   // statusCounts.occurrences will be:
*   // Map { "200" => 3, "404" => 1, "500" => 1 }
*   // actionCounts.occurrences will be:
*   // Map { "login" => 2, "view_dashboard" => 1, "logout" => 1 }
*   // errorCounts.occurrences will be:
*   // Map { "ValidationError" => 2, "NetworkError" => 1 }
*
*   return { statusCounts, actionCounts, errorCounts }
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var frequency = (name, options) => new FrequencyMetric(name, options);
/**
* Represents a `Histogram` metric that records observations into buckets.
*
* Histogram metrics are most suitable for measuring the distribution of values
* within a range.
*
* **Options**
*
* - `description` - A description of the `Histogram`.
* - `attributes`  - The attributes to associate with the `Histogram`.
* - `boundaries`  - The bucket boundaries of the `Histogram`
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class HistogramError extends Data.TaggedError("HistogramError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a histogram for API response times
*   const responseTimeHistogram = Metric.histogram("api_response_time", {
*     description: "Distribution of API response times in milliseconds",
*     boundaries: Metric.linearBoundaries({ start: 0, width: 50, count: 10 })
*     // Creates buckets: 0-50ms, 50-100ms, 100-150ms, ..., 400-450ms, 450ms+
*   })
*
*   // Create a histogram for request payload sizes
*   const payloadSizeHistogram = Metric.histogram("payload_size", {
*     description: "Distribution of request payload sizes in KB",
*     boundaries: Metric.exponentialBoundaries({ start: 1, factor: 2, count: 8 }),
*     // Creates exponential buckets: 1KB, 2KB, 4KB, 8KB, 16KB, 32KB, 64KB, 128KB+
*     attributes: { service: "api-gateway" }
*   })
*
*   // Create a histogram with custom boundaries
*   const customHistogram = Metric.histogram("custom_metric", {
*     description: "Custom distribution metric",
*     boundaries: [0.1, 0.5, 1, 2.5, 5, 10, 25, 50, 100]
*   })
*
*   // Record various response times
*   yield* Metric.update(responseTimeHistogram, 25) // Goes in 0-50ms bucket
*   yield* Metric.update(responseTimeHistogram, 75) // Goes in 50-100ms bucket
*   yield* Metric.update(responseTimeHistogram, 125) // Goes in 100-150ms bucket
*   yield* Metric.update(responseTimeHistogram, 200) // Goes in 150-200ms bucket
*   yield* Metric.update(responseTimeHistogram, 75) // Another 50-100ms
*
*   // Record payload sizes
*   yield* Metric.update(payloadSizeHistogram, 3) // Goes in 2-4KB bucket
*   yield* Metric.update(payloadSizeHistogram, 15) // Goes in 8-16KB bucket
*   yield* Metric.update(payloadSizeHistogram, 0.5) // Goes in 0-1KB bucket
*
*   // Get histogram state with distribution data
*   const responseTimeState = yield* Metric.value(responseTimeHistogram)
*   const payloadSizeState = yield* Metric.value(payloadSizeHistogram)
*
*   // responseTimeState will contain:
*   // - buckets: [[50, 1], [100, 3], [150, 4], [200, 5], ...]
*   // - count: 5, min: 25, max: 200, sum: 500
*   // - Useful for calculating percentiles, averages, etc.
*
*   return { responseTimeState, payloadSizeState }
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var histogram = (name, options) => new HistogramMetric(name, options);
/**
* Creates a `Summary` metric that records observations and calculates quantiles
* which takes a value as input and uses the current time.
*
* Summary metrics are most suitable for providing statistical information about
* a set of values, including quantiles.
*
* **Options**
*
* - `description` - An description of the `Summary`.
* - `attributes`  - The attributes to associate with the `Summary`.
* - `maxAge`      - The maximum age of observations to retain.
* - `maxSize`     - The maximum number of observations to keep.
* - `quantiles`   - An array of quantiles to calculate (e.g., [0.5, 0.9]).
*
* @example
* ```ts
* import { Data, Duration, Effect, Metric } from "effect"
*
* class SummaryError extends Data.TaggedError("SummaryError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a summary for API response times
*   const responseTimeSummary = Metric.summary("api_response_time", {
*     description: "API response time quantiles over 5-minute windows",
*     maxAge: Duration.minutes(5), // Keep observations for 5 minutes
*     maxSize: 1000, // Maximum 1000 observations in memory
*     quantiles: [0.5, 0.9, 0.95, 0.99] // 50th, 90th, 95th, 99th percentiles
*   })
*
*   // Create a summary for request payload sizes
*   const payloadSizeSummary = Metric.summary("request_payload_size", {
*     description: "Request payload size distribution over 2-minute windows",
*     maxAge: Duration.minutes(2), // Shorter window for recent trends
*     maxSize: 500, // Smaller buffer for memory efficiency
*     quantiles: [0.5, 0.75, 0.9], // Median, 75th, 90th percentiles
*     attributes: { service: "upload-service" }
*   })
*
*   // Simulate recording various response times over time
*   for (let i = 0; i < 20; i++) {
*     const responseTime = 50 + Math.random() * 200 // 50-250ms
*     yield* Metric.update(responseTimeSummary, responseTime)
*
*     // Wait a bit to simulate different timestamps
*     yield* Effect.sleep(Duration.millis(100))
*   }
*
*   // Record some payload sizes
*   yield* Metric.update(payloadSizeSummary, 1.2) // 1.2KB
*   yield* Metric.update(payloadSizeSummary, 5.8) // 5.8KB
*   yield* Metric.update(payloadSizeSummary, 15.6) // 15.6KB
*   yield* Metric.update(payloadSizeSummary, 3.4) // 3.4KB
*
*   // Get summary statistics with quantiles
*   const responseStats = yield* Metric.value(responseTimeSummary)
*   const payloadStats = yield* Metric.value(payloadSizeSummary)
*
*   // responseStats will contain:
*   // - quantiles: [[0.5, Some(125)], [0.9, Some(220)], [0.95, Some(235)], [0.99, Some(245)]]
*   // - count: 20, min: ~50, max: ~250, sum: ~2500
*   // - Only observations from the last 5 minutes are included
*
*   // payloadStats will contain quantile information for recent payload sizes
*   // Older observations automatically age out based on maxAge setting
*
*   return { responseStats, payloadStats }
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var summary = (name, options) => mapInput(summaryWithTimestamp(name, options), (input, context) => [input, get(context, ClockRef).currentTimeMillisUnsafe()]);
/**
* Creates a `Summary` metric that records observations and calculates quantiles
* which takes a value and the current timestamp as input.
*
* Summary metrics are most suitable for providing statistical information about
* a set of values, including quantiles.
*
* **Options**
*
* - `description` - An description of the `Summary`.
* - `attributes`  - The attributes to associate with the `Summary`.
* - `maxAge`      - The maximum age of observations to retain.
* - `maxSize`     - The maximum number of observations to keep.
* - `quantiles`   - An array of quantiles to calculate (e.g., [0.5, 0.9]).
*
* @example
* ```ts
* import { Metric } from "effect"
*
* const responseTimesSummary = Metric.summaryWithTimestamp(
*   "response_times_summary",
*   {
*     description: "Measures the distribution of response times",
*     maxAge: "60 seconds", // Retain observations for 60 seconds.
*     maxSize: 1000, // Keep a maximum of 1000 observations.
*     quantiles: [0.5, 0.9, 0.99] // Calculate 50th, 90th, and 99th quantiles.
*   }
* )
* ```
*
* @since 2.0.0
* @category Constructors
*/
var summaryWithTimestamp = (name, options) => new SummaryMetric(name, options);
/**
* Creates a timer metric, based on a `Histogram`, which keeps track of
* durations in milliseconds.
*
* The unit of time will automatically be added to the metric as a tag (i.e.
* `"time_unit: milliseconds"`).
*
* If `options.boundaries` is not provided, the boundaries will be computed
* using `Metric.exponentialBoundaries({ start: 0.5, factor: 2, count: 35 })`.
*
* @example
* ```ts
* import { Data, Duration, Effect, Metric } from "effect"
*
* class TimerError extends Data.TaggedError("TimerError")<{
*   readonly operation: string
* }> {}
*
* // Create a timer metric to track API request durations
* const apiRequestTimer = Metric.timer("api_request_duration", {
*   description: "Duration of API requests",
*   attributes: { service: "user-api" }
* })
*
* // Simulate an API operation and measure its duration
* const apiOperation = Effect.gen(function*() {
*   const start = Date.now()
*   yield* Effect.sleep(Duration.millis(100)) // Simulate work
*   const duration = Duration.millis(Date.now() - start)
*
*   // Update the timer with the measured duration
*   yield* Metric.update(apiRequestTimer, duration)
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var timer = (name, options) => {
	const boundaries = isNotUndefined(options?.boundaries) ? options.boundaries : exponentialBoundaries({
		start: .5,
		factor: 2,
		count: 35
	});
	const attributes = mergeAttributes(options?.attributes, { time_unit: "milliseconds" });
	return mapInput(new HistogramMetric(name, {
		...options,
		boundaries,
		attributes
	}), toMillis);
};
/**
* Retrieves the current state of the specified `Metric`.
*
* This function returns an Effect that, when executed, will provide the current
* aggregated state of the metric. The state type depends on the metric type:
* - Counter: `{ count: number | bigint }`
* - Gauge: `{ value: number | bigint }`
* - Frequency: `{ occurrences: Map<string, number> }`
* - Histogram: `{ buckets: Array<[number, number]>, count: number, min: number, max: number, sum: number }`
* - Summary: `{ quantiles: Array<[number, number | undefined]>, count: number, min: number, max: number, sum: number }`
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const requestCounter = Metric.counter("requests")
* const responseTime = Metric.histogram("response_time", {
*   boundaries: [100, 500, 1000, 2000]
* })
*
* const program = Effect.gen(function*() {
*   // Update metrics
*   yield* Metric.update(requestCounter, 1)
*   yield* Metric.update(responseTime, 750)
*
*   // Get current values
*   const counterState = yield* Metric.value(requestCounter)
*   console.log(`Request count: ${counterState.count}`)
*
*   const histogramState = yield* Metric.value(responseTime)
*   console.log(`Response time stats:`, {
*     count: histogramState.count,
*     min: histogramState.min,
*     max: histogramState.max,
*     average: histogramState.sum / histogramState.count
*   })
* })
* ```
*
* @since 2.0.0
* @category Utilities
*/
var value = (self) => flatMap$2(services$1(), (context) => sync$3(() => self.valueUnsafe(context)));
/**
* Modifies the metric with the specified input.
*
* The behavior of `modify` depends on the metric type:
* - **Counter**: Adds the input value to the current count
* - **Gauge**: Adds the input value to the current gauge value
* - **Frequency**: Same as `update` - increments the occurrence count for the input string
* - **Histogram**: Same as `update` - records the input value in the appropriate bucket
* - **Summary**: Same as `update` - records the input observation
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const temperatureGauge = Metric.gauge("temperature")
* const requestCounter = Metric.counter("requests")
*
* const program = Effect.gen(function*() {
*   // Set initial temperature
*   yield* Metric.update(temperatureGauge, 20)
*
*   // Modify by adding/subtracting values
*   yield* Metric.modify(temperatureGauge, 5) // Now 25
*   yield* Metric.modify(temperatureGauge, -3) // Now 22
*
*   // For counters, modify increments by the specified amount
*   yield* Metric.modify(requestCounter, 10) // Add 10 to counter
*   yield* Metric.modify(requestCounter, 5) // Add 5 more (total: 15)
*
*   const temp = yield* Metric.value(temperatureGauge)
*   const requests = yield* Metric.value(requestCounter)
*
*   console.log(`Temperature: ${temp.value}°C`) // 22°C
*   console.log(`Requests: ${requests.count}`) // 15
* })
* ```
*
* @since 2.0.0
* @category Utilities
*/
var modify = /*#__PURE__*/ dual(2, (self, input) => flatMap$2(services$1(), (context) => sync$3(() => self.modifyUnsafe(input, context))));
/**
* Updates the metric with the specified input.
*
* The behavior of `update` depends on the metric type:
* - **Counter**: Adds the input value to the current count (same as `modify`)
* - **Gauge**: Sets the gauge to the specified value (replaces current value)
* - **Frequency**: Increments the occurrence count for the input string by 1
* - **Histogram**: Records the input value in the appropriate bucket
* - **Summary**: Records the input value as a new observation
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const cpuUsage = Metric.gauge("cpu_usage_percent")
* const httpStatus = Metric.frequency("http_status_codes")
* const responseTime = Metric.histogram("response_time_ms", {
*   boundaries: [100, 500, 1000, 2000]
* })
*
* const program = Effect.gen(function*() {
*   // Update gauge to specific values
*   yield* Metric.update(cpuUsage, 45.2)
*   yield* Metric.update(cpuUsage, 67.8) // Replaces previous value
*
*   // Track HTTP status code occurrences
*   yield* Metric.update(httpStatus, "200")
*   yield* Metric.update(httpStatus, "404")
*   yield* Metric.update(httpStatus, "200") // Increments 200 count
*
*   // Record response times
*   yield* Metric.update(responseTime, 250)
*   yield* Metric.update(responseTime, 750)
*   yield* Metric.update(responseTime, 1500)
*
*   // Check current states
*   const cpu = yield* Metric.value(cpuUsage)
*   const statuses = yield* Metric.value(httpStatus)
*   const times = yield* Metric.value(responseTime)
*
*   console.log(`CPU Usage: ${cpu.value}%`)
*   console.log(`Status 200 count: ${statuses.occurrences.get("200")}`) // 2
*   console.log(`Response time samples: ${times.count}`) // 3
* })
* ```
*
* @since 2.0.0
* @category Utilities
*/
var update = /*#__PURE__*/ dual(2, (self, input) => servicesWith$1((services) => sync$3(() => self.updateUnsafe(input, services))));
/**
* Returns a new metric that is powered by this one, but which accepts updates
* of the specified new type, which must be transformable to the input type of
* this metric.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class MetricError extends Data.TaggedError("MetricError")<{
*   readonly operation: string
* }> {}
*
* // Create a histogram that expects Duration values
* const durationHistogram = Metric.histogram("request_duration_ms", {
*   description: "Request duration in milliseconds",
*   boundaries: Metric.linearBoundaries({ start: 0, width: 100, count: 10 })
* })
*
* // Transform to accept number values representing milliseconds
* const numberHistogram = Metric.mapInput(
*   durationHistogram,
*   (ms: number) => ms // Direct mapping from number to expected input
* )
*
* const program = Effect.gen(function*() {
*   // Now we can update with a plain number
*   yield* Metric.update(numberHistogram, 250)
*
*   // Get metric value to see the recorded state
*   const value = yield* Metric.value(numberHistogram)
*   return value
* })
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapInput = /*#__PURE__*/ dual(2, (self, f) => new MetricTransform(self, (context) => self.valueUnsafe(context), (input, context) => self.updateUnsafe(f(input, context), context), (input, context) => self.modifyUnsafe(f(input, context), context)));
/**
* Returns a new metric that is powered by this one, but which accepts updates
* of any type, and translates them to updates with the specified constant
* update value.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class MetricError extends Data.TaggedError("MetricError")<{
*   readonly operation: string
* }> {}
*
* // Create a counter that normally expects a number increment
* const requestCounter = Metric.counter("total_requests", {
*   description: "Total number of requests processed"
* })
*
* // Create a version that always increments by 1, regardless of input
* const simpleRequestCounter = Metric.withConstantInput(requestCounter, 1)
*
* const program = Effect.gen(function*() {
*   // These all increment the counter by 1, ignoring the input value
*   yield* Metric.update(simpleRequestCounter, "any string")
*   yield* Metric.update(simpleRequestCounter, { complex: "object" })
*   yield* Metric.update(simpleRequestCounter, 999) // Still increments by 1
*
*   const value = yield* Metric.value(simpleRequestCounter)
*   return value // Counter state will show count: 3
* })
* ```
*
* @since 2.0.0
* @category Input
*/
var withConstantInput = /*#__PURE__*/ dual(2, (self, input) => mapInput(self, () => input));
/**
* Returns a new metric that applies the specified attributes to all operations.
*
* Attributes are key-value pairs that provide additional context for metrics,
* enabling filtering, grouping, and more detailed analysis. Each combination
* of attribute values creates a separate metric series.
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const requestCounter = Metric.counter("http_requests_total", {
*   description: "Total HTTP requests"
* })
*
* // Create tagged versions of the metric
* const getRequests = Metric.withAttributes(requestCounter, {
*   method: "GET",
*   endpoint: "/api/users"
* })
*
* const postRequests = Metric.withAttributes(requestCounter, {
*   method: "POST",
*   endpoint: "/api/users"
* })
*
* const program = Effect.gen(function*() {
*   // These will be tracked as separate metric series
*   yield* Metric.update(getRequests, 1) // http_requests_total{method="GET", endpoint="/api/users"}
*   yield* Metric.update(postRequests, 1) // http_requests_total{method="POST", endpoint="/api/users"}
*   yield* Metric.update(getRequests, 1) // Increments the GET counter
*
*   // You can also chain attributes
*   const taggedMetric = requestCounter.pipe(
*     Metric.withAttributes({ service: "user-api" }),
*     Metric.withAttributes({ version: "v1" })
*   )
*
*   yield* Metric.update(taggedMetric, 1) // http_requests_total{service="user-api", version="v1"}
* })
*
* // When taking snapshots, each attribute combination appears as a separate metric
* const viewMetrics = Effect.gen(function*() {
*   const snapshots = yield* Metric.snapshot
*   for (const metric of snapshots) {
*     if (metric.id === "http_requests_total") {
*       console.log(`${metric.id}`, metric.attributes, metric.state)
*     }
*   }
* })
* ```
*
* @since 4.0.0
* @category Attributes
*/
var withAttributes = /*#__PURE__*/ dual(2, (self, attributes) => new MetricTransform(self, (context) => self.valueUnsafe(addAttributesToServiceMap(context, attributes)), (input, context) => self.updateUnsafe(input, addAttributesToServiceMap(context, attributes)), (input, context) => self.modifyUnsafe(input, addAttributesToServiceMap(context, attributes))));
/**
* Captures a snapshot of all registered metrics in the current context.
*
* Returns an array of metric snapshots, each containing the metric's metadata
* (name, description, type) and current state (values, counts, etc.).
*
* @example
* ```ts
* import { Console, Data, Effect, Metric } from "effect"
*
* class SnapshotError extends Data.TaggedError("SnapshotError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create and update some metrics
*   const requestCounter = Metric.counter("http_requests", {
*     description: "Total HTTP requests"
*   })
*   const responseTime = Metric.histogram("response_time_ms", {
*     description: "Response time in milliseconds",
*     boundaries: Metric.linearBoundaries({ start: 0, width: 100, count: 5 })
*   })
*
*   // Update the metrics with some values
*   yield* Metric.update(requestCounter, 1)
*   yield* Metric.update(requestCounter, 1)
*   yield* Metric.update(responseTime, 150)
*   yield* Metric.update(responseTime, 75)
*
*   // Take a snapshot of all metrics
*   const snapshots = yield* Metric.snapshot
*
*   // Examine the snapshots
*   for (const snapshot of snapshots) {
*     yield* Console.log(`Metric: ${snapshot.id}`)
*     yield* Console.log(`Description: ${snapshot.description}`)
*     yield* Console.log(`Type: ${snapshot.type}`)
*     yield* Console.log(`State:`, snapshot.state)
*   }
*
*   return snapshots
* })
* ```
*
* @since 2.0.0
* @category Snapshotting
*/
var snapshot = /*#__PURE__*/ map$4(/*#__PURE__*/ services$1(), (context) => snapshotUnsafe(context));
/**
* Returns a human-readable string representation of all currently registered
* metrics in a tabular format.
*
* This debugging utility captures a snapshot of all metrics and formats them
* in an easy-to-read table showing names, descriptions, types, attributes,
* and current state values.
*
* @example
* ```ts
* import { Console, Data, Effect, Metric } from "effect"
*
* class DumpError extends Data.TaggedError("DumpError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create and update some metrics for demonstration
*   const requestCounter = Metric.counter("http_requests_total", {
*     description: "Total HTTP requests"
*   })
*   const responseTime = Metric.gauge("response_time_ms", {
*     description: "Current response time in milliseconds"
*   })
*   const statusFreq = Metric.frequency("http_status_codes", {
*     description: "Frequency of HTTP status codes"
*   })
*
*   // Update metrics with some values
*   yield* Metric.update(requestCounter, 1)
*   yield* Metric.update(requestCounter, 1)
*   yield* Metric.update(responseTime, 125)
*   yield* Metric.update(statusFreq, "200")
*   yield* Metric.update(statusFreq, "404")
*   yield* Metric.update(statusFreq, "200")
*
*   // Get formatted dump of all metrics
*   const metricsReport = yield* Metric.dump
*   yield* Console.log("Current Metrics:")
*   yield* Console.log(metricsReport)
*
*   // Output will look like a formatted table:
*   // Name                  Description                           Type       State
*   // http_requests_total   Total HTTP requests                   Counter    [count: 2]
*   // response_time_ms      Current response time in milliseconds Gauge      [value: 125]
*   // http_status_codes     Frequency of HTTP status codes       Frequency  [occurrences: 200 -> 2, 404 -> 1]
*
*   return metricsReport
* })
* ```
*
* @since 2.0.0
* @category Debugging
*/
var dump = /*#__PURE__*/ flatMap$2(/*#__PURE__*/ services$1(), (context) => {
	const metrics = snapshotUnsafe(context);
	if (metrics.length > 0) {
		const maxNameLength = metrics.reduce((max, metric) => {
			const length = metric.id.length;
			return length > max ? length : max;
		}, 0) + 2;
		const maxDescriptionLength = metrics.reduce((max, metric) => {
			const length = isNotUndefined(metric.description) ? metric.description.length : 0;
			return length > max ? length : max;
		}, 0) + 2;
		const maxTypeLength = metrics.reduce((max, metric) => {
			const length = metric.type.length;
			return length > max ? length : max;
		}, 0) + 2;
		const maxAttributesLength = metrics.reduce((max, metric) => {
			const length = isNotUndefined(metric.attributes) ? attributesToString(metric.attributes).length : 0;
			return length > max ? length : max;
		}, 0) + 2;
		return succeed$5(sortWith(Object.entries(groupBy(metrics, (metric) => metric.id)), (entry) => entry[0], Order).map(([, group]) => group.map((metric) => renderName(metric, maxNameLength) + renderDescription(metric, maxDescriptionLength) + renderType(metric, maxTypeLength) + renderAttributes(metric, maxAttributesLength) + renderState(metric)).join("\n")).join("\n"));
	}
	return succeed$5("");
});
/**
* Synchronously captures a snapshot of all registered metrics using the provided
* service context.
*
* This is the "unsafe" version that bypasses Effect's safety guarantees and requires
* manual handling of the services context. Use the safe `snapshot` function for normal
* application code.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class UnsafeSnapshotError extends Data.TaggedError("UnsafeSnapshotError")<{
*   readonly operation: string
* }> {}
*
* // Use unsafeSnapshot in performance-critical scenarios or internal implementations
* const performanceMetricsExporter = Effect.gen(function*() {
*   // Create some metrics first
*   const requestCounter = Metric.counter("http_requests", {
*     description: "Total HTTP requests"
*   })
*   const responseTime = Metric.gauge("response_time_ms", {
*     description: "Current response time"
*   })
*
*   // Update metrics
*   yield* Metric.update(requestCounter, 1)
*   yield* Metric.update(responseTime, 150)
*
*   // Get services context for unsafe operations
*   const services = yield* Effect.services()
*
*   // Use snapshotUnsafe for direct, synchronous access
*   const snapshots = Metric.snapshotUnsafe(services)
*
*   // Process snapshots immediately (useful for exporters, debugging tools)
*   const exportData = snapshots.map((snapshot) => ({
*     name: snapshot.id,
*     type: snapshot.type,
*     value: snapshot.state,
*     timestamp: Date.now()
*   }))
*
*   // This is synchronous and doesn't involve Effect overhead
*   // Useful for performance-critical metric export operations
*   return exportData
* })
*
* // For normal application use, prefer the safe snapshot function:
* const safeSnapshotExample = Effect.gen(function*() {
*   // This automatically handles the services context
*   const snapshots = yield* Metric.snapshot
*   return snapshots
* })
* ```
*
* @since 2.0.0
* @category Snapshotting
*/
var snapshotUnsafe = (services) => {
	const registry = get(services, MetricRegistry);
	return Array.from(registry.values()).map(({ hooks, ...meta }) => ({
		...meta,
		state: hooks.get(services)
	}));
};
var renderName = (metric, padTo) => `name=${metric.id.padEnd(padTo, " ")}`;
var renderDescription = (metric, padTo) => `description=${(metric.description ?? "").padEnd(padTo, " ")}`;
var renderType = (metric, padTo) => `type=${metric.type.padEnd(padTo, " ")}`;
var renderAttributes = (metric, padTo) => {
	const attrs = attributesToString(metric.attributes ?? {});
	return `${attrs}${" ".repeat(Math.max(0, padTo - attrs.length))}`;
};
var renderState = (metric) => {
	const prefix = "state=";
	switch (metric.type) {
		case "Counter": return `${prefix}[count: [${metric.state.count}]]`;
		case "Frequency": {
			const state = metric.state;
			return `${prefix}[occurrences: ${renderKeyValues(state.occurrences)}]`;
		}
		case "Gauge": return `${prefix}[value: [${metric.state.value}]]`;
		case "Histogram": {
			const state = metric.state;
			return `${prefix}[${`buckets: [${renderKeyValues(state.buckets)}]`}, ${`count: [${state.count}]`}, ${`min: [${state.min}]`}, ${`max: [${state.max}]`}, ${`sum: [${state.sum}]`}]`;
		}
		case "Summary": {
			const state = metric.state;
			return `${prefix}[${`quantiles: [${renderKeyValues(state.quantiles.map(([key, value]) => [key, value ?? 0]))}]`}, ${`count: [${state.count}]`}, ${`min: [${state.min}]`}, ${`max: [${state.max}]`}, ${`sum: [${state.sum}]`}]`;
		}
	}
};
var renderKeyValues = (keyValues) => Array.from(keyValues).map(([key, value]) => `(${key} -> ${value})`).join(", ");
var attributesToString = (attributes) => {
	return `attributes=[${sortWith(Object.entries(attributes), (attr) => attr[0], Order).map(([key, value]) => `${key}: ${value}`).join(", ")}]`;
};
/**
* A helper method to create histogram bucket boundaries from an iterable set
* of values.
*
* Processes any iterable of numbers by removing duplicates, filtering out
* non-positive values, and automatically appending positive infinity as the
* final boundary.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class BoundaryError extends Data.TaggedError("BoundaryError")<{
*   readonly operation: string
* }> {}
*
* // Create boundaries from an array of custom values
* const customBoundaries = Metric.boundariesFromIterable([
*   10,
*   25,
*   50,
*   100,
*   250,
*   500,
*   1000
* ])
* console.log(customBoundaries) // [10, 25, 50, 100, 250, 500, 1000, Infinity]
*
* // Automatically removes duplicates and negative values
* const messyBoundaries = Metric.boundariesFromIterable([
*   -5,
*   0,
*   10,
*   10,
*   25,
*   25,
*   50,
*   -1
* ])
* console.log(messyBoundaries) // [10, 25, 50, Infinity]
*
* // Works with any iterable (Set, generator functions, etc.)
* const setBoundaries = Metric.boundariesFromIterable(
*   new Set([100, 200, 300, 200, 100])
* )
* console.log(setBoundaries) // [100, 200, 300, Infinity]
*
* // Use with histogram metric
* const responseTimeHistogram = Metric.histogram("response_times", {
*   description: "API response time distribution",
*   boundaries: customBoundaries
* })
*
* const program = Effect.gen(function*() {
*   yield* Metric.update(responseTimeHistogram, 75) // Goes in 50-100ms bucket
*   yield* Metric.update(responseTimeHistogram, 150) // Goes in 100-250ms bucket
*
*   const value = yield* Metric.value(responseTimeHistogram)
*   return value
* })
* ```
*
* @since 2.0.0
* @category Boundaries
*/
var boundariesFromIterable = (iterable) => append(filter$2(new Set(iterable), (n) => n > 0), Number.POSITIVE_INFINITY);
/**
* A helper method to create histogram bucket boundaries with linearly
* increasing values.
*
* Creates evenly-spaced boundaries starting from a base value and incrementing
* by a fixed width. Automatically adds positive infinity as the final boundary.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class BoundaryError extends Data.TaggedError("BoundaryError")<{
*   readonly operation: string
* }> {}
*
* // Create boundaries for response time histogram
* // Buckets: 0-100ms, 100-200ms, 200-300ms, 300-400ms, 400ms+
* const responseBoundaries = Metric.linearBoundaries({
*   start: 0, // Starting point
*   width: 100, // 100ms intervals
*   count: 5 // Creates 4 boundaries + infinity
* })
* console.log(responseBoundaries) // [100, 200, 300, 400, Infinity]
*
* // Create a histogram using these boundaries
* const responseTimeHistogram = Metric.histogram("api_response_time", {
*   description: "API response time distribution",
*   boundaries: responseBoundaries
* })
*
* const program = Effect.gen(function*() {
*   // Record some response times
*   yield* Metric.update(responseTimeHistogram, 85) // Goes in 0-100ms bucket
*   yield* Metric.update(responseTimeHistogram, 250) // Goes in 200-300ms bucket
*   yield* Metric.update(responseTimeHistogram, 450) // Goes in 400ms+ bucket
*
*   const value = yield* Metric.value(responseTimeHistogram)
*   return value
* })
* ```
*
* @since 2.0.0
* @category Boundaries
*/
var linearBoundaries = (options) => boundariesFromIterable(makeBy(options.count - 1, (n) => options.start + n + options.width));
/**
* A helper method to create histogram bucket boundaries with exponentially
* increasing values.
*
* Creates boundaries that grow exponentially, useful for metrics that span
* multiple orders of magnitude. Each boundary is calculated as start * factor^i.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class BoundaryError extends Data.TaggedError("BoundaryError")<{
*   readonly operation: string
* }> {}
*
* // Create exponential boundaries for request size histogram
* // Buckets: 0-1KB, 1-2KB, 2-4KB, 4-8KB, 8KB+
* const sizeBoundaries = Metric.exponentialBoundaries({
*   start: 1, // Starting at 1KB
*   factor: 2, // Each boundary doubles the previous
*   count: 5 // Creates 4 boundaries + infinity
* })
* console.log(sizeBoundaries) // [1, 2, 4, 8, Infinity]
*
* // Create a histogram for tracking request payload sizes
* const requestSizeHistogram = Metric.histogram("request_size_kb", {
*   description: "Request payload size distribution in KB",
*   boundaries: sizeBoundaries
* })
*
* // For very wide ranges, use larger factors
* const latencyBoundaries = Metric.exponentialBoundaries({
*   start: 0.1, // Start at 0.1ms
*   factor: 10, // Each boundary is 10x larger
*   count: 6 // Creates ranges: 0.1ms, 1ms, 10ms, 100ms, 1000ms+
* })
*
* const program = Effect.gen(function*() {
*   // Record different request sizes
*   yield* Metric.update(requestSizeHistogram, 1.5) // Goes in 1-2KB bucket
*   yield* Metric.update(requestSizeHistogram, 3.2) // Goes in 2-4KB bucket
*   yield* Metric.update(requestSizeHistogram, 12) // Goes in 8KB+ bucket
*
*   const value = yield* Metric.value(requestSizeHistogram)
*   return value
* })
* ```
*
* @since 2.0.0
* @category Boundaries
*/
var exponentialBoundaries = (options) => boundariesFromIterable(makeBy(options.count - 1, (i) => options.start * Math.pow(options.factor, i)));
var fibersActive = /*#__PURE__*/ gauge("child_fibers_active", { description: "The current count of active child fibers" });
var fibersStarted = /*#__PURE__*/ counter("child_fibers_started", {
	description: "The total number of child fibers that have been started",
	incremental: true
});
var fiberSuccesses = /*#__PURE__*/ counter("child_fiber_successes", {
	description: "The total number of child fibers that have succeeded",
	incremental: true
});
var fiberFailures = /*#__PURE__*/ counter("child_fiber_failures", {
	description: "The total number of child fibers that have failed",
	incremental: true
});
/**
* Service key for the fiber runtime metrics service.
*
* @example
* ```ts
* import { Data, Effect, Layer, Metric } from "effect"
*
* class MetricsError extends Data.TaggedError("MetricsError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // The key is used internally by the Effect runtime to manage fiber metrics
*   const key = Metric.FiberRuntimeMetricsKey
*   console.log("Fiber metrics key:", key)
*
*   // Enable runtime metrics using the key
*   const layer = Layer.succeed(Metric.FiberRuntimeMetrics)(
*     Metric.FiberRuntimeMetricsImpl
*   )
*
*   return yield* Effect.gen(function*() {
*     // This Effect will have fiber metrics automatically collected
*     yield* Effect.sleep("100 millis")
*
*     // Create a test counter to demonstrate the key usage
*     const testCounter = Metric.counter("test_counter")
*     yield* Metric.update(testCounter, 1)
*     return yield* Metric.value(testCounter)
*   }).pipe(Effect.provide(layer))
* })
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var FiberRuntimeMetricsKey = FiberRuntimeMetricsKey$1;
/**
* Service class for managing fiber runtime metrics collection.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class MetricsError extends Data.TaggedError("MetricsError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Access the fiber runtime metrics service
*   const metricsService = yield* Metric.FiberRuntimeMetrics
*
*   if (metricsService) {
*     console.log("Runtime metrics are enabled")
*   } else {
*     console.log("Runtime metrics are disabled")
*   }
*
*   // Enable runtime metrics for the application
*   const enabledLayer = Metric.enableRuntimeMetricsLayer
*
*   return yield* Effect.gen(function*() {
*     // Create some concurrent fibers to see metrics in action
*     yield* Effect.all([
*       Effect.sleep("100 millis"),
*       Effect.sleep("200 millis"),
*       Effect.sleep("300 millis")
*     ], { concurrency: "unbounded" })
*
*     // Create test metrics to demonstrate the service
*     const testCounter = Metric.counter("test_counter")
*     yield* Metric.update(testCounter, 5)
*     const counterValue = yield* Metric.value(testCounter)
*
*     return { counterValue, metricsEnabled: true }
*   }).pipe(Effect.provide(enabledLayer))
* })
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var FiberRuntimeMetrics = /*#__PURE__*/ Reference(FiberRuntimeMetricsKey$1, { defaultValue: constUndefined });
/**
* Default implementation of the fiber runtime metrics service.
*
* @example
* ```ts
* import { Data, Effect, Layer, Metric } from "effect"
*
* class MetricsError extends Data.TaggedError("MetricsError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Use the default metrics implementation
*   const metrics = Metric.FiberRuntimeMetricsImpl
*   console.log("Metrics implementation:", metrics)
*
*   // Enable runtime metrics using the default implementation
*   const layer = Layer.succeed(Metric.FiberRuntimeMetrics)(metrics)
*
*   return yield* Effect.gen(function*() {
*     // Run some Effects to trigger metric collection
*     yield* Effect.forkChild(Effect.sleep("50 millis"))
*     yield* Effect.forkChild(Effect.sleep("100 millis"))
*
*     // Wait a bit and check the metrics
*     yield* Effect.sleep("200 millis")
*
*     // Create test metrics to demonstrate the implementation
*     const testCounter = Metric.counter("test_counter")
*     const testGauge = Metric.gauge("test_gauge")
*     yield* Metric.update(testCounter, 3)
*     yield* Metric.update(testGauge, 42)
*
*     const counterValue = yield* Metric.value(testCounter)
*     const gaugeValue = yield* Metric.value(testGauge)
*
*     return { counter: counterValue, gauge: gaugeValue }
*   }).pipe(Effect.provide(layer))
* })
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var FiberRuntimeMetricsImpl = {
	recordFiberStart(context) {
		fibersStarted.updateUnsafe(1, context);
		fibersActive.modifyUnsafe(1, context);
	},
	recordFiberEnd(context, exit) {
		fibersActive.modifyUnsafe(-1, context);
		if (exitIsSuccess(exit)) fiberSuccesses.updateUnsafe(1, context);
		else fiberFailures.updateUnsafe(1, context);
	}
};
/**
* A Layer that enables automatic collection of fiber runtime metrics across
* an entire Effect application.
*
* Unlike the function version which wraps individual Effects, this layer provides
* runtime metrics collection to all Effects in the application context. This is
* the recommended approach for production applications that need comprehensive
* fiber monitoring.
*
* @example
* ```ts
* import { Console, Data, Effect, Layer, Metric } from "effect"
*
* class AppError extends Data.TaggedError("AppError")<{
*   readonly operation: string
* }> {}
*
* // Define your application logic
* const userService = Effect.gen(function*() {
*   // Simulate user operations with concurrent processing
*   const fetchUser = (id: number) =>
*     Effect.gen(function*() {
*       yield* Effect.sleep(`${50 + id * 10} millis`)
*       if (id % 7 === 0) {
*         yield* Effect.fail(new AppError({ operation: `fetch-user-${id}` }))
*       }
*       return { id, name: `User ${id}`, email: `user${id}@example.com` }
*     })
*
*   // Process multiple users concurrently (ignoring failures for demo)
*   const userIds = Array.from({ length: 10 }, (_, i) => i + 1)
*   const userTasks = userIds.map((id) =>
*     fetchUser(id).pipe(Effect.catchTag("AppError", () => Effect.succeed(null)))
*   )
*   const allUsers = yield* Effect.all(userTasks, { concurrency: 4 })
*   const successfulUsers = allUsers.filter((user) => user !== null)
*   return successfulUsers
* })
*
* const analyticsService = Effect.gen(function*() {
*   // Simulate analytics processing
*   const tasks = Array.from({ length: 8 }, (_, i) =>
*     Effect.gen(function*() {
*       yield* Effect.sleep(`${100 + i * 25} millis`)
*       return `Analytics task ${i} completed`
*     }))
*   return yield* Effect.all(tasks, { concurrency: 3 })
* })
*
* // Main application that uses multiple services
* const application = Effect.gen(function*() {
*   yield* Console.log("Starting application with runtime metrics...")
*
*   // Run services concurrently
*   const [users, analytics] = yield* Effect.all([
*     userService,
*     analyticsService
*   ], { concurrency: 2 })
*
*   yield* Console.log(
*     `Processed ${users.length} users and ${analytics.length} analytics tasks`
*   )
*
*   // Inspect the automatically collected runtime metrics
*   const metrics = yield* Metric.snapshot
*   const runtimeMetrics = metrics.filter((m) => m.id.startsWith("child_fiber"))
*
*   yield* Console.log("Runtime Metrics Collected:")
*   for (const metric of runtimeMetrics) {
*     yield* Console.log(`  ${metric.id}: ${JSON.stringify(metric.state)}`)
*   }
*
*   return { users, analytics, metricsCount: runtimeMetrics.length }
* })
*
* // Create the base application layer
* const AppLayer = Layer.empty // Add your application layers here (database, HTTP, etc.)
*
* // Add runtime metrics layer at the end
* const AppLayerWithMetrics = AppLayer.pipe(
*   Layer.provide(Metric.enableRuntimeMetricsLayer)
* )
*
* // Run the application with runtime metrics enabled
* const program = application.pipe(
*   Effect.provide(AppLayerWithMetrics)
* )
*
* // Alternative: Provide runtime metrics directly to the application
* const programWithDirectMetrics = application.pipe(
*   Effect.provide(Metric.enableRuntimeMetricsLayer)
* )
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var enableRuntimeMetricsLayer = /*#__PURE__*/ succeed$2(FiberRuntimeMetrics)(FiberRuntimeMetricsImpl);
/**
* A Layer that disables automatic collection of fiber runtime metrics.
*
* @example
* ```ts
* import { Data, Effect, Metric } from "effect"
*
* class MetricsError extends Data.TaggedError("MetricsError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Disable runtime metrics collection
*   const disabledLayer = Metric.disableRuntimeMetricsLayer
*
*   return yield* Effect.gen(function*() {
*     // Check that metrics service is disabled
*     const metricsService = yield* Metric.FiberRuntimeMetrics
*     console.log("Metrics enabled:", metricsService !== undefined) // false
*
*     // Run some Effects - no metrics will be collected
*     yield* Effect.forkChild(Effect.sleep("50 millis"))
*     yield* Effect.forkChild(Effect.sleep("100 millis"))
*     yield* Effect.sleep("200 millis")
*
*     // Create test metrics to show they still work
*     const testCounter = Metric.counter("test_counter")
*     yield* Metric.update(testCounter, 1)
*     const counterValue = yield* Metric.value(testCounter)
*
*     return { counterValue, metricsEnabled: metricsService !== undefined }
*   }).pipe(Effect.provide(disabledLayer))
* })
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var disableRuntimeMetricsLayer = /*#__PURE__*/ succeed$2(FiberRuntimeMetrics)(void 0);
/**
* Enables automatic collection of fiber runtime metrics for the provided Effect.
*
* When enabled, automatically tracks fiber lifecycle metrics including active fibers,
* started fibers, successful completions, and failures. These metrics provide valuable
* insights into the concurrency patterns and health of your Effect application.
*
* @example
* ```ts
* import { Console, Data, Effect, Layer, Metric } from "effect"
*
* class RuntimeMetricsError extends Data.TaggedError("RuntimeMetricsError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a concurrent workload to demonstrate fiber metrics
*   const heavyWorkload = Effect.gen(function*() {
*     // Simulate concurrent operations
*     const tasks = Array.from({ length: 10 }, (_, i) =>
*       Effect.gen(function*() {
*         yield* Effect.sleep(`${100 + i * 50} millis`)
*         if (i % 4 === 0) {
*           // Simulate some failures
*           yield* Effect.fail(
*             new RuntimeMetricsError({ operation: `task-${i}` })
*           )
*         }
*         return `Task ${i} completed`
*       }).pipe(
*         Effect.catchTag("RuntimeMetricsError", () =>
*           Effect.succeed(`Task ${i} failed`))
*       ))
*
*     // Run tasks concurrently
*     const results = yield* Effect.all(tasks, { concurrency: 5 })
*     return results
*   })
*
*   // Enable runtime metrics collection for our workload
*   const workloadWithMetrics = Metric.enableRuntimeMetrics(heavyWorkload)
*
*   // Execute the workload
*   const results = yield* workloadWithMetrics
*
*   // After execution, we can inspect the runtime metrics
*   // The following metrics are automatically collected:
*   // - child_fibers_active: Current number of active child fibers (Gauge)
*   // - child_fibers_started: Total child fibers started (Counter, incremental)
*   // - child_fiber_successes: Total successful child fibers (Counter, incremental)
*   // - child_fiber_failures: Total failed child fibers (Counter, incremental)
*
*   yield* Console.log(`Workload completed with ${results.length} results`)
*
*   // Get all metrics including the runtime metrics
*   const allMetrics = yield* Metric.snapshot
*   const runtimeMetrics = allMetrics.filter((m) =>
*     m.id.startsWith("child_fiber") || m.id.includes("fiber")
*   )
*
*   yield* Console.log("Runtime Metrics:")
*   for (const metric of runtimeMetrics) {
*     yield* Console.log(`  ${metric.id}: ${JSON.stringify(metric.state)}`)
*   }
*
*   return results
* })
*
* // Alternative: Use the layer version for broader application coverage
* const BaseAppLayer = Layer.empty // Your base application layers
* const AppLayerWithMetrics = BaseAppLayer.pipe(
*   Layer.provide(Metric.enableRuntimeMetricsLayer)
* )
* const programWithLayer = program.pipe(
*   Effect.provide(AppLayerWithMetrics)
* )
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var enableRuntimeMetrics = /*#__PURE__*/ provideService$1(FiberRuntimeMetrics, FiberRuntimeMetricsImpl);
/**
* Disables automatic collection of fiber runtime metrics for the provided Effect.
*
* This is useful when you want to selectively disable runtime metrics for specific
* parts of your application while keeping them enabled elsewhere, or when you need
* to avoid the overhead of metrics collection in performance-critical sections.
*
* @example
* ```ts
* import { Console, Data, Effect, Layer, Metric } from "effect"
*
* class DisableMetricsError extends Data.TaggedError("DisableMetricsError")<{
*   readonly operation: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // This section will have runtime metrics enabled
*   const normalOperation = Effect.gen(function*() {
*     const tasks = Array.from({ length: 5 }, (_, i) =>
*       Effect.gen(function*() {
*         yield* Effect.sleep(`${100 + i * 20} millis`)
*         return `Normal task ${i} completed`
*       }))
*     return yield* Effect.all(tasks, { concurrency: 3 })
*   })
*
*   // This section will have runtime metrics disabled for performance
*   const highPerformanceOperation = Metric.disableRuntimeMetrics(
*     Effect.gen(function*() {
*       // Performance-critical code where metrics overhead should be avoided
*       const hotPath = Array.from(
*         { length: 1000 },
*         (_, i) =>
*           Effect.gen(function*() {
*             // Simulate intensive computation
*             const result = i * i + Math.random()
*             return result
*           })
*       )
*       return yield* Effect.all(hotPath, { concurrency: 100 })
*     })
*   )
*
*   yield* Console.log("Running operations with selective metrics...")
*
*   // Run both operations
*   const [normalResults, performanceResults] = yield* Effect.all([
*     normalOperation, // Will generate fiber metrics
*     highPerformanceOperation // Will NOT generate fiber metrics
*   ])
*
*   // Check collected metrics - should only see metrics from normalOperation
*   const metrics = yield* Metric.snapshot
*   const runtimeMetrics = metrics.filter((m) => m.id.startsWith("child_fiber"))
*
*   yield* Console.log(`Normal operation results: ${normalResults.length}`)
*   yield* Console.log(
*     `Performance operation results: ${performanceResults.length}`
*   )
*   yield* Console.log(`Runtime metrics collected: ${runtimeMetrics.length}`)
*
*   // The runtime metrics will only reflect the fibers from normalOperation
*   // The highPerformanceOperation fibers were not tracked due to disableRuntimeMetrics
*
*   return { normalResults, performanceResults, runtimeMetrics }
* })
*
* // Enable runtime metrics globally, then selectively disable where needed
* const BaseAppLayer = Layer.empty // Your base application layers
* const AppLayerWithMetrics = BaseAppLayer.pipe(
*   Layer.provide(Metric.enableRuntimeMetricsLayer)
* )
* const finalProgram = program.pipe(
*   Effect.provide(AppLayerWithMetrics)
* )
* ```
*
* @since 4.0.0
* @category Runtime Metrics
*/
var disableRuntimeMetrics = /*#__PURE__*/ provideService$1(FiberRuntimeMetrics, void 0);
function makeKey(metric, attributes) {
	let key = `${metric.type}:${metric.id}`;
	if (isNotUndefined(metric.description)) key += `:${metric.description}`;
	if (isNotUndefined(attributes)) key += `:${serializeAttributes(attributes)}`;
	return key;
}
function makeHooks(get, update, modify) {
	return {
		get,
		update,
		modify: modify ?? update
	};
}
function serializeAttributes(attributes) {
	return serializeEntries(Array.isArray(attributes) ? attributes : Object.entries(attributes));
}
function serializeEntries(entries) {
	return entries.map(([key, value]) => `${key}=${value}`).join(",");
}
function mergeAttributes(self, other) {
	return {
		...attributesToRecord(self),
		...attributesToRecord(other)
	};
}
function attributesToRecord(attributes) {
	if (isNotUndefined(attributes) && Array.isArray(attributes)) return attributes.reduce((acc, [key, value]) => {
		acc[key] = value;
		return acc;
	}, {});
	return attributes;
}
function addAttributesToServiceMap(context, attributes) {
	return add$1(context, CurrentMetricAttributes, mergeAttributes(get(context, CurrentMetricAttributes), attributes));
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Effect.js
var Effect_exports = /* @__PURE__ */ __exportAll({
	Do: () => Do,
	Transaction: () => Transaction,
	YieldableClass: () => YieldableClass,
	acquireRelease: () => acquireRelease,
	acquireUseRelease: () => acquireUseRelease,
	addFinalizer: () => addFinalizer,
	all: () => all,
	andThen: () => andThen,
	annotateCurrentSpan: () => annotateCurrentSpan,
	annotateLogs: () => annotateLogs,
	annotateLogsScoped: () => annotateLogsScoped,
	annotateSpans: () => annotateSpans,
	as: () => as,
	asSome: () => asSome,
	asVoid: () => asVoid,
	awaitAllChildren: () => awaitAllChildren,
	bind: () => bind,
	bindTo: () => bindTo,
	cached: () => cached,
	cachedInvalidateWithTTL: () => cachedInvalidateWithTTL,
	cachedWithTTL: () => cachedWithTTL,
	callback: () => callback,
	catch: () => catch_,
	catchCause: () => catchCause,
	catchCauseFilter: () => catchCauseFilter,
	catchCauseIf: () => catchCauseIf,
	catchDefect: () => catchDefect,
	catchEager: () => catchEager,
	catchFilter: () => catchFilter,
	catchIf: () => catchIf,
	catchNoSuchElement: () => catchNoSuchElement,
	catchReason: () => catchReason,
	catchReasons: () => catchReasons,
	catchTag: () => catchTag,
	catchTags: () => catchTags,
	clockWith: () => clockWith,
	currentParentSpan: () => currentParentSpan,
	currentSpan: () => currentSpan,
	delay: () => delay,
	die: () => die,
	effectify: () => effectify,
	ensuring: () => ensuring,
	eventually: () => eventually,
	exit: () => exit,
	fail: () => fail,
	failCause: () => failCause,
	failCauseSync: () => failCauseSync,
	failSync: () => failSync,
	fiber: () => fiber,
	fiberId: () => fiberId,
	filter: () => filter,
	filterMap: () => filterMap,
	filterMapEffect: () => filterMapEffect,
	filterMapOrElse: () => filterMapOrElse,
	filterMapOrFail: () => filterMapOrFail,
	filterOrElse: () => filterOrElse,
	filterOrFail: () => filterOrFail,
	findFirst: () => findFirst,
	findFirstFilter: () => findFirstFilter,
	flatMap: () => flatMap,
	flatMapEager: () => flatMapEager,
	flatten: () => flatten,
	flip: () => flip,
	fn: () => fn,
	fnUntraced: () => fnUntraced,
	fnUntracedEager: () => fnUntracedEager,
	forEach: () => forEach,
	forever: () => forever,
	forkChild: () => forkChild,
	forkDetach: () => forkDetach,
	forkIn: () => forkIn,
	forkScoped: () => forkScoped,
	fromNullishOr: () => fromNullishOr,
	fromOption: () => fromOption,
	fromResult: () => fromResult,
	fromYieldable: () => fromYieldable,
	gen: () => gen,
	ignore: () => ignore,
	ignoreCause: () => ignoreCause,
	interrupt: () => interrupt,
	interruptible: () => interruptible,
	interruptibleMask: () => interruptibleMask,
	isEffect: () => isEffect,
	isFailure: () => isFailure,
	isSuccess: () => isSuccess,
	let: () => let_,
	linkSpans: () => linkSpans,
	log: () => log,
	logDebug: () => logDebug,
	logError: () => logError,
	logFatal: () => logFatal,
	logInfo: () => logInfo,
	logTrace: () => logTrace,
	logWarning: () => logWarning,
	logWithLevel: () => logWithLevel,
	makeSpan: () => makeSpan,
	makeSpanScoped: () => makeSpanScoped,
	map: () => map,
	mapBoth: () => mapBoth,
	mapBothEager: () => mapBothEager,
	mapEager: () => mapEager,
	mapError: () => mapError,
	mapErrorEager: () => mapErrorEager,
	match: () => match,
	matchCause: () => matchCause,
	matchCauseEager: () => matchCauseEager,
	matchCauseEffect: () => matchCauseEffect,
	matchCauseEffectEager: () => matchCauseEffectEager,
	matchEager: () => matchEager,
	matchEffect: () => matchEffect,
	never: () => never,
	onError: () => onError,
	onErrorFilter: () => onErrorFilter,
	onErrorIf: () => onErrorIf,
	onExit: () => onExit,
	onExitFilter: () => onExitFilter,
	onExitIf: () => onExitIf,
	onExitPrimitive: () => onExitPrimitive,
	onInterrupt: () => onInterrupt,
	option: () => option,
	orDie: () => orDie,
	orElseSucceed: () => orElseSucceed,
	partition: () => partition,
	promise: () => promise,
	provide: () => provide,
	provideService: () => provideService,
	provideServiceEffect: () => provideServiceEffect,
	provideServices: () => provideServices,
	race: () => race,
	raceAll: () => raceAll,
	raceAllFirst: () => raceAllFirst,
	raceFirst: () => raceFirst,
	repeat: () => repeat,
	repeatOrElse: () => repeatOrElse,
	replicate: () => replicate,
	replicateEffect: () => replicateEffect,
	request: () => request,
	requestUnsafe: () => requestUnsafe,
	result: () => result,
	retry: () => retry,
	retryOrElse: () => retryOrElse,
	retryTransaction: () => retryTransaction,
	runCallback: () => runCallback,
	runCallbackWith: () => runCallbackWith,
	runFork: () => runFork,
	runForkWith: () => runForkWith,
	runPromise: () => runPromise,
	runPromiseExit: () => runPromiseExit,
	runPromiseExitWith: () => runPromiseExitWith,
	runPromiseWith: () => runPromiseWith,
	runSync: () => runSync,
	runSyncExit: () => runSyncExit,
	runSyncExitWith: () => runSyncExitWith,
	runSyncWith: () => runSyncWith,
	sandbox: () => sandbox,
	satisfiesErrorType: () => satisfiesErrorType,
	satisfiesServicesType: () => satisfiesServicesType,
	satisfiesSuccessType: () => satisfiesSuccessType,
	schedule: () => schedule,
	scheduleFrom: () => scheduleFrom,
	scope: () => scope,
	scoped: () => scoped,
	scopedWith: () => scopedWith,
	service: () => service,
	serviceOption: () => serviceOption,
	services: () => services,
	servicesWith: () => servicesWith,
	sleep: () => sleep,
	spanAnnotations: () => spanAnnotations,
	spanLinks: () => spanLinks,
	succeed: () => succeed,
	succeedNone: () => succeedNone,
	succeedSome: () => succeedSome,
	suspend: () => suspend,
	sync: () => sync,
	tap: () => tap,
	tapCause: () => tapCause,
	tapCauseFilter: () => tapCauseFilter,
	tapCauseIf: () => tapCauseIf,
	tapDefect: () => tapDefect,
	tapError: () => tapError,
	tapErrorTag: () => tapErrorTag,
	timed: () => timed,
	timeout: () => timeout,
	timeoutOption: () => timeoutOption,
	timeoutOrElse: () => timeoutOrElse,
	tracer: () => tracer,
	track: () => track,
	trackDefects: () => trackDefects,
	trackDuration: () => trackDuration,
	trackErrors: () => trackErrors,
	trackSuccesses: () => trackSuccesses,
	transaction: () => transaction,
	transactionWith: () => transactionWith,
	try: () => try_,
	tryPromise: () => tryPromise,
	undefined: () => undefined_,
	uninterruptible: () => uninterruptible,
	uninterruptibleMask: () => uninterruptibleMask,
	unwrapReason: () => unwrapReason,
	updateService: () => updateService,
	updateServices: () => updateServices,
	useSpan: () => useSpan,
	validate: () => validate,
	void: () => void_,
	when: () => when,
	whileLoop: () => whileLoop,
	withConcurrency: () => withConcurrency,
	withErrorReporting: () => withErrorReporting,
	withExecutionPlan: () => withExecutionPlan,
	withFiber: () => withFiber,
	withLogSpan: () => withLogSpan,
	withLogger: () => withLogger,
	withParentSpan: () => withParentSpan,
	withSpan: () => withSpan,
	withSpanScoped: () => withSpanScoped,
	withTracer: () => withTracer,
	withTracerEnabled: () => withTracerEnabled,
	withTracerTiming: () => withTracerTiming,
	withTxState: () => withTxState,
	yieldNow: () => yieldNow,
	yieldNowWith: () => yieldNowWith,
	zip: () => zip,
	zipWith: () => zipWith
});
var TypeId = EffectTypeId;
/**
* @since 4.0.0
* @category Yieldable
*/
var YieldableClass = class {
	[Symbol.iterator]() {
		return new SingleShotGen(this);
	}
};
/**
* Tests if a value is an `Effect`.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* console.log(Effect.isEffect(Effect.succeed(1))) // true
* console.log(Effect.isEffect("hello")) // false
* ```
*
* @since 2.0.0
* @category Guards
*/
var isEffect = (u) => typeof u === "object" && u !== null && TypeId in u;
/**
* Combines multiple effects into one, returning results based on the input
* structure.
*
* **Details**
*
* Use this function when you need to run multiple effects and combine their
* results into a single output. It supports tuples, iterables, structs, and
* records, making it flexible for different input types.
*
* For instance, if the input is a tuple:
*
* ```ts skip-type-checking
* //         ┌─── a tuple of effects
* //         ▼
* Effect.all([effect1, effect2, ...])
* ```
*
* the effects are executed sequentially, and the result is a new effect
* containing the results as a tuple. The results in the tuple match the order
* of the effects passed to `Effect.all`.
*
* **Concurrency**
*
* You can control the execution order (e.g., sequential vs. concurrent) using
* the `concurrency` option.
*
* **Short-Circuiting Behavior**
*
* This function stops execution on the first error it encounters, this is
* called "short-circuiting". If any effect in the collection fails, the
* remaining effects will not run, and the error will be propagated. To change
* this behavior, you can use the `mode` option, which allows all effects to run
* and collect every success / failure as `Result` values.
*
* **The `mode` option**
*
* The `{ mode: "result" }` option changes the behavior of `Effect.all` to
* ensure all effects run, even if some fail. Instead of stopping on the first
* failure, this mode collects both successes and failures, returning an array
* of `Result` instances where each result is either an `Ok` (success) or a
* `Err` (failure).
*
* @example Combining Effects in Tuples
* ```ts
* import { Console, Effect } from "effect"
*
* const tupleOfEffects = [
*   Effect.succeed(42).pipe(Effect.tap(Console.log)),
*   Effect.succeed("Hello").pipe(Effect.tap(Console.log))
* ] as const
*
* //      ┌─── Effect<[number, string], never, never>
* //      ▼
* const resultsAsTuple = Effect.all(tupleOfEffects)
*
* Effect.runPromise(resultsAsTuple).then(console.log)
* // Output:
* // 42
* // Hello
* // [ 42, 'Hello' ]
* ```
*
* @example Combining Effects in Iterables
* ```ts
* import { Console, Effect } from "effect"
*
* const iterableOfEffects: Iterable<Effect.Effect<number>> = [1, 2, 3].map(
*   (n) => Effect.succeed(n).pipe(Effect.tap(Console.log))
* )
*
* //      ┌─── Effect<number[], never, never>
* //      ▼
* const resultsAsArray = Effect.all(iterableOfEffects)
*
* Effect.runPromise(resultsAsArray).then(console.log)
* // Output:
* // 1
* // 2
* // 3
* // [ 1, 2, 3 ]
* ```
*
* @example Combining Effects in Structs
* ```ts
* import { Console, Effect } from "effect"
*
* const structOfEffects = {
*   a: Effect.succeed(42).pipe(Effect.tap(Console.log)),
*   b: Effect.succeed("Hello").pipe(Effect.tap(Console.log))
* }
*
* //      ┌─── Effect<{ a: number; b: string; }, never, never>
* //      ▼
* const resultsAsStruct = Effect.all(structOfEffects)
*
* Effect.runPromise(resultsAsStruct).then(console.log)
* // Output:
* // 42
* // Hello
* // { a: 42, b: 'Hello' }
* ```
*
* @example Combining Effects in Records
* ```ts
* import { Console, Effect } from "effect"
*
* const recordOfEffects: Record<string, Effect.Effect<number>> = {
*   key1: Effect.succeed(1).pipe(Effect.tap(Console.log)),
*   key2: Effect.succeed(2).pipe(Effect.tap(Console.log))
* }
*
* //      ┌─── Effect<{ [x: string]: number; }, never, never>
* //      ▼
* const resultsAsRecord = Effect.all(recordOfEffects)
*
* Effect.runPromise(resultsAsRecord).then(console.log)
* // Output:
* // 1
* // 2
* // { key1: 1, key2: 2 }
* ```
*
* @example Short-Circuiting Behavior
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.all([
*   Effect.succeed("Task1").pipe(Effect.tap(Console.log)),
*   Effect.fail("Task2: Oh no!").pipe(Effect.tap(Console.log)),
*   // Won't execute due to earlier failure
*   Effect.succeed("Task3").pipe(Effect.tap(Console.log))
* ])
*
* Effect.runPromiseExit(program).then(console.log)
* // Output:
* // Task1
* // {
* //   _id: 'Exit',
* //   _tag: 'Failure',
* //   cause: { _id: 'Cause', _tag: 'Fail', failure: 'Task2: Oh no!' }
* // }
* ```
*
* @see {@link forEach} for iterating over elements and applying an effect.
*
* @since 2.0.0
* @category Collecting
*/
var all = all$1;
/**
* Applies an effectful function to each element and partitions failures and
* successes.
*
* The returned tuple is `[excluded, satisfying]`, where:
*
* - `excluded` contains all failures.
* - `satisfying` contains all successes.
*
* This function runs every effect and never fails. Use `concurrency` to control
* parallelism.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.partition([0, 1, 2, 3], (n) =>
*   n % 2 === 0 ? Effect.fail(`${n} is even`) : Effect.succeed(n)
* )
*
* Effect.runPromise(program).then(console.log)
* // [ ["0 is even", "2 is even"], [1, 3] ]
* ```
*
* @since 3.0.0
* @category Collecting
*/
var partition = partition$1;
/**
* Applies an effectful function to each element and accumulates all failures.
*
* This function always evaluates every element. If at least one effect fails,
* all failures are returned as a non-empty array and successes are discarded.
* If all effects succeed, it returns all collected successes.
*
* Use `discard: true` to ignore successful values while still validating all
* elements.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.validate([0, 1, 2, 3], (n) =>
*   n % 2 === 0 ? Effect.fail(`${n} is even`) : Effect.succeed(n)
* )
*
* Effect.runPromiseExit(program).then(console.log)
* // {
* //   _id: 'Exit',
* //   _tag: 'Failure',
* //   cause: {
* //     _id: 'Cause',
* //     reasons: [
* //       { _id: 'Reason', _tag: 'Fail', error: '0 is even' },
* //       { _id: 'Reason', _tag: 'Fail', error: '2 is even' }
* //     ]
* //   }
* // }
* ```
*
* @since 4.0.0
* @category Error Accumulation
*/
var validate = validate$1;
/**
* Returns the first element that satisfies an effectful predicate.
*
* The predicate receives the element and its index. Evaluation short-circuits
* as soon as an element matches.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.findFirst([1, 2, 3, 4], (n) => Effect.succeed(n > 2))
*
* Effect.runPromise(program).then(console.log)
* // { _id: 'Option', _tag: 'Some', value: 3 }
* ```
*
* @since 2.0.0
* @category Collecting
*/
var findFirst = findFirst$1;
/**
* Returns the first value that passes an effectful `FilterEffect`.
*
* The filter receives the element and index. Evaluation short-circuits on the
* first `Result.succeed` and returns the transformed value in `Option.some`.
*
* @since 4.0.0
* @category Collecting
*/
var findFirstFilter = findFirstFilter$1;
/**
* Executes an effectful operation for each element in an `Iterable`.
*
* **Details**
*
* The `forEach` function applies a provided operation to each element in the
* iterable, producing a new effect that returns an array of results.
*
* If any effect fails, the iteration stops immediately (short-circuiting), and
* the error is propagated.
*
* **Concurrency**
*
* The `concurrency` option controls how many operations are performed
* concurrently. By default, the operations are performed sequentially.
*
* **Discarding Results**
*
* If the `discard` option is set to `true`, the intermediate results are not
* collected, and the final result of the operation is `void`.
*
* @see {@link all} for combining multiple effects into one.
*
* @example
* ```ts
* // Title: Applying Effects to Iterable Elements
* import { Effect } from "effect"
* import { Console } from "effect"
*
* const result = Effect.forEach(
*   [1, 2, 3, 4, 5],
*   (n, index) =>
*     Console.log(`Currently at index ${index}`).pipe(Effect.as(n * 2))
* )
*
* Effect.runPromise(result).then(console.log)
* // Output:
* // Currently at index 0
* // Currently at index 1
* // Currently at index 2
* // Currently at index 3
* // Currently at index 4
* // [ 2, 4, 6, 8, 10 ]
* ```
*
* @example
* // Title: Using discard to Ignore Results
* import { Effect } from "effect"
* import { Console } from "effect"
*
* // Apply effects but discard the results
* const result = Effect.forEach(
*   [1, 2, 3, 4, 5],
*   (n, index) =>
*     Console.log(`Currently at index ${index}`).pipe(Effect.as(n * 2)),
*   { discard: true }
* )
*
* Effect.runPromise(result).then(console.log)
* // Output:
* // Currently at index 0
* // Currently at index 1
* // Currently at index 2
* // Currently at index 3
* // Currently at index 4
* // undefined
*
* @since 2.0.0
* @category Collecting
*/
var forEach = forEach$1;
/**
* Executes a body effect repeatedly while a condition holds true.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* let counter = 0
*
* const program = Effect.whileLoop({
*   while: () => counter < 5,
*   body: () => Effect.sync(() => ++counter),
*   step: (n) => console.log(`Current count: ${n}`)
* })
*
* Effect.runPromise(program)
* // Output:
* // Current count: 1
* // Current count: 2
* // Current count: 3
* // Current count: 4
* // Current count: 5
* ```
*
* @since 2.0.0
* @category Collecting
*/
var whileLoop = whileLoop$1;
/**
* Creates an `Effect` that represents an asynchronous computation guaranteed to
* succeed.
*
* **When to Use**
*
* Use `promise` when you are sure the operation will not reject.
*
* **Details**
*
* The provided function (`thunk`) returns a `Promise` that should never reject; if it does, the error
* will be treated as a "defect".
*
* This defect is not a standard error but indicates a flaw in the logic that
* was expected to be error-free. You can think of it similar to an unexpected
* crash in the program, which can be further managed or logged using tools like
* {@link catchAllDefect}.
*
* **Interruptions**
*
* An optional `AbortSignal` can be provided to allow for interruption of the
* wrapped `Promise` API.
*
* @see {@link tryPromise} for a version that can handle failures.
*
* @example
* ```ts
* // Title: Delayed Message
* import { Effect } from "effect"
*
* const delay = (message: string) =>
*   Effect.promise<string>(
*     () =>
*       new Promise((resolve) => {
*         setTimeout(() => {
*           resolve(message)
*         }, 2000)
*       })
*   )
*
* //      ┌─── Effect<string, never, never>
* //      ▼
* const program = delay("Async operation completed successfully!")
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var promise = promise$1;
/**
* Creates an `Effect` that represents an asynchronous computation that might
* fail.
*
* **When to Use**
*
* In situations where you need to perform asynchronous operations that might
* fail, such as fetching data from an API, you can use the `tryPromise`
* constructor. This constructor is designed to handle operations that could
* throw exceptions by capturing those exceptions and transforming them into
* manageable errors.
*
* **Error Handling**
*
* There are two ways to handle errors with `tryPromise`:
*
* 1. If you don't provide a `catch` function, the error is caught and the
*    effect fails with an `UnknownError`.
* 2. If you provide a `catch` function, the error is caught and the `catch`
*    function maps it to an error of type `E`.
*
* **Interruptions**
*
* An optional `AbortSignal` can be provided to allow for interruption of the
* wrapped `Promise` API.
*
* @example Fetching a TODO Item
* ```ts
* import { Effect } from "effect"
*
* const getTodo = (id: number) =>
*   // Will catch any errors and propagate them as UnknownError
*   Effect.tryPromise(() =>
*     fetch(`https://jsonplaceholder.typicode.com/todos/${id}`)
*   )
*
* //      ┌─── Effect<Response, UnknownError, never>
* //      ▼
* const program = getTodo(1)
* ```
*
* @example Custom Error Handling
* ```ts
* import { Effect } from "effect"
*
* const getTodo = (id: number) =>
*   Effect.tryPromise({
*     try: () => fetch(`https://jsonplaceholder.typicode.com/todos/${id}`),
*     // remap the error
*     catch: (unknown) => new Error(`something went wrong ${unknown}`)
*   })
*
* //      ┌─── Effect<Response, Error, never>
* //      ▼
* const program = getTodo(1)
* ```
*
* @see {@link promise} if the effectful computation is asynchronous and does not throw errors.
*
* @since 2.0.0
* @category Creating Effects
*/
var tryPromise = tryPromise$1;
/**
* Creates an `Effect` that always succeeds with a given value.
*
* **When to Use**
*
* Use this function when you need an effect that completes successfully with a
* specific value without any errors or external dependencies.
*
* @see {@link fail} to create an effect that represents a failure.
*
* @example
* ```ts
* // Title: Creating a Successful Effect
* import { Effect } from "effect"
*
* // Creating an effect that represents a successful scenario
* //
* //      ┌─── Effect<number, never, never>
* //      ▼
* const success = Effect.succeed(42)
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var succeed = succeed$5;
/**
* Returns an effect which succeeds with `None`.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.succeedNone
*
* Effect.runPromise(program).then(console.log)
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var succeedNone = succeedNone$1;
/**
* Returns an effect which succeeds with the value wrapped in a `Some`.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.succeedSome(42)
*
* Effect.runPromise(program).then(console.log)
* // Output: { _id: 'Option', _tag: 'Some', value: 42 }
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var succeedSome = succeedSome$1;
/**
* Delays the creation of an `Effect` until it is actually needed.
*
* **When to Use**
*
* Use `suspend` when you need to defer the evaluation of an effect until it is required. This is particularly useful for optimizing expensive computations, managing circular dependencies, or resolving type inference issues.
*
* **Details**
*
* `suspend` takes a thunk that represents the effect and wraps it in a suspended effect. This means the effect will not be created until it is explicitly needed, which is helpful in various scenarios:
* - **Lazy Evaluation**: Helps optimize performance by deferring computations, especially when the effect might not be needed, or when its computation is expensive. This also ensures that any side effects or scoped captures are re-executed on each invocation.
* - **Handling Circular Dependencies**: Useful in managing circular dependencies, such as recursive functions that need to avoid eager evaluation to prevent stack overflow.
* - **Unifying Return Types**: Can help TypeScript unify return types in situations where multiple branches of logic return different effects, simplifying type inference.
*
* @example
* ```ts
* // Title: Lazy Evaluation with Side Effects
* import { Effect } from "effect"
*
* let i = 0
*
* const bad = Effect.succeed(i++)
*
* const good = Effect.suspend(() => Effect.succeed(i++))
*
* console.log(Effect.runSync(bad)) // Output: 0
* console.log(Effect.runSync(bad)) // Output: 0
*
* console.log(Effect.runSync(good)) // Output: 1
* console.log(Effect.runSync(good)) // Output: 2
* ```
*
* @example
* // Title: Recursive Fibonacci
* import { Effect } from "effect"
*
* const blowsUp = (n: number): Effect.Effect<number> =>
*   n < 2
*     ? Effect.succeed(1)
*     : Effect.zipWith(blowsUp(n - 1), blowsUp(n - 2), (a, b) => a + b)
*
* // console.log(Effect.runSync(blowsUp(32)))
* // crash: JavaScript heap out of memory
*
* const allGood = (n: number): Effect.Effect<number> =>
*   n < 2
*     ? Effect.succeed(1)
*     : Effect.zipWith(
*         Effect.suspend(() => allGood(n - 1)),
*         Effect.suspend(() => allGood(n - 2)),
*         (a, b) => a + b
*       )
*
* console.log(Effect.runSync(allGood(32)))
* // Output: 3524578
*
* @example
* // Title: Using Effect.suspend to Help TypeScript Infer Types
* import { Effect } from "effect"
*
* //   Without suspend, TypeScript may struggle with type inference.
* //   Inferred type:
* //     (a: number, b: number) =>
* //       Effect<never, Error, never> | Effect<number, never, never>
* const withoutSuspend = (a: number, b: number) =>
*   b === 0
*     ? Effect.fail(new Error("Cannot divide by zero"))
*     : Effect.succeed(a / b)
*
* //   Using suspend to unify return types.
* //   Inferred type:
* //     (a: number, b: number) => Effect<number, Error, never>
* const withSuspend = (a: number, b: number) =>
*   Effect.suspend(() =>
*     b === 0
*       ? Effect.fail(new Error("Cannot divide by zero"))
*       : Effect.succeed(a / b)
*   )
*
* @since 2.0.0
* @category Creating Effects
*/
var suspend = suspend$1;
/**
* Creates an `Effect` that represents a synchronous side-effectful computation.
*
* **When to Use**
*
* Use `sync` when you are sure the operation will not fail.
*
* **Details**
*
* The provided function (`thunk`) must not throw errors; if it does, the error
* will be treated as a "defect".
*
* This defect is not a standard error but indicates a flaw in the logic that
* was expected to be error-free. You can think of it similar to an unexpected
* crash in the program, which can be further managed or logged using tools like
* {@link catchAllDefect}.
*
* @see {@link try_ | try} for a version that can handle failures.
*
* @example
* ```ts
* // Title: Logging a Message
* import { Effect } from "effect"
*
* const log = (message: string) =>
*   Effect.sync(() => {
*     console.log(message) // side effect
*   })
*
* //      ┌─── Effect<void, never, never>
* //      ▼
* const program = log("Hello, World!")
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var sync = sync$3;
var void_ = void_$2;
var undefined_ = undefined_$1;
/**
* Creates an `Effect` from a callback-based asynchronous function.
*
* **Details**
*
* The `resume` function:
* - Must be called exactly once. Any additional calls will be ignored.
* - Can return an optional `Effect` that will be run if the `Fiber` executing
*   this `Effect` is interrupted. This can be useful in scenarios where you
*   need to handle resource cleanup if the operation is interrupted.
* - Can receive an `AbortSignal` to handle interruption if needed.
*
* The `FiberId` of the fiber that may complete the async callback may also be
* specified using the `blockingOn` argument. This is called the "blocking
* fiber" because it suspends the fiber executing the `async` effect (i.e.
* semantically blocks the fiber from making progress). Specifying this fiber id
* in cases where it is known will improve diagnostics, but not affect the
* behavior of the returned effect.
*
* **When to Use**
*
* Use `Effect.async` when dealing with APIs that use callback-style instead of
* `async/await` or `Promise`.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const delay = (ms: number) =>
*   Effect.callback<void>((resume) => {
*     const timeoutId = setTimeout(() => {
*       resume(Effect.void)
*     }, ms)
*     // Cleanup function for interruption
*     return Effect.sync(() => clearTimeout(timeoutId))
*   })
*
* const program = delay(1000)
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var callback = callback$1;
/**
* Returns an effect that will never produce anything. The moral equivalent of
* `while(true) {}`, only without the wasted CPU cycles.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // This effect will never complete
* const program = Effect.never
*
* // This will run forever (or until interrupted)
* // Effect.runPromise(program) // Never resolves
*
* // Use with timeout for practical applications
* const timedProgram = Effect.timeout(program, "1 second")
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var never = never$1;
/**
* An `Effect` containing an empty record `{}`, used as the starting point for
* do notation chains.
*
* @example
* ```ts
* import { Effect } from "effect"
* import { pipe } from "effect/Function"
*
* const program = pipe(
*   Effect.Do,
*   Effect.bind("x", () => Effect.succeed(2)),
*   Effect.bind("y", ({ x }) => Effect.succeed(x + 1)),
*   Effect.let("sum", ({ x, y }) => x + y)
* )
* ```
*
* @since 4.0.0
* @category Do notation
*/
var Do = Do$1;
/**
* Gives a name to the success value of an `Effect`, creating a single-key
* record used in do notation pipelines.
*
* @since 4.0.0
* @category Do notation
*/
var bindTo = bindTo$1;
var let_ = let_$1;
/**
* Adds an `Effect` value to the do notation record under a given name.
*
* @since 4.0.0
* @category Do notation
*/
var bind = bind$1;
/**
* Provides a way to write effectful code using generator functions, simplifying
* control flow and error handling.
*
* **When to Use**
*
* `gen` allows you to write code that looks and behaves like synchronous
* code, but it can handle asynchronous tasks, errors, and complex control flow
* (like loops and conditions). It helps make asynchronous code more readable
* and easier to manage.
*
* The generator functions work similarly to `async/await` but with more
* explicit control over the execution of effects. You can `yield*` values from
* effects and return the final result at the end.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const addServiceCharge = (amount: number) => amount + 1
*
* const applyDiscount = (
*   total: number,
*   discountRate: number
* ): Effect.Effect<number, Error> =>
*   discountRate === 0
*     ? Effect.fail(new Error("Discount rate cannot be zero"))
*     : Effect.succeed(total - (total * discountRate) / 100)
*
* const fetchTransactionAmount = Effect.promise(() => Promise.resolve(100))
*
* const fetchDiscountRate = Effect.promise(() => Promise.resolve(5))
*
* export const program = Effect.gen(function*() {
*   const transactionAmount = yield* fetchTransactionAmount
*   const discountRate = yield* fetchDiscountRate
*   const discountedAmount = yield* applyDiscount(
*     transactionAmount,
*     discountRate
*   )
*   const finalAmount = addServiceCharge(discountedAmount)
*   return `Final amount to charge: ${finalAmount}`
* })
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var gen = gen$1;
/**
* Creates an `Effect` that represents a recoverable error.
*
* **When to Use**
*
* Use this function to explicitly signal an error in an `Effect`. The error
* will keep propagating unless it is handled. You can handle the error with
* functions like {@link catchAll} or {@link catchTag}.
*
* @see {@link succeed} to create an effect that represents a successful value.
*
* @example
* ```ts
* // Title: Creating a Failed Effect
* import { Effect } from "effect"
*
* //      ┌─── Effect<never, Error, never>
* //      ▼
* const failure = Effect.fail(
*   new Error("Operation failed due to network error")
* )
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var fail = fail$5;
/**
* Creates an `Effect` that represents a recoverable error using a lazy evaluation.
*
* This function is useful when you need to create an error effect but want to
* defer the computation of the error value until the effect is actually run.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.failSync(() => new Error("Something went wrong"))
*
* Effect.runPromiseExit(program).then(console.log)
* // Output: { _id: 'Exit', _tag: 'Failure', cause: ... }
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var failSync = failSync$2;
/**
* Creates an `Effect` that represents a failure with a specific `Cause`.
*
* This function allows you to create effects that fail with complex error
* structures, including multiple errors, defects, interruptions, and more.
*
* @example
* ```ts
* import { Cause, Effect } from "effect"
*
* const program = Effect.failCause(
*   Cause.fail("Network error")
* )
*
* Effect.runPromiseExit(program).then(console.log)
* // Output: { _id: 'Exit', _tag: 'Failure', cause: ... }
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var failCause = failCause$4;
/**
* Creates an `Effect` that represents a failure with a `Cause` computed lazily.
*
* This function is useful when you need to create a failure effect with a
* complex cause but want to defer the computation until the effect is run.
*
* @example
* ```ts
* import { Cause, Effect } from "effect"
*
* const program = Effect.failCauseSync(() =>
*   Cause.fail("Error computed at runtime")
* )
*
* Effect.runPromiseExit(program).then(console.log)
* // Output: { _id: 'Exit', _tag: 'Failure', cause: ... }
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var failCauseSync = failCauseSync$2;
/**
* Creates an effect that terminates a fiber with a specified error.
*
* **When to Use**
*
* Use `die` when encountering unexpected conditions in your code that should
* not be handled as regular errors but instead represent unrecoverable defects.
*
* **Details**
*
* The `die` function is used to signal a defect, which represents a critical
* and unexpected error in the code. When invoked, it produces an effect that
* does not handle the error and instead terminates the fiber.
*
* The error channel of the resulting effect is of type `never`, indicating that
* it cannot recover from this failure.
*
* @see {@link dieSync} for a variant that throws a specified error, evaluated lazily.
* @see {@link dieMessage} for a variant that throws a `RuntimeException` with a message.
*
* @example
* ```ts
* // Title: Terminating on Division by Zero with a Specified Error
* import { Effect } from "effect"
*
* const divide = (a: number, b: number) =>
*   b === 0
*     ? Effect.die(new Error("Cannot divide by zero"))
*     : Effect.succeed(a / b)
*
* //      ┌─── Effect<number, never, never>
* //      ▼
* const program = divide(1, 0)
*
* Effect.runPromise(program).catch(console.error)
* // Output:
* // (FiberFailure) Error: Cannot divide by zero
* //   ...stack trace...
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var die = die$4;
var try_ = try_$1;
/**
* Yields control back to the Effect runtime, allowing other fibers to execute.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   console.log("Before yield")
*   yield* Effect.yieldNow
*   console.log("After yield")
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var yieldNow = yieldNow$1;
/**
* Yields control back to the Effect runtime with a specified priority, allowing other fibers to execute.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   console.log("High priority task")
*   yield* Effect.yieldNowWith(10) // Higher priority
*   console.log("Continued after yield")
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var yieldNowWith = yieldNowWith$1;
/**
* Provides access to the current fiber within an effect computation.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.withFiber((fiber) =>
*   Effect.succeed(`Fiber ID: ${fiber.id}`)
* )
*
* Effect.runPromise(program).then(console.log)
* // Output: Fiber ID: 1
* ```
*
* @since 2.0.0
* @category Creating Effects
*/
var withFiber = withFiber$1;
/**
* Converts a `Result` to an `Effect`.
*
* @example
* ```ts
* import { Effect, Result } from "effect"
*
* const success = Result.succeed(42)
* const failure = Result.fail("Something went wrong")
*
* const effect1 = Effect.fromResult(success)
* const effect2 = Effect.fromResult(failure)
*
* Effect.runPromise(effect1).then(console.log) // 42
* Effect.runPromiseExit(effect2).then(console.log)
* // { _id: 'Exit', _tag: 'Failure', cause: { _id: 'Cause', _tag: 'Fail', failure: 'Something went wrong' } }
* ```
*
* @since 4.0.0
* @category Conversions
*/
var fromResult = fromResult$1;
/**
* Converts an `Option` to an `Effect`.
*
* @example
* ```ts
* import { Effect, Option } from "effect"
*
* const some = Option.some(42)
* const none = Option.none()
*
* const effect1 = Effect.fromOption(some)
* const effect2 = Effect.fromOption(none)
*
* Effect.runPromise(effect1).then(console.log) // 42
* Effect.runPromiseExit(effect2).then(console.log)
* // { _id: 'Exit', _tag: 'Failure', cause: { _id: 'Cause', _tag: 'Fail', failure: { _id: 'NoSuchElementError' } } }
* ```
*
* @since 4.0.0
* @category Conversions
*/
var fromOption = fromOption$1;
/**
* Converts a nullable value to an `Effect`, failing with a `NoSuchElementError`
* when the value is `null` or `undefined`.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const input: string | null = null
*
* const program = Effect.gen(function*() {
*   const value = yield* Effect.fromNullishOr(input)
*   yield* Console.log(value)
* }).pipe(
*   Effect.catch(() => Console.log("missing"))
* )
*
* Effect.runPromise(program)
* // Output: missing
* ```
*
* @since 4.0.0
* @category Conversions
*/
var fromNullishOr = fromNullishOr$1;
/**
* Converts a yieldable value to an Effect.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as Option from "effect/Option"
*
* // Option is yieldable in Effect
* const program = Effect.gen(function*() {
*   const value = yield* Effect.fromYieldable(Option.some(42))
*   return value * 2
* })
*
* Effect.runPromise(program).then(console.log)
* // Output: 84
* ```
*
* @since 4.0.0
* @category Conversions
*/
var fromYieldable = fromYieldable$1;
/**
* Chains effects to produce new `Effect` instances, useful for combining
* operations that depend on previous results.
*
* **Syntax**
*
* ```ts skip-type-checking
* const flatMappedEffect = pipe(myEffect, Effect.flatMap(transformation))
* // or
* const flatMappedEffect = Effect.flatMap(myEffect, transformation)
* // or
* const flatMappedEffect = myEffect.pipe(Effect.flatMap(transformation))
* ```
*
* **Details**
*
* `flatMap` lets you sequence effects so that the result of one effect can be
* used in the next step. It is similar to `flatMap` used with arrays but works
* specifically with `Effect` instances, allowing you to avoid deeply nested
* effect structures.
*
* Since effects are immutable, `flatMap` always returns a new effect instead of
* changing the original one.
*
* **When to Use**
*
* Use `flatMap` when you need to chain multiple effects, ensuring that each
* step produces a new `Effect` while flattening any nested effects that may
* occur.
*
* @example
* ```ts
* import { Effect, pipe } from "effect"
*
* // Function to apply a discount safely to a transaction amount
* const applyDiscount = (
*   total: number,
*   discountRate: number
* ): Effect.Effect<number, Error> =>
*   discountRate === 0
*     ? Effect.fail(new Error("Discount rate cannot be zero"))
*     : Effect.succeed(total - (total * discountRate) / 100)
*
* // Simulated asynchronous task to fetch a transaction amount from database
* const fetchTransactionAmount = Effect.promise(() => Promise.resolve(100))
*
* // Chaining the fetch and discount application using `flatMap`
* const finalAmount = pipe(
*   fetchTransactionAmount,
*   Effect.flatMap((amount) => applyDiscount(amount, 5))
* )
*
* Effect.runPromise(finalAmount).then(console.log)
* // Output: 95
* ```
*
* @see {@link tap} for a version that ignores the result of the effect.
*
* @since 2.0.0
* @category Sequencing
*/
var flatMap = flatMap$2;
/**
* Flattens an `Effect` that produces another `Effect` into a single effect.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const nested = Effect.succeed(Effect.succeed("hello"))
*
* const program = Effect.gen(function*() {
*   const value = yield* Effect.flatten(nested)
*   yield* Console.log(value)
*   // Output: hello
* })
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var flatten = flatten$1;
/**
* Chains two actions, where the second action can depend on the result of the
* first.
*
* **Syntax**
*
* ```ts skip-type-checking
* const transformedEffect = pipe(myEffect, Effect.andThen(anotherEffect))
* // or
* const transformedEffect = Effect.andThen(myEffect, anotherEffect)
* // or
* const transformedEffect = myEffect.pipe(Effect.andThen(anotherEffect))
* ```
*
* **When to Use**
*
* Use `andThen` when you need to run multiple actions in sequence, with the
* second action depending on the result of the first. This is useful for
* combining effects or handling computations that must happen in order.
*
* **Details**
*
* The second action can be:
*
* - A constant value (similar to {@link as})
* - A function returning a value (similar to {@link map})
* - A `Promise`
* - A function returning a `Promise`
* - An `Effect`
* - A function returning an `Effect` (similar to {@link flatMap})
*
* **Note:** `andThen` works well with both `Option` and `Result` types,
* treating them as effects.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.zipRight`
*
* @example Applying a Discount Based on Fetched Amount
* ```ts
* import { Effect, pipe } from "effect"
*
* // Function to apply a discount safely to a transaction amount
* const applyDiscount = (
*   total: number,
*   discountRate: number
* ): Effect.Effect<number, Error> =>
*   discountRate === 0
*     ? Effect.fail(new Error("Discount rate cannot be zero"))
*     : Effect.succeed(total - (total * discountRate) / 100)
*
* // Simulated asynchronous task to fetch a transaction amount from database
* const fetchTransactionAmount = Effect.promise(() => Promise.resolve(100))
*
* // Using Effect.map and Effect.flatMap
* const result1 = pipe(
*   fetchTransactionAmount,
*   Effect.map((amount) => amount * 2),
*   Effect.flatMap((amount) => applyDiscount(amount, 5))
* )
*
* Effect.runPromise(result1).then(console.log)
* // Output: 190
*
* // Using Effect.andThen
* const result2 = pipe(
*   fetchTransactionAmount,
*   Effect.andThen((amount) => Effect.succeed(amount * 2)),
*   Effect.andThen((amount) => applyDiscount(amount, 5))
* )
*
* Effect.runPromise(result2).then(console.log)
* // Output: 190
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var andThen = andThen$2;
/**
* Runs a side effect with the result of an effect without changing the original
* value.
*
* **When to Use**
*
* Use `tap` when you want to perform a side effect, like logging or tracking,
* without modifying the main value. This is useful when you need to observe or
* record an action but want the original value to be passed to the next step.
*
* **Details**
*
* `tap` works similarly to `flatMap`, but it ignores the result of the function
* passed to it. The value from the previous effect remains available for the
* next part of the chain. Note that if the side effect fails, the entire chain
* will fail too.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.zipLeft`
*
* @example
* ```ts
* // Title: Logging a step in a pipeline
* import { Effect, pipe } from "effect"
* import { Console } from "effect"
*
* // Function to apply a discount safely to a transaction amount
* const applyDiscount = (
*   total: number,
*   discountRate: number
* ): Effect.Effect<number, Error> =>
*   discountRate === 0
*     ? Effect.fail(new Error("Discount rate cannot be zero"))
*     : Effect.succeed(total - (total * discountRate) / 100)
*
* // Simulated asynchronous task to fetch a transaction amount from database
* const fetchTransactionAmount = Effect.promise(() => Promise.resolve(100))
*
* const finalAmount = pipe(
*   fetchTransactionAmount,
*   // Log the fetched transaction amount
*   Effect.tap((amount) => Console.log(`Apply a discount to: ${amount}`)),
*   // `amount` is still available!
*   Effect.flatMap((amount) => applyDiscount(amount, 5))
* )
*
* Effect.runPromise(finalAmount).then(console.log)
* // Output:
* // Apply a discount to: 100
* // 95
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tap = tap$1;
/**
* Encapsulates both success and failure of an `Effect` into a `Result` type.
*
* **Details**
*
* This function converts an effect that may fail into an effect that always
* succeeds, wrapping the outcome in a `Result` type. The result will be
* `Result.Err` if the effect fails, containing the recoverable error, or
* `Result.Ok` if it succeeds, containing the result.
*
* Using this function, you can handle recoverable errors explicitly without
* causing the effect to fail. This is particularly useful in scenarios where
* you want to chain effects and manage both success and failure in the same
* logical flow.
*
* It's important to note that unrecoverable errors, often referred to as
* "defects," are still thrown and not captured within the `Result` type. Only
* failures that are explicitly represented as recoverable errors in the effect
* are encapsulated.
*
* The resulting effect cannot fail directly because all recoverable failures
* are represented inside the `Result` type.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.either`
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const success = Effect.succeed(42)
* const failure = Effect.fail("Something went wrong")
*
* const program1 = Effect.result(success)
* const program2 = Effect.result(failure)
*
* Effect.runPromise(program1).then(console.log)
* // { _id: 'Result', _tag: 'Success', value: 42 }
*
* Effect.runPromise(program2).then(console.log)
* // { _id: 'Result', _tag: 'Failure', error: 'Something went wrong' }
* ```
*
* @see {@link option} for a version that uses `Option` instead.
* @see {@link exit} for a version that encapsulates both recoverable errors and defects in an `Exit`.
*
* @since 4.0.0
* @category Outcome Encapsulation
*/
var result = result$1;
/**
* Convert success to `Option.some` and failure to `Option.none`.
*
* **Details**
*
* Success values become `Option.some`, recoverable failures become
* `Option.none`, and defects still fail the effect.
*
* @example
* ```ts
* import { Console, Effect, Option } from "effect"
*
* const program = Effect.gen(function*() {
*   const someValue = yield* Effect.option(Effect.succeed(1))
*   const noneValue = yield* Effect.option(Effect.fail("missing"))
*
*   yield* Console.log(Option.isSome(someValue))
*   yield* Console.log(Option.isNone(noneValue))
* })
*
* Effect.runPromise(program)
* // true
* // true
* ```
*
* @see {@link result} for a version that uses `Result` instead.
* @see {@link exit} for a version that encapsulates both recoverable errors and defects in an `Exit`.
*
* @since 2.0.0
* @category Output Encapsulation
*/
var option = option$1;
/**
* Transforms an effect to encapsulate both failure and success using the `Exit`
* data type.
*
* **Details**
*
* `exit` wraps an effect's success or failure inside an `Exit` type, allowing
* you to handle both cases explicitly.
*
* The resulting effect cannot fail because the failure is encapsulated within
* the `Exit.Failure` type. The error type is set to `never`, indicating that
* the effect is structured to never fail directly.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const success = Effect.succeed(42)
* const failure = Effect.fail("Something went wrong")
*
* const program1 = Effect.exit(success)
* const program2 = Effect.exit(failure)
*
* Effect.runPromise(program1).then(console.log)
* // { _id: 'Exit', _tag: 'Success', value: 42 }
*
* Effect.runPromise(program2).then(console.log)
* // { _id: 'Exit', _tag: 'Failure', cause: { _id: 'Cause', _tag: 'Fail', failure: 'Something went wrong' } }
* ```
*
* @see {@link option} for a version that uses `Option` instead.
* @see {@link result} for a version that uses `Result` instead.
*
* @since 2.0.0
* @category Outcome Encapsulation
*/
var exit = exit$1;
/**
* Transforms the value inside an effect by applying a function to it.
*
* **Syntax**
*
* ```ts skip-type-checking
* const mappedEffect = pipe(myEffect, Effect.map(transformation))
* // or
* const mappedEffect = Effect.map(myEffect, transformation)
* // or
* const mappedEffect = myEffect.pipe(Effect.map(transformation))
* ```
*
* **Details**
*
* `map` takes a function and applies it to the value contained within an
* effect, creating a new effect with the transformed value.
*
* It's important to note that effects are immutable, meaning that the original
* effect is not modified. Instead, a new effect is returned with the updated
* value.
*
* @example Adding a Service Charge
* ```ts
* import { Effect, pipe } from "effect"
*
* const addServiceCharge = (amount: number) => amount + 1
*
* const fetchTransactionAmount = Effect.promise(() => Promise.resolve(100))
*
* const finalAmount = pipe(
*   fetchTransactionAmount,
*   Effect.map(addServiceCharge)
* )
*
* Effect.runPromise(finalAmount).then(console.log)
* // Output: 101
* ```
*
* @see {@link mapError} for a version that operates on the error channel.
* @see {@link mapBoth} for a version that operates on both channels.
* @see {@link flatMap} or {@link andThen} for a version that can return a new effect.
*
* @since 2.0.0
* @category Mapping
*/
var map = map$4;
/**
* Replaces the value inside an effect with a constant value.
*
* `as` allows you to ignore the original value inside an effect and
* replace it with a new constant value.
*
* @example
* ```ts
* // Title: Replacing a Value
* import { Effect, pipe } from "effect"
*
* // Replaces the value 5 with the constant "new value"
* const program = pipe(Effect.succeed(5), Effect.as("new value"))
*
* Effect.runPromise(program).then(console.log)
* // Output: "new value"
* ```
*
* @since 2.0.0
* @category Mapping
*/
var as = as$1;
/**
* This function maps the success value of an `Effect` value to a `Some` value
* in an `Option` value. If the original `Effect` value fails, the returned
* `Effect` value will also fail.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.asSome(Effect.succeed(42))
*
* Effect.runPromise(program).then(console.log)
* // { _id: 'Option', _tag: 'Some', value: 42 }
* ```
*
* @category Mapping
* @since 2.0.0
*/
var asSome = asSome$1;
/**
* This function maps the success value of an `Effect` value to `void`. If the
* original `Effect` value succeeds, the returned `Effect` value will also
* succeed. If the original `Effect` value fails, the returned `Effect` value
* will fail with the same error.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.asVoid(Effect.succeed(42))
*
* Effect.runPromise(program).then(console.log)
* // undefined (void)
* ```
*
* @since 2.0.0
* @category Mapping
*/
var asVoid = asVoid$2;
/**
* The `flip` function swaps the success and error channels of an effect,
* so that the success becomes the error, and the error becomes the success.
*
* This function is useful when you need to reverse the flow of an effect,
* treating the previously successful values as errors and vice versa. This can
* be helpful in scenarios where you want to handle a success as a failure or
* treat an error as a valid result.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* //      ┌─── Effect<number, string, never>
* //      ▼
* const program = Effect.fail("Oh uh!").pipe(Effect.as(2))
*
* //      ┌─── Effect<string, number, never>
* //      ▼
* const flipped = Effect.flip(program)
* ```
*
* @since 2.0.0
* @category Mapping
*/
var flip = flip$1;
/**
* Combines two effects into a single effect, producing a tuple with the results of both effects.
*
* The `zip` function executes the first effect (left) and then the second effect (right).
* Once both effects succeed, their results are combined into a tuple.
*
* **Concurrency**
*
* By default, `zip` processes the effects sequentially. To execute the effects concurrently,
* use the `{ concurrent: true }` option.
*
* @see {@link zipWith} for a version that combines the results with a custom function.
* @see {@link validate} for a version that accumulates errors.
*
* @example
* ```ts
* // Title: Combining Two Effects Sequentially
* import { Effect } from "effect"
*
* const task1 = Effect.succeed(1).pipe(
*   Effect.delay("200 millis"),
*   Effect.tap(Effect.log("task1 done"))
* )
* const task2 = Effect.succeed("hello").pipe(
*   Effect.delay("100 millis"),
*   Effect.tap(Effect.log("task2 done"))
* )
*
* // Combine the two effects together
* //
* //      ┌─── Effect<[number, string], never, never>
* //      ▼
* const program = Effect.zip(task1, task2)
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // timestamp=... level=INFO fiber=#0 message="task1 done"
* // timestamp=... level=INFO fiber=#0 message="task2 done"
* // [ 1, 'hello' ]
* ```
*
* @example
* // Title: Combining Two Effects Concurrently
* import { Effect } from "effect"
*
* const task1 = Effect.succeed(1).pipe(
*   Effect.delay("200 millis"),
*   Effect.tap(Effect.log("task1 done"))
* )
* const task2 = Effect.succeed("hello").pipe(
*   Effect.delay("100 millis"),
*   Effect.tap(Effect.log("task2 done"))
* )
*
* // Run both effects concurrently using the concurrent option
* const program = Effect.zip(task1, task2, { concurrent: true })
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // timestamp=... level=INFO fiber=#0 message="task2 done"
* // timestamp=... level=INFO fiber=#0 message="task1 done"
* // [ 1, 'hello' ]
*
* @since 2.0.0
* @category Zipping
*/
var zip = zip$1;
/**
* Combines two effects sequentially and applies a function to their results to
* produce a single value.
*
* **When to Use**
*
* The `zipWith` function is similar to {@link zip}, but instead of returning a
* tuple of results, it applies a provided function to the results of the two
* effects, combining them into a single value.
*
* **Concurrency**
*
* By default, the effects are run sequentially. To execute them concurrently,
* use the `{ concurrent: true }` option.
*
* @example
* ```ts
* // Title: Combining Effects with a Custom Function
* import { Effect } from "effect"
*
* const task1 = Effect.succeed(1).pipe(
*   Effect.delay("200 millis"),
*   Effect.tap(Effect.log("task1 done"))
* )
* const task2 = Effect.succeed("hello").pipe(
*   Effect.delay("100 millis"),
*   Effect.tap(Effect.log("task2 done"))
* )
*
* const task3 = Effect.zipWith(
*   task1,
*   task2,
*   // Combines results into a single value
*   (number, string) => number + string.length
* )
*
* Effect.runPromise(task3).then(console.log)
* // Output:
* // timestamp=... level=INFO fiber=#3 message="task1 done"
* // timestamp=... level=INFO fiber=#2 message="task2 done"
* // 6
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWith = zipWith$1;
var catch_ = catch_$2;
/**
* Catches and handles specific errors by their `_tag` field, which is used as a
* discriminator.
*
* **When to Use**
*
* `catchTag` is useful when your errors are tagged with a readonly `_tag` field
* that identifies the error type. You can use this function to handle specific
* error types by matching the `_tag` value. This allows for precise error
* handling, ensuring that only specific errors are caught and handled.
*
* The error type must have a readonly `_tag` field to use `catchTag`. This
* field is used to identify and match errors.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* class NetworkError {
*   readonly _tag = "NetworkError"
*   constructor(readonly message: string) {}
* }
*
* class ValidationError {
*   readonly _tag = "ValidationError"
*   constructor(readonly message: string) {}
* }
*
* declare const task: Effect.Effect<string, NetworkError | ValidationError>
*
* const program = Effect.catchTag(
*   task,
*   "NetworkError",
*   (error) => Effect.succeed(`Recovered from network error: ${error.message}`)
* )
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var catchTag = catchTag$2;
/**
* Handles multiple errors in a single block of code using their `_tag` field.
*
* **When to Use**
*
* `catchTags` is a convenient way to handle multiple error types at
* once. Instead of using {@link catchTag} multiple times, you can pass an
* object where each key is an error type's `_tag`, and the value is the handler
* for that specific error. This allows you to catch and recover from multiple
* error types in a single call.
*
* The error type must have a readonly `_tag` field to use `catchTag`. This
* field is used to identify and match errors.
*
* @example
* ```ts
* import { Data, Effect } from "effect"
*
* // Define tagged error types
* class ValidationError extends Data.TaggedError("ValidationError")<{
*   message: string
* }> {}
*
* class NetworkError extends Data.TaggedError("NetworkError")<{
*   statusCode: number
* }> {}
*
* // An effect that might fail with multiple error types
* declare const program: Effect.Effect<string, ValidationError | NetworkError>
*
* // Handle multiple error types at once
* const handled = Effect.catchTags(program, {
*   ValidationError: (error) =>
*     Effect.succeed(`Validation failed: ${error.message}`),
*   NetworkError: (error) => Effect.succeed(`Network error: ${error.statusCode}`)
* })
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var catchTags = catchTags$1;
/**
* Catches a specific reason within a tagged error.
*
* Use this to handle nested error causes without removing the parent error
* from the error channel. The handler receives the unwrapped reason.
*
* @example
* ```ts
* import { Data, Effect } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* declare const program: Effect.Effect<string, AiError>
*
* // Handle rate limits specifically
* const handled = program.pipe(
*   Effect.catchReason("AiError", "RateLimitError", (reason) =>
*     Effect.succeed(`Retry after ${reason.retryAfter}s`)
*   )
* )
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchReason = catchReason$1;
/**
* Catches multiple reasons within a tagged error using an object of handlers.
*
* @example
* ```ts
* import { Data, Effect } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* declare const program: Effect.Effect<string, AiError>
*
* const handled = program.pipe(
*   Effect.catchReasons("AiError", {
*     RateLimitError: (reason) =>
*       Effect.succeed(`Retry after ${reason.retryAfter}s`),
*     QuotaExceededError: (reason) =>
*       Effect.succeed(`Quota exceeded: ${reason.limit}`)
*   })
* )
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchReasons = catchReasons$1;
/**
* Promotes nested reason errors into the Effect error channel, replacing
* the parent error.
*
* @example
* ```ts
* import { Data, Effect } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* declare const program: Effect.Effect<string, AiError>
*
* // Before: Effect<string, AiError>
* // After:  Effect<string, RateLimitError | QuotaExceededError>
* const unwrapped = program.pipe(Effect.unwrapReason("AiError"))
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var unwrapReason = unwrapReason$1;
/**
* Handles both recoverable and unrecoverable errors by providing a recovery
* effect.
*
* **When to Use**
*
* The `catchCause` function allows you to handle all errors, including
* unrecoverable defects, by providing a recovery effect. The recovery logic is
* based on the `Cause` of the error, which provides detailed information about
* the failure.
*
* **When to Recover from Defects**
*
* Defects are unexpected errors that typically shouldn't be recovered from, as
* they often indicate serious issues. However, in some cases, such as
* dynamically loaded plugins, controlled recovery might be needed.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.catchAllCause`
*
* @example
* ```ts
* import { Cause, Console, Effect } from "effect"
*
* // An effect that might fail in different ways
* const program = Effect.die("Something went wrong")
*
* // Recover from any cause (including defects)
* const recovered = Effect.catchCause(program, (cause) => {
*   if (Cause.hasDies(cause)) {
*     return Console.log("Caught defect").pipe(
*       Effect.as("Recovered from defect")
*     )
*   }
*   return Effect.succeed("Unknown error")
* })
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchCause = catchCause$2;
/**
* Recovers from all defects using a provided recovery function.
*
* **When to Use**
*
* There is no sensible way to recover from defects. This method should be used
* only at the boundary between Effect and an external system, to transmit
* information on a defect for diagnostic or explanatory purposes.
*
* **Details**
*
* `catchAllDefect` allows you to handle defects, which are unexpected errors
* that usually cause the program to terminate. This function lets you recover
* from these defects by providing a function that handles the error. However,
* it does not handle expected errors (like those from {@link fail}) or
* execution interruptions (like those from {@link interrupt}).
*
* **When to Recover from Defects**
*
* Defects are unexpected errors that typically shouldn't be recovered from, as
* they often indicate serious issues. However, in some cases, such as
* dynamically loaded plugins, controlled recovery might be needed.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.catchAllDefect`
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* // An effect that might throw an unexpected error (defect)
* const program = Effect.sync(() => {
*   throw new Error("Unexpected error")
* })
*
* // Recover from defects only
* const recovered = Effect.catchDefect(program, (defect) => {
*   return Console.log(`Caught defect: ${defect}`).pipe(
*     Effect.as("Recovered from defect")
*   )
* })
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchDefect = catchDefect$1;
/**
* Recovers from specific errors using a `Predicate` or `Refinement`.
*
* **When to Use**
*
* `catchIf` lets you recover from errors that match a condition. Use a
* `Refinement` for type narrowing or a `Predicate` for simple boolean
* matching. Non-matching errors re-fail with the original cause. Defects and
* interrupts are not caught.
*
* **Previously Known As**
*
* This API replaces the following:
*
* - `Effect.catchSome` (Effect 3.x)
* - `Effect.catchIf`
*
* @example
* ```ts
* import { Data, Effect, Filter } from "effect"
*
* class NotFound extends Data.TaggedError("NotFound")<{ id: string }> {}
*
* const program = Effect.fail(new NotFound({ id: "user-1" }))
*
* // With a refinement
* const recovered = program.pipe(
*   Effect.catchIf(
*     (error): error is NotFound => error._tag === "NotFound",
*     (error) => Effect.succeed(`missing:${error.id}`)
*   )
* )
*
* // With a Filter
* const recovered2 = program.pipe(
*   Effect.catchFilter(
*     Filter.tagged("NotFound"),
*     (error) => Effect.succeed(`missing:${error.id}`)
*   )
* )
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var catchIf = catchIf$1;
/**
* Recovers from specific errors using a `Filter`.
*
* @since 4.0.0
* @category Error Handling
*/
var catchFilter = catchFilter$1;
/**
* Catches `NoSuchElementError` failures and converts them to `Option.none`.
*
* Success values become `Option.some`, `NoSuchElementError` becomes
* `Option.none`, and all other errors are preserved.
*
* @example
* ```ts
* import { Effect, Option } from "effect"
*
* const some = Effect.fromNullishOr(1).pipe(Effect.catchNoSuchElement)
* const none = Effect.fromNullishOr(null).pipe(Effect.catchNoSuchElement)
*
* Effect.runPromise(some).then(console.log) // { _id: 'Option', _tag: 'Some', value: 1 }
* Effect.runPromise(none).then(console.log) // { _id: 'Option', _tag: 'None' }
* ```
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.optionFromOptional`
*
* @since 2.0.0
* @category Error Handling
*/
var catchNoSuchElement = catchNoSuchElement$1;
/**
* Recovers from specific failures based on a predicate.
*
* This function allows you to conditionally catch and recover from failures
* that match a specific predicate. This is useful when you want to handle
* only certain types of errors while letting others propagate.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.catchSomeCause`
*
* @example
* ```ts
* import { Cause, Console, Effect } from "effect"
*
* const httpRequest = Effect.fail("Network Error")
*
* // Only catch network-related failures
* const program = Effect.catchCauseIf(
*   httpRequest,
*   Cause.hasFails,
*   (cause) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Caught network error: ${Cause.squash(cause)}`)
*       return "Fallback response"
*     })
* )
*
* Effect.runPromise(program).then(console.log)
* // Output: "Caught network error: Network Error"
* // Then: "Fallback response"
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchCauseIf = catchCauseIf$1;
/**
* Recovers from specific failures based on a `Filter`.
*
* @since 4.0.0
* @category Error Handling
*/
var catchCauseFilter = catchCauseFilter$1;
/**
* The `mapError` function is used to transform or modify the error
* produced by an effect, without affecting its success value.
*
* This function is helpful when you want to enhance the error with additional
* information, change the error type, or apply custom error handling while
* keeping the original behavior of the effect's success values intact. It only
* operates on the error channel and leaves the success channel unchanged.
*
* @see {@link map} for a version that operates on the success channel.
* @see {@link mapBoth} for a version that operates on both channels.
* @see {@link orElseFail} if you want to replace the error with a new one.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* //      ┌─── Effect<number, string, never>
* //      ▼
* const simulatedTask = Effect.fail("Oh no!").pipe(Effect.as(1))
*
* //      ┌─── Effect<number, Error, never>
* //      ▼
* const mapped = Effect.mapError(
*   simulatedTask,
*   (message) => new Error(message)
* )
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var mapError = mapError$2;
/**
* Applies transformations to both the success and error channels of an effect.
*
* **Details**
*
* This function takes two map functions as arguments: one for the error channel
* and one for the success channel. You can use it when you want to modify both
* the error and the success values without altering the overall success or
* failure status of the effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* //      ┌─── Effect<number, string, never>
* //      ▼
* const simulatedTask = Effect.fail("Oh no!").pipe(Effect.as(1))
*
* //      ┌─── Effect<boolean, Error, never>
* //      ▼
* const modified = Effect.mapBoth(simulatedTask, {
*   onFailure: (message) => new Error(message),
*   onSuccess: (n) => n > 0
* })
* ```
*
* @see {@link map} for a version that operates on the success channel.
* @see {@link mapError} for a version that operates on the error channel.
*
* @since 2.0.0
* @category Mapping
*/
var mapBoth = mapBoth$2;
/**
* Converts an effect's failure into a fiber termination, removing the error from the effect's type.
*
* **When to Use*
*
* Use `orDie` when failures should be treated as unrecoverable defects and no error handling is required.
*
* **Details**
*
* The `orDie` function is used when you encounter errors that you do not want to handle or recover from.
* It removes the error type from the effect and ensures that any failure will terminate the fiber.
* This is useful for propagating failures as defects, signaling that they should not be handled within the effect.
*
* @see {@link orDieWith} if you need to customize the error.
*
* @example
* ```ts
* // Title: Propagating an Error as a Defect
* import { Effect } from "effect"
*
* const divide = (a: number, b: number) =>
*   b === 0
*     ? Effect.fail(new Error("Cannot divide by zero"))
*     : Effect.succeed(a / b)
*
* //      ┌─── Effect<number, never, never>
* //      ▼
* const program = Effect.orDie(divide(1, 0))
*
* Effect.runPromise(program).catch(console.error)
* // Output:
* // (FiberFailure) Error: Cannot divide by zero
* //   ...stack trace...
* ```
*
* @since 2.0.0
* @category Converting Failures to Defects
*/
var orDie = orDie$2;
/**
* The `tapError` function executes an effectful operation to inspect the
* failure of an effect without modifying it.
*
* This function is useful when you want to perform some side effect (like
* logging or tracking) on the failure of an effect, but without changing the
* result of the effect itself. The error remains in the effect's error channel,
* while the operation you provide can inspect or act on it.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* // Simulate a task that fails with an error
* const task: Effect.Effect<number, string> = Effect.fail("NetworkError")
*
* // Use tapError to log the error message when the task fails
* const tapping = Effect.tapError(
*   task,
*   (error) => Console.log(`expected error: ${error}`)
* )
*
* Effect.runFork(tapping)
* // Output:
* // expected error: NetworkError
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tapError = tapError$1;
/**
* Runs an effectful handler when a failure's `_tag` matches.
*
* Use this with tagged-union errors to perform side effects for a tag (or tag
* list) while preserving the original failure.
*
* @example
* ```ts
* import { Console, Data, Effect } from "effect"
*
* class NetworkError extends Data.TaggedError("NetworkError")<{
*   statusCode: number
* }> {}
*
* class ValidationError extends Data.TaggedError("ValidationError")<{
*   field: string
* }> {}
*
* const task: Effect.Effect<number, NetworkError | ValidationError> =
*   Effect.fail(new NetworkError({ statusCode: 504 }))
*
* const program = Effect.tapErrorTag(task, "NetworkError", (error) =>
*   Console.log(`expected error: ${error.statusCode}`)
* )
*
* Effect.runPromiseExit(program)
* // Output:
* // expected error: 504
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tapErrorTag = tapErrorTag$1;
/**
* The `tapCause` function allows you to inspect the complete cause
* of an error, including failures and defects.
*
* This function is helpful when you need to log, monitor, or handle specific
* error causes in your effects. It gives you access to the full error cause,
* whether it's a failure, defect, or other exceptional conditions, without
* altering the error or the overall result of the effect.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.tapErrorCause`
*
* @example
* ```ts
* import { Cause, Console, Effect } from "effect"
*
* const task = Effect.fail("Something went wrong")
*
* const program = Effect.tapCause(
*   task,
*   (cause) => Console.log(`Logging cause: ${Cause.squash(cause)}`)
* )
*
* Effect.runPromiseExit(program).then(console.log)
* // Output: "Logging cause: Error: Something went wrong"
* // Then: { _id: 'Exit', _tag: 'Failure', cause: ... }
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tapCause = tapCause$1;
/**
* Conditionally executes a side effect based on the cause of a failed effect.
*
* This function allows you to tap into the cause of an effect's failure only when
* the cause matches a specific predicate. This is useful for conditional logging,
* monitoring, or other side effects based on the type of failure.
*
* @example
* ```ts
* import { Cause, Console, Effect } from "effect"
*
* const task = Effect.fail("Network timeout")
*
* // Only log causes that contain failures (not interrupts or defects)
* const program = Effect.tapCauseIf(
*   task,
*   Cause.hasFails,
*   (cause) => Console.log(`Logging failure cause: ${Cause.squash(cause)}`)
* )
*
* Effect.runPromiseExit(program).then(console.log)
* // Output: "Logging failure cause: Network timeout"
* // Then: { _id: 'Exit', _tag: 'Failure', cause: ... }
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var tapCauseIf = tapCauseIf$1;
/**
* Conditionally executes a side effect based on the cause of a failed effect.
*
* @since 4.0.0
* @category Sequencing
*/
var tapCauseFilter = tapCauseFilter$1;
/**
* Inspect severe errors or defects (non-recoverable failures) in an effect.
*
* **Details**
*
* This function is specifically designed to handle and inspect defects, which
* are critical failures in your program, such as unexpected runtime exceptions
* or system-level errors. Unlike normal recoverable errors, defects typically
* indicate serious issues that cannot be addressed through standard error
* handling.
*
* When a defect occurs in an effect, the function you provide to this function
* will be executed, allowing you to log, monitor, or handle the defect in some
* way. Importantly, this does not alter the main result of the effect. If no
* defect occurs, the effect behaves as if this function was not used.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* // Simulate a task that fails with a recoverable error
* const task1: Effect.Effect<number, string> = Effect.fail("NetworkError")
*
* // tapDefect won't log anything because NetworkError is not a defect
* const tapping1 = Effect.tapDefect(
*   task1,
*   (cause) => Console.log(`defect: ${cause}`)
* )
*
* Effect.runFork(tapping1)
* // No Output
*
* // Simulate a severe failure in the system
* const task2: Effect.Effect<number> = Effect.die(
*   "Something went wrong"
* )
*
* // Log the defect using tapDefect
* const tapping2 = Effect.tapDefect(
*   task2,
*   (cause) => Console.log(`defect: ${cause}`)
* )
*
* Effect.runFork(tapping2)
* // Output:
* // defect: RuntimeException: Something went wrong
* //   ... stack trace ...
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tapDefect = tapDefect$1;
/**
* Retries an effect until it succeeds, discarding failures.
*
* Yields between attempts so other fibers can run.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* let attempts = 0
*
* const flaky = Effect.gen(function*() {
*   attempts++
*   yield* Console.log(`Attempt ${attempts}`)
*   if (attempts < 3) {
*     yield* Effect.fail("Not ready")
*   }
*   return "Ready"
* })
*
* const program = Effect.eventually(flaky)
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Attempt 1
* // Attempt 2
* // Attempt 3
* // Ready
* ```
*
* @since 2.0.0
* @category Repetition / Recursion
*/
var eventually = eventually$1;
/**
* Retries a failing effect based on a defined retry policy.
*
* **Details**
*
* The `Effect.retry` function takes an effect and a {@link Schedule} policy,
* and will automatically retry the effect if it fails, following the rules of
* the policy.
*
* If the effect ultimately succeeds, the result will be returned.
*
* If the maximum retries are exhausted and the effect still fails, the failure
* is propagated.
*
* **When to Use**
*
* This can be useful when dealing with intermittent failures, such as network
* issues or temporary resource unavailability. By defining a retry policy, you
* can control the number of retries, the delay between them, and when to stop
* retrying.
*
* @example
* ```ts
* import { Effect, Schedule } from "effect"
*
* let attempt = 0
* const task = Effect.callback<string, Error>((resume) => {
*   attempt++
*   if (attempt <= 2) {
*     resume(Effect.fail(new Error(`Attempt ${attempt} failed`)))
*   } else {
*     resume(Effect.succeed("Success!"))
*   }
* })
*
* const policy = Schedule.addDelay(Schedule.recurs(5), () => Effect.succeed("100 millis"))
* const program = Effect.retry(task, policy)
*
* Effect.runPromise(program).then(console.log)
* // Output: "Success!" (after 2 retries)
* ```
*
* @see {@link retryOrElse} for a version that allows you to run a fallback.
* @see {@link repeat} if your retry condition is based on successful outcomes rather than errors.
*
* @since 2.0.0
* @category Error Handling
*/
var retry = retry$1;
/**
* Retries a failing effect and runs a fallback effect if retries are exhausted.
*
* **Details**
*
* The `Effect.retryOrElse` function attempts to retry a failing effect multiple
* times according to a defined {@link Schedule} policy.
*
* If the retries are exhausted and the effect still fails, it runs a fallback
* effect instead.
*
* **When to Use**
*
* This function is useful when you want to handle failures gracefully by
* specifying an alternative action after repeated failures.
*
* @see {@link retry} for a version that does not run a fallback effect.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* let attempt = 0
* const networkRequest = Effect.gen(function*() {
*   attempt++
*   yield* Console.log(`Network attempt ${attempt}`)
*   if (attempt < 3) {
*     return yield* Effect.fail(new Error("Network timeout"))
*   }
*   return "Network data"
* })
*
* // Retry up to 2 times, then fall back to cached data
* const program = Effect.retryOrElse(
*   networkRequest,
*   Schedule.recurs(2),
*   (error, retryCount) =>
*     Effect.gen(function*() {
*       yield* Console.log(`All ${retryCount} retries failed, using cache`)
*       return "Cached data"
*     })
* )
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Network attempt 1
* // Network attempt 2
* // Network attempt 3
* // Network data
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var retryOrElse = retryOrElse$1;
/**
* The `sandbox` function transforms an effect by exposing the full cause
* of any error, defect, or fiber interruption that might occur during its
* execution. It changes the error channel of the effect to include detailed
* information about the cause, which is wrapped in a `Cause<E>` type.
*
* This function is useful when you need access to the complete underlying cause
* of failures, defects, or interruptions, enabling more detailed error
* handling. Once you apply `sandbox`, you can use operators like
* {@link catchAll} and {@link catchTags} to handle specific error conditions.
* If necessary, you can revert the sandboxing operation with {@link unsandbox}
* to return to the original error handling behavior.
*
* @example
* ```ts
* import { Cause, Effect } from "effect"
*
* const task = Effect.fail("Something went wrong")
*
* // Sandbox exposes the full cause as the error type
* const program = Effect.gen(function*() {
*   const result = yield* Effect.flip(Effect.sandbox(task))
*   return `Caught cause: ${Cause.squash(result)}`
* })
*
* Effect.runPromise(program).then(console.log)
* // Output: "Caught cause: Something went wrong"
* ```
*
* @see {@link unsandbox} to restore the original error handling.
*
* @since 2.0.0
* @category Error Handling
*/
var sandbox = sandbox$1;
/**
* Discards both the success and failure values of an effect.
*
* **When to Use**
*
* `ignore` allows you to run an effect without caring about its result, whether
* it succeeds or fails. This is useful when you only care about the side
* effects of the effect and do not need to handle or process its outcome.
*
* Use the `log` option to emit the full {@link Cause} when the effect fails.
*
* @example
* ```ts
* // Title: Using Effect.ignore to Discard Values
* import { Effect } from "effect"
*
* //      ┌─── Effect<number, string, never>
* //      ▼
* const task = Effect.fail("Uh oh!").pipe(Effect.as(5))
*
* //      ┌─── Effect<void, never, never>
* //      ▼
* const program = task.pipe(Effect.ignore)
* ```
*
* @example
* ```ts
* // Title: Logging failures while ignoring results
* import { Effect } from "effect"
*
* const task = Effect.fail("Uh oh!")
*
* const program = task.pipe(Effect.ignore({ log: true }))
* const programWarn = task.pipe(Effect.ignore({ log: "Warn" }))
* ```
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.ignoreLogged`
*
* @since 2.0.0
* @category Error Handling
*/
var ignore = ignore$1;
/**
* Ignores the effect's failure cause, including defects and interruptions.
*
* Use the `log` option to emit the full {@link Cause} when the effect fails.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const task = Effect.fail("boom")
*
* const program = task.pipe(Effect.ignoreCause)
* const programLog = task.pipe(Effect.ignoreCause({ log: true }))
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var ignoreCause = ignoreCause$1;
/**
* Apply an `ExecutionPlan` to an effect, retrying with step-provided resources
* until it succeeds or the plan is exhausted.
*
* Each attempt updates `ExecutionPlan.CurrentMetadata` (attempt and step index),
* and retry timing is derived per step (the first attempt uses the remaining
* attempts schedule; later retries apply the step schedule at least once).
*
* @example
* ```ts
* import { Effect, ExecutionPlan, Layer, ServiceMap } from "effect"
*
* const Endpoint = ServiceMap.Service<{ url: string }>("Endpoint")
*
* const fetchUrl = Effect.gen(function*() {
*   const endpoint = yield* Effect.service(Endpoint)
*   return endpoint.url === "bad" ? yield* Effect.fail("Unavailable") : endpoint.url
* })
*
* const plan = ExecutionPlan.make(
*   { provide: Layer.succeed(Endpoint, { url: "bad" }), attempts: 2 },
*   { provide: Layer.succeed(Endpoint, { url: "good" }) }
* )
*
* const program = Effect.withExecutionPlan(fetchUrl, plan)
* ```
*
* @since 3.16.0
* @category Fallback
*/
var withExecutionPlan = withExecutionPlan$1;
/**
* Runs an effect and reports any errors to the configured `ErrorReporter`s.
*
* If the `defectsOnly` option is set to `true`, only defects (unrecoverable
* errors) will be reported, while regular failures will be ignored.
*
* @since 4.0.0
* @category Error Handling
*/
var withErrorReporting = withErrorReporting$1;
/**
* Replaces the original failure with a success value, ensuring the effect
* cannot fail.
*
* `orElseSucceed` allows you to replace the failure of an effect with a
* success value. If the effect fails, it will instead succeed with the provided
* value, ensuring the effect always completes successfully. This is useful when
* you want to guarantee a successful result regardless of whether the original
* effect failed.
*
* The function ensures that any failure is effectively "swallowed" and replaced
* by a successful value, which can be helpful for providing default values in
* case of failure.
*
* **Important**: This function only applies to failed effects. If the effect
* already succeeds, it will remain unchanged.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const validate = (age: number): Effect.Effect<number, string> => {
*   if (age < 0) {
*     return Effect.fail("NegativeAgeError")
*   } else if (age < 18) {
*     return Effect.fail("IllegalAgeError")
*   } else {
*     return Effect.succeed(age)
*   }
* }
*
* const program = Effect.orElseSucceed(validate(-1), () => 18)
*
* console.log(Effect.runSyncExit(program))
* // Output:
* // { _id: 'Exit', _tag: 'Success', value: 18 }
* ```
*
* @since 2.0.0
* @category Fallback
*/
var orElseSucceed = orElseSucceed$1;
/**
* Adds a time limit to an effect, triggering a timeout if the effect exceeds
* the duration.
*
* The `timeout` function allows you to specify a time limit for an
* effect's execution. If the effect does not complete within the given time, a
* `TimeoutException` is raised. This can be useful for controlling how long
* your program waits for a task to finish, ensuring that it doesn't hang
* indefinitely if the task takes too long.
*
* @see {@link timeoutFail} for a version that raises a custom error.
* @see {@link timeoutFailCause} for a version that raises a custom defect.
* @see {@link timeoutTo} for a version that allows specifying both success and timeout handlers.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const task = Effect.gen(function*() {
*   console.log("Start processing...")
*   yield* Effect.sleep("2 seconds") // Simulates a delay in processing
*   console.log("Processing complete.")
*   return "Result"
* })
*
* // Output will show a TimeoutException as the task takes longer
* // than the specified timeout duration
* const timedEffect = task.pipe(Effect.timeout("1 second"))
*
* Effect.runPromiseExit(timedEffect).then(console.log)
* // Output:
* // Start processing...
* // {
* //   _id: 'Exit',
* //   _tag: 'Failure',
* //   cause: {
* //     _id: 'Cause',
* //     _tag: 'Fail',
* //     failure: { _tag: 'TimeoutException' }
* //   }
* // }
* ```
*
* @since 2.0.0
* @category Delays & Timeouts
*/
var timeout = timeout$1;
/**
* Handles timeouts by returning an `Option` that represents either the result
* or a timeout.
*
* The `timeoutOption` function provides a way to gracefully handle
* timeouts by wrapping the outcome of an effect in an `Option` type. If the
* effect completes within the specified time, it returns a `Some` containing
* the result. If the effect times out, it returns a `None`, allowing you to
* treat the timeout as a regular result instead of throwing an error.
*
* This is useful when you want to handle timeouts without causing the program
* to fail, making it easier to manage situations where you expect tasks might
* take too long but want to continue executing other tasks.
*
* @see {@link timeout} for a version that raises a `TimeoutException`.
* @see {@link timeoutFail} for a version that raises a custom error.
* @see {@link timeoutFailCause} for a version that raises a custom defect.
* @see {@link timeoutTo} for a version that allows specifying both success and timeout handlers.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const task = Effect.gen(function*() {
*   console.log("Start processing...")
*   yield* Effect.sleep("2 seconds") // Simulates a delay in processing
*   console.log("Processing complete.")
*   return "Result"
* })
*
* const timedOutEffect = Effect.all([
*   task.pipe(Effect.timeoutOption("3 seconds")),
*   task.pipe(Effect.timeoutOption("1 second"))
* ])
*
* Effect.runPromise(timedOutEffect).then(console.log)
* // Output:
* // Start processing...
* // Processing complete.
* // Start processing...
* // [
* //   { _id: 'Option', _tag: 'Some', value: 'Result' },
* //   { _id: 'Option', _tag: 'None' }
* // ]
* ```
*
* @since 3.1.0
* @category Delays & Timeouts
*/
var timeoutOption = timeoutOption$1;
/**
* Applies a timeout to an effect, with a fallback effect executed if the timeout is reached.
*
* This function is useful when you want to set a maximum duration for an operation
* and provide an alternative action if the timeout is exceeded.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const slowQuery = Effect.gen(function*() {
*   yield* Console.log("Starting database query...")
*   yield* Effect.sleep("5 seconds")
*   return "Database result"
* })
*
* // Use cached data as fallback when timeout is reached
* const program = Effect.timeoutOrElse(slowQuery, {
*   duration: "2 seconds",
*   onTimeout: () =>
*     Effect.gen(function*() {
*       yield* Console.log("Query timed out, using cached data")
*       return "Cached result"
*     })
* })
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Starting database query...
* // Query timed out, using cached data
* // Cached result
* ```
*
* @since 3.1.0
* @category Delays & Timeouts
*/
var timeoutOrElse = timeoutOrElse$1;
/**
* Returns an effect that is delayed from this effect by the specified
* `Duration`.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.delay(
*   Console.log("Delayed message"),
*   "1 second"
* )
*
* Effect.runFork(program)
* // Waits 1 second, then prints: "Delayed message"
* ```
*
* @since 2.0.0
* @category Delays & Timeouts
*/
var delay = delay$1;
/**
* Returns an effect that suspends for the specified duration. This method is
* asynchronous, and does not actually block the fiber executing the effect.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.log("Start")
*   yield* Effect.sleep("2 seconds")
*   yield* Console.log("End")
* })
*
* Effect.runFork(program)
* // Output: "Start" (immediately)
* // Output: "End" (after 2 seconds)
* ```
*
* @since 2.0.0
* @category Delays & Timeouts
*/
var sleep = sleep$1;
/**
* Measures the runtime of an effect and returns the duration with its result.
*
* The original success, failure, or interruption is preserved; only the success
* value is paired with the duration.
*
* @example
* ```ts
* import { Console, Duration, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const [duration, value] = yield* Effect.timed(Effect.succeed("ok"))
*   yield* Console.log(`took ${Duration.toMillis(duration)}ms: ${value}`)
* })
* ```
*
* @since 2.0.0
* @category Delays & Timeouts
*/
var timed = timed$1;
/**
* Races multiple effects and returns the first successful result.
*
* **Details**
*
* This function runs multiple effects concurrently and returns the result of
* the first one to succeed. If one effect succeeds, the others will be
* interrupted.
*
* If none of the effects succeed, the function will fail with the last error
* encountered.
*
* **When to Use**
*
* This is useful when you want to race multiple effects, but only care about
* the first one to succeed. It is commonly used in cases like timeouts,
* retries, or when you want to optimize for the faster response without
* worrying about the other effects.
*
* @see {@link race} for a version that handles only two effects.
*
* @example
* ```ts
* import { Duration, Effect } from "effect"
*
* // Multiple effects with different delays
* const effect1 = Effect.delay(Effect.succeed("Fast"), Duration.millis(100))
* const effect2 = Effect.delay(Effect.succeed("Slow"), Duration.millis(500))
* const effect3 = Effect.delay(Effect.succeed("Very Slow"), Duration.millis(1000))
*
* // Race all effects - the first to succeed wins
* const raced = Effect.raceAll([effect1, effect2, effect3])
*
* // Result: "Fast" (after ~100ms)
* ```
*
* @since 2.0.0
* @category Racing
*/
var raceAll = raceAll$1;
/**
* Races multiple effects and returns the first successful result.
*
* **Details**
*
* Similar to `raceAll`, this function runs multiple effects concurrently
* and returns the result of the first one to succeed. If one effect succeeds,
* the others will be interrupted.
*
* @example
* ```ts
* import { Duration, Effect } from "effect"
*
* // Multiple effects with different delays and potential failures
* const effect1 = Effect.delay(Effect.succeed("First"), Duration.millis(200))
* const effect2 = Effect.delay(Effect.fail("Second failed"), Duration.millis(100))
* const effect3 = Effect.delay(Effect.succeed("Third"), Duration.millis(300))
*
* // Race all effects - the first to succeed wins
* const raced = Effect.raceAllFirst([effect1, effect2, effect3])
*
* // Result: "First" (after ~200ms, even though effect2 completes first but fails)
* ```
*
* @since 4.0.0
* @category Racing
*/
var raceAllFirst = raceAllFirst$1;
/**
* Races two effects and returns the first successful result.
*
* If one effect succeeds, the other is interrupted and `onWinner` can observe the
* winning fiber. If both fail, the race fails.
*
* @example
* ```ts
* import { Console, Duration, Effect } from "effect"
*
* const fastFail = Effect.delay(Effect.fail("fast-fail"), Duration.millis(10))
* const slowSuccess = Effect.delay(Effect.succeed("slow-success"), Duration.millis(50))
*
* const program = Effect.gen(function*() {
*   const result = yield* Effect.race(fastFail, slowSuccess)
*   yield* Console.log(`winner: ${result}`)
* })
*
* Effect.runPromise(program)
* // Output: winner: slow-success
* ```
*
* @since 2.0.0
* @category Racing
*/
var race = race$1;
/**
* Races two effects and returns the result of the first one to complete, whether
* it succeeds or fails.
*
* The losing effect is interrupted, and `onWinner` can observe the winning fiber.
*
* @example
* ```ts
* import { Console, Duration, Effect } from "effect"
*
* const fastFail = Effect.delay(Effect.fail("fast-fail"), Duration.millis(10))
* const slowSuccess = Effect.delay(Effect.succeed("slow-success"), Duration.millis(50))
*
* const program = Effect.gen(function*() {
*   const message = yield* Effect.match(Effect.raceFirst(fastFail, slowSuccess), {
*     onFailure: (error) => `failed: ${error}`,
*     onSuccess: (value) => `succeeded: ${value}`
*   })
*   yield* Console.log(message)
* })
*
* Effect.runPromise(program)
* // Output: failed: fast-fail
* ```
*
* @since 2.0.0
* @category Racing
*/
var raceFirst = raceFirst$1;
/**
* Filters elements of an iterable using a predicate, refinement, or effectful
* predicate.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // Sync predicate
* const evens = Effect.filter([1, 2, 3, 4], (n) => n % 2 === 0)
*
* // Effectful predicate
* const checked = Effect.filter([1, 2, 3], (n) => Effect.succeed(n > 1))
*
* // Use Effect.filterMapEffect for effectful Filter.Filter callbacks
* ```
*
* @since 2.0.0
* @category Filtering
*/
var filter = filter$1;
/**
* Filters and maps elements of an iterable with a `Filter`.
*
* @since 4.0.0
* @category Filtering
*/
var filterMap = filterMap$1;
/**
* Effectfully filters and maps elements of an iterable with a `FilterEffect`.
*
* @since 4.0.0
* @category Filtering
*/
var filterMapEffect = filterMapEffect$1;
/**
* Filters an effect, providing an alternative effect if the predicate fails.
*
* **Details**
*
* This function applies a predicate to the result of an effect. If the
* predicate evaluates to `false`, it executes the `orElse` effect instead. The
* `orElse` effect can produce an alternative value or perform additional
* computations.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // An effect that produces a number
* const program = Effect.succeed(5)
*
* // Filter for even numbers, provide alternative for odd numbers
* const filtered = Effect.filterOrElse(
*   program,
*   (n) => n % 2 === 0,
*   (n) => Effect.succeed(`Number ${n} is odd`)
* )
*
* // Result: "Number 5 is odd" (since 5 is not even)
* ```
*
* @since 2.0.0
* @category Filtering
*/
var filterOrElse = filterOrElse$1;
/**
* Filters an effect with a `Filter`, providing an alternative effect on failure.
*
* @since 4.0.0
* @category Filtering
*/
var filterMapOrElse = filterMapOrElse$1;
/**
* Filters an effect, failing with a custom error if the predicate fails.
*
* **Details**
*
* This function applies a predicate to the result of an effect. If the
* predicate evaluates to `false`, the effect fails with either a custom
* error (if `orFailWith` is provided) or a `NoSuchElementError`.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // An effect that produces a number
* const program = Effect.succeed(5)
*
* // Filter for even numbers, fail for odd numbers
* const filtered = Effect.filterOrFail(
*   program,
*   (n) => n % 2 === 0,
*   (n) => `Expected even number, got ${n}`
* )
*
* // Result: Effect.fail("Expected even number, got 5")
* ```
*
* @since 2.0.0
* @category Filtering
*/
var filterOrFail = filterOrFail$1;
/**
* Filters an effect with a `Filter`, failing when the filter fails.
*
* @since 4.0.0
* @category Filtering
*/
var filterMapOrFail = filterMapOrFail$1;
/**
* Conditionally executes an effect based on a boolean condition.
*
* **Details**
*
* This function allows you to run an effect only if a given condition evaluates
* to `true`. If the condition is `true`, the effect is executed, and its result
* is wrapped in an `Option.some`. If the condition is `false`, the effect is
* skipped, and the result is `Option.none`.
*
* **When to Use**
*
* This function is useful for scenarios where you need to dynamically decide
* whether to execute an effect based on runtime logic, while also representing
* the skipped case explicitly.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const shouldLog = true
*
* const program = Effect.when(
*   Console.log("Condition is true!"),
*   Effect.succeed(shouldLog)
* )
*
* Effect.runPromise(program).then(console.log)
* // Output: "Condition is true!"
* // { _id: 'Option', _tag: 'Some', value: undefined }
* ```
*
* @see {@link whenEffect} for a version that allows the condition to be an effect.
* @see {@link unless} for a version that executes the effect when the condition is `false`.
*
* @since 2.0.0
* @category Conditional Operators
*/
var when = when$1;
/**
* Handles both success and failure cases of an effect without performing side
* effects.
*
* **Details**
*
* `match` lets you define custom handlers for both success and failure
* scenarios. You provide separate functions to handle each case, allowing you
* to process the result if the effect succeeds, or handle the error if the
* effect fails.
*
* **When to Use**
*
* This is useful for structuring your code to respond differently to success or
* failure without triggering side effects.
*
* @see {@link matchEffect} if you need to perform side effects in the handlers.
*
* @example
* ```ts
* // Title: Handling Both Success and Failure Cases
* import { Effect } from "effect"
*
* const success: Effect.Effect<number, Error> = Effect.succeed(42)
*
* const program1 = Effect.match(success, {
*   onFailure: (error) => `failure: ${error.message}`,
*   onSuccess: (value) => `success: ${value}`
* })
*
* // Run and log the result of the successful effect
* Effect.runPromise(program1).then(console.log)
* // Output: "success: 42"
*
* const failure: Effect.Effect<number, Error> = Effect.fail(
*   new Error("Uh oh!")
* )
*
* const program2 = Effect.match(failure, {
*   onFailure: (error) => `failure: ${error.message}`,
*   onSuccess: (value) => `success: ${value}`
* })
*
* // Run and log the result of the failed effect
* Effect.runPromise(program2).then(console.log)
* // Output: "failure: Uh oh!"
* ```
*
* @since 2.0.0
* @category Pattern Matching
*/
var match = match$5;
/**
* Handles both success and failure cases of an effect without performing side
* effects, with eager evaluation for resolved effects.
*
* **Details**
*
* `matchEager` works like `match` but provides better performance for resolved
* effects (Success or Failure). When the effect is already resolved, it applies
* the handlers immediately without fiber scheduling. For unresolved effects,
* it falls back to the regular `match` behavior.
*
* **When to Use**
*
* Use this when you need to handle both success and failure cases and want
* optimal performance for resolved effects. This is particularly useful in
* scenarios where you frequently work with already computed values.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Effect.matchEager(Effect.succeed(42), {
*     onFailure: (error) => `Failed: ${error}`,
*     onSuccess: (value) => `Success: ${value}`
*   })
*   console.log(result) // "Success: 42"
* })
* ```
*
* @see {@link match} for the non-eager version.
* @see {@link matchEffect} if you need to perform side effects in the handlers.
*
* @since 2.0.0
* @category Pattern Matching
*/
var matchEager = matchEager$1;
/**
* Handles failures by matching the cause of failure.
*
* **Details**
*
* The `matchCause` function allows you to handle failures with access to the
* full cause of the failure within a fiber.
*
* **When to Use**
*
* This is useful for differentiating between different types of errors, such as
* regular failures, defects, or interruptions. You can provide specific
* handling logic for each failure type based on the cause.
*
* @example
* ```ts
* import { Cause, Effect } from "effect"
*
* const task = Effect.fail("Something went wrong")
*
* const program = Effect.matchCause(task, {
*   onFailure: (cause) => `Failed: ${Cause.squash(cause)}`,
*   onSuccess: (value) => `Success: ${value}`
* })
*
* Effect.runPromise(program).then(console.log)
* // Output: "Failed: Error: Something went wrong"
* ```
*
* @see {@link matchCauseEffect} if you need to perform side effects in the
* handlers.
* @see {@link match} if you don't need to handle the cause of the failure.
*
* @since 2.0.0
* @category Pattern Matching
*/
var matchCause = matchCause$1;
/**
* Handles failures by matching the cause of failure with eager evaluation.
*
* **Details**
*
* `matchCauseEager` works like `matchCause` but provides better performance for resolved
* effects by immediately applying the matching function instead of deferring it
* through the effect pipeline.
*
* **When to Use**
*
* This is useful when you have effects that are likely to be already resolved
* and you want to avoid the overhead of the effect pipeline. For pending effects,
* it automatically falls back to the regular `matchCause` behavior.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const handleResult = Effect.matchCauseEager(Effect.succeed(42), {
*   onSuccess: (value) => `Success: ${value}`,
*   onFailure: (cause) => `Failed: ${cause}`
* })
* ```
*
* @since 3.8.0
* @category Pattern Matching
*/
var matchCauseEager = matchCauseEager$1;
/**
* Eagerly handles success or failure with effectful handlers when the effect is already resolved.
*
* If the effect is an `Exit`, the matching handler runs immediately; otherwise it behaves like
* {@link matchCauseEffect}.
*
* @since 4.0.0
* @category Pattern Matching
*/
var matchCauseEffectEager = matchCauseEffectEager$1;
/**
* Handles failures with access to the cause and allows performing side effects.
*
* **Details**
*
* The `matchCauseEffect` function works similarly to {@link matchCause}, but it
* also allows you to perform additional side effects based on the failure
* cause. This function provides access to the complete cause of the failure,
* making it possible to differentiate between various failure types, and allows
* you to respond accordingly while performing side effects (like logging or
* other operations).
*
* @example
* ```ts
* import { Cause, Console, Effect, Result } from "effect"
*
* const task = Effect.fail(new Error("Task failed"))
*
* const program = Effect.matchCauseEffect(task, {
*   onFailure: (cause) =>
*     Effect.gen(function*() {
*       if (Cause.hasFails(cause)) {
*         const error = Cause.findError(cause)
*         if (Result.isSuccess(error)) {
*           yield* Console.log(`Handling error: ${error.success.message}`)
*         }
*         return "recovered from error"
*       } else {
*         yield* Console.log("Handling interruption or defect")
*         return "recovered from interruption/defect"
*       }
*     }),
*   onSuccess: (value) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Success: ${value}`)
*       return `processed ${value}`
*     })
* })
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Handling error: Task failed
* // recovered from error
* ```
*
* @see {@link matchCause} if you don't need side effects and only want to handle the result or failure.
* @see {@link matchEffect} if you don't need to handle the cause of the failure.
*
* @since 2.0.0
* @category Pattern Matching
*/
var matchCauseEffect = matchCauseEffect$1;
/**
* Handles both success and failure cases of an effect, allowing for additional
* side effects.
*
* **Details**
*
* The `matchEffect` function is similar to {@link match}, but it enables you to
* perform side effects in the handlers for both success and failure outcomes.
*
* **When to Use**
*
* This is useful when you need to execute additional actions, like logging or
* notifying users, based on whether an effect succeeds or fails.
*
* @see {@link match} if you don't need side effects and only want to handle the
* result or failure.
*
* @example
* ```ts
* // Title: Handling Both Success and Failure Cases with Side Effects
* import { Effect } from "effect"
*
* const success: Effect.Effect<number, Error> = Effect.succeed(42)
* const failure: Effect.Effect<number, Error> = Effect.fail(
*   new Error("Uh oh!")
* )
*
* const program1 = Effect.matchEffect(success, {
*   onFailure: (error) =>
*     Effect.succeed(`failure: ${error.message}`).pipe(
*       Effect.tap(Effect.log)
*     ),
*   onSuccess: (value) =>
*     Effect.succeed(`success: ${value}`).pipe(Effect.tap(Effect.log))
* })
*
* console.log(Effect.runSync(program1))
* // Output:
* // timestamp=... level=INFO fiber=#0 message="success: 42"
* // success: 42
*
* const program2 = Effect.matchEffect(failure, {
*   onFailure: (error) =>
*     Effect.succeed(`failure: ${error.message}`).pipe(
*       Effect.tap(Effect.log)
*     ),
*   onSuccess: (value) =>
*     Effect.succeed(`success: ${value}`).pipe(Effect.tap(Effect.log))
* })
*
* console.log(Effect.runSync(program2))
* // Output:
* // timestamp=... level=INFO fiber=#1 message="failure: Uh oh!"
* // failure: Uh oh!
* ```
*
* @since 2.0.0
* @category Pattern Matching
*/
var matchEffect = matchEffect$2;
/**
* Determines whether an effect fails.
*
* Defects are not converted; if the effect dies, the resulting effect dies too.
*
* **Example**
*
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const failed = yield* Effect.isFailure(Effect.fail("Uh oh!"))
*   yield* Console.log(failed)
* })
*
* Effect.runPromise(program)
* // Output: true
* ```
*
* @since 2.0.0
* @category Condition Checking
*/
var isFailure = isFailure$2;
/**
* Returns whether an effect completes successfully.
*
* Returns `false` for failures in the error channel, but defects still fail the
* effect.
*
* **Example**
*
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const ok = yield* Effect.isSuccess(Effect.succeed("done"))
*   const failed = yield* Effect.isSuccess(Effect.fail("Uh oh"))
*   yield* Console.log(`ok: ${ok}`)
*   yield* Console.log(`failed: ${failed}`)
* })
*
* Effect.runPromise(program)
* // Output:
* // ok: true
* // failed: false
* ```
*
* @since 2.0.0
* @category Condition Checking
*/
var isSuccess = isSuccess$2;
/**
* Returns the complete service map from the current context.
*
* This function allows you to access all services that are currently available
* in the effect's environment. This can be useful for debugging, introspection,
* or when you need to pass the entire context to another function.
*
* @example
* ```ts
* import { Console, Effect, Option, ServiceMap } from "effect"
*
* const Logger = ServiceMap.Service<{
*   log: (msg: string) => void
* }>("Logger")
* const Database = ServiceMap.Service<{
*   query: (sql: string) => string
* }>("Database")
*
* const program = Effect.gen(function*() {
*   const allServices = yield* Effect.services()
*
*   // Check if specific services are available
*   const loggerOption = ServiceMap.getOption(allServices, Logger)
*   const databaseOption = ServiceMap.getOption(allServices, Database)
*
*   yield* Console.log(`Logger available: ${Option.isSome(loggerOption)}`)
*   yield* Console.log(`Database available: ${Option.isSome(databaseOption)}`)
* })
*
* const serviceMap = ServiceMap.make(Logger, { log: console.log })
*   .pipe(ServiceMap.add(Database, { query: () => "result" }))
*
* const provided = Effect.provideServices(program, serviceMap)
* ```
*
* @since 2.0.0
* @category Environment
*/
var services = services$1;
/**
* Transforms the current service map using the provided function.
*
* This function allows you to access the complete service map and perform
* computations based on all available services. This is useful when you need
* to conditionally execute logic based on what services are available.
*
* @example
* ```ts
* import { Console, Effect, Option, ServiceMap } from "effect"
*
* const Logger = ServiceMap.Service<{
*   log: (msg: string) => void
* }>("Logger")
* const Cache = ServiceMap.Service<{
*   get: (key: string) => string | null
* }>("Cache")
*
* const program = Effect.servicesWith((services) => {
*   const cacheOption = ServiceMap.getOption(services, Cache)
*   const hasCache = Option.isSome(cacheOption)
*
*   if (hasCache) {
*     return Effect.gen(function*() {
*       const cache = yield* Effect.service(Cache)
*       yield* Console.log("Using cached data")
*       return cache.get("user:123") || "default"
*     })
*   } else {
*     return Effect.gen(function*() {
*       yield* Console.log("No cache available, using fallback")
*       return "fallback data"
*     })
*   }
* })
*
* const withCache = Effect.provideService(program, Cache, {
*   get: () => "cached_value"
* })
* ```
*
* @since 2.0.0
* @category Environment
*/
var servicesWith = servicesWith$1;
/**
* Provides dependencies to an effect using layers or a context. Use `options.local`
* to build the layer every time; by default, layers are shared between provide
* calls.
*
* @example
* ```ts
* import { Effect, Layer, ServiceMap } from "effect"
*
* interface Database {
*   readonly query: (sql: string) => Effect.Effect<string>
* }
*
* const Database = ServiceMap.Service<Database>("Database")
*
* const DatabaseLive = Layer.succeed(Database)({
*   query: (sql: string) => Effect.succeed(`Result for: ${sql}`)
* })
*
* const program = Effect.gen(function*() {
*   const db = yield* Database
*   return yield* db.query("SELECT * FROM users")
* })
*
* const provided = Effect.provide(program, DatabaseLive)
*
* Effect.runPromise(provided).then(console.log)
* // Output: "Result for: SELECT * FROM users"
* ```
*
* @since 2.0.0
* @category Environment
*/
var provide = provide$1;
/**
* Provides a service map to an effect, fulfilling its service requirements.
*
* **Details**
*
* This function provides multiple services at once by supplying a service map
* that contains all the required services. It removes the provided services
* from the effect's requirements, making them available to the effect.
*
* @example
* ```ts
* import { Effect, ServiceMap } from "effect"
*
* // Define service keys
* const Logger = ServiceMap.Service<{
*   log: (msg: string) => void
* }>("Logger")
* const Database = ServiceMap.Service<{
*   query: (sql: string) => string
* }>("Database")
*
* // Create service map with multiple services
* const serviceMap = ServiceMap.make(Logger, { log: console.log })
*   .pipe(ServiceMap.add(Database, { query: () => "result" }))
*
* // An effect that requires both services
* const program = Effect.gen(function*() {
*   const logger = yield* Effect.service(Logger)
*   const db = yield* Effect.service(Database)
*   logger.log("Querying database")
*   return db.query("SELECT * FROM users")
* })
*
* const provided = Effect.provideServices(program, serviceMap)
* ```
*
* @since 2.0.0
* @category Environment
*/
var provideServices = provideServices$1;
/**
* Accesses a service from the context.
*
* @example
* ```ts
* import { Effect, ServiceMap } from "effect"
*
* interface Database {
*   readonly query: (sql: string) => Effect.Effect<string>
* }
*
* const Database = ServiceMap.Service<Database>("Database")
*
* const program = Effect.gen(function*() {
*   const db = yield* Effect.service(Database)
*   return yield* db.query("SELECT * FROM users")
* })
* ```
*
* @since 4.0.0
* @category ServiceMap
*/
var service = service$1;
/**
* Optionally accesses a service from the environment.
*
* **Details**
*
* This function attempts to access a service from the environment. If the
* service is available, it returns `Some(service)`. If the service is not
* available, it returns `None`. Unlike `service`, this function does not
* require the service to be present in the environment.
*
* @example
* ```ts
* import { Effect, Option, ServiceMap } from "effect"
*
* // Define a service key
* const Logger = ServiceMap.Service<{
*   log: (msg: string) => void
* }>("Logger")
*
* // Use serviceOption to optionally access the logger
* const program = Effect.gen(function*() {
*   const maybeLogger = yield* Effect.serviceOption(Logger)
*
*   if (Option.isSome(maybeLogger)) {
*     maybeLogger.value.log("Service is available")
*   } else {
*     console.log("Service not available")
*   }
* })
* ```
*
* @since 2.0.0
* @category ServiceMap
*/
var serviceOption = serviceOption$1;
/**
* Provides part of the required context while leaving the rest unchanged.
*
* **Details**
*
* This function allows you to transform the context required by an effect,
* providing part of the context and leaving the rest to be fulfilled later.
*
* @example
* ```ts
* import { Effect, ServiceMap } from "effect"
*
* // Define services
* const Logger = ServiceMap.Service<{
*   log: (msg: string) => void
* }>("Logger")
* const Config = ServiceMap.Service<{
*   name: string
* }>("Config")
*
* const program = Effect.service(Config).pipe(
*   Effect.map((config) => `Hello ${config.name}!`)
* )
*
* // Transform services by providing Config while keeping Logger requirement
* const configured = program.pipe(
*   Effect.updateServices((services: ServiceMap.ServiceMap<typeof Logger>) =>
*     ServiceMap.add(services, Config, { name: "World" })
*   )
* )
*
* // The effect now requires only Logger service
* const result = Effect.provideService(configured, Logger, {
*   log: (msg) => console.log(msg)
* })
* ```
*
* @since 4.0.0
* @category ServiceMap
*/
var updateServices = updateServices$1;
/**
* Updates the service with the required service entry.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap } from "effect"
*
* // Define a counter service
* const Counter = ServiceMap.Service<{ count: number }>("Counter")
*
* const program = Effect.gen(function*() {
*   const updatedCounter = yield* Effect.service(Counter)
*   yield* Console.log(`Updated count: ${updatedCounter.count}`)
*   return updatedCounter.count
* }).pipe(
*   Effect.updateService(Counter, (counter) => ({ count: counter.count + 1 }))
* )
*
* // Provide initial service and run
* const result = Effect.provideService(program, Counter, { count: 0 })
* Effect.runPromise(result).then(console.log)
* // Output: Updated count: 1
* // 1
* ```
*
* @since 2.0.0
* @category ServiceMap
*/
var updateService = updateService$2;
/**
* The `provideService` function is used to provide an actual
* implementation for a service in the context of an effect.
*
* This function allows you to associate a service with its implementation so
* that it can be used in your program. You define the service (e.g., a random
* number generator), and then you use `provideService` to link that
* service to its implementation. Once the implementation is provided, the
* effect can be run successfully without further requirements.
*
* @see {@link provide} for providing multiple layers to an effect.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap } from "effect"
*
* // Define a service for configuration
* const Config = ServiceMap.Service<{
*   apiUrl: string
*   timeout: number
* }>("Config")
*
* const fetchData = Effect.gen(function*() {
*   const config = yield* Effect.service(Config)
*   yield* Console.log(`Fetching from: ${config.apiUrl}`)
*   yield* Console.log(`Timeout: ${config.timeout}ms`)
*   return "data"
* })
*
* // Provide the service implementation
* const program = Effect.provideService(fetchData, Config, {
*   apiUrl: "https://api.example.com",
*   timeout: 5000
* })
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Fetching from: https://api.example.com
* // Timeout: 5000ms
* // data
* ```
*
* @since 2.0.0
* @category ServiceMap
*/
var provideService = provideService$1;
/**
* Provides the effect with the single service it requires. If the effect
* requires more than one service use `provide` instead.
*
* This function is similar to `provideService`, but instead of providing a
* static service implementation, it allows you to provide an effect that
* will produce the service. This is useful when the service needs to be
* acquired through an effectful computation (e.g., reading from a database,
* making an HTTP request, or allocating resources).
*
* @example
* ```ts
* import { Console, Effect, ServiceMap } from "effect"
*
* // Define a database connection service
* interface DatabaseConnection {
*   readonly query: (sql: string) => Effect.Effect<string>
* }
* const Database = ServiceMap.Service<DatabaseConnection>("Database")
*
* // Effect that creates a database connection
* const createConnection = Effect.gen(function*() {
*   yield* Console.log("Establishing database connection...")
*   yield* Effect.sleep("100 millis") // Simulate connection time
*   yield* Console.log("Database connected!")
*   return {
*     query: (sql: string) => Effect.succeed(`Result for: ${sql}`)
*   }
* })
*
* const program = Effect.gen(function*() {
*   const db = yield* Effect.service(Database)
*   return yield* db.query("SELECT * FROM users")
* })
*
* // Provide the service through an effect
* const withDatabase = Effect.provideServiceEffect(
*   program,
*   Database,
*   createConnection
* )
*
* Effect.runPromise(withDatabase).then(console.log)
* // Output:
* // Establishing database connection...
* // Database connected!
* // Result for: SELECT * FROM users
* ```
*
* @since 2.0.0
* @category ServiceMap
*/
var provideServiceEffect = provideServiceEffect$1;
/**
* Sets the concurrency level for parallel operations within an effect.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const task = (id: number) =>
*   Effect.gen(function*() {
*     yield* Console.log(`Task ${id} starting`)
*     yield* Effect.sleep("100 millis")
*     yield* Console.log(`Task ${id} completed`)
*     return id
*   })
*
* // Run tasks with limited concurrency (max 2 at a time)
* const program = Effect.gen(function*() {
*   const tasks = [1, 2, 3, 4, 5].map(task)
*   return yield* Effect.all(tasks, { concurrency: 2 })
* }).pipe(
*   Effect.withConcurrency(2)
* )
*
* Effect.runPromise(program).then(console.log)
* // Tasks will run with max 2 concurrent operations
* // [1, 2, 3, 4, 5]
* ```
*
* @since 2.0.0
* @category References
*/
var withConcurrency = withConcurrency$1;
/**
* Returns the current scope for resource management.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const currentScope = yield* Effect.scope
*   yield* Console.log("Got scope for resource management")
*
*   // Use the scope to manually manage resources if needed
*   const resource = yield* Effect.acquireRelease(
*     Console.log("Acquiring resource").pipe(Effect.as("resource")),
*     () => Console.log("Releasing resource")
*   )
*
*   return resource
* })
*
* Effect.runPromise(Effect.scoped(program)).then(console.log)
* // Output:
* // Got scope for resource management
* // Acquiring resource
* // resource
* // Releasing resource
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var scope = scope$1;
/**
* Scopes all resources used in this workflow to the lifetime of the workflow,
* ensuring that their finalizers are run as soon as this workflow completes
* execution, whether by success, failure, or interruption.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const resource = Effect.acquireRelease(
*   Console.log("Acquiring resource").pipe(Effect.as("resource")),
*   () => Console.log("Releasing resource")
* )
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const res = yield* resource
*     yield* Console.log(`Using ${res}`)
*     return res
*   })
* )
*
* Effect.runFork(program)
* // Output: "Acquiring resource"
* // Output: "Using resource"
* // Output: "Releasing resource"
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var scoped = scoped$1;
/**
* Creates a scoped effect by providing access to the scope.
*
* @example
* ```ts
* import { Console, Effect, Scope } from "effect"
*
* const program = Effect.scopedWith((scope) =>
*   Effect.gen(function*() {
*     yield* Console.log("Inside scoped context")
*
*     // Manually add a finalizer to the scope
*     yield* Scope.addFinalizer(scope, Console.log("Manual finalizer"))
*
*     // Create a scoped resource
*     const resource = yield* Effect.scoped(
*       Effect.acquireRelease(
*         Console.log("Acquiring resource").pipe(Effect.as("resource")),
*         () => Console.log("Releasing resource")
*       )
*     )
*
*     return resource
*   })
* )
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Inside scoped context
* // Acquiring resource
* // resource
* // Releasing resource
* // Manual finalizer
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var scopedWith = scopedWith$1;
/**
* This function constructs a scoped resource from an `acquire` and `release`
* `Effect` value.
*
* If the `acquire` `Effect` value successfully completes execution, then the
* `release` `Effect` value will be added to the finalizers associated with the
* scope of this `Effect` value, and it is guaranteed to be run when the scope
* is closed.
*
* The `acquire` and `release` `Effect` values will be run uninterruptibly.
* Additionally, the `release` `Effect` value may depend on the `Exit` value
* specified when the scope is closed.
*
* @example
* ```ts
* import { Console, Effect, Exit } from "effect"
*
* // Simulate a resource that needs cleanup
* interface FileHandle {
*   readonly path: string
*   readonly content: string
* }
*
* // Acquire a file handle
* const acquire = Effect.gen(function*() {
*   yield* Console.log("Opening file")
*   return { path: "/tmp/file.txt", content: "file content" }
* })
*
* // Release the file handle
* const release = (handle: FileHandle, exit: Exit.Exit<unknown, unknown>) =>
*   Console.log(
*     `Closing file ${handle.path} with exit: ${
*       Exit.isSuccess(exit) ? "success" : "failure"
*     }`
*   )
*
* // Create a scoped resource
* const resource = Effect.acquireRelease(acquire, release)
*
* // Use the resource within a scope
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const handle = yield* resource
*     yield* Console.log(`Using file: ${handle.path}`)
*     return handle.content
*   })
* )
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var acquireRelease = acquireRelease$1;
/**
* This function is used to ensure that an `Effect` value that represents the
* acquisition of a resource (for example, opening a file, launching a thread,
* etc.) will not be interrupted, and that the resource will always be released
* when the `Effect` value completes execution.
*
* `acquireUseRelease` does the following:
*
*   1. Ensures that the `Effect` value that acquires the resource will not be
*      interrupted. Note that acquisition may still fail due to internal
*      reasons (such as an uncaught exception).
*   2. Ensures that the `release` `Effect` value will not be interrupted,
*      and will be executed as long as the acquisition `Effect` value
*      successfully acquires the resource.
*
* During the time period between the acquisition and release of the resource,
* the `use` `Effect` value will be executed.
*
* If the `release` `Effect` value fails, then the entire `Effect` value will
* fail, even if the `use` `Effect` value succeeds. If this fail-fast behavior
* is not desired, errors produced by the `release` `Effect` value can be caught
* and ignored.
*
* @example
* ```ts
* import { Console, Effect, Exit } from "effect"
*
* interface Database {
*   readonly connection: string
*   readonly query: (sql: string) => Effect.Effect<string>
* }
*
* const program = Effect.acquireUseRelease(
*   // Acquire - connect to database
*   Effect.gen(function*() {
*     yield* Console.log("Connecting to database...")
*     return {
*       connection: "db://localhost:5432",
*       query: (sql: string) => Effect.succeed(`Result for: ${sql}`)
*     }
*   }),
*   // Use - perform database operations
*   (db) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Connected to ${db.connection}`)
*       const result = yield* db.query("SELECT * FROM users")
*       yield* Console.log(`Query result: ${result}`)
*       return result
*     }),
*   // Release - close database connection
*   (db, exit) =>
*     Effect.gen(function*() {
*       if (Exit.isSuccess(exit)) {
*         yield* Console.log(`Closing connection to ${db.connection} (success)`)
*       } else {
*         yield* Console.log(`Closing connection to ${db.connection} (failure)`)
*       }
*     })
* )
*
* Effect.runPromise(program)
* // Output:
* // Connecting to database...
* // Connected to db://localhost:5432
* // Query result: Result for: SELECT * FROM users
* // Closing connection to db://localhost:5432 (success)
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var acquireUseRelease = acquireUseRelease$1;
/**
* This function adds a finalizer to the scope of the calling `Effect` value.
* The finalizer is guaranteed to be run when the scope is closed, and it may
* depend on the `Exit` value that the scope is closed with.
*
* Finalizers are useful for cleanup operations that must run regardless of
* whether the effect succeeds or fails. They're commonly used for resource
* cleanup, logging, or other side effects that should always occur.
*
* @example
* ```ts
* import { Console, Effect, Exit } from "effect"
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     // Add a finalizer that runs when the scope closes
*     yield* Effect.addFinalizer((exit) =>
*       Console.log(
*         Exit.isSuccess(exit)
*           ? "Cleanup: Operation completed successfully"
*           : "Cleanup: Operation failed, cleaning up resources"
*       )
*     )
*
*     yield* Console.log("Performing main operation...")
*
*     // This could succeed or fail
*     return "operation result"
*   })
* )
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Performing main operation...
* // Cleanup: Operation completed successfully
* // operation result
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var addFinalizer = addFinalizer$2;
/**
* Returns an effect that, if this effect _starts_ execution, then the
* specified `finalizer` is guaranteed to be executed, whether this effect
* succeeds, fails, or is interrupted.
*
* For use cases that need access to the effect's result, see `onExit`.
*
* Finalizers offer very powerful guarantees, but they are low-level, and
* should generally not be used for releasing resources. For higher-level
* logic built on `ensuring`, see the `acquireRelease` family of methods.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const task = Effect.gen(function*() {
*   yield* Console.log("Task started")
*   yield* Effect.sleep("1 second")
*   yield* Console.log("Task completed")
*   return 42
* })
*
* // Ensure cleanup always runs, regardless of success or failure
* const program = Effect.ensuring(
*   task,
*   Console.log("Cleanup: This always runs!")
* )
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Task started
* // Task completed
* // Cleanup: This always runs!
* // 42
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var ensuring = ensuring$1;
/**
* Runs the specified effect if this effect fails, providing the error to the
* effect if it exists. The provided effect will not be interrupted.
*
* @example
* ```ts
* import { Cause, Console, Effect } from "effect"
*
* const task = Effect.fail(new Error("Something went wrong"))
*
* const program = Effect.onError(
*   task,
*   (cause) => Console.log(`Cleanup on error: ${Cause.squash(cause)}`)
* )
*
* Effect.runPromise(program).catch(console.error)
* // Output:
* // Cleanup on error: Error: Something went wrong
* // Error: Something went wrong
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var onError = onError$1;
/**
* Runs the finalizer only when this effect fails and the `Cause` matches the
* provided predicate.
*
* @example
* ```ts
* import { Cause, Console, Effect } from "effect"
*
* const task = Effect.fail("boom")
*
* const program = Effect.onErrorIf(
*   task,
*   Cause.hasFails,
*   (cause) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Cause: ${Cause.pretty(cause)}`)
*     })
* )
* ```
*
* @since 4.0.0
* @category Resource Management & Finalization
*/
var onErrorIf = onErrorIf$1;
/**
* Runs the finalizer only when this effect fails and the cause matches the provided `Filter`.
*
* @since 4.0.0
* @category Resource Management & Finalization
*/
var onErrorFilter = onErrorFilter$1;
/**
* The low level primitive that powers `onExit`.
* function is used to run a finalizer when the effect exits, regardless of the
* exit status.
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var onExitPrimitive = onExitPrimitive$1;
/**
* Ensures that a cleanup functions runs, whether this effect succeeds, fails,
* or is interrupted.
*
* @example
* ```ts
* import { Console, Effect, Exit } from "effect"
*
* const task = Effect.succeed(42)
*
* const program = Effect.onExit(task, (exit) =>
*   Console.log(
*     Exit.isSuccess(exit)
*       ? `Task succeeded with: ${exit.value}`
*       : `Task failed: ${Exit.isFailure(exit) ? exit.cause : "interrupted"}`
*   ))
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Task succeeded with: 42
* // 42
* ```
*
* @since 2.0.0
* @category Resource Management & Finalization
*/
var onExit = onExit$1;
/**
* Runs the cleanup effect only when the `Exit` satisfies the provided
* predicate.
*
* @example
* ```ts
* import { Console, Effect, Exit } from "effect"
*
* const program = Effect.onExitIf(
*   Effect.succeed(42),
*   Exit.isSuccess,
*   (exit) =>
*     Exit.isSuccess(exit)
*       ? Console.log(`Succeeded with: ${exit.value}`)
*       : Effect.void
* )
* ```
*
* @since 4.0.0
* @category Resource Management & Finalization
*/
var onExitIf = onExitIf$1;
/**
* Runs the cleanup effect only when the `Exit` matches the provided `Filter`.
*
* @since 4.0.0
* @category Resource Management & Finalization
*/
var onExitFilter = onExitFilter$1;
/**
* Returns an effect that lazily computes a result and caches it for subsequent
* evaluations.
*
* **Details**
*
* This function wraps an effect and ensures that its result is computed only
* once. Once the result is computed, it is cached, meaning that subsequent
* evaluations of the same effect will return the cached result without
* re-executing the logic.
*
* **When to Use**
*
* Use this function when you have an expensive or time-consuming operation that
* you want to avoid repeating. The first evaluation will compute the result,
* and all following evaluations will immediately return the cached value,
* improving performance and reducing unnecessary work.
*
* @see {@link cachedWithTTL} for a similar function that includes a
* time-to-live duration for the cached value.
* @see {@link cachedInvalidateWithTTL} for a similar function that includes an
* additional effect for manually invalidating the cached value.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* let i = 1
* const expensiveTask = Effect.promise<string>(() => {
*   console.log("expensive task...")
*   return new Promise((resolve) => {
*     setTimeout(() => {
*       resolve(`result ${i++}`)
*     }, 100)
*   })
* })
*
* const program = Effect.gen(function*() {
*   console.log("non-cached version:")
*   yield* expensiveTask.pipe(Effect.andThen(Console.log))
*   yield* expensiveTask.pipe(Effect.andThen(Console.log))
*   console.log("cached version:")
*   const cached = yield* Effect.cached(expensiveTask)
*   yield* cached.pipe(Effect.andThen(Console.log))
*   yield* cached.pipe(Effect.andThen(Console.log))
* })
*
* Effect.runFork(program)
* // Output:
* // non-cached version:
* // expensive task...
* // result 1
* // expensive task...
* // result 2
* // cached version:
* // expensive task...
* // result 3
* // result 3
* ```
*
* @since 2.0.0
* @category Caching
*/
var cached = cached$1;
/**
* Returns an effect that caches its result for a specified `Duration`,
* known as "timeToLive" (TTL).
*
* **Details**
*
* This function is used to cache the result of an effect for a specified amount
* of time. This means that the first time the effect is evaluated, its result
* is computed and stored.
*
* If the effect is evaluated again within the specified `timeToLive`, the
* cached result will be used, avoiding recomputation.
*
* After the specified duration has passed, the cache expires, and the effect
* will be recomputed upon the next evaluation.
*
* **When to Use**
*
* Use this function when you have an effect that involves costly operations or
* computations, and you want to avoid repeating them within a short time frame.
*
* It's ideal for scenarios where the result of an effect doesn't change
* frequently and can be reused for a specified duration.
*
* By caching the result, you can improve efficiency and reduce unnecessary
* computations, especially in performance-critical applications.
*
* @see {@link cached} for a similar function that caches the result
* indefinitely.
* @see {@link cachedInvalidateWithTTL} for a similar function that includes an
* additional effect for manually invalidating the cached value.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* let i = 1
* const expensiveTask = Effect.promise<string>(() => {
*   console.log("expensive task...")
*   return new Promise((resolve) => {
*     setTimeout(() => {
*       resolve(`result ${i++}`)
*     }, 100)
*   })
* })
*
* const program = Effect.gen(function*() {
*   const cached = yield* Effect.cachedWithTTL(expensiveTask, "150 millis")
*   yield* cached.pipe(Effect.andThen(Console.log))
*   yield* cached.pipe(Effect.andThen(Console.log))
*   yield* Effect.sleep("100 millis")
*   yield* cached.pipe(Effect.andThen(Console.log))
* })
*
* Effect.runFork(program)
* // Output:
* // expensive task...
* // result 1
* // result 1
* // expensive task...
* // result 2
* ```
*
* @since 2.0.0
* @category Caching
*/
var cachedWithTTL = cachedWithTTL$1;
/**
* Caches an effect's result for a specified duration and allows manual
* invalidation before expiration.
*
* **Details**
*
* This function behaves similarly to {@link cachedWithTTL} by caching the
* result of an effect for a specified period of time. However, it introduces an
* additional feature: it provides an effect that allows you to manually
* invalidate the cached result before it naturally expires.
*
* This gives you more control over the cache, allowing you to refresh the
* result when needed, even if the original cache has not yet expired.
*
* Once the cache is invalidated, the next time the effect is evaluated, the
* result will be recomputed, and the cache will be refreshed.
*
* **When to Use**
*
* Use this function when you have an effect whose result needs to be cached for
* a certain period, but you also want the option to refresh the cache manually
* before the expiration time.
*
* This is useful when you need to ensure that the cached data remains valid for
* a certain period but still want to invalidate it if the underlying data
* changes or if you want to force a recomputation.
*
* @see {@link cached} for a similar function that caches the result
* indefinitely.
* @see {@link cachedWithTTL} for a similar function that caches the result for
* a specified duration but does not include an effect for manual invalidation.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* let i = 1
* const expensiveTask = Effect.promise<string>(() => {
*   console.log("expensive task...")
*   return new Promise((resolve) => {
*     setTimeout(() => {
*       resolve(`result ${i++}`)
*     }, 100)
*   })
* })
*
* const program = Effect.gen(function*() {
*   const [cached, invalidate] = yield* Effect.cachedInvalidateWithTTL(
*     expensiveTask,
*     "1 hour"
*   )
*   yield* cached.pipe(Effect.andThen(Console.log))
*   yield* cached.pipe(Effect.andThen(Console.log))
*   yield* invalidate
*   yield* cached.pipe(Effect.andThen(Console.log))
* })
*
* Effect.runFork(program)
* // Output:
* // expensive task...
* // result 1
* // result 1
* // expensive task...
* // result 2
* ```
*
* @since 2.0.0
* @category Caching
*/
var cachedInvalidateWithTTL = cachedInvalidateWithTTL$1;
/**
* Returns an effect that is immediately interrupted.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.interrupt
*   yield* Effect.succeed("This won't execute")
* })
*
* Effect.runPromise(program).catch(console.error)
* // Throws: InterruptedException
* ```
*
* @since 2.0.0
* @category Interruption
*/
var interrupt = interrupt$4;
/**
* Returns a new effect that allows the effect to be interruptible.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const longRunning = Effect.forever(Effect.succeed("working..."))
*
* const program = Effect.interruptible(longRunning)
*
* // This effect can now be interrupted
* const fiber = Effect.runFork(program)
* // Later: fiber.interrupt()
* ```
*
* @since 2.0.0
* @category Interruption
*/
var interruptible = interruptible$1;
/**
* Runs the specified finalizer effect if this effect is interrupted.
*
* @example
* ```ts
* import { Console, Effect, Fiber } from "effect"
*
* const task = Effect.forever(Effect.succeed("working..."))
*
* const program = Effect.onInterrupt(
*   task,
*   () => Console.log("Task was interrupted, cleaning up...")
* )
*
* const fiber = Effect.runFork(program)
* // Later interrupt the task
* Effect.runFork(Fiber.interrupt(fiber))
* // Output: Task was interrupted, cleaning up...
* ```
*
* @since 2.0.0
* @category Interruption
*/
var onInterrupt = onInterrupt$1;
/**
* Returns a new effect that disables interruption for the given effect.
*
* @example
* ```ts
* import { Console, Effect, Fiber } from "effect"
*
* const criticalTask = Effect.gen(function*() {
*   yield* Console.log("Starting critical section...")
*   yield* Effect.sleep("2 seconds")
*   yield* Console.log("Critical section completed")
* })
*
* const program = Effect.uninterruptible(criticalTask)
*
* const fiber = Effect.runFork(program)
* // Even if interrupted, the critical task will complete
* Effect.runPromise(Fiber.interrupt(fiber))
* ```
*
* @since 2.0.0
* @category Interruption
*/
var uninterruptible = uninterruptible$1;
/**
* Disables interruption and provides a restore function to restore the
* interruptible state within the effect.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.uninterruptibleMask((restore) =>
*   Effect.gen(function*() {
*     yield* Console.log("Uninterruptible phase...")
*     yield* Effect.sleep("1 second")
*
*     // Restore interruptibility for this part
*     yield* restore(
*       Effect.gen(function*() {
*         yield* Console.log("Interruptible phase...")
*         yield* Effect.sleep("2 seconds")
*       })
*     )
*
*     yield* Console.log("Back to uninterruptible")
*   })
* )
* ```
*
* @since 2.0.0
* @category Interruption
*/
var uninterruptibleMask = uninterruptibleMask$1;
/**
* This function behaves like {@link interruptible}, but it also provides a
* `restore` function. This function can be used to restore the interruptibility
* of any specific region of code.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.interruptibleMask((restore) =>
*   Effect.gen(function*() {
*     yield* Console.log("Interruptible phase...")
*     yield* Effect.sleep("1 second")
*
*     // Make this part uninterruptible
*     yield* restore(
*       Effect.gen(function*() {
*         yield* Console.log("Uninterruptible phase...")
*         yield* Effect.sleep("2 seconds")
*       })
*     )
*
*     yield* Console.log("Back to interruptible")
*   })
* )
* ```
*
* @since 2.0.0
* @category Interruption
*/
var interruptibleMask = interruptibleMask$1;
/**
* Repeats this effect forever (until the first error).
*
* @example
* ```ts
* import { Console, Effect, Fiber } from "effect"
*
* const task = Effect.gen(function*() {
*   yield* Console.log("Task running...")
*   yield* Effect.sleep("1 second")
* })
*
* // This will run forever, printing every second
* const program = task.pipe(Effect.forever)
*
* // This will run forever, without yielding every iteration
* const programNoYield = task.pipe(Effect.forever({ disableYield: true }))
*
* // Run for 5 seconds then interrupt
* const timedProgram = Effect.gen(function*() {
*   const fiber = yield* Effect.forkChild(program)
*   yield* Effect.sleep("5 seconds")
*   yield* Fiber.interrupt(fiber)
* })
* ```
*
* @since 2.0.0
* @category Repetition / Recursion
*/
var forever = forever$2;
/**
* Repeats an effect based on a specified schedule or until the first failure.
*
* **Details**
*
* This function executes an effect repeatedly according to the given schedule.
* Each repetition occurs after the initial execution of the effect, meaning
* that the schedule determines the number of additional repetitions. For
* example, using `Schedule.once` will result in the effect being executed twice
* (once initially and once as part of the repetition).
*
* If the effect succeeds, it is repeated according to the schedule. If it
* fails, the repetition stops immediately, and the failure is returned.
*
* The schedule can also specify delays between repetitions, making it useful
* for tasks like retrying operations with backoff, periodic execution, or
* performing a series of dependent actions.
*
* You can combine schedules for more advanced repetition logic, such as adding
* delays, limiting recursions, or dynamically adjusting based on the outcome of
* each execution.
*
* @example
* ```ts
* // Success Example
* import { Effect } from "effect"
* import { Schedule } from "effect"
* import { Console } from "effect"
*
* const action = Console.log("success")
* const policy = Schedule.addDelay(Schedule.recurs(2), () => Effect.succeed("100 millis"))
* const program = Effect.repeat(action, policy)
*
* // Effect.runPromise(program).then((n) => console.log(`repetitions: ${n}`))
* ```
*
* @example
* // Failure Example
* import { Effect } from "effect"
* import { Schedule } from "effect"
*
* let count = 0
*
* // Define a callback effect that simulates an action with possible failures
* const action = Effect.callback<string, string>((resume) => {
*   if (count > 1) {
*     console.log("failure")
*     resume(Effect.fail("Uh oh!"))
*   } else {
*     count++
*     console.log("success")
*     resume(Effect.succeed("yay!"))
*   }
* })
*
* const policy = Schedule.addDelay(Schedule.recurs(2), () => Effect.succeed("100 millis"))
* const program = Effect.repeat(action, policy)
*
* // Effect.runPromiseExit(program).then(console.log)
*
* @since 2.0.0
* @category Repetition / Recursion
*/
var repeat = repeat$1;
/**
* Repeats an effect with a schedule, handling failures using a custom handler.
*
* **Details**
*
* This function allows you to execute an effect repeatedly based on a specified
* schedule. If the effect fails at any point, a custom failure handler is
* invoked. The handler is provided with both the failure value and the output
* of the schedule at the time of failure. If the effect fails immediately, the
* schedule will never be executed and the output provided to the handler will
* be `None`. This enables advanced error recovery or alternative fallback logic
* while maintaining flexibility in how repetitions are handled.
*
* For example, using a schedule with `recurs(2)` will allow for two additional
* repetitions after the initial execution, provided the effect succeeds. If a
* failure occurs during any iteration, the failure handler is invoked to handle
* the situation.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
* import * as Option from "effect/Option"
*
* let attempt = 0
* const task = Effect.gen(function*() {
*   attempt++
*   if (attempt <= 2) {
*     yield* Console.log(`Attempt ${attempt} failed`)
*     yield* Effect.fail(`Error ${attempt}`)
*   }
*   yield* Console.log(`Attempt ${attempt} succeeded`)
*   return "success"
* })
*
* const program = Effect.repeatOrElse(
*   task,
*   Schedule.recurs(3),
*   (error, attempts) =>
*     Console.log(
*       `Final failure: ${error}, after ${
*         Option.getOrElse(attempts, () => 0)
*       } attempts`
*     ).pipe(Effect.map(() => 0))
* )
* ```
*
* @since 2.0.0
* @category Repetition / Recursion
*/
var repeatOrElse = repeatOrElse$1;
/**
* Returns an array of `n` identical effects.
*
* Use with `Effect.all` to run the replicated effects and collect results.
*
* @since 2.0.0
* @category Collecting
*/
var replicate = replicate$1;
/**
* Performs this effect `n` times and collects results with `Effect.all` semantics.
*
* Use `concurrency` to control parallelism and `discard: true` to ignore results.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const results = yield* Effect.replicateEffect(3)(Effect.succeed(1))
*   yield* Console.log(results)
* })
* ```
*
* @since 2.0.0
* @category Collecting
*/
var replicateEffect = replicateEffect$1;
/**
* Repeats an effect based on a specified schedule.
*
* **Details**
*
* This function allows you to execute an effect repeatedly according to a given
* schedule. The schedule determines the timing and number of repetitions. Each
* repetition can also depend on the decision of the schedule, providing
* flexibility for complex workflows. This function does not modify the effect's
* success or failure; it only controls its repetition.
*
* For example, you can use a schedule that recurs a specific number of times,
* adds delays between repetitions, or customizes repetition behavior based on
* external inputs. The effect runs initially and is repeated according to the
* schedule.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* const task = Effect.gen(function*() {
*   yield* Console.log("Task executing...")
*   return Math.random()
* })
*
* // Repeat 3 times with 1 second delay between executions
* const program = Effect.schedule(
*   task,
*   Schedule.addDelay(Schedule.recurs(2), () => Effect.succeed("1 second"))
* )
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // Task executing... (immediate)
* // Task executing... (after 1 second)
* // Task executing... (after 1 second)
* // Returns the count from Schedule.recurs
* ```
*
* @see {@link scheduleFrom} for a variant that allows the schedule's decision
* to depend on the result of this effect.
*
* @since 2.0.0
* @category Repetition / Recursion
*/
var schedule = /*#__PURE__*/ dual(2, (self, schedule) => scheduleFrom(self, void 0, schedule));
/**
* Runs an effect repeatedly according to a schedule, starting from a specified
* initial input value.
*
* **Details**
*
* This function allows you to repeatedly execute an effect based on a schedule.
* The schedule starts with the given `initial` input value, which is passed to
* the first execution. Subsequent executions of the effect are controlled by
* the schedule's rules, using the output of the previous iteration as the input
* for the next one.
*
* The returned effect will complete when the schedule ends or the effect fails,
* propagating the error.
*
* @example
* ```ts
* import { Console, Effect, Schedule } from "effect"
*
* const task = (input: number) =>
*   Effect.gen(function*() {
*     yield* Console.log(`Processing: ${input}`)
*     return input + 1
*   })
*
* // Start with 0, repeat 3 times
* const program = Effect.scheduleFrom(
*   task(0),
*   0,
*   Schedule.recurs(2)
* )
*
* Effect.runPromise(program).then(console.log)
* // Returns the schedule count
* ```
*
* @since 2.0.0
* @category Repetition / Recursion
*/
var scheduleFrom = scheduleFrom$1;
/**
* Returns the current tracer from the context.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const currentTracer = yield* Effect.tracer
*   yield* Effect.log(`Using tracer: ${currentTracer}`)
*   return "operation completed"
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var tracer = tracer$1;
/**
* Provides a tracer to an effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.log("Using tracer")
*   return "completed"
* })
*
* // withTracer provides a tracer to the effect context
* // const traced = Effect.withTracer(program, customTracer)
* ```
*
* @since 2.0.0
* @category Tracing
*/
var withTracer = withTracer$1;
/**
* Disable the tracer for the given Effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* Effect.succeed(42).pipe(
*   Effect.withSpan("my-span"),
*   // the span will not be registered with the tracer
*   Effect.withTracerEnabled(false)
* )
* ```
*
* @since 2.0.0
* @category Tracing
*/
var withTracerEnabled = withTracerEnabled$1;
/**
* Enables or disables tracer timing for the given Effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* Effect.succeed(42).pipe(
*   Effect.withSpan("my-span"),
*   // the span will not have timing information
*   Effect.withTracerTiming(false)
* )
* ```
*
* @since 2.0.0
* @category Tracing
*/
var withTracerTiming = withTracerTiming$1;
/**
* Adds an annotation to each span in this effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.log("Doing some work...")
*   return "result"
* })
*
* // Add single annotation
* const annotated1 = Effect.annotateSpans(program, "user", "john")
*
* // Add multiple annotations
* const annotated2 = Effect.annotateSpans(program, {
*   operation: "data-processing",
*   version: "1.0.0",
*   environment: "production"
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var annotateSpans = annotateSpans$1;
/**
* Adds an annotation to the current span if available.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.annotateCurrentSpan("userId", "123")
*   yield* Effect.annotateCurrentSpan({
*     operation: "user-lookup",
*     timestamp: Date.now()
*   })
*   yield* Effect.log("User lookup completed")
*   return "success"
* })
*
* const traced = Effect.withSpan(program, "user-operation")
* ```
*
* @since 2.0.0
* @category Tracing
*/
var annotateCurrentSpan = annotateCurrentSpan$1;
/**
* Returns the current span from the context.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const span = yield* Effect.currentSpan
*   yield* Effect.log(`Current span: ${span}`)
*   return "done"
* })
*
* const traced = Effect.withSpan(program, "my-span")
* ```
*
* @since 2.0.0
* @category Tracing
*/
var currentSpan = currentSpan$1;
/**
* Returns the current parent span from the context.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const childOperation = Effect.gen(function*() {
*   const parentSpan = yield* Effect.currentParentSpan
*   yield* Effect.log(`Parent span: ${parentSpan}`)
*   return "child completed"
* })
*
* const program = Effect.gen(function*() {
*   yield* Effect.withSpan(childOperation, "child-span")
*   return "parent completed"
* })
*
* const traced = Effect.withSpan(program, "parent-span")
* ```
*
* @since 2.0.0
* @category Tracing
*/
var currentParentSpan = currentParentSpan$1;
/**
* Returns the annotations of the current span.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   // Add some annotations to the current span
*   yield* Effect.annotateCurrentSpan("userId", "123")
*   yield* Effect.annotateCurrentSpan("operation", "data-processing")
*
*   // Retrieve all annotations
*   const annotations = yield* Effect.spanAnnotations
*
*   console.log("Current span annotations:", annotations)
*   return annotations
* })
*
* Effect.runPromise(program).then(console.log)
* // Output: Current span annotations: { userId: "123", operation: "data-processing" }
* ```
*
* @since 2.0.0
* @category Tracing
*/
var spanAnnotations = spanAnnotations$1;
/**
* Retrieves the span links associated with the current span.
*
* Span links are connections between spans that are related but not in a
* parent-child relationship. They are useful for linking spans across different
* traces or connecting spans from parallel operations.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   // Get the current span links
*   const links = yield* Effect.spanLinks
*   console.log(`Current span has ${links.length} links`)
*   return links
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var spanLinks = spanLinks$1;
/**
* For all spans in this effect, add a link with the provided span.
*
* This is useful for connecting spans that are related but not in a direct
* parent-child relationship. For example, you might want to link spans from
* parallel operations or connect spans across different traces.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const parentEffect = Effect.withSpan("parent-operation")(
*   Effect.succeed("parent result")
* )
*
* const childEffect = Effect.withSpan("child-operation")(
*   Effect.succeed("child result")
* )
*
* // Link the child span to the parent span
* const program = Effect.gen(function*() {
*   const parentSpan = yield* Effect.currentSpan
*   const result = yield* childEffect.pipe(
*     Effect.linkSpans(parentSpan, { relationship: "follows" })
*   )
*   return result
* })
* ```
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // Link multiple spans
* const program = Effect.gen(function*() {
*   const span1 = yield* Effect.currentSpan
*   const span2 = yield* Effect.currentSpan
*
*   return yield* Effect.succeed("result").pipe(
*     Effect.linkSpans([span1, span2], {
*       type: "dependency",
*       source: "multiple-operations"
*     })
*   )
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var linkSpans = linkSpans$1;
/**
* Create a new span for tracing.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const span = yield* Effect.makeSpan("my-operation")
*   yield* Effect.log("Operation in progress")
*   return "completed"
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var makeSpan = makeSpan$1;
/**
* Create a new span for tracing, and automatically close it when the Scope
* finalizes.
*
* The span is not added to the current span stack, so no child spans will be
* created for it.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const span = yield* Effect.makeSpanScoped("scoped-operation")
*     yield* Effect.log("Working...")
*     return "done"
*     // Span automatically closes when scope ends
*   })
* )
* ```
*
* @since 2.0.0
* @category Tracing
*/
var makeSpanScoped = makeSpanScoped$1;
/**
* Create a new span for tracing, and automatically close it when the effect
* completes.
*
* The span is not added to the current span stack, so no child spans will be
* created for it.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.useSpan(
*   "user-operation",
*   (span) =>
*     Effect.gen(function*() {
*       yield* Effect.log("Processing user data")
*       return "success"
*     })
* )
* ```
*
* @since 2.0.0
* @category Tracing
*/
var useSpan = useSpan$1;
/**
* Wraps the effect with a new span for tracing.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const task = Effect.gen(function*() {
*   yield* Effect.log("Executing task")
*   return "result"
* })
*
* const traced = Effect.withSpan(task, "my-task", {
*   attributes: { version: "1.0" }
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var withSpan = withSpan$2;
/**
* Wraps the effect with a new span for tracing.
*
* The span is ended when the Scope is finalized.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const task = Effect.log("Working...")
*     yield* Effect.withSpanScoped(task, "scoped-task")
*     return "completed"
*   })
* )
* ```
*
* @since 2.0.0
* @category Tracing
*/
var withSpanScoped = withSpanScoped$1;
/**
* Adds the provided span to the current span stack.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const span = yield* Effect.makeSpan("parent-span")
*   const childTask = Effect.log("Child operation")
*   yield* Effect.withParentSpan(childTask, span)
*   return "completed"
* })
* ```
*
* @since 2.0.0
* @category Tracing
*/
var withParentSpan = withParentSpan$2;
/**
* Executes a request using the provided resolver.
*
* @since 2.0.0
* @category Requests & Batching
*
* @example
* ```ts
* import { Console, Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetUser extends Request.Request<string> {
*   readonly _tag: "GetUser"
*   readonly id: number
* }
* const GetUser = Request.tagged<GetUser>("GetUser")
*
* const resolver = RequestResolver.make<GetUser>(
*   Effect.fnUntraced(function*(entries) {
*     for (const entry of entries) {
*       yield* Request.complete(entry, Exit.succeed(`user-${entry.request.id}`))
*     }
*   })
* )
*
* const program = Effect.gen(function*() {
*   const name = yield* Effect.request(GetUser({ id: 1 }), Effect.succeed(resolver))
*   yield* Console.log(name)
* })
* ```
*/
var request = request$1;
/**
* Low-level entry point that registers a request with a resolver and delivers the exit value via `onExit`.
* Use this when you already have a `ServiceMap` and need to enqueue a request outside an `Effect`.
*
* It returns a canceler that removes the pending request entry.
*
* @since 4.0.0
* @category Requests & Batching
*/
var requestUnsafe = requestUnsafe$1;
/**
* Returns an effect that forks this effect into its own separate fiber,
* returning the fiber immediately, without waiting for it to begin executing
* the effect.
*
* You can use the `forkChild` method whenever you want to execute an effect in a
* new fiber, concurrently and without "blocking" the fiber executing other
* effects. Using fibers can be tricky, so instead of using this method
* directly, consider other higher-level methods, such as `raceWith`,
* `zipPar`, and so forth.
*
* The fiber returned by this method has methods to interrupt the fiber and to
* wait for it to finish executing the effect. See `Fiber` for more
* information.
*
* Whenever you use this method to launch a new fiber, the new fiber is
* attached to the parent fiber's scope. This means when the parent fiber
* terminates, the child fiber will be terminated as well, ensuring that no
* fibers leak. This behavior is called "auto supervision", and if this
* behavior is not desired, you may use the `forkDetach` or `forkIn` methods.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const longRunningTask = Effect.gen(function*() {
*   yield* Effect.sleep("2 seconds")
*   yield* Effect.log("Task completed")
*   return "result"
* })
*
* const program = Effect.gen(function*() {
*   const fiber = yield* longRunningTask.pipe(Effect.forkChild)
*
*   // or fork a fiber that starts immediately:
*   yield* longRunningTask.pipe(Effect.forkChild({ startImmediately: true }))
*
*   yield* Effect.log("Task forked, continuing...")
*   const result = yield* Fiber.join(fiber)
*   return result
* })
* ```
*
* @since 4.0.0
* @category Supervision & Fibers
*/
var forkChild = forkChild$1;
/**
* Forks the effect in the specified scope. The fiber will be interrupted
* when the scope is closed.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const task = Effect.gen(function*() {
*   yield* Effect.sleep("10 seconds")
*   return "completed"
* })
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const scope = yield* Effect.scope
*     const fiber = yield* Effect.forkIn(task, scope)
*     yield* Effect.sleep("1 second")
*     // Fiber will be interrupted when scope closes
*     return "done"
*   })
* )
* ```
*
* @since 2.0.0
* @category Supervision & Fibers
*/
var forkIn = forkIn$1;
/**
* Forks the fiber in a `Scope`, interrupting it when the scope is closed.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const backgroundTask = Effect.gen(function*() {
*   yield* Effect.sleep("5 seconds")
*   yield* Effect.log("Background task completed")
*   return "result"
* })
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const fiber = yield* backgroundTask.pipe(Effect.forkScoped)
*
*     // or fork a fiber that starts immediately:
*     yield* backgroundTask.pipe(Effect.forkScoped({ startImmediately: true }))
*
*     yield* Effect.log("Task forked in scope")
*     yield* Effect.sleep("1 second")
*
*     // Fiber will be interrupted when scope closes
*     return "scope completed"
*   })
* )
* ```
*
* @since 2.0.0
* @category Supervision & Fibers
*/
var forkScoped = forkScoped$1;
/**
* Forks the effect into a new fiber attached to the global scope. Because the
* new fiber is attached to the global scope, when the fiber executing the
* returned effect terminates, the forked fiber will continue running.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const daemonTask = Effect.gen(function*() {
*   while (true) {
*     yield* Effect.sleep("1 second")
*     yield* Effect.log("Daemon running...")
*   }
* })
*
* const program = Effect.gen(function*() {
*   const fiber = yield* daemonTask.pipe(Effect.forkDetach)
*
*   // or fork a fiber that starts immediately:
*   yield* daemonTask.pipe(Effect.forkDetach({ startImmediately: true }))
*
*   yield* Effect.log("Daemon started")
*   yield* Effect.sleep("3 seconds")
*   // Daemon continues running after this effect completes
*   return "main completed"
* })
* ```
*
* @since 2.0.0
* @category Supervision & Fibers
*/
var forkDetach = forkDetach$1;
/**
* Waits for all child fibers forked by this effect to complete before this
* effect completes.
*
* @since 2.0.0
* @category Supervision & Fibers
*/
var awaitAllChildren = awaitAllChildren$1;
/**
* Access the fiber currently executing the effect.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const fiber = yield* Effect.fiber
*   yield* Console.log(`Fiber id: ${fiber.id}`)
* })
* ```
*
* @since 4.0.0
* @category Supervision & Fibers
*/
var fiber = fiber$1;
/**
* Access the current fiber id executing the effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.log("event").pipe(
*   // Read the current span with the fiber id for tagging.
*   Effect.andThen(Effect.all([Effect.currentSpan, Effect.fiberId])),
*   Effect.withSpan("A"),
*   Effect.map(([span, fiberId]) => ({
*     spanName: span.name,
*     fiberId
*   }))
* )
* ```
*
* @since 4.0.0
* @category Supervision & Fibers
*/
var fiberId = fiberId$1;
/**
* The foundational function for running effects, returning a "fiber" that can
* be observed or interrupted.
*
* **When to Use**
*
* `runFork` is used to run an effect in the background by creating a
* fiber. It is the base function for all other run functions. It starts a fiber
* that can be observed or interrupted.
*
* Unless you specifically need a `Promise` or synchronous operation,
* `runFork` is a good default choice.
*
* @example
* ```ts
* // Title: Running an Effect in the Background
* import { Effect } from "effect"
* import { Schedule } from "effect"
* import { Fiber } from "effect"
* import { Console } from "effect"
*
* //      ┌─── Effect<number, never, never>
* //      ▼
* const program = Effect.repeat(
*   Console.log("running..."),
*   Schedule.spaced("200 millis")
* )
*
* //      ┌─── RuntimeFiber<number, never>
* //      ▼
* const fiber = Effect.runFork(program)
*
* setTimeout(() => {
*   Effect.runFork(Fiber.interrupt(fiber))
* }, 500)
* ```
*
* @since 2.0.0
* @category Running Effects
*/
var runFork = runFork$1;
/**
* Runs an effect in the background with the provided services.
*
* @example
* ```ts
* import { Effect, ServiceMap } from "effect"
*
* interface Logger {
*   log: (message: string) => void
* }
*
* const Logger = ServiceMap.Service<Logger>("Logger")
*
* const services = ServiceMap.make(Logger, {
*   log: (message) => console.log(message)
* })
*
* const program = Effect.gen(function*() {
*   const logger = yield* Logger
*   logger.log("Hello from service!")
*   return "done"
* })
*
* const fiber = Effect.runForkWith(services)(program)
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runForkWith = runForkWith$1;
/**
* Forks an effect with the provided services, registers `onExit` as a fiber observer, and returns an interruptor.
*
* The returned interruptor calls `fiber.interruptUnsafe`, optionally with an interruptor id.
*
* @example
* ```ts
* import { Console, Effect, Exit, ServiceMap } from "effect"
*
* interface Logger {
*   log: (message: string) => Effect.Effect<void>
* }
*
* const Logger = ServiceMap.Service<Logger>("Logger")
*
* const services = ServiceMap.make(Logger, {
*   log: (message) => Console.log(message)
* })
*
* const program = Effect.gen(function*() {
*   const logger = yield* Logger
*   yield* logger.log("Started")
*   return "done"
* })
*
* const interrupt = Effect.runCallbackWith(services)(program, {
*   onExit: (exit) => {
*     if (Exit.isFailure(exit)) {
*       // handle failure or interruption
*     }
*   }
* })
*
* // Use the interruptor if you need to cancel the fiber later.
* interrupt()
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runCallbackWith = runCallbackWith$1;
/**
* Runs an effect asynchronously, registering `onExit` as a fiber observer and
* returning an interruptor.
*
* The interruptor calls `fiber.interruptUnsafe` with the optional interruptor
* id.
*
* @example
* ```ts
* import { Console, Effect, Exit } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.log("working")
*   return "done"
* })
*
* const interrupt = Effect.runCallback(program, {
*   onExit: (exit) => {
*     Effect.runSync(
*       Exit.match(exit, {
*         onFailure: () => Console.log("failed"),
*         onSuccess: (value) => Console.log(`success: ${value}`)
*       })
*     )
*   }
* })
*
* // Output:
* // working
* // success: done
*
* // interrupt() to cancel the fiber if needed
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runCallback = runCallback$1;
/**
* Executes an effect and returns the result as a `Promise`.
*
* **When to Use**
*
* Use `runPromise` when you need to execute an effect and work with the
* result using `Promise` syntax, typically for compatibility with other
* promise-based code.
*
* If the effect succeeds, the promise will resolve with the result. If the
* effect fails, the promise will reject with an error.
*
* @see {@link runPromiseExit} for a version that returns an `Exit` type instead of rejecting.
*
* @example
* ```ts
* // Title: Running a Successful Effect as a Promise
* import { Effect } from "effect"
*
* Effect.runPromise(Effect.succeed(1)).then(console.log)
* // Output: 1
* ```
*
* @example
* //Example: Handling a Failing Effect as a Rejected Promise
* import { Effect } from "effect"
*
* Effect.runPromise(Effect.fail("my error")).catch(console.error)
* // Output:
* // (FiberFailure) Error: my error
*
* @since 2.0.0
* @category Running Effects
*/
var runPromise = runPromise$1;
/**
* Executes an effect as a Promise with the provided services.
*
* @example
* ```ts
* import { Effect, ServiceMap } from "effect"
*
* interface Config {
*   apiUrl: string
* }
*
* const Config = ServiceMap.Service<Config>("Config")
*
* const services = ServiceMap.make(Config, {
*   apiUrl: "https://api.example.com"
* })
*
* const program = Effect.gen(function*() {
*   const config = yield* Config
*   return `Connecting to ${config.apiUrl}`
* })
*
* Effect.runPromiseWith(services)(program).then(console.log)
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runPromiseWith = runPromiseWith$1;
/**
* Runs an effect and returns a `Promise` that resolves to an `Exit`, which
* represents the outcome (success or failure) of the effect.
*
* **When to Use**
*
* Use `runPromiseExit` when you need to determine if an effect succeeded
* or failed, including any defects, and you want to work with a `Promise`.
*
* **Details**
*
* The `Exit` type represents the result of the effect:
* - If the effect succeeds, the result is wrapped in a `Success`.
* - If it fails, the failure information is provided as a `Failure` containing
*   a `Cause` type.
*
* @example
* ```ts
* // Title: Handling Results as Exit
* import { Effect } from "effect"
*
* // Execute a successful effect and get the Exit result as a Promise
* Effect.runPromiseExit(Effect.succeed(1)).then(console.log)
* // Output:
* // {
* //   _id: "Exit",
* //   _tag: "Success",
* //   value: 1
* // }
*
* // Execute a failing effect and get the Exit result as a Promise
* Effect.runPromiseExit(Effect.fail("my error")).then(console.log)
* // Output:
* // {
* //   _id: "Exit",
* //   _tag: "Failure",
* //   cause: {
* //     _id: "Cause",
* //     _tag: "Fail",
* //     failure: "my error"
* //   }
* // }
* ```
*
* @since 2.0.0
* @category Running Effects
*/
var runPromiseExit = runPromiseExit$1;
/**
* Runs an effect and returns a Promise of Exit with provided services.
*
* @example
* ```ts
* import { Effect, Exit, ServiceMap } from "effect"
*
* interface Database {
*   query: (sql: string) => string
* }
*
* const Database = ServiceMap.Service<Database>("Database")
*
* const services = ServiceMap.make(Database, {
*   query: (sql) => `Result for: ${sql}`
* })
*
* const program = Effect.gen(function*() {
*   const db = yield* Database
*   return db.query("SELECT * FROM users")
* })
*
* Effect.runPromiseExitWith(services)(program).then((exit) => {
*   if (Exit.isSuccess(exit)) {
*     console.log("Success:", exit.value)
*   }
* })
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runPromiseExitWith = runPromiseExitWith$1;
/**
* Executes an effect synchronously, running it immediately and returning the
* result.
*
* **When to Use**
*
* Use `runSync` to run an effect that does not fail and does not include
* any asynchronous operations.
*
* If the effect fails or involves asynchronous work, it will throw an error,
* and execution will stop where the failure or async operation occurs.
*
* @see {@link runSyncExit} for a version that returns an `Exit` type instead of
* throwing an error.
*
* @example
* ```ts
* // Title: Synchronous Logging
* import { Effect } from "effect"
*
* const program = Effect.sync(() => {
*   console.log("Hello, World!")
*   return 1
* })
*
* const result = Effect.runSync(program)
* // Output: Hello, World!
*
* console.log(result)
* // Output: 1
* ```
*
* @example
* // Title: Incorrect Usage with Failing or Async Effects
* import { Effect } from "effect"
*
* try {
*   // Attempt to run an effect that fails
*   Effect.runSync(Effect.fail("my error"))
* } catch (e) {
*   console.error(e)
* }
* // Output:
* // (FiberFailure) Error: my error
*
* try {
*   // Attempt to run an effect that involves async work
*   Effect.runSync(Effect.promise(() => Promise.resolve(1)))
* } catch (e) {
*   console.error(e)
* }
* // Output:
* // (FiberFailure) AsyncFiberException: Fiber #0 cannot be resolved synchronously. This is caused by using runSync on an effect that performs async work
*
* @since 2.0.0
* @category Running Effects
*/
var runSync = runSync$1;
/**
* Executes an effect synchronously with provided services.
*
* @example
* ```ts
* import { Effect, ServiceMap } from "effect"
*
* interface MathService {
*   add: (a: number, b: number) => number
* }
*
* const MathService = ServiceMap.Service<MathService>("MathService")
*
* const services = ServiceMap.make(MathService, {
*   add: (a, b) => a + b
* })
*
* const program = Effect.gen(function*() {
*   const math = yield* MathService
*   return math.add(2, 3)
* })
*
* const result = Effect.runSyncWith(services)(program)
* console.log(result) // 5
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runSyncWith = runSyncWith$1;
/**
* Runs an effect synchronously and returns the result as an `Exit` type, which
* represents the outcome (success or failure) of the effect.
*
* **When to Use**
*
* Use `runSyncExit` to find out whether an effect succeeded or failed,
* including any defects, without dealing with asynchronous operations.
*
* **Details**
*
* The `Exit` type represents the result of the effect:
* - If the effect succeeds, the result is wrapped in a `Success`.
* - If it fails, the failure information is provided as a `Failure` containing
*   a `Cause` type.
*
* If the effect contains asynchronous operations, `runSyncExit` will
* return an `Failure` with a `Die` cause, indicating that the effect cannot be
* resolved synchronously.
*
* @example
* ```ts
* // Title: Handling Results as Exit
* import { Effect } from "effect"
*
* console.log(Effect.runSyncExit(Effect.succeed(1)))
* // Output:
* // {
* //   _id: "Exit",
* //   _tag: "Success",
* //   value: 1
* // }
*
* console.log(Effect.runSyncExit(Effect.fail("my error")))
* // Output:
* // {
* //   _id: "Exit",
* //   _tag: "Failure",
* //   cause: {
* //     _id: "Cause",
* //     _tag: "Fail",
* //     failure: "my error"
* //   }
* // }
* ```
*
* @example
* // Title: Asynchronous Operation Resulting in Die
* import { Effect } from "effect"
*
* console.log(Effect.runSyncExit(Effect.promise(() => Promise.resolve(1))))
* // Output:
* // {
* //   _id: 'Exit',
* //   _tag: 'Failure',
* //   cause: {
* //     _id: 'Cause',
* //     _tag: 'Die',
* //     defect: [Fiber #0 cannot be resolved synchronously. This is caused by using runSync on an effect that performs async work] {
* //       fiber: [FiberRuntime],
* //       _tag: 'AsyncFiberException',
* //       name: 'AsyncFiberException'
* //     }
* //   }
* // }
*
* @since 2.0.0
* @category Running Effects
*/
var runSyncExit = runSyncExit$1;
/**
* Runs an effect synchronously with provided services, returning an Exit result.
*
* @example
* ```ts
* import { Effect, Exit, ServiceMap } from "effect"
*
* // Define a logger service
* const Logger = ServiceMap.Service<{
*   log: (msg: string) => void
* }>("Logger")
*
* const program = Effect.gen(function*() {
*   const logger = yield* Effect.service(Logger)
*   logger.log("Computing result...")
*   return 42
* })
*
* // Prepare services
* const services = ServiceMap.make(Logger, {
*   log: (msg) => console.log(`[LOG] ${msg}`)
* })
*
* const exit = Effect.runSyncExitWith(services)(program)
*
* if (Exit.isSuccess(exit)) {
*   console.log(`Success: ${exit.value}`)
* } else {
*   console.log(`Failure: ${exit.cause}`)
* }
* // Output:
* // [LOG] Computing result...
* // Success: 42
* ```
*
* @since 4.0.0
* @category Running Effects
*/
var runSyncExitWith = runSyncExitWith$1;
/**
* Creates an Effect-returning function without tracing.
*
* `Effect.fnUntraced` also acts as a `pipe` function, so you can append transforms after the body.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const greet = Effect.fnUntraced(function* (name: string) {
*   yield* Console.log(`Hello, ${name}`)
*   return name.length
* })
*
* Effect.runFork(greet("Ada"))
* ```
*
* @since 3.12.0
* @category Function
*/
var fnUntraced = fnUntraced$1;
/**
* Creates a traced function with an optional span name and `SpanOptionsNoTrace` that adds spans and stack frames, plus pipeable post-processing that receives the Effect and the original arguments.
*
* Pipeable functions run after the body and can transform the resulting Effect.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* // Create a named span and post-process the returned Effect.
* const greet = Effect.fn("greet")(
*   function*(name: string) {
*     yield* Console.log(`Hello, ${name}`)
*     return name.length
*   },
*   Effect.map((length) => length + 1)
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* greet("Ada")
*   yield* Console.log(`Length: ${result}`)
* })
* ```
*
* @since 3.12.0
* @category Function
*/
var fn = fn$1;
/**
* Retrieves the `Clock` service from the context and provides it to the
* specified effectful function.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.clockWith((clock) =>
*   clock.currentTimeMillis.pipe(
*     Effect.map((currentTime) => `Current time is: ${currentTime}`),
*     Effect.tap(Console.log)
*   )
* )
*
* Effect.runFork(program)
* // Example Output:
* // Current time is: 1735484929744
* ```
*
* @since 2.0.0
* @category Clock
*/
var clockWith = clockWith$2;
/**
* Creates a logger function that logs at the specified level.
*
* If no level is provided, the logger uses the fiber's current log level and
* extracts any `Cause` values from the message list.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const logWarn = Effect.logWithLevel("Warn")
*
* const program = Effect.gen(function*() {
*   yield* logWarn("Cache miss", { key: "user:1" })
* })
* ```
*
* @since 2.0.0
* @category Logging
*/
var logWithLevel = logWithLevel$1;
/**
* Logs one or more messages using the default log level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.log("Starting computation")
*   const result = 2 + 2
*   yield* Effect.log("Result:", result)
*   yield* Effect.log("Multiple", "values", "can", "be", "logged")
*   return result
* })
*
* Effect.runPromise(program).then(console.log)
* // Output:
* // timestamp=2023-... level=INFO message="Starting computation"
* // timestamp=2023-... level=INFO message="Result: 4"
* // timestamp=2023-... level=INFO message="Multiple values can be logged"
* // 4
* ```
*
* @since 2.0.0
* @category Logging
*/
var log = /*#__PURE__*/ logWithLevel$1();
/**
* Logs one or more messages at the FATAL level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   try {
*     // Simulate a critical system failure
*     throw new Error("System memory exhausted")
*   } catch (error) {
*     const errorMessage = error instanceof Error ? error.message : String(error)
*     yield* Effect.logFatal("Critical system failure:", errorMessage)
*     yield* Effect.logFatal("System shutting down")
*   }
* })
*
* Effect.runPromise(program)
* // Output:
* // timestamp=2023-... level=FATAL message="Critical system failure: System memory exhausted"
* // timestamp=2023-... level=FATAL message="System shutting down"
* ```
*
* @since 2.0.0
* @category Logging
*/
var logFatal = /*#__PURE__*/ logWithLevel$1("Fatal");
/**
* Logs one or more messages at the WARNING level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.logWarning("API rate limit approaching")
*   yield* Effect.logWarning("Retries remaining:", 2, "Operation:", "fetchData")
*
*   // Useful for non-critical issues
*   const deprecated = true
*   if (deprecated) {
*     yield* Effect.logWarning("Using deprecated API endpoint")
*   }
* })
*
* Effect.runPromise(program)
* // Output:
* // timestamp=2023-... level=WARN message="API rate limit approaching"
* // timestamp=2023-... level=WARN message="Retries remaining: 2 Operation: fetchData"
* // timestamp=2023-... level=WARN message="Using deprecated API endpoint"
* ```
*
* @since 2.0.0
* @category Logging
*/
var logWarning = /*#__PURE__*/ logWithLevel$1("Warn");
/**
* Logs one or more messages at the ERROR level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.logError("Database connection failed")
*   yield* Effect.logError(
*     "Error code:",
*     500,
*     "Message:",
*     "Internal server error"
*   )
*
*   // Can be used with error objects
*   const error = new Error("Something went wrong")
*   yield* Effect.logError("Caught error:", error.message)
* })
*
* Effect.runPromise(program)
* // Output:
* // timestamp=2023-... level=ERROR message="Database connection failed"
* // timestamp=2023-... level=ERROR message="Error code: 500 Message: Internal server error"
* // timestamp=2023-... level=ERROR message="Caught error: Something went wrong"
* ```
*
* @since 2.0.0
* @category Logging
*/
var logError = /*#__PURE__*/ logWithLevel$1("Error");
/**
* Logs one or more messages at the INFO level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.logInfo("Application starting up")
*   yield* Effect.logInfo("Config loaded:", "production", "Port:", 3000)
*
*   // Useful for general information
*   const version = "1.2.3"
*   yield* Effect.logInfo("Application version:", version)
* })
*
* Effect.runPromise(program)
* // Output:
* // timestamp=2023-... level=INFO message="Application starting up"
* // timestamp=2023-... level=INFO message="Config loaded: production Port: 3000"
* // timestamp=2023-... level=INFO message="Application version: 1.2.3"
* ```
*
* @since 2.0.0
* @category Logging
*/
var logInfo = /*#__PURE__*/ logWithLevel$1("Info");
/**
* Logs one or more messages at the DEBUG level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.logDebug("Debug mode enabled")
*
*   const userInput = { name: "Alice", age: 30 }
*   yield* Effect.logDebug("Processing user input:", userInput)
*
*   // Useful for detailed diagnostic information
*   yield* Effect.logDebug("Variable state:", "x=10", "y=20", "z=30")
* })
*
* Effect.runPromise(program)
* // Output:
* // timestamp=2023-... level=DEBUG message="Debug mode enabled"
* // timestamp=2023-... level=DEBUG message="Processing user input: [object Object]"
* // timestamp=2023-... level=DEBUG message="Variable state: x=10 y=20 z=30"
* ```
*
* @since 2.0.0
* @category Logging
*/
var logDebug = /*#__PURE__*/ logWithLevel$1("Debug");
/**
* Logs one or more messages at the TRACE level.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.logTrace("Entering function processData")
*
*   // Trace detailed execution flow
*   for (let i = 0; i < 3; i++) {
*     yield* Effect.logTrace("Loop iteration:", i, "Processing item")
*   }
*
*   yield* Effect.logTrace("Exiting function processData")
* })
*
* Effect.runPromise(program)
* // Output:
* // timestamp=2023-... level=TRACE message="Entering function processData"
* // timestamp=2023-... level=TRACE message="Loop iteration: 0 Processing item"
* // timestamp=2023-... level=TRACE message="Loop iteration: 1 Processing item"
* // timestamp=2023-... level=TRACE message="Loop iteration: 2 Processing item"
* // timestamp=2023-... level=TRACE message="Exiting function processData"
* ```
*
* @since 2.0.0
* @category Logging
*/
var logTrace = /*#__PURE__*/ logWithLevel$1("Trace");
/**
* Adds a logger to the set of loggers which will output logs for this effect.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Create a custom logger that logs to the console
* const customLogger = Logger.make(({ message }) =>
*   Effect.sync(() => console.log(`[CUSTOM]: ${message}`))
* )
*
* const program = Effect.gen(function*() {
*   yield* Effect.log("This will go to both default and custom logger")
*   return "completed"
* })
*
* // Add the custom logger to the effect
* const programWithLogger = Effect.withLogger(program, customLogger)
*
* Effect.runPromise(programWithLogger)
* // Output includes both default and custom log outputs
* ```
*
* @since 2.0.0
* @category Logging
*/
var withLogger = /*#__PURE__*/ dual(2, (effect, logger) => updateService$2(effect, CurrentLoggers, (loggers) => /* @__PURE__ */ new Set([...loggers, logger])));
/**
* Adds an annotation to each log line in this effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.log("Starting operation")
*   yield* Effect.log("Processing data")
*   yield* Effect.log("Operation completed")
* })
*
* // Add annotations to all log messages
* const annotatedProgram = Effect.annotateLogs(program, {
*   userId: "user123",
*   operation: "data-processing"
* })
*
* // Also supports single key-value annotations
* const singleAnnotated = Effect.annotateLogs(program, "requestId", "req-456")
*
* Effect.runPromise(annotatedProgram)
* // All log messages will include the userId and operation annotations
* ```
*
* @since 2.0.0
* @category Logging
*/
var annotateLogs = /*#__PURE__*/ dual((args) => isEffect$1(args[0]), (effect, ...args) => updateService$2(effect, CurrentLogAnnotations, (annotations) => {
	const newAnnotations = { ...annotations };
	if (args.length === 1) Object.assign(newAnnotations, args[0]);
	else newAnnotations[args[0]] = args[1];
	return newAnnotations;
}));
/**
* Adds log annotations to the current scope.
*
* This differs from `annotateLogs`, which only annotates a specific effect.
* `annotateLogsScoped` updates annotations for the entire current `Scope` and
* restores the previous annotations when the scope closes.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     yield* Effect.log("before")
*     yield* Effect.annotateLogsScoped({ requestId: "req-123" })
*     yield* Effect.log("inside scope")
*   })
* )
*
* Effect.runPromise(program)
* ```
*
* @since 4.0.0
* @category Logging
*/
var annotateLogsScoped = annotateLogsScoped$1;
/**
* Adds a span to each log line in this effect.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const databaseOperation = Effect.gen(function*() {
*   yield* Effect.log("Connecting to database")
*   yield* Effect.log("Executing query")
*   yield* Effect.log("Processing results")
*   return "data"
* })
*
* const httpRequest = Effect.gen(function*() {
*   yield* Effect.log("Making HTTP request")
*   const data = yield* Effect.withLogSpan(databaseOperation, "db-operation")
*   yield* Effect.log("Sending response")
*   return data
* })
*
* const program = Effect.withLogSpan(httpRequest, "http-handler")
*
* Effect.runPromise(program)
* // All log messages will include span information showing the nested operation context
* ```
*
* @since 2.0.0
* @category Logging
*/
var withLogSpan = /*#__PURE__*/ dual(2, (effect, label) => flatMap$2(currentTimeMillis$1, (now) => updateService$2(effect, CurrentLogSpans, (spans) => {
	return [[label, now], ...spans];
})));
/**
* Updates the `Metric` every time the `Effect` is executed.
*
* Also accepts an optional function which can be used to map the `Exit` value
* of the `Effect` into a valid `Input` for the `Metric`.
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const counter = Metric.counter("effect_executions", {
*   description: "Counts effect executions"
* }).pipe(Metric.withConstantInput(1))
*
* const program = Effect.succeed("Hello").pipe(
*   Effect.track(counter)
* )
*
* // This will increment the counter by 1 when executed
* Effect.runPromise(program).then(() =>
*   Effect.runPromise(Metric.value(counter)).then(console.log)
*   // Output: { count: 1, incremental: false }
* )
* ```
*
* @example
* ```ts
* import { Effect, Exit, Metric } from "effect"
*
* // Track different exit types with custom mapping
* const exitTracker = Metric.frequency("exit_types", {
*   description: "Tracks success/failure/defect counts"
* })
*
* const mapExitToString = (exit: Exit.Exit<string, Error>) => {
*   if (Exit.isSuccess(exit)) return "success"
*   if (Exit.isFailure(exit)) return "failure"
*   return "defect"
* }
*
* const effect = Effect.succeed("result").pipe(
*   Effect.track(exitTracker, mapExitToString)
* )
* ```
*
* @since 4.0.0
* @category Tracking
*/
var track = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, metric, f) => onExit(self, (exit) => {
	return update(metric, f === void 0 ? exit : internalCall(() => f(exit)));
}));
/**
* Updates the provided `Metric` every time the wrapped `Effect` succeeds with
* a value.
*
* Also accepts an optional function which can be used to map the success value
* of the `Effect` into a valid `Input` for the `Metric`.
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const successCounter = Metric.counter("successes").pipe(
*   Metric.withConstantInput(1)
* )
*
* const program = Effect.succeed(42).pipe(
*   Effect.trackSuccesses(successCounter)
* )
*
* Effect.runPromise(program).then(() =>
*   Effect.runPromise(Metric.value(successCounter)).then(console.log)
*   // Output: { count: 1, incremental: false }
* )
* ```
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* // Track successful request sizes
* const requestSizeGauge = Metric.gauge("request_size_bytes")
*
* const program = Effect.succeed("Hello World!").pipe(
*   Effect.trackSuccesses(requestSizeGauge, (value: string) => value.length)
* )
*
* Effect.runPromise(program).then(() =>
*   Effect.runPromise(Metric.value(requestSizeGauge)).then(console.log)
*   // Output: { value: 12 }
* )
* ```
*
* @since 4.0.0
* @category Tracking
*/
var trackSuccesses = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, metric, f) => tap(self, (value) => {
	return update(metric, f === void 0 ? value : f(value));
}));
/**
* Updates the provided `Metric` every time the wrapped `Effect` fails with an
* **expected** error.
*
* Also accepts an optional function which can be used to map the error value
* of the `Effect` into a valid `Input` for the `Metric`.
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const errorCounter = Metric.counter("errors").pipe(
*   Metric.withConstantInput(1)
* )
*
* const program = Effect.fail("Network timeout").pipe(
*   Effect.trackErrors(errorCounter)
* )
*
* Effect.runPromiseExit(program).then(() =>
*   Effect.runPromise(Metric.value(errorCounter)).then(console.log)
*   // Output: { count: 1, incremental: false }
* )
* ```
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* // Track error types using frequency metric
* const errorTypeFrequency = Metric.frequency("error_types")
*
* const program = Effect.fail(new Error("Connection failed")).pipe(
*   Effect.trackErrors(errorTypeFrequency, (error: Error) => error.name)
* )
*
* Effect.runPromiseExit(program).then(() =>
*   Effect.runPromise(Metric.value(errorTypeFrequency)).then(console.log)
*   // Output: { occurrences: Map(1) { "Error" => 1 } }
* )
* ```
*
* @since 4.0.0
* @category Tracking
*/
var trackErrors = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, metric, f) => tapError(self, (error) => {
	return update(metric, f === void 0 ? error : internalCall(() => f(error)));
}));
/**
* Updates the provided `Metric` every time the wrapped `Effect` fails with an
* **unexpected** error (i.e. a defect).
*
* Also accepts an optional function which can be used to map the defect value
* of the `Effect` into a valid `Input` for the `Metric`.
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const defectCounter = Metric.counter("defects").pipe(
*   Metric.withConstantInput(1)
* )
*
* const program = Effect.die("Critical system failure").pipe(
*   Effect.trackDefects(defectCounter)
* )
*
* Effect.runPromiseExit(program).then(() =>
*   Effect.runPromise(Metric.value(defectCounter)).then(console.log)
*   // Output: { count: 1, incremental: false }
* )
* ```
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* // Track defect types using frequency metric
* const defectTypeFrequency = Metric.frequency("defect_types")
*
* const program = Effect.die(new Error("Null pointer exception")).pipe(
*   Effect.trackDefects(defectTypeFrequency, (defect: unknown) => {
*     if (defect instanceof Error) return defect.constructor.name
*     return typeof defect
*   })
* )
*
* Effect.runPromiseExit(program).then(() =>
*   Effect.runPromise(Metric.value(defectTypeFrequency)).then(console.log)
*   // Output: { occurrences: Map(1) { "Error" => 1 } }
* )
* ```
*
* @since 4.0.0
* @category Tracking
*/
var trackDefects = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, metric, f) => tapDefect(self, (defect) => {
	return update(metric, f === void 0 ? defect : internalCall(() => f(defect)));
}));
/**
* Updates the provided `Metric` with the `Duration` of time (in nanoseconds)
* that the wrapped `Effect` took to complete.
*
* Also accepts an optional function which can be used to map the `Duration`
* that the wrapped `Effect` took to complete into a valid `Input` for the
* `Metric`.
*
* @example
* ```ts
* import { Effect, Metric } from "effect"
*
* const executionTimer = Metric.timer("execution_time")
*
* const program = Effect.sleep("100 millis").pipe(
*   Effect.trackDuration(executionTimer)
* )
*
* Effect.runPromise(program).then(() =>
*   Effect.runPromise(Metric.value(executionTimer)).then(console.log)
*   // Output: { count: 1, min: 100000000, max: 100000000, sum: 100000000 }
* )
* ```
*
* @example
* ```ts
* import { Duration, Effect, Metric } from "effect"
*
* // Track execution time in milliseconds using custom mapping
* const durationGauge = Metric.gauge("execution_millis")
*
* const program = Effect.sleep("200 millis").pipe(
*   Effect.trackDuration(durationGauge, (duration) => Duration.toMillis(duration))
* )
*
* Effect.runPromise(program).then(() =>
*   Effect.runPromise(Metric.value(durationGauge)).then(console.log)
*   // Output: { value: 200 }
* )
* ```
*
* @since 4.0.0
* @category Tracking
*/
var trackDuration = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, metric, f) => clockWith((clock) => {
	const startTime = clock.currentTimeNanosUnsafe();
	return onExit(self, () => {
		const duration = subtract$2(fromInputUnsafe(clock.currentTimeNanosUnsafe()), fromInputUnsafe(startTime));
		return update(metric, f === void 0 ? duration : internalCall(() => f(duration)));
	});
}));
/**
* Service that holds the current transaction state, it includes
*
* - a journal that stores any non committed change to TxRef values
* - a retry flag to know if the transaction should be retried
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // Transaction class for software transactional memory operations
* const txEffect = Effect.gen(function*() {
*   const tx = yield* Effect.Transaction
*   // Use transaction for coordinated state changes
*   return "Transaction complete"
* })
* ```
*
* @since 4.0.0
* @category Transactions
*/
var Transaction = class extends Service()("effect/Effect/Transaction") {};
/**
* Accesses the current transaction state within an active transaction.
*
* This function requires `Transaction` in the context and does NOT create or strip
* transaction boundaries. Use it to interact with the transaction journal (e.g. in
* `TxRef` internals). To define a transaction boundary, use {@link transaction}.
*
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* Effect.transaction(TxRef.make(0))
*
*   yield* Effect.transaction(Effect.gen(function*() {
*     yield* TxRef.set(ref, 42)
*     return yield* TxRef.get(ref)
*   }))
* })
* ```
*
* @since 4.0.0
* @category Transactions
*/
var withTxState = (f) => flatMap(Transaction.asEffect(), (state) => internalCall(() => f(state)));
/**
* Defines a transaction boundary. Transactions are "all or nothing" with respect to changes
* made to transactional values (i.e. TxRef) that occur within the transaction body.
*
* In Effect transactions are optimistic with retry, that means transactions are retried when:
*
* - the body of the transaction explicitely calls to `Effect.retryTransaction` and any of the
*   accessed transactional values changes.
*
* - any of the accessed transactional values change during the execution of the transaction
*   due to a different transaction committing before the current.
*
* Each call to `transaction` always creates a new isolated transaction boundary with its own
* journal and retry logic.
*
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref1 = yield* Effect.transaction(TxRef.make(0))
*   const ref2 = yield* Effect.transaction(TxRef.make(0))
*
*   // All operations within transaction block succeed or fail together
*   yield* Effect.transaction(Effect.gen(function*() {
*     yield* TxRef.set(ref1, 10)
*     yield* TxRef.set(ref2, 20)
*     const sum = (yield* TxRef.get(ref1)) + (yield* TxRef.get(ref2))
*     console.log(`Transaction sum: ${sum}`)
*   }))
*
*   console.log(`Final ref1: ${yield* Effect.transaction(TxRef.get(ref1))}`) // 10
*   console.log(`Final ref2: ${yield* Effect.transaction(TxRef.get(ref2))}`) // 20
* })
* ```
*
* @since 4.0.0
* @category Transactions
*/
var transaction = (effect) => transactionWith(() => effect);
/**
* Like {@link transaction} but provides access to the transaction state.
*
* Always creates a new isolated transaction boundary with its own journal and retry logic.
*
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.transactionWith((_txState) =>
*   Effect.gen(function*() {
*     const ref = yield* TxRef.make(0)
*     yield* TxRef.set(ref, 42)
*     return yield* TxRef.get(ref)
*   })
* )
* ```
*
* @since 4.0.0
* @category Transactions
*/
var transactionWith = (f) => withFiber((fiber) => {
	const state = {
		journal: /* @__PURE__ */ new Map(),
		retry: false
	};
	const scheduler = fiber.currentScheduler;
	let result;
	return uninterruptibleMask((restore) => flatMap(whileLoop({
		while: () => !result,
		body: constant(restore(suspend(() => f(state))).pipe(provideService(Transaction, state), tapCause(() => {
			if (!state.retry) return void_;
			return restore(awaitPendingTransaction(state));
		}), exit)),
		step(exit) {
			if (state.retry || !isTransactionConsistent(state)) return clearTransaction(state);
			if (isSuccess$1(exit)) commitTransaction(scheduler, state);
			else clearTransaction(state);
			result = exit;
		}
	}), () => result));
});
var isTransactionConsistent = (state) => {
	for (const [ref, { version }] of state.journal) if (ref.version !== version) return false;
	return true;
};
var awaitPendingTransaction = (state) => suspend(() => {
	const key = {};
	const refs = Array.from(state.journal.keys());
	const clearPending = () => {
		for (const clear of refs) clear.pending.delete(key);
	};
	return callback((resume) => {
		const onCall = () => {
			clearPending();
			resume(void_);
		};
		for (const ref of refs) ref.pending.set(key, onCall);
		return sync(clearPending);
	});
});
function commitTransaction(scheduler, state) {
	for (const [ref, { value }] of state.journal) {
		if (value !== ref.value) {
			ref.version = ref.version + 1;
			ref.value = value;
		}
		for (const pending of ref.pending.values()) scheduler.scheduleTask(pending, 0);
		ref.pending.clear();
	}
}
function clearTransaction(state) {
	state.retry = false;
	state.journal.clear();
}
/**
* Signals that the current transaction needs to be retried.
*
* NOTE: the transaction retries on any change to transactional values (i.e. TxRef) accessed in its body.
*
* @since 4.0.0
* @category Transactions
*
* @example
*
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   // create a transactional reference
*   const ref = yield* Effect.transaction(TxRef.make(0))
*
*   // forks a fiber that increases the value of `ref` every 100 millis
*   yield* Effect.forkChild(Effect.forever(
*     // update to transactional value
*     Effect.transaction(TxRef.update(ref, (n) => n + 1)).pipe(Effect.delay("100 millis"))
*   ))
*
*   // the following will retry 10 times until the `ref` value is 10
*   yield* Effect.transaction(Effect.gen(function*() {
*     const value = yield* TxRef.get(ref)
*     if (value < 10) {
*       yield* Effect.log(`retry due to value: ${value}`)
*       return yield* Effect.retryTransaction
*     }
*     yield* Effect.log(`transaction done with value: ${value}`)
*   }))
* })
*
* Effect.runPromise(program).catch(console.error)
* ```
*/
var retryTransaction = /*#__PURE__*/ flatMap(/*#__PURE__*/ Transaction.asEffect(), (state) => {
	state.retry = true;
	return interrupt;
});
/**
* Converts a callback-based function to a function that returns an `Effect`.
*
* @example Basic Usage
* ```ts
* import { Effect } from "effect"
* import * as fs from "fs"
*
* // Convert Node.js readFile to an Effect
* const readFile = Effect.effectify(fs.readFile)
*
* // Use the effectified function
* const program = readFile("package.json", "utf8")
*
* Effect.runPromise(program).then(console.log)
* // Output: contents of package.json
* ```
*
* @example Custom Error Handling
* ```ts
* import { Effect } from "effect"
* import * as fs from "fs"
*
* const readFile = Effect.effectify(
*   fs.readFile,
*   (error, args) => new Error(`Failed to read file ${args[0]}: ${error.message}`)
* )
*
* const program = readFile("nonexistent.txt", "utf8")
*
* Effect.runPromiseExit(program).then(console.log)
* // Output: Exit.failure with custom error message
* ```
*
* @since 4.0.0
* @category Effectify
*/
var effectify = (fn, onError, onSyncError) => (...args) => callback((resume) => {
	try {
		fn(...args, (err, result) => {
			if (err) resume(fail(onError ? onError(err, args) : err));
			else resume(succeed(result));
		});
	} catch (err) {
		resume(onSyncError ? fail(onSyncError(err, args)) : die(err));
	}
});
/**
* Ensures that an effect's success type extends a given type `A`.
*
* This function provides compile-time type checking to ensure that the success
* value of an effect conforms to a specific type constraint.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // Define a constraint that the success type must be a number
* const satisfiesNumber = Effect.satisfiesSuccessType<number>()
*
* // This works - Effect<42, never, never> extends Effect<number, never, never>
* const validEffect = satisfiesNumber(Effect.succeed(42))
*
* // This would cause a TypeScript compilation error:
* // const invalidEffect = satisfiesNumber(Effect.succeed("string"))
* //                                      ^^^^^^^^^^^^^^^^^^^^^^
* // Type 'string' is not assignable to type 'number'
* ```
*
* @since 4.0.0
* @category Type Constraints
*/
var satisfiesSuccessType = () => (effect) => effect;
/**
* Ensures that an effect's error type extends a given type `E`.
*
* This function provides compile-time type checking to ensure that the error
* type of an effect conforms to a specific type constraint.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // Define a constraint that the error type must be an Error
* const satisfiesError = Effect.satisfiesErrorType<Error>()
*
* // This works - Effect<number, TypeError, never> extends Effect<number, Error, never>
* const validEffect = satisfiesError(Effect.fail(new TypeError("Invalid type")))
*
* // This would cause a TypeScript compilation error:
* // const invalidEffect = satisfiesError(Effect.fail("string error"))
* //                                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^
* // Type 'string' is not assignable to type 'Error'
* ```
*
* @since 4.0.0
* @category Type Constraints
*/
var satisfiesErrorType = () => (effect) => effect;
/**
* Ensures that an effect's requirements type extends a given type `R`.
*
* This function provides compile-time type checking to ensure that the
* requirements (context) type of an effect conforms to a specific type constraint.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // Define a constraint that requires a string as the requirements type
* const satisfiesStringServices = Effect.satisfiesServicesType<string>()
*
* // This works - effect requires string
* const validEffect: Effect.Effect<number, never, "config"> = Effect.succeed(42)
* const constrainedEffect = satisfiesStringServices(validEffect)
*
* // This would cause a TypeScript compilation error if uncommented:
* // const invalidEffect: Effect.Effect<number, never, number> = Effect.succeed(42)
* // const constrainedInvalid = satisfiesStringServices(invalidEffect)
* ```
*
* @since 4.0.0
* @category Type Constraints
*/
var satisfiesServicesType = () => (effect) => effect;
/**
* An optimized version of `map` that checks if an effect is already resolved
* and applies the mapping function eagerly when possible.
*
* **When to Use**
*
* `mapEager` provides better performance for effects that are already resolved
* by applying the transformation immediately instead of deferring it through
* the effect pipeline.
*
* **Behavior**
*
* - For **Success effects**: Applies the mapping function immediately to the value
* - For **Failure effects**: Returns the failure as-is without applying the mapping
* - For **Pending effects**: Falls back to the regular `map` behavior
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // For resolved effects, the mapping is applied immediately
* const resolved = Effect.succeed(5)
* const mapped = Effect.mapEager(resolved, (n) => n * 2) // Applied eagerly
*
* // For pending effects, behaves like regular map
* const pending = Effect.delay(Effect.succeed(5), "100 millis")
* const mappedPending = Effect.mapEager(pending, (n) => n * 2) // Uses regular map
* ```
*
* @since 4.0.0
* @category Eager
*/
var mapEager = mapEager$1;
/**
* An optimized version of `mapError` that checks if an effect is already resolved
* and applies the error mapping function eagerly when possible.
*
* **When to Use**
*
* `mapErrorEager` provides better performance for effects that are already resolved
* by applying the error transformation immediately instead of deferring it through
* the effect pipeline.
*
* **Behavior**
*
* - For **Success effects**: Returns the success as-is (no error to transform)
* - For **Failure effects**: Applies the mapping function immediately to the error
* - For **Pending effects**: Falls back to the regular `mapError` behavior
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // For resolved failure effects, the error mapping is applied immediately
* const failed = Effect.fail("original error")
* const mapped = Effect.mapErrorEager(failed, (err: string) => `mapped: ${err}`) // Applied eagerly
*
* // For pending effects, behaves like regular mapError
* const pending = Effect.delay(Effect.fail("error"), "100 millis")
* const mappedPending = Effect.mapErrorEager(
*   pending,
*   (err: string) => `mapped: ${err}`
* ) // Uses regular mapError
* ```
*
* @since 4.0.0
* @category Eager
*/
var mapErrorEager = mapErrorEager$1;
/**
* An optimized version of `mapBoth` that checks if an effect is already resolved
* and applies the appropriate mapping function eagerly when possible.
*
* **When to Use**
*
* `mapBothEager` provides better performance for effects that are already resolved
* by applying the transformation immediately instead of deferring it through
* the effect pipeline.
*
* **Behavior**
*
* - For **Success effects**: Applies the `onSuccess` function immediately to the value
* - For **Failure effects**: Applies the `onFailure` function immediately to the error
* - For **Pending effects**: Falls back to the regular `mapBoth` behavior
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // For resolved effects, the appropriate mapping is applied immediately
* const success = Effect.succeed(5)
* const mapped = Effect.mapBothEager(success, {
*   onFailure: (err: string) => `Failed: ${err}`,
*   onSuccess: (n: number) => n * 2
* }) // onSuccess applied eagerly
*
* const failure = Effect.fail("error")
* const mappedError = Effect.mapBothEager(failure, {
*   onFailure: (err: string) => `Failed: ${err}`,
*   onSuccess: (n: number) => n * 2
* }) // onFailure applied eagerly
* ```
*
* @since 4.0.0
* @category Eager
*/
var mapBothEager = mapBothEager$1;
/**
* An optimized version of `flatMap` that checks if an effect is already resolved
* and applies the flatMap function eagerly when possible.
*
* **When to Use**
*
* `flatMapEager` provides better performance for effects that are already resolved
* by applying the transformation immediately instead of deferring it through
* the effect pipeline.
*
* **Behavior**
*
* - For **Success effects**: Applies the flatMap function immediately to the value
* - For **Failure effects**: Returns the failure as-is without applying the flatMap
* - For **Pending effects**: Falls back to the regular `flatMap` behavior
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // For resolved effects, the flatMap is applied immediately
* const resolved = Effect.succeed(5)
* const flatMapped = Effect.flatMapEager(resolved, (n) => Effect.succeed(n * 2)) // Applied eagerly
*
* // For pending effects, behaves like regular flatMap
* const pending = Effect.delay(Effect.succeed(5), "100 millis")
* const flatMappedPending = Effect.flatMapEager(
*   pending,
*   (n) => Effect.succeed(n * 2)
* ) // Uses regular flatMap
* ```
*
* @since 4.0.0
* @category Eager
*/
var flatMapEager = flatMapEager$1;
/**
* An optimized version of `catch` that checks if an effect is already resolved
* and applies the catch function eagerly when possible.
*
* **When to Use**
*
* `catchEager` provides better performance for effects that are already resolved
* by applying the error recovery immediately instead of deferring it through
* the effect pipeline.
*
* **Behavior**
*
* - For **Success effects**: Returns the success as-is (no error to catch)
* - For **Failure effects**: Applies the catch function immediately to the error
* - For **Pending effects**: Falls back to the regular `catch` behavior
*
* @example
* ```ts
* import { Effect } from "effect"
*
* // For resolved failure effects, the catch function is applied immediately
* const failed = Effect.fail("original error")
* const recovered = Effect.catchEager(
*   failed,
*   (err: string) => Effect.succeed(`recovered from: ${err}`)
* ) // Applied eagerly
*
* // For success effects, returns success as-is
* const success = Effect.succeed(42)
* const unchanged = Effect.catchEager(
*   success,
*   (err: string) => Effect.succeed(`recovered from: ${err}`)
* ) // Returns success as-is
*
* // For pending effects, behaves like regular catch
* const pending = Effect.delay(Effect.fail("error"), "100 millis")
* const recoveredPending = Effect.catchEager(
*   pending,
*   (err: string) => Effect.succeed(`recovered from: ${err}`)
* ) // Uses regular catch
* ```
*
* @since 4.0.0
* @category Eager
*/
var catchEager = catchEager$1;
/**
* Creates untraced function effects with eager evaluation optimization.
*
* Executes generator functions eagerly when all yielded effects are synchronous,
* stopping at the first async effect and deferring to normal execution.
*
* @example
* ```ts
* import { Effect } from "effect"
*
* const computation = Effect.fnUntracedEager(function*() {
*   yield* Effect.succeed(1)
*   yield* Effect.succeed(2)
*   return "computed eagerly"
* })
*
* const effect = computation() // Executed immediately if all effects are sync
* ```
*
* @since 4.0.0
* @category Eager
*/
var fnUntracedEager = fnUntracedEager$1;
//#endregion
export { filterMap as $, toParts as $a, servicesWith$1 as $c, format as $i, negativeInfinity as $l, scheduleFrom as $n, into as $o, withParentSpan as $r, as$1 as $s, matchCauseEager as $t, empty$5 as $u, catchIf as A, mapEpochMillis as Aa, forkUnsafe$1 as Ac, String_exports as Ai, empty$3 as Al, request as An, provide$2 as Ao, trackErrors as Ar, hasInterruptsOnly as As, isEffect as At, isReadonlyArrayNonEmpty as Au, delay as B, removeTime as Ba, loggerMake as Bc, Number_exports as Bi, compose$1 as Bl, runPromise as Bn, close as Bo, updateService as Br, pretty as Bs, logTrace as Bt, of$1 as Bu, callback as C, isUtc as Ca, fiberJoin as Cc, catchDone as Ci, externalSpan as Cl, raceAll as Cn, Layer_exports as Co, timeout as Cr, fail$4 as Cs, fromYieldable as Ct, findLastIndex as Cu, catchDefect as D, makeZoned as Da, fnUntraced$1 as Dc, isDoneCause as Di, Service as Dl, repeatOrElse as Dn, effectDiscard as Do, track as Dr, hasDies$1 as Ds, interrupt as Dt, intersection as Du, catchCauseIf as E, makeUnsafe as Ea, flatMap$2 as Ec, filterNoDone as Ei, Reference as El, repeat as En, effect as Eo, tracer as Er, fromReasons as Es, ignoreCause as Et, getUnsafe$1 as Eu, catchTags as F, mutateUtc as Fa, ignore$1 as Fc, snakeToCamel as Fi, make$6 as Fl, retryTransaction as Fn, unwrap as Fo, try_ as Fr, isReason as Fs, log as Ft, makeEquivalence as Fu, exit as G, setZoneNamedUnsafe as Ga, map$4 as Gc, Equivalence$3 as Gi, fromInput as Gl, runSyncExit as Gn, makeUnsafe$1 as Go, when as Gr, CurrentLoggers as Gs, map as Gt, remove as Gu, effectify as H, setPartsUtc as Ha, makeLatchUnsafe as Hc, ReducerMin as Hi, toPredicate as Hl, runPromiseExitWith as Hn, fork as Ho, useSpan as Hr, ClockRef as Hs, logWithLevel as Ht, range as Hu, catch_ as I, nearest as Ia, interrupt$4 as Ic, toLowerCase as Ii, makeUnsafe$3 as Il, runCallback as In, Scope as Io, undefined_ as Ir, makeDieReason as Is, logDebug as It, makeReducerConcat as Iu, failCauseSync as J, subtract$1 as Ja, provideService$1 as Jc, addDuration as Ji, isDuration as Jl, sandbox as Jn, _await as Jo, withErrorReporting as Jr, LogToStderr as Js, mapEager as Jt, sort as Ju, fail as K, setZoneOffset as Ka, matchCauseEffect$1 as Kc, Order$2 as Ki, fromInputUnsafe as Kl, runSyncExitWith as Kn, provide$3 as Ko, whileLoop as Kr, FiberTypeId as Ks, mapBoth as Kt, reverse as Ku, clockWith as L, now as La, interruptChildrenPatch as Lc, toUpperCase as Li, merge$2 as Ll, runCallbackWith as Ln, Scope_exports as Lo, uninterruptible as Lr, makeFailReason as Ls, logError as Lt, map$6 as Lu, catchReason as M, max$1 as Ma, formatLogSpan as Mc, capitalize as Mi, getOption as Ml, result as Mn, succeed$2 as Mo, transaction as Mr, interruptors as Ms, isSuccess as Mt, last as Mu, catchReasons as N, min$1 as Na, gen$1 as Nc, constantCase as Ni, getUnsafe as Nl, retry as Nn, succeedServices as No, transactionWith as Nr, isCause as Ns, let_ as Nt, lastNonEmpty as Nu, catchEager as O, makeZonedFromString as Oa, forever$2 as Oc, Random as Oi, ServiceMap_exports as Ol, replicate as On, effectServices as Oo, trackDefects as Or, hasFails$1 as Os, interruptible as Ot, isArray as Ou, catchTag as P, mutate as Pa, getCurrentFiber as Pc, isString as Pi, isServiceMap as Pl, retryOrElse as Pn, sync$1 as Po, tryPromise as Pr, isDone$1 as Ps, linkSpans as Pt, makeBy as Pu, filter as Q, toEpochMillis as Qa, scopeAddFinalizerExit as Qc, endOf as Qi, nanos as Ql, schedule as Qn, interruptWith as Qo, withLogger as Qr, andThen$2 as Qs, matchCause as Qt, Iterable_exports as Qu, currentParentSpan as R, nowAsDate as Ra, isLogLevelGreaterThan as Rc, trim as Ri, omit as Rl, runFork as Rn, addFinalizer$1 as Ro, uninterruptibleMask as Rr, makeInterruptReason as Rs, logFatal as Rt, mapAccum as Ru, cachedWithTTL as S, isTimeZoneOffset as Sa, fiberInterruptAs as Sc, Pull_exports as Si, Tracer_exports as Sl, race as Sn, CurrentMemoMap as So, timed as Sr, done$1 as Ss, fromResult as St, findLast as Su, catchCauseFilter as T, make$1 as Ta, fiberRunIn as Tc, filterDone as Ti, Scheduler_exports as Tl, raceFirst as Tn, buildWithScope as To, timeoutOrElse as Tr, findError$1 as Ts, ignore as Tt, getSomes as Tu, ensuring as U, setZone as Ua, makeSemaphore as Uc, nextPow2 as Ui, Duration_exports as Ul, runPromiseWith as Un, forkUnsafe as Uo, validate as Ur, ConsoleRef as Us, makeSpan as Ut, reduce$1 as Uu, die as V, setParts as Va, makeLatch as Vc, ReducerMax as Vi, has as Vl, runPromiseExit as Vn, closeUnsafe as Vo, updateServices as Vr, squash as Vs, logWarning as Vt, partition$2 as Vu, eventually as W, setZoneNamed as Wa, makeSemaphoreUnsafe as Wc, remainder as Wi, Equivalence$4 as Wl, runSync as Wn, make$3 as Wo, void_ as Wr, CurrentErrorReporters as Ws, makeSpanScoped as Wt, reduceRight as Wu, fiber as X, toDate as Xa, reportCauseUnsafe as Xc, clamp$1 as Xi, isZero as Xl, satisfiesServicesType as Xn, doneUnsafe as Xo, withFiber as Xr, acquireUseRelease$1 as Xs, mapErrorEager as Xt, unzip as Xu, failSync as Y, subtractDuration as Ya, race$1 as Yc, between$1 as Yi, isFinite as Yl, satisfiesErrorType as Yn, done as Yo, withExecutionPlan as Yr, acquireRelease$1 as Ys, mapError as Yt, union as Yu, fiberId as Z, toDateUtc as Za, scope$1 as Zc, distance as Zi, millis as Zl, satisfiesSuccessType as Zn, fail$2 as Zo, withLogSpan as Zr, addFinalizer$2 as Zs, match as Zt, zipWith$3 as Zu, awaitAllChildren as _, isLessThanOrEqualTo$1 as _a, fiberAwait as _c, exponential as _i, MinimumLogLevel as _l, promise as _n, Data_exports as _o, tapCauseFilter as _r, Cause_exports as _s, forkDetach as _t, empty$4 as _u, acquireRelease as a, formatIsoZoned as aa, causePretty as ac, map$7 as ad, withTxState as ai, suspend$1 as al, onError as an, zoneMakeLocal as ao, services as ar, fail$3 as as, findFirst as at, makeReducer as au, cached as b, isTimeZone as ba, fiberInterruptAll as bc, toStepWithMetadata as bi, UnhandledLogLevel as bl, provideServiceEffect as bn, CurrentMetadata$1 as bo, tapError as br, StackTrace as bs, fromNullishOr as bt, findFirst$2 as bu, all as c, fromDateUnsafe as ca, defaultLogger as cc, zip as ci, undefined_$1 as cl, onExit as cn, zoneMakeNamedUnsafe as co, spanAnnotations as cr, hasInterrupts as cs, flatMapEager as ct, append as cu, annotateLogs as d, isDateTime as da, exit$1 as dc, request$1 as di, updateServices$1 as dl, onExitPrimitive as dn, zonedOffset as do, succeedNone as dr, isFailure$1 as ds, fn as dt, containsWith as du, formatIntl as ea, asSome$1 as ec, filter$3 as ed, withSpan as ei, sleep$1 as el, matchCauseEffect as en, toPartsUtc as eo, scope as er, make$4 as es, filterMapEffect as et, seconds as eu, annotateLogsScoped as f, isFuture as fa, exitInterrupt as fc, Request_exports as fi, void_$2 as fl, onInterrupt as fn, zonedOffsetIso as fo, succeedSome as fr, isSuccess$1 as fs, fnUntraced as ft, dedupe as fu, asVoid as g, isLessThan$1 as ga, exitZipRight as gc, either as gi, CurrentLogSpans as gl, partition as gn, Class$1 as go, tapCause as gr, void_$1 as gs, forkChild as gt, differenceWith as gu, asSome as h, isGreaterThanOrEqualTo$1 as ha, exitVoid as hc, Schedule_exports as hi, CurrentLogAnnotations as hl, orElseSucceed as hn, currentTimeNanos as ho, tap as hr, succeed$4 as hs, forever as ht, difference as hu, YieldableClass as i, formatIsoOffset as ia, causeInterrupt as ic, headUnsafe as id, withTracerTiming as ii, succeedSome$1 as il, never as in, zoneFromString as io, serviceOption as ir, die$2 as is, filterOrFail as it, UndefinedOr_exports as iu, catchNoSuchElement as j, match$3 as ja, formatLabel as jc, camelToSnake as ji, get as jl, requestUnsafe as jn, provideMerge as jo, trackSuccesses as jr, interrupt$3 as js, isFailure as jt, join as ju, catchFilter as k, makeZonedUnsafe as ka, forkDetach$1 as kc, Cron_exports as ki, add$1 as kl, replicateEffect as kn, makeMemoMapUnsafe as ko, trackDuration as kr, hasInterrupts$1 as ks, interruptibleMask as kt, isArrayNonEmpty as ku, andThen as l, getPart as la, effectIsExit as lc, zipWith as li, uninterruptible$1 as ll, onExitFilter as ln, zoneMakeOffset as lo, spanLinks as lr, interrupt$2 as ls, flatten as lt, appendAll as lu, as as m, isGreaterThan$1 as ma, exitIsSuccess as mc, CurrentMetadata as mi, addSpanStackTrace as ml, orDie as mn, Clock_exports as mo, sync as mr, mapError$1 as ms, forEach as mt, dedupeWith as mu, Effect_exports as n, formatIsoDate as na, catchCause$2 as nc, forever$3 as nd, withTracer as ni, succeed$5 as nl, matchEager as nn, withDate as no, scopedWith as nr, succeed$3 as ns, filterMapOrFail as nt, toNanos as nu, acquireUseRelease as o, formatLocal as oa, causePrettyError as oc, Tuple_exports as od, yieldNow as oi, sync$3 as ol, onErrorFilter as on, zoneMakeNamed as oo, servicesWith as or, failCause$3 as os, findFirstFilter as ot, map$5 as ou, annotateSpans as p, isFutureUnsafe as pa, exitIsFailure as pc, scheduleFromStep as pi, whileLoop$1 as pl, option as pn, Clock as po, suspend as pr, map$2 as ps, fnUntracedEager as pt, dedupeAdjacent as pu, failCause as q, startOf as qa, onExit$1 as qc, add as qi, infinity as ql, runSyncWith as qn, Deferred_exports as qo, withConcurrency as qr, LogLevelOrder as qs, mapBothEager as qt, separate as qu, Transaction as r, formatIsoDateUtc as ra, catch_$2 as rc, head$1 as rd, withTracerEnabled as ri, succeedNone$1 as rl, matchEffect as rn, withDateUtc as ro, service as rr, Exit_exports as rs, filterOrElse as rt, zero as ru, addFinalizer as s, formatUtc as sa, consolePretty as sc, makeEquivalence$1 as sd, yieldNowWith as si, tracerLogger as sl, onErrorIf as sn, zoneMakeNamedEffect as so, sleep as sr, getSuccess as ss, flatMap as st, Array_exports as su, Do as t, formatIso as ta, callback$1 as tc, filterMap$3 as td, withSpanScoped as ti, structuredMessage as tl, matchCauseEffectEager as tn, toUtc as to, scoped as tr, makeUnsafe$2 as ts, filterMapOrElse as tt, toMillis as tu, annotateCurrentSpan as u, getPartUtc as ua, endSpan as uc, Metric_exports as ui, uninterruptibleMask$1 as ul, onExitIf as un, zoneToString as uo, succeed as ur, isExit as us, flip as ut, contains as uu, bind as v, isPast as va, fiberAwaitAll as vc, forever$1 as vi, References_exports as vl, provide as vn, Error$1 as vo, tapCauseIf as vr, Done as vs, forkIn as vt, ensure as vu, catchCause as w, isZoned as wa, fiberJoinAll as wc, doneExitFromCause as wi, MixedScheduler as wl, raceAllFirst as wn, buildWithMemoMap as wo, timeoutOption as wr, filterInterruptors as ws, gen as wt, fromIterable as wu, cachedInvalidateWithTTL as x, isTimeZoneNamed as xa, fiberInterruptAllAs as xc, toStepWithSleep as xi, ParentSpan as xl, provideServices as xn, ExecutionPlan_exports as xo, tapErrorTag as xr, die$3 as xs, fromOption as xt, findFirstIndex as xu, bindTo as y, isPastUnsafe as ya, fiberInterrupt as yc, spaced as yi, TracerTimingEnabled as yl, provideService as yn, TaggedError as yo, tapDefect as yr, ExceededCapacityError as ys, forkScoped as yt, filter$2 as yu, currentSpan as z, nowUnsafe as za, logLevelToOrder as zc, uncapitalize as zi, Filter_exports as zl, runForkWith as zn, addFinalizerExit as zo, unwrapReason as zr, map$3 as zs, logInfo as zt, modify$1 as zu };
