import { $ as flow, Q as dual, X as constVoid, x as hasProperty } from "./Equal-CgzkNqbP.js";
import { G as fail, at as succeed } from "./Record-BrB0racz.js";
import { At as isEffect, Bo as close, Dl as Service, Ei as filterNoDone, El as Reference, Eo as effect, Gt as map, Ho as fork, Jo as _await, K as fail$1, Ko as provide, Kr as whileLoop, Ll as merge, Mo as succeed$1, Pr as tryPromise, Ro as addFinalizer, T as catchCauseFilter, Tn as raceFirst, Tr as timeoutOrElse, U as ensuring, Vr as updateServices, Wr as void_$1, Xo as doneUnsafe, Xr as withFiber, Zo as fail$2, _n as promise, a as acquireRelease, ft as fnUntraced, gs as void_, ht as forever, k as catchFilter, mr as sync, nr as scopedWith, pr as suspend, st as flatMap, ts as makeUnsafe, ur as succeed$2, vt as forkIn, yn as provideService } from "./Effect-DrBRDdmt.js";
import { E as ErrorClass, R as Literals, Vt as Union, ei as optional, mi as tag, mt as String, q as Number, y as Defect } from "./Schema-DuK_yWH0.js";
import { An as makeUnsafe$1, Ht as unwrap, U as fromTransform, en as failCause, nn as into, rn as make, sn as offerUnsafe, un as takeAll } from "./Channel-BalfMI2y.js";
import { a as runtime, i as run, n as join, r as make$1 } from "./FiberSet-CV_RhfQA.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/socket/Socket.js
/**
* @since 4.0.0
* @category Type IDs
*/
var TypeId = "~effect/socket/Socket";
/**
* @since 4.0.0
* @category guards
*/
var isSocket = (u) => hasProperty(u, TypeId);
/**
* @since 4.0.0
* @category tags
*/
var Socket = /*#__PURE__*/ Service("effect/socket/Socket");
var CloseEventTypeId = "~effect/socket/Socket/CloseEvent";
/**
* @since 4.0.0
* @category models
*/
var CloseEvent = class {
	/**
	* @since 4.0.0
	*/
	[CloseEventTypeId];
	code;
	reason;
	constructor(code = 1e3, reason) {
		this[CloseEventTypeId] = CloseEventTypeId;
		this.code = code;
		this.reason = reason;
	}
	/**
	* @since 4.0.0
	*/
	toString() {
		return this.reason ? `${this.code}: ${this.reason}` : `${this.code}`;
	}
};
/**
* @since 4.0.0
* @category refinements
*/
var isCloseEvent = (u) => hasProperty(u, CloseEventTypeId);
/**
* @since 4.0.0
* @category type ids
*/
var SocketErrorTypeId = "~effect/socket/Socket/SocketError";
/**
* @since 4.0.0
* @category refinements
*/
var isSocketError = (u) => hasProperty(u, SocketErrorTypeId);
/**
* @since 4.0.0
* @category errors
*/
var SocketReadError = class extends ErrorClass("effect/socket/Socket/SocketReadError")({
	_tag: /*#__PURE__*/ tag("SocketReadError"),
	cause: Defect
}) {
	/**
	* @since 4.0.0
	*/
	message = `An error occurred during Read`;
};
/**
* @since 4.0.0
* @category errors
*/
var SocketWriteError = class extends ErrorClass("effect/socket/Socket/SocketWriteError")({
	_tag: /*#__PURE__*/ tag("SocketWriteError"),
	cause: Defect
}) {
	/**
	* @since 4.0.0
	*/
	message = `An error occurred during Write`;
};
/**
* @since 4.0.0
* @category errors
*/
var SocketOpenError = class extends ErrorClass("effect/socket/Socket/SocketOpenError")({
	_tag: /*#__PURE__*/ tag("SocketOpenError"),
	kind: /*#__PURE__*/ Literals(["Unknown", "Timeout"]),
	cause: Defect
}) {
	/**
	* @since 4.0.0
	*/
	get message() {
		return this.kind === "Timeout" ? `timeout waiting for "open"` : `An error occurred during Open`;
	}
};
/**
* @since 4.0.0
* @category errors
*/
var SocketCloseError = class extends ErrorClass("effect/socket/Socket/SocketCloseError")({
	_tag: /*#__PURE__*/ tag("SocketCloseError"),
	code: Number,
	closeReason: /*#__PURE__*/ optional(String)
}) {
	/**
	* @since 4.0.0
	*/
	static filterClean(isClean) {
		return function(u) {
			return SocketError.is(u) && u.reason._tag === "SocketCloseError" && isClean(u.reason.code) ? succeed(u.reason) : fail(u);
		};
	}
	get message() {
		if (this.closeReason) return `${this.code}: ${this.closeReason}`;
		return `${this.code}`;
	}
};
/**
* @since 4.0.0
* @category errors
*/
var SocketErrorReason = /*#__PURE__*/ Union([
	SocketReadError,
	SocketWriteError,
	SocketOpenError,
	SocketCloseError
]);
/**
* @since 4.0.0
* @category errors
*/
var SocketError = class extends ErrorClass(SocketErrorTypeId)({
	_tag: /*#__PURE__*/ tag("SocketError"),
	reason: SocketErrorReason
}) {
	constructor(props) {
		if ("cause" in props.reason) super({
			...props,
			cause: props.reason.cause
		});
		else super(props);
	}
	/**
	* @since 4.0.0
	*/
	[SocketErrorTypeId] = SocketErrorTypeId;
	/**
	* @since 4.0.0
	*/
	static is(u) {
		return isSocketError(u);
	}
};
/**
* @since 4.0.0
* @category combinators
*/
var toChannelMap = (self, f) => fromTransform(fnUntraced(function* (upstream, scope) {
	const queue = yield* make();
	const writeScope = yield* fork(scope);
	const write = yield* provide(self.writer, writeScope);
	let chunk;
	let index = 0;
	const writeChunk = whileLoop({
		while: () => index < chunk.length,
		body: () => write(chunk[index++]),
		step: constVoid
	});
	yield* upstream.pipe(flatMap((arr) => {
		if (arr.length === 1) return write(arr[0]);
		chunk = arr;
		index = 0;
		return writeChunk;
	}), forever({ disableYield: true }), catchCauseFilter(filterNoDone, (cause) => failCause(queue, cause)), ensuring(close(writeScope, void_)), forkIn(scope));
	yield* self.runRaw((data) => {
		offerUnsafe(queue, f(data));
	}).pipe(into(queue), forkIn(scope));
	return takeAll(queue);
}));
/**
* @since 4.0.0
* @category combinators
*/
var toChannel = (self) => {
	const encoder = new TextEncoder();
	return toChannelMap(self, (data) => typeof data === "string" ? encoder.encode(data) : data);
};
/**
* @since 4.0.0
* @category combinators
*/
var toChannelString = /*#__PURE__*/ dual((args) => isSocket(args[0]), (self, encoding) => {
	const decoder = new TextDecoder(encoding);
	return toChannelMap(self, (data) => typeof data === "string" ? data : decoder.decode(data));
});
/**
* @since 4.0.0
* @category combinators
*/
var toChannelWith = () => (self) => toChannel(self);
/**
* @since 4.0.0
* @category constructors
*/
var makeChannel = () => unwrap(map(Socket.asEffect(), toChannelWith()));
/**
* @since 4.0.0
*/
var defaultCloseCodeIsError = (code) => code !== 1e3 && code !== 1006;
/**
* @since 4.0.0
* @category tags
*/
var WebSocket = class extends Service()("~effect/socket/Socket/WebSocket") {};
/**
* @since 4.0.0
* @category tags
*/
var WebSocketConstructor = class extends Service()("@effect/platform/Socket/WebSocketConstructor") {};
/**
* @since 4.0.0
* @category layers
*/
var layerWebSocketConstructorGlobal = /*#__PURE__*/ succeed$1(WebSocketConstructor)((url, protocols) => new globalThis.WebSocket(url, protocols));
/**
* @since 4.0.0
* @category constructors
*/
var makeWebSocket = (url, options) => fromWebSocket(acquireRelease((typeof url === "string" ? succeed$2(url) : url).pipe(flatMap((url) => map(WebSocketConstructor.asEffect(), (f) => f(url, options?.protocols)))), (ws) => sync(() => ws.close(1e3))), options);
/**
* @since 4.0.0
* @category constructors
*/
var fromWebSocket = (acquire, options) => withFiber((fiber) => {
	let currentWS;
	const latch = makeUnsafe$1(false);
	const acquireContext = fiber.services;
	const closeCodeIsError = options?.closeCodeIsError ?? defaultCloseCodeIsError;
	const runRaw = (handler, opts) => scopedWith(fnUntraced(function* (scope) {
		const fiberSet = yield* make$1().pipe(provide(scope));
		const ws = yield* provide(acquire, scope);
		const run = yield* provideService(runtime(fiberSet)(), WebSocket, ws);
		let open = false;
		function onMessage(event) {
			if (event.data instanceof Blob) {
				const effect = flatMap(promise(() => event.data.arrayBuffer()), (buffer) => {
					const result = handler(new Uint8Array(buffer));
					return isEffect(result) ? result : void_$1;
				});
				return run(effect);
			}
			const result = handler(event.data);
			if (isEffect(result)) run(result);
		}
		function onError(cause) {
			ws.removeEventListener("message", onMessage);
			ws.removeEventListener("close", onClose);
			doneUnsafe(fiberSet.deferred, fail$1(new SocketError({ reason: open ? new SocketReadError({ cause }) : new SocketOpenError({
				kind: "Unknown",
				cause
			}) })));
		}
		function onClose(event) {
			ws.removeEventListener("message", onMessage);
			ws.removeEventListener("error", onError);
			doneUnsafe(fiberSet.deferred, fail$1(new SocketError({ reason: new SocketCloseError({
				code: event.code,
				closeReason: event.reason
			}) })));
		}
		ws.addEventListener("close", onClose, { once: true });
		ws.addEventListener("error", onError, { once: true });
		ws.addEventListener("message", onMessage);
		if (ws.readyState !== 1) {
			const openDeferred = makeUnsafe();
			ws.addEventListener("open", () => {
				open = true;
				doneUnsafe(openDeferred, void_$1);
			}, { once: true });
			yield* _await(openDeferred).pipe(timeoutOrElse({
				duration: options?.openTimeout ?? 1e4,
				onTimeout: () => fail$1(new SocketError({ reason: new SocketOpenError({
					kind: "Timeout",
					cause: /* @__PURE__ */ new Error("timeout waiting for \"open\"")
				}) }))
			}), raceFirst(join(fiberSet)));
		}
		open = true;
		currentWS = ws;
		latch.openUnsafe();
		if (opts?.onOpen) yield* opts.onOpen;
		return yield* catchFilter(join(fiberSet), SocketCloseError.filterClean((_) => !closeCodeIsError(_)), () => void_$1);
	})).pipe(updateServices((input) => merge(acquireContext, input)), ensuring(sync(() => {
		latch.closeUnsafe();
		currentWS = void 0;
	})));
	const encoder = new TextEncoder();
	const run = (handler, opts) => runRaw((data) => typeof data === "string" ? handler(encoder.encode(data)) : data instanceof Uint8Array ? handler(data) : handler(new Uint8Array(data)), opts);
	const write = (chunk) => latch.whenOpen(sync(() => {
		const ws = currentWS;
		if (isCloseEvent(chunk)) ws.close(chunk.code, chunk.reason);
		else ws.send(chunk);
	}));
	const writer = succeed$2(write);
	return succeed$2(Socket.of({
		[TypeId]: TypeId,
		run,
		runRaw,
		writer
	}));
});
/**
* @since 4.0.0
* @category constructors
*/
var makeWebSocketChannel = (url, options) => unwrap(map(makeWebSocket(url, options), toChannelWith()));
/**
* @since 4.0.0
* @category layers
*/
var layerWebSocket = /*#__PURE__*/ flow(makeWebSocket, /*#__PURE__*/ effect(Socket));
/**
* @since 4.0.0
* @category fiber refs
*/
var SendQueueCapacity = /*#__PURE__*/ Reference("~effect/socket/Socket/SendQueueCapacity", { defaultValue: () => 16 });
/**
* @since 4.0.0
* @category constructors
*/
var fromTransformStream = (acquire, options) => withFiber((fiber) => {
	const latch = makeUnsafe$1(false);
	let currentStream;
	const acquireServices = fiber.services;
	const closeCodeIsError = options?.closeCodeIsError ?? defaultCloseCodeIsError;
	const runRaw = (handler, opts) => scopedWith(fnUntraced(function* (scope) {
		const stream = yield* provide(acquire, scope);
		const reader = stream.readable.getReader();
		yield* addFinalizer(scope, promise(() => reader.cancel()));
		const fiberSet = yield* make$1().pipe(provide(scope));
		const runFork = yield* runtime(fiberSet)();
		yield* tryPromise({
			try: async () => {
				while (true) {
					const { done, value } = await reader.read();
					if (done) throw new SocketError({ reason: new SocketCloseError({ code: 1e3 }) });
					const result = handler(value);
					if (isEffect(result)) runFork(result);
				}
			},
			catch: (cause) => isSocketError(cause) ? cause : new SocketError({ reason: new SocketReadError({ cause }) })
		}).pipe(run(fiberSet));
		currentStream = {
			stream,
			fiberSet
		};
		yield* latch.open;
		if (opts?.onOpen) yield* opts.onOpen;
		return yield* catchFilter(join(fiberSet), SocketCloseError.filterClean((_) => !closeCodeIsError(_)), () => void_$1);
	})).pipe((_) => _, updateServices((input) => merge(acquireServices, input)), ensuring(sync(() => {
		latch.closeUnsafe();
		currentStream = void 0;
	})));
	const encoder = new TextEncoder();
	const run$1 = (handler, opts) => runRaw((data) => typeof data === "string" ? handler(encoder.encode(data)) : handler(data), opts);
	const writers = /* @__PURE__ */ new WeakMap();
	const getWriter = (stream) => {
		let writer = writers.get(stream);
		if (!writer) {
			writer = stream.writable.getWriter();
			writers.set(stream, writer);
		}
		return writer;
	};
	const write = (chunk) => latch.whenOpen(suspend(() => {
		const { fiberSet, stream } = currentStream;
		if (isCloseEvent(chunk)) return fail$2(fiberSet.deferred, new SocketError({ reason: new SocketCloseError({
			code: chunk.code,
			closeReason: chunk.reason
		}) }));
		return promise(() => getWriter(stream).write(typeof chunk === "string" ? encoder.encode(chunk) : chunk));
	}));
	const writer = acquireRelease(succeed$2(write), () => promise(async () => {
		if (!currentStream) return;
		await getWriter(currentStream.stream).close();
	}));
	return succeed$2(Socket.of({
		[TypeId]: TypeId,
		run: run$1,
		runRaw,
		writer
	}));
});
//#endregion
export { CloseEvent, SendQueueCapacity, Socket, SocketCloseError, SocketError, SocketErrorReason, SocketErrorTypeId, SocketOpenError, SocketReadError, SocketWriteError, TypeId, WebSocket, WebSocketConstructor, defaultCloseCodeIsError, fromTransformStream, fromWebSocket, isCloseEvent, isSocket, isSocketError, layerWebSocket, layerWebSocketConstructorGlobal, makeChannel, makeWebSocket, makeWebSocketChannel, toChannel, toChannelMap, toChannelString, toChannelWith };
