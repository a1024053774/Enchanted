import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { o as EMPTY_ARRAY } from "./useRenderElement-CvLulVDb.js";
//#region node_modules/.bun/@base-ui+utils@0.3.2+0ea9ec2a211d4613/node_modules/@base-ui/utils/useOnMount.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* A React.useEffect equivalent that runs once, when the component is mounted.
*/
function useOnMount(fn) {
	import_react.useEffect(fn, EMPTY_ARRAY);
}
//#endregion
export { useOnMount as t };
