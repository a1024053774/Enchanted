import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { M as isObject, Q as dual, T as isFunction, Y as constUndefined, a as equals, d as array, f as combine$2, g as string, l as symbol$1, n as asEquivalence, ot as pipeArguments, p as hash, q as constNull, tt as identity, v as structureKeys, x as hasProperty, y as symbol } from "./Equal-CgzkNqbP.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Reducer.js
var Reducer_exports = /* @__PURE__ */ __exportAll({
	flip: () => flip$3,
	make: () => make$3
});
/**
* A module for reducing collections of values into a single result.
*
* A `Reducer<A>` extends {@link Combiner.Combiner} by adding an
* `initialValue` (identity element) and a `combineAll` method that folds an
* entire collection. Think `Array.prototype.reduce`, but packaged as a
* reusable, composable value.
*
* ## Mental model
*
* - **Reducer** – a {@link Combiner.Combiner} plus an `initialValue` and a
*   `combineAll` method.
* - **initialValue** – the neutral/identity element. Combining any value with
*   `initialValue` should return the original value unchanged (e.g. `0` for
*   addition, `""` for string concatenation).
* - **combineAll** – folds an `Iterable<A>` starting from `initialValue`.
*   When omitted from {@link make}, a default left-to-right fold is used.
* - **Purity** – all reducers produced by this module are pure; they never
*   mutate their arguments.
* - **Composability** – reducers can be lifted into `Option`, `Struct`,
*   `Tuple`, `Record`, and other container types via helpers in those modules.
* - **Subtype of Combiner** – every `Reducer` is also a valid
*   `Combiner`, so you can pass a `Reducer` anywhere a `Combiner` is
*   expected.
*
* ## Common tasks
*
* - Create a reducer from a combine function and initial value → {@link make}
* - Swap argument order → {@link flip}
* - Combine two values without an initial value → use {@link Combiner.Combiner}
*   instead
*
* ## Gotchas
*
* - `combineAll` on an empty iterable returns `initialValue`, not an error.
* - The default `combineAll` folds left-to-right. If your `combine` is not
*   associative, order matters. Pass a custom `combineAll` to {@link make} if
*   you need different traversal or short-circuiting.
* - A `Reducer` is also a valid `Combiner` — but a `Combiner` is *not* a
*   `Reducer` (it lacks `initialValue`).
*
* ## Quickstart
*
* **Example** (summing a list of numbers)
*
* ```ts
* import { Reducer } from "effect"
*
* const Sum = Reducer.make<number>((a, b) => a + b, 0)
*
* console.log(Sum.combine(3, 4))
* // Output: 7
*
* console.log(Sum.combineAll([1, 2, 3, 4]))
* // Output: 10
*
* console.log(Sum.combineAll([]))
* // Output: 0
* ```
*
* ## See also
*
* - {@link make} – the primary constructor
* - {@link Reducer} – the core interface
* - {@link Combiner.Combiner} – the parent interface (no `initialValue`)
*
* @since 4.0.0
*/
/**
* Creates a `Reducer` from a `combine` function and an `initialValue`.
*
* When to use:
* - You have a custom reducing operation not covered by a pre-built reducer.
* - You want to provide an optimized `combineAll` (e.g. short-circuiting on
*   a known absorbing element like `0` for multiplication).
*
* Behavior:
* - If `combineAll` is omitted, a default left-to-right fold starting from
*   `initialValue` is used.
* - If `combineAll` is provided, it completely replaces the default fold.
* - Pure – the returned reducer does not mutate its arguments.
*
* **Example** (multiplication with short-circuit)
*
* ```ts
* import { Reducer } from "effect"
*
* const Product = Reducer.make<number>(
*   (a, b) => a * b,
*   1,
*   (collection) => {
*     let acc = 1
*     for (const n of collection) {
*       if (n === 0) return 0
*       acc *= n
*     }
*     return acc
*   }
* )
*
* console.log(Product.combineAll([2, 3, 4]))
* // Output: 24
*
* console.log(Product.combineAll([2, 0, 4]))
* // Output: 0
* ```
*
* @see {@link Reducer} – the interface this creates
* @see {@link flip} – reverse the argument order
*
* @since 4.0.0
*/
function make$3(combine, initialValue, combineAll) {
	return {
		combine,
		initialValue,
		combineAll: combineAll ?? ((collection) => {
			let out = initialValue;
			for (const value of collection) out = combine(out, value);
			return out;
		})
	};
}
/**
* Reverses the argument order of a reducer's `combine` method.
*
* When to use:
* - You need the "right" value to act as the accumulator side.
* - You want to reverse the natural direction of a non-commutative reducer
*   (e.g. string concatenation becomes prepend).
*
* Behavior:
* - Returns a new `Reducer` where `combine(self, that)` calls the original
*   reducer as `combine(that, self)`.
* - The `initialValue` is preserved from the original reducer.
* - The `combineAll` is re-derived from the flipped `combine` (using the
*   default left-to-right fold), not carried over from the original.
* - Does not mutate the input reducer.
*
* **Example** (reversing string concatenation)
*
* ```ts
* import { Reducer, String } from "effect"
*
* const Prepend = Reducer.flip(String.ReducerConcat)
*
* console.log(Prepend.combine("a", "b"))
* // Output: "ba"
*
* console.log(Prepend.combineAll(["a", "b", "c"]))
* // Output: "cba"
* ```
*
* @see {@link make}
* @see {@link Combiner.flip} – the same operation on a plain `Combiner`
*
* @since 4.0.0
*/
function flip$3(reducer) {
	return make$3((self, that) => reducer.combine(that, self), reducer.initialValue);
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Equivalence.js
/**
* Utilities for defining equivalence relations - binary relations that determine when two values
* should be considered equivalent. Equivalence relations are used for comparing, deduplicating,
* and organizing data in collections and data structures.
*
* ## Mental model
*
* - **Equivalence relation**: A function `(a: A, b: A) => boolean` that returns `true` when values are equivalent
* - **Reflexive property**: Every value is equivalent to itself (`eq(a, a) === true`)
* - **Symmetric property**: If `a` is equivalent to `b`, then `b` is equivalent to `a` (`eq(a, b) === eq(b, a)`)
* - **Transitive property**: If `a` is equivalent to `b` and `b` is equivalent to `c`, then `a` is equivalent to `c`
* - **Reference equality optimization**: {@link make} checks `===` first for performance before calling the custom function
* - **Composition**: Equivalences can be combined using {@link combine} and {@link combineAll} to create more complex relations
*
* ## Common tasks
*
* - Creating custom equivalences → {@link make}
* - Using strict equality (`===`) → {@link strictEqual}
* - Combining multiple equivalences (AND logic) → {@link combine}, {@link combineAll}
* - Transforming input before comparison → {@link mapInput}
* - Creating equivalences for structured types → {@link Struct}, {@link Tuple}, {@link Array}, {@link Record}
*
* ## Gotchas
*
* - `strictEqual` uses `===`, so `NaN !== NaN` and objects are compared by reference, not structure
* - `make` optimizes with a reference equality check, so identical references return `true` without calling the function
* - `combineAll` with an empty collection returns an equivalence that always returns `true`
* - `Tuple` and `Array` require matching lengths; different lengths are never equivalent
*
* ## Quickstart
*
* **Example** (Case-insensitive string equivalence)
*
* ```ts
* import { Array, Equivalence } from "effect"
*
* const caseInsensitive = Equivalence.make<string>((a, b) =>
*   a.toLowerCase() === b.toLowerCase()
* )
*
* const strings = ["Hello", "world", "HELLO", "World"]
* const deduplicated = Array.dedupeWith(strings, caseInsensitive)
* console.log(deduplicated) // ["Hello", "world"]
* ```
*
* ## See also
*
* - {@link Equal} - For structural equality (can convert to Equivalence)
* - {@link Array.dedupeWith} - Remove duplicates using an equivalence
* - {@link Chunk} - Collections that use equivalences for operations
*
* @since 2.0.0
*/
var Equivalence_exports = /* @__PURE__ */ __exportAll({
	Array: () => Array$2,
	BigInt: () => BigInt$1,
	Boolean: () => Boolean$1,
	Number: () => Number$1,
	Record: () => Record,
	String: () => String$2,
	Struct: () => Struct$1,
	Tuple: () => Tuple$1,
	combine: () => combine$1,
	combineAll: () => combineAll$1,
	make: () => make$2,
	makeReducer: () => makeReducer$2,
	mapInput: () => mapInput$1,
	strictEqual: () => strictEqual
});
/**
* Creates a custom equivalence relation with an optimized reference equality check.
*
* When to use this:
* - When you need a custom equivalence that isn't just strict equality
* - When creating equivalences for complex types with custom comparison logic
* - When you want the performance benefit of reference equality optimization
*
* Behavior:
* - Does not mutate inputs
* - First checks reference equality (`===`) for performance; if values are identical, returns `true` without calling the function
* - Falls back to the provided equivalence function if values are not the same reference
* - The provided function must satisfy reflexive, symmetric, and transitive properties
*
* **Example** (Case-insensitive string equivalence)
*
* ```ts
* import { Equivalence } from "effect"
*
* const caseInsensitive = Equivalence.make<string>((a, b) =>
*   a.toLowerCase() === b.toLowerCase()
* )
*
* console.log(caseInsensitive("Hello", "HELLO")) // true
* console.log(caseInsensitive("foo", "bar")) // false
*
* // Same reference optimization
* const str = "test"
* console.log(caseInsensitive(str, str)) // true (fast path)
* ```
*
* **Example** (Numeric tolerance equivalence)
*
* ```ts
* import { Equivalence } from "effect"
*
* const tolerance = Equivalence.make<number>((a, b) => Math.abs(a - b) < 0.0001)
*
* console.log(tolerance(1.0, 1.0001)) // false
* console.log(tolerance(1.0, 1.00001)) // true
* ```
*
* See also: {@link strictEqual}, {@link mapInput}
*
* @category constructors
* @since 2.0.0
*/
var make$2 = (isEquivalent) => (self, that) => self === that || isEquivalent(self, that);
var isStrictEquivalent = (x, y) => x === y;
/**
* Creates an equivalence relation that uses strict equality (`===`) to compare values.
*
* When to use this:
* - For primitive types (numbers, strings, booleans) where `===` is appropriate
* - When you need reference equality for objects (same object instance)
* - As a building block for more complex equivalences via {@link mapInput} or {@link combine}
* - When performance is critical and you don't need structural equality
*
* Behavior:
* - Does not mutate inputs
* - Uses JavaScript's strict equality operator (`===`)
* - For primitives: compares values directly
* - For objects: compares by reference (same object instance)
* - Note: `NaN !== NaN`, so `NaN` values are never considered equivalent
*
* **Example** (Primitive types)
*
* ```ts
* import { Equivalence } from "effect"
*
* const strictEq = Equivalence.strictEqual<number>()
*
* console.log(strictEq(1, 1)) // true
* console.log(strictEq(1, 2)) // false
* console.log(strictEq(NaN, NaN)) // false (NaN !== NaN)
* ```
*
* **Example** (Reference equality for objects)
*
* ```ts
* import { Equivalence } from "effect"
*
* const obj = { value: 42 }
* const strictObjEq = Equivalence.strictEqual<typeof obj>()
*
* console.log(strictObjEq(obj, obj)) // true
* console.log(strictObjEq(obj, { value: 42 })) // false (different references)
* ```
*
* See also: {@link make}, {@link Equal} (for structural equality)
*
* @category constructors
* @since 4.0.0
*/
var strictEqual = () => isStrictEquivalent;
/**
* An `Equivalence` instance for strings using strict equality (`===`).
*
* @example
* ```ts
* import { Equivalence } from "effect"
*
* console.log(Equivalence.String("hello", "hello")) // true
* console.log(Equivalence.String("hello", "world")) // false
* ```
*
* @category instances
* @since 4.0.0
*/
var String$2 = isStrictEquivalent;
/**
* An `Equivalence` instance for numbers.
*
* `NaN` is considered equal to `NaN`.
*
* @example
* ```ts
* import { Equivalence } from "effect"
*
* console.log(Equivalence.Number(1, 1)) // true
* console.log(Equivalence.Number(1, 2)) // false
* console.log(Equivalence.Number(NaN, NaN)) // true
* ```
*
* @category instances
* @since 4.0.0
*/
var Number$1 = /*#__PURE__*/ make$2((self, that) => globalThis.Number.isNaN(self) && globalThis.Number.isNaN(that));
/**
* An `Equivalence` instance for booleans using strict equality (`===`).
*
* @example
* ```ts
* import { Equivalence } from "effect"
*
* console.log(Equivalence.Boolean(true, true)) // true
* console.log(Equivalence.Boolean(true, false)) // false
* ```
*
* @category instances
* @since 4.0.0
*/
var Boolean$1 = isStrictEquivalent;
/**
* An `Equivalence` instance for bigints using strict equality (`===`).
*
* @example
* ```ts
* import { Equivalence } from "effect"
*
* console.log(Equivalence.BigInt(1n, 1n)) // true
* console.log(Equivalence.BigInt(1n, 2n)) // false
* ```
*
* @category instances
* @since 4.0.0
*/
var BigInt$1 = isStrictEquivalent;
/**
* Combines two equivalence relations using logical AND.
*
* When to use this:
* - When you need to combine exactly two equivalences
* - When building complex equivalences from simpler ones
* - When you want both conditions to be satisfied (AND logic)
*
* Behavior:
* - Does not mutate inputs
* - Returns `true` only if both equivalences return `true`
* - Short-circuits: if the first equivalence returns `false`, the second is not called
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Combining name and age equivalences)
*
* ```ts
* import { Equivalence } from "effect"
*
* interface Person {
*   name: string
*   age: number
* }
*
* const nameEquivalence = Equivalence.mapInput(
*   Equivalence.strictEqual<string>(),
*   (p: Person) => p.name
* )
*
* const ageEquivalence = Equivalence.mapInput(
*   Equivalence.strictEqual<number>(),
*   (p: Person) => p.age
* )
*
* const personEquivalence = Equivalence.combine(nameEquivalence, ageEquivalence)
*
* const person1 = { name: "Alice", age: 30 }
* const person2 = { name: "Alice", age: 30 }
* const person3 = { name: "Alice", age: 31 }
*
* console.log(personEquivalence(person1, person2)) // true
* console.log(personEquivalence(person1, person3)) // false (different age)
* ```
*
* See also: {@link combineAll}, {@link mapInput}
*
* @category combining
* @since 2.0.0
*/
var combine$1 = /*#__PURE__*/ dual(2, (self, that) => make$2((x, y) => self(x, y) && that(x, y)));
/**
* Combines multiple equivalence relations into a single equivalence using logical AND.
*
* When to use this:
* - When you need to combine three or more equivalences
* - When you have a dynamic collection of equivalences to combine
* - When building equivalences from arrays or iterables
* - Prefer over multiple `combine` calls when you have many equivalences
*
* Behavior:
* - Does not mutate inputs
* - Returns `true` only if all equivalences in the collection return `true`
* - Short-circuits: stops at the first equivalence that returns `false`
* - Empty collection edge case: returns an equivalence that always returns `true`
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Combining multiple field equivalences)
*
* ```ts
* import { Equivalence } from "effect"
*
* interface Point3D {
*   x: number
*   y: number
*   z: number
* }
*
* const xEq = Equivalence.mapInput(
*   Equivalence.strictEqual<number>(),
*   (p: Point3D) => p.x
* )
* const yEq = Equivalence.mapInput(
*   Equivalence.strictEqual<number>(),
*   (p: Point3D) => p.y
* )
* const zEq = Equivalence.mapInput(
*   Equivalence.strictEqual<number>(),
*   (p: Point3D) => p.z
* )
*
* const point3DEq = Equivalence.combineAll([xEq, yEq, zEq])
*
* const point1 = { x: 1, y: 2, z: 3 }
* const point2 = { x: 1, y: 2, z: 3 }
* const point3 = { x: 1, y: 2, z: 4 }
*
* console.log(point3DEq(point1, point2)) // true
* console.log(point3DEq(point1, point3)) // false (different z)
* ```
*
* **Example** (Empty collection edge case)
*
* ```ts
* import { Equivalence } from "effect"
*
* // Empty collection always returns true
* const alwaysEq = Equivalence.combineAll([])
* console.log(alwaysEq("anything", "else")) // true
* ```
*
* See also: {@link combine}, {@link mapInput}
*
* @category combining
* @since 2.0.0
*/
var combineAll$1 = (collection) => make$2((x, y) => {
	for (const equivalence of collection) if (!equivalence(x, y)) return false;
	return true;
});
/**
* Transforms an equivalence relation by mapping the input values before comparison.
*
* When to use this:
* - When you need an equivalence for a complex type based on a single property
* - When you want to normalize values before comparison (e.g., case-insensitive strings)
* - When creating equivalences that focus on specific fields of objects
* - As a building block for creating equivalences via {@link combine} or {@link combineAll}
*
* Behavior:
* - Does not mutate inputs
* - Applies the transformation function to both values before comparing
* - The transformation function should be pure (no side effects)
* - The resulting equivalence compares the transformed values using the provided equivalence
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Equivalence based on object property)
*
* ```ts
* import { Equivalence } from "effect"
*
* interface User {
*   id: number
*   name: string
*   email: string
* }
*
* // Create equivalence based on user ID only
* const userByIdEq = Equivalence.mapInput(
*   Equivalence.strictEqual<number>(),
*   (user: User) => user.id
* )
*
* const user1 = { id: 1, name: "Alice", email: "alice@example.com" }
* const user2 = { id: 1, name: "Alice Smith", email: "alice.smith@example.com" }
* const user3 = { id: 2, name: "Bob", email: "bob@example.com" }
*
* console.log(userByIdEq(user1, user2)) // true (same ID)
* console.log(userByIdEq(user1, user3)) // false (different ID)
* ```
*
* **Example** (Case-insensitive string equivalence)
*
* ```ts
* import { Equivalence } from "effect"
*
* const caseInsensitiveEq = Equivalence.mapInput(
*   Equivalence.strictEqual<string>(),
*   (s: string) => s.toLowerCase()
* )
*
* console.log(caseInsensitiveEq("Hello", "HELLO")) // true
* console.log(caseInsensitiveEq("Hello", "World")) // false
* ```
*
* See also: {@link combine}, {@link Struct}
*
* @category mapping
* @since 2.0.0
*/
var mapInput$1 = /*#__PURE__*/ dual(2, (self, f) => make$2((x, y) => self(f(x), f(y))));
/**
* Creates an equivalence for tuples with heterogeneous element types.
*
* When to use this:
* - When comparing tuples with different types at each position
* - When you need different equivalence logic for each tuple element
* - When working with fixed-length tuples (not arrays)
* - Prefer over `Array` when you have a known tuple structure with different types
*
* Behavior:
* - Does not mutate inputs
* - Requires tuples to have the same length; different lengths are never equivalent
* - Applies each equivalence to the corresponding element position
* - Returns `true` only if all elements are equivalent according to their respective equivalences
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Homogeneous tuple equivalence)
*
* ```ts
* import { Equivalence } from "effect"
*
* const stringTupleEq = Equivalence.Tuple([
*   Equivalence.strictEqual<string>(),
*   Equivalence.strictEqual<string>(),
*   Equivalence.strictEqual<string>()
* ])
*
* const tuple1 = ["hello", "world", "test"] as const
* const tuple2 = ["hello", "world", "test"] as const
* const tuple3 = ["hello", "world", "different"] as const
*
* console.log(stringTupleEq(tuple1, tuple2)) // true
* console.log(stringTupleEq(tuple1, tuple3)) // false (different third element)
* ```
*
* **Example** (Heterogeneous tuple with custom equivalences)
*
* ```ts
* import { Equivalence } from "effect"
*
* const caseInsensitive = Equivalence.mapInput(
*   Equivalence.strictEqual<string>(),
*   (s: string) => s.toLowerCase()
* )
*
* const customTupleEq = Equivalence.Tuple([
*   caseInsensitive,
*   caseInsensitive,
*   caseInsensitive
* ])
*
* console.log(
*   customTupleEq(["Hello", "World", "Test"], ["HELLO", "WORLD", "TEST"])
* ) // true
* ```
*
* See also: {@link Array}, {@link Struct}
*
* @category combinators
* @since 4.0.0
*/
function Tuple$1(elements) {
	return make$2((self, that) => {
		if (self.length !== that.length) return false;
		for (let i = 0; i < self.length; i++) if (!elements[i](self[i], that[i])) return false;
		return true;
	});
}
/**
* Creates an equivalence for arrays where all elements are compared using the same equivalence.
*
* When to use this:
* - When comparing arrays with homogeneous element types
* - When all elements should use the same equivalence logic
* - When working with variable-length arrays (not fixed tuples)
* - Prefer over `Tuple` when you have arrays of the same type
*
* Behavior:
* - Does not mutate inputs
* - Requires arrays to have the same length; different lengths are never equivalent
* - Compares elements positionally (index 0 with index 0, etc.)
* - Returns `true` only if all corresponding elements are equivalent
* - Empty arrays are considered equivalent
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Number array equivalence)
*
* ```ts
* import { Equivalence } from "effect"
*
* const numberArrayEq = Equivalence.Array(Equivalence.strictEqual<number>())
*
* console.log(numberArrayEq([1, 2, 3], [1, 2, 3])) // true
* console.log(numberArrayEq([1, 2, 3], [1, 2, 4])) // false
* console.log(numberArrayEq([1, 2], [1, 2, 3])) // false (different length)
* ```
*
* **Example** (Case-insensitive string array)
*
* ```ts
* import { Equivalence } from "effect"
*
* const caseInsensitive = Equivalence.mapInput(
*   Equivalence.strictEqual<string>(),
*   (s: string) => s.toLowerCase()
* )
* const stringArrayEq = Equivalence.Array(caseInsensitive)
*
* console.log(stringArrayEq(["Hello", "World"], ["HELLO", "WORLD"])) // true
* console.log(stringArrayEq(["Hello"], ["Hi"])) // false
* console.log(stringArrayEq([], [])) // true (empty arrays)
* ```
*
* See also: {@link Tuple}, {@link Record}
*
* @category combinators
* @since 4.0.0
*/
function Array$2(item) {
	return make$2((self, that) => {
		if (self.length !== that.length) return false;
		for (let i = 0; i < self.length; i++) if (!item(self[i], that[i])) return false;
		return true;
	});
}
/**
* Creates an equivalence for objects by comparing their properties using provided equivalences.
*
* When to use this:
* - When comparing objects with known, fixed property names
* - When you need different equivalence logic for different properties
* - When working with struct/interface types with specific fields
* - Prefer over `Record` when you have a fixed set of known properties
*
* Behavior:
* - Does not mutate inputs
* - Compares only the properties specified in the struct definition
* - Properties not in the struct are ignored
* - Returns `true` only if all specified properties are equivalent according to their equivalences
* - Supports both string and symbol keys (via `Reflect.ownKeys`)
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Struct with different equivalences per field)
*
* ```ts
* import { Equivalence } from "effect"
*
* interface Person {
*   name: string
*   age: number
*   email: string
* }
*
* const caseInsensitive = Equivalence.mapInput(
*   Equivalence.strictEqual<string>(),
*   (s: string) => s.toLowerCase()
* )
*
* const personEq = Equivalence.Struct({
*   name: caseInsensitive,
*   age: Equivalence.strictEqual<number>(),
*   email: caseInsensitive
* })
*
* const person1 = { name: "Alice", age: 30, email: "alice@example.com" }
* const person2 = { name: "ALICE", age: 30, email: "ALICE@EXAMPLE.COM" }
* const person3 = { name: "Alice", age: 31, email: "alice@example.com" }
*
* console.log(personEq(person1, person2)) // true (case-insensitive match)
* console.log(personEq(person1, person3)) // false (different age)
* ```
*
* **Example** (Partial equivalence for specific fields)
*
* ```ts
* import { Equivalence } from "effect"
*
* const nameAgeEq = Equivalence.Struct({
*   name: Equivalence.strictEqual<string>(),
*   age: Equivalence.strictEqual<number>()
* })
*
* // Only compares name and age, ignores other properties
* const obj1 = { name: "Alice", age: 30, extra: "ignored" }
* const obj2 = { name: "Alice", age: 30, extra: "different" }
* console.log(nameAgeEq(obj1, obj2)) // true
* ```
*
* See also: {@link Record}, {@link mapInput}, {@link combine}
*
* @category combinators
* @since 4.0.0
*/
function Struct$1(fields) {
	const keys = Reflect.ownKeys(fields);
	return make$2((self, that) => {
		for (const key of keys) if (!fields[key](self[key], that[key])) return false;
		return true;
	});
}
/**
* Creates an equivalence for objects by comparing all properties using the same equivalence.
*
* When to use this:
* - When comparing objects with dynamic or unknown property names
* - When all property values should use the same equivalence logic
* - When working with record/dictionary types (key-value maps)
* - Prefer over `Struct` when you have variable properties or need to compare all properties uniformly
*
* Behavior:
* - Does not mutate inputs
* - Compares all properties present in both objects
* - Requires both objects to have the same set of keys; different keys result in `false`
* - All property values must be equivalent according to the provided equivalence
* - Supports both string and symbol keys (via `Reflect.ownKeys`)
* - Empty objects are considered equivalent
* - The result is also an equivalence (satisfies reflexive, symmetric, transitive properties)
*
* **Example** (Record with string values)
*
* ```ts
* import { Equivalence } from "effect"
*
* const stringRecordEq = Equivalence.Record(Equivalence.strictEqual<string>())
*
* const record1 = { a: "hello", b: "world" }
* const record2 = { a: "hello", b: "world" }
* const record3 = { a: "hello", b: "different" }
* const record4 = { a: "hello" } // missing key 'b'
*
* console.log(stringRecordEq(record1, record2)) // true
* console.log(stringRecordEq(record1, record3)) // false
* console.log(stringRecordEq(record1, record4)) // false (different keys)
* ```
*
* **Example** (Record with number values)
*
* ```ts
* import { Equivalence } from "effect"
*
* const numberRecordEq = Equivalence.Record(Equivalence.strictEqual<number>())
*
* const scores1 = { alice: 100, bob: 85 }
* const scores2 = { alice: 100, bob: 85 }
* const scores3 = { alice: 100, bob: 90 }
*
* console.log(numberRecordEq(scores1, scores2)) // true
* console.log(numberRecordEq(scores1, scores3)) // false
* ```
*
* See also: {@link Struct}, {@link Array}
*
* @category combinators
* @since 4.0.0
*/
function Record(value) {
	return make$2((self, that) => {
		const selfKeys = Reflect.ownKeys(self);
		const thatKeys = Reflect.ownKeys(that);
		if (selfKeys.length !== thatKeys.length) return false;
		for (const key of selfKeys) if (!Object.hasOwn(that, key) || !value(self[key], that[key])) return false;
		return true;
	});
}
/**
* Creates a `Reducer` for combining `Equivalence` instances, useful for aggregating equivalences in collections.
*
* When to use this:
* - When you need to combine multiple equivalences from a collection using reducer patterns
* - When implementing fold operations over collections of equivalences
* - When working with reducers that operate on equivalences
*
* Behavior:
* - Returns a reducer that combines equivalences using {@link combine}
* - Uses an equivalence that always returns `true` as the identity element (for empty collections)
* - Uses {@link combineAll} for combining collections of equivalences
* - The reducer can be used with fold operations on collections
*
* **Example** (Creating a Reducer)
*
* ```ts
* import { Equivalence } from "effect"
*
* const reducer = Equivalence.makeReducer<number>()
* const equivalences = [
*   Equivalence.strictEqual<number>(),
*   Equivalence.make<number>((a, b) => Math.abs(a - b) < 1)
* ]
*
* const combined = reducer.combineAll(equivalences)
* // Combined equivalence requires both conditions to be true
* console.log(combined(1, 1)) // true (strict equal)
* console.log(combined(1, 1.5)) // false (strict equal fails)
* ```
*
* See also:
* - {@link combine} - Combine two equivalences
* - {@link combineAll} - Combine multiple equivalences
* - {@link Reducer} - Reducer type for collection operations
*
* @category utilities
* @since 4.0.0
*/
function makeReducer$2() {
	return make$3(combine$1, () => true, combineAll$1);
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/doNotation.js
/** @internal */
var let_$2 = (map) => dual(3, (self, name, f) => map(self, (a) => ({
	...a,
	[name]: f(a)
})));
/** @internal */
var bindTo$2 = (map) => dual(2, (self, name) => map(self, (a) => ({ [name]: a })));
/** @internal */
var bind$2 = (map, flatMap) => dual(3, (self, name, f) => flatMap(self, (a) => map(f(a), (b) => ({
	...a,
	[name]: b
}))));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Combiner.js
var Combiner_exports = /* @__PURE__ */ __exportAll({
	constant: () => constant,
	first: () => first,
	flip: () => flip$2,
	intercalate: () => intercalate,
	last: () => last,
	make: () => make$1,
	max: () => max$1,
	min: () => min$1
});
/**
* Creates a `Combiner` from a binary function.
*
* When to use:
* - You have a custom combining operation that is not covered by the built-in
*   constructors (`min`, `max`, `first`, `last`, `constant`).
*
* Behavior:
* - Returns a new `Combiner` whose `combine` method delegates to the provided
*   function.
* - Pure – the returned combiner does not mutate its arguments.
*
* **Example** (multiplying numbers)
*
* ```ts
* import { Combiner } from "effect"
*
* const Product = Combiner.make<number>((self, that) => self * that)
*
* console.log(Product.combine(3, 5))
* // Output: 15
* ```
*
* @see {@link Combiner} – the interface this creates
*
* @since 4.0.0
*/
function make$1(combine) {
	return { combine };
}
/**
* Reverses the argument order of a combiner's `combine` method.
*
* When to use:
* - You need the "right" value to act as the accumulator side.
* - You want to reverse the natural direction of a non-commutative combiner
*   (e.g. string concatenation).
*
* Behavior:
* - Returns a new `Combiner` where `combine(self, that)` calls the original
*   combiner as `combine(that, self)`.
* - Does not mutate the input combiner.
*
* **Example** (reversing string concatenation)
*
* ```ts
* import { Combiner, String } from "effect"
*
* const Prepend = Combiner.flip(String.ReducerConcat)
*
* console.log(Prepend.combine("a", "b"))
* // Output: "ba"
* ```
*
* @see {@link make}
*
* @since 4.0.0
*/
function flip$2(combiner) {
	return make$1((self, that) => combiner.combine(that, self));
}
/**
* Creates a `Combiner` that returns the smaller of two values according to
* the provided `Order`.
*
* When to use:
* - You want to accumulate the minimum value across a collection.
* - You are building a `Reducer` that tracks the running minimum.
*
* Behavior:
* - Compares using the given `Order`. When values are equal, returns `that`
*   (the second argument).
* - Pure – does not mutate either argument.
*
* **Example** (minimum of two numbers)
*
* ```ts
* import { Combiner, Number } from "effect"
*
* const Min = Combiner.min(Number.Order)
*
* console.log(Min.combine(3, 1))
* // Output: 1
*
* console.log(Min.combine(1, 3))
* // Output: 1
* ```
*
* @see {@link max}
*
* @since 4.0.0
*/
function min$1(order) {
	return make$1((self, that) => order(self, that) === -1 ? self : that);
}
/**
* Creates a `Combiner` that returns the larger of two values according to
* the provided `Order`.
*
* When to use:
* - You want to accumulate the maximum value across a collection.
* - You are building a `Reducer` that tracks the running maximum.
*
* Behavior:
* - Compares using the given `Order`. When values are equal, returns `that`
*   (the second argument).
* - Pure – does not mutate either argument.
*
* **Example** (maximum of two numbers)
*
* ```ts
* import { Combiner, Number } from "effect"
*
* const Max = Combiner.max(Number.Order)
*
* console.log(Max.combine(3, 1))
* // Output: 3
*
* console.log(Max.combine(1, 3))
* // Output: 3
* ```
*
* @see {@link min}
*
* @since 4.0.0
*/
function max$1(order) {
	return make$1((self, that) => order(self, that) === 1 ? self : that);
}
/**
* Creates a `Combiner` that always returns the first (left) argument.
*
* When to use:
* - You want "first write wins" semantics when merging values.
* - You need a combiner but the combining logic should be a no-op that keeps
*   the existing value.
*
* Behavior:
* - `combine(self, that)` returns `self`, ignoring `that`.
* - Pure – the second argument is discarded, not mutated.
*
* **Example** (keeping the first value)
*
* ```ts
* import { Combiner } from "effect"
*
* const First = Combiner.first<number>()
*
* console.log(First.combine(1, 2))
* // Output: 1
* ```
*
* @see {@link last}
*
* @since 4.0.0
*/
function first() {
	return make$1((self, _) => self);
}
/**
* Creates a `Combiner` that always returns the last (right) argument.
*
* When to use:
* - You want "last write wins" semantics when merging values.
* - You need a combiner that replaces the accumulator with each new value.
*
* Behavior:
* - `combine(self, that)` returns `that`, ignoring `self`.
* - Pure – the first argument is discarded, not mutated.
*
* **Example** (keeping the last value)
*
* ```ts
* import { Combiner } from "effect"
*
* const Last = Combiner.last<number>()
*
* console.log(Last.combine(1, 2))
* // Output: 2
* ```
*
* @see {@link first}
*
* @since 4.0.0
*/
function last() {
	return make$1((_, that) => that);
}
/**
* Creates a `Combiner` that ignores both arguments and always returns the
* given constant value.
*
* When to use:
* - You need a combiner that produces a fixed result regardless of input.
* - You are providing a combiner to a generic API but the combined value is
*   predetermined.
*
* Behavior:
* - `combine(self, that)` returns the constant `a`, ignoring both arguments.
* - Pure – no mutation occurs.
*
* **Example** (always returning zero)
*
* ```ts
* import { Combiner } from "effect"
*
* const Zero = Combiner.constant(0)
*
* console.log(Zero.combine(42, 99))
* // Output: 0
* ```
*
* @see {@link first}
* @see {@link last}
*
* @since 4.0.0
*/
function constant(a) {
	return make$1(() => a);
}
/**
* Wraps a `Combiner` so that a separator value is inserted between every
* pair of combined elements.
*
* When to use:
* - You are building delimited strings (CSV, paths, etc.) by repeated
*   combination.
* - You need to inject a fixed separator between accumulated values.
*
* Behavior:
* - `intercalate(middle)(combiner).combine(self, that)` is equivalent to
*   `combiner.combine(self, combiner.combine(middle, that))`.
* - Curried: first provide the separator, then the base combiner.
* - Does not mutate the input combiner; returns a new one.
*
* **Example** (joining strings with a separator)
*
* ```ts
* import { Combiner, String } from "effect"
*
* const commaSep = Combiner.intercalate(",")(String.ReducerConcat)
*
* console.log(commaSep.combine("a", "b"))
* // Output: "a,b"
* ```
*
* @see {@link make}
*
* @since 4.0.0
*/
function intercalate(middle) {
	return (combiner) => make$1((self, that) => combiner.combine(self, combiner.combine(middle, that)));
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Redactable.js
/**
* @since 4.0.0
*/
var Redactable_exports = /* @__PURE__ */ __exportAll({
	currentFiberTypeId: () => currentFiberTypeId,
	getRedacted: () => getRedacted,
	isRedactable: () => isRedactable,
	redact: () => redact,
	symbolRedactable: () => symbolRedactable
});
/**
* Symbol used to identify objects that implement redaction capabilities.
*
* @since 4.0.0
* @category symbol
*/
var symbolRedactable = /*#__PURE__*/ Symbol.for("~effect/Inspectable/redactable");
/**
* Checks if a value implements the `Redactable` interface.
*
* This function determines whether a given value has redaction capabilities,
* meaning it can provide alternative representations based on context.
*
* @param u - The value to check
*
* @example
* ```ts
* import { Redactable } from "effect"
*
* class RedactableSecret {
*   [Redactable.symbolRedactable]() {
*     return "[REDACTED]"
*   }
* }
*
* const secret = new RedactableSecret()
* const normal = { value: 42 }
*
* console.log(Redactable.isRedactable(secret)) // true
* console.log(Redactable.isRedactable(normal)) // false
* console.log(Redactable.isRedactable("string")) // false
* ```
*
* @since 4.0.0
* @category redactable
*/
var isRedactable = (u) => hasProperty(u, symbolRedactable);
/**
* Applies redaction to a value if it implements the Redactable interface.
*
* This function checks if the value is redactable and applies the redaction
* transformation if a current fiber context is available. Otherwise, it returns
* the value unchanged.
*
* @param u - The value to potentially redact
*
* @example
* ```ts
* import { Redactable } from "effect"
*
* class CreditCard {
*   constructor(private number: string) {}
*
*   [Redactable.symbolRedactable]() {
*     return {
*       number: this.number.slice(0, 4) + "****"
*     }
*   }
* }
*
* const card = new CreditCard("1234567890123456")
* console.log(Redactable.redact(card)) // { number: "1234****" }
*
* // Non-redactable values are returned unchanged
* console.log(Redactable.redact("normal string")) // "normal string"
* console.log(Redactable.redact({ id: 123 })) // { id: 123 }
* ```
*
* @since 4.0.0
*/
function redact(u) {
	if (isRedactable(u)) return getRedacted(u);
	return u;
}
/**
* @since 4.0.0
*/
function getRedacted(redactable) {
	return redactable[symbolRedactable](globalThis["~effect/Fiber/currentFiber"]?.services ?? emptyServiceMap);
}
/** @internal */
var currentFiberTypeId = "~effect/Fiber/currentFiber";
var emptyServiceMap = {
	"~effect/ServiceMap": {},
	mapUnsafe: /*#__PURE__*/ new Map(),
	pipe() {
		return pipeArguments(this, arguments);
	}
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Formatter.js
/**
* Utilities for converting arbitrary JavaScript values into human-readable
* strings, with support for circular references, redaction, and common JS
* types that `JSON.stringify` handles poorly.
*
* Mental model:
* - A `Formatter<Value, Format>` is a callable `(value: Value) => Format`.
* - {@link format} is the general-purpose pretty-printer: it handles
*   primitives, arrays, objects, `BigInt`, `Symbol`, `Date`, `RegExp`,
*   `Set`, `Map`, class instances, and circular references.
* - {@link formatJson} is a safe `JSON.stringify` wrapper that silently
*   drops circular references and applies redaction.
* - Both functions accept a `space` option for indentation control.
*
* Common tasks:
* - Pretty-print any value for debugging / logging -> {@link format}
* - Serialize to JSON safely (no circular throws) -> {@link formatJson}
* - Format a single object property key -> {@link formatPropertyKey}
* - Format a property path like `["a"]["b"]` -> {@link formatPath}
* - Format a `Date` to ISO string safely -> {@link formatDate}
*
* Gotchas:
* - {@link format} output is **not** valid JSON; use {@link formatJson} when
*   you need parseable JSON.
* - {@link format} calls `toString()` on objects by default; pass
*   `ignoreToString: true` to disable.
* - {@link formatJson} silently omits circular references (the key is
*   dropped from the output).
* - Values implementing the `Redactable` protocol are automatically
*   redacted by both {@link format} and {@link formatJson}.
*
* **Example** (Pretty-print a value)
*
* ```ts
* import { Formatter } from "effect"
*
* const obj = { name: "Alice", scores: [100, 97] }
* console.log(Formatter.format(obj))
* // {"name":"Alice","scores":[100,97]}
*
* console.log(Formatter.format(obj, { space: 2 }))
* // {
* //   "name": "Alice",
* //   "scores": [
* //     100,
* //     97
* //   ]
* // }
* ```
*
* See also: {@link Formatter}, {@link format}, {@link formatJson}
*
* @since 4.0.0
*/
var Formatter_exports = /* @__PURE__ */ __exportAll({
	format: () => format,
	formatDate: () => formatDate,
	formatJson: () => formatJson,
	formatPath: () => formatPath,
	formatPropertyKey: () => formatPropertyKey
});
/**
* Converts any JavaScript value into a human-readable string.
*
* When to use:
* - Pretty-printing values for debugging, logging, or error messages.
* - You need to handle `BigInt`, `Symbol`, `Set`, `Map`, `Date`, `RegExp`,
*   or class instances that `JSON.stringify` cannot represent.
* - You want circular references shown as `"[Circular]"` instead of
*   throwing.
*
* Behavior:
* - Does not mutate input.
* - Output is **not** valid JSON; use {@link formatJson} when you need
*   parseable JSON.
* - Primitives: stringified naturally (`null`, `undefined`, `123`, `true`).
*   Strings are JSON-quoted.
* - Objects with a custom `toString` (not `Object.prototype.toString`):
*   `toString()` is called unless `ignoreToString` is `true`.
* - Errors with a `cause`: formatted as `"<message> (cause: <cause>)"`.
* - Iterables (`Set`, `Map`, etc.): formatted as
*   `ClassName([...elements])`.
* - Class instances: wrapped as `ClassName({...})`.
* - `Redactable` values are automatically redacted.
* - Arrays/objects with 0–1 entries are inline; larger ones are
*   pretty-printed when `space` is set.
* - Circular references are replaced with `"[Circular]"`.
*
* Options:
* - `space` — indentation unit (number of spaces, or a string like
*   `"\t"`). Defaults to `0` (compact).
* - `ignoreToString` — skip calling `toString()`. Defaults to `false`.
*
* **Example** (Compact output)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.format({ a: 1, b: [2, 3] }))
* // {"a":1,"b":[2,3]}
* ```
*
* **Example** (Pretty-printed output)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.format({ a: 1, b: [2, 3] }, { space: 2 }))
* // {
* //   "a": 1,
* //   "b": [
* //     2,
* //     3
* //   ]
* // }
* ```
*
* **Example** (Circular reference handling)
*
* ```ts
* import { Formatter } from "effect"
*
* const obj: any = { name: "loop" }
* obj.self = obj
* console.log(Formatter.format(obj))
* // {"name":"loop","self":[Circular]}
* ```
*
* See also: {@link formatJson}, {@link Formatter}
*
* @since 4.0.0
*/
function format(input, options) {
	const space = options?.space ?? 0;
	const seen = /* @__PURE__ */ new WeakSet();
	const gap = !space ? "" : typeof space === "number" ? " ".repeat(space) : space;
	const ind = (d) => gap.repeat(d);
	const wrap = (v, body) => {
		const ctor = v?.constructor;
		return ctor && ctor !== Object.prototype.constructor && ctor.name ? `${ctor.name}(${body})` : body;
	};
	const ownKeys = (o) => {
		try {
			return Reflect.ownKeys(o);
		} catch {
			return ["[ownKeys threw]"];
		}
	};
	function recur(v, d = 0) {
		if (Array.isArray(v)) {
			if (seen.has(v)) return CIRCULAR;
			seen.add(v);
			if (!gap || v.length <= 1) return `[${v.map((x) => recur(x, d)).join(",")}]`;
			const inner = v.map((x) => recur(x, d + 1)).join(",\n" + ind(d + 1));
			return `[\n${ind(d + 1)}${inner}\n${ind(d)}]`;
		}
		if (v instanceof Date) return formatDate(v);
		if (!options?.ignoreToString && hasProperty(v, "toString") && typeof v["toString"] === "function" && v["toString"] !== Object.prototype.toString && v["toString"] !== Array.prototype.toString) {
			const s = safeToString(v);
			if (v instanceof Error && v.cause) return `${s} (cause: ${recur(v.cause, d)})`;
			return s;
		}
		if (typeof v === "string") return JSON.stringify(v);
		if (typeof v === "number" || v == null || typeof v === "boolean" || typeof v === "symbol") return String(v);
		if (typeof v === "bigint") return String(v) + "n";
		if (typeof v === "object" || typeof v === "function") {
			if (seen.has(v)) return CIRCULAR;
			seen.add(v);
			if (symbolRedactable in v) return format(getRedacted(v));
			if (Symbol.iterator in v) return `${v.constructor.name}(${recur(Array.from(v), d)})`;
			const keys = ownKeys(v);
			if (!gap || keys.length <= 1) {
				const body = `{${keys.map((k) => `${formatPropertyKey(k)}:${recur(v[k], d)}`).join(",")}}`;
				return wrap(v, body);
			}
			const body = `{\n${keys.map((k) => `${ind(d + 1)}${formatPropertyKey(k)}: ${recur(v[k], d + 1)}`).join(",\n")}\n${ind(d)}}`;
			return wrap(v, body);
		}
		return String(v);
	}
	return recur(input, 0);
}
var CIRCULAR = "[Circular]";
/**
* Formats a single property key for display.
*
* When to use:
* - You are building a custom formatter that needs to render object keys.
*
* Behavior:
* - String keys are JSON-quoted (e.g. `"foo"`).
* - Symbol and number keys are converted with `String()`.
* - Pure function; does not mutate input.
*
* **Example** (Format property keys)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.formatPropertyKey("name"))
* // "name"
*
* console.log(Formatter.formatPropertyKey(Symbol.for("id")))
* // Symbol(id)
* ```
*
* See also: {@link formatPath}, {@link format}
*
* @internal
*/
function formatPropertyKey(name) {
	return typeof name === "string" ? JSON.stringify(name) : String(name);
}
/**
* Formats an array of property keys as a bracket-notation path string.
*
* When to use:
* - You need to display a path through a nested object (e.g. in error
*   messages or schema validation output).
*
* Behavior:
* - Each key is wrapped in brackets and formatted via
*   {@link formatPropertyKey}.
* - Returns an empty string for an empty path.
* - Pure function; does not mutate input.
*
* **Example** (Render a property path)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.formatPath(["users", 0, "name"]))
* // ["users"][0]["name"]
* ```
*
* See also: {@link formatPropertyKey}, {@link format}
*
* @internal
*/
function formatPath(path) {
	return path.map((key) => `[${formatPropertyKey(key)}]`).join("");
}
/**
* Formats a `Date` as an ISO 8601 string, returning `"Invalid Date"` for
* invalid dates instead of throwing.
*
* When to use:
* - You want a safe `toISOString()` that never throws.
*
* Behavior:
* - Returns `date.toISOString()` on success.
* - Returns `"Invalid Date"` if `toISOString()` throws (e.g. for
*   `new Date(NaN)`).
* - Pure function; does not mutate input.
*
* **Example** (Safe date formatting)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.formatDate(new Date("2024-01-15T10:30:00Z")))
* // 2024-01-15T10:30:00.000Z
*
* console.log(Formatter.formatDate(new Date("invalid")))
* // Invalid Date
* ```
*
* See also: {@link format}
*
* @internal
*/
function formatDate(date) {
	try {
		return date.toISOString();
	} catch {
		return "Invalid Date";
	}
}
function safeToString(input) {
	try {
		const s = input.toString();
		return typeof s === "string" ? s : String(s);
	} catch {
		return "[toString threw]";
	}
}
/**
* Safely stringifies a value to JSON, silently dropping circular references.
*
* When to use:
* - You need valid JSON output (unlike {@link format}).
* - The input may contain circular references and you want them silently
*   omitted rather than throwing a `TypeError`.
*
* Behavior:
* - Does not mutate input.
* - Uses `JSON.stringify` internally with a replacer that tracks seen
*   objects.
* - Circular references are replaced with `undefined` (omitted from
*   output).
* - `Redactable` values are automatically redacted before serialization.
* - Types not supported by JSON (`BigInt`, `Symbol`, `undefined`,
*   functions) follow standard `JSON.stringify` behavior (omitted or
*   `null` in arrays).
*
* Options:
* - `space` — indentation unit (number of spaces, or a string like
*   `"\t"`). Defaults to `0` (compact).
*
* **Example** (Compact JSON)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.formatJson({ name: "Alice", age: 30 }))
* // {"name":"Alice","age":30}
* ```
*
* **Example** (Circular reference handling)
*
* ```ts
* import { Formatter } from "effect"
*
* const obj: any = { name: "test" }
* obj.self = obj
* console.log(Formatter.formatJson(obj))
* // {"name":"test"}
* ```
*
* **Example** (Pretty-printed JSON)
*
* ```ts
* import { Formatter } from "effect"
*
* console.log(Formatter.formatJson({ name: "Alice", age: 30 }, { space: 2 }))
* // {
* //   "name": "Alice",
* //   "age": 30
* // }
* ```
*
* See also: {@link format}, {@link Formatter}
*
* @since 4.0.0
*/
function formatJson(input, options) {
	let cache = [];
	const out = JSON.stringify(input, (_key, value) => typeof value === "object" && value !== null ? cache.includes(value) ? void 0 : cache.push(value) && redact(value) : value, options?.space);
	cache = void 0;
	return out;
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Inspectable.js
/**
* This module provides utilities for making values inspectable and debuggable in TypeScript.
*
* The Inspectable interface provides a standard way to implement custom string representations
* for objects, making them easier to debug and inspect. It includes support for JSON
* serialization, Node.js inspection, and safe circular reference handling.
*
* The module also includes redaction capabilities for sensitive data, allowing objects
* to provide different representations based on the current execution context.
*
* @example
* ```ts
* import { Inspectable } from "effect"
* import { format } from "effect/Formatter"
*
* class User extends Inspectable.Class {
*   constructor(
*     public readonly name: string,
*     public readonly email: string
*   ) {
*     super()
*   }
*
*   toJSON() {
*     return {
*       _tag: "User",
*       name: this.name,
*       email: this.email
*     }
*   }
* }
*
* const user = new User("Alice", "alice@example.com")
* console.log(user.toString()) // Pretty printed JSON
* console.log(format(user)) // Same as toString()
* ```
*
* @since 2.0.0
*/
var Inspectable_exports = /* @__PURE__ */ __exportAll({
	BaseProto: () => BaseProto,
	Class: () => Class,
	NodeInspectSymbol: () => NodeInspectSymbol,
	stringifyCircular: () => stringifyCircular,
	toJson: () => toJson,
	toStringUnknown: () => toStringUnknown
});
/**
* Symbol used by Node.js for custom object inspection.
*
* This symbol is recognized by Node.js's `util.inspect()` function and the REPL
* for custom object representation. When an object has a method with this symbol,
* it will be called to determine how the object should be displayed.
*
* @example
* ```ts
* import { Inspectable } from "effect"
*
* class CustomObject {
*   constructor(private value: string) {}
*
*   [Inspectable.NodeInspectSymbol]() {
*     return `CustomObject(${this.value})`
*   }
* }
*
* const obj = new CustomObject("hello")
* console.log(obj) // Displays: CustomObject(hello)
* ```
*
* @since 2.0.0
* @category symbols
*/
var NodeInspectSymbol = /*#__PURE__*/ Symbol.for("nodejs.util.inspect.custom");
/**
* Safely converts a value to a JSON-serializable representation, useful for
* implementing the `toJSON` method of the {@link Inspectable} interface.
*
* This function attempts to extract JSON data from objects that implement the
* `toJSON` method, recursively processes arrays, and handles errors gracefully.
* For objects that don't have a `toJSON` method, it applies redaction to
* protect sensitive information.
*
* @since 2.0.0
*/
var toJson = (input) => {
	try {
		if (hasProperty(input, "toJSON") && isFunction(input["toJSON"]) && input["toJSON"].length === 0) return input.toJSON();
		else if (Array.isArray(input)) return input.map(toJson);
	} catch {
		return "[toJSON threw]";
	}
	return redact(input);
};
/**
* @since 2.0.0
*/
var toStringUnknown = (u, whitespace = 2) => {
	if (typeof u === "string") return u;
	try {
		return typeof u === "object" ? stringifyCircular(u, whitespace) : String(u);
	} catch {
		return String(u);
	}
};
/**
* @since 2.0.0
*/
var stringifyCircular = (obj, whitespace) => {
	let cache = [];
	const retVal = JSON.stringify(obj, (_key, value) => typeof value === "object" && value !== null ? cache.includes(value) ? void 0 : cache.push(value) && redact(value) : value, whitespace);
	cache = void 0;
	return retVal;
};
/**
* A base prototype object that implements the {@link Inspectable} interface.
*
* This object provides default implementations for the {@link Inspectable} methods.
* It can be used as a prototype for objects that want to be inspectable,
* or as a mixin to add inspection capabilities to existing objects.
*
* @example
* ```ts
* import { Inspectable } from "effect"
*
* // Use as prototype
* const myObject = Object.create(Inspectable.BaseProto)
* myObject.name = "example"
* myObject.value = 42
*
* console.log(myObject.toString()) // Pretty printed representation
*
* // Or extend in a constructor
* function MyClass(this: any, name: string) {
*   this.name = name
* }
* MyClass.prototype = Object.create(Inspectable.BaseProto)
* MyClass.prototype.constructor = MyClass
* ```
*
* @since 2.0.0
*/
var BaseProto = {
	toJSON() {
		return toJson(this);
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	toString() {
		return format(this.toJSON());
	}
};
/**
* Abstract base class that implements the Inspectable interface.
*
* This class provides a convenient way to create inspectable objects by extending it.
* Subclasses only need to implement the `toJSON()` method, and they automatically
* get proper `toString()` and Node.js inspection support.
*
* @example
* ```ts
* import { Inspectable } from "effect"
*
* class User extends Inspectable.Class {
*   constructor(
*     public readonly id: number,
*     public readonly name: string,
*     public readonly email: string
*   ) {
*     super()
*   }
*
*   toJSON() {
*     return {
*       _tag: "User",
*       id: this.id,
*       name: this.name,
*       email: this.email
*     }
*   }
* }
*
* const user = new User(1, "Alice", "alice@example.com")
* console.log(user.toString()) // Pretty printed JSON with _tag, id, name, email
* console.log(user) // In Node.js, shows the same formatted output
* ```
*
* @since 2.0.0
* @category classes
*/
var Class = class {
	/**
	* Node.js custom inspection method.
	*
	* @since 2.0.0
	*/
	[NodeInspectSymbol]() {
		return this.toJSON();
	}
	/**
	* Returns a formatted string representation of this object.
	*
	* @since 2.0.0
	*/
	toString() {
		return format(this.toJSON());
	}
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Utils.js
/**
* @since 2.0.0
*/
var Utils_exports = /* @__PURE__ */ __exportAll({
	SingleShotGen: () => SingleShotGen,
	internalCall: () => internalCall,
	isGenKind: () => isGenKind,
	isGeneratorFunction: () => isGeneratorFunction,
	makeGenKind: () => makeGenKind
});
/**
* @since 2.0.0
*/
var GenKindTypeId = "~effect/Utils/GenKind";
/**
* @category predicates
* @since 3.0.6
*/
var isGenKind = (u) => isObject(u) && GenKindTypeId in u;
var GenKindImpl = class {
	value;
	constructor(value) {
		this.value = value;
	}
	get _F() {
		return identity;
	}
	get _R() {
		return (_) => _;
	}
	get _O() {
		return (_) => _;
	}
	get _E() {
		return (_) => _;
	}
	[GenKindTypeId] = GenKindTypeId;
	[Symbol.iterator]() {
		return new SingleShotGen(this);
	}
};
/**
* @category constructors
* @since 2.0.0
*/
var SingleShotGen = class SingleShotGen {
	called = false;
	self;
	constructor(self) {
		this.self = self;
	}
	/**
	* @since 2.0.0
	*/
	next(a) {
		return this.called ? {
			value: a,
			done: true
		} : (this.called = true, {
			value: this.self,
			done: false
		});
	}
	/**
	* @since 2.0.0
	*/
	[Symbol.iterator]() {
		return new SingleShotGen(this.self);
	}
};
/**
* @category constructors
* @since 2.0.0
*/
var makeGenKind = (kind) => new GenKindImpl(kind);
var InternalTypeId = "~effect/Effect/internal";
var standard = { [InternalTypeId]: (body) => {
	return body();
} };
var forced = { [InternalTypeId]: (body) => {
	try {
		return body();
	} finally {}
} };
/**
* @since 3.2.2
* @status experimental
* @category tracing
*/
var internalCall = /*#__PURE__*/ standard[InternalTypeId](() => (/* @__PURE__ */ new Error()).stack)?.includes(InternalTypeId) === true ? standard[InternalTypeId] : forced[InternalTypeId];
var genConstructor = function* () {}.constructor;
/**
* @example
* ```ts
* import { Utils } from "effect"
*
* function* generatorFn() {
*   yield 1
*   yield 2
* }
*
* console.log(Utils.isGeneratorFunction(generatorFn)) // true
* console.log(Utils.isGeneratorFunction(() => {})) // false
* ```
*
* @category predicates
* @since 3.11.0
*/
var isGeneratorFunction = (u) => isObject(u) && u.constructor === genConstructor;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/core.js
/** @internal */
var EffectTypeId = `~effect/Effect`;
/** @internal */
var ExitTypeId = `~effect/Exit`;
var effectVariance = {
	_A: identity,
	_E: identity,
	_R: identity
};
/** @internal */
var identifier = `${EffectTypeId}/identifier`;
/** @internal */
var args = `${EffectTypeId}/args`;
/** @internal */
var evaluate = `${EffectTypeId}/evaluate`;
/** @internal */
var contA = `${EffectTypeId}/successCont`;
/** @internal */
var contE = `${EffectTypeId}/failureCont`;
/** @internal */
var contAll = `${EffectTypeId}/ensureCont`;
/** @internal */
var Yield = /*#__PURE__*/ Symbol.for("effect/Effect/Yield");
/** @internal */
var PipeInspectableProto = {
	pipe() {
		return pipeArguments(this, arguments);
	},
	toJSON() {
		return { ...this };
	},
	toString() {
		return format(this.toJSON(), {
			ignoreToString: true,
			space: 2
		});
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	}
};
/** @internal */
var StructuralProto = {
	[symbol]() {
		return structureKeys(this, Object.keys(this));
	},
	[symbol$1](that) {
		const selfKeys = Object.keys(this);
		const thatKeys = Object.keys(that);
		if (selfKeys.length !== thatKeys.length) return false;
		for (let i = 0; i < selfKeys.length; i++) if (selfKeys[i] !== thatKeys[i] && !equals(this[selfKeys[i]], that[selfKeys[i]])) return false;
		return true;
	}
};
/** @internal */
var YieldableProto = { [Symbol.iterator]() {
	return new SingleShotGen(this);
} };
/** @internal */
var YieldableErrorProto = {
	...YieldableProto,
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/** @internal */
var EffectProto = {
	[EffectTypeId]: effectVariance,
	...PipeInspectableProto,
	[Symbol.iterator]() {
		return new SingleShotGen(this);
	},
	asEffect() {
		return this;
	},
	toJSON() {
		return {
			_id: "Effect",
			op: this[identifier],
			...args in this ? { args: this[args] } : void 0
		};
	}
};
/** @internal */
var isEffect = (u) => hasProperty(u, EffectTypeId);
/** @internal */
var isExit = (u) => hasProperty(u, ExitTypeId);
/** @internal */
var CauseTypeId = "~effect/Cause";
/** @internal */
var CauseReasonTypeId = "~effect/Cause/Reason";
/** @internal */
var isCause = (self) => hasProperty(self, CauseTypeId);
/** @internal */
var isCauseReason = (self) => hasProperty(self, CauseReasonTypeId);
/** @internal */
var CauseImpl = class {
	[CauseTypeId];
	reasons;
	constructor(failures) {
		this[CauseTypeId] = CauseTypeId;
		this.reasons = failures;
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
	toJSON() {
		return {
			_id: "Cause",
			failures: this.reasons.map((f) => f.toJSON())
		};
	}
	toString() {
		return `Cause(${format(this.reasons)})`;
	}
	[NodeInspectSymbol]() {
		return this.toJSON();
	}
	[symbol$1](that) {
		return isCause(that) && this.reasons.length === that.reasons.length && this.reasons.every((e, i) => equals(e, that.reasons[i]));
	}
	[symbol]() {
		return array(this.reasons);
	}
};
var annotationsMap = /*#__PURE__*/ new WeakMap();
/** @internal */
var ReasonBase = class {
	[CauseReasonTypeId];
	annotations;
	_tag;
	constructor(_tag, annotations, originalError) {
		this[CauseReasonTypeId] = CauseReasonTypeId;
		this._tag = _tag;
		if (annotations !== constEmptyAnnotations && typeof originalError === "object" && originalError !== null && annotations.size > 0) {
			const prevAnnotations = annotationsMap.get(originalError);
			if (prevAnnotations) annotations = new Map([...prevAnnotations, ...annotations]);
			annotationsMap.set(originalError, annotations);
		}
		this.annotations = annotations;
	}
	annotate(annotations, options) {
		if (annotations.mapUnsafe.size === 0) return this;
		const newAnnotations = new Map(this.annotations);
		annotations.mapUnsafe.forEach((value, key) => {
			if (options?.overwrite !== true && newAnnotations.has(key)) return;
			newAnnotations.set(key, value);
		});
		const self = Object.assign(Object.create(Object.getPrototypeOf(this)), this);
		self.annotations = newAnnotations;
		return self;
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
	toString() {
		return format(this);
	}
	[NodeInspectSymbol]() {
		return this.toString();
	}
};
/** @internal */
var constEmptyAnnotations = /*#__PURE__*/ new Map();
/** @internal */
var Fail = class extends ReasonBase {
	error;
	constructor(error, annotations = constEmptyAnnotations) {
		super("Fail", annotations, error);
		this.error = error;
	}
	toString() {
		return `Fail(${format(this.error)})`;
	}
	toJSON() {
		return {
			_tag: "Fail",
			error: this.error
		};
	}
	[symbol$1](that) {
		return isFailReason(that) && equals(this.error, that.error) && equals(this.annotations, that.annotations);
	}
	[symbol]() {
		return combine$2(string(this._tag))(combine$2(hash(this.error))(hash(this.annotations)));
	}
};
/** @internal */
var causeFromReasons = (reasons) => new CauseImpl(reasons);
/** @internal */
var causeEmpty = /*#__PURE__*/ new CauseImpl([]);
/** @internal */
var causeFail = (error) => new CauseImpl([new Fail(error)]);
/** @internal */
var Die = class extends ReasonBase {
	defect;
	constructor(defect, annotations = constEmptyAnnotations) {
		super("Die", annotations, defect);
		this.defect = defect;
	}
	toString() {
		return `Die(${format(this.defect)})`;
	}
	toJSON() {
		return {
			_tag: "Die",
			defect: this.defect
		};
	}
	[symbol$1](that) {
		return isDieReason(that) && equals(this.defect, that.defect) && equals(this.annotations, that.annotations);
	}
	[symbol]() {
		return combine$2(string(this._tag))(combine$2(hash(this.defect))(hash(this.annotations)));
	}
};
/** @internal */
var causeDie = (defect) => new CauseImpl([new Die(defect)]);
/** @internal */
var causeAnnotate = /*#__PURE__*/ dual((args) => isCause(args[0]), (self, annotations, options) => {
	if (annotations.mapUnsafe.size === 0) return self;
	return new CauseImpl(self.reasons.map((f) => f.annotate(annotations, options)));
});
/** @internal */
var isFailReason = (self) => self._tag === "Fail";
/** @internal */
var isDieReason = (self) => self._tag === "Die";
/** @internal */
var isInterruptReason = (self) => self._tag === "Interrupt";
function defaultEvaluate(_fiber) {
	return exitDie(`Effect.evaluate: Not implemented`);
}
/** @internal */
var makePrimitiveProto = (options) => ({
	...EffectProto,
	[identifier]: options.op,
	[evaluate]: options[evaluate] ?? defaultEvaluate,
	[contA]: options[contA],
	[contE]: options[contE],
	[contAll]: options[contAll]
});
/** @internal */
var makePrimitive = (options) => {
	const Proto = makePrimitiveProto(options);
	return function() {
		const self = Object.create(Proto);
		self[args] = options.single === false ? arguments : arguments[0];
		return self;
	};
};
/** @internal */
var makeExit = (options) => {
	const Proto = {
		...makePrimitiveProto(options),
		[ExitTypeId]: ExitTypeId,
		_tag: options.op,
		get [options.prop]() {
			return this[args];
		},
		toString() {
			return `${options.op}(${format(this[args])})`;
		},
		toJSON() {
			return {
				_id: "Exit",
				_tag: options.op,
				[options.prop]: this[args]
			};
		},
		[symbol$1](that) {
			return isExit(that) && that._tag === this._tag && equals(this[args], that[args]);
		},
		[symbol]() {
			return combine$2(string(options.op), hash(this[args]));
		}
	};
	return function(value) {
		const self = Object.create(Proto);
		self[args] = value;
		return self;
	};
};
/** @internal */
var exitSucceed = /*#__PURE__*/ makeExit({
	op: "Success",
	prop: "value",
	[evaluate](fiber) {
		const cont = fiber.getCont(contA);
		return cont ? cont[contA](this[args], fiber, this) : fiber.yieldWith(this);
	}
});
/** @internal */
var StackTraceKey = { key: "effect/Cause/StackTrace" };
/** @internal */
var InterruptorStackTrace = { key: "effect/Cause/InterruptorStackTrace" };
/** @internal */
var exitFailCause = /*#__PURE__*/ makeExit({
	op: "Failure",
	prop: "cause",
	[evaluate](fiber) {
		let cause = this[args];
		let annotated = false;
		if (fiber.currentStackFrame) {
			cause = causeAnnotate(cause, { mapUnsafe: /* @__PURE__ */ new Map([[StackTraceKey.key, fiber.currentStackFrame]]) });
			annotated = true;
		}
		let cont = fiber.getCont(contE);
		while (fiber.interruptible && fiber._interruptedCause && cont) cont = fiber.getCont(contE);
		return cont ? cont[contE](cause, fiber, annotated ? void 0 : this) : fiber.yieldWith(annotated ? this : exitFailCause(cause));
	}
});
/** @internal */
var exitFail = (e) => exitFailCause(causeFail(e));
/** @internal */
var exitDie = (defect) => exitFailCause(causeDie(defect));
/** @internal */
var withFiber = /*#__PURE__*/ makePrimitive({
	op: "WithFiber",
	[evaluate](fiber) {
		return this[args](fiber);
	}
});
/** @internal */
var YieldableError = /*#__PURE__*/ function() {
	class YieldableError extends globalThis.Error {
		asEffect() {
			return exitFail(this);
		}
	}
	Object.assign(YieldableError.prototype, YieldableErrorProto);
	return YieldableError;
}();
/** @internal */
var Error$1 = /*#__PURE__*/ function() {
	const plainArgsSymbol = /*#__PURE__*/ Symbol.for("effect/Data/Error/plainArgs");
	return class Base extends YieldableError {
		constructor(args) {
			super(args?.message, args?.cause ? { cause: args.cause } : void 0);
			if (args) {
				Object.assign(this, args);
				Object.defineProperty(this, plainArgsSymbol, {
					value: args,
					enumerable: false
				});
			}
		}
		toJSON() {
			return {
				...this[plainArgsSymbol],
				...this
			};
		}
	};
}();
/** @internal */
var TaggedError = (tag) => {
	class Base extends Error$1 {
		_tag = tag;
	}
	Base.prototype.name = tag;
	return Base;
};
/** @internal */
var NoSuchElementErrorTypeId = "~effect/Cause/NoSuchElementError";
/** @internal */
var isNoSuchElementError = (u) => hasProperty(u, NoSuchElementErrorTypeId);
/** @internal */
var NoSuchElementError = class extends TaggedError("NoSuchElementError") {
	[NoSuchElementErrorTypeId] = NoSuchElementErrorTypeId;
	constructor(message) {
		super({ message });
	}
};
/** @internal */
var DoneTypeId = "~effect/Cause/Done";
/** @internal */
var isDone = (u) => hasProperty(u, DoneTypeId);
var DoneVoid = {
	[DoneTypeId]: DoneTypeId,
	_tag: "Done",
	value: void 0
};
/** @internal */
var Done = (value) => {
	if (value === void 0) return DoneVoid;
	return {
		[DoneTypeId]: DoneTypeId,
		_tag: "Done",
		value
	};
};
var doneVoid = /*#__PURE__*/ exitFail(DoneVoid);
/** @internal */
var done = (value) => {
	if (value === void 0) return doneVoid;
	return exitFail(Done(value));
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/option.js
/**
* @since 2.0.0
*/
var TypeId$1 = "~effect/data/Option";
var CommonProto$1 = {
	[TypeId$1]: { _A: (_) => _ },
	...PipeInspectableProto,
	...YieldableProto
};
var SomeProto = /*#__PURE__*/ Object.assign(/*#__PURE__*/ Object.create(CommonProto$1), {
	_tag: "Some",
	_op: "Some",
	[symbol$1](that) {
		return isOption$1(that) && isSome$1(that) && equals(this.value, that.value);
	},
	[symbol]() {
		return combine$2(hash(this._tag))(hash(this.value));
	},
	toString() {
		return `some(${format(this.value)})`;
	},
	toJSON() {
		return {
			_id: "Option",
			_tag: this._tag,
			value: toJson(this.value)
		};
	},
	asEffect() {
		return exitSucceed(this.value);
	}
});
var NoneHash = /*#__PURE__*/ hash("None");
var NoneProto = /*#__PURE__*/ Object.assign(/*#__PURE__*/ Object.create(CommonProto$1), {
	_tag: "None",
	_op: "None",
	[symbol$1](that) {
		return isOption$1(that) && isNone$1(that);
	},
	[symbol]() {
		return NoneHash;
	},
	toString() {
		return `none()`;
	},
	toJSON() {
		return {
			_id: "Option",
			_tag: this._tag
		};
	},
	asEffect() {
		return exitFail(new NoSuchElementError());
	}
});
/** @internal */
var isOption$1 = (input) => hasProperty(input, TypeId$1);
/** @internal */
var isNone$1 = (fa) => fa._tag === "None";
/** @internal */
var isSome$1 = (fa) => fa._tag === "Some";
/** @internal */
var none$1 = /*#__PURE__*/ Object.create(NoneProto);
/** @internal */
var some$2 = (value) => {
	const a = Object.create(SomeProto);
	a.value = value;
	return a;
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/result.js
var TypeId = "~effect/data/Result";
var CommonProto = {
	[TypeId]: {
		/* v8 ignore next 2 */
		_A: (_) => _,
		_E: (_) => _
	},
	...PipeInspectableProto,
	...YieldableProto
};
var SuccessProto = /*#__PURE__*/ Object.assign(/*#__PURE__*/ Object.create(CommonProto), {
	_tag: "Success",
	_op: "Success",
	[symbol$1](that) {
		return isResult$1(that) && isSuccess$1(that) && equals(this.success, that.success);
	},
	[symbol]() {
		return combine$2(hash(this._tag))(hash(this.success));
	},
	toString() {
		return `success(${format(this.success)})`;
	},
	toJSON() {
		return {
			_id: "Result",
			_tag: this._tag,
			value: toJson(this.success)
		};
	},
	asEffect() {
		return exitSucceed(this.success);
	}
});
var FailureProto = /*#__PURE__*/ Object.assign(/*#__PURE__*/ Object.create(CommonProto), {
	_tag: "Failure",
	_op: "Failure",
	[symbol$1](that) {
		return isResult$1(that) && isFailure$1(that) && equals(this.failure, that.failure);
	},
	[symbol]() {
		return combine$2(hash(this._tag))(hash(this.failure));
	},
	toString() {
		return `failure(${format(this.failure)})`;
	},
	toJSON() {
		return {
			_id: "Result",
			_tag: this._tag,
			failure: toJson(this.failure)
		};
	},
	asEffect() {
		return exitFail(this.failure);
	}
});
/** @internal */
var isResult$1 = (input) => hasProperty(input, TypeId);
/** @internal */
var isFailure$1 = (result) => result._tag === "Failure";
/** @internal */
var isSuccess$1 = (result) => result._tag === "Success";
/** @internal */
var fail$1 = (failure) => {
	const a = Object.create(FailureProto);
	a.failure = failure;
	return a;
};
/** @internal */
var succeed$1 = (success) => {
	const a = Object.create(SuccessProto);
	a.success = success;
	return a;
};
/** @internal */
var getFailure$2 = (self) => isSuccess$1(self) ? none$1 : some$2(self.failure);
/** @internal */
var getSuccess$2 = (self) => isFailure$1(self) ? none$1 : some$2(self.success);
/** @internal */
var fromOption$1 = /*#__PURE__*/ dual(2, (self, onNone) => isNone$1(self) ? fail$1(onNone()) : succeed$1(self.value));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Order.js
/**
* This module provides the `Order` type class for defining total orderings on types.
* An `Order` is a comparison function that returns `-1` (less than), `0` (equal), or `1` (greater than).
*
* Mental model:
* - An `Order<A>` is a pure function `(a: A, b: A) => Ordering` that compares two values
* - The result `-1` means the first value is less than the second
* - The result `0` means the values are equal according to this ordering
* - The result `1` means the first value is greater than the second
* - Orders must satisfy total ordering laws: totality (either `x <= y` or `y <= x`), antisymmetry (if `x <= y` and `y <= x` then `x == y`), and transitivity (if `x <= y` and `y <= z` then `x <= z`)
* - Orders can be composed using {@link combine} and {@link combineAll} to create multi-criteria comparisons
* - Orders can be transformed using {@link mapInput} to compare values by extracting a comparable property
* - Built-in orders exist for common types: {@link Number}, {@link String}, {@link Boolean}, {@link BigInt}, {@link Date}
*
* Common tasks:
* - Creating custom orders → {@link make}
* - Using built-in orders → {@link Number}, {@link String}, {@link Boolean}, {@link BigInt}, {@link Date}
* - Combining multiple orders → {@link combine}, {@link combineAll}
* - Transforming orders → {@link mapInput}
* - Comparing values → {@link isLessThan}, {@link isGreaterThan}, {@link isLessThanOrEqualTo}, {@link isGreaterThanOrEqualTo}
* - Finding min/max → {@link min}, {@link max}
* - Clamping values → {@link clamp}, {@link isBetween}
* - Ordering collections → {@link Array}, {@link Tuple}, {@link Struct}
*
* Gotchas:
* - `Order.Number` treats all `NaN` values as equal and less than any other number
* - `Order.make` uses reference equality (`===`) as a shortcut: if `self === that`, it returns `0` without calling the comparison function
* - `Order.Array` compares arrays element-by-element, then by length if all elements are equal; `Order.all` only compares elements up to the shorter array's length
* - `Order.Tuple` requires a fixed-length tuple with matching order types; `Order.Array` works with variable-length arrays
* - `Order.min` and `Order.max` return the first argument when values are equal
*
* Quickstart:
*
* **Example** (Basic Usage)
*
* ```ts
* import { Order } from "effect"
*
* const result = Order.Number(5, 10)
* console.log(result) // -1 (5 is less than 10)
*
* const isLessThan = Order.isLessThan(Order.Number)(5, 10)
* console.log(isLessThan) // true
* ```
*
* See also:
* - {@link Ordering} - The result type of comparisons
* - {@link Reducer} - For combining orders in collections
*
* @since 2.0.0
*/
var Order_exports = /* @__PURE__ */ __exportAll({
	Array: () => Array$1,
	BigInt: () => BigInt,
	Boolean: () => Boolean,
	Date: () => Date$1,
	Number: () => Number,
	String: () => String$1,
	Struct: () => Struct,
	Tuple: () => Tuple,
	alwaysEqual: () => alwaysEqual,
	clamp: () => clamp,
	combine: () => combine,
	combineAll: () => combineAll,
	flip: () => flip$1,
	isBetween: () => isBetween,
	isGreaterThan: () => isGreaterThan,
	isGreaterThanOrEqualTo: () => isGreaterThanOrEqualTo,
	isLessThan: () => isLessThan,
	isLessThanOrEqualTo: () => isLessThanOrEqualTo,
	make: () => make,
	makeReducer: () => makeReducer$1,
	mapInput: () => mapInput,
	max: () => max,
	min: () => min
});
/**
* Creates a new `Order` instance from a comparison function.
*
* When to use this:
* - When creating a custom order for a type that doesn't have a built-in order
* - When you need fine-grained control over comparison logic
* - When implementing orders for complex types
*
* Behavior:
* - Pure function: does not mutate inputs
* - Uses reference equality (`===`) as a shortcut: if `self === that`, returns `0` without calling the comparison function
* - The comparison function should return `-1`, `0`, or `1` based on the comparison result
* - The returned order satisfies total ordering laws if the comparison function does
*
* **Example** (Creating an Order)
*
* ```ts
* import { Order } from "effect"
*
* const byAge = Order.make<{ name: string; age: number }>((self, that) => {
*   if (self.age < that.age) return -1
*   if (self.age > that.age) return 1
*   return 0
* })
*
* console.log(byAge({ name: "Alice", age: 30 }, { name: "Bob", age: 25 })) // 1
* console.log(byAge({ name: "Alice", age: 25 }, { name: "Bob", age: 30 })) // -1
* ```
*
* See also:
* - {@link mapInput} - Transform an order by mapping the input type
* - {@link combine} - Combine multiple orders
*
* @category constructors
* @since 2.0.0
*/
function make(compare) {
	return (self, that) => self === that ? 0 : compare(self, that);
}
/**
* An `Order` instance for strings that compares them lexicographically using JavaScript's `<` operator.
*
* When to use this:
* - When comparing strings alphabetically
* - When sorting string collections
* - As a base for creating orders on types containing strings
*
* Behavior:
* - Pure function: does not mutate inputs
* - Uses lexicographic (dictionary) ordering
* - Empty string is less than any non-empty string
* - Comparison is case-sensitive
*
* **Example** (String Ordering)
*
* ```ts
* import { Order } from "effect"
*
* console.log(Order.String("apple", "banana")) // -1
* console.log(Order.String("banana", "apple")) // 1
* console.log(Order.String("apple", "apple")) // 0
* ```
*
* See also:
* - {@link mapInput} - Use this order to compare objects by a string property
* - {@link Struct} - Combine with other orders for struct comparison
*
* @category instances
* @since 4.0.0
*/
var String$1 = /*#__PURE__*/ make((self, that) => self < that ? -1 : 1);
/**
* An `Order` instance for numbers that compares them numerically.
*
* When to use this:
* - When comparing numbers for sorting or searching
* - As a base for creating orders on types containing numbers
* - When implementing numeric comparisons in data structures
*
* Behavior:
* - Pure function: does not mutate inputs
* - `0` is considered equal to `-0`
* - All `NaN` values are considered equal to each other
* - Any `NaN` is considered less than any non-NaN number
* - Uses standard numeric comparison for all other values
*
* **Example** (Number Ordering)
*
* ```ts
* import { Order } from "effect"
*
* console.log(Order.Number(1, 1)) // 0
* console.log(Order.Number(1, 2)) // -1
* console.log(Order.Number(2, 1)) // 1
*
* console.log(Order.Number(0, -0)) // 0
* console.log(Order.Number(NaN, 1)) // -1
* ```
*
* See also:
* - {@link mapInput} - Use this order to compare objects by a number property
* - {@link BigInt} - For bigint comparisons
*
* @category instances
* @since 4.0.0
*/
var Number = /*#__PURE__*/ make((self, that) => {
	if (globalThis.Number.isNaN(self) && globalThis.Number.isNaN(that)) return 0;
	if (globalThis.Number.isNaN(self)) return -1;
	if (globalThis.Number.isNaN(that)) return 1;
	return self < that ? -1 : 1;
});
/**
* An `Order` instance for booleans where `false` is considered less than `true`.
*
* When to use this:
* - When comparing booleans for sorting or searching
* - As a base for creating orders on types containing booleans
* - When implementing boolean-based comparisons
*
* Behavior:
* - Pure function: does not mutate inputs
* - `false` is less than `true`
* - Equal values return `0`
*
* **Example** (Boolean Ordering)
*
* ```ts
* import { Order } from "effect"
*
* console.log(Order.Boolean(false, true)) // -1
* console.log(Order.Boolean(true, false)) // 1
* console.log(Order.Boolean(true, true)) // 0
* ```
*
* See also:
* - {@link mapInput} - Use this order to compare objects by a boolean property
*
* @category instances
* @since 4.0.0
*/
var Boolean = /*#__PURE__*/ make((self, that) => self < that ? -1 : 1);
/**
* An `Order` instance for bigints that compares them numerically.
*
* When to use this:
* - When comparing bigint values for sorting or searching
* - As a base for creating orders on types containing bigints
* - When working with large integers that exceed number precision
*
* Behavior:
* - Pure function: does not mutate inputs
* - Uses standard numeric comparison for bigint values
* - Handles arbitrarily large integers
*
* **Example** (BigInt Ordering)
*
* ```ts
* import { Order } from "effect"
*
* console.log(Order.BigInt(1n, 2n)) // -1
* console.log(Order.BigInt(2n, 1n)) // 1
* console.log(Order.BigInt(1n, 1n)) // 0
* ```
*
* See also:
* - {@link Number} - For regular number comparisons
* - {@link mapInput} - Use this order to compare objects by a bigint property
*
* @category instances
* @since 4.0.0
*/
var BigInt = /*#__PURE__*/ make((self, that) => self < that ? -1 : 1);
/**
* Creates a new `Order` that reverses the comparison order of the input `Order`.
*
* When to use this:
* - When you need descending order instead of ascending
* - When reversing an existing order without modifying the original
* - When creating orders that compare in the opposite direction
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns a new order that swaps the arguments before comparison
* - If the original order returns `-1`, the flipped order returns `1`, and vice versa
* - Equal comparisons remain `0`
*
* **Example** (Reversing Order)
*
* ```ts
* import { Order } from "effect"
*
* const flip = Order.flip(Order.Number)
*
* console.log(flip(1, 2)) // 1
* console.log(flip(2, 1)) // -1
* console.log(flip(1, 1)) // 0
* ```
*
* See also:
* - {@link combine} - Combine orders for multi-criteria comparison
*
* @category combinators
* @since 2.0.0
*/
function flip$1(O) {
	return make((self, that) => O(that, self));
}
/**
* Combines two `Order` instances to create a new `Order` that first compares using the first `Order`,
* and if the values are equal, then compares using the second `Order`.
*
* When to use this:
* - When you need multi-criteria comparison (e.g., sort by age, then by name)
* - When creating composite orders from simpler orders
* - When implementing lexicographic ordering
*
* Behavior:
* - Pure function: does not mutate inputs
* - First applies the first order; if the result is non-zero, returns that result
* - If the first order returns `0` (equal), applies the second order
* - Returns the first non-zero result, or `0` if both orders return `0`
*
* **Example** (Combining Orders)
*
* ```ts
* import { Order } from "effect"
*
* const byAge = Order.mapInput(
*   Order.Number,
*   (person: { name: string; age: number }) => person.age
* )
* const byName = Order.mapInput(
*   Order.String,
*   (person: { name: string; age: number }) => person.name
* )
* const byAgeAndName = Order.combine(byAge, byName)
*
* const person1 = { name: "Alice", age: 30 }
* const person2 = { name: "Bob", age: 30 }
* const person3 = { name: "Charlie", age: 25 }
*
* console.log(byAgeAndName(person1, person2)) // -1 (Same age, Alice < Bob)
* console.log(byAgeAndName(person1, person3)) // 1 (Alice (30) > Charlie (25))
* ```
*
* See also:
* - {@link combineAll} - Combine multiple orders from a collection
* - {@link mapInput} - Transform orders to work with different types
*
* @category combining
* @since 2.0.0
*/
var combine = /*#__PURE__*/ dual(2, (self, that) => make((a1, a2) => {
	const out = self(a1, a2);
	if (out !== 0) return out;
	return that(a1, a2);
}));
/**
* Creates an `Order` that considers all values as equal.
*
* When to use this:
* - When you need an order that doesn't distinguish between values
* - As a default or fallback order when no meaningful comparison exists
* - When implementing optional ordering where equality is sufficient
*
* Behavior:
* - Pure function: does not mutate inputs
* - Always returns `0` regardless of input values
* - Useful as a neutral element in order composition
*
* **Example** (Always Equal Order)
*
* ```ts
* import { Order } from "effect"
*
* const alwaysEqualOrder = Order.alwaysEqual<number>()
*
* console.log(alwaysEqualOrder(1, 2)) // 0
* console.log(alwaysEqualOrder(2, 1)) // 0
* console.log(alwaysEqualOrder(1, 1)) // 0
* ```
*
* See also:
* - {@link combine} - Combine with other orders
*
* @category constructors
* @since 4.0.0
*/
function alwaysEqual() {
	return make(() => 0);
}
/**
* Combines all `Order` instances in the provided collection into a single `Order`.
* The resulting `Order` compares using each `Order` in sequence until a non-zero result is found.
*
* When to use this:
* - When you have a variable number of orders to combine
* - When combining orders from a collection or array
* - When implementing dynamic multi-criteria sorting
*
* Behavior:
* - Pure function: does not mutate inputs
* - Applies orders in iteration order
* - Returns the first non-zero result from any order
* - Returns `0` only if all orders return `0`
* - Short-circuits on the first non-zero result
*
* **Example** (Combining Multiple Orders)
*
* ```ts
* import { Order } from "effect"
*
* const byAge = Order.mapInput(
*   Order.Number,
*   (person: { name: string; age: number }) => person.age
* )
* const byName = Order.mapInput(
*   Order.String,
*   (person: { name: string; age: number }) => person.name
* )
*
* const combinedOrder = Order.combineAll([byAge, byName])
*
* const person1 = { name: "Alice", age: 30 }
* const person2 = { name: "Bob", age: 30 }
*
* console.log(combinedOrder(person1, person2)) // -1 (Same age, Alice < Bob)
* ```
*
* See also:
* - {@link combine} - Combine two orders
* - {@link makeReducer} - Create a reducer for combining orders
*
* @category combining
* @since 2.0.0
*/
function combineAll(collection) {
	return make((a1, a2) => {
		let out = 0;
		for (const O of collection) {
			out = O(a1, a2);
			if (out !== 0) return out;
		}
		return out;
	});
}
/**
* Transforms an `Order` on type `A` into an `Order` on type `B` by providing a function that
* maps values of type `B` to values of type `A`.
*
* When to use this:
* - When you have an order for a property type and want to compare objects by that property
* - When extracting a comparable value from a complex type
* - When creating orders for types that contain comparable values
*
* Behavior:
* - Pure function: does not mutate inputs
* - Applies the mapping function to both values before comparison
* - The mapping function should be pure and not have side effects
* - Preserves the ordering properties of the original order
*
* **Example** (Mapping Input)
*
* ```ts
* import { Order } from "effect"
*
* const byLength = Order.mapInput(Order.Number, (s: string) => s.length)
*
* console.log(byLength("a", "bb")) // -1
* console.log(byLength("bb", "a")) // 1
* console.log(byLength("aa", "bb")) // 0
* ```
*
* See also:
* - {@link combine} - Combine mapped orders for multi-criteria comparison
* - {@link Struct} - Create orders for structs with multiple fields
*
* @category mapping
* @since 2.0.0
*/
var mapInput = /*#__PURE__*/ dual(2, (self, f) => make((b1, b2) => self(f(b1), f(b2))));
/**
* An `Order` instance for `Date` objects that compares them chronologically by their timestamp.
*
* When to use this:
* - When comparing dates for sorting or searching
* - As a base for creating orders on types containing dates
* - When implementing time-based comparisons
*
* Behavior:
* - Pure function: does not mutate inputs
* - Compares dates by their underlying timestamp (milliseconds since epoch)
* - Earlier dates are less than later dates
* - Invalid dates are compared as if they were valid (uses `getTime()` result)
*
* **Example** (Date Ordering)
*
* ```ts
* import { Order } from "effect"
*
* const date1 = new Date("2023-01-01")
* const date2 = new Date("2023-01-02")
*
* console.log(Order.Date(date1, date2)) // -1
* console.log(Order.Date(date2, date1)) // 1
* console.log(Order.Date(date1, date1)) // 0
* ```
*
* See also:
* - {@link mapInput} - Use this order to compare objects by a date property
*
* @category instances
* @since 2.0.0
*/
var Date$1 = /*#__PURE__*/ mapInput(Number, (date) => date.getTime());
/**
* Creates an `Order` for a tuple type based on orders for each element.
*
* When to use this:
* - When comparing tuples with different types for each position
* - When you need type-safe tuple ordering
* - When working with fixed-length heterogeneous collections
*
* Behavior:
* - Pure function: does not mutate inputs
* - Compares tuples element-by-element using the corresponding order
* - Stops at the first non-zero comparison result
* - Requires tuples to have the same length as the order collection
* - Returns `0` if all elements are equal
*
* **Example** (Tuple Ordering)
*
* ```ts
* import { Order } from "effect"
*
* const tupleOrder = Order.Tuple([Order.Number, Order.String])
*
* console.log(tupleOrder([1, "a"], [2, "b"])) // -1
* console.log(tupleOrder([1, "b"], [1, "a"])) // 1
* console.log(tupleOrder([1, "a"], [1, "a"])) // 0
* ```
*
* See also:
* - {@link Array} - Compare arrays with length consideration
*
* @category combinators
* @since 4.0.0
*/
function Tuple(elements) {
	return make((self, that) => {
		const len = elements.length;
		for (let i = 0; i < len; i++) {
			const o = elements[i](self[i], that[i]);
			if (o !== 0) return o;
		}
		return 0;
	});
}
/**
* Creates an `Order` for arrays by applying the given `Order` to each element, then comparing by length if all elements are equal.
*
* When to use this:
* - When comparing arrays of the same element type
* - When you want shorter arrays to be considered less than longer arrays
* - When sorting collections of arrays
*
* Behavior:
* - Pure function: does not mutate inputs
* - Compares arrays element-by-element using the provided order
* - Stops at the first non-zero comparison result
* - If all elements are equal, shorter arrays are less than longer arrays
* - Returns `0` only if arrays have the same length and all elements are equal
*
* **Example** (Array Element Ordering)
*
* ```ts
* import { Order } from "effect"
*
* const arrayOrder = Order.Array(Order.Number)
*
* console.log(arrayOrder([1, 2], [1, 3])) // -1
* console.log(arrayOrder([1, 2], [1, 2, 3])) // -1 (shorter array is less)
* console.log(arrayOrder([1, 2, 3], [1, 2])) // 1 (longer array is greater)
* console.log(arrayOrder([1, 2], [1, 2])) // 0
* ```
*
* See also:
* - {@link Tuple} - Type-safe tuple ordering
*
* @category combinators
* @since 4.0.0
*/
function Array$1(O) {
	return make((self, that) => {
		const aLen = self.length;
		const bLen = that.length;
		const len = Math.min(aLen, bLen);
		for (let i = 0; i < len; i++) {
			const o = O(self[i], that[i]);
			if (o !== 0) return o;
		}
		return Number(aLen, bLen);
	});
}
/**
* Creates an `Order` for structs by applying the given `Order`s to each property in sequence.
*
* When to use this:
* - When comparing objects with multiple properties
* - When you need multi-field comparison for structs
* - When creating orders for complex data types
*
* Behavior:
* - Pure function: does not mutate inputs
* - Compares structs field-by-field in the order of keys in the fields object
* - Stops at the first non-zero comparison result
* - Returns `0` only if all fields are equal
* - Field order matters: earlier fields take precedence
*
* **Example** (Struct Ordering)
*
* ```ts
* import { Order } from "effect"
*
* const personOrder = Order.Struct({
*   name: Order.String,
*   age: Order.Number
* })
*
* const person1 = { name: "Alice", age: 30 }
* const person2 = { name: "Bob", age: 25 }
* const person3 = { name: "Alice", age: 25 }
*
* console.log(personOrder(person1, person2)) // -1 (Alice < Bob)
* console.log(personOrder(person1, person3)) // 1 (same name, 30 > 25)
* console.log(personOrder(person1, person1)) // 0
* ```
*
* See also:
* - {@link combine} - Combine orders manually
* - {@link mapInput} - Extract and compare by a single property
*
* @category combinators
* @since 4.0.0
*/
function Struct(fields) {
	const keys = Object.keys(fields);
	return make((self, that) => {
		for (const key of keys) {
			const o = fields[key](self[key], that[key]);
			if (o !== 0) return o;
		}
		return 0;
	});
}
/**
* Tests whether one value is strictly less than another according to the given order.
*
* When to use this:
* - When you need a boolean predicate instead of an ordering result
* - When checking if a value is less than another in conditional logic
* - When implementing range checks or comparisons
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns `true` if the order returns `-1` (first value is less than second)
* - Returns `false` for equal or greater values
* - Supports curried and uncurried call styles
*
* **Example** (Less Than)
*
* ```ts
* import { Order } from "effect"
*
* const isLessThanNumber = Order.isLessThan(Order.Number)
*
* console.log(isLessThanNumber(1, 2)) // true
* console.log(isLessThanNumber(2, 1)) // false
* console.log(isLessThanNumber(1, 1)) // false
* ```
*
* See also:
* - {@link isLessThanOrEqualTo} - Non-strict less than or equal
* - {@link isGreaterThan} - Strict greater than
*
* @category predicates
* @since 2.0.0
*/
var isLessThan = (O) => dual(2, (self, that) => O(self, that) === -1);
/**
* Tests whether one value is strictly greater than another according to the given order.
*
* When to use this:
* - When you need a boolean predicate instead of an ordering result
* - When checking if a value is greater than another in conditional logic
* - When implementing range checks or comparisons
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns `true` if the order returns `1` (first value is greater than second)
* - Returns `false` for equal or lesser values
* - Supports curried and uncurried call styles
*
* **Example** (Greater Than)
*
* ```ts
* import { Order } from "effect"
*
* const isGreaterThanNumber = Order.isGreaterThan(Order.Number)
*
* console.log(isGreaterThanNumber(2, 1)) // true
* console.log(isGreaterThanNumber(1, 2)) // false
* console.log(isGreaterThanNumber(1, 1)) // false
* ```
*
* See also:
* - {@link isGreaterThanOrEqualTo} - Non-strict greater than or equal
* - {@link isLessThan} - Strict less than
*
* @category predicates
* @since 2.0.0
*/
var isGreaterThan = (O) => dual(2, (self, that) => O(self, that) === 1);
/**
* Tests whether one value is less than or equal to another according to the given order.
*
* When to use this:
* - When you need a boolean predicate for non-strict comparison
* - When checking if a value is within a range (inclusive lower bound)
* - When implementing inclusive comparisons
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns `true` if the order returns `-1` or `0` (less than or equal)
* - Returns `false` only if the order returns `1` (greater than)
* - Supports curried and uncurried call styles
*
* **Example** (Less Than Or Equal)
*
* ```ts
* import { Order } from "effect"
*
* const isLessThanOrEqualToNumber = Order.isLessThanOrEqualTo(Order.Number)
*
* console.log(isLessThanOrEqualToNumber(1, 2)) // true
* console.log(isLessThanOrEqualToNumber(1, 1)) // true
* console.log(isLessThanOrEqualToNumber(2, 1)) // false
* ```
*
* See also:
* - {@link isLessThan} - Strict less than
* - {@link isGreaterThan} - Strict greater than
*
* @category predicates
* @since 2.0.0
*/
var isLessThanOrEqualTo = (O) => dual(2, (self, that) => O(self, that) !== 1);
/**
* Tests whether one value is greater than or equal to another according to the given order.
*
* When to use this:
* - When you need a boolean predicate for non-strict comparison
* - When checking if a value is within a range (inclusive upper bound)
* - When implementing inclusive comparisons
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns `true` if the order returns `1` or `0` (greater than or equal)
* - Returns `false` only if the order returns `-1` (less than)
* - Supports curried and uncurried call styles
*
* **Example** (Greater Than Or Equal)
*
* ```ts
* import { Order } from "effect"
*
* const isGreaterThanOrEqualToNumber = Order.isGreaterThanOrEqualTo(Order.Number)
*
* console.log(isGreaterThanOrEqualToNumber(2, 1)) // true
* console.log(isGreaterThanOrEqualToNumber(1, 1)) // true
* console.log(isGreaterThanOrEqualToNumber(1, 2)) // false
* ```
*
* See also:
* - {@link isGreaterThan} - Strict greater than
* - {@link isLessThanOrEqualTo} - Less than or equal
*
* @category predicates
* @since 2.0.0
*/
var isGreaterThanOrEqualTo = (O) => dual(2, (self, that) => O(self, that) !== -1);
/**
* Returns the minimum of two values according to the given order. If they are equal, returns the first argument.
*
* When to use this:
* - When you need to find the smaller of two values
* - When implementing min/max operations
* - When selecting values based on ordering
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns the value that compares as less than or equal to the other
* - If values are equal, returns the first argument
* - Supports curried and uncurried call styles
*
* **Example** (Minimum Value)
*
* ```ts
* import { Order } from "effect"
*
* const minNumber = Order.min(Order.Number)
*
* console.log(minNumber(1, 2)) // 1
* console.log(minNumber(2, 1)) // 1
* console.log(minNumber(1, 1)) // 1
* ```
*
* See also:
* - {@link max} - Maximum of two values
* - {@link clamp} - Clamp a value between min and max
*
* @category comparisons
* @since 2.0.0
*/
var min = (O) => dual(2, (self, that) => self === that || O(self, that) < 1 ? self : that);
/**
* Returns the maximum of two values according to the given order. If they are equal, returns the first argument.
*
* When to use this:
* - When you need to find the larger of two values
* - When implementing min/max operations
* - When selecting values based on ordering
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns the value that compares as greater than or equal to the other
* - If values are equal, returns the first argument
* - Supports curried and uncurried call styles
*
* **Example** (Maximum Value)
*
* ```ts
* import { Order } from "effect"
*
* const maxNumber = Order.max(Order.Number)
*
* console.log(maxNumber(1, 2)) // 2
* console.log(maxNumber(2, 1)) // 2
* console.log(maxNumber(1, 1)) // 1
* ```
*
* See also:
* - {@link min} - Minimum of two values
* - {@link clamp} - Clamp a value between min and max
*
* @category comparisons
* @since 2.0.0
*/
var max = (O) => dual(2, (self, that) => self === that || O(self, that) > -1 ? self : that);
/**
* Clamps a value between a minimum and a maximum according to the given order.
*
* When to use this:
* - When you need to restrict a value to a specific range
* - When implementing bounds checking and normalization
* - When ensuring values stay within valid ranges
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns the value if it's between minimum and maximum (inclusive)
* - Returns minimum if the value is less than minimum
* - Returns maximum if the value is greater than maximum
* - Supports curried and uncurried call styles
* - Requires that minimum <= maximum according to the order
*
* **Example** (Clamping Values)
*
* ```ts
* import { Order } from "effect"
*
* const clamp = Order.clamp(Order.Number)({ minimum: 1, maximum: 5 })
*
* console.log(clamp(3)) // 3
* console.log(clamp(0)) // 1
* console.log(clamp(6)) // 5
* ```
*
* See also:
* - {@link min} - Minimum of two values
* - {@link max} - Maximum of two values
* - {@link isBetween} - Check if a value is within a range
*
* @category comparisons
* @since 2.0.0
*/
var clamp = (O) => dual(2, (self, options) => min(O)(options.maximum, max(O)(options.minimum, self)));
/**
* Tests whether a value is between a minimum and a maximum (inclusive) according to the given order.
*
* When to use this:
* - When validating that a value is within a valid range
* - When implementing range checks for bounds validation
* - When filtering or selecting values within a range
*
* Behavior:
* - Pure function: does not mutate inputs
* - Returns `true` if the value is greater than or equal to minimum and less than or equal to maximum
* - Returns `false` if the value is outside the range
* - Supports curried and uncurried call styles
* - Both bounds are inclusive
*
* **Example** (Checking Range)
*
* ```ts
* import { Order } from "effect"
*
* const betweenNumber = Order.isBetween(Order.Number)
*
* console.log(betweenNumber(5, { minimum: 1, maximum: 10 })) // true
* console.log(betweenNumber(1, { minimum: 1, maximum: 10 })) // true
* console.log(betweenNumber(10, { minimum: 1, maximum: 10 })) // true
* console.log(betweenNumber(0, { minimum: 1, maximum: 10 })) // false
* console.log(betweenNumber(11, { minimum: 1, maximum: 10 })) // false
* ```
*
* See also:
* - {@link clamp} - Clamp a value to a range
* - {@link isLessThanOrEqualTo} - Less than or equal check
* - {@link isGreaterThanOrEqualTo} - Greater than or equal check
*
* @category predicates
* @since 4.0.0
*/
var isBetween = (O) => dual(2, (self, options) => !isLessThan(O)(self, options.minimum) && !isGreaterThan(O)(self, options.maximum));
/**
* Creates a `Reducer` for combining `Order` instances, useful for aggregating orders in collections.
*
* When to use this:
* - When you need to combine multiple orders from a collection using reducer patterns
* - When implementing fold operations over collections of orders
* - When working with reducers that operate on orders
*
* Behavior:
* - Returns a reducer that combines orders using {@link combine}
* - Uses {@link alwaysEqual} as the identity element (returns `0` for empty collections)
* - Uses {@link combineAll} for combining collections of orders
* - The reducer can be used with fold operations on collections
*
* **Example** (Creating a Reducer)
*
* ```ts
* import { Order } from "effect"
*
* const reducer = Order.makeReducer<number>()
* const orders = [Order.Number, Order.flip(Order.Number)]
*
* const combined = reducer.combineAll(orders)
* console.log(combined(1, 2)) // -1 (uses first order)
* ```
*
* See also:
* - {@link combine} - Combine two orders
* - {@link combineAll} - Combine multiple orders
* - {@link Reducer} - Reducer type for collection operations
*
* @category utilities
* @since 4.0.0
*/
function makeReducer$1() {
	return make$3(combine, () => 0, combineAll);
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Option.js
var Option_exports = /* @__PURE__ */ __exportAll({
	Do: () => Do$1,
	all: () => all$1,
	andThen: () => andThen$1,
	as: () => as,
	asVoid: () => asVoid,
	bind: () => bind$1,
	bindTo: () => bindTo$1,
	composeK: () => composeK,
	contains: () => contains,
	containsWith: () => containsWith,
	exists: () => exists,
	filter: () => filter$1,
	filterMap: () => filterMap$1,
	firstSomeOf: () => firstSomeOf,
	flatMap: () => flatMap$1,
	flatMapNullishOr: () => flatMapNullishOr,
	flatten: () => flatten,
	fromIterable: () => fromIterable,
	fromNullOr: () => fromNullOr,
	fromNullishOr: () => fromNullishOr$1,
	fromUndefinedOr: () => fromUndefinedOr,
	gen: () => gen$1,
	getFailure: () => getFailure$1,
	getOrElse: () => getOrElse$1,
	getOrNull: () => getOrNull$1,
	getOrThrow: () => getOrThrow$1,
	getOrThrowWith: () => getOrThrowWith$1,
	getOrUndefined: () => getOrUndefined$1,
	getSuccess: () => getSuccess$1,
	isNone: () => isNone,
	isOption: () => isOption,
	isSome: () => isSome,
	let: () => let_$1,
	lift2: () => lift2,
	liftNullishOr: () => liftNullishOr,
	liftPredicate: () => liftPredicate$1,
	liftThrowable: () => liftThrowable,
	makeCombinerFailFast: () => makeCombinerFailFast,
	makeEquivalence: () => makeEquivalence$2,
	makeOrder: () => makeOrder,
	makeReducer: () => makeReducer,
	makeReducerFailFast: () => makeReducerFailFast,
	map: () => map$2,
	match: () => match$1,
	none: () => none,
	orElse: () => orElse$1,
	orElseResult: () => orElseResult,
	orElseSome: () => orElseSome,
	partitionMap: () => partitionMap,
	product: () => product,
	productMany: () => productMany,
	reduceCompact: () => reduceCompact,
	some: () => some$1,
	tap: () => tap$1,
	toArray: () => toArray,
	toRefinement: () => toRefinement,
	void: () => void_$1,
	zipLeft: () => zipLeft,
	zipRight: () => zipRight,
	zipWith: () => zipWith
});
/**
* Creates an `Option` representing the absence of a value.
*
* **When to use**
*
* - Representing a missing or uninitialized value
* - Returning "no result" from a function
*
* **Behavior**
*
* - Returns `Option<never>`, which is a subtype of `Option<A>` for any `A`
* - Always returns the same singleton instance
*
* **Example** (Creating an empty Option)
*
* ```ts
* import { Option } from "effect"
*
* //      ┌─── Option<never>
* //      ▼
* const noValue = Option.none()
*
* console.log(noValue)
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link some} for the opposite operation.
*
* @category Constructors
* @since 2.0.0
*/
var none = () => none$1;
/**
* Wraps the given value into an `Option` to represent its presence.
*
* **When to use**
*
* - Wrapping a known-present value as `Option`
* - Returning a successful result from a partial function
*
* **Behavior**
*
* - Always returns `Some<A>`
* - Does not filter `null` or `undefined`; use {@link fromNullishOr} for that
*
* **Example** (Wrapping a value)
*
* ```ts
* import { Option } from "effect"
*
* //      ┌─── Option<number>
* //      ▼
* const value = Option.some(1)
*
* console.log(value)
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
* ```
*
* @see {@link none} for the opposite operation.
*
* @category Constructors
* @since 2.0.0
*/
var some$1 = some$2;
/**
* Determines whether the given value is an `Option`.
*
* **When to use**
*
* - Validating unknown values at runtime boundaries
* - Type-narrowing in union types
*
* **Behavior**
*
* - Returns `true` for both `Some` and `None` instances
* - Acts as a type guard, narrowing the input to `Option<unknown>`
*
* **Example** (Checking if a value is an Option)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.isOption(Option.some(1)))
* // Output: true
*
* console.log(Option.isOption(Option.none()))
* // Output: true
*
* console.log(Option.isOption({}))
* // Output: false
* ```
*
* @see {@link isNone} to check for `None` specifically
* @see {@link isSome} to check for `Some` specifically
*
* @category Guards
* @since 2.0.0
*/
var isOption = isOption$1;
/**
* Checks whether an `Option` is `None` (absent).
*
* **When to use**
*
* - Branching on absence before accessing `.value`
*
* **Behavior**
*
* - Acts as a type guard, narrowing to `None<A>`
*
* **Example** (Checking for None)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.isNone(Option.some(1)))
* // Output: false
*
* console.log(Option.isNone(Option.none()))
* // Output: true
* ```
*
* @see {@link isSome} for the opposite check.
*
* @category Guards
* @since 2.0.0
*/
var isNone = isNone$1;
/**
* Checks whether an `Option` contains a value (`Some`).
*
* **When to use**
*
* - Branching on presence before accessing `.value`
*
* **Behavior**
*
* - Acts as a type guard, narrowing to `Some<A>`
*
* **Example** (Checking for Some)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.isSome(Option.some(1)))
* // Output: true
*
* console.log(Option.isSome(Option.none()))
* // Output: false
* ```
*
* @see {@link isNone} for the opposite check.
*
* @category Guards
* @since 2.0.0
*/
var isSome = isSome$1;
/**
* Pattern-matches on an `Option`, handling both `None` and `Some` cases.
*
* **When to use**
*
* - Exhaustively handling both branches in one expression
* - Transforming an `Option` into a plain value
*
* **Behavior**
*
* - If `None`, calls `onNone` and returns its result
* - If `Some`, calls `onSome` with the value and returns its result
* - Supports the `dual` API (data-last and data-first)
*
* **Example** (Matching on an Option)
*
* ```ts
* import { Option } from "effect"
*
* const message = Option.match(Option.some(1), {
*   onNone: () => "Option is empty",
*   onSome: (value) => `Option has a value: ${value}`
* })
*
* console.log(message)
* // Output: "Option has a value: 1"
* ```
*
* @see {@link getOrElse} for unwrapping with a default
*
* @category Pattern matching
* @since 2.0.0
*/
var match$1 = /*#__PURE__*/ dual(2, (self, { onNone, onSome }) => isNone(self) ? onNone() : onSome(self.value));
/**
* Converts an `Option`-returning function into a type guard (refinement).
*
* **When to use**
*
* - Turning a parsing function into a type-narrowing predicate
* - Filtering arrays with `Array.prototype.filter`
*
* **Behavior**
*
* - Returns `true` when the original function returns `Some`
* - Returns `false` when the original function returns `None`
* - Narrows the input type to `B` on success
*
* **Example** (Converting a parser to a type guard)
*
* ```ts
* import { Option } from "effect"
*
* type MyData = string | number
*
* const parseString = (data: MyData): Option.Option<string> =>
*   typeof data === "string" ? Option.some(data) : Option.none()
*
* //      ┌─── (a: MyData) => a is string
* //      ▼
* const isString = Option.toRefinement(parseString)
*
* console.log(isString("a"))
* // Output: true
*
* console.log(isString(1))
* // Output: false
* ```
*
* @see {@link liftPredicate} for the reverse direction
*
* @category Conversions
* @since 2.0.0
*/
var toRefinement = (f) => (a) => isSome(f(a));
/**
* Wraps the first element of an `Iterable` in a `Some`, or returns `None` if
* the iterable is empty.
*
* **When to use**
*
* - Safely extracting the head of a collection
* - Working with generators or lazy iterables
*
* **Behavior**
*
* - Only consumes the first element; does not iterate the rest
* - Returns `None` for empty iterables
*
* **Example** (Getting the first element)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.fromIterable([1, 2, 3]))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
*
* console.log(Option.fromIterable([]))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link toArray} for the inverse direction
*
* @category Constructors
* @since 2.0.0
*/
var fromIterable = (collection) => {
	for (const a of collection) return some$1(a);
	return none();
};
/**
* Converts a `Result` into an `Option`, keeping only the success value.
*
* **When to use**
*
* - Discarding the error channel when you only care about success
*
* **Behavior**
*
* - `Ok` → `Some` with the success value
* - `Err` → `None` (error is discarded)
*
* **Example** (Extracting the success side)
*
* ```ts
* import { Option, Result } from "effect"
*
* console.log(Option.getSuccess(Result.succeed("ok")))
* // Output: { _id: 'Option', _tag: 'Some', value: 'ok' }
*
* console.log(Option.getSuccess(Result.fail("err")))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link getFailure} for the opposite operation.
*
* @category Conversions
* @since 2.0.0
*/
var getSuccess$1 = getSuccess$2;
/**
* Converts a `Result` into an `Option`, keeping only the error value.
*
* **When to use**
*
* - Extracting the error when you don't need the success channel
*
* **Behavior**
*
* - `Err` → `Some` with the error value
* - `Ok` → `None` (success value is discarded)
*
* **Example** (Extracting the failure side)
*
* ```ts
* import { Option, Result } from "effect"
*
* console.log(Option.getFailure(Result.succeed("ok")))
* // Output: { _id: 'Option', _tag: 'None' }
*
* console.log(Option.getFailure(Result.fail("err")))
* // Output: { _id: 'Option', _tag: 'Some', value: 'err' }
* ```
*
* @see {@link getSuccess} for the opposite operation.
*
* @category Conversions
* @since 2.0.0
*/
var getFailure$1 = getFailure$2;
/**
* Extracts the value from a `Some`, or evaluates a fallback thunk on `None`.
*
* **When to use**
*
* - Providing a default value for an absent `Option`
* - Unwrapping with lazy evaluation of the fallback
*
* **Behavior**
*
* - `Some` → returns the inner value
* - `None` → calls `onNone()` and returns its result
* - `onNone` is only called when needed (lazy)
*
* **Example** (Unwrapping with a fallback)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.some(1).pipe(Option.getOrElse(() => 0)))
* // Output: 1
*
* console.log(Option.none().pipe(Option.getOrElse(() => 0)))
* // Output: 0
* ```
*
* @see {@link getOrNull} to fall back to `null`
* @see {@link getOrUndefined} to fall back to `undefined`
* @see {@link getOrThrow} to throw on `None`
*
* @category Getters
* @since 2.0.0
*/
var getOrElse$1 = /*#__PURE__*/ dual(2, (self, onNone) => isNone(self) ? onNone() : self.value);
/**
* Returns the fallback `Option` if `self` is `None`; otherwise returns `self`.
*
* **When to use**
*
* - Chaining fallback `Option` computations
* - Building priority chains of optional values
*
* **Behavior**
*
* - `Some` → returns `self` unchanged
* - `None` → evaluates and returns `that()`
* - `that` is lazily evaluated
*
* **Example** (Providing a fallback Option)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.none().pipe(Option.orElse(() => Option.some("b"))))
* // Output: { _id: 'Option', _tag: 'Some', value: 'b' }
*
* console.log(Option.some("a").pipe(Option.orElse(() => Option.some("b"))))
* // Output: { _id: 'Option', _tag: 'Some', value: 'a' }
* ```
*
* @see {@link orElseSome} to wrap the fallback value in `Some` automatically
* @see {@link firstSomeOf} to pick the first `Some` from a collection
*
* @category Error handling
* @since 2.0.0
*/
var orElse$1 = /*#__PURE__*/ dual(2, (self, that) => isNone(self) ? that() : self);
/**
* Returns `Some` of the fallback value if `self` is `None`; otherwise returns
* `self`.
*
* **When to use**
*
* - Providing a default plain value (not an `Option`) as fallback
*
* **Behavior**
*
* - `Some` → returns `self` unchanged
* - `None` → calls `onNone()`, wraps result in `Some`, and returns it
*
* **Example** (Providing a fallback value)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.none().pipe(Option.orElseSome(() => "b")))
* // Output: { _id: 'Option', _tag: 'Some', value: 'b' }
*
* console.log(Option.some("a").pipe(Option.orElseSome(() => "b")))
* // Output: { _id: 'Option', _tag: 'Some', value: 'a' }
* ```
*
* @see {@link orElse} when the fallback is itself an `Option`
*
* @category Error handling
* @since 2.0.0
*/
var orElseSome = /*#__PURE__*/ dual(2, (self, onNone) => isNone(self) ? some$1(onNone()) : self);
/**
* Like {@link orElse}, but wraps the result in a `Result` to indicate the
* source of the value.
*
* **When to use**
*
* - Distinguishing whether a value came from the primary or fallback `Option`
*
* **Behavior**
*
* - `self` is `Some` → `Some(Result.fail(value))` (value from primary)
* - `self` is `None`, `that()` is `Some` → `Some(Result.succeed(value))` (value from fallback)
* - Both `None` → `None`
*
* **Example** (Tracking value source)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.orElseResult(Option.some("primary"), () => Option.some("fallback")))
* // Output: { _id: 'Option', _tag: 'Some', value: { _tag: 'Failure', value: 'primary' } }
*
* console.log(Option.orElseResult(Option.none(), () => Option.some("fallback")))
* // Output: { _id: 'Option', _tag: 'Some', value: { _tag: 'Success', value: 'fallback' } }
* ```
*
* @see {@link orElse} for the simpler variant without source tracking
*
* @category Error handling
* @since 2.0.0
*/
var orElseResult = /*#__PURE__*/ dual(2, (self, that) => isNone(self) ? map$2(that(), succeed$1) : map$2(self, fail$1));
/**
* Returns the first `Some` found in an iterable of `Option`s, or `None` if
* all are `None`.
*
* **When to use**
*
* - Searching for the first available value in a priority list
*
* **Behavior**
*
* - Short-circuits on the first `Some`
* - Returns `None` only when every element is `None`
*
* **Example** (Finding the first Some)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.firstSomeOf([
*   Option.none(),
*   Option.some(1),
*   Option.some(2)
* ]))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
* ```
*
* @see {@link orElse} for a two-option fallback
*
* @category Error handling
* @since 2.0.0
*/
var firstSomeOf = (collection) => {
	let out = none();
	for (out of collection) if (isSome(out)) return out;
	return out;
};
/**
* Converts a nullable value (`null` or `undefined`) into an `Option`.
*
* **When to use**
*
* - Bridging from nullable APIs to `Option`
* - Wrapping values that may be `null` or `undefined`
*
* **Behavior**
*
* - `null` or `undefined` → `None`
* - Any other value → `Some` (typed as `NonNullable<A>`)
*
* **Example** (From nullable values)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.fromNullishOr(undefined))
* // Output: { _id: 'Option', _tag: 'None' }
*
* console.log(Option.fromNullishOr(null))
* // Output: { _id: 'Option', _tag: 'None' }
*
* console.log(Option.fromNullishOr(1))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
* ```
*
* @see {@link fromNullOr} to only treat `null` as absent
* @see {@link fromUndefinedOr} to only treat `undefined` as absent
* @see {@link liftNullishOr} to lift a nullable-returning function
*
* @category Conversions
* @since 2.0.0
*/
var fromNullishOr$1 = (a) => a == null ? none() : some$1(a);
/**
* Converts a possibly `undefined` value into an `Option`, leaving `null`
* as a valid `Some`.
*
* **When to use**
*
* - When `null` is a meaningful value but `undefined` means absent
*
* **Behavior**
*
* - `undefined` → `None`
* - Any other value (including `null`) → `Some`
*
* **Example** (From possibly-undefined values)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.fromUndefinedOr(undefined))
* // Output: { _id: 'Option', _tag: 'None' }
*
* console.log(Option.fromUndefinedOr(null))
* // Output: { _id: 'Option', _tag: 'Some', value: null }
*
* console.log(Option.fromUndefinedOr(42))
* // Output: { _id: 'Option', _tag: 'Some', value: 42 }
* ```
*
* @see {@link fromNullishOr} to treat both `null` and `undefined` as absent
* @see {@link fromNullOr} to only treat `null` as absent
*
* @category Conversions
* @since 4.0.0
*/
var fromUndefinedOr = (a) => a === void 0 ? none() : some$1(a);
/**
* Converts a possibly `null` value into an `Option`, leaving `undefined`
* as a valid `Some`.
*
* **When to use**
*
* - When `undefined` is a meaningful value but `null` means absent
*
* **Behavior**
*
* - `null` → `None`
* - Any other value (including `undefined`) → `Some`
*
* **Example** (From possibly-null values)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.fromNullOr(null))
* // Output: { _id: 'Option', _tag: 'None' }
*
* console.log(Option.fromNullOr(undefined))
* // Output: { _id: 'Option', _tag: 'Some', value: undefined }
*
* console.log(Option.fromNullOr(42))
* // Output: { _id: 'Option', _tag: 'Some', value: 42 }
* ```
*
* @see {@link fromNullishOr} to treat both `null` and `undefined` as absent
* @see {@link fromUndefinedOr} to only treat `undefined` as absent
*
* @category Conversions
* @since 4.0.0
*/
var fromNullOr = (a) => a === null ? none() : some$1(a);
/**
* Lifts a function that may return `null` or `undefined` into one that returns
* an `Option`.
*
* **When to use**
*
* - Wrapping existing nullable-returning functions for use in `Option` pipelines
*
* **Behavior**
*
* - Calls the original function with the given arguments
* - Wraps the result via {@link fromNullishOr}
*
* **Example** (Lifting a parser)
*
* ```ts
* import { Option } from "effect"
*
* const parse = (s: string): number | undefined => {
*   const n = parseFloat(s)
*   return isNaN(n) ? undefined : n
* }
*
* const parseOption = Option.liftNullishOr(parse)
*
* console.log(parseOption("1"))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
*
* console.log(parseOption("not a number"))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link fromNullishOr} for converting a single value
* @see {@link liftThrowable} for functions that throw instead
*
* @category Conversions
* @since 2.0.0
*/
var liftNullishOr = (f) => (...a) => fromNullishOr$1(f(...a));
/**
* Extracts the value from a `Some`, or returns `null` for `None`.
*
* **When to use**
*
* - Interoping with APIs that use `null` for missing values
*
* **Behavior**
*
* - `Some` → the inner value
* - `None` → `null`
*
* **Example** (Unwrapping to null)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.getOrNull(Option.some(1)))
* // Output: 1
*
* console.log(Option.getOrNull(Option.none()))
* // Output: null
* ```
*
* @see {@link getOrUndefined} to return `undefined` instead
* @see {@link getOrElse} for a custom fallback
*
* @category Getters
* @since 2.0.0
*/
var getOrNull$1 = /*#__PURE__*/ getOrElse$1(constNull);
/**
* Extracts the value from a `Some`, or returns `undefined` for `None`.
*
* **When to use**
*
* - Interoping with APIs that use `undefined` for missing values
*
* **Behavior**
*
* - `Some` → the inner value
* - `None` → `undefined`
*
* **Example** (Unwrapping to undefined)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.getOrUndefined(Option.some(1)))
* // Output: 1
*
* console.log(Option.getOrUndefined(Option.none()))
* // Output: undefined
* ```
*
* @see {@link getOrNull} to return `null` instead
* @see {@link getOrElse} for a custom fallback
*
* @category Getters
* @since 2.0.0
*/
var getOrUndefined$1 = /*#__PURE__*/ getOrElse$1(constUndefined);
/**
* Lifts a function that may throw into one that returns an `Option`.
*
* **When to use**
*
* - Wrapping exception-throwing APIs (e.g. `JSON.parse`) for safe usage
*
* **Behavior**
*
* - If the function returns normally → `Some` with the result
* - If the function throws → `None` (exception is swallowed)
*
* **Example** (Lifting JSON.parse)
*
* ```ts
* import { Option } from "effect"
*
* const parse = Option.liftThrowable(JSON.parse)
*
* console.log(parse("1"))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
*
* console.log(parse(""))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link liftNullishOr} for nullable-returning functions
*
* @category Conversions
* @since 2.0.0
*/
var liftThrowable = (f) => (...a) => {
	try {
		return some$1(f(...a));
	} catch {
		return none();
	}
};
/**
* Extracts the value from a `Some`, or throws a custom error for `None`.
*
* **When to use**
*
* - Fail-fast unwrapping when absence is unexpected
* - Providing a descriptive error for debugging
*
* **Behavior**
*
* - `Some` → returns the inner value
* - `None` → throws the value returned by `onNone()`
*
* **Example** (Throwing a custom error)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.getOrThrowWith(Option.some(1), () => new Error("missing")))
* // Output: 1
*
* Option.getOrThrowWith(Option.none(), () => new Error("missing"))
* // throws Error: missing
* ```
*
* @see {@link getOrThrow} for a version with a default error
* @see {@link getOrElse} for a non-throwing alternative
*
* @category Conversions
* @since 2.0.0
*/
var getOrThrowWith$1 = /*#__PURE__*/ dual(2, (self, onNone) => {
	if (isSome(self)) return self.value;
	throw onNone();
});
/**
* Extracts the value from a `Some`, or throws a default `Error` for `None`.
*
* **When to use**
*
* - Quick fail-fast unwrapping when a generic error is acceptable
*
* **Behavior**
*
* - `Some` → returns the inner value
* - `None` → throws `new Error("getOrThrow called on a None")`
*
* **Example** (Throwing a default error)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.getOrThrow(Option.some(1)))
* // Output: 1
*
* Option.getOrThrow(Option.none())
* // throws Error: getOrThrow called on a None
* ```
*
* @see {@link getOrThrowWith} for a custom error
* @see {@link getOrElse} for a non-throwing alternative
*
* @category Conversions
* @since 2.0.0
*/
var getOrThrow$1 = /*#__PURE__*/ getOrThrowWith$1(() => /* @__PURE__ */ new Error("getOrThrow called on a None"));
/**
* Transforms the value inside a `Some` using the provided function, leaving
* `None` unchanged.
*
* **When to use**
*
* - Applying a pure transformation to an optional value
* - Chaining transformations in a pipeline
*
* **Behavior**
*
* - `Some` → applies `f` and wraps the result in a new `Some`
* - `None` → returns `None` unchanged
* - Does not mutate the input
*
* **Example** (Mapping over an Option)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.map(Option.some(2), (n) => n * 2))
* // Output: { _id: 'Option', _tag: 'Some', value: 4 }
*
* console.log(Option.map(Option.none(), (n: number) => n * 2))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link flatMap} when `f` returns an `Option`
* @see {@link as} to replace the value with a constant
*
* @category Mapping
* @since 2.0.0
*/
var map$2 = /*#__PURE__*/ dual(2, (self, f) => isNone(self) ? none() : some$1(f(self.value)));
/**
* Replaces the value inside a `Some` with a constant, leaving `None` unchanged.
*
* **When to use**
*
* - Preserving presence/absence while discarding the original value
*
* **Behavior**
*
* - `Some` → `Some(b)`
* - `None` → `None`
*
* **Example** (Replacing a value)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.as(Option.some(42), "new value"))
* // Output: { _id: 'Option', _tag: 'Some', value: 'new value' }
*
* console.log(Option.as(Option.none(), "new value"))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link asVoid} to replace with `undefined`
* @see {@link map} for a general transformation
*
* @category Mapping
* @since 2.0.0
*/
var as = /*#__PURE__*/ dual(2, (self, b) => map$2(self, () => b));
/**
* Replaces the value inside a `Some` with `void` (`undefined`), leaving `None`
* unchanged.
*
* **When to use**
*
* - Discarding the value while preserving presence/absence
*
* **Behavior**
*
* - `Some` → `Some(undefined)`
* - `None` → `None`
*
* **Example** (Voiding the value)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.asVoid(Option.some(42)))
* // Output: { _id: 'Option', _tag: 'Some', value: undefined }
*
* console.log(Option.asVoid(Option.none()))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link as} to replace with a specific constant
*
* @category Mapping
* @since 2.0.0
*/
var asVoid = /*#__PURE__*/ as(void 0);
var void_$1 = /*#__PURE__*/ some$1(void 0);
/**
* Applies a function that returns an `Option` to the value of a `Some`,
* flattening the result. Returns `None` if the input is `None`.
*
* **When to use**
*
* - Chaining computations that each may fail (return `None`)
* - Sequencing dependent optional operations
*
* **Behavior**
*
* - `Some` → applies `f` to the value and returns its `Option` result
* - `None` → returns `None` without calling `f`
* - Equivalent to `map` followed by {@link flatten}
*
* **Example** (Chaining optional lookups)
*
* ```ts
* import { Option } from "effect"
*
* interface User {
*   readonly name: string
*   readonly address: Option.Option<{ readonly street: Option.Option<string> }>
* }
*
* const user: User = {
*   name: "John",
*   address: Option.some({ street: Option.some("123 Main St") })
* }
*
* const street = user.address.pipe(
*   Option.flatMap((addr) => addr.street)
* )
*
* console.log(street)
* // Output: { _id: 'Option', _tag: 'Some', value: '123 Main St' }
* ```
*
* @see {@link map} when `f` returns a plain value
* @see {@link andThen} for a more flexible variant
* @see {@link flatten} to unwrap a nested `Option<Option<A>>`
*
* @category Sequencing
* @since 2.0.0
*/
var flatMap$1 = /*#__PURE__*/ dual(2, (self, f) => isNone(self) ? none() : f(self.value));
/**
* Chains a second computation onto an `Option`. The second value can be a
* plain value, an `Option`, or a function returning either.
*
* **When to use**
*
* - Flexible chaining where the next step may return `Option`, a plain value,
*   or a function
*
* **Behavior**
*
* - If `self` is `None`, returns `None` immediately
* - If `f` is a function, calls it with the `Some` value
* - If `f` returns an `Option`, returns it as-is; if a plain value, wraps in `Some`
* - If `f` is not a function, uses it directly (same wrapping rules)
*
* **Example** (Chaining with andThen)
*
* ```ts
* import { Option } from "effect"
*
* // Chain with a function returning Option
* console.log(Option.andThen(Option.some(5), (x) => Option.some(x * 2)))
* // Output: { _id: 'Option', _tag: 'Some', value: 10 }
*
* // Chain with a static value
* console.log(Option.andThen(Option.some(5), "hello"))
* // Output: { _id: 'Option', _tag: 'Some', value: "hello" }
*
* // Chain with None - skips
* console.log(Option.andThen(Option.none(), (x) => Option.some(x * 2)))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link flatMap} for the standard monadic bind
* @see {@link map} when you always return a plain value
*
* @category Sequencing
* @since 2.0.0
*/
var andThen$1 = /*#__PURE__*/ dual(2, (self, f) => flatMap$1(self, (a) => {
	const b = isFunction(f) ? f(a) : f;
	return isOption(b) ? b : some$1(b);
}));
/**
* Combines {@link flatMap} with {@link fromNullishOr}: applies a function that
* may return `null`/`undefined` to the value of a `Some`.
*
* **When to use**
*
* - Chaining with functions that use `null`/`undefined` instead of `Option`
* - Navigating deeply nested optional properties
*
* **Behavior**
*
* - `None` → `None`
* - `Some` → applies `f`, then wraps via {@link fromNullishOr}
*
* **Example** (Navigating optional properties)
*
* ```ts
* import { Option } from "effect"
*
* interface Employee {
*   company?: { address?: { street?: { name?: string } } }
* }
*
* const emp: Employee = {
*   company: { address: { street: { name: "high street" } } }
* }
*
* console.log(
*   Option.some(emp).pipe(
*     Option.flatMapNullishOr((e) => e.company?.address?.street?.name)
*   )
* )
* // Output: { _id: 'Option', _tag: 'Some', value: 'high street' }
* ```
*
* @see {@link flatMap} when the function already returns `Option`
* @see {@link fromNullishOr} for single-value conversion
*
* @category Sequencing
* @since 2.0.0
*/
var flatMapNullishOr = /*#__PURE__*/ dual(2, (self, f) => isNone(self) ? none() : fromNullishOr$1(f(self.value)));
/**
* Flattens a nested `Option<Option<A>>` into `Option<A>`.
*
* **When to use**
*
* - Removing one layer of `Option` nesting
*
* **Behavior**
*
* - `Some(Some(value))` → `Some(value)`
* - `Some(None)` → `None`
* - `None` → `None`
*
* **Example** (Flattening nested Options)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.flatten(Option.some(Option.some("value"))))
* // Output: { _id: 'Option', _tag: 'Some', value: 'value' }
*
* console.log(Option.flatten(Option.some(Option.none())))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link flatMap} which is `map` + `flatten`
*
* @category Sequencing
* @since 2.0.0
*/
var flatten = /*#__PURE__*/ flatMap$1(identity);
/**
* Sequences two `Option`s, keeping the value from the second if both are `Some`.
*
* **When to use**
*
* - Running a side-condition that must succeed, then using the second value
*
* **Behavior**
*
* - Both `Some` → returns `that`
* - Either `None` → returns `None`
*
* **Example** (Keeping the second value)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.zipRight(Option.some(1), Option.some("hello")))
* // Output: { _id: 'Option', _tag: 'Some', value: 'hello' }
*
* console.log(Option.zipRight(Option.none(), Option.some("hello")))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link zipLeft} to keep the first value instead
* @see {@link zipWith} to combine both values
*
* @category Zipping
* @since 2.0.0
*/
var zipRight = /*#__PURE__*/ dual(2, (self, that) => flatMap$1(self, () => that));
/**
* Sequences two `Option`s, keeping the value from the first if both are `Some`.
*
* **When to use**
*
* - Running a validation that must succeed, but keeping the original value
*
* **Behavior**
*
* - Both `Some` → returns `self`
* - Either `None` → returns `None`
*
* **Example** (Keeping the first value)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.zipLeft(Option.some("hello"), Option.some(1)))
* // Output: { _id: 'Option', _tag: 'Some', value: 'hello' }
*
* console.log(Option.zipLeft(Option.some("hello"), Option.none()))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link zipRight} to keep the second value instead
* @see {@link zipWith} to combine both values
*
* @category Zipping
* @since 2.0.0
*/
var zipLeft = /*#__PURE__*/ dual(2, (self, that) => tap$1(self, () => that));
/**
* Composes two `Option`-returning functions into a single function that chains
* them together.
*
* **When to use**
*
* - Building pipelines of partial functions (Kleisli composition)
*
* **Behavior**
*
* - Calls `afb(a)`, then if `Some`, calls `bfc` with its value
* - Short-circuits to `None` if either function returns `None`
*
* **Example** (Composing parsers)
*
* ```ts
* import { Option } from "effect"
*
* const parse = (s: string): Option.Option<number> =>
*   isNaN(Number(s)) ? Option.none() : Option.some(Number(s))
*
* const double = (n: number): Option.Option<number> =>
*   n > 0 ? Option.some(n * 2) : Option.none()
*
* const parseAndDouble = Option.composeK(parse, double)
*
* console.log(parseAndDouble("42"))
* // Output: { _id: 'Option', _tag: 'Some', value: 84 }
*
* console.log(parseAndDouble("not a number"))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link flatMap} for single-step chaining
*
* @category Sequencing
* @since 2.0.0
*/
var composeK = /*#__PURE__*/ dual(2, (afb, bfc) => (a) => flatMap$1(afb(a), bfc));
/**
* Runs a side-effecting `Option`-returning function on the value of a `Some`,
* returning the original `Option` if the function returns `Some`, or `None`
* if it returns `None`.
*
* **When to use**
*
* - Validating a value without transforming it
* - Adding a side-condition check in a pipeline
*
* **Behavior**
*
* - `None` → `None`
* - `Some` → calls `f(value)`; if result is `Some`, returns original `self`; if `None`, returns `None`
*
* **Example** (Validating without transforming)
*
* ```ts
* import { Option } from "effect"
*
* const getInteger = (n: number) =>
*   Number.isInteger(n) ? Option.some(n) : Option.none()
*
* console.log(Option.tap(Option.some(1), getInteger))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
*
* console.log(Option.tap(Option.some(1.14), getInteger))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link flatMap} when you want to transform the value
* @see {@link filter} for predicate-based filtering
*
* @category Sequencing
* @since 2.0.0
*/
var tap$1 = /*#__PURE__*/ dual(2, (self, f) => flatMap$1(self, (a) => map$2(f(a), () => a)));
/**
* Combines two `Option`s into a `Some` containing a tuple `[A, B]` if both
* are `Some`.
*
* **When to use**
*
* - Pairing two optional values together
*
* **Behavior**
*
* - Both `Some` → `Some([a, b])`
* - Either `None` → `None`
*
* **Example** (Pairing two Options)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.product(Option.some("hello"), Option.some(42)))
* // Output: { _id: 'Option', _tag: 'Some', value: ['hello', 42] }
*
* console.log(Option.product(Option.none(), Option.some(42)))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link zipWith} to combine with a function instead of a tuple
* @see {@link all} to combine many `Option`s
*
* @category Combining
* @since 2.0.0
*/
var product = (self, that) => isSome(self) && isSome(that) ? some$1([self.value, that.value]) : none();
/**
* Combines a primary `Option` with an iterable of `Option`s into a tuple if
* all are `Some`.
*
* **When to use**
*
* - Collecting several `Option`s of the same type into a non-empty tuple
*
* **Behavior**
*
* - All `Some` → `Some([self.value, ...rest])`
* - Any `None` → `None`
*
* **Example** (Combining many Options)
*
* ```ts
* import { Option } from "effect"
*
* const first = Option.some(1)
* const rest = [Option.some(2), Option.some(3)]
*
* console.log(Option.productMany(first, rest))
* // Output: { _id: 'Option', _tag: 'Some', value: [1, 2, 3] }
*
* console.log(Option.productMany(first, [Option.some(2), Option.none()]))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link product} for combining exactly two
* @see {@link all} for tuples, structs, and iterables
*
* @category Combining
* @since 2.0.0
*/
var productMany = (self, collection) => {
	if (isNone(self)) return none();
	const out = [self.value];
	for (const o of collection) {
		if (isNone(o)) return none();
		out.push(o.value);
	}
	return some$1(out);
};
/**
* Combines a structure of `Option`s (tuple, struct, or iterable) into a single
* `Option` containing the unwrapped structure.
*
* **When to use**
*
* - Collecting multiple `Option`s into one, preserving the input shape
* - "All or nothing" combination — any `None` makes the result `None`
*
* **Behavior**
*
* - Tuple input → `Option` of a tuple with the same length
* - Struct input → `Option` of a struct with the same keys
* - Iterable input → `Option` of an `Array`
* - Any `None` in the input → entire result is `None`
*
* **Example** (Combining a tuple and a struct)
*
* ```ts
* import { Option } from "effect"
*
* const maybeName: Option.Option<string> = Option.some("John")
* const maybeAge: Option.Option<number> = Option.some(25)
*
* //      ┌─── Option<[string, number]>
* //      ▼
* const tuple = Option.all([maybeName, maybeAge])
* console.log(tuple)
* // Output:
* // { _id: 'Option', _tag: 'Some', value: [ 'John', 25 ] }
*
* //      ┌─── Option<{ name: string; age: number; }>
* //      ▼
* const struct = Option.all({ name: maybeName, age: maybeAge })
* console.log(struct)
* // Output:
* // { _id: 'Option', _tag: 'Some', value: { name: 'John', age: 25 } }
* ```
*
* @see {@link product} for combining exactly two
* @see {@link productMany} for a homogeneous collection
*
* @category Combining
* @since 2.0.0
*/
var all$1 = (input) => {
	if (Symbol.iterator in input) {
		const out = [];
		for (const o of input) {
			if (isNone(o)) return none();
			out.push(o.value);
		}
		return some$1(out);
	}
	const out = {};
	for (const key of Object.keys(input)) {
		const o = input[key];
		if (isNone(o)) return none();
		out[key] = o.value;
	}
	return some$1(out);
};
/**
* Combines two `Option`s using a provided function.
*
* **When to use**
*
* - Merging two optional values into a computed result
*
* **Behavior**
*
* - Both `Some` → applies `f(a, b)` and wraps in `Some`
* - Either `None` → `None`
*
* **Example** (Combining with a function)
*
* ```ts
* import { Option } from "effect"
*
* const person = Option.zipWith(
*   Option.some("John"),
*   Option.some(25),
*   (name, age) => ({ name: name.toUpperCase(), age })
* )
*
* console.log(person)
* // Output:
* // { _id: 'Option', _tag: 'Some', value: { name: 'JOHN', age: 25 } }
* ```
*
* @see {@link product} to combine into a tuple instead
* @see {@link lift2} to lift a binary function
*
* @category Zipping
* @since 2.0.0
*/
var zipWith = /*#__PURE__*/ dual(3, (self, that, f) => map$2(product(self, that), ([a, b]) => f(a, b)));
/**
* Reduces an iterable of `Option`s to a single value, skipping `None` entries.
*
* **When to use**
*
* - Aggregating values from a collection where some may be absent
*
* **Behavior**
*
* - Iterates through the collection, applying `f` only to `Some` values
* - `None` values are skipped entirely
* - Returns the accumulated result
*
* **Example** (Summing present values)
*
* ```ts
* import { Option, pipe } from "effect"
*
* const items = [Option.some(1), Option.none(), Option.some(2), Option.none()]
*
* console.log(pipe(items, Option.reduceCompact(0, (b, a) => b + a)))
* // Output: 3
* ```
*
* @category Reducing
* @since 2.0.0
*/
var reduceCompact = /*#__PURE__*/ dual(3, (self, b, f) => {
	let out = b;
	for (const oa of self) if (isSome(oa)) out = f(out, oa.value);
	return out;
});
/**
* Converts an `Option` into an `Array`.
*
* **When to use**
*
* - Interfacing with array-based APIs
* - Spreading optional values into collections
*
* **Behavior**
*
* - `Some` → single-element array `[value]`
* - `None` → empty array `[]`
*
* **Example** (Converting to an array)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.toArray(Option.some(1)))
* // Output: [1]
*
* console.log(Option.toArray(Option.none()))
* // Output: []
* ```
*
* @see {@link fromIterable} for the inverse direction
*
* @category Conversions
* @since 2.0.0
*/
var toArray = (self) => isNone(self) ? [] : [self.value];
/**
* Splits an `Option` into two `Option`s using a function that returns a `Result`.
*
* **When to use**
*
* - Categorizing an optional value into "left" (failure) and "right" (success) channels
*
* **Behavior**
*
* - `None` → `[None, None]`
* - `Some` where `f` returns `Err` → `[Some(error), None]`
* - `Some` where `f` returns `Ok` → `[None, Some(value)]`
*
* **Example** (Partitioning by Result)
*
* ```ts
* import { Option, Result } from "effect"
*
* const parseNumber = (s: string): Result.Result<number, string> => {
*   const n = Number(s)
*   return isNaN(n) ? Result.fail("Not a number") : Result.succeed(n)
* }
*
* console.log(Option.partitionMap(Option.some("42"), parseNumber))
* // Output: [{ _id: 'Option', _tag: 'None' }, { _id: 'Option', _tag: 'Some', value: 42 }]
*
* console.log(Option.partitionMap(Option.some("abc"), parseNumber))
* // Output: [{ _id: 'Option', _tag: 'Some', value: 'Not a number' }, { _id: 'Option', _tag: 'None' }]
*
* console.log(Option.partitionMap(Option.none(), parseNumber))
* // Output: [{ _id: 'Option', _tag: 'None' }, { _id: 'Option', _tag: 'None' }]
* ```
*
* @see {@link filter} for simple predicate-based filtering
*
* @category Filtering
* @since 2.0.0
*/
var partitionMap = /*#__PURE__*/ dual(2, (self, f) => {
	if (isNone(self)) return [none(), none()];
	const e = f(self.value);
	return isFailure$1(e) ? [some$1(e.failure), none()] : [none(), some$1(e.success)];
});
/**
* Transforms and filters an `Option` using a `Filter` callback.
*
* The callback returns a `Result`: `Result.succeed` keeps and transforms the
* value, while `Result.fail` discards it.
*
* **Example** (Filtering and transforming)
*
* ```ts
* import { Option } from "effect"
* import * as Result from "effect/Result"
*
* console.log(Option.filterMap(
*   Option.some(2),
*   (n) => (n % 2 === 0 ? Result.succeed(`Even: ${n}`) : Result.failVoid)
* ))
* // Output: { _id: 'Option', _tag: 'Some', value: 'Even: 2' }
* ```
*
* @see {@link filter} for predicate-based filtering
*
* @category Filtering
* @since 2.0.0
*/
var filterMap$1 = /*#__PURE__*/ dual(2, (self, f) => {
	if (isNone(self)) return none();
	const next = f(self.value);
	return isSuccess$1(next) ? some$1(next.success) : none();
});
/**
* Filters an `Option` using a predicate. Returns `None` if the predicate is
* not satisfied or the input is `None`.
*
* **When to use**
*
* - Discarding values that don't meet a condition
* - Narrowing the type via a refinement predicate
*
* **Behavior**
*
* - `None` → `None`
* - `Some` where `predicate(value)` is `true` → `Some(value)`
* - `Some` where `predicate(value)` is `false` → `None`
* - Supports refinements for type narrowing
*
* **Example** (Filtering with a predicate)
*
* ```ts
* import { Option } from "effect"
*
* const removeEmpty = (input: Option.Option<string>) =>
*   Option.filter(input, (value) => value !== "")
*
* console.log(removeEmpty(Option.some("hello")))
* // Output: { _id: 'Option', _tag: 'Some', value: 'hello' }
*
* console.log(removeEmpty(Option.some("")))
* // Output: { _id: 'Option', _tag: 'None' }
*
* console.log(removeEmpty(Option.none()))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link filterMap} to transform and filter simultaneously
* @see {@link exists} to test without filtering
*
* @category Filtering
* @since 2.0.0
*/
var filter$1 = /*#__PURE__*/ dual(2, (self, predicate) => isNone(self) ? none() : predicate(self.value) ? some$1(self.value) : none());
/**
* Creates an `Equivalence` for `Option<A>` from an `Equivalence` for `A`.
*
* **When to use**
*
* - Comparing two `Option` values for structural equality
*
* **Behavior**
*
* - `None` vs `None` → `true`
* - `Some` vs `None` (or vice versa) → `false`
* - `Some(a)` vs `Some(b)` → delegates to the provided `Equivalence`
*
* **Example** (Comparing Options)
*
* ```ts
* import { Equivalence, Option } from "effect"
*
* const eq = Option.makeEquivalence(Equivalence.strictEqual<number>())
*
* console.log(eq(Option.some(1), Option.some(1)))
* // Output: true
*
* console.log(eq(Option.some(1), Option.some(2)))
* // Output: false
*
* console.log(eq(Option.none(), Option.none()))
* // Output: true
* ```
*
* @category Equivalence
* @since 2.0.0
*/
var makeEquivalence$2 = (isEquivalent) => make$2((x, y) => isNone(x) ? isNone(y) : isNone(y) ? false : isEquivalent(x.value, y.value));
/**
* Creates an `Order` for `Option<A>` from an `Order` for `A`.
*
* **When to use**
*
* - Sorting collections of `Option` values
*
* **Behavior**
*
* - `None` is considered less than any `Some`
* - Two `Some` values are compared using the provided `Order`
* - Two `None` values are equal (returns `0`)
*
* **Example** (Ordering Options)
*
* ```ts
* import { Option } from "effect"
* import * as N from "effect/Number"
*
* const ord = Option.makeOrder(N.Order)
*
* console.log(ord(Option.none(), Option.some(1)))
* // Output: -1
*
* console.log(ord(Option.some(1), Option.none()))
* // Output: 1
*
* console.log(ord(Option.some(1), Option.some(2)))
* // Output: -1
* ```
*
* @category Sorting
* @since 2.0.0
*/
var makeOrder = (O) => make((self, that) => isSome(self) ? isSome(that) ? O(self.value, that.value) : 1 : -1);
/**
* Lifts a binary function to operate on two `Option` values.
*
* **When to use**
*
* - Reusing an existing binary function in an `Option` context
*
* **Behavior**
*
* - Both `Some` → applies `f` and wraps in `Some`
* - Either `None` → `None`
*
* **Example** (Lifting addition)
*
* ```ts
* import { Option } from "effect"
*
* const addOptions = Option.lift2((a: number, b: number) => a + b)
*
* console.log(addOptions(Option.some(2), Option.some(3)))
* // Output: { _id: 'Option', _tag: 'Some', value: 5 }
*
* console.log(addOptions(Option.some(2), Option.none()))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link zipWith} for a non-lifted variant
*
* @category Lifting
* @since 2.0.0
*/
var lift2 = (f) => dual(2, (self, that) => zipWith(self, that, f));
/**
* Lifts a `Predicate` or `Refinement` into the `Option` context: returns
* `Some(value)` when the predicate holds, `None` otherwise.
*
* **When to use**
*
* - Converting a boolean check into an `Option`-returning function
* - Validating input and wrapping it in `Option`
*
* **Behavior**
*
* - `predicate(value)` is `true` → `Some(value)`
* - `predicate(value)` is `false` → `None`
* - Supports refinements for type narrowing
*
* **Example** (Validating positive numbers)
*
* ```ts
* import { Option } from "effect"
*
* const parsePositive = Option.liftPredicate((n: number) => n > 0)
*
* console.log(parsePositive(1))
* // Output: { _id: 'Option', _tag: 'Some', value: 1 }
*
* console.log(parsePositive(-1))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link filter} to apply a predicate to an existing `Option`
* @see {@link toRefinement} for the inverse direction
*
* @category Lifting
* @since 2.0.0
*/
var liftPredicate$1 = /*#__PURE__*/ dual(2, (b, predicate) => predicate(b) ? some$1(b) : none());
/**
* Checks if an `Option` contains a value equivalent to the given one, using a
* custom `Equivalence`.
*
* **When to use**
*
* - Testing membership with a custom equality check
*
* **Behavior**
*
* - `Some` where `isEquivalent(value, a)` is `true` → `true`
* - `Some` where not equivalent, or `None` → `false`
*
* **Example** (Custom equivalence check)
*
* ```ts
* import { Equivalence, Option } from "effect"
*
* const check = Option.containsWith(Equivalence.strictEqual<number>())
*
* console.log(Option.some(2).pipe(check(2)))
* // Output: true
*
* console.log(Option.some(1).pipe(check(2)))
* // Output: false
*
* console.log(Option.none().pipe(check(2)))
* // Output: false
* ```
*
* @see {@link contains} for a version using default equality
*
* @category Elements
* @since 2.0.0
*/
var containsWith = (isEquivalent) => dual(2, (self, a) => isNone(self) ? false : isEquivalent(self.value, a));
/**
* Checks if an `Option` contains a value equal to the given one, using default
* structural equality.
*
* **When to use**
*
* - Quick membership test with standard equality
*
* **Behavior**
*
* - `Some` where `Equal.equals(value, a)` is `true` → `true`
* - `Some` where not equal, or `None` → `false`
*
* **Example** (Checking containment)
*
* ```ts
* import { Option } from "effect"
*
* console.log(Option.some(2).pipe(Option.contains(2)))
* // Output: true
*
* console.log(Option.some(1).pipe(Option.contains(2)))
* // Output: false
*
* console.log(Option.none().pipe(Option.contains(2)))
* // Output: false
* ```
*
* @see {@link containsWith} for custom equality
* @see {@link exists} to test with a predicate
*
* @category Elements
* @since 2.0.0
*/
var contains = /*#__PURE__*/ containsWith(/*#__PURE__*/ asEquivalence());
/**
* Tests if the value in a `Some` satisfies a predicate or refinement.
*
* **When to use**
*
* - Checking a condition on an optional value without unwrapping
*
* **Behavior**
*
* - `None` → `false`
* - `Some` where `predicate(value)` is `true` → `true`
* - `Some` where `predicate(value)` is `false` → `false`
* - With a refinement, narrows the `Option` type on `true`
*
* **Example** (Testing a condition)
*
* ```ts
* import { Option } from "effect"
*
* const isEven = (n: number) => n % 2 === 0
*
* console.log(Option.some(2).pipe(Option.exists(isEven)))
* // Output: true
*
* console.log(Option.some(1).pipe(Option.exists(isEven)))
* // Output: false
*
* console.log(Option.none().pipe(Option.exists(isEven)))
* // Output: false
* ```
*
* @see {@link filter} to keep or discard based on a predicate
* @see {@link contains} to test for a specific value
*
* @category Elements
* @since 2.0.0
*/
var exists = /*#__PURE__*/ dual(2, (self, refinement) => isNone(self) ? false : refinement(self.value));
/**
* Gives a name to the value of an `Option`, creating a single-key record
* inside `Some`. Starting point for the do notation pipeline.
*
* **When to use**
*
* - Beginning a do notation chain by naming the first value
*
* **Example** (Starting do notation)
*
* ```ts
* import { Option, pipe } from "effect"
* import * as assert from "node:assert"
*
* const result = pipe(
*   Option.some(2),
*   Option.bindTo("x"),
*   Option.bind("y", () => Option.some(3)),
*   Option.let("sum", ({ x, y }) => x + y)
* )
* assert.deepStrictEqual(result, Option.some({ x: 2, y: 3, sum: 5 }))
* ```
*
* @see {@link Do} for starting with an empty record
* @see {@link bind} to add `Option` values
* @see {@link let_ let} to add plain values
*
* @category Do notation
* @since 2.0.0
*/
var bindTo$1 = /*#__PURE__*/ bindTo$2(map$2);
var let_$1 = /*#__PURE__*/ let_$2(map$2);
/**
* Adds an `Option` value to the do notation record under a given name. If the
* `Option` is `None`, the whole pipeline short-circuits to `None`.
*
* **When to use**
*
* - Sequencing `Option` computations in do notation
*
* **Example** (Binding Option values)
*
* ```ts
* import { Option, pipe } from "effect"
* import * as assert from "node:assert"
*
* const result = pipe(
*   Option.Do,
*   Option.bind("x", () => Option.some(2)),
*   Option.bind("y", () => Option.some(3)),
*   Option.let("sum", ({ x, y }) => x + y),
*   Option.filter(({ x, y }) => x * y > 5)
* )
* assert.deepStrictEqual(result, Option.some({ x: 2, y: 3, sum: 5 }))
* ```
*
* @see {@link Do} for starting the chain
* @see {@link let_ let} to add plain values
* @see {@link bindTo} to start by naming an existing `Option`
*
* @category Do notation
* @since 2.0.0
*/
var bind$1 = /*#__PURE__*/ bind$2(map$2, flatMap$1);
/**
* An `Option` containing an empty record `{}`, used as the starting point for
* do notation chains.
*
* **When to use**
*
* - Starting a do notation pipeline before adding bindings
*
* **Example** (Do notation pipeline)
*
* ```ts
* import { Option, pipe } from "effect"
* import * as assert from "node:assert"
*
* const result = pipe(
*   Option.Do,
*   Option.bind("x", () => Option.some(2)),
*   Option.bind("y", () => Option.some(3)),
*   Option.let("sum", ({ x, y }) => x + y),
*   Option.filter(({ x, y }) => x * y > 5)
* )
* assert.deepStrictEqual(result, Option.some({ x: 2, y: 3, sum: 5 }))
* ```
*
* @see {@link bind} to add `Option` values
* @see {@link let_ let} to add plain values
* @see {@link bindTo} to start by naming an existing `Option`
*
* @category Do notation
* @since 2.0.0
*/
var Do$1 = /*#__PURE__*/ some$1({});
/**
* Generator-based syntax for `Option`, similar to `async`/`await` but for
* optional values. Yielding a `None` short-circuits the generator to `None`.
*
* **When to use**
*
* - Writing imperative-style code that chains multiple `Option`s
* - Readability when many sequential optional steps are involved
*
* **Behavior**
*
* - Each `yield*` unwraps a `Some` value or short-circuits to `None`
* - The return value is wrapped in `Some`
* - No `Effect` runtime is needed
*
* **Example** (Generator syntax)
*
* ```ts
* import { Option } from "effect"
*
* const maybeName: Option.Option<string> = Option.some("John")
* const maybeAge: Option.Option<number> = Option.some(25)
*
* const person = Option.gen(function*() {
*   const name = (yield* maybeName).toUpperCase()
*   const age = yield* maybeAge
*   return { name, age }
* })
*
* console.log(person)
* // Output:
* // { _id: 'Option', _tag: 'Some', value: { name: 'JOHN', age: 25 } }
* ```
*
* @see {@link Do} / {@link bind} for the do notation alternative
*
* @category Generators
* @since 2.0.0
*/
var gen$1 = (...args) => {
	const iterator = (args.length === 1 ? args[0] : args[1].bind(args[0]))();
	let state = iterator.next();
	while (!state.done) {
		const current = isGenKind(state.value) ? state.value.value : state.value;
		if (isNone(current)) return current;
		state = iterator.next(current.value);
	}
	return some$1(state.value);
};
/**
* Creates a `Reducer` for `Option<A>` that prioritizes the first non-`None`
* value and combines values when both are `Some`.
*
* **When to use**
*
* - Building a reducer that falls back to the first available value
* - Combining optional values where either side may be absent
*
* **Behavior**
*
* - `None` + `None` → `None`
* - `Some(a)` + `None` → `Some(a)`
* - `None` + `Some(b)` → `Some(b)`
* - `Some(a)` + `Some(b)` → `Some(combine(a, b))`
* - Initial value is `None`
*
* **Example** (Reducing with first-wins semantics)
*
* ```ts
* import { Number, Option } from "effect"
*
* const reducer = Option.makeReducer(Number.ReducerSum)
* console.log(reducer.combineAll([Option.some(1), Option.none(), Option.some(2)]))
* // Output: { _id: 'Option', _tag: 'Some', value: 3 }
* ```
*
* @see {@link makeReducerFailFast} for fail-fast semantics
*
* @since 4.0.0
*/
function makeReducer(combiner) {
	return make$3((self, that) => {
		if (isNone(self)) return that;
		if (isNone(that)) return self;
		return some$1(combiner.combine(self.value, that.value));
	}, none());
}
/**
* Creates a `Combiner` for `Option<A>` with fail-fast semantics: returns `None`
* if either operand is `None`.
*
* **When to use**
*
* - Operations that require both values to be present
*
* **Behavior**
*
* - `None` + anything → `None`
* - anything + `None` → `None`
* - `Some(a)` + `Some(b)` → `Some(combine(a, b))`
*
* **Example** (Fail-fast combining)
*
* ```ts
* import { Number, Option } from "effect"
*
* const combiner = Option.makeCombinerFailFast(Number.ReducerSum)
* console.log(combiner.combine(Option.some(1), Option.some(2)))
* // Output: { _id: 'Option', _tag: 'Some', value: 3 }
*
* console.log(combiner.combine(Option.some(1), Option.none()))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link makeReducerFailFast} to get a full `Reducer`
*
* @since 4.0.0
*/
function makeCombinerFailFast(combiner) {
	return make$1((self, that) => {
		if (isNone(self) || isNone(that)) return none();
		return some$1(combiner.combine(self.value, that.value));
	});
}
/**
* Creates a `Reducer` for `Option<A>` by lifting an existing `Reducer` with
* fail-fast semantics.
*
* **When to use**
*
* - Wrapping an existing `Reducer` to work with `Option` values
* - Reductions where any `None` should abort the entire result
*
* **Behavior**
*
* - Initial value is `Some(reducer.initialValue)`
* - Combines only when both operands are `Some`
* - Any `None` causes the result to become `None` immediately
*
* **Example** (Fail-fast reducing)
*
* ```ts
* import { Number, Option } from "effect"
*
* const reducer = Option.makeReducerFailFast(Number.ReducerSum)
* console.log(reducer.combineAll([Option.some(1), Option.some(2)]))
* // Output: { _id: 'Option', _tag: 'Some', value: 3 }
*
* console.log(reducer.combineAll([Option.some(1), Option.none()]))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @see {@link makeCombinerFailFast} for just the combiner
* @see {@link makeReducer} for non-fail-fast semantics
*
* @since 4.0.0
*/
function makeReducerFailFast(reducer) {
	const combine = makeCombinerFailFast(reducer).combine;
	const initialValue = some$1(reducer.initialValue);
	return make$3(combine, initialValue, (collection) => {
		let out = initialValue;
		for (const value of collection) {
			out = combine(out, value);
			if (isNone(out)) return out;
		}
		return out;
	});
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Result.js
/**
* A synchronous, pure type for representing computations that can succeed
* (`Success<A>`) or fail (`Failure<E>`). Unlike `Effect`, `Result` is
* evaluated eagerly and carries no side effects.
*
* **Mental model**
*
* - `Result<A, E>` is a discriminated union: `Success<A, E> | Failure<A, E>`
* - `Success` wraps a value of type `A`, accessed via `.success`
* - `Failure` wraps an error of type `E`, accessed via `.failure`
* - `Result` is a monad: chain operations with {@link flatMap}, compose pipelines with `pipe`
* - All operations are pure and return new `Result` values; the input is never mutated
* - `Result` is yieldable in `Effect.gen`, producing the inner value or short-circuiting on failure
*
* **Common tasks**
*
* - Create from a value: {@link succeed}, {@link fail}
* - Create from nullable: {@link fromNullishOr}
* - Create from Option: {@link fromOption}
* - Create from throwing code: {@link try_ try}
* - Create from predicate: {@link liftPredicate}
* - Transform: {@link map}, {@link mapError}, {@link mapBoth}
* - Unwrap: {@link getOrElse}, {@link getOrNull}, {@link getOrUndefined}, {@link getOrThrow}
* - Pattern match: {@link match}
* - Sequence: {@link flatMap}, {@link andThen}, {@link all}
* - Recover: {@link orElse}
* - Filter: {@link filterOrFail}
* - Convert to Option: {@link getSuccess}, {@link getFailure}
* - Generator syntax: {@link gen}
* - Do notation: {@link Do}, {@link bind}, {@link let_ let}
* - Check variant: {@link isResult}, {@link isSuccess}, {@link isFailure}
*
* **Gotchas**
*
* - `E` defaults to `never`, so `Result<number>` means a result that cannot fail
* - {@link andThen} accepts a `Result`, a function returning a `Result`, a plain value, or a function returning a plain value; {@link flatMap} only accepts a function returning a `Result`
* - {@link all} short-circuits on the first `Failure` and returns it; later elements are not inspected
* - {@link getOrThrow} throws the raw failure value `E`; use {@link getOrThrowWith} for custom error objects
* - {@link tap} runs a side-effect but does not change the result; its return value is ignored
*
* **Quickstart**
*
* **Example** (Parsing and validating with Result)
*
* ```ts
* import { Result } from "effect"
*
* const parse = (input: string): Result.Result<number, string> =>
*   isNaN(Number(input))
*     ? Result.fail("not a number")
*     : Result.succeed(Number(input))
*
* const ensurePositive = (n: number): Result.Result<number, string> =>
*   n > 0 ? Result.succeed(n) : Result.fail("not positive")
*
* const result = Result.flatMap(parse("42"), ensurePositive)
*
* console.log(Result.getOrElse(result, (err) => `Error: ${err}`))
* // Output: 42
* ```
*
* **See also**
*
* - {@link succeed} / {@link fail} to create values
* - {@link match} to fold both branches
* - {@link gen} for generator-based composition
*
* @since 4.0.0
*/
var Result_exports = /* @__PURE__ */ __exportAll({
	Do: () => Do,
	all: () => all,
	andThen: () => andThen,
	bind: () => bind,
	bindTo: () => bindTo,
	fail: () => fail,
	failVoid: () => failVoid,
	filterOrFail: () => filterOrFail,
	flatMap: () => flatMap,
	flip: () => flip,
	fromNullishOr: () => fromNullishOr,
	fromOption: () => fromOption,
	gen: () => gen,
	getFailure: () => getFailure,
	getOrElse: () => getOrElse,
	getOrNull: () => getOrNull,
	getOrThrow: () => getOrThrow,
	getOrThrowWith: () => getOrThrowWith,
	getOrUndefined: () => getOrUndefined,
	getSuccess: () => getSuccess,
	isFailure: () => isFailure,
	isResult: () => isResult,
	isSuccess: () => isSuccess,
	let: () => let_,
	liftPredicate: () => liftPredicate,
	makeEquivalence: () => makeEquivalence$1,
	map: () => map$1,
	mapBoth: () => mapBoth,
	mapError: () => mapError,
	match: () => match,
	merge: () => merge,
	orElse: () => orElse,
	succeed: () => succeed,
	succeedNone: () => succeedNone,
	succeedSome: () => succeedSome,
	tap: () => tap,
	transposeMapOption: () => transposeMapOption,
	transposeOption: () => transposeOption,
	try: () => try_,
	void: () => void_
});
/**
* Creates a `Result` holding a `Success` value.
*
* - Use when you have a value and want to lift it into the `Result` type
* - The error type `E` defaults to `never`
* - Does not mutate input; allocates a new `Success` wrapper
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Either.right`
*
* **Example** (Wrapping a value)
*
* ```ts
* import { Result } from "effect"
*
* const result = Result.succeed(42)
*
* console.log(Result.isSuccess(result))
* // Output: true
* ```
*
* @see {@link fail} to create a Failure
* @see {@link void} for a pre-built `Success<void>`
*
* @category Constructors
* @since 4.0.0
*/
var succeed = succeed$1;
/**
* Creates a `Result` holding a `Failure` value.
*
* - Use when you want to represent a failed computation
* - The success type `A` defaults to `never`
* - Does not mutate input; allocates a new `Failure` wrapper
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Either.left`
*
* **Example** (Creating a failure)
*
* ```ts
* import { Result } from "effect"
*
* const result = Result.fail("Something went wrong")
*
* console.log(Result.isFailure(result))
* // Output: true
* ```
*
* @see {@link succeed} to create a Success
* @see {@link mapError} to transform the error
*
* @category Constructors
* @since 4.0.0
*/
var fail = fail$1;
var void_ = /*#__PURE__*/ succeed(void 0);
/**
* A pre-built `Result<void>` holding `undefined` as its failure value.
*
* - Use when you need a `Result` that represents "failed with no meaningful value"
* - Equivalent to `Result.fail(undefined)` but avoids an extra allocation
*
* @see {@link fail}
*
* @category Constructors
* @since 4.0.0
*/
var failVoid = /*#__PURE__*/ fail(void 0);
/**
* Converts a possibly `null` or `undefined` value into a `Result`.
*
* - Non-nullish values become `Success<NonNullable<A>>`
* - `null` or `undefined` becomes `Failure<E>` using the provided function
* - Supports both data-first and data-last (piped) usage
* - The `onNullish` callback receives the original value
*
* **Example** (Handling nullable values)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.fromNullishOr(1, () => "fallback"))
* // Output: { _tag: "Success", success: 1, ... }
*
* console.log(Result.fromNullishOr(null, () => "fallback"))
* // Output: { _tag: "Failure", failure: "fallback", ... }
* ```
*
* @see {@link fromOption} to convert from an Option
* @see {@link succeed} / {@link fail} for direct construction
*
* @category Constructors
* @since 4.0.0
*/
var fromNullishOr = /*#__PURE__*/ dual(2, (self, onNullish) => self == null ? fail(onNullish(self)) : succeed(self));
/**
* Converts an `Option<A>` into a `Result<A, E>`.
*
* - `Some<A>` becomes `Success<A>`
* - `None` becomes `Failure<E>` using the provided function
* - Supports both data-first and data-last (piped) usage
*
* **Example** (Converting an Option to a Result)
*
* ```ts
* import { Option, Result } from "effect"
*
* const some = Result.fromOption(Option.some(1), () => "missing")
* console.log(some)
* // Output: { _tag: "Success", success: 1, ... }
*
* const none = Result.fromOption(Option.none(), () => "missing")
* console.log(none)
* // Output: { _tag: "Failure", failure: "missing", ... }
* ```
*
* @see {@link getSuccess} / {@link getFailure} to convert back to Option
* @see {@link fromNullishOr} to convert from nullable values
*
* @category Constructors
* @since 4.0.0
*/
var fromOption = fromOption$1;
var try_ = (evaluate) => {
	if (isFunction(evaluate)) try {
		return succeed(evaluate());
	} catch (e) {
		return fail(e);
	}
	else try {
		return succeed(evaluate.try());
	} catch (e) {
		return fail(evaluate.catch(e));
	}
};
/**
* Tests whether a value is a `Result` (either `Success` or `Failure`).
*
* - Use to validate unknown input before operating on it as a `Result`
* - Returns `true` for both `Success` and `Failure` variants
* - Acts as a TypeScript type guard, narrowing to `Result<unknown, unknown>`
*
* **Example** (Checking if a value is a Result)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.isResult(Result.succeed(1)))
* // Output: true
*
* console.log(Result.isResult({ value: 1 }))
* // Output: false
* ```
*
* @see {@link isSuccess} / {@link isFailure} to narrow to a specific variant
*
* @category Type Guards
* @since 4.0.0
*/
var isResult = isResult$1;
/**
* Checks whether a `Result` is a `Failure`.
*
* - Acts as a TypeScript type guard, narrowing to `Failure<A, E>`
* - After narrowing, you can access `.failure` to read the error value
*
* **Example** (Narrowing to Failure)
*
* ```ts
* import { Result } from "effect"
*
* const result = Result.fail("oops")
*
* if (Result.isFailure(result)) {
*   console.log(result.failure)
*   // Output: "oops"
* }
* ```
*
* @see {@link isSuccess} for the opposite check
* @see {@link isResult} to check if a value is any Result
*
* @category Type Guards
* @since 4.0.0
*/
var isFailure = isFailure$1;
/**
* Checks whether a `Result` is a `Success`.
*
* - Acts as a TypeScript type guard, narrowing to `Success<A, E>`
* - After narrowing, you can access `.success` to read the value
*
* **Example** (Narrowing to Success)
*
* ```ts
* import { Result } from "effect"
*
* const result = Result.succeed(42)
*
* if (Result.isSuccess(result)) {
*   console.log(result.success)
*   // Output: 42
* }
* ```
*
* @see {@link isFailure} for the opposite check
* @see {@link isResult} to check if a value is any Result
*
* @category Type Guards
* @since 4.0.0
*/
var isSuccess = isSuccess$1;
/**
* Extracts the success value as an `Option`, discarding the failure.
*
* - `Success<A>` becomes `Some<A>`
* - `Failure<E>` becomes `None`
* - Use when you only care about the success case and want to discard error info
*
* **Example** (Extracting the success as an Option)
*
* ```ts
* import { Option, Result } from "effect"
*
* console.log(Result.getSuccess(Result.succeed("ok")))
* // Output: { _tag: "Some", value: "ok" }
*
* console.log(Result.getSuccess(Result.fail("err")))
* // Output: { _tag: "None" }
* ```
*
* @see {@link getFailure} to extract the error instead
* @see {@link fromOption} for the reverse conversion
*
* @category Getters
* @since 4.0.0
*/
var getSuccess = getSuccess$2;
/**
* Extracts the failure value as an `Option`, discarding the success.
*
* - `Failure<E>` becomes `Some<E>`
* - `Success<A>` becomes `None`
* - Use when you only care about the error case
*
* **Example** (Extracting the failure as an Option)
*
* ```ts
* import { Option, Result } from "effect"
*
* console.log(Result.getFailure(Result.succeed("ok")))
* // Output: { _tag: "None" }
*
* console.log(Result.getFailure(Result.fail("err")))
* // Output: { _tag: "Some", value: "err" }
* ```
*
* @see {@link getSuccess} to extract the success instead
* @see {@link fromOption} for the reverse conversion
*
* @category Getters
* @since 4.0.0
*/
var getFailure = getFailure$2;
/**
* Creates an `Equivalence` for comparing two `Result` values.
*
* - Two `Success` values are equal when the `success` equivalence says so
* - Two `Failure` values are equal when the `failure` equivalence says so
* - A `Success` and a `Failure` are never equal
*
* **Example** (Comparing Results for equality)
*
* ```ts
* import { Equivalence, Result } from "effect"
*
* const eq = Result.makeEquivalence(
*   Equivalence.strictEqual<number>(),
*   Equivalence.strictEqual<string>()
* )
*
* console.log(eq(Result.succeed(1), Result.succeed(1)))
* // Output: true
*
* console.log(eq(Result.succeed(1), Result.fail("x")))
* // Output: false
* ```
*
* @category Equivalence
* @since 4.0.0
*/
var makeEquivalence$1 = (success, failure) => make$2((x, y) => isFailure(x) ? isFailure(y) && failure(x.failure, y.failure) : isSuccess(y) && success(x.success, y.success));
/**
* Transforms both the success and failure channels of a `Result`.
*
* - Applies `onSuccess` if the result is a `Success`
* - Applies `onFailure` if the result is a `Failure`
* - Returns a new `Result`; does not mutate the input
* - Use when you need to transform both channels in a single operation
*
* **Example** (Mapping both channels)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.succeed(1),
*   Result.mapBoth({
*     onSuccess: (n) => n + 1,
*     onFailure: (e) => `Error: ${e}`
*   })
* )
* console.log(result)
* // Output: { _tag: "Success", success: 2, ... }
* ```
*
* @see {@link map} to transform only the success value
* @see {@link mapError} to transform only the error value
* @see {@link match} to fold into a single value
*
* @category Mapping
* @since 4.0.0
*/
var mapBoth = /*#__PURE__*/ dual(2, (self, { onFailure, onSuccess }) => isFailure(self) ? fail(onFailure(self.failure)) : succeed(onSuccess(self.success)));
/**
* Transforms the failure channel of a `Result`, leaving the success channel unchanged.
*
* - If the result is a `Failure`, applies `f` to the error and returns a new `Failure`
* - If the result is a `Success`, returns it as-is
* - Does not mutate the input
*
* **Example** (Adding context to an error)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.fail("not found"),
*   Result.mapError((e) => `Error: ${e}`)
* )
* console.log(result)
* // Output: { _tag: "Failure", failure: "Error: not found", ... }
* ```
*
* @see {@link map} to transform only the success value
* @see {@link mapBoth} to transform both channels
*
* @category Mapping
* @since 4.0.0
*/
var mapError = /*#__PURE__*/ dual(2, (self, f) => isFailure(self) ? fail(f(self.failure)) : succeed(self.success));
/**
* Transforms the success channel of a `Result`, leaving the failure channel unchanged.
*
* - If the result is a `Success`, applies `f` to the value and returns a new `Success`
* - If the result is a `Failure`, returns it as-is
* - Does not mutate the input
* - Use {@link flatMap} if `f` returns a `Result` (to avoid nested Results)
*
* **Example** (Doubling the success value)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.succeed(3),
*   Result.map((n) => n * 2)
* )
* console.log(result)
* // Output: { _tag: "Success", success: 6, ... }
* ```
*
* @see {@link mapError} to transform only the error value
* @see {@link mapBoth} to transform both channels
* @see {@link flatMap} when `f` returns a `Result`
*
* @category Mapping
* @since 4.0.0
*/
var map$1 = /*#__PURE__*/ dual(2, (self, f) => isSuccess(self) ? succeed(f(self.success)) : fail(self.failure));
/**
* Folds a `Result` into a single value by applying one of two functions.
*
* - Applies `onSuccess` if the result is a `Success`
* - Applies `onFailure` if the result is a `Failure`
* - Both branches must return the same type (or a common supertype)
* - Use when you need to "exit" the `Result` type and produce a plain value
*
* **Example** (Folding to a string)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const format = Result.match({
*   onSuccess: (n: number) => `Got ${n}`,
*   onFailure: (e: string) => `Err: ${e}`
* })
*
* console.log(format(Result.succeed(42)))
* // Output: "Got 42"
*
* console.log(format(Result.fail("timeout")))
* // Output: "Err: timeout"
* ```
*
* @see {@link merge} to extract `A | E` without mapping
* @see {@link getOrElse} to unwrap only the success with a fallback
*
* @category Pattern Matching
* @since 4.0.0
*/
var match = /*#__PURE__*/ dual(2, (self, { onFailure, onSuccess }) => isFailure(self) ? onFailure(self.failure) : onSuccess(self.success));
/**
* Lifts a value into a `Result` based on a predicate or refinement.
*
* - If the predicate returns `true`, the value becomes `Success<A>`
* - If the predicate returns `false`, `orFailWith` produces the error for `Failure<E>`
* - Also accepts a `Refinement` to narrow the success type
* - Supports both data-first and data-last (piped) usage
*
* **Example** (Validating a number)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const ensurePositive = pipe(
*   5,
*   Result.liftPredicate(
*     (n: number) => n > 0,
*     (n) => `${n} is not positive`
*   )
* )
* console.log(ensurePositive)
* // Output: { _tag: "Success", success: 5, ... }
* ```
*
* @see {@link filterOrFail} to validate a value that is already in a `Result`
* @see {@link fromNullishOr} for nullable-based construction
*
* @category Constructors
* @since 4.0.0
*/
var liftPredicate = /*#__PURE__*/ dual(3, (a, predicate, orFailWith) => predicate(a) ? succeed(a) : fail(orFailWith(a)));
/**
* Validates the success value of a `Result` using a predicate, failing with a
* custom error if the predicate returns `false`.
*
* - If the result is already a `Failure`, it is returned as-is
* - If the predicate passes, the `Success` is returned unchanged
* - If the predicate fails, `orFailWith` produces the error for a new `Failure`
* - Also accepts a `Refinement` to narrow the success type
* - The error type of the output is the union of both error types
*
* **Example** (Filtering a success value)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.succeed(0),
*   Result.filterOrFail(
*     (n) => n > 0,
*     (n) => `${n} is not positive`
*   )
* )
* console.log(result)
* // Output: { _tag: "Failure", failure: "0 is not positive", ... }
* ```
*
* @see {@link liftPredicate} to create a `Result` from a raw value with a predicate
* @see {@link flatMap} for general conditional chaining
*
* @since 4.0.0
* @category Filtering
*/
var filterOrFail = /*#__PURE__*/ dual(3, (self, predicate, orFailWith) => flatMap(self, (a) => predicate(a) ? succeed(a) : fail(orFailWith(a))));
/**
* Unwraps a `Result` into `A | E` by returning the inner value regardless
* of whether it is a success or failure.
*
* - `Success<A>` returns `A`
* - `Failure<E>` returns `E`
* - Useful when both channels share a compatible type
*
* **Example** (Extracting the inner value)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.merge(Result.succeed(42)))
* // Output: 42
*
* console.log(Result.merge(Result.fail("error")))
* // Output: "error"
* ```
*
* @see {@link match} to map each branch to a common type
* @see {@link getOrElse} to provide a fallback for failures
*
* @category Getters
* @since 4.0.0
*/
var merge = /*#__PURE__*/ match({
	onFailure: identity,
	onSuccess: identity
});
/**
* Extracts the success value, or computes a fallback from the error.
*
* - `Success<A>` returns the inner value
* - `Failure<E>` applies `onFailure` to the error and returns the result
* - The return type is `A | A2` (union of both branches)
*
* **Example** (Providing a fallback)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.getOrElse(Result.succeed(1), () => 0))
* // Output: 1
*
* console.log(Result.getOrElse(Result.fail("err"), () => 0))
* // Output: 0
* ```
*
* @see {@link getOrNull} / {@link getOrUndefined} for simpler fallbacks
* @see {@link getOrThrow} to throw on failure
* @see {@link match} to map both branches
*
* @category Getters
* @since 4.0.0
*/
var getOrElse = /*#__PURE__*/ dual(2, (self, onFailure) => isFailure(self) ? onFailure(self.failure) : self.success);
/**
* Extracts the success value, or returns `null` on failure.
*
* - `Success<A>` returns `A`
* - `Failure<E>` returns `null`
* - Convenient for interop with APIs that use `null` to represent absence
*
* **Example** (Unwrapping to nullable)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.getOrNull(Result.succeed(1)))
* // Output: 1
*
* console.log(Result.getOrNull(Result.fail("err")))
* // Output: null
* ```
*
* @see {@link getOrUndefined} to return `undefined` instead
* @see {@link getOrElse} for a custom fallback
*
* @category Getters
* @since 4.0.0
*/
var getOrNull = /*#__PURE__*/ getOrElse(constNull);
/**
* Extracts the success value, or returns `undefined` on failure.
*
* - `Success<A>` returns `A`
* - `Failure<E>` returns `undefined`
* - Convenient for interop with APIs that use `undefined` to represent absence
*
* **Example** (Unwrapping to optional)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.getOrUndefined(Result.succeed(1)))
* // Output: 1
*
* console.log(Result.getOrUndefined(Result.fail("err")))
* // Output: undefined
* ```
*
* @see {@link getOrNull} to return `null` instead
* @see {@link getOrElse} for a custom fallback
*
* @category Getters
* @since 4.0.0
*/
var getOrUndefined = /*#__PURE__*/ getOrElse(constUndefined);
/**
* Extracts the success value or throws a custom error derived from the failure.
*
* - `Success<A>` returns `A`
* - `Failure<E>` throws the value returned by `onFailure(e)`
* - Use when you want to convert a `Result` into a thrown exception with a
*   custom error message or error type
*
* **Example** (Throwing a custom error)
*
* ```ts
* import { Result } from "effect"
*
* console.log(
*   Result.getOrThrowWith(Result.succeed(1), () => new Error("fail"))
* )
* // Output: 1
*
* // This would throw: new Error("Unexpected: oops")
* // Result.getOrThrowWith(
* //   Result.fail("oops"),
* //   (err) => new Error(`Unexpected: ${err}`)
* // )
* ```
*
* @see {@link getOrThrow} to throw the raw failure value
* @see {@link getOrElse} for a non-throwing alternative
*
* @category Getters
* @since 4.0.0
*/
var getOrThrowWith = /*#__PURE__*/ dual(2, (self, onFailure) => {
	if (isSuccess(self)) return self.success;
	throw onFailure(self.failure);
});
/**
* Extracts the success value or throws the raw failure value `E`.
*
* - `Success<A>` returns `A`
* - `Failure<E>` throws `E` directly
* - Use {@link getOrThrowWith} for a custom error object
*
* **Example** (Unwrapping or throwing)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.getOrThrow(Result.succeed(1)))
* // Output: 1
*
* // This would throw the string "error":
* // Result.getOrThrow(Result.fail("error"))
* ```
*
* @see {@link getOrThrowWith} for custom error mapping
* @see {@link getOrElse} for a non-throwing alternative
*
* @category Getters
* @since 4.0.0
*/
var getOrThrow = /*#__PURE__*/ getOrThrowWith(identity);
/**
* Returns the original `Result` if it is a `Success`, otherwise applies
* `that` to the error and returns the resulting `Result`.
*
* - `Success<A>` is returned unchanged
* - `Failure<E>` calls `that(e)` to produce a new `Result`
* - Use to provide a recovery path or fallback computation on failure
*
* **Example** (Recovering from a failure)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.fail("primary failed"),
*   Result.orElse(() => Result.succeed(99))
* )
* console.log(result)
* // Output: { _tag: "Success", success: 99, ... }
* ```
*
* @see {@link getOrElse} to unwrap with a fallback value (not a Result)
* @see {@link mapError} to transform the error without recovering
*
* @category Error Handling
* @since 4.0.0
*/
var orElse = /*#__PURE__*/ dual(2, (self, that) => isFailure(self) ? that(self.failure) : succeed(self.success));
/**
* Chains a function that returns a `Result` onto a successful value.
*
* - If `self` is a `Success`, applies `f` to the value and returns the resulting `Result`
* - If `self` is a `Failure`, short-circuits and returns it unchanged
* - The error types are merged into a union (`E | E2`)
* - This is the monadic `bind` / `>>=` for `Result`
*
* **Example** (Sequential validation)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.succeed(5),
*   Result.flatMap((n) =>
*     n > 0 ? Result.succeed(n * 2) : Result.fail("not positive")
*   )
* )
* console.log(result)
* // Output: { _tag: "Success", success: 10, ... }
* ```
*
* @see {@link andThen} for a more flexible variant that also accepts plain values
* @see {@link map} when `f` does not return a `Result`
*
* @category Sequencing
* @since 4.0.0
*/
var flatMap = /*#__PURE__*/ dual(2, (self, f) => isFailure(self) ? fail(self.failure) : f(self.success));
/**
* A flexible variant of {@link flatMap} that accepts multiple input shapes.
*
* The second argument can be:
* - A function `(a: A) => Result<A2, E2>` (same as `flatMap`)
* - A function `(a: A) => A2` (auto-wrapped in `succeed`)
* - A `Result<A2, E2>` value (ignores the success of `self`)
* - A plain value `A2` (auto-wrapped in `succeed`, ignores `self`)
*
* If `self` is a `Failure`, the second argument is never evaluated.
*
* **Example** (Using andThen with different argument types)
*
* ```ts
* import { pipe, Result } from "effect"
*
* // With a function returning a Result
* const a = pipe(
*   Result.succeed(1),
*   Result.andThen((n) => Result.succeed(n + 1))
* )
*
* // With a plain mapping function
* const b = pipe(
*   Result.succeed(1),
*   Result.andThen((n) => n + 1)
* )
*
* // With a constant value
* const c = pipe(Result.succeed(1), Result.andThen("done"))
*
* console.log(a, b, c)
* ```
*
* @see {@link flatMap} for the stricter variant (function returning Result only)
* @see {@link map} when you always return a plain value
*
* @category Sequencing
* @since 4.0.0
*/
var andThen = /*#__PURE__*/ dual(2, (self, f) => flatMap(self, (a) => {
	const out = isFunction(f) ? f(a) : f;
	return isResult(out) ? out : succeed(out);
}));
/**
* Collects a structure of `Result`s into a single `Result` of collected values.
*
* Accepts:
* - A tuple/array: returns `Result` with a tuple/array of success values
* - A struct (record): returns `Result` with a struct of success values
* - An iterable: returns `Result` with an array of success values
*
* Short-circuits on the first `Failure` encountered; later elements are not inspected.
*
* **Example** (Collecting a tuple and a struct)
*
* ```ts
* import { Result } from "effect"
*
* // Tuple
* const tuple = Result.all([Result.succeed(1), Result.succeed("two")])
* console.log(tuple)
* // Output: { _tag: "Success", success: [1, "two"], ... }
*
* // Struct
* const struct = Result.all({ x: Result.succeed(1), y: Result.fail("err") })
* console.log(struct)
* // Output: { _tag: "Failure", failure: "err", ... }
* ```
*
* @see {@link flatMap} for chaining two Results sequentially
* @see {@link gen} for generator-based composition of multiple Results
*
* @category Sequencing
* @since 4.0.0
*/
var all = (input) => {
	if (Symbol.iterator in input) {
		const out = [];
		for (const e of input) {
			if (isFailure(e)) return e;
			out.push(e.success);
		}
		return succeed(out);
	}
	const out = {};
	for (const key of Object.keys(input)) {
		const e = input[key];
		if (isFailure(e)) return e;
		out[key] = e.success;
	}
	return succeed(out);
};
/**
* Swaps the success and failure channels of a `Result`.
*
* - `Success<A>` becomes `Failure<A>` (i.e., `Result<E, A>`)
* - `Failure<E>` becomes `Success<E>` (i.e., `Result<E, A>`)
* - Useful when you want to apply success-oriented operations (like `map`)
*   to the error channel, then flip back
*
* **Example** (Swapping channels)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.flip(Result.succeed(42)))
* // Output: { _tag: "Failure", failure: 42, ... }
*
* console.log(Result.flip(Result.fail("error")))
* // Output: { _tag: "Success", success: "error", ... }
* ```
*
* @see {@link mapError} to transform the error without swapping
*
* @category Utilities
* @since 4.0.0
*/
var flip = (self) => isFailure(self) ? succeed(self.failure) : fail(self.success);
/**
* Generator-based syntax for composing `Result` values sequentially.
*
* - Use `yield*` to unwrap a `Result` inside the generator; if any yielded
*   `Result` is a `Failure`, the generator short-circuits and returns that failure
* - The return value of the generator is wrapped in `Success`
* - Evaluated eagerly and synchronously (unlike `Effect.gen`)
*
* **Example** (Composing multiple Results)
*
* ```ts
* import { Result } from "effect"
*
* const result = Result.gen(function*() {
*   const a = yield* Result.succeed(1)
*   const b = yield* Result.succeed(2)
*   return a + b
* })
*
* console.log(result)
* // Output: { _tag: "Success", success: 3, ... }
* ```
*
* @see {@link flatMap} for point-free sequential composition
* @see {@link all} to collect multiple independent Results
*
* @category Generators
* @since 4.0.0
*/
var gen = (...args) => {
	const iterator = (args.length === 1 ? args[0] : args[1].bind(args[0]))();
	let state = iterator.next();
	while (!state.done) {
		const current = isGenKind(state.value) ? state.value.value : state.value;
		if (isFailure(current)) return current;
		state = iterator.next(current.success);
	}
	return succeed(state.value);
};
/**
* Starting point for the "do notation" simulation with `Result`.
*
* Creates a `Result<{}>` (success with an empty object). Use with
* {@link bind} to add `Result`-producing fields and {@link let_ let}
* to add pure computed fields.
*
* **Example** (Building an object step by step)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.Do,
*   Result.bind("x", () => Result.succeed(2)),
*   Result.bind("y", () => Result.succeed(3)),
*   Result.let("sum", ({ x, y }) => x + y)
* )
* console.log(result)
* // Output: { _tag: "Success", success: { x: 2, y: 3, sum: 5 }, ... }
* ```
*
* @see {@link bind} to add Result-producing fields
* @see {@link let_ let} to add pure computed fields
* @see {@link gen} for an alternative generator-based syntax
*
* @category Do Notation
* @since 4.0.0
*/
var Do = /*#__PURE__*/ succeed({});
/**
* Adds a named field to the do-notation accumulator by running a `Result`-producing
* function that receives the current accumulated object.
*
* - Short-circuits on the first `Failure`
* - The field name must not collide with existing keys
* - Use {@link let_ let} for pure (non-Result) computed fields
*
* **Example** (Binding Result values)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.Do,
*   Result.bind("x", () => Result.succeed(2)),
*   Result.bind("y", ({ x }) => Result.succeed(x + 3))
* )
* console.log(result)
* // Output: { _tag: "Success", success: { x: 2, y: 5 }, ... }
* ```
*
* @see {@link Do} to start the do-notation chain
* @see {@link let_ let} for pure computed fields
* @see {@link bindTo} to wrap an initial Result into a named field
*
* @category Do Notation
* @since 4.0.0
*/
var bind = /*#__PURE__*/ bind$2(map$1, flatMap);
/**
* Wraps the success value of a `Result` into a named field, producing a
* `Result<Record<N, A>>`. This is typically used to start a do-notation
* chain from an existing `Result`.
*
* **Example** (Wrapping a value into a named field)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.succeed(42),
*   Result.bindTo("answer")
* )
* console.log(result)
* // Output: { _tag: "Success", success: { answer: 42 }, ... }
* ```
*
* @see {@link Do} to start from an empty object
* @see {@link bind} to add more fields
*
* @category Do Notation
* @since 4.0.0
*/
var bindTo = /*#__PURE__*/ bindTo$2(map$1);
var let_ = /*#__PURE__*/ let_$2(map$1);
/**
* Transforms `Option<Result<A, E>>` into `Result<Option<A>, E>`.
*
* - `None` becomes `Success(None)`
* - `Some(Success(a))` becomes `Success(Some(a))`
* - `Some(Failure(e))` becomes `Failure(e)`
*
* **Example** (Transposing an Option of a Result)
*
* ```ts
* import { Option, Result } from "effect"
*
* const some = Option.some(Result.succeed(42))
* console.log(Result.transposeOption(some))
* // Output: { _tag: "Success", success: { _tag: "Some", value: 42 }, ... }
*
* const none = Option.none<Result.Result<number, string>>()
* console.log(Result.transposeOption(none))
* // Output: { _tag: "Success", success: { _tag: "None" }, ... }
* ```
*
* @see {@link transposeMapOption} to map and transpose in one step
*
* @since 3.14.0
* @category Transposing
*/
var transposeOption = (self) => {
	return isNone$1(self) ? succeedNone : map$1(self.value, some$2);
};
/**
* Maps an `Option` value with a `Result`-producing function, then transposes
* the structure from `Option<Result<B, E>>` to `Result<Option<B>, E>`.
*
* - `None` becomes `Success(None)` (the function is never called)
* - `Some(a)` where `f(a)` is `Success(b)` becomes `Success(Some(b))`
* - `Some(a)` where `f(a)` is `Failure(e)` becomes `Failure(e)`
*
* **Example** (Map and transpose in one step)
*
* ```ts
* import { Option, Result } from "effect"
*
* const parse = (s: string) =>
*   isNaN(Number(s))
*     ? Result.fail("not a number" as const)
*     : Result.succeed(Number(s))
*
* console.log(Result.transposeMapOption(Option.some("42"), parse))
* // Output: { _tag: "Success", success: { _tag: "Some", value: 42 }, ... }
*
* console.log(Result.transposeMapOption(Option.none(), parse))
* // Output: { _tag: "Success", success: { _tag: "None" }, ... }
* ```
*
* @see {@link transposeOption} when the Option already contains a Result
*
* @since 3.15.0
* @category Transposing
*/
var transposeMapOption = /*#__PURE__*/ dual(2, (self, f) => isNone$1(self) ? succeedNone : map$1(f(self.value), some$2));
/**
* A pre-built `Result<Option<never>>` that succeeds with `None`.
*
* - Equivalent to `Result.succeed(Option.none())` but avoids an extra allocation
* - Useful with {@link transposeOption} patterns
*
* **Example** (Using succeedNone)
*
* ```ts
* import { Result } from "effect"
*
* console.log(Result.isSuccess(Result.succeedNone))
* // Output: true
* ```
*
* @see {@link succeedSome} for the `Some` counterpart
*
* @category Constructors
* @since 4.0.0
*/
var succeedNone = /*#__PURE__*/ succeed(none$1);
/**
* Creates a `Result<Option<A>>` that succeeds with `Some(a)`.
*
* - Equivalent to `Result.succeed(Option.some(a))`
* - Useful with {@link transposeOption} patterns
*
* **Example** (Wrapping a value in Some inside a Result)
*
* ```ts
* import { Result } from "effect"
*
* const result = Result.succeedSome(42)
* console.log(result)
* // Output: { _tag: "Success", success: { _tag: "Some", value: 42 }, ... }
* ```
*
* @see {@link succeedNone} for the `None` counterpart
*
* @category Constructors
* @since 4.0.0
*/
var succeedSome = (a) => succeed(some$2(a));
/**
* Runs a side-effect on the success value without altering the `Result`.
*
* - If the result is a `Success`, calls `f` with the value (return value is ignored)
* - If the result is a `Failure`, `f` is not called
* - Returns the original `Result` unchanged (same reference)
* - Useful for logging, debugging, or performing mutations outside the Result chain
*
* **Example** (Logging a success value)
*
* ```ts
* import { pipe, Result } from "effect"
*
* const result = pipe(
*   Result.succeed(42),
*   Result.tap((n) => console.log("Got:", n))
* )
* // Output: "Got: 42"
*
* console.log(Result.isSuccess(result))
* // Output: true
* ```
*
* @see {@link map} to transform the success value
*
* @category Mapping
* @since 4.0.0
*/
var tap = /*#__PURE__*/ dual(2, (self, f) => {
	if (isSuccess(self)) f(self.success);
	return self;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Record.js
/**
* This module provides utility functions for working with records in TypeScript.
*
* @since 2.0.0
*/
var Record_exports = /* @__PURE__ */ __exportAll({
	collect: () => collect,
	difference: () => difference,
	empty: () => empty,
	every: () => every,
	filter: () => filter,
	filterMap: () => filterMap,
	findFirst: () => findFirst,
	fromEntries: () => fromEntries,
	fromIterableBy: () => fromIterableBy,
	fromIterableWith: () => fromIterableWith,
	get: () => get,
	getFailures: () => getFailures,
	getSomes: () => getSomes,
	getSuccesses: () => getSuccesses,
	has: () => has,
	intersection: () => intersection,
	isEmptyReadonlyRecord: () => isEmptyReadonlyRecord,
	isEmptyRecord: () => isEmptyRecord,
	isSubrecord: () => isSubrecord,
	isSubrecordBy: () => isSubrecordBy,
	keys: () => keys,
	makeEquivalence: () => makeEquivalence,
	makeReducerIntersection: () => makeReducerIntersection,
	makeReducerUnion: () => makeReducerUnion,
	map: () => map,
	mapEntries: () => mapEntries,
	mapKeys: () => mapKeys,
	modify: () => modify,
	partition: () => partition,
	pop: () => pop,
	reduce: () => reduce,
	remove: () => remove,
	replace: () => replace,
	separate: () => separate,
	set: () => set,
	singleton: () => singleton,
	size: () => size,
	some: () => some,
	toEntries: () => toEntries,
	union: () => union,
	values: () => values
});
/**
* Creates a new, empty record.
*
* @example
* ```ts
* import { Record } from "effect"
*
* // Create an empty record
* const emptyRecord = Record.empty<string, number>()
* console.log(emptyRecord) // {}
*
* // The type ensures type safety for future operations
* const withValue = Record.set(emptyRecord, "count", 42)
* console.log(withValue) // { count: 42 }
* ```
*
* @category constructors
* @since 2.0.0
*/
var empty = () => ({});
/**
* Determine if a record is empty.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.isEmptyRecord({}), true)
* assert.deepStrictEqual(Record.isEmptyRecord({ a: 3 }), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isEmptyRecord = (self) => Object.keys(self).length === 0;
/**
* Determine if a record is empty.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.isEmptyReadonlyRecord({}), true)
* assert.deepStrictEqual(Record.isEmptyReadonlyRecord({ a: 3 }), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isEmptyReadonlyRecord = isEmptyRecord;
/**
* Takes an iterable and a projection function and returns a record.
* The projection function maps each value of the iterable to a tuple of a key and a value, which is then added to the resulting record.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const input = [1, 2, 3, 4]
*
* assert.deepStrictEqual(
*   Record.fromIterableWith(input, (a) => [String(a), a * 2]),
*   { "1": 2, "2": 4, "3": 6, "4": 8 }
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromIterableWith = /*#__PURE__*/ dual(2, (self, f) => {
	const out = empty();
	for (const a of self) {
		const [k, b] = f(a);
		out[k] = b;
	}
	return out;
});
/**
* Creates a new record from an iterable, utilizing the provided function to determine the key for each element.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const users = [
*   { id: "2", name: "name2" },
*   { id: "1", name: "name1" }
* ]
*
* assert.deepStrictEqual(
*   Record.fromIterableBy(users, (user) => user.id),
*   {
*     "2": { id: "2", name: "name2" },
*     "1": { id: "1", name: "name1" }
*   }
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromIterableBy = (items, f) => fromIterableWith(items, (a) => [f(a), a]);
/**
* Builds a record from an iterable of key-value pairs.
*
* If there are conflicting keys when using `fromEntries`, the last occurrence of the key/value pair will overwrite the
* previous ones. So the resulting record will only have the value of the last occurrence of each key.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const input: Array<[string, number]> = [["a", 1], ["b", 2]]
*
* assert.deepStrictEqual(Record.fromEntries(input), { a: 1, b: 2 })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromEntries = Object.fromEntries;
/**
* Transforms the values of a record into an `Array` with a custom mapping function.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const x = { a: 1, b: 2, c: 3 }
* assert.deepStrictEqual(Record.collect(x, (key, n) => [key, n]), [["a", 1], [
*   "b",
*   2
* ], ["c", 3]])
* ```
*
* @category conversions
* @since 2.0.0
*/
var collect = /*#__PURE__*/ dual(2, (self, f) => {
	const out = [];
	for (const key of keys(self)) out.push(f(key, self[key]));
	return out;
});
/**
* Takes a record and returns an array of tuples containing its keys and values.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const x = { a: 1, b: 2, c: 3 }
* assert.deepStrictEqual(Record.toEntries(x), [["a", 1], ["b", 2], ["c", 3]])
* ```
*
* @category conversions
* @since 2.0.0
*/
var toEntries = /*#__PURE__*/ collect((key, value) => [key, value]);
/**
* Returns the number of key/value pairs in a record.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.size({ a: "a", b: 1, c: true }), 3)
* ```
*
* @category getters
* @since 2.0.0
*/
var size = (self) => keys(self).length;
/**
* Check if a given `key` exists in a record.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.has({ a: 1, b: 2 }, "a"), true)
* assert.deepStrictEqual(Record.has(Record.empty<string>(), "c"), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var has = /*#__PURE__*/ dual(2, (self, key) => Object.hasOwn(self, key));
/**
* Retrieve a value at a particular key from a record, returning it wrapped in an `Option`.
*
* @example
* ```ts
* import { Option, Record as R } from "effect"
* import * as assert from "node:assert"
*
* const person: Record<string, unknown> = { name: "John Doe", age: 35 }
*
* assert.deepStrictEqual(R.get(person, "name"), Option.some("John Doe"))
* assert.deepStrictEqual(R.get(person, "email"), Option.none())
* ```
*
* @category getters
* @since 2.0.0
*/
var get = /*#__PURE__*/ dual(2, (self, key) => has(self, key) ? some$1(self[key]) : none());
/**
* Apply a function to the element at the specified key, creating a new record,
* or return `undefined` if the key doesn't exist.
*
* @example
* ```ts
* import { Record } from "effect"
*
* const f = (x: number) => x * 2
*
* const input: Record<string, number> = { a: 3 }
*
* Record.modify(input, "a", f) // { a: 6 }
* Record.modify(input, "b", f) // undefined
* ```
*
* @category utils
* @since 2.0.0
*/
var modify = /*#__PURE__*/ dual(3, (self, key, f) => {
	if (!has(self, key)) return void 0;
	return {
		...self,
		[key]: f(self[key])
	};
});
/**
* Replaces a value in the record with the new value passed as parameter.
*
* @example
* ```ts
* import { Record } from "effect"
*
* Record.replace({ a: 1, b: 2, c: 3 }, "a", 10) // { a: 10, b: 2, c: 3 }
* Record.replace(Record.empty<string>(), "a", 10) // undefined
* ```
*
* @category utils
* @since 2.0.0
*/
var replace = /*#__PURE__*/ dual(3, (self, key, b) => modify(self, key, () => b));
/**
* If the given key exists in the record, returns a new record with the key removed,
* otherwise returns `undefined`.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.remove({ a: 1, b: 2 }, "a"), { b: 2 })
* ```
*
* @category utils
* @since 2.0.0
*/
var remove = /*#__PURE__*/ dual(2, (self, key) => {
	if (!has(self, key)) return { ...self };
	const out = { ...self };
	delete out[key];
	return out;
});
/**
* Retrieves the value of the property with the given `key` from a record and returns an `Option`
* of a tuple with the value and the record with the removed property.
* If the key is not present, returns `undefined`.
*
* @example
* ```ts
* import { Record } from "effect"
*
* const input: Record<string, number> = { a: 1, b: 2 }
*
* Record.pop(input, "a") // [1, { b: 2 }]
* Record.pop(input, "c") // undefined
* ```
*
* @category utils
* @since 2.0.0
*/
var pop = /*#__PURE__*/ dual(2, (self, key) => has(self, key) ? [self[key], remove(self, key)] : void 0);
/**
* Maps a record into another record by applying a transformation function to each of its values.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const f = (n: number) => `-${n}`
*
* assert.deepStrictEqual(Record.map({ a: 3, b: 5 }, f), { a: "-3", b: "-5" })
*
* const g = (n: number, key: string) => `${key.toUpperCase()}-${n}`
*
* assert.deepStrictEqual(Record.map({ a: 3, b: 5 }, g), { a: "A-3", b: "B-5" })
* ```
*
* @category mapping
* @since 2.0.0
*/
var map = /*#__PURE__*/ dual(2, (self, f) => {
	const out = { ...self };
	for (const key of keys(self)) out[key] = f(self[key], key);
	return out;
});
/**
* Maps the keys of a `ReadonlyRecord` while preserving the corresponding values.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.mapKeys({ a: 3, b: 5 }, (key) => key.toUpperCase()),
*   { A: 3, B: 5 }
* )
* ```
*
* @category mapping
* @since 2.0.0
*/
var mapKeys = /*#__PURE__*/ dual(2, (self, f) => {
	const out = {};
	for (const key of keys(self)) {
		const a = self[key];
		out[f(key, a)] = a;
	}
	return out;
});
/**
* Maps entries of a `ReadonlyRecord` using the provided function, allowing modification of both keys and corresponding values.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.mapEntries({ a: 3, b: 5 }, (a, key) => [key.toUpperCase(), a + 1]),
*   { A: 4, B: 6 }
* )
* ```
*
* @category mapping
* @since 2.0.0
*/
var mapEntries = /*#__PURE__*/ dual(2, (self, f) => {
	const out = {};
	for (const key of keys(self)) {
		const [k, b] = f(self[key], key);
		out[k] = b;
	}
	return out;
});
/**
* Transforms a record by applying the function `f` to each key and value in the original record.
* If the function succeeds, the key-value pair is included in the output record.
*
* @example
* ```ts
* import { Record, Result } from "effect"
* import * as assert from "node:assert"
*
* const x = { a: 1, b: 2, c: 3 }
* const f = (a: number, key: string) => a > 2 ? Result.succeed(a * 2) : Result.failVoid
* assert.deepStrictEqual(Record.filterMap(x, f), { c: 6 })
* ```
*
* @category filtering
* @since 2.0.0
*/
var filterMap = /*#__PURE__*/ dual(2, (self, f) => {
	const out = empty();
	for (const key of keys(self)) {
		const result = f(self[key], key);
		if (isSuccess(result)) out[key] = result.success;
	}
	return out;
});
/**
* Selects properties from a record whose values match the given predicate.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* const x = { a: 1, b: 2, c: 3, d: 4 }
* assert.deepStrictEqual(Record.filter(x, (n) => n > 2), { c: 3, d: 4 })
* ```
*
* @category filtering
* @since 2.0.0
*/
var filter = /*#__PURE__*/ dual(2, (self, predicate) => {
	const out = empty();
	for (const key of keys(self)) if (predicate(self[key], key)) out[key] = self[key];
	return out;
});
/**
* Given a record with `Option` values, returns a new record containing only the `Some` values, preserving the original keys.
*
* @example
* ```ts
* import { Option, Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.getSomes({ a: Option.some(1), b: Option.none(), c: Option.some(2) }),
*   { a: 1, c: 2 }
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var getSomes = (self) => {
	const out = empty();
	for (const key of keys(self)) {
		const option = self[key];
		if (isSome(option)) out[key] = option.value;
	}
	return out;
};
/**
* Given a record with `Result` values, returns a new record containing only the `Err` values, preserving the original keys.
*
* @example
* ```ts
* import { Record, Result } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.getFailures({
*     a: Result.succeed(1),
*     b: Result.fail("err"),
*     c: Result.succeed(2)
*   }),
*   { b: "err" }
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var getFailures = (self) => {
	const out = empty();
	for (const key of keys(self)) {
		const value = self[key];
		if (isFailure(value)) out[key] = value.failure;
	}
	return out;
};
/**
* Given a record with `Result` values, returns a new record containing only the `Ok` values, preserving the original keys.
*
* @example
* ```ts
* import { Record, Result } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.getSuccesses({
*     a: Result.succeed(1),
*     b: Result.fail("err"),
*     c: Result.succeed(2)
*   }),
*   { a: 1, c: 2 }
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var getSuccesses = (self) => {
	const out = empty();
	for (const key of keys(self)) {
		const value = self[key];
		if (isSuccess(value)) out[key] = value.success;
	}
	return out;
};
/**
* Partitions the elements of a record into two groups: those that match a filter, and those that don't.
*
* @example
* ```ts
* import { Record, Result } from "effect"
* import * as assert from "node:assert"
*
* const x = { a: 1, b: 2, c: 3 }
* const f = (n: number) => (n % 2 === 0 ? Result.succeed(n) : Result.fail(n))
* assert.deepStrictEqual(Record.partition(x, f), [{ a: 1, c: 3 }, { b: 2 }])
* ```
*
* @category filtering
* @since 2.0.0
*/
var partition = /*#__PURE__*/ dual(2, (self, f) => {
	const left = empty();
	const right = empty();
	for (const key of keys(self)) {
		const e = f(self[key], key);
		if (isFailure(e)) left[key] = e.failure;
		else right[key] = e.success;
	}
	return [left, right];
});
/**
* Partitions a record of `Result` values into two separate records,
* one with the `Err` values and one with the `Ok` values.
*
* @example
* ```ts
* import { Record, Result } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.separate({ a: Result.fail("e"), b: Result.succeed(1) }),
*   [{ a: "e" }, { b: 1 }]
* )
* ```
*
* @category filtering
* @since 2.0.0
*/
var separate = /*#__PURE__*/ partition(identity);
/**
* Retrieve the keys of a given record as an array.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.keys({ a: 1, b: 2, c: 3 }), ["a", "b", "c"])
* ```
*
* @category getters
* @since 2.0.0
*/
var keys = (self) => Object.keys(self);
/**
* Retrieve the values of a given record as an array.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.values({ a: 1, b: 2, c: 3 }), [1, 2, 3])
* ```
*
* @category getters
* @since 2.0.0
*/
var values = (self) => collect(self, (_, a) => a);
/**
* Add a new key-value pair or update an existing key's value in a record.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.set("a", 5)({ a: 1, b: 2 }), { a: 5, b: 2 })
* assert.deepStrictEqual(Record.set("c", 5)({ a: 1, b: 2 }), { a: 1, b: 2, c: 5 })
* ```
*
* @category utils
* @since 2.0.0
*/
var set = /*#__PURE__*/ dual(3, (self, key, value) => {
	return {
		...self,
		[key]: value
	};
});
/**
* Check if all the keys and values in one record are also found in another record.
* Uses the provided equivalence function to compare values.
*
* @example
* ```ts
* import { Equal, Record } from "effect"
* import * as assert from "node:assert"
*
* const isSubrecord = Record.isSubrecordBy(Equal.asEquivalence<number>())
*
* assert.deepStrictEqual(
*   Record.isSubrecord({ a: 1 } as Record<string, number>, { a: 1, b: 2 }),
*   true
* )
* assert.deepStrictEqual(
*   Record.isSubrecord({ a: 1, b: 2 }, { a: 1 } as Record<string, number>),
*   false
* )
* ```
*
* @category predicates
* @since 2.0.0
*/
var isSubrecordBy = (equivalence) => dual(2, (self, that) => {
	for (const key of keys(self)) if (!has(that, key) || !equivalence(self[key], that[key])) return false;
	return true;
});
/**
* Check if one record is a subrecord of another, meaning it contains all the keys and values found in the second record.
* This comparison uses default equality checks (`Equal.equivalence()`).
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.isSubrecord({ a: 1 } as Record<string, number>, { a: 1, b: 2 }),
*   true
* )
* assert.deepStrictEqual(
*   Record.isSubrecord({ a: 1, b: 2 }, { a: 1 } as Record<string, number>),
*   false
* )
* ```
*
* @category predicates
* @since 2.0.0
*/
var isSubrecord = /*#__PURE__*/ isSubrecordBy(/*#__PURE__*/ asEquivalence());
/**
* Reduce a record to a single value by combining its entries with a specified function.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.reduce({ a: 1, b: 2, c: 3 }, 0, (acc, value, key) => acc + value),
*   6
* )
* ```
*
* @category folding
* @since 2.0.0
*/
var reduce = /*#__PURE__*/ dual(3, (self, zero, f) => {
	let out = zero;
	for (const key of keys(self)) out = f(out, self[key], key);
	return out;
});
/**
* Check if all entries in a record meet a specific condition.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.every({ a: 1, b: 2 }, (n) => n > 0), true)
* assert.deepStrictEqual(Record.every({ a: 1, b: -1 }, (n) => n > 0), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var every = /*#__PURE__*/ dual(2, (self, refinement) => {
	for (const key of keys(self)) if (!refinement(self[key], key)) return false;
	return true;
});
/**
* Check if any entry in a record meets a specific condition.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.some({ a: 1, b: 2 }, (n) => n > 1), true)
* assert.deepStrictEqual(Record.some({ a: 1, b: 2 }, (n) => n > 2), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var some = /*#__PURE__*/ dual(2, (self, predicate) => {
	for (const key of keys(self)) if (predicate(self[key], key)) return true;
	return false;
});
/**
* Merge two records, preserving entries that exist in either of the records.
* For keys that exist in both records, the provided combine function is used to merge the values.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.union({ a: 1, b: 2 }, { b: 3, c: 4 }, (a, b) => a + b),
*   { a: 1, b: 5, c: 4 }
* )
* ```
*
* @category combining
* @since 2.0.0
*/
var union = /*#__PURE__*/ dual(3, (self, that, combine) => {
	if (isEmptyRecord(self)) return { ...that };
	if (isEmptyRecord(that)) return { ...self };
	const out = empty();
	for (const key of keys(self)) if (has(that, key)) out[key] = combine(self[key], that[key]);
	else out[key] = self[key];
	for (const key of keys(that)) if (!has(out, key)) out[key] = that[key];
	return out;
});
/**
* Merge two records, retaining only the entries that exist in both records.
* For intersecting keys, the provided combine function is used to merge the values.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.intersection({ a: 1, b: 2 }, { b: 3, c: 4 }, (a, b) => a + b),
*   { b: 5 }
* )
* ```
*
* @category combining
* @since 2.0.0
*/
var intersection = /*#__PURE__*/ dual(3, (self, that, combine) => {
	const out = empty();
	if (isEmptyRecord(self) || isEmptyRecord(that)) return out;
	for (const key of keys(self)) if (has(that, key)) out[key] = combine(self[key], that[key]);
	return out;
});
/**
* Merge two records, preserving only the entries that are unique to each record.
* Keys that exist in both records are excluded from the result.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(
*   Record.difference({ a: 1, b: 2 }, { b: 3, c: 4 }),
*   { a: 1, c: 4 }
* )
* ```
*
* @category combining
* @since 2.0.0
*/
var difference = /*#__PURE__*/ dual(2, (self, that) => {
	if (isEmptyRecord(self)) return { ...that };
	if (isEmptyRecord(that)) return { ...self };
	const out = {};
	for (const key of keys(self)) if (!has(that, key)) out[key] = self[key];
	for (const key of keys(that)) if (!has(self, key)) out[key] = that[key];
	return out;
});
/**
* Create an `Equivalence` for records using the provided `Equivalence` for values.
* Two records are considered equivalent if they have the same keys and their corresponding values are equivalent.
*
* @example
* ```ts
* import { Equal, Record } from "effect"
* import * as assert from "node:assert"
*
* const recordEquivalence = Record.makeEquivalence(Equal.asEquivalence<number>())
*
* assert.deepStrictEqual(recordEquivalence({ a: 1, b: 2 }, { a: 1, b: 2 }), true)
* assert.deepStrictEqual(recordEquivalence({ a: 1, b: 2 }, { a: 1, b: 3 }), false)
* ```
*
* @category instances
* @since 2.0.0
*/
var makeEquivalence = (equivalence) => {
	const is = isSubrecordBy(equivalence);
	return (self, that) => is(self, that) && is(that, self);
};
/**
* Create a non-empty record from a single element.
*
* @example
* ```ts
* import { Record } from "effect"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Record.singleton("a", 1), { a: 1 })
* ```
*
* @category constructors
* @since 2.0.0
*/
var singleton = (key, value) => ({ [key]: value });
/**
* A `Reducer` for combining `Record`s using union.
*
* Values for keys that exist in both records are combined using the provided `Combiner`.
*
* @since 4.0.0
*/
function makeReducerUnion(combiner) {
	return make$3((self, that) => union(self, that, combiner.combine), {});
}
/**
* A `Reducer` for combining `Record`s using intersection.
*
* Values are combined using the provided `Combiner`.
*
* @since 4.0.0
*/
function makeReducerIntersection(combiner) {
	return make$3((self, that) => intersection(self, that, combiner.combine), {});
}
/**
* Returns the first entry that satisfies the specified
* predicate, or `None` if no such entry exists.
*
* @example
* ```ts
* import { Record } from "effect"
*
* const record = { a: 1, b: 2, c: 3 }
* const result = Record.findFirst(
*   record,
*   (value, key) => value > 1 && key !== "b"
* )
* console.log(result) // Option.Some(["c", 3])
* ```
*
* @category elements
* @since 3.14.0
*/
var findFirst = /*#__PURE__*/ dual(2, (self, f) => {
	const k = keys(self);
	for (let i = 0; i < k.length; i++) {
		const key = k[i];
		if (f(self[key], key)) return [key, self[key]];
	}
});
//#endregion
export { makeEquivalence$1 as $, formatDate as $n, DoneTypeId as $t, partition as A, isCause as An, Boolean as At, toEntries as B, makePrimitiveProto as Bn, isGreaterThan as Bt, makeEquivalence as C, contE as Cn, strictEqual as Cr, match$1 as Ct, mapEntries as D, exitFail as Dn, toArray as Dt, map as E, exitDie as En, some$1 as Et, separate as F, isExit as Fn, Struct as Ft, fail as G, BaseProto as Gn, mapInput as Gt, values as H, SingleShotGen as Hn, isLessThan as Ht, set as I, isFailReason as In, Tuple as It, getOrElse as J, NodeInspectSymbol as Jn, CauseImpl as Jt, failVoid as K, Class as Kn, max as Kt, singleton as L, isInterruptReason as Ln, clamp as Lt, reduce as M, isDieReason as Mn, Number as Mt, remove as N, isDone as Nn, Order_exports as Nt, mapKeys as O, exitFailCause as On, Array$1 as Ot, replace as P, isEffect as Pn, String$1 as Pt, isSuccess as Q, format as Qn, Done as Qt, size as R, isNoSuchElementError as Rn, combineAll as Rt, keys as S, contAll as Sn, make$2 as Sr, map$2 as St, makeReducerUnion as T, evaluate as Tn, make$3 as Tr, orElseSome as Tt, Result_exports as U, Utils_exports as Un, isLessThanOrEqualTo as Ut, union as V, withFiber as Vn, isGreaterThanOrEqualTo as Vt, all as W, internalCall as Wn, make as Wt, isFailure as X, toStringUnknown as Xn, CauseTypeId as Xt, getOrThrow as Y, toJson as Yn, CauseReasonTypeId as Yt, isResult as Z, Formatter_exports as Zn, Die as Zt, intersection as _, causeEmpty as _n, Equivalence_exports as _r, getSuccess$1 as _t, every as a, NoSuchElementError as an, redact as ar, succeed as at, isSubrecord as b, constEmptyAnnotations as bn, Struct$1 as br, isSome as bt, findFirst as c, ReasonBase as cn, make$1 as cr, flatMap$1 as ct, fromIterableWith as d, TaggedError as dn, bind$2 as dr, fromNullishOr$1 as dt, EffectTypeId as en, formatJson as er, map$1 as et, get as f, Yield as fn, bindTo$2 as fr, fromUndefinedOr as ft, has as g, causeDie as gn, Boolean$1 as gr, getOrUndefined$1 as gt, getSuccesses as h, causeAnnotate as hn, BigInt$1 as hr, getOrThrow$1 as ht, empty as i, InterruptorStackTrace as in, currentFiberTypeId as ir, merge as it, pop as j, isCauseReason as jn, Date$1 as jt, modify as k, exitSucceed as kn, BigInt as kt, fromEntries as l, StackTraceKey as ln, max$1 as lr, flatten as lt, getSomes as m, args as mn, Array$2 as mr, getOrNull$1 as mt, collect as n, ExitTypeId as nn, formatPropertyKey as nr, mapError as nt, filter as o, NoSuchElementErrorTypeId as on, symbolRedactable as or, Option_exports as ot, getFailures as p, YieldableProto as pn, let_$2 as pr, getOrElse$1 as pt, flatMap as q, Inspectable_exports as qn, min as qt, difference as r, Fail as rn, Redactable_exports as rr, match as rt, filterMap as s, PipeInspectableProto as sn, Combiner_exports as sr, filter$1 as st, Record_exports as t, Error$1 as tn, formatPath as tr, mapBoth as tt, fromIterableBy as u, StructuralProto as un, min$1 as ur, fromNullOr as ut, isEmptyReadonlyRecord as v, causeFail as vn, Number$1 as vr, isNone as vt, makeReducerIntersection as w, done as wn, Reducer_exports as wr, none as wt, isSubrecordBy as x, contA as xn, Tuple$1 as xr, makeEquivalence$2 as xt, isEmptyRecord as y, causeFromReasons as yn, String$2 as yr, isOption as yt, some as z, makePrimitive as zn, isBetween as zt };
