import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { useLexicalComposerContext } from "./@lexical_react_LexicalComposerContext.js";
import { $isRangeSelection, $isRootNode, $isTextNode, CAN_REDO_COMMAND, CAN_UNDO_COMMAND, CLEAR_EDITOR_COMMAND, CLEAR_HISTORY_COMMAND, HISTORIC_TAG, HISTORY_PUSH_TAG, REDO_COMMAND, UNDO_COMMAND, configExtension, defineExtension, mergeRegister, safeCast } from "./lexical.js";
import "./LexicalUtils.dev-3NAN296g.js";
import { a as o, i as namedSignals, r as getPeerDependencyFromEditor, t as E } from "./LexicalExtension.dev-D5IB0gWg.js";
//#region node_modules/.bun/@lexical+history@0.41.0/node_modules/@lexical/history/LexicalHistory.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var HISTORY_MERGE = 0;
var HISTORY_PUSH = 1;
var DISCARD_HISTORY_CANDIDATE = 2;
var OTHER = 0;
var COMPOSING_CHARACTER = 1;
var INSERT_CHARACTER_AFTER_SELECTION = 2;
var DELETE_CHARACTER_BEFORE_SELECTION = 3;
var DELETE_CHARACTER_AFTER_SELECTION = 4;
function getDirtyNodes(editorState, dirtyLeaves, dirtyElements) {
	const nodeMap = editorState._nodeMap;
	const nodes = [];
	for (const dirtyLeafKey of dirtyLeaves) {
		const dirtyLeaf = nodeMap.get(dirtyLeafKey);
		if (dirtyLeaf !== void 0) nodes.push(dirtyLeaf);
	}
	for (const [dirtyElementKey, intentionallyMarkedAsDirty] of dirtyElements) {
		if (!intentionallyMarkedAsDirty) continue;
		const dirtyElement = nodeMap.get(dirtyElementKey);
		if (dirtyElement !== void 0 && !$isRootNode(dirtyElement)) nodes.push(dirtyElement);
	}
	return nodes;
}
function getChangeType(prevEditorState, nextEditorState, dirtyLeavesSet, dirtyElementsSet, isComposing) {
	if (prevEditorState === null || dirtyLeavesSet.size === 0 && dirtyElementsSet.size === 0 && !isComposing) return OTHER;
	const nextSelection = nextEditorState._selection;
	const prevSelection = prevEditorState._selection;
	if (isComposing) return COMPOSING_CHARACTER;
	if (!$isRangeSelection(nextSelection) || !$isRangeSelection(prevSelection) || !prevSelection.isCollapsed() || !nextSelection.isCollapsed()) return OTHER;
	const dirtyNodes = getDirtyNodes(nextEditorState, dirtyLeavesSet, dirtyElementsSet);
	if (dirtyNodes.length === 0) return OTHER;
	if (dirtyNodes.length > 1) {
		const nextNodeMap = nextEditorState._nodeMap;
		const nextAnchorNode = nextNodeMap.get(nextSelection.anchor.key);
		const prevAnchorNode = nextNodeMap.get(prevSelection.anchor.key);
		if (nextAnchorNode && prevAnchorNode && !prevEditorState._nodeMap.has(nextAnchorNode.__key) && $isTextNode(nextAnchorNode) && nextAnchorNode.__text.length === 1 && nextSelection.anchor.offset === 1) return INSERT_CHARACTER_AFTER_SELECTION;
		return OTHER;
	}
	const nextDirtyNode = dirtyNodes[0];
	const prevDirtyNode = prevEditorState._nodeMap.get(nextDirtyNode.__key);
	if (!$isTextNode(prevDirtyNode) || !$isTextNode(nextDirtyNode) || prevDirtyNode.__mode !== nextDirtyNode.__mode) return OTHER;
	const prevText = prevDirtyNode.__text;
	const nextText = nextDirtyNode.__text;
	if (prevText === nextText) return OTHER;
	const nextAnchor = nextSelection.anchor;
	const prevAnchor = prevSelection.anchor;
	if (nextAnchor.key !== prevAnchor.key || nextAnchor.type !== "text") return OTHER;
	const nextAnchorOffset = nextAnchor.offset;
	const prevAnchorOffset = prevAnchor.offset;
	const textDiff = nextText.length - prevText.length;
	if (textDiff === 1 && prevAnchorOffset === nextAnchorOffset - 1) return INSERT_CHARACTER_AFTER_SELECTION;
	if (textDiff === -1 && prevAnchorOffset === nextAnchorOffset + 1) return DELETE_CHARACTER_BEFORE_SELECTION;
	if (textDiff === -1 && prevAnchorOffset === nextAnchorOffset) return DELETE_CHARACTER_AFTER_SELECTION;
	return OTHER;
}
function isTextNodeUnchanged(key, prevEditorState, nextEditorState) {
	const prevNode = prevEditorState._nodeMap.get(key);
	const nextNode = nextEditorState._nodeMap.get(key);
	const prevSelection = prevEditorState._selection;
	const nextSelection = nextEditorState._selection;
	if (!($isRangeSelection(prevSelection) && $isRangeSelection(nextSelection) && prevSelection.anchor.type === "element" && prevSelection.focus.type === "element" && nextSelection.anchor.type === "text" && nextSelection.focus.type === "text") && $isTextNode(prevNode) && $isTextNode(nextNode) && prevNode.__parent === nextNode.__parent) return JSON.stringify(prevEditorState.read(() => prevNode.exportJSON())) === JSON.stringify(nextEditorState.read(() => nextNode.exportJSON()));
	return false;
}
function createMergeActionGetter(editor, delayOrStore) {
	let prevChangeTime = Date.now();
	let prevChangeType = OTHER;
	let compositionStartTime = Date.now();
	let compositionStartChangeType = OTHER;
	let compositionStartState = null;
	return (prevEditorState, nextEditorState, currentHistoryEntry, dirtyLeaves, dirtyElements, tags) => {
		const changeTime = Date.now();
		if (tags.has("composition-start")) {
			compositionStartTime = prevChangeTime;
			compositionStartChangeType = prevChangeType;
			compositionStartState = prevEditorState;
		}
		if (tags.has("historic")) {
			prevChangeType = OTHER;
			prevChangeTime = changeTime;
			return DISCARD_HISTORY_CANDIDATE;
		}
		if (tags.has("composition-end") && compositionStartState) {
			prevChangeTime = compositionStartTime;
			prevChangeType = compositionStartChangeType;
			prevEditorState = compositionStartState;
		}
		const changeType = getChangeType(prevEditorState, nextEditorState, dirtyLeaves, dirtyElements, editor.isComposing());
		const mergeAction = (() => {
			const isSameEditor = currentHistoryEntry === null || currentHistoryEntry.editor === editor;
			const shouldPushHistory = tags.has(HISTORY_PUSH_TAG);
			if (!shouldPushHistory && isSameEditor && tags.has("history-merge")) return HISTORY_MERGE;
			if (changeType === COMPOSING_CHARACTER) return DISCARD_HISTORY_CANDIDATE;
			if (prevEditorState === null) return HISTORY_PUSH;
			const selection = nextEditorState._selection;
			if (!(dirtyLeaves.size > 0 || dirtyElements.size > 0)) {
				if (selection !== null) return HISTORY_MERGE;
				return DISCARD_HISTORY_CANDIDATE;
			}
			const delay = typeof delayOrStore === "number" ? delayOrStore : delayOrStore.peek();
			if (shouldPushHistory === false && changeType !== OTHER && changeType === prevChangeType && changeTime < prevChangeTime + delay && isSameEditor) return HISTORY_MERGE;
			if (dirtyLeaves.size === 1) {
				const dirtyLeafKey = Array.from(dirtyLeaves)[0];
				if (isTextNodeUnchanged(dirtyLeafKey, prevEditorState, nextEditorState)) return HISTORY_MERGE;
			}
			return HISTORY_PUSH;
		})();
		prevChangeTime = changeTime;
		prevChangeType = changeType;
		return mergeAction;
	};
}
function redo(editor, historyState) {
	const redoStack = historyState.redoStack;
	const undoStack = historyState.undoStack;
	if (redoStack.length !== 0) {
		const current = historyState.current;
		if (current !== null) {
			undoStack.push(current);
			editor.dispatchCommand(CAN_UNDO_COMMAND, true);
		}
		const historyStateEntry = redoStack.pop();
		if (redoStack.length === 0) editor.dispatchCommand(CAN_REDO_COMMAND, false);
		historyState.current = historyStateEntry || null;
		if (historyStateEntry) historyStateEntry.editor.setEditorState(historyStateEntry.editorState, { tag: HISTORIC_TAG });
	}
}
function undo(editor, historyState) {
	const redoStack = historyState.redoStack;
	const undoStack = historyState.undoStack;
	if (undoStack.length !== 0) {
		const current = historyState.current;
		const historyStateEntry = undoStack.pop();
		if (current !== null) {
			redoStack.push(current);
			editor.dispatchCommand(CAN_REDO_COMMAND, true);
		}
		if (undoStack.length === 0) editor.dispatchCommand(CAN_UNDO_COMMAND, false);
		historyState.current = historyStateEntry || null;
		if (historyStateEntry) historyStateEntry.editor.setEditorState(historyStateEntry.editorState, { tag: HISTORIC_TAG });
	}
}
function clearHistory(historyState) {
	historyState.undoStack = [];
	historyState.redoStack = [];
	historyState.current = null;
}
/**
* Registers necessary listeners to manage undo/redo history stack and related editor commands.
* It returns `unregister` callback that cleans up all listeners and should be called on editor unmount.
* @param editor - The lexical editor.
* @param historyState - The history state, containing the current state and the undo/redo stack.
* @param delay - The time (in milliseconds) the editor should delay generating a new history stack,
* instead of merging the current changes with the current stack.
* @returns The listeners cleanup callback function.
*/
function registerHistory(editor, historyState, delay) {
	const getMergeAction = createMergeActionGetter(editor, delay);
	const applyChange = ({ editorState, prevEditorState, dirtyLeaves, dirtyElements, tags }) => {
		const current = historyState.current;
		const redoStack = historyState.redoStack;
		const undoStack = historyState.undoStack;
		const currentEditorState = current === null ? null : current.editorState;
		if (current !== null && editorState === currentEditorState) return;
		const mergeAction = getMergeAction(prevEditorState, editorState, current, dirtyLeaves, dirtyElements, tags);
		if (mergeAction === HISTORY_PUSH) {
			if (redoStack.length !== 0) {
				historyState.redoStack = [];
				editor.dispatchCommand(CAN_REDO_COMMAND, false);
			}
			if (current !== null) {
				undoStack.push({ ...current });
				editor.dispatchCommand(CAN_UNDO_COMMAND, true);
			}
		} else if (mergeAction === DISCARD_HISTORY_CANDIDATE) return;
		historyState.current = {
			editor,
			editorState
		};
	};
	return mergeRegister(editor.registerCommand(UNDO_COMMAND, () => {
		undo(editor, historyState);
		return true;
	}, 0), editor.registerCommand(REDO_COMMAND, () => {
		redo(editor, historyState);
		return true;
	}, 0), editor.registerCommand(CLEAR_EDITOR_COMMAND, () => {
		clearHistory(historyState);
		return false;
	}, 0), editor.registerCommand(CLEAR_HISTORY_COMMAND, () => {
		clearHistory(historyState);
		editor.dispatchCommand(CAN_REDO_COMMAND, false);
		editor.dispatchCommand(CAN_UNDO_COMMAND, false);
		return true;
	}, 0), editor.registerUpdateListener(applyChange));
}
/**
* Creates an empty history state.
* @returns - The empty history state, as an object.
*/
function createEmptyHistoryState() {
	return {
		current: null,
		redoStack: [],
		undoStack: []
	};
}
/**
* Registers necessary listeners to manage undo/redo history stack and related
* editor commands, via the \@lexical/history module.
*/
var HistoryExtension = defineExtension({
	build: (editor, { delay, createInitialHistoryState, disabled }) => namedSignals({
		delay,
		disabled,
		historyState: createInitialHistoryState(editor)
	}),
	config: safeCast({
		createInitialHistoryState: createEmptyHistoryState,
		delay: 300,
		disabled: typeof window === "undefined"
	}),
	name: "@lexical/history/History",
	register: (editor, config, state) => {
		const stores = state.getOutput();
		return E(() => stores.disabled.value ? void 0 : registerHistory(editor, stores.historyState.value, stores.delay));
	}
});
function getHistoryPeer(editor) {
	return editor ? getPeerDependencyFromEditor(editor, HistoryExtension.name) : null;
}
defineExtension({
	dependencies: [configExtension(HistoryExtension, {
		createInitialHistoryState: () => {
			throw new Error("SharedHistory did not inherit parent history");
		},
		disabled: true
	})],
	name: "@lexical/history/SharedHistory",
	register(editor, _config, state) {
		const { output } = state.getDependency(HistoryExtension);
		const parentPeer = getHistoryPeer(editor._parentEditor);
		if (!parentPeer) return () => {};
		const parentOutput = parentPeer.output;
		return E(() => o(() => {
			output.delay.value = parentOutput.delay.value;
			output.historyState.value = parentOutput.historyState.value;
			output.disabled.value = parentOutput.disabled.value;
		}));
	}
});
//#endregion
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalHistoryPlugin.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function useHistory(editor, externalHistoryState, delay = 1e3) {
	const historyState = (0, import_react.useMemo)(() => externalHistoryState || createEmptyHistoryState(), [externalHistoryState]);
	(0, import_react.useEffect)(() => {
		return registerHistory(editor, historyState, delay);
	}, [
		delay,
		editor,
		historyState
	]);
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function HistoryPlugin({ delay, externalHistoryState }) {
	const [editor] = useLexicalComposerContext();
	useHistory(editor, externalHistoryState, delay);
	return null;
}
//#endregion
export { HistoryPlugin, createEmptyHistoryState };
