import { i as __toESM, t as __commonJSMin } from "./rolldown-runtime-B4lejLz5.js";
import { F as DIFFS_TAG_NAME, S as CUSTOM_HEADER_SLOT_ID, c as getCustomExtensionsMap, k as DEFAULT_THEMES, l as getCustomExtensionsVersion, o as getLineAnnotationName, u as getFiletypeFromFileName } from "./platform-vkp1Dvjb.js";
import { C as FileDiff$1, Ct as getThemes, D as isDiffPlainText, Et as getSharedHighlighter, Ft as attachResolvedThemes, H as VirtualizedFile, L as areDiffRenderOptionsEqual, O as renderDiffWithHighlighter, S as VirtualizedFileDiff, U as File$1, V as areDiffTargetsEqual, _n as areOptionsEqual, a as hasResolvedLanguages, b as areManagedSnapshotsEqual, bt as areFileRenderOptionsEqual, cn as parseDiffFromFile, d as getMergeConflictActionAnchor, f as parseMergeConflictDiffFromFile, i as resolveLanguages, l as UnresolvedFile$1, n as resolveThemes, o as getResolvedLanguages, on as areFilesEqual, ot as isFilePlainText, p as getMergeConflictActionSlotName, r as getResolvedThemes, s as Virtualizer$1, st as renderFileWithHighlighter, t as getSingularPatch, vn as areThemesEqual, xt as hasResolvedThemes, y as CodeView$1 } from "./getSingularPatch-BAVc3pWq.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { t as require_react_dom } from "./react-dom.js";
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/useStableCallback.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function useStableCallback(callback) {
	const callbackRef = (0, import_react.useRef)(callback);
	(0, import_react.useInsertionEffect)(() => void (callbackRef.current = callback));
	return (0, import_react.useCallback)((...args) => {
		return callbackRef.current(...args);
	}, []);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/EditContext.js
var import_jsx_runtime = require_jsx_runtime();
var EditContext = (0, import_react.createContext)(void 0);
function EditProvider({ children, createEditor }) {
	const editorCacheRef = (0, import_react.useRef)(/* @__PURE__ */ new WeakMap());
	const stableCreateEditor = useStableCallback((options) => {
		const cached = editorCacheRef.current.get(options);
		if (cached != null) return cached;
		const editor = createEditor(options);
		editorCacheRef.current.set(options, editor);
		return editor;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditContext.Provider, {
		value: stableCreateEditor,
		children
	});
}
function useCreateEditor() {
	return (0, import_react.useContext)(EditContext);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/constants.js
var GutterUtilitySlotStyles = {
	position: "absolute",
	top: 0,
	bottom: 0,
	textAlign: "center",
	whiteSpace: "normal",
	touchAction: "none"
};
var MergeConflictSlotStyles = { display: "contents" };
function noopRender() {
	return null;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/renderDiffChildren.js
function renderDiffChildren({ fileDiff, actions, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderAnnotation, renderGutterUtility, renderMergeConflictUtility, lineAnnotations, getHoveredLine, getInstance }) {
	const customHeader = renderCustomHeader?.(fileDiff);
	const prefix = renderHeaderPrefix?.(fileDiff);
	const suffix = renderHeaderFilenameSuffix?.(fileDiff);
	const metadata = renderHeaderMetadata?.(fileDiff);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		customHeader != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			slot: CUSTOM_HEADER_SLOT_ID,
			children: customHeader
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			prefix != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot: "header-prefix",
				children: prefix
			}),
			suffix != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot: "header-filename-suffix",
				children: suffix
			}),
			metadata != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot: "header-metadata",
				children: metadata
			})
		] }),
		renderAnnotation != null && lineAnnotations?.map((annotation, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			slot: getLineAnnotationName(annotation),
			children: renderAnnotation(annotation)
		}, index)),
		actions != null && renderMergeConflictUtility != null && getInstance != null && actions.map((action) => {
			if (action == null) return;
			const slot = getSlotName(action, fileDiff);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot,
				style: MergeConflictSlotStyles,
				children: renderMergeConflictUtility(action, getInstance)
			}, slot);
		}),
		renderGutterUtility != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			slot: "gutter-utility-slot",
			style: GutterUtilitySlotStyles,
			children: renderGutterUtility(getHoveredLine)
		})
	] });
}
function getSlotName(action, fileDiff) {
	const anchor = getMergeConflictActionAnchor(action, fileDiff);
	return anchor != null ? getMergeConflictActionSlotName({
		hunkIndex: anchor.hunkIndex,
		lineIndex: anchor.lineIndex,
		conflictIndex: action.conflictIndex
	}) : void 0;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/renderFileChildren.js
function renderFileChildren({ file, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderAnnotation, lineAnnotations, renderGutterUtility, getHoveredLine }) {
	const customHeader = renderCustomHeader?.(file);
	const prefix = renderHeaderPrefix?.(file);
	const suffix = renderHeaderFilenameSuffix?.(file);
	const metadata = renderHeaderMetadata?.(file);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		customHeader != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			slot: CUSTOM_HEADER_SLOT_ID,
			children: customHeader
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			prefix != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot: "header-prefix",
				children: prefix
			}),
			suffix != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot: "header-filename-suffix",
				children: suffix
			}),
			metadata != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				slot: "header-metadata",
				children: metadata
			})
		] }),
		renderAnnotation != null && lineAnnotations?.map((annotation, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			slot: getLineAnnotationName(annotation),
			children: renderAnnotation(annotation)
		}, index)),
		renderGutterUtility != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			slot: "gutter-utility-slot",
			style: GutterUtilitySlotStyles,
			children: renderGutterUtility(getHoveredLine)
		})
	] });
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/worker/WorkerPoolManager.js
var import_lru = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(g, c) {
		typeof exports == "object" && typeof module != "undefined" ? c(exports) : typeof define == "function" && define.amd ? define(["exports"], c) : c((g = g || self).lru_map = g.lru_map || {});
	})(exports, function(g) {
		const c = Symbol("newer"), e = Symbol("older");
		class n {
			constructor(a, b) {
				typeof a !== "number" && (b = a, a = 0), this.size = 0, this.limit = a, this.oldest = this.newest = void 0, this._keymap = /* @__PURE__ */ new Map(), b && (this.assign(b), a < 1 && (this.limit = this.size));
			}
			_markEntryAsUsed(a) {
				if (a === this.newest) return;
				a[c] && (a === this.oldest && (this.oldest = a[c]), a[c][e] = a[e]), a[e] && (a[e][c] = a[c]), a[c] = void 0, a[e] = this.newest, this.newest && (this.newest[c] = a), this.newest = a;
			}
			assign(a) {
				let b, d = this.limit || Number.MAX_VALUE;
				this._keymap.clear();
				let m = a[Symbol.iterator]();
				for (let h = m.next(); !h.done; h = m.next()) {
					let f = new l(h.value[0], h.value[1]);
					this._keymap.set(f.key, f), b ? (b[c] = f, f[e] = b) : this.oldest = f, b = f;
					if (d-- == 0) throw new Error("overflow");
				}
				this.newest = b, this.size = this._keymap.size;
			}
			get(a) {
				var b = this._keymap.get(a);
				return b ? (this._markEntryAsUsed(b), b.value) : void 0;
			}
			set(a, b) {
				var d = this._keymap.get(a);
				return d ? (d.value = b, this._markEntryAsUsed(d), this) : (this._keymap.set(a, d = new l(a, b)), this.newest ? (this.newest[c] = d, d[e] = this.newest) : this.oldest = d, this.newest = d, ++this.size, this.size > this.limit && this.shift(), this);
			}
			shift() {
				var a = this.oldest;
				if (a) return this.oldest[c] ? (this.oldest = this.oldest[c], this.oldest[e] = void 0) : (this.oldest = void 0, this.newest = void 0), a[c] = a[e] = void 0, this._keymap.delete(a.key), --this.size, [a.key, a.value];
			}
			find(a) {
				let b = this._keymap.get(a);
				return b ? b.value : void 0;
			}
			has(a) {
				return this._keymap.has(a);
			}
			delete(a) {
				var b = this._keymap.get(a);
				return b ? (this._keymap.delete(b.key), b[c] && b[e] ? (b[e][c] = b[c], b[c][e] = b[e]) : b[c] ? (b[c][e] = void 0, this.oldest = b[c]) : b[e] ? (b[e][c] = void 0, this.newest = b[e]) : this.oldest = this.newest = void 0, this.size--, b.value) : void 0;
			}
			clear() {
				this.oldest = this.newest = void 0, this.size = 0, this._keymap.clear();
			}
			keys() {
				return new j(this.oldest);
			}
			values() {
				return new k(this.oldest);
			}
			entries() {
				return this;
			}
			[Symbol.iterator]() {
				return new i(this.oldest);
			}
			forEach(a, b) {
				typeof b !== "object" && (b = this);
				let d = this.oldest;
				for (; d;) a.call(b, d.value, d.key, this), d = d[c];
			}
			toJSON() {
				for (var a = new Array(this.size), b = 0, d = this.oldest; d;) a[b++] = {
					key: d.key,
					value: d.value
				}, d = d[c];
				return a;
			}
			toString() {
				for (var a = "", b = this.oldest; b;) a += String(b.key) + ":" + b.value, b = b[c], b && (a += " < ");
				return a;
			}
		}
		g.LRUMap = n;
		function l(a, b) {
			this.key = a, this.value = b, this[c] = void 0, this[e] = void 0;
		}
		function i(a) {
			this.entry = a;
		}
		i.prototype[Symbol.iterator] = function() {
			return this;
		}, i.prototype.next = function() {
			let a = this.entry;
			return a ? (this.entry = a[c], {
				done: !1,
				value: [a.key, a.value]
			}) : {
				done: !0,
				value: void 0
			};
		};
		function j(a) {
			this.entry = a;
		}
		j.prototype[Symbol.iterator] = function() {
			return this;
		}, j.prototype.next = function() {
			let a = this.entry;
			return a ? (this.entry = a[c], {
				done: !1,
				value: a.key
			}) : {
				done: !0,
				value: void 0
			};
		};
		function k(a) {
			this.entry = a;
		}
		k.prototype[Symbol.iterator] = function() {
			return this;
		}, k.prototype.next = function() {
			let a = this.entry;
			return a ? (this.entry = a[c], {
				done: !1,
				value: a.value
			}) : {
				done: !0,
				value: void 0
			};
		};
	});
})))(), 1);
var IGNORE_RESPONSE = Symbol("IGNORE_RESPONSE");
var WorkerPoolTerminatedError = class extends Error {
	constructor() {
		super("WorkerPoolManager: operation canceled because the pool terminated");
	}
};
var WorkerPoolTaskCanceledError = class extends Error {
	constructor() {
		super("WorkerPoolManager: operation canceled before the task completed");
	}
};
var WorkerPoolManager = class {
	options;
	highlighter;
	preferredHighlighter;
	renderOptions;
	renderOptionsRequestVersion = 0;
	renderOptionsVersion = 0;
	initialized = false;
	workers = [];
	queuedTasks = [];
	queuedTaskByInstance = /* @__PURE__ */ new Map();
	taskByHighlightKey = /* @__PURE__ */ new Map();
	activeTaskById = /* @__PURE__ */ new Map();
	activeRequestByInstance = /* @__PURE__ */ new Map();
	nextRequestId = 0;
	themeSubscribers = /* @__PURE__ */ new Set();
	workersFailed = false;
	statSubscribers = /* @__PURE__ */ new Set();
	fileCache;
	diffCache;
	_queuedBroadcast;
	lifecycleGeneration = 0;
	constructor(options, { langs, theme = DEFAULT_THEMES, useTokenTransformer = false, lineDiffType = "word-alt", maxLineDiffLength = 1e3, tokenizeMaxLineLength = 1e3, preferredHighlighter = "shiki-js" }) {
		this.options = options;
		this.preferredHighlighter = preferredHighlighter;
		this.renderOptions = {
			theme,
			useTokenTransformer,
			lineDiffType,
			maxLineDiffLength,
			tokenizeMaxLineLength
		};
		this.fileCache = new import_lru.default.LRUMap(options.totalASTLRUCacheSize ?? 100);
		this.diffCache = new import_lru.default.LRUMap(options.totalASTLRUCacheSize ?? 100);
		this.queueInitialization(langs);
	}
	isWorkingPool() {
		return !this.workersFailed;
	}
	getFileResultCache(file) {
		return file.cacheKey != null ? this.fileCache.get(file.cacheKey) : void 0;
	}
	getDiffResultCache(diff) {
		return diff.cacheKey != null ? this.diffCache.get(diff.cacheKey) : void 0;
	}
	inspectCaches() {
		const { fileCache, diffCache } = this;
		return {
			fileCache,
			diffCache
		};
	}
	evictFileFromCache(cacheKey) {
		try {
			return this.fileCache.delete(cacheKey) !== void 0;
		} finally {
			this.queueBroadcastStateChanges();
		}
	}
	evictDiffFromCache(cacheKey) {
		try {
			return this.diffCache.delete(cacheKey) !== void 0;
		} finally {
			this.queueBroadcastStateChanges();
		}
	}
	async setRenderOptions({ theme = this.renderOptions.theme ?? DEFAULT_THEMES, useTokenTransformer = this.renderOptions.useTokenTransformer ?? false, lineDiffType = this.renderOptions.lineDiffType ?? "word-alt", maxLineDiffLength = this.renderOptions.maxLineDiffLength ?? 1e3, tokenizeMaxLineLength = this.renderOptions.tokenizeMaxLineLength ?? 1e3 }) {
		const { lifecycleGeneration } = this;
		const renderOptionsRequestVersion = ++this.renderOptionsRequestVersion;
		const isCurrentRequest = () => this.isCurrentLifecycle(lifecycleGeneration) && this.renderOptionsRequestVersion === renderOptionsRequestVersion;
		try {
			const newRenderOptions = {
				theme,
				useTokenTransformer,
				lineDiffType,
				maxLineDiffLength,
				tokenizeMaxLineLength
			};
			if (!this.isInitialized()) await this.initialize();
			if (!isCurrentRequest() || areDiffRenderOptionsEqual(newRenderOptions, this.renderOptions)) return;
			const themeNames = getThemes(theme);
			let resolvedThemes = [];
			if (!areThemesEqual(newRenderOptions.theme, this.renderOptions.theme)) if (hasResolvedThemes(themeNames)) resolvedThemes = getResolvedThemes(themeNames);
			else resolvedThemes = await resolveThemes(themeNames);
			if (!isCurrentRequest()) return;
			if (this.highlighter != null) attachResolvedThemes(resolvedThemes, this.highlighter);
			else {
				const highlighter = await getSharedHighlighter({
					themes: themeNames,
					langs: ["text"],
					preferredHighlighter: this.preferredHighlighter
				});
				if (!isCurrentRequest()) return;
				this.highlighter = highlighter;
			}
			const workerSetup = this.setRenderOptionsOnWorkers(newRenderOptions, resolvedThemes);
			this.renderOptions = newRenderOptions;
			this.renderOptionsVersion++;
			this.diffCache.clear();
			this.fileCache.clear();
			this.invalidateRenderTasks();
			for (const instance of this.themeSubscribers) instance.onThemeChange();
			await workerSetup;
		} catch (error) {
			if (error instanceof WorkerPoolTerminatedError || !isCurrentRequest()) return;
			throw error;
		}
	}
	getPreferredHighlighter() {
		return this.preferredHighlighter;
	}
	getFileRenderOptions() {
		const { tokenizeMaxLineLength, theme, useTokenTransformer } = this.renderOptions;
		return {
			theme,
			useTokenTransformer,
			tokenizeMaxLineLength
		};
	}
	getDiffRenderOptions() {
		return { ...this.renderOptions };
	}
	async setRenderOptionsOnWorkers(renderOptions, resolvedThemes) {
		if (this.workersFailed) return;
		if (!this.isInitialized()) await this.initialize();
		const taskPromises = [];
		for (const managedWorker of this.workers) {
			if (!managedWorker.initialized) {
				console.log({ managedWorker });
				throw new Error("setRenderOptionsOnWorkers: Somehow we have an uninitialized worker");
			}
			taskPromises.push(new Promise((resolve, reject) => {
				const id = this.generateRequestId();
				const task = {
					type: "set-render-options",
					id,
					request: {
						type: "set-render-options",
						id,
						renderOptions,
						resolvedThemes
					},
					resolve,
					reject,
					requestStart: Date.now()
				};
				this.activeTaskById.set(id, task);
				managedWorker.pendingSetupRequestId = id;
				managedWorker.worker.postMessage(task.request);
			}));
		}
		await Promise.all(taskPromises);
	}
	subscribeToThemeChanges(instance) {
		this.themeSubscribers.add(instance);
		this.queueBroadcastStateChanges();
		return () => {
			this.unsubscribeToThemeChanges(instance);
			this.queueBroadcastStateChanges();
		};
	}
	unsubscribeToThemeChanges(instance) {
		this.themeSubscribers.delete(instance);
		this.queueBroadcastStateChanges();
	}
	subscribeToStatChanges(callback) {
		this.statSubscribers.add(callback);
		callback(this.getStats());
		return () => {
			this.statSubscribers.delete(callback);
		};
	}
	queueBroadcastStateChanges() {
		if (this._queuedBroadcast != null) return;
		this._queuedBroadcast = requestAnimationFrame(this._broadcastStateChanges);
	}
	_broadcastStateChanges = () => {
		if (this._queuedBroadcast != null) {
			cancelAnimationFrame(this._queuedBroadcast);
			this._queuedBroadcast = void 0;
		}
		const stats = this.getStats();
		for (const callback of this.statSubscribers) callback(stats);
	};
	cleanUpTasks(instance) {
		this.detachInstanceFromQueuedTasks(instance);
		const requestId = this.activeRequestByInstance.get(instance);
		if (requestId != null) {
			const task = this.activeTaskById.get(requestId);
			if (isRenderTask(task)) {
				this.detachInstanceFromRenderTask(task, instance);
				if (!task.primeCache && task.instances.size === 0) this.removeActiveTask(task);
			} else this.activeTaskById.delete(requestId);
		}
		this.activeRequestByInstance.delete(instance);
		this.queueBroadcastStateChanges();
	}
	isInitialized() {
		return this.initialized === true;
	}
	async initialize(languages = []) {
		if (this.initialized === true) return;
		else if (this.initialized === false) {
			const { lifecycleGeneration } = this;
			this.initialized = new Promise((resolve, reject) => {
				(async () => {
					try {
						const themes = getThemes(this.renderOptions.theme);
						let resolvedThemes = [];
						if (hasResolvedThemes(themes)) resolvedThemes = getResolvedThemes(themes);
						else resolvedThemes = await resolveThemes(themes);
						if (!this.isCurrentLifecycle(lifecycleGeneration)) {
							resolve();
							return;
						}
						let resolvedLanguages = [];
						if (hasResolvedLanguages(languages)) resolvedLanguages = getResolvedLanguages(languages);
						else resolvedLanguages = await resolveLanguages(languages);
						if (!this.isCurrentLifecycle(lifecycleGeneration)) {
							resolve();
							return;
						}
						const [highlighter] = await Promise.all([getSharedHighlighter({
							themes,
							langs: ["text", ...languages],
							preferredHighlighter: this.preferredHighlighter
						}), this.initializeWorkers(resolvedThemes, resolvedLanguages)]);
						if (!this.isCurrentLifecycle(lifecycleGeneration)) {
							this.terminateWorkers();
							resolve();
							return;
						}
						this.highlighter = highlighter;
						this.initialized = true;
						this.diffCache.clear();
						this.fileCache.clear();
						this.drainQueue();
						this.queueBroadcastStateChanges();
						resolve();
					} catch (e) {
						if (e instanceof WorkerPoolTerminatedError || !this.isCurrentLifecycle(lifecycleGeneration)) {
							resolve();
							return;
						}
						this.initialized = false;
						this.workersFailed = true;
						for (const task of this.queuedTasks) this.rejectRenderTaskCallbacks(task, normalizeWorkerError(e));
						this.queueBroadcastStateChanges();
						reject(e);
					}
				})();
			});
			this.queueBroadcastStateChanges();
		} else return this.initialized;
	}
	async initializeWorkers(resolvedThemes, resolvedLanguages) {
		this.workersFailed = false;
		const initPromises = [];
		const customExtensionVersion = getCustomExtensionsVersion();
		const customExtensionMap = customExtensionVersion > 0 ? getCustomExtensionsMap() : void 0;
		if (this.workers.length > 0) this.terminateWorkers();
		for (let i = 0; i < (this.options.poolSize ?? 8); i++) {
			const worker = this.options.workerFactory();
			const managedWorker = {
				worker,
				requestId: void 0,
				pendingSetupRequestId: void 0,
				initialized: false,
				langs: /* @__PURE__ */ new Set(["text", ...resolvedLanguages.map(({ name }) => name)]),
				customExtensionsVersion: 0
			};
			worker.addEventListener("message", (event) => {
				this.handleWorkerMessage(managedWorker, event.data);
			});
			worker.addEventListener("error", (error) => console.error("Worker error:", error, managedWorker));
			this.workers.push(managedWorker);
			initPromises.push(new Promise((resolve, reject) => {
				const id = this.generateRequestId();
				const task = {
					type: "initialize",
					id,
					request: {
						type: "initialize",
						id,
						renderOptions: this.renderOptions,
						preferredHighlighter: this.preferredHighlighter,
						resolvedThemes,
						resolvedLanguages,
						customExtensionsVersion: customExtensionMap != null ? customExtensionVersion : void 0,
						customExtensionMap
					},
					resolve() {
						managedWorker.initialized = true;
						resolve();
					},
					reject,
					requestStart: Date.now()
				};
				this.activeTaskById.set(id, task);
				this.executeTask(managedWorker, task);
			}));
		}
		await Promise.all(initPromises);
	}
	drainQueue = () => {
		this._queuedDrain = void 0;
		if (this.initialized !== true || this.queuedTasks.length === 0) return;
		for (let i = 0; i < this.queuedTasks.length;) {
			const task = this.queuedTasks[i];
			if (this.hasActiveRequest(task)) {
				i++;
				continue;
			}
			const langs = getLangsFromTask(task);
			const availableWorker = this.getAvailableWorker(langs);
			if (availableWorker == null) break;
			this.queuedTasks.splice(i, 1);
			this.assignWorkerToTask(task, availableWorker);
			this.resolveLanguagesAndExecuteTask(availableWorker, task, langs);
		}
		this.queueBroadcastStateChanges();
	};
	highlightFileAST(instance, file) {
		const cachedResult = this.getFileResultCache(file);
		if (isFilePlainText(file) || cachedResult != null && areFileRenderOptionsEqual(cachedResult.options, this.getFileRenderOptions())) return;
		if (!this.hasMatchingFileInstanceTask(instance, file)) this.submitTask(instance, {
			type: "file",
			file
		});
	}
	primeFileHighlightCache(file) {
		if (!this.isWorkingPool()) return Promise.reject(/* @__PURE__ */ new Error("WorkerPoolManager.primeFileHighlightCache: worker pool is not working"));
		const task = this.getOrCreateFileHighlightCacheTask(file);
		return task != null ? this.createRenderTaskCallbacks(task) : Promise.resolve();
	}
	getOrCreateFileHighlightCacheTask(file) {
		if (file.cacheKey == null) {
			console.warn(`WorkerPoolManager.primeFileHighlightCache: priming highlight cache requires file.cacheKey; skipping "${file.name}".`);
			return;
		}
		const cachedResult = this.getFileResultCache(file);
		const highlightKey = this.getFileHighlightKey(file);
		if (highlightKey == null || isFilePlainText(file) || cachedResult != null && areFileRenderOptionsEqual(cachedResult.options, this.getFileRenderOptions())) return;
		const existingTask = this.getTaskByHighlightKey(highlightKey);
		if (existingTask != null) {
			existingTask.primeCache = true;
			return existingTask.type === "file" ? existingTask : void 0;
		} else {
			const task = this.submitCacheTask({
				type: "file",
				file
			}, highlightKey);
			return task.type === "file" ? task : void 0;
		}
	}
	getPlainFileAST(file, startingLine, totalLines, lines) {
		if (this.highlighter == null) {
			this.queueInitialization();
			return;
		}
		return renderFileWithHighlighter(file, this.highlighter, this.renderOptions, {
			forcePlainText: true,
			startingLine,
			totalLines,
			lines
		});
	}
	highlightDiffAST(instance, diff) {
		const cachedResult = this.getDiffResultCache(diff);
		if (isDiffPlainText(diff) || cachedResult != null && areDiffRenderOptionsEqual(cachedResult.options, this.getDiffRenderOptions())) return;
		if (!this.hasMatchingDiffInstanceTask(instance, diff)) this.submitTask(instance, {
			type: "diff",
			diff
		});
	}
	primeDiffHighlightCache(diff) {
		if (!this.isWorkingPool()) return Promise.reject(/* @__PURE__ */ new Error("WorkerPoolManager.primeDiffHighlightCache: worker pool is not working"));
		const task = this.getOrCreateDiffHighlightCacheTask(diff);
		return task != null ? this.createRenderTaskCallbacks(task) : Promise.resolve();
	}
	getOrCreateDiffHighlightCacheTask(diff) {
		if (diff.cacheKey == null) {
			console.warn(`WorkerPoolManager.primeDiffHighlightCache: priming highlight cache requires diff.cacheKey; skipping "${diff.prevName ?? diff.name}" -> "${diff.name}".`);
			return;
		}
		const cachedResult = this.getDiffResultCache(diff);
		const highlightKey = this.getDiffHighlightKey(diff);
		if (highlightKey == null || isDiffPlainText(diff) || cachedResult != null && areDiffRenderOptionsEqual(cachedResult.options, this.getDiffRenderOptions())) return;
		const existingTask = this.getTaskByHighlightKey(highlightKey);
		if (existingTask != null) {
			existingTask.primeCache = true;
			return existingTask.type === "diff" ? existingTask : void 0;
		} else {
			const task = this.submitCacheTask({
				type: "diff",
				diff
			}, highlightKey);
			return task.type === "diff" ? task : void 0;
		}
	}
	getPlainDiffAST(diff, startingLine, totalLines, expandedHunks, collapsedContextThreshold) {
		return this.highlighter != null ? renderDiffWithHighlighter(diff, this.highlighter, this.renderOptions, {
			forcePlainText: true,
			startingLine,
			totalLines,
			expandedHunks,
			collapsedContextThreshold
		}) : void 0;
	}
	terminate() {
		this.lifecycleGeneration++;
		this.cancelActiveWorkerTasks();
		this.terminateWorkers();
		const error = new WorkerPoolTerminatedError();
		for (const task of this.queuedTasks) this.rejectRenderTaskCallbacks(task, error);
		this.fileCache.clear();
		this.diffCache.clear();
		this.activeRequestByInstance.clear();
		this.queuedTasks.length = 0;
		this.queuedTaskByInstance.clear();
		this.taskByHighlightKey.clear();
		this.activeTaskById.clear();
		this.highlighter = void 0;
		this.initialized = false;
		this.workersFailed = false;
		this.queueBroadcastStateChanges();
	}
	isCurrentLifecycle(lifecycleGeneration) {
		return this.lifecycleGeneration === lifecycleGeneration;
	}
	queueInitialization(languages) {
		this.initialize(languages).catch((error) => {
			console.error(error);
		});
	}
	cancelActiveWorkerTasks() {
		const error = new WorkerPoolTerminatedError();
		for (const task of this.activeTaskById.values()) if ("reject" in task) task.reject(error);
		else if (isRenderTask(task)) this.rejectRenderTaskCallbacks(task, error);
	}
	terminateWorkers() {
		for (const managedWorker of this.workers) managedWorker.worker.terminate();
		this.workers.length = 0;
	}
	getStats() {
		return {
			managerState: (() => {
				if (this.initialized === false) return "waiting";
				if (this.initialized !== true) return "initializing";
				return "initialized";
			})(),
			totalWorkers: this.workers.length,
			workersFailed: this.workersFailed,
			busyWorkers: this.workers.filter((w) => w.requestId != null || w.pendingSetupRequestId != null).length,
			queuedTasks: this.queuedTasks.length,
			activeTasks: this.activeTaskById.size,
			themeSubscribers: this.themeSubscribers.size,
			fileCacheSize: this.fileCache.size,
			diffCacheSize: this.diffCache.size
		};
	}
	submitTask(instance, request) {
		if (this.initialized === false) this.queueInitialization();
		const highlightKey = this.getHighlightKeyForRequest(request);
		const existingTask = highlightKey != null ? this.getTaskByHighlightKey(highlightKey) : void 0;
		if (existingTask != null) {
			this.detachInstanceFromQueuedTasks(instance, existingTask);
			this.addInstanceToTask(existingTask, instance);
			this.queueBroadcastStateChanges();
			return;
		}
		this.detachInstanceFromQueuedTasks(instance);
		const id = this.generateRequestId();
		const requestStart = Date.now();
		const { renderOptionsVersion } = this;
		const task = (() => {
			switch (request.type) {
				case "file": return {
					type: "file",
					id,
					request: {
						...request,
						id
					},
					instances: /* @__PURE__ */ new Set([instance]),
					primeCache: false,
					highlightKey,
					callbacks: /* @__PURE__ */ new Set(),
					renderOptionsVersion,
					requestStart
				};
				case "diff": return {
					type: "diff",
					id,
					request: {
						...request,
						id
					},
					instances: /* @__PURE__ */ new Set([instance]),
					primeCache: false,
					highlightKey,
					callbacks: /* @__PURE__ */ new Set(),
					renderOptionsVersion,
					requestStart
				};
			}
		})();
		this.enqueueRenderTask(task, instance);
	}
	submitCacheTask(request, highlightKey) {
		if (this.initialized === false) this.queueInitialization();
		const id = this.generateRequestId();
		const requestStart = Date.now();
		const { renderOptionsVersion } = this;
		const task = (() => {
			switch (request.type) {
				case "file": return {
					type: "file",
					id,
					request: {
						...request,
						id
					},
					instances: /* @__PURE__ */ new Set(),
					primeCache: true,
					highlightKey,
					callbacks: /* @__PURE__ */ new Set(),
					renderOptionsVersion,
					requestStart
				};
				case "diff": return {
					type: "diff",
					id,
					request: {
						...request,
						id
					},
					instances: /* @__PURE__ */ new Set(),
					primeCache: true,
					highlightKey,
					callbacks: /* @__PURE__ */ new Set(),
					renderOptionsVersion,
					requestStart
				};
			}
		})();
		this.enqueueRenderTask(task);
		return task;
	}
	enqueueRenderTask(task, instance) {
		this.queuedTasks.push(task);
		if (instance != null) this.queuedTaskByInstance.set(instance, task);
		if (task.highlightKey != null) this.taskByHighlightKey.set(task.highlightKey, task);
		this.queueDrain();
	}
	async resolveLanguagesAndExecuteTask(availableWorker, task, langs) {
		try {
			const workerMissingLangs = langs.filter((lang) => !availableWorker.langs.has(lang));
			if (workerMissingLangs.length > 0) if (hasResolvedLanguages(workerMissingLangs)) task.request.resolvedLanguages = getResolvedLanguages(workerMissingLangs);
			else task.request.resolvedLanguages = await resolveLanguages(workerMissingLangs);
			if (!this.activeTaskById.has(task.id)) {
				if (availableWorker.requestId === task.id) {
					this.cleanWorkerAndTask(availableWorker, task);
					this.queueBroadcastStateChanges();
					if (this.queuedTasks.length > 0) this.queueDrain();
				}
				return;
			}
			this.executeTask(availableWorker, task);
		} catch (error) {
			this.rejectRenderTaskCallbacks(task, normalizeWorkerError(error));
			this.cleanWorkerAndTask(availableWorker, task);
			this.queueBroadcastStateChanges();
			if (this.queuedTasks.length > 0) this.queueDrain();
		}
	}
	handleWorkerMessage(managedWorker, response) {
		const task = this.activeTaskById.get(response.id);
		try {
			if (task == null) throw IGNORE_RESPONSE;
			else if (response.type === "error") {
				const error = new Error(response.error);
				if (response.stack) error.stack = response.stack;
				if ("reject" in task) task.reject(error);
				else if (isRenderTask(task)) {
					this.notifyHighlightError(task, error);
					this.rejectRenderTaskCallbacks(task, error);
				} else throw new Error("handleWorkerMessage: unknown task type");
				throw error;
			} else switch (response.requestType) {
				case "initialize":
					if (task.type !== "initialize") throw new Error("handleWorkerMessage: task/response dont match");
					this.syncCustomExtensionVersion(managedWorker, task.request);
					task.resolve();
					break;
				case "set-render-options":
					if (task.type !== "set-render-options") throw new Error("handleWorkerMessage: task/response dont match");
					task.resolve();
					break;
				case "file": {
					if (task.type !== "file") throw new Error("handleWorkerMessage: task/response dont match");
					const { result, options } = response;
					if (!this.isCurrentRenderTask(task) || !areFileRenderOptionsEqual(options, this.getFileRenderOptions())) throw IGNORE_RESPONSE;
					const { request } = task;
					this.syncCustomExtensionVersion(managedWorker, request);
					if (task.cacheKeyAtDispatch != null) this.fileCache.set(task.cacheKeyAtDispatch, {
						result,
						options
					});
					this.resolveRenderTaskCallbacks(task);
					this.notifyFileInstances(task, result, options);
					break;
				}
				case "diff": {
					if (task.type !== "diff") throw new Error("handleWorkerMessage: task/response dont match");
					const { result, options } = response;
					if (!this.isCurrentRenderTask(task) || !areDiffRenderOptionsEqual(options, this.getDiffRenderOptions())) throw IGNORE_RESPONSE;
					const { request } = task;
					this.syncCustomExtensionVersion(managedWorker, request);
					if (task.cacheKeyAtDispatch != null) this.diffCache.set(task.cacheKeyAtDispatch, {
						result,
						options
					});
					this.resolveRenderTaskCallbacks(task);
					this.notifyDiffInstances(task, result, options);
					break;
				}
			}
		} catch (error) {
			if (error !== IGNORE_RESPONSE) console.error(error, task, response);
		}
		this.cleanWorkerAndTask(managedWorker, task, response.id);
		this.queueBroadcastStateChanges();
		if (this.queuedTasks.length > 0) this.queueDrain();
	}
	_queuedDrain;
	queueDrain() {
		if (this._queuedDrain != null) return;
		this._queuedDrain = Promise.resolve().then(this.drainQueue);
		this.queueBroadcastStateChanges();
	}
	assignWorkerToTask(task, managedWorker) {
		managedWorker.requestId = task.id;
		if (isRenderTask(task)) {
			this.clearQueuedInstanceRequests(task);
			this.trackInstanceRequests(task);
		}
		this.activeTaskById.set(task.id, task);
	}
	cleanWorkerAndTask(managedWorker, task, requestId = task?.id) {
		if (managedWorker.requestId === requestId) managedWorker.requestId = void 0;
		if (managedWorker.pendingSetupRequestId === requestId) managedWorker.pendingSetupRequestId = void 0;
		if (task != null) {
			if (isRenderTask(task)) {
				this.rejectRenderTaskCallbacks(task, new WorkerPoolTaskCanceledError());
				this.clearInstanceRequests(task);
				this.clearHighlightKey(task);
			}
			this.activeTaskById.delete(task.id);
		}
	}
	executeTask(managedWorker, task) {
		if (shouldSyncCustomExtensions(task.request)) this.maybeAttachCustomExtensions(managedWorker, task.request);
		if (!this.activeTaskById.has(task.id)) this.assignWorkerToTask(task, managedWorker);
		for (const lang of getLangsFromTask(task)) managedWorker.langs.add(lang);
		try {
			if (task.type === "file") task.cacheKeyAtDispatch = task.request.file.cacheKey;
			else if (task.type === "diff") task.cacheKeyAtDispatch = task.request.diff.cacheKey;
			managedWorker.worker.postMessage(task.request);
		} catch (error) {
			console.error("Failed to post message to worker:", error);
			if (isRenderTask(task)) {
				this.notifyHighlightError(task, error);
				this.rejectRenderTaskCallbacks(task, normalizeWorkerError(error));
			} else if ("reject" in task) task.reject(error);
			this.cleanWorkerAndTask(managedWorker, task);
			if (this.queuedTasks.length > 0) this.queueDrain();
		}
		this.queueBroadcastStateChanges();
	}
	maybeAttachCustomExtensions(managedWorker, request) {
		if (request.customExtensionsVersion != null) return;
		const version = getCustomExtensionsVersion();
		if (managedWorker.customExtensionsVersion >= version) return;
		request.customExtensionsVersion = version;
		request.customExtensionMap = getCustomExtensionsMap();
	}
	syncCustomExtensionVersion(managedWorker, request) {
		if (request.customExtensionsVersion == null) return;
		managedWorker.customExtensionsVersion = request.customExtensionsVersion;
	}
	getAvailableWorker(langs) {
		let worker;
		for (const managedWorker of this.workers) {
			if (managedWorker.requestId != null || managedWorker.pendingSetupRequestId != null || !managedWorker.initialized) continue;
			worker = managedWorker;
			if (langs.length === 0) break;
			let hasEveryLang = true;
			for (const lang of langs) if (!managedWorker.langs.has(lang)) {
				hasEveryLang = false;
				break;
			}
			if (hasEveryLang) break;
		}
		return worker;
	}
	getFileHighlightKey(file) {
		if (file.cacheKey == null) return;
		return `file:${file.cacheKey}:${this.renderOptionsVersion}`;
	}
	getDiffHighlightKey(diff) {
		if (diff.cacheKey == null) return;
		return `diff:${diff.cacheKey}:${this.renderOptionsVersion}`;
	}
	getHighlightKeyForRequest(request) {
		switch (request.type) {
			case "file": return this.getFileHighlightKey(request.file);
			case "diff": return this.getDiffHighlightKey(request.diff);
		}
	}
	hasActiveRequest(task) {
		for (const instance of getInstances(task)) if (this.activeRequestByInstance.has(instance)) return true;
		return false;
	}
	addInstanceToTask(task, instance) {
		if (task.type === "file") task.instances.add(instance);
		else task.instances.add(instance);
		if (this.activeTaskById.has(task.id)) this.activeRequestByInstance.set(instance, task.id);
		else this.queuedTaskByInstance.set(instance, task);
	}
	detachInstanceFromQueuedTasks(instance, exceptTask) {
		const task = this.queuedTaskByInstance.get(instance);
		if (task == null || task === exceptTask) return;
		this.queuedTaskByInstance.delete(instance);
		this.detachInstanceFromRenderTask(task, instance);
		if (!task.primeCache && task.instances.size === 0) this.removeQueuedTask(task);
	}
	detachInstanceFromRenderTask(task, instance) {
		if (task.type === "file") task.instances.delete(instance);
		else task.instances.delete(instance);
	}
	removeQueuedTask(task) {
		const index = this.queuedTasks.indexOf(task);
		if (index !== -1) this.queuedTasks.splice(index, 1);
		this.rejectRenderTaskCallbacks(task, new WorkerPoolTaskCanceledError());
		this.clearQueuedInstanceRequests(task);
		this.clearHighlightKey(task);
	}
	removeActiveTask(task) {
		this.rejectRenderTaskCallbacks(task, new WorkerPoolTaskCanceledError());
		this.clearInstanceRequests(task);
		this.clearHighlightKey(task);
		this.activeTaskById.delete(task.id);
	}
	createRenderTaskCallbacks(task) {
		return new Promise((resolve, reject) => {
			task.callbacks.add({
				resolve,
				reject
			});
		});
	}
	resolveRenderTaskCallbacks(task) {
		for (const callbacks of task.callbacks) callbacks.resolve();
		task.callbacks.clear();
	}
	rejectRenderTaskCallbacks(task, error) {
		for (const callbacks of task.callbacks) callbacks.reject(error);
		task.callbacks.clear();
	}
	invalidateRenderTasks() {
		for (let index = this.queuedTasks.length - 1; index >= 0; index--) {
			const task = this.queuedTasks[index];
			if (task.renderOptionsVersion !== this.renderOptionsVersion) this.removeQueuedTask(task);
		}
		for (const task of Array.from(this.activeTaskById.values())) if (isRenderTask(task) && task.renderOptionsVersion !== this.renderOptionsVersion) this.removeActiveTask(task);
	}
	clearQueuedInstanceRequests(task) {
		for (const instance of getInstances(task)) if (this.queuedTaskByInstance.get(instance) === task) this.queuedTaskByInstance.delete(instance);
	}
	clearHighlightKey(task) {
		if (task.highlightKey != null && this.taskByHighlightKey.get(task.highlightKey) === task) this.taskByHighlightKey.delete(task.highlightKey);
	}
	trackInstanceRequests(task) {
		for (const instance of getInstances(task)) this.activeRequestByInstance.set(instance, task.id);
	}
	clearInstanceRequests(task) {
		for (const instance of getInstances(task)) if (this.activeRequestByInstance.get(instance) === task.id) this.activeRequestByInstance.delete(instance);
	}
	notifyFileInstances(task, result, options) {
		for (const instance of task.instances) if (this.activeRequestByInstance.get(instance) === task.id) instance.onHighlightSuccess(task.request.file, result, options);
	}
	notifyDiffInstances(task, result, options) {
		for (const instance of task.instances) if (this.activeRequestByInstance.get(instance) === task.id) instance.onHighlightSuccess(task.request.diff, result, options);
	}
	notifyHighlightError(task, error) {
		for (const instance of getInstances(task)) if (this.activeRequestByInstance.get(instance) === task.id) instance.onHighlightError(error);
	}
	hasMatchingFileInstanceTask(instance, file) {
		for (const task of this.iterateRenderTasks()) if (task.type === "file" && this.isCurrentRenderTask(task) && task.instances.has(instance) && areFilesEqual(file, task.request.file)) return true;
		return false;
	}
	hasMatchingDiffInstanceTask(instance, diff) {
		for (const task of this.iterateRenderTasks()) if (task.type === "diff" && this.isCurrentRenderTask(task) && task.instances.has(instance) && areDiffTargetsEqual(task.request.diff, diff)) return true;
		return false;
	}
	getTaskByHighlightKey(highlightKey) {
		const task = this.taskByHighlightKey.get(highlightKey);
		return task != null && this.isCurrentRenderTask(task) ? task : void 0;
	}
	isCurrentRenderTask(task) {
		return task.renderOptionsVersion === this.renderOptionsVersion;
	}
	*iterateRenderTasks() {
		for (const task of this.queuedTasks) yield task;
		for (const task of this.activeTaskById.values()) if (isRenderTask(task)) yield task;
	}
	generateRequestId() {
		return `req_${++this.nextRequestId}`;
	}
};
function shouldSyncCustomExtensions(request) {
	return request.type === "initialize" || request.type === "file" || request.type === "diff";
}
function getLangsFromTask(task) {
	const langs = /* @__PURE__ */ new Set();
	if (task.type === "initialize" || task.type === "set-render-options") return [];
	switch (task.type) {
		case "file":
			langs.add(task.request.file.lang ?? getFiletypeFromFileName(task.request.file.name));
			break;
		case "diff":
			langs.add(task.request.diff.lang ?? getFiletypeFromFileName(task.request.diff.name));
			langs.add(task.request.diff.lang ?? getFiletypeFromFileName(task.request.diff.prevName ?? "-"));
			break;
	}
	langs.delete("text");
	return Array.from(langs);
}
function isRenderTask(task) {
	return task?.type === "file" || task?.type === "diff";
}
function getInstances(task) {
	return task.instances;
}
function normalizeWorkerError(error) {
	return error instanceof Error ? error : new Error(String(error));
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/worker/getOrCreateWorkerPoolSingleton.js
var workerPoolSingleton;
function getOrCreateWorkerPoolSingleton({ poolOptions, highlighterOptions }) {
	workerPoolSingleton ??= new WorkerPoolManager(poolOptions, highlighterOptions);
	return workerPoolSingleton;
}
function terminateWorkerPoolSingleton() {
	if (workerPoolSingleton == null) return;
	workerPoolSingleton.terminate();
	workerPoolSingleton = void 0;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/WorkerPoolContext.js
var WorkerPoolContext = (0, import_react.createContext)(void 0);
var instanceCount = 0;
function WorkerPoolContextProvider({ children, poolOptions, highlighterOptions }) {
	const [poolManager] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return;
		return getOrCreateWorkerPoolSingleton({
			poolOptions,
			highlighterOptions
		});
	});
	(0, import_react.useInsertionEffect)(() => {
		if (poolManager != null) {
			instanceCount++;
			return () => {
				instanceCount--;
			};
		}
	}, [poolManager]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (instanceCount === 0) terminateWorkerPoolSingleton();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkerPoolContext.Provider, {
		value: poolManager,
		children
	});
}
function useWorkerPool() {
	return (0, import_react.useContext)(WorkerPoolContext);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/CodeView.js
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var useIsomorphicLayoutEffect$3 = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
function createDefaultCache(controlled) {
	return {
		instance: void 0,
		items: void 0,
		controlled,
		managedOptions: void 0,
		disableFlushSync: false,
		slotCoordinator: void 0
	};
}
function CodeViewInner(props, ref) {
	const { className, containerRef, disableWorkerPool = false, editorOptions, initialItems, items: controlledItems, onItemEditChange, onItemEditComplete, onScroll, onSelectedLinesChange, options, renderAnnotation, renderCodeViewFooter, renderCodeViewHeader, renderCustomHeader, renderGutterUtility, renderHeaderFilenameSuffix, renderHeaderMetadata, renderHeaderPrefix, selectedLines, style } = props;
	const controlled = controlledItems !== void 0;
	const contextCreateEditor = useCreateEditor();
	const poolManager = (0, import_react.useContext)(WorkerPoolContext);
	const cachedDataRef = (0, import_react.useRef)(createDefaultCache(controlled));
	const hasCustomHeader = renderCustomHeader != null;
	const hasAnnotationRenderer = renderAnnotation != null;
	const hasGutterRenderer = renderGutterUtility != null;
	const hasHeaderRenderers = hasCustomHeader || renderHeaderPrefix != null || renderHeaderFilenameSuffix != null || renderHeaderMetadata != null;
	const hasRenderers = hasHeaderRenderers || hasAnnotationRenderer || hasGutterRenderer;
	const hasCodeViewHeader = renderCodeViewHeader != null;
	const hasCodeViewFooter = renderCodeViewFooter != null;
	const emitSelectedLinesChange = useStableCallback((selection) => {
		onSelectedLinesChange?.(selection);
	});
	const controlledSelection = selectedLines !== void 0;
	const createEditor = useStableCallback((options) => {
		if (contextCreateEditor == null) throw new Error("CodeView: EditContext is not attached");
		const editor = contextCreateEditor({
			...editorOptions,
			...options
		});
		if (editor == null) throw new Error("CodeView: EditProvider.createEditor must return an editor instance");
		return editor;
	});
	const emitItemEditChange = useStableCallback((item, file, lineAnnotations) => {
		onItemEditChange?.(item, file, lineAnnotations);
	});
	const emitItemEditComplete = useStableCallback((item, file, lineAnnotations) => {
		onItemEditComplete?.(item, file, lineAnnotations);
	});
	const managedOptions = (0, import_react.useMemo)(() => createManagedCodeViewOptions({
		options,
		hasCustomHeader,
		hasGutterRenderer,
		hasCodeViewHeader,
		hasCodeViewFooter,
		onSelectedLinesChange: onSelectedLinesChange != null ? emitSelectedLinesChange : void 0,
		controlledSelection,
		createEditor: contextCreateEditor != null ? createEditor : void 0,
		onItemEditChange: onItemEditChange != null ? emitItemEditChange : void 0,
		onItemEditComplete: onItemEditComplete != null ? emitItemEditComplete : void 0
	}), [
		contextCreateEditor,
		controlledSelection,
		createEditor,
		emitItemEditChange,
		emitItemEditComplete,
		emitSelectedLinesChange,
		hasCodeViewFooter,
		hasCodeViewHeader,
		hasCustomHeader,
		hasGutterRenderer,
		onItemEditChange,
		onItemEditComplete,
		onSelectedLinesChange,
		options
	]);
	const [slotContentStore] = (0, import_react.useState)(() => createSlotContentStore());
	const [, forceUpdate] = (0, import_react.useState)({});
	const nodeRef = useStableCallback((node) => {
		if (cachedDataRef.current.instance != null && (node == null || node !== cachedDataRef.current.instance.getContainerElement())) {
			cachedDataRef.current.instance.cleanUp();
			slotContentStore.publish(void 0);
			cachedDataRef.current = createDefaultCache(controlled);
		}
		if (node != null && node !== cachedDataRef.current.instance?.getContainerElement()) {
			cachedDataRef.current.instance = new CodeView$1(managedOptions, !disableWorkerPool ? poolManager : void 0, true);
			cachedDataRef.current.instance.setup(node);
		}
		if (typeof containerRef === "function") containerRef(node);
		else if (containerRef != null) containerRef.current = node;
	});
	const onSnapshotChange = useStableCallback((snapshot) => {
		if (cachedDataRef.current.disableFlushSync) slotContentStore.publish(snapshot);
		else (0, import_react_dom.flushSync)(() => {
			slotContentStore.publish(snapshot);
		});
	});
	const slotCoordinator = (0, import_react.useMemo)(() => {
		if (!hasHeaderRenderers && !hasAnnotationRenderer && !hasGutterRenderer && !hasCodeViewHeader && !hasCodeViewFooter) return;
		else return {
			hasHeaderRenderers,
			hasAnnotationRenderer,
			hasGutterRenderer,
			onSnapshotChange
		};
	}, [
		onSnapshotChange,
		hasAnnotationRenderer,
		hasGutterRenderer,
		hasHeaderRenderers,
		hasCodeViewHeader,
		hasCodeViewFooter
	]);
	useIsomorphicLayoutEffect$3(() => {
		return onScroll != null ? cachedDataRef.current.instance?.subscribeToScroll(onScroll) : void 0;
	});
	useIsomorphicLayoutEffect$3(() => {
		const { instance, controlled: prevControlled, items: prevItems, managedOptions: prevManagedOptions, slotCoordinator: prevSlotCoordinator } = cachedDataRef.current;
		if (instance == null) return;
		try {
			cachedDataRef.current.disableFlushSync = true;
			let shouldRender = false;
			if (!areOptionsEqual(managedOptions, prevManagedOptions)) {
				cachedDataRef.current.managedOptions = managedOptions;
				instance.setOptions(managedOptions);
				shouldRender = true;
			}
			if (prevControlled !== controlled) {
				console.error("CodeView: cannot switch between controlled and uncontrolled modes. Remount with a new key instead.");
				return;
			}
			if (controlled) {
				if (controlledItems !== prevItems) if (areItemListsEqual(prevItems, controlledItems)) cachedDataRef.current.items = controlledItems;
				else if (isAppendOnlyItemUpdate(prevItems, controlledItems)) {
					cachedDataRef.current.items = controlledItems;
					instance.addItems(controlledItems.slice(prevItems.length));
				} else {
					cachedDataRef.current.items = controlledItems;
					instance.setItems(controlledItems);
					shouldRender = true;
				}
			} else if (prevItems == null) {
				const seedItems = initialItems ?? [];
				cachedDataRef.current.items = seedItems;
				if (seedItems.length > 0) {
					instance.setItems(seedItems);
					shouldRender = true;
				}
			}
			if (selectedLines !== void 0) instance.setSelectedLines(selectedLines, { notify: false });
			const slotPublish = instance.setSlotCoordinator(slotCoordinator);
			let forceInlinePublish = false;
			if (slotCoordinator !== prevSlotCoordinator) {
				if (slotCoordinator == null || prevSlotCoordinator == null) forceInlinePublish = true;
				cachedDataRef.current.slotCoordinator = slotCoordinator;
			}
			if (shouldRender || slotPublish) instance.render(true);
			if (slotPublish && slotCoordinator == null) slotContentStore.publish(void 0);
			if (forceInlinePublish) forceUpdate({});
		} finally {
			cachedDataRef.current.disableFlushSync = false;
		}
	});
	(0, import_react.useImperativeHandle)(ref, () => ({
		addItems(items) {
			const { controlled, instance } = cachedDataRef.current;
			assertUncontrolledCodeViewAction(controlled, "addItems");
			if (instance == null) console.error("CodeView.addItems: no valid instance to append items with", items);
			else instance.addItems(items);
		},
		getItem(id) {
			const { instance } = cachedDataRef.current;
			if (instance == null) {
				console.error("CodeView.getItem: no valid instance exists", id);
				return;
			} else return instance.getItem(id);
		},
		removeItem(id) {
			const { controlled, instance } = cachedDataRef.current;
			assertUncontrolledCodeViewAction(controlled, "removeItem");
			if (instance == null) {
				console.error("CodeView.removeItem: no valid instance to remove item from", id);
				return false;
			}
			return instance.removeItem(id);
		},
		updateItem(item) {
			const { controlled, instance } = cachedDataRef.current;
			assertUncontrolledCodeViewAction(controlled, "updateItem");
			if (instance == null) {
				console.error("CodeView.updateItem: no valid instance to update item with", item);
				return false;
			}
			return instance.updateItem(item);
		},
		updateItemId(oldId, newId) {
			const { controlled, instance } = cachedDataRef.current;
			assertUncontrolledCodeViewAction(controlled, "updateItemId");
			if (instance == null) {
				console.error("CodeView.updateItemId: no valid instance to update item id with", oldId, newId);
				return false;
			}
			return instance.updateItemId(oldId, newId);
		},
		scrollTo(target) {
			const { instance } = cachedDataRef.current;
			if (instance == null) console.error("CodeView.scrollTo: no valid instance to scroll with", target);
			else instance.scrollTo(target);
		},
		setSelectedLines(selection) {
			const { instance } = cachedDataRef.current;
			if (instance == null) console.error("CodeView.setSelectedLines: no valid instance to update selection with", selection);
			else {
				instance.setSelectedLines(selection, { notify: false });
				emitSelectedLinesChange(selection);
			}
		},
		getSelectedLines() {
			const { instance } = cachedDataRef.current;
			if (instance == null) {
				console.error("CodeView.getSelectedLines: no valid instance exists");
				return null;
			} else return instance.getSelectedLines();
		},
		clearSelectedLines() {
			const { instance } = cachedDataRef.current;
			if (instance == null) console.error("CodeView.clearSelectedLines: no valid instance to update selection with");
			else {
				instance.clearSelectedLines({ notify: false });
				emitSelectedLinesChange(null);
			}
		},
		getEditor(id) {
			const { instance } = cachedDataRef.current;
			if (instance == null) {
				console.error("CodeView.getEditor: no valid instance exists", id);
				return;
			}
			return instance.getEditor(id);
		},
		getInstance() {
			return cachedDataRef.current.instance;
		}
	}), [emitSelectedLinesChange]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: nodeRef,
		className,
		style
	}), (hasRenderers || hasCodeViewHeader || hasCodeViewFooter) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlotPortals, {
		managedContentStore: slotContentStore,
		renderCustomHeader,
		renderHeaderPrefix,
		renderHeaderFilenameSuffix,
		renderHeaderMetadata,
		renderAnnotation,
		renderGutterUtility,
		renderCodeViewHeader,
		renderCodeViewFooter
	})] });
}
var CodeView = (0, import_react.forwardRef)(CodeViewInner);
function isAppendOnlyItemUpdate(previousItems, nextItems) {
	if (previousItems == null || nextItems.length <= previousItems.length) return false;
	if (previousItems.length === 0) return true;
	for (let index = 0; index < previousItems.length; index++) if (nextItems[index] !== previousItems[index]) return false;
	return true;
}
function areItemListsEqual(previousItems, nextItems) {
	if (previousItems == null || previousItems.length !== nextItems.length) return false;
	for (let index = 0; index < previousItems.length; index++) if (previousItems[index] !== nextItems[index]) return false;
	return true;
}
function assertUncontrolledCodeViewAction(controlled, action) {
	if (!controlled) return;
	throw new Error(`CodeView.${action} cannot be used when CodeView is controlled. Use initialItems for imperative item updates.`);
}
function createSlotContentStore() {
	let snapshot;
	const listeners = /* @__PURE__ */ new Set();
	return {
		getSnapshot() {
			return snapshot;
		},
		publish(nextSnapshot) {
			if (areManagedSnapshotsEqual(snapshot, nextSnapshot)) return;
			snapshot = nextSnapshot;
			for (const listener of listeners) listener();
		},
		subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		}
	};
}
function createManagedCodeViewOptions({ options, hasCustomHeader, hasGutterRenderer, hasCodeViewHeader, hasCodeViewFooter, onSelectedLinesChange, controlledSelection, createEditor, onItemEditChange, onItemEditComplete }) {
	const managedOptions = {
		...options,
		controlledSelection,
		onSelectedLinesChange,
		createEditor
	};
	if (onItemEditChange != null) managedOptions.onItemEditChange = onItemEditChange;
	if (onItemEditComplete != null) managedOptions.onItemEditComplete = onItemEditComplete;
	if (hasCustomHeader) managedOptions.renderCustomHeader = noopRender$1;
	if (hasGutterRenderer) managedOptions.renderGutterUtility = noopRender$1;
	if (hasCodeViewHeader) managedOptions.renderCodeViewHeader = noopRender$1;
	if (hasCodeViewFooter) managedOptions.renderCodeViewFooter = noopRender$1;
	return managedOptions;
}
var SlotPortals = (0, import_react.memo)(function SlotPortals({ managedContentStore, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderAnnotation, renderGutterUtility, renderCodeViewHeader, renderCodeViewFooter }) {
	"use no memo";
	const subscribe = useStableCallback((listener) => managedContentStore.subscribe(listener));
	const getSnapshot = useStableCallback(() => managedContentStore.getSnapshot());
	const snapshot = (0, import_react.useSyncExternalStore)(subscribe, getSnapshot, getSnapshot);
	let itemKeys = "";
	for (const item of snapshot?.items ?? []) itemKeys += `${item.id}:${item.version}:${item.type}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_react.useMemo)(() => {
			return snapshot?.items?.map((renderedItem) => (0, import_react_dom.createPortal)(renderCodeViewItemChildren({
				renderedItem,
				renderCustomHeader,
				renderHeaderPrefix,
				renderHeaderFilenameSuffix,
				renderHeaderMetadata,
				renderAnnotation,
				renderGutterUtility
			}), renderedItem.element, renderedItem.id));
		}, [
			renderCustomHeader,
			renderHeaderPrefix,
			renderHeaderFilenameSuffix,
			renderHeaderMetadata,
			renderAnnotation,
			renderGutterUtility,
			itemKeys
		]),
		(0, import_react.useMemo)(() => {
			return renderCodeViewHeader != null && snapshot?.header != null ? (0, import_react_dom.createPortal)(renderCodeViewHeader(), snapshot.header) : null;
		}, [renderCodeViewHeader, snapshot?.header]),
		(0, import_react.useMemo)(() => {
			return renderCodeViewFooter != null && snapshot?.footer != null ? (0, import_react_dom.createPortal)(renderCodeViewFooter(), snapshot.footer) : null;
		}, [renderCodeViewFooter, snapshot?.footer])
	] });
});
function renderCodeViewItemChildren({ renderedItem, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderAnnotation, renderGutterUtility }) {
	if (renderedItem.type === "diff") {
		const { item, instance } = renderedItem;
		return renderDiffChildren({
			fileDiff: item.fileDiff,
			renderCustomHeader: renderCustomHeader != null ? () => renderCustomHeader(item) : void 0,
			renderHeaderPrefix: renderHeaderPrefix != null ? () => renderHeaderPrefix(item) : void 0,
			renderHeaderFilenameSuffix: renderHeaderFilenameSuffix != null ? () => renderHeaderFilenameSuffix(item) : void 0,
			renderHeaderMetadata: renderHeaderMetadata != null ? () => renderHeaderMetadata(item) : void 0,
			renderAnnotation: renderAnnotation != null ? (annotation) => renderAnnotation(annotation, item) : void 0,
			lineAnnotations: item.annotations,
			renderGutterUtility: renderGutterUtility != null ? (getHoveredLine) => renderGutterUtility(getHoveredLine, item) : void 0,
			getHoveredLine: instance.getHoveredLine
		});
	} else {
		const { item, instance } = renderedItem;
		return renderFileChildren({
			file: item.file,
			renderCustomHeader: renderCustomHeader != null ? () => renderCustomHeader(item) : void 0,
			renderHeaderPrefix: renderHeaderPrefix != null ? () => renderHeaderPrefix(item) : void 0,
			renderHeaderFilenameSuffix: renderHeaderFilenameSuffix != null ? () => renderHeaderFilenameSuffix(item) : void 0,
			renderHeaderMetadata: renderHeaderMetadata != null ? () => renderHeaderMetadata(item) : void 0,
			renderAnnotation: renderAnnotation != null ? (annotation) => renderAnnotation(annotation, item) : void 0,
			lineAnnotations: item.annotations,
			renderGutterUtility: renderGutterUtility != null ? (getHoveredLine) => renderGutterUtility(getHoveredLine, item) : void 0,
			getHoveredLine: instance.getHoveredLine
		});
	}
}
function noopRender$1() {}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/templateRender.js
function templateRender(children, __html) {
	if (typeof window === "undefined" && __html != null) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("template", {
		shadowrootmode: "open",
		dangerouslySetInnerHTML: { __html }
	}), children] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/Virtualizer.js
var VirtualizerContext = (0, import_react.createContext)(void 0);
function Virtualizer({ children, config, className, style, contentClassName, contentStyle }) {
	const [instance] = (0, import_react.useState)(() => {
		return typeof window !== "undefined" ? new Virtualizer$1(config) : void 0;
	});
	const ref = (0, import_react.useCallback)((node) => {
		if (node != null) instance?.setup(node);
		else instance?.cleanUp();
	}, [instance]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VirtualizerContext.Provider, {
		value: instance,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className,
			style,
			ref,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: contentClassName,
				style: contentStyle,
				children
			})
		})
	});
}
function useVirtualizer() {
	return (0, import_react.useContext)(VirtualizerContext);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/useFileInstance.js
var useIsomorphicLayoutEffect$2 = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
function useFileInstance({ file, options, editorOptions, lineAnnotations, selectedLines, prerenderedHTML, metrics, hasGutterRenderUtility, hasCustomHeader, disableWorkerPool, edit }) {
	const simpleVirtualizer = useVirtualizer();
	const controlledSelection = selectedLines !== void 0;
	const poolManager = (0, import_react.useContext)(WorkerPoolContext);
	const createEditor = useCreateEditor();
	const instanceRef = (0, import_react.useRef)(null);
	const ref = useStableCallback((node) => {
		if (node != null) {
			if (instanceRef.current != null) throw new Error("File: An instance should not already exist when a node is created");
			if (simpleVirtualizer != null) instanceRef.current = new VirtualizedFile(mergeFileOptions({
				controlledSelection,
				hasCustomHeader,
				hasGutterRenderUtility,
				options
			}), simpleVirtualizer, metrics, !disableWorkerPool ? poolManager : void 0, true);
			else instanceRef.current = new File$1(mergeFileOptions({
				controlledSelection,
				hasCustomHeader,
				hasGutterRenderUtility,
				options
			}), !disableWorkerPool ? poolManager : void 0, true);
			instanceRef.current.hydrate({
				file,
				fileContainer: node,
				lineAnnotations,
				prerenderedHTML
			});
		} else {
			if (instanceRef.current == null) throw new Error("File: A File instance should exist when unmounting");
			instanceRef.current.cleanUp();
			instanceRef.current = null;
		}
	});
	useIsomorphicLayoutEffect$2(() => {
		if (instanceRef.current == null) return;
		const newOptions = mergeFileOptions({
			controlledSelection,
			hasCustomHeader,
			hasGutterRenderUtility,
			options
		});
		const forceRender = newOptions !== void 0 && !areOptionsEqual(instanceRef.current.options, newOptions);
		instanceRef.current.setOptions(newOptions);
		instanceRef.current.render({
			file,
			lineAnnotations,
			forceRender
		});
		if (selectedLines !== void 0) instanceRef.current.setSelectedLines(selectedLines);
	});
	useIsomorphicLayoutEffect$2(() => {
		if (edit && instanceRef.current != null) {
			if (createEditor === void 0) throw new Error("File: EditContext is not attached");
			const editor = createEditor(editorOptions ?? {});
			if (editor == null) throw new Error("File: EditProvider.createEditor must return an editor instance");
			try {
				return editor.edit(instanceRef.current);
			} catch (error) {
				editor.cleanUp();
				throw error;
			}
		}
	}, [edit]);
	return {
		ref,
		getHoveredLine: (0, import_react.useCallback)(() => {
			return instanceRef.current?.getHoveredLine();
		}, [])
	};
}
function mergeFileOptions({ options, controlledSelection, hasCustomHeader, hasGutterRenderUtility }) {
	if (!(controlledSelection || hasGutterRenderUtility || hasCustomHeader)) return options;
	return {
		...options,
		controlledSelection,
		renderCustomHeader: hasCustomHeader ? noopRender : options?.renderCustomHeader,
		renderGutterUtility: hasGutterRenderUtility ? noopRender : options?.renderGutterUtility
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/File.js
function File({ file, lineAnnotations, selectedLines, options, editorOptions, metrics, className, style, renderAnnotation, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, prerenderedHTML, renderGutterUtility, disableWorkerPool = false, edit = false }) {
	const { ref, getHoveredLine } = useFileInstance({
		file,
		options,
		editorOptions,
		metrics,
		lineAnnotations,
		selectedLines,
		prerenderedHTML,
		hasGutterRenderUtility: renderGutterUtility != null,
		hasCustomHeader: renderCustomHeader != null,
		disableWorkerPool,
		edit
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DIFFS_TAG_NAME, {
		ref,
		className,
		style,
		children: templateRender(renderFileChildren({
			file,
			renderAnnotation,
			renderCustomHeader,
			renderHeaderPrefix,
			renderHeaderFilenameSuffix,
			renderHeaderMetadata,
			renderGutterUtility,
			lineAnnotations,
			getHoveredLine
		}), prerenderedHTML)
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/useFileDiffInstance.js
var useIsomorphicLayoutEffect$1 = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
function useFileDiffInstance({ fileDiff, options, editorOptions, lineAnnotations, selectedLines, prerenderedHTML, metrics, hasGutterRenderUtility, hasCustomHeader, disableWorkerPool, edit }) {
	const simpleVirtualizer = useVirtualizer();
	const controlledSelection = selectedLines !== void 0;
	const poolManager = (0, import_react.useContext)(WorkerPoolContext);
	const createEditor = useCreateEditor();
	const instanceRef = (0, import_react.useRef)(null);
	const ref = useStableCallback((fileContainer) => {
		if (fileContainer != null) {
			if (instanceRef.current != null) throw new Error("useFileDiffInstance: An instance should not already exist when a node is created");
			if (simpleVirtualizer != null) instanceRef.current = new VirtualizedFileDiff(mergeFileDiffOptions({
				controlledSelection,
				hasCustomHeader,
				hasGutterRenderUtility,
				options
			}), simpleVirtualizer, metrics, !disableWorkerPool ? poolManager : void 0, true);
			else instanceRef.current = new FileDiff$1(mergeFileDiffOptions({
				controlledSelection,
				hasCustomHeader,
				hasGutterRenderUtility,
				options
			}), !disableWorkerPool ? poolManager : void 0, true);
			instanceRef.current.hydrate({
				fileDiff,
				fileContainer,
				lineAnnotations,
				prerenderedHTML
			});
		} else {
			if (instanceRef.current == null) throw new Error("useFileDiffInstance: A FileDiff instance should exist when unmounting");
			instanceRef.current.cleanUp();
			instanceRef.current = null;
		}
	});
	useIsomorphicLayoutEffect$1(() => {
		const { current: instance } = instanceRef;
		if (instance == null) return;
		const newOptions = mergeFileDiffOptions({
			controlledSelection,
			hasCustomHeader,
			hasGutterRenderUtility,
			options
		});
		const forceRender = newOptions !== void 0 && !areOptionsEqual(instance.options, newOptions);
		instance.setOptions(newOptions);
		instance.render({
			forceRender,
			fileDiff,
			lineAnnotations
		});
		if (selectedLines !== void 0) instance.setSelectedLines(selectedLines);
	});
	useIsomorphicLayoutEffect$1(() => {
		if (edit && instanceRef.current != null) {
			if (createEditor === void 0) throw new Error("FileDiff: EditContext is not attached");
			const editor = createEditor(editorOptions ?? {});
			if (editor == null) throw new Error("FileDiff: EditProvider.createEditor must return an editor instance");
			try {
				return editor.edit(instanceRef.current);
			} catch (error) {
				editor.cleanUp();
				throw error;
			}
		}
	}, [edit]);
	return {
		ref,
		getHoveredLine: (0, import_react.useCallback)(() => {
			return instanceRef.current?.getHoveredLine();
		}, [])
	};
}
function mergeFileDiffOptions({ options, controlledSelection, hasCustomHeader, hasGutterRenderUtility }) {
	if (!(controlledSelection || hasGutterRenderUtility || hasCustomHeader)) return options;
	return {
		...options,
		controlledSelection,
		renderCustomHeader: hasCustomHeader ? noopRender : options?.renderCustomHeader,
		renderGutterUtility: hasGutterRenderUtility ? noopRender : options?.renderGutterUtility
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/FileDiff.js
function FileDiff({ fileDiff, options, editorOptions, metrics, lineAnnotations, selectedLines, className, style, prerenderedHTML, renderAnnotation, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderGutterUtility, disableWorkerPool = false, edit = false }) {
	const { ref, getHoveredLine } = useFileDiffInstance({
		fileDiff,
		options,
		editorOptions,
		metrics,
		lineAnnotations,
		selectedLines,
		prerenderedHTML,
		hasGutterRenderUtility: renderGutterUtility != null,
		hasCustomHeader: renderCustomHeader != null,
		disableWorkerPool,
		edit
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DIFFS_TAG_NAME, {
		ref,
		className,
		style,
		children: templateRender(renderDiffChildren({
			fileDiff,
			renderCustomHeader,
			renderHeaderPrefix,
			renderHeaderFilenameSuffix,
			renderHeaderMetadata,
			renderAnnotation,
			renderGutterUtility,
			lineAnnotations,
			getHoveredLine
		}), prerenderedHTML)
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/MultiFileDiff.js
function MultiFileDiff({ oldFile, newFile, options, editorOptions, metrics, lineAnnotations, selectedLines, className, style, prerenderedHTML, renderAnnotation, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderGutterUtility, disableWorkerPool = false, edit = false }) {
	const fileDiff = (0, import_react.useMemo)(() => {
		return parseDiffFromFile(oldFile, newFile, options?.parseDiffOptions);
	}, [
		oldFile,
		newFile,
		options?.parseDiffOptions
	]);
	const { ref, getHoveredLine } = useFileDiffInstance({
		fileDiff,
		options,
		editorOptions,
		metrics,
		lineAnnotations,
		selectedLines,
		prerenderedHTML,
		hasGutterRenderUtility: renderGutterUtility != null,
		hasCustomHeader: renderCustomHeader != null,
		disableWorkerPool,
		edit
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DIFFS_TAG_NAME, {
		ref,
		className,
		style,
		children: templateRender(renderDiffChildren({
			fileDiff,
			renderCustomHeader,
			renderHeaderPrefix,
			renderHeaderFilenameSuffix,
			renderHeaderMetadata,
			renderAnnotation,
			lineAnnotations,
			renderGutterUtility,
			getHoveredLine
		}), prerenderedHTML)
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/PatchDiff.js
function PatchDiff({ patch, options, editorOptions, metrics, lineAnnotations, selectedLines, className, style, prerenderedHTML, renderAnnotation, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderGutterUtility, disableWorkerPool = false, edit = false }) {
	const fileDiff = usePatch(patch);
	const { ref, getHoveredLine } = useFileDiffInstance({
		fileDiff,
		options,
		editorOptions,
		metrics,
		lineAnnotations,
		selectedLines,
		prerenderedHTML,
		hasGutterRenderUtility: renderGutterUtility != null,
		hasCustomHeader: renderCustomHeader != null,
		disableWorkerPool,
		edit
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DIFFS_TAG_NAME, {
		ref,
		className,
		style,
		children: templateRender(renderDiffChildren({
			fileDiff,
			renderCustomHeader,
			renderHeaderPrefix,
			renderHeaderFilenameSuffix,
			renderHeaderMetadata,
			renderAnnotation,
			lineAnnotations,
			renderGutterUtility,
			getHoveredLine
		}), prerenderedHTML)
	});
}
function usePatch(patch) {
	return (0, import_react.useMemo)(() => getSingularPatch(patch), [patch]);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/utils/useUnresolvedFileInstance.js
var useIsomorphicLayoutEffect = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
function useUnresolvedFileInstance({ file, options, lineAnnotations, selectedLines, prerenderedHTML, hasConflictUtility, hasGutterRenderUtility, hasCustomHeader, disableWorkerPool }) {
	const [{ fileDiff, actions, markerRows }, setState] = (0, import_react.useState)(() => {
		const { fileDiff, actions, markerRows } = parseMergeConflictDiffFromFile(file, options?.maxContextLines);
		return {
			fileDiff,
			actions,
			markerRows
		};
	});
	const onMergeConflictAction = useStableCallback((payload, instance) => {
		setState((prevState) => {
			const { fileDiff, actions, markerRows } = instance.resolveConflict(payload.conflict.conflictIndex, payload.resolution, prevState.fileDiff) ?? {};
			if (fileDiff == null || actions == null || markerRows == null) return prevState;
			else return {
				fileDiff,
				actions,
				markerRows
			};
		});
	});
	const controlledSelection = selectedLines !== void 0;
	const poolManager = (0, import_react.useContext)(WorkerPoolContext);
	const instanceRef = (0, import_react.useRef)(null);
	const ref = useStableCallback((fileContainer) => {
		if (fileContainer != null) {
			if (instanceRef.current != null) throw new Error("useUnresolvedFileInstance: An instance should not already exist when a node is created");
			instanceRef.current = new UnresolvedFile$1(mergeUnresolvedOptions({
				controlledSelection,
				hasConflictUtility,
				hasCustomHeader,
				hasGutterRenderUtility,
				onMergeConflictAction,
				options
			}), !disableWorkerPool ? poolManager : void 0, true);
			instanceRef.current.hydrate({
				fileDiff,
				actions,
				markerRows,
				fileContainer,
				lineAnnotations,
				prerenderedHTML
			});
		} else {
			if (instanceRef.current == null) throw new Error("useUnresolvedFileInstance: A UnresolvedFile instance should exist when unmounting");
			instanceRef.current.cleanUp();
			instanceRef.current = null;
		}
	});
	useIsomorphicLayoutEffect(() => {
		if (instanceRef.current == null) return;
		const instance = instanceRef.current;
		const newOptions = mergeUnresolvedOptions({
			controlledSelection,
			hasConflictUtility,
			hasCustomHeader,
			hasGutterRenderUtility,
			onMergeConflictAction,
			options
		});
		const forceRender = newOptions !== void 0 && !areOptionsEqual(instance.options, newOptions);
		instance.setOptions(newOptions);
		instance.render({
			fileDiff,
			actions,
			markerRows,
			lineAnnotations,
			forceRender
		});
		if (selectedLines !== void 0) instance.setSelectedLines(selectedLines);
	});
	return {
		ref,
		getHoveredLine: (0, import_react.useCallback)(() => {
			return instanceRef.current?.getHoveredLine();
		}, []),
		fileDiff,
		actions,
		markerRows,
		getInstance: (0, import_react.useCallback)(() => {
			return instanceRef.current ?? void 0;
		}, [])
	};
}
function mergeUnresolvedOptions({ options, controlledSelection, onMergeConflictAction, hasConflictUtility, hasCustomHeader, hasGutterRenderUtility }) {
	return {
		...options,
		controlledSelection,
		onMergeConflictAction,
		hunkSeparators: options?.hunkSeparators === "custom" ? noopRender : options?.hunkSeparators,
		mergeConflictActionsType: hasConflictUtility || options?.mergeConflictActionsType === "custom" ? noopRender : options?.mergeConflictActionsType,
		renderCustomHeader: hasCustomHeader ? noopRender : void 0,
		renderGutterUtility: hasGutterRenderUtility ? noopRender : void 0
	};
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/react/UnresolvedFile.js
function UnresolvedFile({ file, options, lineAnnotations, selectedLines, className, style, prerenderedHTML, renderAnnotation, renderCustomHeader, renderHeaderPrefix, renderHeaderFilenameSuffix, renderHeaderMetadata, renderGutterUtility, renderMergeConflictUtility, disableWorkerPool = false }) {
	const { ref, getHoveredLine, fileDiff, actions, getInstance } = useUnresolvedFileInstance({
		file,
		options,
		lineAnnotations,
		selectedLines,
		prerenderedHTML,
		hasConflictUtility: renderMergeConflictUtility != null,
		hasGutterRenderUtility: renderGutterUtility != null,
		hasCustomHeader: renderCustomHeader != null,
		disableWorkerPool
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DIFFS_TAG_NAME, {
		ref,
		className,
		style,
		children: templateRender(renderDiffChildren({
			fileDiff,
			renderCustomHeader,
			renderHeaderPrefix,
			renderHeaderFilenameSuffix,
			renderHeaderMetadata,
			renderAnnotation,
			renderGutterUtility,
			lineAnnotations,
			getHoveredLine,
			actions,
			renderMergeConflictUtility,
			getInstance
		}), prerenderedHTML)
	});
}
//#endregion
export { CodeView, EditContext, EditProvider, File, FileDiff, GutterUtilitySlotStyles, MergeConflictSlotStyles, MultiFileDiff, PatchDiff, UnresolvedFile, Virtualizer, VirtualizerContext, WorkerPoolContext, WorkerPoolContextProvider, noopRender, renderDiffChildren, renderFileChildren, templateRender, useCreateEditor, useFileDiffInstance, useFileInstance, useStableCallback, useVirtualizer, useWorkerPool };
