import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { useLexicalComposerContext } from "./@lexical_react_LexicalComposerContext.js";
import "./lexical.js";
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalOnChangePlugin.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var useLayoutEffectImpl = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function OnChangePlugin({ ignoreHistoryMergeTagChange = true, ignoreSelectionChange = false, onChange }) {
	const [editor] = useLexicalComposerContext();
	useLayoutEffectImpl(() => {
		if (onChange) return editor.registerUpdateListener(({ editorState, dirtyElements, dirtyLeaves, prevEditorState, tags }) => {
			if (ignoreSelectionChange && dirtyElements.size === 0 && dirtyLeaves.size === 0 || ignoreHistoryMergeTagChange && tags.has("history-merge") || prevEditorState.isEmpty()) return;
			onChange(editorState, editor, tags);
		});
	}, [
		editor,
		ignoreHistoryMergeTagChange,
		ignoreSelectionChange,
		onChange
	]);
	return null;
}
//#endregion
export { OnChangePlugin };
