import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { shallow } from "./zustand_vanilla_shallow.js";
//#region node_modules/.bun/zustand@5.0.12+10f197a4cef36846/node_modules/zustand/esm/react/shallow.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function useShallow(selector) {
	const prev = import_react.useRef(void 0);
	return (state) => {
		const next = selector(state);
		return shallow(prev.current, next) ? prev.current : prev.current = next;
	};
}
//#endregion
export { useShallow };
