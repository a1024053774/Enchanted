//#region node_modules/.bun/@base-ui+utils@0.3.2+0ea9ec2a211d4613/node_modules/@base-ui/utils/error.mjs
var set = /* @__PURE__ */ new Set();
function error(...messages) {
	{
		const messageKey = messages.join(" ");
		if (!set.has(messageKey)) {
			set.add(messageKey);
			console.error(`Base UI: ${messageKey}`);
		}
	}
}
//#endregion
export { error as t };
