import { i as __toESM, n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { C as useIsoLayoutEffect, m as isElement } from "./useId-Cfrl5XdH.js";
import { D as POPUP_COLLISION_AVOIDANCE, a as triggerOpenStateMapping, c as ReactStore, d as fastComponent, f as fastComponentRef, h as useFloatingNodeId, m as FloatingTree, n as popupStateMapping, o as PopupTriggerMap, p as FloatingNode, r as popupTransitionStateMapping } from "./inertValue-C-bH78NQ.js";
import { t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { a as useHoverFloatingInteraction, i as useHoverReferenceInteraction, n as usePopupViewport, r as safePolygon, t as popupViewportStateMapping } from "./usePopupViewport-uDjiA0hf.js";
import { d as imperativeAction, t as createChangeEventDetails } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { c as useOpenStateTransitions, f as useTriggerDataForwarding, h as useDismiss, l as usePopupInteractionProps, n as PopupHandleAttachment, r as applyPopupOpenChange, s as useImplicitActiveTrigger, t as FOCUSABLE_POPUP_PROPS, u as usePopupRootStore } from "./popupStoreUtils-ULj3E1ul.js";
import { r as useOpenChangeComplete } from "./stateAttributesMapping-DKWbKMwM.js";
import { n as getDisabledMountTransitionStyles, r as useAnchorPositioning, t as usePositioner } from "./usePositioner-CXpcG81q.js";
import { a as popupStoreSelectors, i as createPopupFloatingRootContext, n as usePopupHandleStore, o as BasePopupHandle, r as createInitialPopupStoreState, t as NullStore } from "./NullStore-QQXJ83gy.js";
import { t as useFocus } from "./useFocus-CE3vxHes.js";
import { t as useBaseUiId } from "./useBaseUiId-BBG3KkG2.js";
import { t as FloatingPortalLite } from "./FloatingPortalLite-DyrzMru0.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/popups/inlineRect.mjs
function createRect(left, top, right, bottom) {
	return {
		left,
		top,
		right,
		bottom,
		x: left,
		y: top,
		width: right - left,
		height: bottom - top
	};
}
function copyRect(rect) {
	return {
		left: rect.left,
		top: rect.top,
		right: rect.right,
		bottom: rect.bottom,
		width: rect.width,
		height: rect.height
	};
}
function getLineRects(rects) {
	const lines = [];
	let previousRect;
	let left = Number.POSITIVE_INFINITY;
	let top = Number.POSITIVE_INFINITY;
	let right = Number.NEGATIVE_INFINITY;
	let bottom = Number.NEGATIVE_INFINITY;
	for (const rect of Array.from(rects).sort((a, b) => a.top - b.top)) {
		left = Math.min(left, rect.left);
		top = Math.min(top, rect.top);
		right = Math.max(right, rect.right);
		bottom = Math.max(bottom, rect.bottom);
		if (!previousRect || rect.top - previousRect.top > previousRect.height / 2) lines.push(copyRect(rect));
		else {
			const line = lines[lines.length - 1];
			line.left = Math.min(line.left, rect.left);
			line.right = Math.max(line.right, rect.right);
			line.bottom = Math.max(line.bottom, rect.bottom);
			line.width = line.right - line.left;
			line.height = line.bottom - line.top;
		}
		previousRect = rect;
	}
	return {
		lines,
		fallback: createRect(left, top, right, bottom)
	};
}
function findLineIndex(lines, x, y) {
	return lines.findIndex((lineRect) => x > lineRect.left - 2 && x < lineRect.right + 2 && y > lineRect.top - 2 && y < lineRect.bottom + 2);
}
function createClientRect(rect) {
	return createRect(rect.left, rect.top, rect.right, rect.bottom);
}
function getInlineRectCoords(element, clientX, clientY) {
	const { lines } = getLineRects(element.getClientRects());
	if (lines.length < 2) return;
	const lineIndex = findLineIndex(lines, clientX, clientY);
	return {
		x: clientX,
		y: clientY,
		lineIndex: lineIndex === -1 ? void 0 : lineIndex,
		element
	};
}
function getInlineReferenceRect(reference, placement, coords) {
	const { lines, fallback } = getLineRects(reference.getClientRects());
	if (lines.length < 2) return null;
	const x = coords?.x;
	const y = coords?.y;
	const side = placement[0];
	if (coords?.lineIndex != null && lines[coords.lineIndex]) return createClientRect(lines[coords.lineIndex]);
	if (x != null && y != null) {
		const lineIndex = findLineIndex(lines, x, y);
		if (lineIndex !== -1) return createClientRect(lines[lineIndex]);
	}
	if (lines.length === 2 && lines[0].left > lines[1].right && x != null && y != null) return fallback;
	if (side === "t" || side === "b") {
		const firstRect = lines[0];
		const lastRect = lines[lines.length - 1];
		const targetRect = side === "t" ? firstRect : lastRect;
		return createRect(targetRect.left, firstRect.top, targetRect.right, lastRect.bottom);
	}
	const isLeft = side === "l";
	let left = lines[0].left;
	let right = lines[0].right;
	let edge = isLeft ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
	let targetFirstRect = lines[0];
	let targetLastRect = lines[0];
	for (const rect of lines) {
		left = Math.min(left, rect.left);
		right = Math.max(right, rect.right);
		const nextEdge = isLeft ? rect.left : rect.right;
		if (isLeft && nextEdge < edge || !isLeft && nextEdge > edge) {
			edge = nextEdge;
			targetFirstRect = rect;
			targetLastRect = rect;
		} else if (nextEdge === edge) targetLastRect = rect;
	}
	return createRect(left, targetFirstRect.top, right, targetLastRect.bottom);
}
function getContextElement(reference) {
	if ("contextElement" in reference && reference.contextElement) return reference.contextElement;
	return isElement(reference) ? reference : void 0;
}
function getInlineRectTriggerProps(coordsRef, isOpen) {
	function updateCoords(event) {
		updateInlineRectCoords(coordsRef, event.currentTarget, event.clientX, event.clientY);
	}
	function updateCoordsIfClosed(event) {
		if (!isOpen) updateCoords(event);
	}
	return {
		onFocus() {
			coordsRef.current = void 0;
		},
		onMouseEnter: updateCoordsIfClosed,
		onMouseMove: updateCoordsIfClosed
	};
}
function updateInlineRectCoords(coordsRef, element, clientX, clientY) {
	const nextCoords = getInlineRectCoords(element, clientX, clientY);
	coordsRef.current = nextCoords;
	return nextCoords;
}
function createInlineMiddleware(coordsRef) {
	return {
		name: "inline",
		async fn(state) {
			const reference = state.elements.reference;
			if (typeof reference?.getClientRects !== "function") return {};
			const contextElement = getContextElement(reference);
			const coords = coordsRef.current;
			const currentCoords = coords?.element === reference || coords?.element === contextElement ? coords : void 0;
			const rect = getInlineReferenceRect(reference, state.placement, currentCoords);
			if (!rect || typeof state.platform.getElementRects !== "function") return {};
			const resetRects = await state.platform.getElementRects({
				reference: {
					contextElement,
					getBoundingClientRect() {
						return rect;
					}
				},
				floating: state.elements.floating,
				strategy: state.strategy
			});
			if (state.rects.reference.x === resetRects.reference.x && state.rects.reference.y === resetRects.reference.y && state.rects.reference.width === resetRects.reference.width && state.rects.reference.height === resetRects.reference.height) return {};
			return { reset: { rects: resetRects } };
		}
	};
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/root/PreviewCardContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var PreviewCardRootContext = /*#__PURE__*/ import_react.createContext(void 0);
PreviewCardRootContext.displayName = "PreviewCardRootContext";
function usePreviewCardRootContext(optional) {
	const context = import_react.useContext(PreviewCardRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: PreviewCardRootContext is missing. PreviewCard parts must be placed within <PreviewCard.Root>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/store/PreviewCardStore.mjs
var selectors = {
	...popupStoreSelectors,
	instantType: (state) => state.instantType,
	adaptiveOrigin: (state) => state.adaptiveOrigin,
	closeDelay: (state) => state.closeDelay
};
/**
* The store view that detached handle-backed triggers read from. Both the real `PreviewCardStore`
* and the inert fallback store satisfy it, so a trigger can read from whichever store the handle
* currently exposes. Narrowed to the trigger-data members a trigger uses; it exposes no popup-open
* mutator, so the inert fallback can be a plain `NullStore`.
*/
var PreviewCardStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		super(createInitialState(initialState, triggerElements, floatingId, nested), createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		const { inlineRectCoordsRef } = this.context;
		applyPopupOpenChange(this, nextOpen, eventDetails, { onBeforeDispatch() {
			const event = eventDetails.event;
			if (nextOpen && eventDetails.reason === "trigger-hover" && eventDetails.trigger && "clientX" in event && "clientY" in event && inlineRectCoordsRef.current?.element !== eventDetails.trigger) updateInlineRectCoords(inlineRectCoordsRef, eventDetails.trigger, event.clientX, event.clientY);
		} });
	};
};
/**
* Creates the inert fallback store used by detached handle-backed triggers while no
* `PreviewCard.Root` is attached. It preserves a preview-card-specific trigger registry in context
* so detached triggers can register before migrating to the live root store.
*/
function createNullPreviewCardStore() {
	const triggerElements = new PopupTriggerMap();
	return new NullStore(Object.freeze(createInitialState(void 0, triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors);
}
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	const state = {
		...createInitialPopupStoreState(),
		instantType: void 0,
		adaptiveOrigin: void 0,
		closeDelay: 300,
		...initialState
	};
	state.floatingRootContext = createPopupFloatingRootContext(triggerElements, floatingId, nested);
	return state;
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		onOpenChange: void 0,
		onOpenChangeComplete: void 0,
		triggerElements,
		inlineRectCoordsRef: { current: void 0 }
	};
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/root/PreviewCardRoot.mjs
var import_jsx_runtime = require_jsx_runtime();
function PreviewCardRootComponent(props) {
	const { open: openProp, defaultOpen = false, onOpenChange, onOpenChangeComplete, actionsRef, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null, children } = props;
	const store = usePopupRootStore((floatingId, nested) => new PreviewCardStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp
	}, floatingId, nested));
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const open = store.useState("open");
	const activeTriggerId = store.useState("activeTriggerId");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	useImplicitActiveTrigger(store, { closeOnActiveTriggerUnmount: true });
	const { forceUnmount } = useOpenStateTransitions(open, store, () => {
		store.context.inlineRectCoordsRef.current = void 0;
	});
	useIsoLayoutEffect(() => {
		if (open) {
			if (activeTriggerId == null) store.set("payload", void 0);
		}
	}, [
		store,
		activeTriggerId,
		open
	]);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(PreviewCardRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PreviewCardInteractions, { store }),
			typeof children === "function" ? children({ payload }) : children
		]
	});
}
function PreviewCardInteractions({ store }) {
	const dismiss = useDismiss(store.useState("floatingRootContext"));
	usePopupInteractionProps(store, {
		activeTriggerProps: dismiss.reference,
		inactiveTriggerProps: dismiss.trigger,
		popupProps: dismiss.floating
	});
	return null;
}
/**
* Groups all parts of the preview card.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardRoot = fastComponent(function PreviewCardRoot(props) {
	if (usePreviewCardRootContext(true)) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PreviewCardRootComponent, { ...props });
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingTree, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PreviewCardRootComponent, { ...props }) });
});
PreviewCardRoot.displayName = "PreviewCardRoot";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/portal/PreviewCardPortalContext.mjs
var PreviewCardPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
PreviewCardPortalContext.displayName = "PreviewCardPortalContext";
function usePreviewCardPortalContext() {
	const value = import_react.useContext(PreviewCardPortalContext);
	if (value === void 0) throw new Error("Base UI: <PreviewCard.Portal> is missing.");
	return value;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/portal/PreviewCardPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardPortal = /*#__PURE__*/ import_react.forwardRef(function PreviewCardPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	if (!(usePreviewCardRootContext().useState("mounted") || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PreviewCardPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortalLite, {
			ref: forwardedRef,
			...portalProps
		})
	});
});
PreviewCardPortal.displayName = "PreviewCardPortal";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/trigger/PreviewCardTrigger.mjs
/**
* A link that opens the preview card.
* Renders an `<a>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardTrigger = fastComponentRef(function PreviewCardTrigger(componentProps, forwardedRef) {
	const { render, className, delay, closeDelay, id: idProp, payload, handle, style, ...elementProps } = componentProps;
	const rootContext = usePreviewCardRootContext(true);
	const store = usePopupHandleStore(handle) ?? rootContext;
	if (!store) throw new Error("Base UI: <PreviewCard.Trigger> must be either used within a <PreviewCard.Root> component or provided with a handle.");
	const thisTriggerId = useBaseUiId(idProp);
	const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const floatingRootContext = store.useState("floatingRootContext");
	const inlineRectCoordsRef = store.context.inlineRectCoordsRef;
	const triggerElementRef = import_react.useRef(null);
	const delayWithDefault = delay ?? 600;
	const closeDelayWithDefault = closeDelay ?? 300;
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
		payload,
		closeDelay: closeDelayWithDefault
	});
	const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
		mouseOnly: true,
		move: false,
		handleClose: safePolygon(),
		delay: () => ({
			open: delayWithDefault,
			close: closeDelayWithDefault
		}),
		triggerElementRef,
		isActiveTrigger: isTriggerActive,
		isClosing: () => store.select("transitionStatus") === "ending"
	});
	const focusProps = useFocus(floatingRootContext, { delay: delayWithDefault });
	const state = { open: isOpenedByThisTrigger };
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	const inlineRectTriggerProps = getInlineRectTriggerProps(inlineRectCoordsRef, isOpenedByThisTrigger);
	return useRenderElement("a", componentProps, {
		state,
		ref: [
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			hoverProps,
			focusProps.reference,
			rootTriggerProps,
			inlineRectTriggerProps,
			{ id: thisTriggerId },
			elementProps
		],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
PreviewCardTrigger.displayName = "PreviewCardTrigger";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/positioner/PreviewCardPositionerContext.mjs
var PreviewCardPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
PreviewCardPositionerContext.displayName = "PreviewCardPositionerContext";
function usePreviewCardPositionerContext() {
	const context = import_react.useContext(PreviewCardPositionerContext);
	if (context === void 0) throw new Error("Base UI: PreviewCardPositionerContext is missing. PreviewCardPositioner parts must be placed within <PreviewCard.Positioner>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/positioner/PreviewCardPositioner.mjs
/**
* Positions the popup against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardPositioner = /*#__PURE__*/ import_react.forwardRef(function PreviewCardPositioner(componentProps, forwardedRef) {
	const { render, className, anchor, positionMethod = "absolute", side = "bottom", align = "center", sideOffset = 0, alignOffset = 0, collisionBoundary = "clipping-ancestors", collisionPadding = 5, arrowPadding = 5, sticky = false, disableAnchorTracking = false, collisionAvoidance = POPUP_COLLISION_AVOIDANCE, style, ...elementProps } = componentProps;
	const store = usePreviewCardRootContext();
	const keepMounted = usePreviewCardPortalContext();
	const nodeId = useFloatingNodeId();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const floatingRootContext = store.useState("floatingRootContext");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const adaptiveOrigin = store.useState("adaptiveOrigin");
	const inlineRectCoordsRef = store.context.inlineRectCoordsRef;
	const positioning = useAnchorPositioning({
		anchor,
		floatingRootContext,
		positionMethod,
		mounted,
		side,
		sideOffset,
		align,
		alignOffset,
		arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		disableAnchorTracking,
		keepMounted,
		nodeId,
		collisionAvoidance,
		adaptiveOrigin,
		inline: createInlineMiddleware(inlineRectCoordsRef)
	});
	const updatePosition = positioning.update;
	useIsoLayoutEffect(() => {
		if (open && mounted) updatePosition();
	}, [
		open,
		mounted,
		updatePosition
	]);
	const element = usePositioner(componentProps, {
		open,
		side: positioning.side,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden,
		instant: instantType
	}, {
		styles: positioning.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, store.useStateSetter("positionerElement")],
		hidden: !mounted,
		inert: !open
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PreviewCardPositionerContext.Provider, {
		value: positioning,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingNode, {
			id: nodeId,
			children: element
		})
	});
});
PreviewCardPositioner.displayName = "PreviewCardPositioner";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/popup/PreviewCardPopup.mjs
/**
* A container for the preview card contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardPopup = /*#__PURE__*/ import_react.forwardRef(function PreviewCardPopup(componentProps, forwardedRef) {
	const { className, render, style, ...elementProps } = componentProps;
	const store = usePreviewCardRootContext();
	const { side, align } = usePreviewCardPositionerContext();
	const open = store.useState("open");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const popupProps = store.useState("popupProps");
	const floatingContext = store.useState("floatingRootContext");
	const closeDelay = store.useState("closeDelay");
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	useHoverFloatingInteraction(floatingContext, { closeDelay });
	return useRenderElement("div", componentProps, {
		state: {
			open,
			side,
			align,
			instant: instantType,
			transitionStatus
		},
		ref: [
			forwardedRef,
			store.context.popupRef,
			store.useStateSetter("popupElement")
		],
		props: [
			FOCUSABLE_POPUP_PROPS,
			popupProps,
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps
		],
		stateAttributesMapping: popupTransitionStateMapping
	});
});
PreviewCardPopup.displayName = "PreviewCardPopup";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/arrow/PreviewCardArrow.mjs
/**
* Displays an element positioned against the preview card anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardArrow = /*#__PURE__*/ import_react.forwardRef(function PreviewCardArrow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = usePreviewCardRootContext();
	const { arrowRef, side, align, arrowUncentered, arrowStyles } = usePreviewCardPositionerContext();
	return useRenderElement("div", componentProps, {
		state: {
			open: store.useState("open"),
			side,
			align,
			uncentered: arrowUncentered
		},
		ref: [arrowRef, forwardedRef],
		props: [{
			style: arrowStyles,
			"aria-hidden": true
		}, elementProps],
		stateAttributesMapping: popupStateMapping
	});
});
PreviewCardArrow.displayName = "PreviewCardArrow";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/backdrop/PreviewCardBackdrop.mjs
/**
* A presentational overlay displayed beneath the popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardBackdrop = /*#__PURE__*/ import_react.forwardRef(function PreviewCardBackdrop(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = usePreviewCardRootContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	return useRenderElement("div", componentProps, {
		state: {
			open,
			transitionStatus: store.useState("transitionStatus")
		},
		ref: [forwardedRef],
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				pointerEvents: "none",
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps],
		stateAttributesMapping: popupTransitionStateMapping
	});
});
PreviewCardBackdrop.displayName = "PreviewCardBackdrop";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/viewport/PreviewCardViewport.mjs
/**
* A viewport for displaying content transitions.
* This component is only required if one popup can be opened by multiple triggers, its content
* changes based on the trigger, and switching between them is animated.
* Renders a `<div>` element.
*
* Documentation: [Base UI Preview Card](https://base-ui.com/react/components/preview-card)
*/
var PreviewCardViewport = /*#__PURE__*/ import_react.forwardRef(function PreviewCardViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const store = usePreviewCardRootContext();
	const positioner = usePreviewCardPositionerContext();
	const instantType = store.useState("instantType");
	const { children: childrenToRender, state: viewportState } = usePopupViewport({
		store,
		side: positioner.side,
		children
	});
	return useRenderElement("div", componentProps, {
		state: {
			activationDirection: viewportState.activationDirection,
			transitioning: viewportState.transitioning,
			instant: instantType
		},
		ref: forwardedRef,
		props: [elementProps, { children: childrenToRender }],
		stateAttributesMapping: popupViewportStateMapping
	});
});
PreviewCardViewport.displayName = "PreviewCardViewport";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/store/PreviewCardHandle.mjs
/**
* Controls a PreviewCard imperatively and associates detached `PreviewCard.Trigger` components with
* a `PreviewCard.Root`. Create one with `PreviewCard.createHandle()` and pass it to the `handle`
* prop of the root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var PreviewCardHandle = class extends BasePopupHandle {
	constructor() {
		super(createNullPreviewCardStore(), "PreviewCard");
	}
	/**
	* Opens the preview card and associates it with the trigger with the given id.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the preview card. The trigger must be a
	* matching `PreviewCard.Trigger` with this handle passed as a prop.
	*/
	open(triggerId) {
		this.openByTrigger(triggerId);
	}
	/**
	* Closes the preview card.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	close() {
		this.closePopup();
	}
	/**
	* Whether the preview card is currently open. Returns `false` while no root is attached to the handle.
	*/
	get isOpen() {
		return this.attachedStore?.select("open") ?? false;
	}
};
/**
* Creates a new handle to connect a PreviewCard.Root with detached PreviewCard.Trigger components.
*/
function createPreviewCardHandle() {
	return new PreviewCardHandle();
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/preview-card/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Arrow: () => PreviewCardArrow,
	Backdrop: () => PreviewCardBackdrop,
	Handle: () => PreviewCardHandle,
	Popup: () => PreviewCardPopup,
	Portal: () => PreviewCardPortal,
	Positioner: () => PreviewCardPositioner,
	Root: () => PreviewCardRoot,
	Trigger: () => PreviewCardTrigger,
	Viewport: () => PreviewCardViewport,
	createHandle: () => createPreviewCardHandle
});
//#endregion
export { index_parts_exports as PreviewCard };
