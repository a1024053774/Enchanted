import { i as __toESM, n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import "./createBaseUIEventDetails-CVD4a1Ya.js";
import { o as stringifyAsLabel, t as ListboxSeparator } from "./ListboxSeparator-BERMPiEO.js";
import { A as useComboboxInputValueContext, C as ComboboxTrigger, E as AriaCombobox, O as useCoreFilter, _ as ComboboxIcon, b as ComboboxInput, c as ComboboxArrow, d as ComboboxBackdrop, f as ComboboxPortal, g as ComboboxClear, h as ComboboxCollection, i as ComboboxItem, l as ComboboxPopup, m as ComboboxList, n as ComboboxEmpty, o as ComboboxGroupLabel, p as ComboboxStatus, r as ComboboxRow, s as ComboboxGroup, t as useFilteredItems, u as ComboboxPositioner, v as ComboboxInputGroup } from "./useFilteredItems-CKyPw-BX.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/root/AutocompleteRoot.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function AutocompleteRoot(props) {
	const { openOnInputClick = false, value, defaultValue, onValueChange, mode = "list", itemToStringValue, ...other } = props;
	const enableInline = mode === "inline" || mode === "both";
	const staticItems = mode === "inline" || mode === "none";
	const isControlled = value !== void 0;
	const [internalValue, setInternalValue] = import_react.useState(defaultValue ?? "");
	const [inlineInputValue, setInlineInputValue] = import_react.useState("");
	import_react.useEffect(() => {
		if (isControlled) setInlineInputValue("");
	}, [value, isControlled]);
	let resolvedInputValue;
	if (enableInline && inlineInputValue !== "") resolvedInputValue = inlineInputValue;
	else if (isControlled) resolvedInputValue = value ?? "";
	else resolvedInputValue = internalValue;
	const collator = useCoreFilter({ locale: other.locale });
	const baseFilter = import_react.useMemo(() => {
		if (other.filter !== void 0) return other.filter;
		return collator.contains;
	}, [other.filter, collator]);
	const resolvedQuery = String(isControlled ? value : internalValue).trim();
	const resolvedFilter = import_react.useMemo(() => {
		if (mode !== "both") return staticItems ? null : baseFilter;
		if (baseFilter === null) return null;
		return (item, _query, toString) => {
			return baseFilter(item, resolvedQuery, toString);
		};
	}, [
		baseFilter,
		mode,
		resolvedQuery,
		staticItems
	]);
	function handleValueChange(nextValue, eventDetails) {
		setInlineInputValue("");
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue, eventDetails);
	}
	function handleItemHighlighted(highlightedValue, eventDetails) {
		props.onItemHighlighted?.(highlightedValue, eventDetails);
		if (eventDetails.reason === "pointer") return;
		setInlineInputValue(enableInline && highlightedValue != null ? stringifyAsLabel(highlightedValue, itemToStringValue) : "");
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(AriaCombobox, {
		...other,
		itemToStringLabel: itemToStringValue,
		openOnInputClick,
		selectionMode: "none",
		fillInputOnItemPress: true,
		filter: resolvedFilter,
		autoComplete: mode,
		inputValue: resolvedInputValue,
		defaultInputValue: defaultValue,
		onInputValueChange: handleValueChange,
		onItemHighlighted: handleItemHighlighted
	});
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/value/AutocompleteValue.mjs
/**
* The current value of the autocomplete.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Autocomplete](https://base-ui.com/react/components/autocomplete)
*/
function AutocompleteValue(props) {
	const { children } = props;
	const inputValue = useComboboxInputValueContext();
	let returnValue = null;
	if (typeof children === "function") returnValue = children(String(inputValue));
	else if (children != null) returnValue = children;
	else returnValue = inputValue;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: returnValue });
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/trigger/AutocompleteTrigger.mjs
/**
* A button that opens the popup.
* Renders a `<button>` element.
*
* Documentation: [Base UI Autocomplete](https://base-ui.com/react/components/autocomplete)
*/
var AutocompleteTrigger = ComboboxTrigger;
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/input-group/AutocompleteInputGroup.mjs
/**
* A wrapper for the input and its associated controls.
* Renders a `<div>` element.
*
* Documentation: [Base UI Autocomplete](https://base-ui.com/react/components/autocomplete)
*/
var AutocompleteInputGroup = ComboboxInputGroup;
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/item/AutocompleteItem.mjs
/**
* An individual item in the list.
* Renders a `<div>` element.
*
* Documentation: [Base UI Autocomplete](https://base-ui.com/react/components/autocomplete)
*/
var AutocompleteItem = ComboboxItem;
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/separator/AutocompleteSeparator.mjs
/**
* A visual separator between items or groups.
* Renders a `<div>` element.
*
* Documentation: [Base UI Autocomplete](https://base-ui.com/react/components/autocomplete)
*/
var AutocompleteSeparator = ListboxSeparator;
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/autocomplete/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Arrow: () => ComboboxArrow,
	Backdrop: () => ComboboxBackdrop,
	Clear: () => ComboboxClear,
	Collection: () => ComboboxCollection,
	Empty: () => ComboboxEmpty,
	Group: () => ComboboxGroup,
	GroupLabel: () => ComboboxGroupLabel,
	Icon: () => ComboboxIcon,
	Input: () => ComboboxInput,
	InputGroup: () => AutocompleteInputGroup,
	Item: () => AutocompleteItem,
	List: () => ComboboxList,
	Popup: () => ComboboxPopup,
	Portal: () => ComboboxPortal,
	Positioner: () => ComboboxPositioner,
	Root: () => AutocompleteRoot,
	Row: () => ComboboxRow,
	Separator: () => AutocompleteSeparator,
	Status: () => ComboboxStatus,
	Trigger: () => AutocompleteTrigger,
	Value: () => AutocompleteValue,
	useFilter: () => useCoreFilter,
	useFilteredItems: () => useFilteredItems
});
//#endregion
export { index_parts_exports as Autocomplete };
