import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { LexicalComposerContext, createLexicalComposerContext } from "./@lexical_react_LexicalComposerContext.js";
import { $createParagraphNode, $getRoot, $getSelection, HISTORY_MERGE_TAG, createEditor } from "./lexical.js";
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalComposer.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var CAN_USE_DOM = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var useLayoutEffectImpl = CAN_USE_DOM ? import_react.useLayoutEffect : import_react.useEffect;
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var HISTORY_MERGE_OPTIONS = { tag: HISTORY_MERGE_TAG };
function LexicalComposer({ initialConfig, children }) {
	const composerContext = (0, import_react.useMemo)(() => {
		const { theme, namespace, nodes, onError, editorState: initialEditorState, html } = initialConfig;
		const context = createLexicalComposerContext(null, theme);
		const editor = createEditor({
			editable: initialConfig.editable,
			html,
			namespace,
			nodes,
			onError: (error) => onError(error, editor),
			theme
		});
		initializeEditor(editor, initialEditorState);
		return [editor, context];
	}, []);
	useLayoutEffectImpl(() => {
		const isEditable = initialConfig.editable;
		const [editor] = composerContext;
		editor.setEditable(isEditable !== void 0 ? isEditable : true);
	}, []);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(LexicalComposerContext.Provider, {
		value: composerContext,
		children
	});
}
function initializeEditor(editor, initialEditorState) {
	if (initialEditorState === null) return;
	else if (initialEditorState === void 0) editor.update(() => {
		const root = $getRoot();
		if (root.isEmpty()) {
			const paragraph = $createParagraphNode();
			root.append(paragraph);
			const activeElement = CAN_USE_DOM ? document.activeElement : null;
			if ($getSelection() !== null || activeElement !== null && activeElement === editor.getRootElement()) paragraph.select();
		}
	}, HISTORY_MERGE_OPTIONS);
	else if (initialEditorState !== null) switch (typeof initialEditorState) {
		case "string": {
			const parsedEditorState = editor.parseEditorState(initialEditorState);
			editor.setEditorState(parsedEditorState, HISTORY_MERGE_OPTIONS);
			break;
		}
		case "object":
			editor.setEditorState(initialEditorState, HISTORY_MERGE_OPTIONS);
			break;
		case "function":
			editor.update(() => {
				if ($getRoot().isEmpty()) initialEditorState(editor);
			}, HISTORY_MERGE_OPTIONS);
			break;
	}
}
//#endregion
export { LexicalComposer };
