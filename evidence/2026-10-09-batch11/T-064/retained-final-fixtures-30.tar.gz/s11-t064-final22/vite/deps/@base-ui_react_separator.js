import { t as Separator } from "./Separator-Dd7eExbH.js";
export { Separator };
