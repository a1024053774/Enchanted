import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var DirectionContext = /*#__PURE__*/ import_react.createContext(void 0);
DirectionContext.displayName = "DirectionContext";
function useDirection() {
	return import_react.useContext(DirectionContext)?.direction ?? "ltr";
}
//#endregion
export { useDirection as t };
