import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { a as DialogTitle, c as DialogDescription, d as useRenderDialogRoot, i as DialogTrigger, l as DialogClose, o as DialogPortal, r as DialogViewport, s as DialogPopup, t as DialogHandle, u as DialogBackdrop } from "./DialogHandle-BK30-wrq.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/alert-dialog/root/AlertDialogRoot.mjs
/**
* Groups all parts of the alert dialog.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Alert Dialog](https://base-ui.com/react/components/alert-dialog)
*/
function AlertDialogRoot(props) {
	return useRenderDialogRoot("alert-dialog", props);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/alert-dialog/trigger/AlertDialogTrigger.mjs
/**
* A button that opens the alert dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Alert Dialog](https://base-ui.com/react/components/alert-dialog)
*/
var AlertDialogTrigger = DialogTrigger;
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/alert-dialog/handle.mjs
/**
* Controls an Alert Dialog imperatively and associates detached `AlertDialog.Trigger` components with
* an `AlertDialog.Root`. Create one with `AlertDialog.createHandle()` and pass it to the `handle`
* prop of the root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var AlertDialogHandle = class extends DialogHandle {};
/**
* Creates a new handle to connect an AlertDialog.Root with detached AlertDialog.Trigger components.
*/
function createAlertDialogHandle() {
	return new AlertDialogHandle();
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/alert-dialog/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Backdrop: () => DialogBackdrop,
	Close: () => DialogClose,
	Description: () => DialogDescription,
	Handle: () => AlertDialogHandle,
	Popup: () => DialogPopup,
	Portal: () => DialogPortal,
	Root: () => AlertDialogRoot,
	Title: () => DialogTitle,
	Trigger: () => AlertDialogTrigger,
	Viewport: () => DialogViewport,
	createHandle: () => createAlertDialogHandle
});
//#endregion
export { index_parts_exports as AlertDialog };
