import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { Y as constUndefined, ot as pipeArguments, x as hasProperty } from "./Equal-CgzkNqbP.js";
import { Al as empty, Dl as Service, Ll as merge, bs as StackTrace, kl as add } from "./Effect-DrBRDdmt.js";
import { Er as isSchema, Kt as Void, O as Exit, V as Never, Vr as make$1, Vt as Union, d as Class, ht as Struct, nn as declare, y as Defect } from "./Schema-DuK_yWH0.js";
import { m as isStream, n as symbol } from "./PrimaryKey-BilJj_MP.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcSchema.js
/**
* @since 4.0.0
*/
var RpcSchema_exports = /* @__PURE__ */ __exportAll({
	ClientAbort: () => ClientAbort,
	Stream: () => Stream,
	getStreamSchemas: () => getStreamSchemas,
	isStreamSchema: () => isStreamSchema
});
var StreamSchemaTypeId = "~effect/rpc/RpcSchema/StreamSchema";
/**
* @since 4.0.0
* @category Stream
*/
function isStreamSchema(schema) {
	return hasProperty(schema, StreamSchemaTypeId);
}
/** @internal */
function getStreamSchemas(schema) {
	return isStreamSchema(schema) ? {
		success: schema.success,
		error: schema.error
	} : void 0;
}
var schema = /*#__PURE__*/ declare(isStream);
/**
* @since 4.0.0
* @category Stream
*/
function Stream(success, error) {
	return make$1(schema.ast, {
		[StreamSchemaTypeId]: StreamSchemaTypeId,
		success,
		error
	});
}
/**
* @since 4.0.0
* @category Cause annotations
*/
var ClientAbort = class extends Service()("effect/rpc/RpcSchema/ClientAbort") {
	static annotation = /*#__PURE__*/ this.serviceMap(true).pipe(/*#__PURE__*/ add(StackTrace, {
		name: "ClientAbort",
		stack: constUndefined,
		parent: void 0
	}));
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/Rpc.js
var Rpc_exports = /* @__PURE__ */ __exportAll({
	exitSchema: () => exitSchema,
	fork: () => fork,
	isRpc: () => isRpc,
	isWrapper: () => isWrapper,
	make: () => make,
	uninterruptible: () => uninterruptible,
	wrap: () => wrap
});
var TypeId = "~effect/rpc/Rpc";
/**
* @since 4.0.0
* @category guards
*/
var isRpc = (u) => hasProperty(u, TypeId);
var Proto = {
	[TypeId]: TypeId,
	pipe() {
		return pipeArguments(this, arguments);
	},
	setSuccess(successSchema) {
		return makeProto({
			_tag: this._tag,
			payloadSchema: this.payloadSchema,
			successSchema,
			errorSchema: this.errorSchema,
			defectSchema: this.defectSchema,
			annotations: this.annotations,
			middlewares: this.middlewares
		});
	},
	setError(errorSchema) {
		return makeProto({
			_tag: this._tag,
			payloadSchema: this.payloadSchema,
			successSchema: this.successSchema,
			errorSchema,
			defectSchema: this.defectSchema,
			annotations: this.annotations,
			middlewares: this.middlewares
		});
	},
	setPayload(payloadSchema) {
		return makeProto({
			_tag: this._tag,
			payloadSchema: isSchema(payloadSchema) ? payloadSchema : Struct(payloadSchema),
			successSchema: this.successSchema,
			errorSchema: this.errorSchema,
			defectSchema: this.defectSchema,
			annotations: this.annotations,
			middlewares: this.middlewares
		});
	},
	middleware(middleware) {
		return makeProto({
			_tag: this._tag,
			payloadSchema: this.payloadSchema,
			successSchema: this.successSchema,
			errorSchema: this.errorSchema,
			defectSchema: this.defectSchema,
			annotations: this.annotations,
			middlewares: /* @__PURE__ */ new Set([...this.middlewares, middleware])
		});
	},
	prefix(prefix) {
		return makeProto({
			_tag: `${prefix}${this._tag}`,
			payloadSchema: this.payloadSchema,
			successSchema: this.successSchema,
			errorSchema: this.errorSchema,
			defectSchema: this.defectSchema,
			annotations: this.annotations,
			middlewares: this.middlewares
		});
	},
	annotate(tag, value) {
		return makeProto({
			_tag: this._tag,
			payloadSchema: this.payloadSchema,
			successSchema: this.successSchema,
			errorSchema: this.errorSchema,
			defectSchema: this.defectSchema,
			middlewares: this.middlewares,
			annotations: add(this.annotations, tag, value)
		});
	},
	annotateMerge(context) {
		return makeProto({
			_tag: this._tag,
			payloadSchema: this.payloadSchema,
			successSchema: this.successSchema,
			errorSchema: this.errorSchema,
			defectSchema: this.defectSchema,
			middlewares: this.middlewares,
			annotations: merge(this.annotations, context)
		});
	}
};
var makeProto = (options) => {
	function Rpc() {}
	Object.setPrototypeOf(Rpc, Proto);
	Object.assign(Rpc, options);
	Rpc.key = `effect/rpc/Rpc/${options._tag}`;
	return Rpc;
};
/**
* @since 4.0.0
* @category constructors
*/
var make = (tag, options) => {
	const successSchema = options?.success ?? Void;
	const errorSchema = options?.error ?? Never;
	const defectSchema = options?.defect ?? Defect;
	let payloadSchema;
	if (options?.primaryKey) payloadSchema = class Payload extends Class(`effect/rpc/Rpc/${tag}`)(options.payload) {
		[symbol]() {
			return options.primaryKey(this);
		}
	};
	else payloadSchema = isSchema(options?.payload) ? options?.payload : options?.payload ? Struct(options?.payload) : Void;
	return makeProto({
		_tag: tag,
		payloadSchema,
		successSchema: options?.stream ? Stream(successSchema, errorSchema) : successSchema,
		errorSchema: options?.stream ? Never : errorSchema,
		defectSchema,
		annotations: empty(),
		middlewares: /* @__PURE__ */ new Set()
	});
};
var exitSchemaCache = /*#__PURE__*/ new WeakMap();
/**
* @since 4.0.0
* @category constructors
*/
var exitSchema = (self) => {
	if (exitSchemaCache.has(self)) return exitSchemaCache.get(self);
	const rpc = self;
	const failures = /* @__PURE__ */ new Set([rpc.errorSchema]);
	const streamSchemas = getStreamSchemas(rpc.successSchema);
	if (streamSchemas) failures.add(streamSchemas.error);
	for (const middleware of rpc.middlewares) failures.add(middleware.error);
	const schema = Exit(streamSchemas ? Void : rpc.successSchema, Union([...failures]), rpc.defectSchema);
	exitSchemaCache.set(self, schema);
	return schema;
};
var WrapperTypeId = "~effect/rpc/Rpc/Wrapper";
/**
* @since 4.0.0
* @category Wrapper
*/
var isWrapper = (u) => WrapperTypeId in u;
/**
* @since 4.0.0
* @category Wrapper
*/
var wrap = (options) => (value) => isWrapper(value) ? {
	[WrapperTypeId]: WrapperTypeId,
	value: value.value,
	fork: options.fork ?? value.fork,
	uninterruptible: options.uninterruptible ?? value.uninterruptible
} : {
	[WrapperTypeId]: WrapperTypeId,
	value,
	fork: options.fork ?? false,
	uninterruptible: options.uninterruptible ?? false
};
/**
* You can use `fork` to wrap a response Effect or Stream, to ensure that the
* response is executed concurrently regardless of the RpcServer concurrency
* setting.
*
* @since 4.0.0
* @category Wrapper
*/
var fork = /*#__PURE__*/ wrap({ fork: true });
/**
* You can use `uninterruptible` to wrap a response Effect or Stream, to ensure that it is run in an uninterruptible region.
*
* @since 4.0.0
* @category Wrapper
*/
var uninterruptible = /*#__PURE__*/ wrap({ uninterruptible: true });
//#endregion
export { isWrapper as a, wrap as c, getStreamSchemas as d, isStreamSchema as f, isRpc as i, ClientAbort as l, exitSchema as n, make as o, fork as r, uninterruptible as s, Rpc_exports as t, RpcSchema_exports as u };
