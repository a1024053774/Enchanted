import { t as findAndReplace } from "./lib-BnqScE4y.js";
//#region node_modules/.bun/mdast-util-newline-to-break@2.0.0/node_modules/mdast-util-newline-to-break/lib/index.js
/**
* @typedef {import('mdast').Nodes} Nodes
* @typedef {import('mdast-util-find-and-replace').ReplaceFunction} ReplaceFunction
*/
/**
* Turn normal line endings into hard breaks.
*
* @param {Nodes} tree
*   Tree to change.
* @returns {undefined}
*   Nothing.
*/
function newlineToBreak(tree) {
	findAndReplace(tree, [/\r?\n|\r/g, replace]);
}
/**
* Replace line endings.
*
* @type {ReplaceFunction}
*/
function replace() {
	return { type: "break" };
}
//#endregion
//#region node_modules/.bun/remark-breaks@4.0.0/node_modules/remark-breaks/lib/index.js
/**
* @typedef {import('mdast').Root} Root
*/
/**
* Support hard breaks without needing spaces or escapes (turns enters into
* `<br>`s).
*
* @returns
*   Transform.
*/
function remarkBreaks() {
	/**
	* Transform.
	*
	* @param {Root} tree
	*   Tree.
	* @returns {undefined}
	*   Nothing.
	*/
	return function(tree) {
		newlineToBreak(tree);
	};
}
//#endregion
export { remarkBreaks as default };
