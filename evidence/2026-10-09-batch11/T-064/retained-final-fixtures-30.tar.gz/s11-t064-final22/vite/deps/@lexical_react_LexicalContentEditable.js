import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { useLexicalComposerContext } from "./@lexical_react_LexicalComposerContext.js";
import { mergeRegister } from "./lexical.js";
import { t as $canShowPlaceholderCurry } from "./LexicalText.dev-BKzjuMLh.js";
import "./LexicalUtils.dev-3NAN296g.js";
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalContentEditable.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var useLayoutEffectImpl = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function mergeRefs(...refs) {
	return (value) => {
		for (const ref of refs) if (typeof ref === "function") ref(value);
		else if (ref != null) ref.current = value;
	};
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function ContentEditableElementImpl({ editor, ariaActiveDescendant, ariaAutoComplete, ariaControls, ariaDescribedBy, ariaErrorMessage, ariaExpanded, ariaInvalid, ariaLabel, ariaLabelledBy, ariaMultiline, ariaOwns, ariaRequired, autoCapitalize, className, id, role = "textbox", spellCheck = true, style, tabIndex, "data-testid": testid, ...rest }, ref) {
	const [isEditable, setEditable] = (0, import_react.useState)(editor.isEditable());
	const handleRef = (0, import_react.useCallback)((rootElement) => {
		if (rootElement && rootElement.ownerDocument && rootElement.ownerDocument.defaultView) editor.setRootElement(rootElement);
		else editor.setRootElement(null);
	}, [editor]);
	const mergedRefs = (0, import_react.useMemo)(() => mergeRefs(ref, handleRef), [handleRef, ref]);
	useLayoutEffectImpl(() => {
		setEditable(editor.isEditable());
		return editor.registerEditableListener((currentIsEditable) => {
			setEditable(currentIsEditable);
		});
	}, [editor]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		"aria-activedescendant": isEditable ? ariaActiveDescendant : void 0,
		"aria-autocomplete": isEditable ? ariaAutoComplete : "none",
		"aria-controls": isEditable ? ariaControls : void 0,
		"aria-describedby": ariaDescribedBy,
		...ariaErrorMessage != null ? { "aria-errormessage": ariaErrorMessage } : {},
		"aria-expanded": isEditable && role === "combobox" ? !!ariaExpanded : void 0,
		...ariaInvalid != null ? { "aria-invalid": ariaInvalid } : {},
		"aria-label": ariaLabel,
		"aria-labelledby": ariaLabelledBy,
		"aria-multiline": ariaMultiline,
		"aria-owns": isEditable ? ariaOwns : void 0,
		"aria-readonly": isEditable ? void 0 : true,
		"aria-required": ariaRequired,
		autoCapitalize,
		className,
		contentEditable: isEditable,
		"data-testid": testid,
		id,
		ref: mergedRefs,
		role,
		spellCheck,
		style,
		tabIndex,
		...rest
	});
}
var ContentEditableElement = /*#__PURE__*/ (0, import_react.forwardRef)(ContentEditableElementImpl);
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function canShowPlaceholderFromCurrentEditorState(editor) {
	return editor.getEditorState().read($canShowPlaceholderCurry(editor.isComposing()));
}
function useCanShowPlaceholder(editor) {
	const [canShowPlaceholder, setCanShowPlaceholder] = (0, import_react.useState)(() => canShowPlaceholderFromCurrentEditorState(editor));
	useLayoutEffectImpl(() => {
		function resetCanShowPlaceholder() {
			const currentCanShowPlaceholder = canShowPlaceholderFromCurrentEditorState(editor);
			setCanShowPlaceholder(currentCanShowPlaceholder);
		}
		resetCanShowPlaceholder();
		return mergeRegister(editor.registerUpdateListener(() => {
			resetCanShowPlaceholder();
		}), editor.registerEditableListener(() => {
			resetCanShowPlaceholder();
		}));
	}, [editor]);
	return canShowPlaceholder;
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* @deprecated This type has been renamed to `ContentEditableProps` to provide a clearer and more descriptive name.
* For backward compatibility, this type is still exported as `Props`, but it is recommended to migrate to using `ContentEditableProps` instead.
*
* This alias is maintained for compatibility purposes but may be removed in future versions.
* Please update your codebase to use `ContentEditableProps` to ensure long-term maintainability.
*/
var ContentEditable = /*#__PURE__*/ (0, import_react.forwardRef)(ContentEditableImpl);
function ContentEditableImpl(props, ref) {
	const { placeholder, ...rest } = props;
	const [editor] = useLexicalComposerContext();
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/*#__PURE__*/ (0, import_jsx_runtime.jsx)(ContentEditableElement, {
		editor,
		...rest,
		ref
	}), placeholder != null && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Placeholder, {
		editor,
		content: placeholder
	})] });
}
function Placeholder({ content, editor }) {
	const showPlaceholder = useCanShowPlaceholder(editor);
	const [isEditable, setEditable] = (0, import_react.useState)(editor.isEditable());
	(0, import_react.useLayoutEffect)(() => {
		setEditable(editor.isEditable());
		return editor.registerEditableListener((currentIsEditable) => {
			setEditable(currentIsEditable);
		});
	}, [editor]);
	if (!showPlaceholder) return null;
	let placeholder = null;
	if (typeof content === "function") placeholder = content(isEditable);
	else if (content !== null) placeholder = content;
	if (placeholder === null) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		"aria-hidden": true,
		children: placeholder
	});
}
//#endregion
export { ContentEditable, ContentEditableElement };
