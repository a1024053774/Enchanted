//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/constants.js
var DIFFS_TAG_NAME = "diffs-container";
var DIFFS_DEVELOPMENT_BUILD = (() => {
	try {
		return true;
	} catch {
		return false;
	}
})();
var COMMIT_METADATA_SPLIT = /(?=^From [a-f0-9]+ .+$)/m;
var GIT_DIFF_FILE_BREAK_REGEX = /(?=^diff --git)/gm;
var UNIFIED_DIFF_FILE_BREAK_REGEX = /(?=^---\s+\S)/gm;
var FILE_CONTEXT_BLOB = /(?=^@@ )/gm;
var HUNK_HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: (.*))?/m;
var SPLIT_WITH_NEWLINES = /(?<=\n)/;
var FILENAME_HEADER_REGEX = /^(---|\+\+\+)\s+([^\t\r\n]+)/;
var FILENAME_HEADER_REGEX_GIT = /^(---|\+\+\+)\s+[ab]\/([^\t\r\n]+)/;
var ALTERNATE_FILE_NAMES_GIT = /^diff --git (?:"a\/(.+?)"|a\/(.+?)) (?:"b\/(.+?)"|b\/(.+?))$/;
var INDEX_LINE_METADATA = /^index ([0-9a-f]+)\.\.([0-9a-f]+)(?: (\d+))?$/i;
var MERGE_CONFLICT_START_MARKER_REGEX = /^<{7,}(?:\s.*)?$/;
var MERGE_CONFLICT_BASE_MARKER_REGEX = /^\|{7,}(?:\s.*)?$/;
var MERGE_CONFLICT_SEPARATOR_MARKER_REGEX = /^={7,}$/;
var MERGE_CONFLICT_END_MARKER_REGEX = /^>{7,}(?:\s.*)?$/;
var HEADER_PREFIX_SLOT_ID = "header-prefix";
var HEADER_FILENAME_SUFFIX_SLOT_ID = "header-filename-suffix";
var HEADER_METADATA_SLOT_ID = "header-metadata";
var CUSTOM_HEADER_SLOT_ID = "header-custom";
var DEFAULT_THEMES = {
	dark: "pierre-dark",
	light: "pierre-light"
};
var THEME_CSS_ATTRIBUTE = "data-theme-css";
var UNSAFE_CSS_ATTRIBUTE = "data-unsafe-css";
var CORE_CSS_ATTRIBUTE = "data-core-css";
var DIFFS_SCROLLBAR_MEASURE_ATTRIBUTE = "data-diffs-scrollbar-measure";
var CODE_VIEW_HEADER_ATTRIBUTE = "data-diffs-code-view-header";
var CODE_VIEW_FOOTER_ATTRIBUTE = "data-diffs-code-view-footer";
var DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY = "--diffs-scrollbar-gutter-measured";
var DEFAULT_COLLAPSED_CONTEXT_THRESHOLD = 1;
var DEFAULT_TOKENIZE_MAX_LENGTH = 1e5;
var DEFAULT_VIRTUAL_FILE_METRICS = {
	hunkLineCount: 50,
	lineHeight: 20,
	diffHeaderHeight: 44,
	spacing: 8
};
var DEFAULT_CODE_VIEW_FILE_METRICS = {
	...DEFAULT_VIRTUAL_FILE_METRICS,
	hunkLineCount: 1
};
var DEFAULT_CODE_VIEW_LAYOUT = {
	paddingTop: 8,
	paddingBottom: 8,
	gap: 8
};
var DEFAULT_SMOOTH_SCROLL_SETTINGS = {
	omega: .015,
	positionEpsilon: .5,
	velocityEpsilon: .05
};
var DEFAULT_EXPANDED_REGION = Object.freeze({
	fromStart: 0,
	fromEnd: 0
});
var DEFAULT_RENDER_RANGE = {
	startingLine: 0,
	totalLines: Infinity,
	bufferBefore: 0,
	bufferAfter: 0
};
var EMPTY_RENDER_RANGE = {
	startingLine: 0,
	totalLines: 0,
	bufferBefore: 0,
	bufferAfter: 0
};
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/managers/UniversalRenderingManager.js
var callbacks = /* @__PURE__ */ new Set();
var frameId = null;
function queueRender(callback) {
	callbacks.add(callback);
	frameId ??= requestAnimationFrame(render);
}
function dequeueRender(callback) {
	if (callbacks.delete(callback) && callbacks.size === 0 && frameId != null) {
		cancelAnimationFrame(frameId);
		frameId = null;
	}
}
function clearRenderQueue() {
	callbacks.clear();
	if (frameId != null && typeof cancelAnimationFrame === "function") cancelAnimationFrame(frameId);
	frameId = null;
}
function render(time) {
	const toIterate = new Set(callbacks);
	callbacks.clear();
	for (const callback of toIterate) try {
		callback(time);
	} catch (error) {
		console.error(error);
	}
	if (callbacks.size > 0) frameId = requestAnimationFrame(render);
	else frameId = null;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/isGutterUtilityPath.js
function isGutterUtilityPath(path) {
	for (const element of path) {
		if (!(element instanceof HTMLElement)) continue;
		if (element.hasAttribute("data-utility-button") || element.hasAttribute("data-gutter-utility-slot") || element.getAttribute("slot") === "gutter-utility-slot" || element.getAttribute("name") === "gutter-utility-slot") return true;
	}
	return false;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getFiletypeFromFileName.js
var CUSTOM_EXTENSION_TO_FILE_FORMAT = /* @__PURE__ */ new Map();
var customExtensionsVersion = 0;
var EXTENSION_TO_FILE_FORMAT = {
	"1c": "1c",
	abap: "abap",
	as: "actionscript-3",
	ada: "ada",
	adb: "ada",
	ads: "ada",
	adoc: "asciidoc",
	asciidoc: "asciidoc",
	"component.html": "angular-html",
	"component.ts": "angular-ts",
	conf: "nginx",
	htaccess: "apache",
	cls: "tex",
	trigger: "apex",
	apl: "apl",
	applescript: "applescript",
	scpt: "applescript",
	ara: "ara",
	asm: "asm",
	s: "riscv",
	astro: "astro",
	awk: "awk",
	bal: "ballerina",
	sh: "zsh",
	bash: "zsh",
	bat: "cmd",
	cmd: "cmd",
	be: "berry",
	beancount: "beancount",
	bib: "bibtex",
	bicep: "bicep",
	"blade.php": "blade",
	bsl: "bsl",
	c: "c",
	h: "objective-cpp",
	cs: "csharp",
	cpp: "cpp",
	hpp: "cpp",
	cc: "cpp",
	cxx: "cpp",
	hh: "cpp",
	cdc: "cdc",
	cairo: "cairo",
	clar: "clarity",
	clj: "clojure",
	cljs: "clojure",
	cljc: "clojure",
	soy: "soy",
	cmake: "cmake",
	"CMakeLists.txt": "cmake",
	cob: "cobol",
	cbl: "cobol",
	cobol: "cobol",
	CODEOWNERS: "codeowners",
	ql: "ql",
	coffee: "coffeescript",
	lisp: "lisp",
	cl: "lisp",
	lsp: "lisp",
	log: "log",
	v: "verilog",
	cql: "cql",
	cr: "crystal",
	css: "css",
	csv: "csv",
	cue: "cue",
	cypher: "cypher",
	cyp: "cypher",
	d: "d",
	dart: "dart",
	dax: "dax",
	desktop: "desktop",
	diff: "diff",
	patch: "diff",
	Dockerfile: "dockerfile",
	dockerfile: "dockerfile",
	env: "dotenv",
	dm: "dream-maker",
	edge: "edge",
	el: "emacs-lisp",
	ex: "elixir",
	exs: "elixir",
	elm: "elm",
	erb: "erb",
	erl: "erlang",
	hrl: "erlang",
	f: "fortran-fixed-form",
	for: "fortran-fixed-form",
	fs: "fsharp",
	fsi: "fsharp",
	fsx: "fsharp",
	f03: "f03",
	f08: "f08",
	f18: "f18",
	f77: "f77",
	f90: "fortran-free-form",
	f95: "fortran-free-form",
	fnl: "fennel",
	fish: "fish",
	ftl: "ftl",
	tres: "gdresource",
	res: "gdresource",
	gd: "gdscript",
	gdshader: "gdshader",
	gs: "genie",
	feature: "gherkin",
	COMMIT_EDITMSG: "git-commit",
	"git-rebase-todo": "git-rebase",
	gjs: "glimmer-js",
	gleam: "gleam",
	gts: "glimmer-ts",
	glsl: "glsl",
	vert: "glsl",
	frag: "glsl",
	shader: "shaderlab",
	gp: "gnuplot",
	plt: "gnuplot",
	gnuplot: "gnuplot",
	go: "go",
	graphql: "graphql",
	gql: "graphql",
	groovy: "groovy",
	gvy: "groovy",
	hack: "hack",
	haml: "haml",
	hbs: "handlebars",
	handlebars: "handlebars",
	hs: "haskell",
	lhs: "haskell",
	hx: "haxe",
	hcl: "hcl",
	hjson: "hjson",
	hlsl: "hlsl",
	fx: "hlsl",
	html: "html",
	htm: "html",
	http: "http",
	rest: "http",
	hxml: "hxml",
	hy: "hy",
	imba: "imba",
	ini: "ini",
	cfg: "ini",
	jade: "pug",
	pug: "pug",
	java: "java",
	js: "javascript",
	mjs: "javascript",
	cjs: "javascript",
	jinja: "jinja",
	jinja2: "jinja",
	j2: "jinja",
	jison: "jison",
	jl: "julia",
	json: "json",
	json5: "json5",
	jsonc: "jsonc",
	jsonl: "jsonl",
	jsonnet: "jsonnet",
	libsonnet: "jsonnet",
	jssm: "jssm",
	jsx: "jsx",
	kt: "kotlin",
	kts: "kts",
	kql: "kusto",
	tex: "tex",
	ltx: "tex",
	lean: "lean4",
	less: "less",
	liquid: "liquid",
	lit: "lit",
	ll: "llvm",
	logo: "logo",
	lua: "lua",
	luau: "luau",
	Makefile: "makefile",
	mk: "makefile",
	makefile: "makefile",
	md: "markdown",
	markdown: "markdown",
	marko: "marko",
	m: "wolfram",
	mat: "matlab",
	mdc: "mdc",
	mdx: "mdx",
	wiki: "wikitext",
	mediawiki: "wikitext",
	mmd: "mermaid",
	mermaid: "mermaid",
	mips: "mipsasm",
	mojo: "mojo",
	"🔥": "mojo",
	move: "move",
	nar: "narrat",
	nf: "nextflow",
	nim: "nim",
	nims: "nim",
	nimble: "nim",
	nix: "nix",
	nu: "nushell",
	mm: "objective-cpp",
	ml: "ocaml",
	mli: "ocaml",
	mll: "ocaml",
	mly: "ocaml",
	pas: "pascal",
	p: "pascal",
	pl: "prolog",
	pm: "perl",
	t: "perl",
	raku: "raku",
	p6: "raku",
	pl6: "raku",
	php: "php",
	phtml: "php",
	pls: "plsql",
	sql: "sql",
	po: "po",
	polar: "polar",
	pcss: "postcss",
	pot: "pot",
	potx: "potx",
	pq: "powerquery",
	pqm: "powerquery",
	ps1: "powershell",
	psm1: "powershell",
	psd1: "powershell",
	prisma: "prisma",
	pro: "prolog",
	P: "prolog",
	properties: "properties",
	proto: "protobuf",
	pp: "puppet",
	purs: "purescript",
	py: "python",
	pyw: "python",
	pyi: "python",
	qml: "qml",
	qmldir: "qmldir",
	qss: "qss",
	r: "r",
	R: "r",
	rkt: "racket",
	rktl: "racket",
	razor: "razor",
	cshtml: "razor",
	rb: "ruby",
	rbw: "ruby",
	reg: "reg",
	regex: "regexp",
	rel: "rel",
	rs: "rust",
	rst: "rst",
	rake: "ruby",
	gemspec: "ruby",
	jbuilder: "ruby",
	builder: "ruby",
	rabl: "ruby",
	arb: "ruby",
	ru: "ruby",
	podspec: "ruby",
	Gemfile: "ruby",
	Rakefile: "ruby",
	Guardfile: "ruby",
	Capfile: "ruby",
	Berksfile: "ruby",
	Brewfile: "ruby",
	Vagrantfile: "ruby",
	Thorfile: "ruby",
	Appraisals: "ruby",
	Dangerfile: "ruby",
	sas: "sas",
	sass: "sass",
	scala: "scala",
	sc: "scala",
	scm: "scheme",
	ss: "scheme",
	sld: "scheme",
	scss: "scss",
	sdbl: "sdbl",
	shadergraph: "shader",
	st: "smalltalk",
	sol: "solidity",
	sparql: "sparql",
	rq: "sparql",
	spl: "splunk",
	config: "ssh-config",
	do: "stata",
	ado: "stata",
	dta: "stata",
	styl: "stylus",
	stylus: "stylus",
	svelte: "svelte",
	swift: "swift",
	sv: "system-verilog",
	svh: "system-verilog",
	service: "systemd",
	socket: "systemd",
	device: "systemd",
	timer: "systemd",
	talon: "talonscript",
	tasl: "tasl",
	tcl: "tcl",
	templ: "templ",
	tf: "tf",
	tfvars: "tfvars",
	toml: "toml",
	ts: "typescript",
	mts: "typescript",
	cts: "typescript",
	tsp: "typespec",
	tsv: "tsv",
	tsx: "tsx",
	ttl: "turtle",
	twig: "twig",
	typ: "typst",
	vv: "v",
	vala: "vala",
	vapi: "vala",
	vb: "vb",
	vbs: "vb",
	bas: "vb",
	vh: "verilog",
	vhd: "vhdl",
	vhdl: "vhdl",
	vim: "vimscript",
	vue: "vue",
	"vine.ts": "vue-vine",
	vy: "vyper",
	wasm: "wasm",
	wat: "wasm",
	wy: "文言",
	wgsl: "wgsl",
	wit: "wit",
	wl: "wolfram",
	nb: "wolfram",
	xml: "xml",
	xsl: "xsl",
	xslt: "xsl",
	yaml: "yaml",
	yml: "yml",
	zs: "zenscript",
	zig: "zig",
	zsh: "zsh",
	sty: "tex"
};
function getFiletypeFromFileName(fileName) {
	if (CUSTOM_EXTENSION_TO_FILE_FORMAT.has(fileName)) return CUSTOM_EXTENSION_TO_FILE_FORMAT.get(fileName) ?? "text";
	if (EXTENSION_TO_FILE_FORMAT[fileName] != null) return EXTENSION_TO_FILE_FORMAT[fileName];
	const compoundMatch = fileName.match(/\.([^/\\]+\.[^/\\]+)$/);
	if (compoundMatch != null) {
		if (CUSTOM_EXTENSION_TO_FILE_FORMAT.has(compoundMatch[1])) return CUSTOM_EXTENSION_TO_FILE_FORMAT.get(compoundMatch[1]) ?? "text";
		if (EXTENSION_TO_FILE_FORMAT[compoundMatch[1]] != null) return EXTENSION_TO_FILE_FORMAT[compoundMatch[1]] ?? "text";
	}
	const simpleMatch = fileName.match(/\.([^.]+)$/)?.[1] ?? "";
	if (CUSTOM_EXTENSION_TO_FILE_FORMAT.has(simpleMatch)) return CUSTOM_EXTENSION_TO_FILE_FORMAT.get(simpleMatch) ?? "text";
	return EXTENSION_TO_FILE_FORMAT[simpleMatch] ?? "text";
}
function replaceCustomExtensions(version, map) {
	if (version <= customExtensionsVersion) return false;
	CUSTOM_EXTENSION_TO_FILE_FORMAT.clear();
	for (const key in map) {
		const lang = map[key];
		if (lang != null) CUSTOM_EXTENSION_TO_FILE_FORMAT.set(key, lang);
	}
	customExtensionsVersion = version;
	return true;
}
function getCustomExtensionsVersion() {
	return customExtensionsVersion;
}
function setCustomExtension(key, lang) {
	const existing = CUSTOM_EXTENSION_TO_FILE_FORMAT.get(key);
	if (existing === lang) return false;
	if (existing != null) console.warn(`setCustomExtension: overriding custom mapping for "${key}" from "${existing}" to "${lang}"`);
	CUSTOM_EXTENSION_TO_FILE_FORMAT.set(key, lang);
	customExtensionsVersion++;
	return true;
}
function getCustomExtensionsMap() {
	return Object.fromEntries(CUSTOM_EXTENSION_TO_FILE_FORMAT);
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/getLineAnnotationName.js
function getLineAnnotationName(annotation) {
	return `annotation-${"side" in annotation ? `${annotation.side}-` : ""}${annotation.lineNumber}`;
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/computeFileOffsets.js
var LINE_FEED = 10;
var CARRIAGE_RETURN = 13;
var DENSE_LINE_BREAK_BLOCK_SIZE = 4;
var DENSE_LINE_BREAK_BLOCK_SPAN = 40;
/**
* Computes line start offsets for a string.
*/
function computeLineOffsets(contents) {
	const offsets = [0];
	let carriageReturn = contents.indexOf("\r");
	let lineFeed = contents.indexOf("\n");
	let blockStart = 0;
	let blockBreaks = 0;
	while (carriageReturn !== -1 || lineFeed !== -1) {
		let nextOffset;
		if (carriageReturn !== -1 && (lineFeed === -1 || carriageReturn < lineFeed)) if (lineFeed === carriageReturn + 1) {
			nextOffset = lineFeed + 1;
			carriageReturn = contents.indexOf("\r", nextOffset);
			lineFeed = contents.indexOf("\n", nextOffset);
		} else {
			nextOffset = carriageReturn + 1;
			carriageReturn = contents.indexOf("\r", nextOffset);
		}
		else {
			nextOffset = lineFeed + 1;
			lineFeed = contents.indexOf("\n", nextOffset);
		}
		offsets.push(nextOffset);
		if (++blockBreaks === DENSE_LINE_BREAK_BLOCK_SIZE) {
			if (nextOffset - blockStart <= DENSE_LINE_BREAK_BLOCK_SPAN) {
				for (let i = nextOffset; i < contents.length; i++) {
					const char = contents.charCodeAt(i);
					if (char === LINE_FEED || char === CARRIAGE_RETURN) {
						if (char === CARRIAGE_RETURN && i + 1 < contents.length && contents.charCodeAt(i + 1) === LINE_FEED) i++;
						offsets.push(i + 1);
					}
				}
				return offsets;
			}
			blockStart = nextOffset;
			blockBreaks = 0;
		}
	}
	return offsets;
}
/**
* Counts line breaks in a string, treating `\n`, `\r`, and `\r\n` the same way
* {@link computeLineOffsets} does (a `\r\n` pair is one break). Mirrors that
* scan but counts in a single pass instead of building and discarding an
* offsets array, so sizing the changed-line range for large edits stays cheap.
* A unit test asserts it stays in lockstep with `computeLineOffsets`.
*/
function countLineBreaks(contents) {
	let count = 0;
	for (let i = 0; i < contents.length; i++) {
		const char = contents.charCodeAt(i);
		if (char === LINE_FEED || char === CARRIAGE_RETURN) {
			if (char === CARRIAGE_RETURN && i + 1 < contents.length && contents.charCodeAt(i + 1) === LINE_FEED) i++;
			count++;
		}
	}
	return count;
}
/**
* Splits file contents into lines aligned with {@link computeLineOffsets}.
* Unlike splitFileContents, a trailing newline produces a final empty line.
*/
function linesFromFileContents(contents) {
	const offsets = computeLineOffsets(contents);
	return Array.from({ length: offsets.length }, (_, i) => {
		const start = offsets[i];
		const end = offsets[i + 1] ?? contents.length;
		return contents.slice(start, end);
	});
}
//#endregion
//#region node_modules/.bun/@pierre+diffs@1.3.5+3e2988da8b43fa5d/node_modules/@pierre/diffs/dist/utils/platform.js
var _isMacLike = void 0;
var _isSafari = void 0;
function isMacLike() {
	return _isMacLike ??= /macOS|MacIntel|iPhone|iPad|iPod/i.test(getPlatform());
}
function isSafari() {
	return _isSafari ??= "safari" in window && "pushNotification" in window.safari || /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
}
function getPlatform() {
	const navigator = globalThis.navigator;
	return navigator?.platform ?? navigator?.userAgentData?.platform ?? "unknown";
}
//#endregion
export { UNSAFE_CSS_ATTRIBUTE as $, DEFAULT_TOKENIZE_MAX_LENGTH as A, GIT_DIFF_FILE_BREAK_REGEX as B, DEFAULT_CODE_VIEW_FILE_METRICS as C, DEFAULT_RENDER_RANGE as D, DEFAULT_EXPANDED_REGION as E, DIFFS_TAG_NAME as F, INDEX_LINE_METADATA as G, HEADER_METADATA_SLOT_ID as H, EMPTY_RENDER_RANGE as I, MERGE_CONFLICT_SEPARATOR_MARKER_REGEX as J, MERGE_CONFLICT_BASE_MARKER_REGEX as K, FILENAME_HEADER_REGEX as L, DIFFS_DEVELOPMENT_BUILD as M, DIFFS_SCROLLBAR_GUTTER_MEASURED_PROPERTY as N, DEFAULT_SMOOTH_SCROLL_SETTINGS as O, DIFFS_SCROLLBAR_MEASURE_ATTRIBUTE as P, UNIFIED_DIFF_FILE_BREAK_REGEX as Q, FILENAME_HEADER_REGEX_GIT as R, CUSTOM_HEADER_SLOT_ID as S, DEFAULT_COLLAPSED_CONTEXT_THRESHOLD as T, HEADER_PREFIX_SLOT_ID as U, HEADER_FILENAME_SUFFIX_SLOT_ID as V, HUNK_HEADER as W, SPLIT_WITH_NEWLINES as X, MERGE_CONFLICT_START_MARKER_REGEX as Y, THEME_CSS_ATTRIBUTE as Z, ALTERNATE_FILE_NAMES_GIT as _, linesFromFileContents as a, COMMIT_METADATA_SPLIT as b, getCustomExtensionsMap as c, replaceCustomExtensions as d, setCustomExtension as f, queueRender as g, dequeueRender as h, countLineBreaks as i, DEFAULT_VIRTUAL_FILE_METRICS as j, DEFAULT_THEMES as k, getCustomExtensionsVersion as l, clearRenderQueue as m, isSafari as n, getLineAnnotationName as o, isGutterUtilityPath as p, MERGE_CONFLICT_END_MARKER_REGEX as q, computeLineOffsets as r, EXTENSION_TO_FILE_FORMAT as s, isMacLike as t, getFiletypeFromFileName as u, CODE_VIEW_FOOTER_ATTRIBUTE as v, DEFAULT_CODE_VIEW_LAYOUT as w, CORE_CSS_ATTRIBUTE as x, CODE_VIEW_HEADER_ATTRIBUTE as y, FILE_CONTEXT_BLOB as z };
