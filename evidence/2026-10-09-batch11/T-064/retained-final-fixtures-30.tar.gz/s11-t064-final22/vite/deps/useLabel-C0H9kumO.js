import { C as useIsoLayoutEffect, h as isHTMLElement, n as useStableCallback } from "./useId-Cfrl5XdH.js";
import { t as ownerDocument } from "./owner-BmKt4Bpq.js";
import { r as getTarget } from "./shadowDom-CQZHMuh3.js";
import { t as useBaseUiId } from "./useBaseUiId-BBG3KkG2.js";
import { n as useLabelableContext } from "./LabelableContext-CdYnDOEr.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/useRegisteredLabelId.mjs
function useRegisteredLabelId(idProp, setLabelId) {
	const id = useBaseUiId(idProp);
	useIsoLayoutEffect(() => {
		setLabelId(id);
		return () => {
			setLabelId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [id, setLabelId]);
	return id;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/labelable-provider/useLabel.mjs
function useLabel(params = {}) {
	const { id: idProp, fallbackControlId, native = false, setLabelId: setLabelIdProp, focusControl: focusControlProp } = params;
	const { controlId: contextControlId, setLabelId: setContextLabelId } = useLabelableContext();
	const id = useRegisteredLabelId(idProp, useStableCallback((nextLabelId) => {
		setContextLabelId(nextLabelId);
		setLabelIdProp?.(nextLabelId);
	}));
	const resolvedControlId = contextControlId ?? fallbackControlId;
	function focusControl(event) {
		if (focusControlProp) {
			focusControlProp(event, resolvedControlId);
			return;
		}
		if (!resolvedControlId) return;
		const controlElement = ownerDocument(event.currentTarget).getElementById(resolvedControlId);
		if (isHTMLElement(controlElement)) focusElementWithVisible(controlElement);
	}
	function handleInteraction(event) {
		if (getTarget(event.nativeEvent)?.closest("button,input,select,textarea")) return;
		if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
		if (native) return;
		focusControl(event);
	}
	return native ? {
		id,
		htmlFor: resolvedControlId ?? void 0,
		onMouseDown: handleInteraction
	} : {
		id,
		onClick: handleInteraction,
		onPointerDown(event) {
			event.preventDefault();
		}
	};
}
function focusElementWithVisible(element) {
	element.focus({ focusVisible: true });
}
//#endregion
export { useLabel as n, focusElementWithVisible as t };
