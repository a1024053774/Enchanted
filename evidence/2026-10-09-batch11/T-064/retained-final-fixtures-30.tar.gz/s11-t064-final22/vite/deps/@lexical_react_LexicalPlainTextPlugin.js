import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { t as require_react_dom } from "./react-dom.js";
import { useLexicalComposerContext } from "./@lexical_react_LexicalComposerContext.js";
import { $caretFromPoint, $cloneWithPropertiesEphemeral, $extendCaretToRange, $getCharacterOffsets, $getEditor, $getRoot, $getSelection, $isChildCaret, $isDecoratorNode, $isElementNode, $isExtendableTextPointCaret, $isRangeSelection, $isRootNode, $isTextNode, $isTokenOrSegmented, $selectAll, CONTROLLED_TEXT_INSERTION_COMMAND, COPY_COMMAND, CUT_COMMAND, DELETE_CHARACTER_COMMAND, DELETE_LINE_COMMAND, DELETE_WORD_COMMAND, DRAGSTART_COMMAND, DROP_COMMAND, INSERT_LINE_BREAK_COMMAND, INSERT_PARAGRAPH_COMMAND, KEY_ARROW_LEFT_COMMAND, KEY_ARROW_RIGHT_COMMAND, KEY_BACKSPACE_COMMAND, KEY_DELETE_COMMAND, KEY_ENTER_COMMAND, PASTE_COMMAND, PASTE_TAG, REMOVE_TEXT_COMMAND, SELECT_ALL_COMMAND, defineExtension, getRegisteredNode, isDocumentFragment, isHTMLElement, mergeRegister, safeCast } from "./lexical.js";
import { t as $canShowPlaceholderCurry } from "./LexicalText.dev-BKzjuMLh.js";
import { r as objectKlassEquals } from "./LexicalUtils.dev-3NAN296g.js";
import { i as namedSignals, n as LexicalBuilder, t as E } from "./LexicalExtension.dev-D5IB0gWg.js";
//#region node_modules/.bun/@lexical+selection@0.41.0/node_modules/@lexical/selection/LexicalSelection.dev.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Gets the computed DOM styles of the element.
* @param element - The node to check the styles for.
* @returns the computed styles of the element or null if there is no DOM element or no default view for the document.
*/
function $getComputedStyleForElement(element) {
	const domElement = $getEditor().getElementByKey(element.getKey());
	if (domElement === null) return null;
	const view = domElement.ownerDocument.defaultView;
	if (view === null) return null;
	return view.getComputedStyle(domElement);
}
/**
* Gets the computed DOM styles of the parent of the node.
* @param node - The node to check its parent's styles for.
* @returns the computed styles of the node or null if there is no DOM element or no default view for the document.
*/
function $getComputedStyleForParent(node) {
	return $getComputedStyleForElement($isRootNode(node) ? node : node.getParentOrThrow());
}
/**
* Generally used to append text content to HTML and JSON. Grabs the text content and "slices"
* it to be generated into the new TextNode.
* @param selection - The selection containing the node whose TextNode is to be edited.
* @param textNode - The TextNode to be edited.
* @param mutates - 'clone' to return a clone before mutating, 'self' to update in-place
* @returns The updated TextNode or clone.
*/
function $sliceSelectedTextNodeContent(selection, textNode, mutates = "self") {
	const anchorAndFocus = selection.getStartEndPoints();
	if (textNode.isSelected(selection) && !$isTokenOrSegmented(textNode) && anchorAndFocus !== null) {
		const [anchor, focus] = anchorAndFocus;
		const isBackward = selection.isBackward();
		const anchorNode = anchor.getNode();
		const focusNode = focus.getNode();
		const isAnchor = textNode.is(anchorNode);
		const isFocus = textNode.is(focusNode);
		if (isAnchor || isFocus) {
			const [anchorOffset, focusOffset] = $getCharacterOffsets(selection);
			const isSame = anchorNode.is(focusNode);
			const isFirst = textNode.is(isBackward ? focusNode : anchorNode);
			const isLast = textNode.is(isBackward ? anchorNode : focusNode);
			let startOffset = 0;
			let endOffset = void 0;
			if (isSame) {
				startOffset = anchorOffset > focusOffset ? focusOffset : anchorOffset;
				endOffset = anchorOffset > focusOffset ? anchorOffset : focusOffset;
			} else if (isFirst) {
				startOffset = isBackward ? focusOffset : anchorOffset;
				endOffset = void 0;
			} else if (isLast) {
				const offset = isBackward ? anchorOffset : focusOffset;
				startOffset = 0;
				endOffset = offset;
			}
			const text = textNode.__text.slice(startOffset, endOffset);
			if (text !== textNode.__text) {
				if (mutates === "clone") textNode = $cloneWithPropertiesEphemeral(textNode);
				textNode.__text = text;
			}
		}
	}
	return textNode;
}
/**
* Tests if the selection's parent element has vertical writing mode.
* @param selection - The selection whose parent to test.
* @returns true if the selection's parent has vertical writing mode (writing-mode: vertical-rl), false otherwise.
*/
function $isEditorVerticalOrientation(selection) {
	const computedStyle = $getComputedStyle(selection);
	return computedStyle !== null && computedStyle.writingMode === "vertical-rl";
}
/**
* Gets the computed DOM styles of the parent of the selection's anchor node.
* @param selection - The selection to check the styles for.
* @returns the computed styles of the node or null if there is no DOM element or no default view for the document.
*/
function $getComputedStyle(selection) {
	const anchorNode = selection.anchor.getNode();
	if ($isElementNode(anchorNode)) return $getComputedStyleForElement(anchorNode);
	return $getComputedStyleForParent(anchorNode);
}
/**
* Determines if the default character selection should be overridden. Used with DecoratorNodes
* @param selection - The selection whose default character selection may need to be overridden.
* @param isBackward - Is the selection backwards (the focus comes before the anchor)?
* @returns true if it should be overridden, false if not.
*/
function $shouldOverrideDefaultCharacterSelection(selection, isBackward) {
	let adjustedIsBackward = $isEditorVerticalOrientation(selection) ? !isBackward : isBackward;
	if ($isParentElementRTL(selection)) adjustedIsBackward = !adjustedIsBackward;
	const focusCaret = $caretFromPoint(selection.focus, adjustedIsBackward ? "previous" : "next");
	if ($isExtendableTextPointCaret(focusCaret)) return false;
	for (const nextCaret of $extendCaretToRange(focusCaret)) {
		if ($isChildCaret(nextCaret)) return !nextCaret.origin.isInline();
		else if ($isElementNode(nextCaret.origin)) continue;
		else if ($isDecoratorNode(nextCaret.origin)) return true;
		break;
	}
	return false;
}
/**
* Moves the selection according to the arguments.
* @param selection - The selected text or nodes.
* @param isHoldingShift - Is the shift key being held down during the operation.
* @param isBackward - Is the selection selected backwards (the focus comes before the anchor)?
* @param granularity - The distance to adjust the current selection.
*/
function $moveCaretSelection(selection, isHoldingShift, isBackward, granularity) {
	selection.modify(isHoldingShift ? "extend" : "move", isBackward, granularity);
}
/**
* Tests a parent element for right to left direction.
* @param selection - The selection whose parent is to be tested.
* @returns true if the selections' parent element has a direction of 'rtl' (right to left), false otherwise.
*/
function $isParentElementRTL(selection) {
	const computedStyle = $getComputedStyle(selection);
	return computedStyle !== null && computedStyle.direction === "rtl";
}
/**
* Moves selection by character according to arguments.
* @param selection - The selection of the characters to move.
* @param isHoldingShift - Is the shift key being held down during the operation.
* @param isBackward - Is the selection backward (the focus comes before the anchor)?
*/
function $moveCharacter(selection, isHoldingShift, isBackward) {
	const isRTL = $isParentElementRTL(selection);
	const isVertical = $isEditorVerticalOrientation(selection);
	let adjustedIsBackward;
	if (isVertical) adjustedIsBackward = !isBackward;
	else if (isRTL) adjustedIsBackward = !isBackward;
	else adjustedIsBackward = isBackward;
	$moveCaretSelection(selection, isHoldingShift, adjustedIsBackward, "character");
}
//#endregion
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/useLexicalEditable.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var useLayoutEffectImpl$1 = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Shortcut to Lexical subscriptions when values are used for render.
* @param subscription - The function to create the {@link LexicalSubscription}. This function's identity must be stable (e.g. defined at module scope or with useCallback).
*/
function useLexicalSubscription(subscription) {
	const [editor] = useLexicalComposerContext();
	const initializedSubscription = (0, import_react.useMemo)(() => subscription(editor), [editor, subscription]);
	const [value, setValue] = (0, import_react.useState)(() => initializedSubscription.initialValueFn());
	const valueRef = (0, import_react.useRef)(value);
	useLayoutEffectImpl$1(() => {
		const { initialValueFn, subscribe } = initializedSubscription;
		const currentValue = initialValueFn();
		if (valueRef.current !== currentValue) {
			valueRef.current = currentValue;
			setValue(currentValue);
		}
		return subscribe((newValue) => {
			valueRef.current = newValue;
			setValue(newValue);
		});
	}, [initializedSubscription, subscription]);
	return value;
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function subscription(editor) {
	return {
		initialValueFn: () => editor.isEditable(),
		subscribe: (callback) => {
			return editor.registerEditableListener(callback);
		}
	};
}
/**
* Get the current value for {@link LexicalEditor.isEditable}
* using {@link useLexicalSubscription}.
* You should prefer this over manually observing the value with
* {@link LexicalEditor.registerEditableListener},
* which is a bit tricky to do correctly, particularly when using
* React StrictMode (the default for development) or concurrency.
*/
function useLexicalEditable() {
	return useLexicalSubscription(subscription);
}
//#endregion
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalReactProviderExtension.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* An extension used to declare that there is a LexicalExtensionComposer or
* ReactPluginHostExtension available so that we can issue runtime warnings
* when plugins that depend on React are hosted in an environment
* where it is not ever going to be rendered.
*
* It is a separate extension so it can be used as a peer dependency.
*/
var ReactProviderExtension = defineExtension({ name: "@lexical/react/ReactProvider" });
//#endregion
//#region node_modules/.bun/@lexical+dragon@0.41.0/node_modules/@lexical/dragon/LexicalDragon.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function registerDragonSupport(editor) {
	const origin = window.location.origin;
	const handler = (event) => {
		if (event.origin !== origin) return;
		const rootElement = editor.getRootElement();
		if (document.activeElement !== rootElement) return;
		const data = event.data;
		if (typeof data === "string") {
			let parsedData;
			try {
				parsedData = JSON.parse(data);
			} catch (_e) {
				return;
			}
			if (parsedData && parsedData.protocol === "nuanria_messaging" && parsedData.type === "request") {
				const payload = parsedData.payload;
				if (payload && payload.functionId === "makeChanges") {
					const args = payload.args;
					if (args) {
						const [elementStart, elementLength, text, selStart, selLength] = args;
						editor.update(() => {
							const selection = $getSelection();
							if ($isRangeSelection(selection)) {
								const anchor = selection.anchor;
								let anchorNode = anchor.getNode();
								let setSelStart = 0;
								let setSelEnd = 0;
								if ($isTextNode(anchorNode)) {
									if (elementStart >= 0 && elementLength >= 0) {
										setSelStart = elementStart;
										setSelEnd = elementStart + elementLength;
										selection.setTextNodeRange(anchorNode, setSelStart, anchorNode, setSelEnd);
									}
								}
								if (setSelStart !== setSelEnd || text !== "") {
									selection.insertRawText(text);
									anchorNode = anchor.getNode();
								}
								if ($isTextNode(anchorNode)) {
									setSelStart = selStart;
									setSelEnd = selStart + selLength;
									const anchorNodeTextLength = anchorNode.getTextContentSize();
									setSelStart = setSelStart > anchorNodeTextLength ? anchorNodeTextLength : setSelStart;
									setSelEnd = setSelEnd > anchorNodeTextLength ? anchorNodeTextLength : setSelEnd;
									selection.setTextNodeRange(anchorNode, setSelStart, anchorNode, setSelEnd);
								}
								event.stopImmediatePropagation();
							}
						});
					}
				}
			}
		}
	};
	window.addEventListener("message", handler, true);
	return () => {
		window.removeEventListener("message", handler, true);
	};
}
/**
* Add Dragon speech to text input support to the editor, via the
* \@lexical/dragon module.
*/
var DragonExtension = defineExtension({
	build: (editor, config, state) => namedSignals(config),
	config: safeCast({ disabled: typeof window === "undefined" }),
	name: "@lexical/dragon",
	register: (editor, config, state) => E(() => state.getOutput().disabled.value ? void 0 : registerDragonSupport(editor))
});
//#endregion
//#region node_modules/.bun/@lexical+html@0.41.0/node_modules/@lexical/html/LexicalHtml.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function $generateHtmlFromNodes(editor, selection) {
	if (typeof document === "undefined" || typeof window === "undefined" && typeof global.window === "undefined") throw new Error("To use $generateHtmlFromNodes in headless mode please initialize a headless browser implementation such as JSDom before calling this function.");
	const container = document.createElement("div");
	const topLevelChildren = $getRoot().getChildren();
	for (let i = 0; i < topLevelChildren.length; i++) {
		const topLevelNode = topLevelChildren[i];
		$appendNodesToHTML(editor, topLevelNode, container, selection);
	}
	return container.innerHTML;
}
function $appendNodesToHTML(editor, currentNode, parentElement, selection = null) {
	let shouldInclude = selection !== null ? currentNode.isSelected(selection) : true;
	const shouldExclude = $isElementNode(currentNode) && currentNode.excludeFromCopy("html");
	let target = currentNode;
	if (selection !== null && $isTextNode(currentNode)) target = $sliceSelectedTextNodeContent(selection, currentNode, "clone");
	const children = $isElementNode(target) ? target.getChildren() : [];
	const registeredNode = getRegisteredNode(editor, target.getType());
	let exportOutput;
	if (registeredNode && registeredNode.exportDOM !== void 0) exportOutput = registeredNode.exportDOM(editor, target);
	else exportOutput = target.exportDOM(editor);
	const { element, after } = exportOutput;
	if (!element) return false;
	const fragment = document.createDocumentFragment();
	for (let i = 0; i < children.length; i++) {
		const childNode = children[i];
		const shouldIncludeChild = $appendNodesToHTML(editor, childNode, fragment, selection);
		if (!shouldInclude && $isElementNode(currentNode) && shouldIncludeChild && currentNode.extractWithChild(childNode, selection, "html")) shouldInclude = true;
	}
	if (shouldInclude && !shouldExclude) {
		if (isHTMLElement(element) || isDocumentFragment(element)) element.append(fragment);
		parentElement.append(element);
		if (after) {
			const newElement = after.call(target, element);
			if (newElement) if (isDocumentFragment(element)) element.replaceChildren(newElement);
			else element.replaceWith(newElement);
		}
	} else parentElement.append(fragment);
	return shouldInclude;
}
//#endregion
//#region node_modules/.bun/@lexical+clipboard@0.41.0/node_modules/@lexical/clipboard/LexicalClipboard.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function formatDevErrorMessage$1(message) {
	throw new Error(message);
}
/**
* Returns the *currently selected* Lexical content as an HTML string, relying on the
* logic defined in the exportDOM methods on the LexicalNode classes. Note that
* this will not return the HTML content of the entire editor (unless all the content is included
* in the current selection).
*
* @param editor - LexicalEditor instance to get HTML content from
* @param selection - The selection to use (default is $getSelection())
* @returns a string of HTML content
*/
function $getHtmlContent(editor, selection = $getSelection()) {
	if (selection == null) formatDevErrorMessage$1(`Expected valid LexicalSelection`);
	if ($isRangeSelection(selection) && selection.isCollapsed() || selection.getNodes().length === 0) return "";
	return $generateHtmlFromNodes(editor, selection);
}
/**
* Attempts to insert content of the mime-types text/plain or text/uri-list from
* the provided DataTransfer object into the editor at the provided selection.
* text/uri-list is only used if text/plain is not also provided.
*
* @param dataTransfer an object conforming to the [DataTransfer interface] (https://html.spec.whatwg.org/multipage/dnd.html#the-datatransfer-interface)
* @param selection the selection to use as the insertion point for the content in the DataTransfer object
*/
function $insertDataTransferForPlainText(dataTransfer, selection) {
	const text = dataTransfer.getData("text/plain") || dataTransfer.getData("text/uri-list");
	if (text != null) selection.insertRawText(text);
}
//#endregion
//#region node_modules/.bun/@lexical+plain-text@0.41.0/node_modules/@lexical/plain-text/LexicalPlainText.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var CAN_USE_DOM = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var documentMode = CAN_USE_DOM && "documentMode" in document ? document.documentMode : null;
var IS_APPLE = CAN_USE_DOM && /Mac|iPod|iPhone|iPad/.test(navigator.platform);
var CAN_USE_BEFORE_INPUT = CAN_USE_DOM && "InputEvent" in window && !documentMode ? "getTargetRanges" in new window.InputEvent("input") : false;
var IS_SAFARI = CAN_USE_DOM && /Version\/[\d.]+.*Safari/.test(navigator.userAgent);
var IS_IOS = CAN_USE_DOM && /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
var IS_CHROME = CAN_USE_DOM && /^(?=.*Chrome).*/i.test(navigator.userAgent);
var IS_APPLE_WEBKIT = CAN_USE_DOM && /AppleWebKit\/[\d.]+/.test(navigator.userAgent) && IS_APPLE && !IS_CHROME;
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function onCopyForPlainText(event, editor) {
	editor.update(() => {
		if (event !== null) {
			const clipboardData = objectKlassEquals(event, KeyboardEvent) ? null : event.clipboardData;
			const selection = $getSelection();
			if (selection !== null && !selection.isCollapsed() && clipboardData != null) {
				event.preventDefault();
				const htmlString = $getHtmlContent(editor);
				if (htmlString !== null) clipboardData.setData("text/html", htmlString);
				clipboardData.setData("text/plain", selection.getTextContent());
			}
		}
	});
}
function onPasteForPlainText(event, editor) {
	event.preventDefault();
	editor.update(() => {
		const selection = $getSelection();
		const clipboardData = objectKlassEquals(event, ClipboardEvent) ? event.clipboardData : null;
		if (clipboardData != null && $isRangeSelection(selection)) $insertDataTransferForPlainText(clipboardData, selection);
	}, { tag: PASTE_TAG });
}
function onCutForPlainText(event, editor) {
	onCopyForPlainText(event, editor);
	editor.update(() => {
		const selection = $getSelection();
		if ($isRangeSelection(selection)) selection.removeText();
	});
}
function registerPlainText(editor) {
	return mergeRegister(editor.registerCommand(DELETE_CHARACTER_COMMAND, (isBackward) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		selection.deleteCharacter(isBackward);
		return true;
	}, 0), editor.registerCommand(DELETE_WORD_COMMAND, (isBackward) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		selection.deleteWord(isBackward);
		return true;
	}, 0), editor.registerCommand(DELETE_LINE_COMMAND, (isBackward) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		selection.deleteLine(isBackward);
		return true;
	}, 0), editor.registerCommand(CONTROLLED_TEXT_INSERTION_COMMAND, (eventOrText) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		if (typeof eventOrText === "string") selection.insertText(eventOrText);
		else {
			const dataTransfer = eventOrText.dataTransfer;
			if (dataTransfer != null) $insertDataTransferForPlainText(dataTransfer, selection);
			else {
				const data = eventOrText.data;
				if (data) selection.insertText(data);
			}
		}
		return true;
	}, 0), editor.registerCommand(REMOVE_TEXT_COMMAND, () => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		selection.removeText();
		return true;
	}, 0), editor.registerCommand(INSERT_LINE_BREAK_COMMAND, (selectStart) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		selection.insertLineBreak(selectStart);
		return true;
	}, 0), editor.registerCommand(INSERT_PARAGRAPH_COMMAND, () => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		selection.insertLineBreak();
		return true;
	}, 0), editor.registerCommand(KEY_ARROW_LEFT_COMMAND, (payload) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		const event = payload;
		const isHoldingShift = event.shiftKey;
		if ($shouldOverrideDefaultCharacterSelection(selection, true)) {
			event.preventDefault();
			$moveCharacter(selection, isHoldingShift, true);
			return true;
		}
		return false;
	}, 0), editor.registerCommand(KEY_ARROW_RIGHT_COMMAND, (payload) => {
		const selection = $getSelection();
		if (!$isRangeSelection(selection)) return false;
		const event = payload;
		const isHoldingShift = event.shiftKey;
		if ($shouldOverrideDefaultCharacterSelection(selection, false)) {
			event.preventDefault();
			$moveCharacter(selection, isHoldingShift, false);
			return true;
		}
		return false;
	}, 0), editor.registerCommand(KEY_BACKSPACE_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		if (IS_IOS && navigator.language === "ko-KR") return false;
		event.preventDefault();
		return editor.dispatchCommand(DELETE_CHARACTER_COMMAND, true);
	}, 0), editor.registerCommand(KEY_DELETE_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		event.preventDefault();
		return editor.dispatchCommand(DELETE_CHARACTER_COMMAND, false);
	}, 0), editor.registerCommand(KEY_ENTER_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		if (event !== null) {
			if ((IS_IOS || IS_SAFARI || IS_APPLE_WEBKIT) && CAN_USE_BEFORE_INPUT) return false;
			event.preventDefault();
		}
		return editor.dispatchCommand(INSERT_LINE_BREAK_COMMAND, false);
	}, 0), editor.registerCommand(SELECT_ALL_COMMAND, () => {
		$selectAll();
		return true;
	}, 0), editor.registerCommand(COPY_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		onCopyForPlainText(event, editor);
		return true;
	}, 0), editor.registerCommand(CUT_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		onCutForPlainText(event, editor);
		return true;
	}, 0), editor.registerCommand(PASTE_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		onPasteForPlainText(event, editor);
		return true;
	}, 0), editor.registerCommand(DROP_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		event.preventDefault();
		return true;
	}, 0), editor.registerCommand(DRAGSTART_COMMAND, (event) => {
		if (!$isRangeSelection($getSelection())) return false;
		event.preventDefault();
		return true;
	}, 0));
}
defineExtension({
	conflictsWith: ["@lexical/rich-text"],
	dependencies: [DragonExtension],
	name: "@lexical/plain-text",
	register: registerPlainText
});
//#endregion
//#region node_modules/.bun/@lexical+react@0.41.0+367b9348b1de5bcd/node_modules/@lexical/react/LexicalPlainTextPlugin.dev.mjs
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function formatDevErrorMessage(message) {
	throw new Error(message);
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
var useLayoutEffectImpl = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function useDecorators(editor, ErrorBoundary) {
	const [decorators, setDecorators] = (0, import_react.useState)(() => editor.getDecorators());
	useLayoutEffectImpl(() => {
		return editor.registerDecoratorListener((nextDecorators) => {
			(0, import_react_dom.flushSync)(() => {
				setDecorators(nextDecorators);
			});
		});
	}, [editor]);
	(0, import_react.useEffect)(() => {
		setDecorators(editor.getDecorators());
	}, [editor]);
	return (0, import_react.useMemo)(() => {
		const decoratedPortals = [];
		const decoratorKeys = Object.keys(decorators);
		for (let i = 0; i < decoratorKeys.length; i++) {
			const nodeKey = decoratorKeys[i];
			const reactDecorator = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ErrorBoundary, {
				onError: (e) => editor._onError(e),
				children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
					fallback: null,
					children: decorators[nodeKey]
				})
			});
			const element = editor.getElementByKey(nodeKey);
			if (element !== null) decoratedPortals.push(/*#__PURE__*/ (0, import_react_dom.createPortal)(reactDecorator, element, nodeKey));
		}
		return decoratedPortals;
	}, [
		ErrorBoundary,
		decorators,
		editor
	]);
}
function isUsingReactExtension(editor) {
	const builder = LexicalBuilder.maybeFromEditor(editor);
	if (builder && builder.hasExtensionByName(ReactProviderExtension.name)) {
		for (const name of ["@lexical/plain-text", "@lexical/rich-text"]) if (!!builder.hasExtensionByName(name)) formatDevErrorMessage(`LexicalBuilder: @lexical/react legacy text plugins conflict with the ${name} extension. Remove the legacy <RichTextPlugin/> or <PlainTextPlugin/> component.`);
		return true;
	}
	return false;
}
function Decorators({ editor, ErrorBoundary }) {
	return useDecorators(editor, ErrorBoundary);
}
/**
* @internal
*
* When using @lexical/extension, the ReactProvider is expected to handle
* rendering decorators. This component allows RichTextPlugin and
* PlainTextPlugin to be used in extension projects that have not yet
* migrated to use RichTextExtension or PlainTextExtension.
**/
function LegacyDecorators({ editor, ErrorBoundary }) {
	return isUsingReactExtension(editor) ? null : /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Decorators, {
		editor,
		ErrorBoundary
	});
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function canShowPlaceholderFromCurrentEditorState(editor) {
	return editor.getEditorState().read($canShowPlaceholderCurry(editor.isComposing()));
}
function useCanShowPlaceholder(editor) {
	const [canShowPlaceholder, setCanShowPlaceholder] = (0, import_react.useState)(() => canShowPlaceholderFromCurrentEditorState(editor));
	useLayoutEffectImpl(() => {
		function resetCanShowPlaceholder() {
			const currentCanShowPlaceholder = canShowPlaceholderFromCurrentEditorState(editor);
			setCanShowPlaceholder(currentCanShowPlaceholder);
		}
		resetCanShowPlaceholder();
		return mergeRegister(editor.registerUpdateListener(() => {
			resetCanShowPlaceholder();
		}), editor.registerEditableListener(() => {
			resetCanShowPlaceholder();
		}));
	}, [editor]);
	return canShowPlaceholder;
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function usePlainTextSetup(editor) {
	useLayoutEffectImpl(() => {
		return mergeRegister(registerPlainText(editor), registerDragonSupport(editor));
	}, [editor]);
}
/**
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*
*/
function PlainTextPlugin({ contentEditable, placeholder = null, ErrorBoundary }) {
	const [editor] = useLexicalComposerContext();
	usePlainTextSetup(editor);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		contentEditable,
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(Placeholder, { content: placeholder }),
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(LegacyDecorators, {
			editor,
			ErrorBoundary
		})
	] });
}
function Placeholder({ content }) {
	const [editor] = useLexicalComposerContext();
	const showPlaceholder = useCanShowPlaceholder(editor);
	const editable = useLexicalEditable();
	if (!showPlaceholder) return null;
	if (typeof content === "function") return content(editable);
	else return content;
}
//#endregion
export { PlainTextPlugin };
