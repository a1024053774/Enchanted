import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { t as createChangeEventDetails, v as none } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { t as error } from "./error-scG2ld3p.js";
import { t as useButton } from "./useButton-vy-VFWTJ.js";
import { t as useBaseUiId } from "./useBaseUiId-BBG3KkG2.js";
import { t as useControlled } from "./useControlled-tPZe1TD5.js";
import { t as CompositeItem } from "./CompositeItem-CTgtes9c.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toggle-group/ToggleGroupContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var ToggleGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
ToggleGroupContext.displayName = "ToggleGroupContext";
function useToggleGroupContext() {
	return import_react.useContext(ToggleGroupContext);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toggle/Toggle.mjs
var import_jsx_runtime = require_jsx_runtime();
var Toggle = /*#__PURE__*/ import_react.forwardRef(function Toggle(componentProps, forwardedRef) {
	const { className, defaultPressed: defaultPressedProp = false, disabled: disabledProp = false, form, onPressedChange, pressed: pressedProp, render, type, value: valueProp, nativeButton = true, style, ...elementProps } = componentProps;
	const value = useBaseUiId(valueProp || void 0);
	const groupContext = useToggleGroupContext();
	const groupValue = groupContext?.value ?? [];
	const defaultPressed = groupContext ? void 0 : defaultPressedProp;
	const disabled = (disabledProp || groupContext?.disabled) ?? false;
	import_react.useEffect(() => {
		if (groupContext && valueProp === void 0 && groupContext.isValueInitialized) error("A `<Toggle>` component rendered in a `<ToggleGroup>` has no explicit `value` prop.", "This will cause issues between the Toggle Group and Toggle values.", "Provide the `<Toggle>` with a `value` prop matching the `<ToggleGroup>` values prop type.");
	}, [
		groupContext,
		valueProp,
		groupContext?.isValueInitialized
	]);
	const [pressed, setPressedState] = useControlled({
		controlled: groupContext ? value !== void 0 && groupValue.indexOf(value) > -1 : pressedProp,
		default: defaultPressed,
		name: "Toggle",
		state: "pressed"
	});
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = {
		disabled,
		pressed
	};
	const refs = [buttonRef, forwardedRef];
	const props = [
		{
			"aria-pressed": pressed,
			onClick(event) {
				const nextPressed = !pressed;
				const details = createChangeEventDetails(none, event.nativeEvent);
				onPressedChange?.(nextPressed, details);
				if (details.isCanceled) return;
				if (value) groupContext?.setGroupValue?.(value, nextPressed, details);
				if (details.isCanceled) return;
				setPressedState(nextPressed);
			}
		},
		elementProps,
		getButtonProps
	];
	const element = useRenderElement("button", componentProps, {
		enabled: !groupContext,
		state,
		ref: refs,
		props
	});
	const itemMetadata = import_react.useMemo(() => ({
		disabled,
		focusableWhenDisabled: false
	}), [disabled]);
	if (groupContext) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeItem, {
		tag: "button",
		render,
		className,
		style,
		metadata: itemMetadata,
		state,
		refs,
		props
	});
	return element;
});
Toggle.displayName = "Toggle";
//#endregion
export { Toggle };
