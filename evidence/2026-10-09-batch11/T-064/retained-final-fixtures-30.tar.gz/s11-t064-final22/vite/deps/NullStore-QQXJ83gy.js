import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { c as ReactStore, o as PopupTriggerMap, s as FloatingRootStore } from "./inertValue-C-bH78NQ.js";
import { c as NOOP, s as EMPTY_OBJECT } from "./useRenderElement-CvLulVDb.js";
import { t as AnimationFrame } from "./useAnimationFrame-CNfBoYED.js";
import { d as imperativeAction, t as createChangeEventDetails } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { t as require_shim } from "./shim-DgmQmt-v.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/popups/popupHandle.mjs
/**
* Minimal store contract exposed by popup handles to detached triggers.
*
* Detached triggers read `store` during render and subscribe to be notified when the handle switches
* between its fallback store and a root's live store.
*
* @template HandleStore Store shape exposed to detached triggers.
*/
/**
* Store shape holding a trigger registry, required by `BasePopupHandle.openByTrigger` to resolve a
* trigger element by id on both the attached root's store and the fallback store.
*/
/**
* Store shape required by `BasePopupHandle.openByTrigger`/`closePopup` to drive open/close state.
* Only the root-owned `Store` needs this — the `HandleStore` view exposed to detached triggers may
* omit `setOpen` entirely (as Dialog and PreviewCard's do) since it is never called while detached.
*/
/**
* Shared implementation for popup handles that coordinate detached triggers with a mounted root.
*
* Subclasses provide the component-specific imperative methods, while this base class owns the
* fallback store, root store attachment stack, subscriber notifications, and development warning for
* overlapping roots.
*
* @template HandleStore Store shape exposed to detached triggers.
* @template Store Root-owned store attached by the component root.
*/
var BasePopupHandle = class {
	/**
	* Stores of every root currently using this handle, in attach order. A handle is meant to be used
	* by a single mounted root, but roots can transiently overlap (e.g. during an animated route
	* transition), so this stack lets `attachStore`'s cleanup restore the previous root instead of
	* leaving a still-mounted root uncontrollable when a newer overlapping root detaches first.
	*/
	attachedStores = [];
	/**
	* Store of the root that currently controls the handle: the most recently attached one still
	* mounted, or `null` when no root is attached. Imperative methods are no-ops while this is `null`.
	*/
	attachedStoreValue = null;
	/**
	* Listeners notified when `attachedStore` changes, so detached triggers can follow the store pointer.
	*/
	storeListeners = /* @__PURE__ */ new Set();
	/**
	* Creates a handle backed by the store used while no root is attached.
	*
	* @param fallbackStore Inert, closed store handed to detached triggers while no root is attached,
	* so they can render and register without a mounted root. Triggers register into whichever store
	* `store` currently resolves to, so while detached they live in this store's trigger map and
	* migrate themselves to the root's store (and back) as it attaches/detaches.
	* @param componentName Component name used to prefix dev warnings, e.g. `'Menu'` produces
	* `MenuHandle.open()` in warning text.
	* @param throwOnMissingTrigger Whether `open(triggerId)` throws when no trigger with that id is
	* registered. Anchored popups (Menu, Popover, Tooltip, PreviewCard) need a trigger to anchor to,
	* so they throw; Dialog is not anchored and instead opens unassociated with a dev warning.
	*/
	constructor(fallbackStore, componentName, throwOnMissingTrigger = true) {
		this.fallbackStore = fallbackStore;
		this.componentName = componentName;
		this.throwOnMissingTrigger = throwOnMissingTrigger;
	}
	get attachedStore() {
		return this.attachedStoreValue;
	}
	/**
	* Store that detached triggers read from: the attached root's store, or an inert fallback store
	* used while no root is attached.
	* @internal
	*/
	get store() {
		return this.attachedStoreValue ?? this.fallbackStore;
	}
	/**
	* Stable fallback store used for server rendering and hydration. Root stores cannot be recorded on
	* the handle during render because a handle can be shared by concurrent server-rendered requests.
	* @internal
	*/
	get serverStore() {
		return this.fallbackStore;
	}
	/**
	* Subscribes to changes of the attached store pointer so detached triggers re-render and re-bind
	* when a root attaches or detaches. Returns a function that removes the listener.
	* @internal
	*/
	subscribeStore(listener) {
		this.storeListeners.add(listener);
		return () => {
			this.storeListeners.delete(listener);
		};
	}
	/**
	* Points the handle at a root's store and notifies subscribers so detached triggers re-render and
	* re-register into it (their registration ref re-fires on the store-pointer change). Returns a
	* cleanup function that detaches the store again.
	* @internal
	*/
	attachStore(newStore) {
		this.attachedStores.push(newStore);
		this.setActiveStore(newStore);
		if (this.attachedStores.length > 1) {
			const dev = this;
			(dev.overlapWarningFrame ??= AnimationFrame.create()).request(() => {
				if (this.attachedStores.length > 1) console.warn("Base UI: A handle is attached to more than one mounted root at the same time. The most recently mounted root takes over and the previous one stops being controlled by the handle. A handle should be used by a single root that stays mounted for the lifetime of the handle.");
			});
		}
		return () => {
			const index = this.attachedStores.lastIndexOf(newStore);
			if (index !== -1) this.attachedStores.splice(index, 1);
			this.setActiveStore(this.attachedStores[this.attachedStores.length - 1] ?? null);
		};
	}
	/**
	* Sets the store that currently controls the handle and notifies subscribers when it changes, so
	* detached triggers re-render and migrate their registration to the new store.
	*/
	setActiveStore(store) {
		if (this.attachedStoreValue !== store) {
			this.attachedStoreValue = store;
			this.storeListeners.forEach((listener) => {
				listener();
			});
		}
	}
	/**
	* Opens the attached root's store and associates it with the trigger with the given id, or a
	* no-op (with a dev warning) while no root is attached. Shared by every concrete handle's public
	* `open()` method, which only narrows the parameter type.
	*
	* When a trigger id is given but no matching trigger is registered, anchored popups throw (see
	* `throwOnMissingTrigger`); Dialog opens unassociated with a dev warning instead.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the popup, or `null`/`undefined` to open
	* without associating any trigger.
	*/
	openByTrigger(triggerId) {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn(`Base UI: ${this.componentName}Handle.open() was called while no root using this handle is mounted. The call was ignored; mount a root with this handle before opening it imperatively.`);
			return;
		}
		let triggerElement;
		if (triggerId) {
			for (let i = this.attachedStores.length - 1; i >= 0 && !triggerElement; i -= 1) triggerElement = this.attachedStores[i].context.triggerElements.getById(triggerId);
			triggerElement ??= this.fallbackStore.context.triggerElements.getById(triggerId);
		}
		if (triggerId && !triggerElement) {
			if (this.throwOnMissingTrigger) throw new Error(`Base UI: ${this.componentName}Handle.open() was called with the trigger id "${triggerId}", but no matching trigger is registered with this handle. An anchored popup cannot open without a trigger to anchor to. Pass the id of a mounted ${this.componentName}.Trigger that has this handle set on its "handle" prop.`);
			console.warn(`Base UI: ${this.componentName}Handle.open: No trigger found with id "${triggerId}". The popup will open, but the trigger will not be associated with it.`);
		}
		attachedStore.setOpen(true, createChangeEventDetails(imperativeAction, void 0, triggerElement));
	}
	/**
	* Closes the popup by setting the attached root's store to closed, or a no-op (with a dev warning)
	* while no root is attached. Shared by every concrete handle's public `close()` method.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	closePopup() {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn(`Base UI: ${this.componentName}Handle.close() was called while no root using this handle is mounted. The call was ignored.`);
			return;
		}
		attachedStore.setOpen(false, createChangeEventDetails(imperativeAction));
	}
};
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/floating-ui-react/utils/getEmptyRootContext.mjs
function getEmptyRootContext() {
	return new FloatingRootStore({
		open: false,
		transitionStatus: void 0,
		floatingElement: null,
		referenceElement: null,
		triggerElements: new PopupTriggerMap(),
		floatingId: void 0,
		syncOnly: false,
		nested: false,
		onOpenChange: void 0
	});
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/popups/store.mjs
/**
* State common to all popup stores.
*/
function createInitialPopupStoreState() {
	return {
		open: false,
		openProp: void 0,
		mounted: false,
		transitionStatus: void 0,
		floatingRootContext: getEmptyRootContext(),
		floatingId: void 0,
		triggerCount: 0,
		preventUnmountingOnClose: false,
		payload: void 0,
		activeTriggerId: null,
		activeTriggerElement: null,
		triggerIdProp: void 0,
		popupElement: null,
		positionerElement: null,
		activeTriggerProps: EMPTY_OBJECT,
		inactiveTriggerProps: EMPTY_OBJECT,
		popupProps: EMPTY_OBJECT
	};
}
function createPopupFloatingRootContext(triggerElements, floatingId, nested = false) {
	return new FloatingRootStore({
		open: false,
		transitionStatus: void 0,
		floatingElement: null,
		referenceElement: null,
		triggerElements,
		floatingId,
		syncOnly: true,
		nested,
		onOpenChange: void 0
	});
}
var activeTriggerIdSelector = (state) => state.triggerIdProp ?? state.activeTriggerId;
var openSelector = (state) => state.openProp ?? state.open;
var popupIdSelector = (state) => {
	return (state.popupElement?.id ?? state.floatingId) || void 0;
};
function triggerOwnsOpenPopup(state, triggerId) {
	return triggerId !== void 0 && openSelector(state) && activeTriggerIdSelector(state) === triggerId;
}
function triggerOwnsOpenPopupOrIsOnlyTrigger(state, triggerId) {
	if (triggerOwnsOpenPopup(state, triggerId)) return true;
	return triggerId !== void 0 && openSelector(state) && activeTriggerIdSelector(state) == null && state.triggerCount === 1;
}
var popupStoreSelectors = {
	open: openSelector,
	mounted: (state) => state.mounted,
	transitionStatus: (state) => state.transitionStatus,
	floatingRootContext: (state) => state.floatingRootContext,
	triggerCount: (state) => state.triggerCount,
	preventUnmountingOnClose: (state) => state.preventUnmountingOnClose,
	payload: (state) => state.payload,
	activeTriggerId: activeTriggerIdSelector,
	activeTriggerElement: (state) => state.mounted ? state.activeTriggerElement : null,
	popupId: popupIdSelector,
	/**
	* Whether the trigger with the given ID was used to open the popup.
	*/
	isTriggerActive: (state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId,
	/**
	* Whether the popup is open and was activated by a trigger with the given ID.
	*/
	isOpenedByTrigger: (state, triggerId) => triggerOwnsOpenPopup(state, triggerId),
	/**
	* Whether the popup is mounted and was activated by a trigger with the given ID.
	*/
	isMountedByTrigger: (state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId && state.mounted,
	triggerProps: (state, isActive) => isActive ? state.activeTriggerProps : state.inactiveTriggerProps,
	/**
	* Popup id for the trigger that currently owns the open popup.
	*/
	triggerPopupId: (state, triggerId) => triggerOwnsOpenPopupOrIsOnlyTrigger(state, triggerId) ? popupIdSelector(state) : void 0,
	popupProps: (state) => state.popupProps,
	popupElement: (state) => state.popupElement,
	positionerElement: (state) => state.positionerElement
};
/**
* Store members a detached handle-backed trigger reads or invokes for trigger registration and data
* forwarding. `set`/`update` are included only for trigger-count and trigger-data bookkeeping; on a
* detached (inert) store they are intentionally no-ops, so a write through them is not guaranteed to
* be durable. Component handle-store views Pick these from their concrete store (preserving its
* context and selectors) and add any component-specific trigger-invoked members such as `setOpen`.
*/
/**
* The subset of a popup store that trigger registration and data forwarding rely on. Narrow enough
* that an inert store can be passed while detached.
*/
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/popups/usePopupHandleStore.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_shim = require_shim();
/**
* Reads the store currently exposed by a popup handle and subscribes to store-pointer changes.
* Detached triggers use this to follow a handle as a root attaches or detaches: while no root is
* attached, the handle exposes its fallback store; once a root attaches, subscribers re-render and
* read from the live root store.
*
* Returns `undefined` when no handle is provided so callers can fall back to their root context.
*
* @param handle The popup handle to read from, or `undefined` when the trigger is not handle-bound.
*/
function usePopupHandleStore(handle) {
	return (0, import_shim.useSyncExternalStore)(import_react.useCallback((listener) => {
		if (handle === void 0) return NOOP;
		return handle.subscribeStore(listener);
	}, [handle]), import_react.useCallback(() => {
		return handle === void 0 ? void 0 : handle.store;
	}, [handle]), () => handle?.serverStore);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/NullStore.mjs
/**
* A `ReactStore` whose state never changes.
*
* Useful for fallback stores that need to support normal store reads while detached from the
* component that owns real state. Context values may still contain mutable refs or maps.
*/
var NullStore = class extends ReactStore {
	setState(_newState) {}
	update(_changes) {}
	set(_key, _value) {}
	notifyAll() {}
};
//#endregion
export { popupStoreSelectors as a, createPopupFloatingRootContext as i, usePopupHandleStore as n, BasePopupHandle as o, createInitialPopupStoreState as r, NullStore as t };
