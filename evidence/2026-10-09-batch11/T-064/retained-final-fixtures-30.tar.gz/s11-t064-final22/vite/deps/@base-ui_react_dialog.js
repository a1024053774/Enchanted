import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { a as DialogTitle, c as DialogDescription, d as useRenderDialogRoot, i as DialogTrigger, l as DialogClose, n as createDialogHandle, o as DialogPortal, r as DialogViewport, s as DialogPopup, t as DialogHandle, u as DialogBackdrop } from "./DialogHandle-BK30-wrq.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/dialog/root/DialogRoot.mjs
/**
* Groups all parts of the dialog.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
function DialogRoot(props) {
	return useRenderDialogRoot("dialog", props);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/dialog/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Backdrop: () => DialogBackdrop,
	Close: () => DialogClose,
	Description: () => DialogDescription,
	Handle: () => DialogHandle,
	Popup: () => DialogPopup,
	Portal: () => DialogPortal,
	Root: () => DialogRoot,
	Title: () => DialogTitle,
	Trigger: () => DialogTrigger,
	Viewport: () => DialogViewport,
	createHandle: () => createDialogHandle
});
//#endregion
export { index_parts_exports as Dialog };
