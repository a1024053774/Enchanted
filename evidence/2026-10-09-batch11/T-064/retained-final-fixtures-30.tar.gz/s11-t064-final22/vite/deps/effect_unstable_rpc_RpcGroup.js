import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { tt as identity } from "./Equal-CgzkNqbP.js";
import { Al as empty, At as isEffect, Fl as make$1, Il as makeUnsafe, Ll as merge, Oo as effectServices, ar as services, kl as add, or as servicesWith, ur as succeed, vn as provide, wt as gen } from "./Effect-DrBRDdmt.js";
import { v as provideServices } from "./PrimaryKey-BilJj_MP.js";
import { a as isWrapper } from "./Rpc-DrEN5nNz.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/unstable/rpc/RpcGroup.js
var RpcGroup_exports = /* @__PURE__ */ __exportAll({ make: () => make });
var RpcGroupProto = {
	add(...rpcs) {
		const requests = new Map(this.requests);
		for (const rpc of rpcs) requests.set(rpc._tag, rpc);
		return makeProto({
			requests,
			annotations: this.annotations
		});
	},
	merge(...groups) {
		const requests = new Map(this.requests);
		const annotations = new Map(this.annotations.mapUnsafe);
		for (const group of groups) {
			for (const [tag, rpc] of group.requests) requests.set(tag, rpc);
			for (const [key, value] of group.annotations.mapUnsafe) annotations.set(key, value);
		}
		return makeProto({
			requests,
			annotations: makeUnsafe(annotations)
		});
	},
	middleware(middleware) {
		const requests = /* @__PURE__ */ new Map();
		for (const [tag, rpc] of this.requests) requests.set(tag, rpc.middleware(middleware));
		return makeProto({
			requests,
			annotations: this.annotations
		});
	},
	toHandlers(build) {
		const self = this;
		return gen(function* () {
			const services$1 = yield* services();
			const handlers = isEffect(build) ? yield* build : build;
			const contextMap = /* @__PURE__ */ new Map();
			for (const [tag, handler] of Object.entries(handlers)) {
				const rpc = self.requests.get(tag);
				contextMap.set(rpc.key, {
					tag: rpc._tag,
					handler,
					services: services$1
				});
			}
			return makeUnsafe(contextMap);
		});
	},
	prefix(prefix) {
		const requests = /* @__PURE__ */ new Map();
		for (const rpc of this.requests.values()) {
			const newRpc = rpc.prefix(prefix);
			requests.set(newRpc._tag, newRpc);
		}
		return makeProto({
			requests,
			annotations: this.annotations
		});
	},
	toLayer(build) {
		return effectServices(this.toHandlers(build));
	},
	of: identity,
	toLayerHandler(service, build) {
		const self = this;
		return effectServices(gen(function* () {
			const services$2 = yield* services();
			const handler = isEffect(build) ? yield* build : build;
			const contextMap = /* @__PURE__ */ new Map();
			const rpc = self.requests.get(service);
			contextMap.set(rpc.key, {
				handler,
				services: services$2
			});
			return makeUnsafe(contextMap);
		}));
	},
	accessHandler(service) {
		return servicesWith((parentServices) => {
			const rpc = this.requests.get(service);
			const { handler, services } = parentServices.mapUnsafe.get(rpc.key);
			return succeed((payload, options) => {
				options.rpc = rpc;
				const result = handler(payload, options);
				const effectOrStream = isWrapper(result) ? result.value : result;
				return isEffect(effectOrStream) ? provide(effectOrStream, services) : provideServices(effectOrStream, services);
			});
		});
	},
	annotate(service, value) {
		return makeProto({
			requests: this.requests,
			annotations: add(this.annotations, service, value)
		});
	},
	annotateRpcs(service, value) {
		return this.annotateRpcsMerge(make$1(service, value));
	},
	annotateMerge(context) {
		return makeProto({
			requests: this.requests,
			annotations: merge(this.annotations, context)
		});
	},
	annotateRpcsMerge(serviceMap) {
		const requests = /* @__PURE__ */ new Map();
		for (const [tag, rpc] of this.requests) requests.set(tag, rpc.annotateMerge(merge(serviceMap, rpc.annotations)));
		return makeProto({
			requests,
			annotations: this.annotations
		});
	}
};
var makeProto = (options) => Object.assign(function() {}, RpcGroupProto, {
	requests: options.requests,
	annotations: options.annotations
});
/**
* @since 4.0.0
* @category groups
*/
var make = (...rpcs) => makeProto({
	requests: new Map(rpcs.map((rpc) => [rpc._tag, rpc])),
	annotations: empty()
});
//#endregion
export { make, RpcGroup_exports as t };
