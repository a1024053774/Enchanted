import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { Q as dual, ot as pipeArguments, rt as pipe, tt as identity, x as hasProperty } from "./Equal-CgzkNqbP.js";
import { Cr as strictEqual, Et as some, Ht as isLessThan$1, Q as isSuccess, Ut as isLessThanOrEqualTo$1, Vn as withFiber, Vt as isGreaterThanOrEqualTo$1, Y as getOrThrow, _t as getSuccess, at as succeed, nt as mapError } from "./Record-BrB0racz.js";
import { At as isEffect, B as delay, Bo as close, Bu as of, Dl as Service, Dt as interrupt, Eo as effect, Fr as try_, G as exit, Gt as map, Ht as logWithLevel, Io as Scope, Ir as undefined_, K as fail, Kl as fromInputUnsafe, Ko as provide, Ll as merge, Lr as uninterruptible, Mo as succeed$2, Ot as interruptible, P as catchTag, Rc as isLogLevelGreaterThan, Ro as addFinalizer, Rr as uninterruptibleMask, Ss as done, U as ensuring, V as die, Vr as updateServices, Wo as make$5, Wr as void_, Ws as CurrentErrorReporters$1, Xc as reportCauseUnsafe, Xr as withFiber$1, _l as MinimumLogLevel, _t as forkDetach, ar as services, bl as UnhandledLogLevel, ed as filter, er as scope, fn as onInterrupt, ft as fnUntraced, g as asVoid, hr as tap, ht as forever, id as headUnsafe, jl as get$1, kn as replicateEffect, ku as isArrayNonEmpty, m as as, mr as sync, nl as succeed$3, o as acquireUseRelease, oc as causePrettyError, po as Clock, pr as suspend, qs as LogLevelOrder, rd as head, st as flatMap, tu as toMillis, ur as succeed$1, vo as Error, vt as forkIn, w as catchCause, yo as TaggedError, zc as logLevelToOrder, zo as addFinalizerExit } from "./Effect-DrBRDdmt.js";
import { co as runChecks, so as makeFilter } from "./Schema-DuK_yWH0.js";
import { An as makeUnsafe$1, Jt as makeUnsafe, Pn as interrupt$1, dn as unbounded, in as offer, ln as take } from "./Channel-BalfMI2y.js";
import { A as fail$1, C as unwrap, M as unwrap$1, d as fromPull, j as forEach, o as fail$2 } from "./PrimaryKey-BilJj_MP.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Brand.js
/**
* This module provides types and utility functions to create and work with
* branded types, which are TypeScript types with an added type tag to prevent
* accidental usage of a value in the wrong context.
*
* @since 2.0.0
*/
var Brand_exports = /* @__PURE__ */ __exportAll({
	BrandError: () => BrandError,
	all: () => all,
	check: () => check,
	make: () => make$4,
	nominal: () => nominal
});
/**
* A `BrandError` is returned when a branded type is constructed from an invalid
* value.
*
* @category models
* @since 4.0.0
*/
var BrandError = class {
	constructor(issue) {
		this.issue = issue;
	}
	/**
	* @since 4.0.0
	*/
	_tag = "BrandError";
	/**
	* @since 4.0.0
	*/
	name = "BrandError";
	/**
	* @since 4.0.0
	*/
	issue;
	/**
	* @since 4.0.0
	*/
	get message() {
		return this.issue.toString();
	}
	/**
	* @since 4.0.0
	*/
	toString() {
		return `BrandError(${this.message})`;
	}
};
/**
* This function returns a `Constructor` that **does not apply any runtime
* checks**, it just returns the provided value. It can be used to create
* nominal types that allow distinguishing between two values of the same type
* but with different meanings.
*
* If you also want to perform some validation, see {@link make} or
* {@link check} or {@link refine}.
*
* @category constructors
* @since 2.0.0
*/
function nominal() {
	return Object.assign((input) => input, {
		option: (input) => some(input),
		result: (input) => succeed(input),
		is: (_) => true
	});
}
/**
* Returns a `Constructor` that can construct a branded type from an
* unbranded value using the provided `filter` predicate as validation of
* the input data.
*
* If you don't want to perform any validation but only distinguish between two
* values of the same type but with different meanings, see {@link nominal}.
*
* @category constructors
* @since 2.0.0
*/
function make$4(filter) {
	return check(makeFilter(filter));
}
/**
* @since 4.0.0
*/
function check(...checks) {
	const result = (input) => {
		return mapError(runChecks(checks, input), (issue) => new BrandError(issue));
	};
	return Object.assign((input) => getOrThrow(result(input)), {
		option: (input) => getSuccess(result(input)),
		result,
		is: (input) => isSuccess(result(input)),
		checks
	});
}
/**
* Combines two or more brands together to form a single branded type. This API
* is useful when you want to validate that the input data passes multiple brand
* validators.
*
* @category combining
* @since 2.0.0
*/
function all(...brands) {
	const checks = brands.flatMap((brand) => brand.checks ?? []);
	return isArrayNonEmpty(checks) ? check(...checks) : nominal();
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/PlatformError.js
/**
* @since 4.0.0
*/
var PlatformError_exports = /* @__PURE__ */ __exportAll({
	BadArgument: () => BadArgument,
	PlatformError: () => PlatformError,
	SystemError: () => SystemError,
	badArgument: () => badArgument,
	systemError: () => systemError
});
var TypeId$5 = "~effect/platform/PlatformError";
/**
* @since 4.0.0
* @category Models
*/
var BadArgument = class extends TaggedError("BadArgument") {
	/**
	* @since 4.0.0
	*/
	get message() {
		return `${this.module}.${this.method}${this.description ? `: ${this.description}` : ""}`;
	}
};
/**
* @since 4.0.0
* @category models
*/
var SystemError = class extends Error {
	/**
	* @since 4.0.0
	*/
	get message() {
		return `${this._tag}: ${this.module}.${this.method}${this.pathOrDescriptor !== void 0 ? ` (${this.pathOrDescriptor})` : ""}${this.description ? `: ${this.description}` : ""}`;
	}
};
/**
* @since 4.0.0
* @category Models
*/
var PlatformError = class extends TaggedError("PlatformError") {
	constructor(reason) {
		if ("cause" in reason) super({
			reason,
			cause: reason.cause
		});
		else super({ reason });
	}
	/**
	* @since 4.0.0
	*/
	[TypeId$5] = TypeId$5;
	get message() {
		return this.reason.message;
	}
};
/**
* @since 4.0.0
* @category constructors
*/
var systemError = (options) => new PlatformError(new SystemError(options));
/**
* @since 4.0.0
* @category constructors
*/
var badArgument = (options) => new PlatformError(new BadArgument(options));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/FileSystem.js
/**
* This module provides a comprehensive file system abstraction that supports both synchronous
* and asynchronous file operations through Effect. It includes utilities for file I/O, directory
* management, permissions, timestamps, and file watching with proper error handling.
*
* The `FileSystem` interface provides a cross-platform abstraction over file system operations,
* allowing you to work with files and directories in a functional, composable way. All operations
* return `Effect` values that can be composed, transformed, and executed safely.
*
* @example
* ```ts
* import { Console, Effect, FileSystem } from "effect"
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // Create a directory
*   yield* fs.makeDirectory("./temp", { recursive: true })
*
*   // Write a file
*   yield* fs.writeFileString("./temp/hello.txt", "Hello, World!")
*
*   // Read the file back
*   const content = yield* fs.readFileString("./temp/hello.txt")
*   yield* Console.log("File content:", content)
*
*   // Get file information
*   const stats = yield* fs.stat("./temp/hello.txt")
*   yield* Console.log("File size:", stats.size)
*
*   // Clean up
*   yield* fs.remove("./temp", { recursive: true })
* })
* ```
*
* @since 4.0.0
*/
var FileSystem_exports = /* @__PURE__ */ __exportAll({
	FileDescriptor: () => FileDescriptor,
	FileSystem: () => FileSystem,
	FileTypeId: () => FileTypeId,
	GiB: () => GiB,
	KiB: () => KiB,
	MiB: () => MiB,
	PiB: () => PiB,
	Size: () => Size,
	TiB: () => TiB,
	WatchBackend: () => WatchBackend,
	isFile: () => isFile,
	layerNoop: () => layerNoop,
	make: () => make$3,
	makeNoop: () => makeNoop
});
var TypeId$4 = "~effect/platform/FileSystem";
/**
* Creates a `Size` from various numeric input types.
*
* Converts numbers, bigints, or existing Size values into a properly
* branded Size type. This function handles the conversion and ensures
* type safety for file size operations.
*
* @example
* ```ts
* import { Effect, FileSystem } from "effect"
*
* // From number
* const size1 = FileSystem.Size(1024)
* console.log(typeof size1) // "bigint"
*
* // From bigint
* const size2 = FileSystem.Size(BigInt(2048))
*
* // From existing Size (identity)
* const size3 = FileSystem.Size(size1)
*
* // Use in file operations
* const readChunk = (path: string, chunkSize: number) =>
*   Effect.gen(function*() {
*     const fs = yield* FileSystem.FileSystem
*     return fs.stream(path, {
*       chunkSize: FileSystem.Size(chunkSize)
*     })
*   })
* ```
*
* @since 4.0.0
* @category sizes
*/
var Size = (bytes) => typeof bytes === "bigint" ? bytes : BigInt(bytes);
/**
* Creates a `Size` representing kilobytes (1024 bytes).
*
* Converts a number of kilobytes to the equivalent size in bytes.
* Uses binary kilobytes (1024 bytes) rather than decimal (1000 bytes).
*
* @example
* ```ts
* import { Effect, FileSystem } from "effect"
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // Create a 64 KiB buffer size for streaming
*   const bufferSize = FileSystem.KiB(64)
*
*   const stream = fs.stream("large-file.txt", {
*     chunkSize: bufferSize
*   })
*
*   // Truncate file to 100 KiB
*   yield* fs.truncate("data.txt", FileSystem.KiB(100))
* })
* ```
*
* @since 4.0.0
* @category sizes
*/
var KiB = (n) => Size(n * 1024);
/**
* Creates a `Size` representing mebibytes (1024² bytes).
*
* Converts a number of mebibytes to the equivalent size in bytes.
* Uses binary mebibytes (1,048,576 bytes) rather than decimal megabytes.
*
* @example
* ```ts
* import { Effect, FileSystem } from "effect"
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // Set a 10 MiB chunk size for large file operations
*   const largeChunkSize = FileSystem.MiB(10)
*
*   const stream = fs.stream("video.mp4", {
*     chunkSize: largeChunkSize
*   })
*
*   // Check if file is larger than 100 MiB
*   const stats = yield* fs.stat("archive.zip")
*   const maxSize = FileSystem.MiB(100)
*   if (stats.size > maxSize) {
*     yield* Effect.log("File is very large!")
*   }
* })
* ```
*
* @since 4.0.0
* @category sizes
*/
var MiB = (n) => Size(n * 1024 * 1024);
/**
* Creates a `Size` representing gibibytes (1024³ bytes).
*
* Converts a number of gibibytes to the equivalent size in bytes.
* Uses binary gibibytes (1,073,741,824 bytes) rather than decimal gigabytes.
*
* @example
* ```ts
* import { Console, Effect, FileSystem } from "effect"
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // Check available space before creating large files
*   const stats = yield* fs.stat(".")
*   const requiredSpace = FileSystem.GiB(5)
*
*   // Create a large temporary file
*   const tempFile = yield* fs.makeTempFile({ prefix: "large-" })
*   yield* fs.truncate(tempFile, FileSystem.GiB(1)) // 1 GiB file
*
*   yield* Console.log(`Created ${tempFile} with 1 GiB size`)
* })
* ```
*
* @since 4.0.0
* @category sizes
*/
var GiB = (n) => Size(n * 1024 * 1024 * 1024);
/**
* Creates a `Size` representing tebibytes (1024⁴ bytes).
*
* Converts a number of tebibytes to the equivalent size in bytes.
* Uses binary tebibytes (1,099,511,627,776 bytes) rather than decimal terabytes.
*
* @example
* ```ts
* import { Console, Effect, FileSystem } from "effect"
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // Check if we're dealing with very large files
*   const stats = yield* fs.stat("database-backup.sql")
*   const oneTiB = FileSystem.TiB(1)
*
*   if (stats.size > oneTiB) {
*     yield* Console.log("This is a very large database backup!")
*
*     // Use larger chunk sizes for such files
*     const stream = fs.stream("database-backup.sql", {
*       chunkSize: FileSystem.MiB(100) // 100 MiB chunks
*     })
*   }
* })
* ```
*
* @since 4.0.0
* @category sizes
*/
var TiB = (n) => Size(n * 1024 * 1024 * 1024 * 1024);
var bigint1024 = /*#__PURE__*/ BigInt(1024);
var bigintPiB = bigint1024 * bigint1024 * bigint1024 * bigint1024 * bigint1024;
/**
* Creates a `Size` representing pebibytes (1024⁵ bytes).
*
* Converts a number of pebibytes to the equivalent size in bytes.
* Uses binary pebibytes (1,125,899,906,842,624 bytes) rather than decimal petabytes.
* This function uses BigInt arithmetic to handle the very large numbers involved.
*
* @example
* ```ts
* import { Console, Effect, FileSystem } from "effect"
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // For extremely large data processing scenarios
*   const massiveDataset = FileSystem.PiB(2) // 2 PiB
*
*   // This would typically be used in enterprise/cloud scenarios
*   yield* Console.log(`Processing ${massiveDataset} bytes of data`)
*
*   // Such large files would require specialized streaming
*   const stream = fs.stream("massive-dataset.bin", {
*     chunkSize: FileSystem.GiB(1), // 1 GiB chunks
*     offset: FileSystem.TiB(100) // Start from 100 TiB offset
*   })
* })
* ```
*
* @since 4.0.0
* @category sizes
*/
var PiB = (n) => Size(BigInt(n) * bigintPiB);
/**
* The service identifier for the FileSystem service.
*
* This key is used to provide and access the FileSystem service in the Effect context.
* Use this to inject file system implementations or access file system operations.
*
* @example
* ```ts
* import { Effect, FileSystem } from "effect"
*
* // Access the FileSystem service
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   const exists = yield* fs.exists("./data.txt")
*   if (exists) {
*     const content = yield* fs.readFileString("./data.txt")
*     yield* Effect.log("File content:", content)
*   }
* })
*
* // Provide a custom FileSystem implementation
* declare const platformImpl: Omit<
*   FileSystem.FileSystem,
*   "exists" | "readFileString" | "stream" | "sink" | "writeFileString"
* >
* const customFs = FileSystem.make(platformImpl)
*
* const withCustomFs = Effect.provideService(
*   program,
*   FileSystem.FileSystem,
*   customFs
* )
* ```
*
* @since 4.0.0
* @category tag
*/
var FileSystem = /*#__PURE__*/ Service("effect/platform/FileSystem");
/**
* Creates a FileSystem implementation from a partial implementation.
*
* This function takes a partial FileSystem implementation and automatically provides
* default implementations for `exists`, `readFileString`, `stream`, `sink`, and
* `writeFileString` methods based on the provided core methods.
*
* @since 4.0.0
* @category constructor
*/
var make$3 = (impl) => FileSystem.of({
	...impl,
	[TypeId$4]: TypeId$4,
	exists: (path) => pipe(impl.access(path), as(true), catchTag("PlatformError", (e) => e.reason._tag === "NotFound" ? succeed$1(false) : fail(e))),
	readFileString: (path, encoding) => flatMap(impl.readFile(path), (_) => try_({
		try: () => new TextDecoder(encoding).decode(_),
		catch: (cause) => badArgument({
			module: "FileSystem",
			method: "readFileString",
			description: "invalid encoding",
			cause
		})
	})),
	stream: fnUntraced(function* (path, options) {
		const file = yield* impl.open(path, { flag: "r" });
		if (options?.offset) yield* file.seek(options.offset, "start");
		const bytesToRead = options?.bytesToRead !== void 0 ? Size(options.bytesToRead) : void 0;
		let totalBytesRead = BigInt(0);
		const chunkSize = Size(options?.chunkSize ?? 64 * 1024);
		const readChunk = file.readAlloc(chunkSize);
		return fromPull(succeed$1(flatMap(suspend(() => {
			if (bytesToRead !== void 0 && bytesToRead <= totalBytesRead) return done();
			return bytesToRead !== void 0 && bytesToRead - totalBytesRead < chunkSize ? file.readAlloc(bytesToRead - totalBytesRead) : readChunk;
		}), (buf) => {
			if (!buf) return done();
			totalBytesRead += BigInt(buf.length);
			return succeed$1(of(buf));
		})));
	}, unwrap),
	sink: (path, options) => pipe(impl.open(path, {
		flag: "w",
		...options
	}), map((file) => forEach((_) => file.writeAll(_))), unwrap$1),
	writeFileString: (path, data, options) => flatMap(try_({
		try: () => new TextEncoder().encode(data),
		catch: (cause) => badArgument({
			module: "FileSystem",
			method: "writeFileString",
			description: "could not encode string",
			cause
		})
	}), (_) => impl.writeFile(path, _, options))
});
var notFound = (method, path) => systemError({
	module: "FileSystem",
	method,
	_tag: "NotFound",
	description: "No such file or directory",
	pathOrDescriptor: path
});
/**
* Creates a no-op FileSystem implementation for testing purposes.
*
* This function creates a FileSystem where most operations fail with "NotFound" errors,
* except for operations that can be safely stubbed. You can override specific methods
* by providing them in the `fileSystem` parameter.
*
* This is useful for testing scenarios where you want to control specific file system
* behaviors without affecting the actual file system.
*
* @example
* ```ts
* import { Effect, FileSystem, PlatformError } from "effect"
*
* // Create a test filesystem that only allows reading specific files
* const testFs = FileSystem.makeNoop({
*   readFileString: (path) => {
*     if (path === "test-config.json") {
*       return Effect.succeed("{\"test\": true}")
*     }
*     return Effect.fail(
*       PlatformError.systemError({
*         _tag: "NotFound",
*         module: "FileSystem",
*         method: "readFileString",
*         description: "File not found",
*         pathOrDescriptor: path
*       })
*     )
*   },
*   exists: (path) => Effect.succeed(path === "test-config.json")
* })
*
* // Use in tests
* const program = Effect.gen(function*() {
*   const content = yield* testFs.readFileString("test-config.json")
*   // Will succeed with mocked content
* })
*
* // Test with the no-op filesystem
* const testProgram = Effect.provideService(
*   program,
*   FileSystem.FileSystem,
*   testFs
* )
* ```
*
* @since 4.0.0
* @category constructor
*/
var makeNoop = (fileSystem) => FileSystem.of({
	[TypeId$4]: TypeId$4,
	access(path) {
		return fail(notFound("access", path));
	},
	chmod(path) {
		return fail(notFound("chmod", path));
	},
	chown(path) {
		return fail(notFound("chown", path));
	},
	copy(path) {
		return fail(notFound("copy", path));
	},
	copyFile(path) {
		return fail(notFound("copyFile", path));
	},
	exists() {
		return succeed$1(false);
	},
	link(path) {
		return fail(notFound("link", path));
	},
	makeDirectory() {
		return die("not implemented");
	},
	makeTempDirectory() {
		return die("not implemented");
	},
	makeTempDirectoryScoped() {
		return die("not implemented");
	},
	makeTempFile() {
		return die("not implemented");
	},
	makeTempFileScoped() {
		return die("not implemented");
	},
	open(path) {
		return fail(notFound("open", path));
	},
	readDirectory(path) {
		return fail(notFound("readDirectory", path));
	},
	readFile(path) {
		return fail(notFound("readFile", path));
	},
	readFileString(path) {
		return fail(notFound("readFileString", path));
	},
	readLink(path) {
		return fail(notFound("readLink", path));
	},
	realPath(path) {
		return fail(notFound("realPath", path));
	},
	remove() {
		return void_;
	},
	rename(oldPath) {
		return fail(notFound("rename", oldPath));
	},
	sink(path) {
		return fail$1(notFound("sink", path));
	},
	stat(path) {
		return fail(notFound("stat", path));
	},
	stream(path) {
		return fail$2(notFound("stream", path));
	},
	symlink(fromPath) {
		return fail(notFound("symlink", fromPath));
	},
	truncate(path) {
		return fail(notFound("truncate", path));
	},
	utimes(path) {
		return fail(notFound("utimes", path));
	},
	watch(path) {
		return fail$2(notFound("watch", path));
	},
	writeFile(path) {
		return fail(notFound("writeFile", path));
	},
	writeFileString(path) {
		return fail(notFound("writeFileString", path));
	},
	...fileSystem
});
/**
* Creates a Layer that provides a no-op FileSystem implementation for testing.
*
* This is a convenience function that wraps `makeNoop` in a Layer, making it easy
* to provide the test filesystem to your Effect programs.
*
* @example
* ```ts
* import { Effect, FileSystem } from "effect"
*
* // Create a test layer with specific behaviors
* const testLayer = FileSystem.layerNoop({
*   readFileString: (path) => Effect.succeed("mocked content"),
*   exists: () => Effect.succeed(true)
* })
*
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*   const content = yield* fs.readFileString("any-file.txt")
*   return content
* })
*
* // Provide the test layer
* const testProgram = Effect.provide(program, testLayer)
* ```
*
* @since 4.0.0
* @category layers
*/
var layerNoop = (fileSystem) => succeed$2(FileSystem)(makeNoop(fileSystem));
/**
* @since 4.0.0
* @category File
*/
var FileTypeId = "~effect/platform/FileSystem/File";
/**
* Type guard to check if a value is a File instance.
*
* This function determines whether the provided value is a valid File
* instance by checking for the presence of the File type identifier.
*
* @since 4.0.0
* @category File
*/
var isFile = (u) => typeof u === "object" && u !== null && "~effect/platform/FileSystem/File" in u;
/**
* Creates a branded file descriptor.
*
* File descriptors are integer handles that the operating system uses to identify
* open files. This branded type ensures type safety when working with file descriptors.
*
* @since 4.0.0
* @category constructor
*/
var FileDescriptor = /*#__PURE__*/ nominal();
/**
* Service key for file system watch backend implementations.
*
* This service provides the low-level file watching capabilities that can be
* implemented differently on various platforms (e.g., inotify on Linux,
* FSEvents on macOS, etc.).
*
* @example
* ```ts
* import { Effect, FileSystem, Stream } from "effect"
*
* // Custom watch backend implementation
* const customWatchBackend = {
*   register: (path: string, stat: FileSystem.File.Info) => {
*     // Implementation would depend on platform
*     return Stream.empty // Placeholder implementation
*   }
* }
*
* // Provide custom watch backend
* const program = Effect.gen(function*() {
*   const fs = yield* FileSystem.FileSystem
*
*   // File watching will use the custom backend
*   const watcher = fs.watch("./directory")
* })
*
* const withCustomBackend = Effect.provideService(
*   program,
*   FileSystem.WatchBackend,
*   customWatchBackend
* )
* ```
*
* @since 4.0.0
* @category file watcher
*/
var WatchBackend = class extends Service()("effect/platform/FileSystem/WatchBackend") {};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Path.js
/**
* @since 4.0.0
*/
var Path_exports = /* @__PURE__ */ __exportAll({
	Path: () => Path,
	TypeId: () => TypeId$3,
	layer: () => layer$1
});
/**
* @since 4.0.0
*/
var TypeId$3 = "~effect/platform/Path";
/**
* @since 4.0.0
* @category tag
* @example
* ```ts
* import { Effect, Layer, Path } from "effect"
*
* // Create a custom path implementation
* const customPath: Path.Path = {
*   [Path.TypeId]: Path.TypeId,
*   sep: "/",
*   basename: (path: string, suffix?: string) => {
*     const base = path.split("/").pop() || ""
*     return suffix && base.endsWith(suffix)
*       ? base.slice(0, -suffix.length)
*       : base
*   },
*   dirname: (path: string) => path.split("/").slice(0, -1).join("/") || "/",
*   extname: (path: string) => {
*     const match = path.match(/\.[^.]*$/)
*     return match ? match[0] : ""
*   },
*   format: (pathObject) => {
*     const dir = pathObject.dir || ""
*     const name = pathObject.name || ""
*     const ext = pathObject.ext || ""
*     return dir ? `${dir}/${name}${ext}` : `${name}${ext}`
*   },
*   fromFileUrl: (url: URL) => Effect.succeed(url.pathname),
*   isAbsolute: (path: string) => path.startsWith("/"),
*   join: (...paths: ReadonlyArray<string>) => paths.join("/"),
*   normalize: (path: string) => path.replace(/\/+/g, "/"),
*   parse: (path: string) => ({
*     root: path.startsWith("/") ? "/" : "",
*     dir: path.split("/").slice(0, -1).join("/") || "/",
*     base: path.split("/").pop() || "",
*     ext: path.match(/\.[^.]*$/)?.[0] || "",
*     name: path.split("/").pop()?.replace(/\.[^.]*$/, "") || ""
*   }),
*   relative: (from: string, to: string) => to.replace(from, ""),
*   resolve: (...pathSegments: ReadonlyArray<string>) => pathSegments.join("/"),
*   toFileUrl: (path: string) => Effect.succeed(new URL(`file://${path}`)),
*   toNamespacedPath: (path: string) => path
* }
*
* // Provide the path service
* const customPathLayer = Layer.succeed(Path.Path)(customPath)
*
* const program = Effect.gen(function*() {
*   const path = yield* Path.Path
*   const joined = path.join("home", "user", "file.txt")
*   console.log(joined) // "home/user/file.txt"
* })
*
* // Run with custom path implementation
* const result = Effect.provide(program, customPathLayer)
* ```
*/
var Path = /*#__PURE__*/ Service("effect/Path");
/**
* The following functions are adapted from the Node.js source code:
* https://github.com/nodejs/node/blob/main/lib/internal/url.js
*
* The following license applies to these functions:
* - MIT
*/
function normalizeStringPosix(path, allowAboveRoot) {
	let res = "";
	let lastSegmentLength = 0;
	let lastSlash = -1;
	let dots = 0;
	let code;
	for (let i = 0; i <= path.length; ++i) {
		if (i < path.length) code = path.charCodeAt(i);
		else if (code === 47) break;
		else code = 47;
		if (code === 47) {
			if (lastSlash === i - 1 || dots === 1) {} else if (lastSlash !== i - 1 && dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 || res.charCodeAt(res.length - 2) !== 46) {
					if (res.length > 2) {
						const lastSlashIndex = res.lastIndexOf("/");
						if (lastSlashIndex !== res.length - 1) {
							if (lastSlashIndex === -1) {
								res = "";
								lastSegmentLength = 0;
							} else {
								res = res.slice(0, lastSlashIndex);
								lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
							}
							lastSlash = i;
							dots = 0;
							continue;
						}
					} else if (res.length === 2 || res.length === 1) {
						res = "";
						lastSegmentLength = 0;
						lastSlash = i;
						dots = 0;
						continue;
					}
				}
				if (allowAboveRoot) {
					if (res.length > 0) res += "/..";
					else res = "..";
					lastSegmentLength = 2;
				}
			} else {
				if (res.length > 0) res += "/" + path.slice(lastSlash + 1, i);
				else res = path.slice(lastSlash + 1, i);
				lastSegmentLength = i - lastSlash - 1;
			}
			lastSlash = i;
			dots = 0;
		} else if (code === 46 && dots !== -1) ++dots;
		else dots = -1;
	}
	return res;
}
function _format(sep, pathObject) {
	const dir = pathObject.dir || pathObject.root;
	const base = pathObject.base || (pathObject.name || "") + (pathObject.ext || "");
	if (!dir) return base;
	if (dir === pathObject.root) return dir + base;
	return dir + sep + base;
}
function fromFileUrl(url) {
	if (url.protocol !== "file:") return fail(new BadArgument({
		module: "Path",
		method: "fromFileUrl",
		description: "URL must be of scheme file"
	}));
	else if (url.hostname !== "") return fail(new BadArgument({
		module: "Path",
		method: "fromFileUrl",
		description: "Invalid file URL host"
	}));
	const pathname = url.pathname;
	for (let n = 0; n < pathname.length; n++) if (pathname[n] === "%") {
		const third = pathname.codePointAt(n + 2) | 32;
		if (pathname[n + 1] === "2" && third === 102) return fail(new BadArgument({
			module: "Path",
			method: "fromFileUrl",
			description: "must not include encoded / characters"
		}));
	}
	return succeed$1(decodeURIComponent(pathname));
}
var resolve = function resolve() {
	let resolvedPath = "";
	let resolvedAbsolute = false;
	let cwd = void 0;
	for (let i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
		let path;
		if (i >= 0) path = arguments[i];
		else {
			const process = globalThis.process;
			if (cwd === void 0 && "process" in globalThis && typeof process === "object" && process !== null && typeof process.cwd === "function") cwd = process.cwd();
			path = cwd;
		}
		if (path.length === 0) continue;
		resolvedPath = path + "/" + resolvedPath;
		resolvedAbsolute = path.charCodeAt(0) === 47;
	}
	resolvedPath = normalizeStringPosix(resolvedPath, !resolvedAbsolute);
	if (resolvedAbsolute) if (resolvedPath.length > 0) return "/" + resolvedPath;
	else return "/";
	else if (resolvedPath.length > 0) return resolvedPath;
	else return ".";
};
var CHAR_FORWARD_SLASH = 47;
function toFileUrl(filepath) {
	const outURL = new URL("file://");
	let resolved = resolve(filepath);
	if (filepath.charCodeAt(filepath.length - 1) === CHAR_FORWARD_SLASH && resolved[resolved.length - 1] !== "/") resolved += "/";
	outURL.pathname = encodePathChars(resolved);
	return succeed$1(outURL);
}
var percentRegExp = /%/g;
var backslashRegExp = /\\/g;
var newlineRegExp = /\n/g;
var carriageReturnRegExp = /\r/g;
var tabRegExp = /\t/g;
function encodePathChars(filepath) {
	if (filepath.includes("%")) filepath = filepath.replace(percentRegExp, "%25");
	if (filepath.includes("\\")) filepath = filepath.replace(backslashRegExp, "%5C");
	if (filepath.includes("\n")) filepath = filepath.replace(newlineRegExp, "%0A");
	if (filepath.includes("\r")) filepath = filepath.replace(carriageReturnRegExp, "%0D");
	if (filepath.includes("	")) filepath = filepath.replace(tabRegExp, "%09");
	return filepath;
}
var posixImpl = /*#__PURE__*/ Path.of({
	[TypeId$3]: TypeId$3,
	resolve,
	normalize(path) {
		if (path.length === 0) return ".";
		const isAbsolute = path.charCodeAt(0) === 47;
		const trailingSeparator = path.charCodeAt(path.length - 1) === 47;
		path = normalizeStringPosix(path, !isAbsolute);
		if (path.length === 0 && !isAbsolute) path = ".";
		if (path.length > 0 && trailingSeparator) path += "/";
		if (isAbsolute) return "/" + path;
		return path;
	},
	isAbsolute(path) {
		return path.length > 0 && path.charCodeAt(0) === 47;
	},
	join() {
		if (arguments.length === 0) return ".";
		let joined;
		for (let i = 0; i < arguments.length; ++i) {
			const arg = arguments[i];
			if (arg.length > 0) if (joined === void 0) joined = arg;
			else joined += "/" + arg;
		}
		if (joined === void 0) return ".";
		return posixImpl.normalize(joined);
	},
	relative(from, to) {
		if (from === to) return "";
		from = posixImpl.resolve(from);
		to = posixImpl.resolve(to);
		if (from === to) return "";
		let fromStart = 1;
		for (; fromStart < from.length; ++fromStart) if (from.charCodeAt(fromStart) !== 47) break;
		const fromEnd = from.length;
		const fromLen = fromEnd - fromStart;
		let toStart = 1;
		for (; toStart < to.length; ++toStart) if (to.charCodeAt(toStart) !== 47) break;
		const toLen = to.length - toStart;
		const length = fromLen < toLen ? fromLen : toLen;
		let lastCommonSep = -1;
		let i = 0;
		for (; i <= length; ++i) {
			if (i === length) {
				if (toLen > length) {
					if (to.charCodeAt(toStart + i) === 47) return to.slice(toStart + i + 1);
					else if (i === 0) return to.slice(toStart + i);
				} else if (fromLen > length) {
					if (from.charCodeAt(fromStart + i) === 47) lastCommonSep = i;
					else if (i === 0) lastCommonSep = 0;
				}
				break;
			}
			const fromCode = from.charCodeAt(fromStart + i);
			if (fromCode !== to.charCodeAt(toStart + i)) break;
			else if (fromCode === 47) lastCommonSep = i;
		}
		let out = "";
		for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) if (i === fromEnd || from.charCodeAt(i) === 47) if (out.length === 0) out += "..";
		else out += "/..";
		if (out.length > 0) return out + to.slice(toStart + lastCommonSep);
		else {
			toStart += lastCommonSep;
			if (to.charCodeAt(toStart) === 47) ++toStart;
			return to.slice(toStart);
		}
	},
	dirname(path) {
		if (path.length === 0) return ".";
		let code = path.charCodeAt(0);
		const hasRoot = code === 47;
		let end = -1;
		let matchedSlash = true;
		for (let i = path.length - 1; i >= 1; --i) {
			code = path.charCodeAt(i);
			if (code === 47) {
				if (!matchedSlash) {
					end = i;
					break;
				}
			} else matchedSlash = false;
		}
		if (end === -1) return hasRoot ? "/" : ".";
		if (hasRoot && end === 1) return "//";
		return path.slice(0, end);
	},
	basename(path, ext) {
		let start = 0;
		let end = -1;
		let matchedSlash = true;
		let i;
		if (ext !== void 0 && ext.length > 0 && ext.length <= path.length) {
			if (ext.length === path.length && ext === path) return "";
			let extIdx = ext.length - 1;
			let firstNonSlashEnd = -1;
			for (i = path.length - 1; i >= 0; --i) {
				const code = path.charCodeAt(i);
				if (code === 47) {
					if (!matchedSlash) {
						start = i + 1;
						break;
					}
				} else {
					if (firstNonSlashEnd === -1) {
						matchedSlash = false;
						firstNonSlashEnd = i + 1;
					}
					if (extIdx >= 0) if (code === ext.charCodeAt(extIdx)) {
						if (--extIdx === -1) end = i;
					} else {
						extIdx = -1;
						end = firstNonSlashEnd;
					}
				}
			}
			if (start === end) end = firstNonSlashEnd;
			else if (end === -1) end = path.length;
			return path.slice(start, end);
		} else {
			for (i = path.length - 1; i >= 0; --i) if (path.charCodeAt(i) === 47) {
				if (!matchedSlash) {
					start = i + 1;
					break;
				}
			} else if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (end === -1) return "";
			return path.slice(start, end);
		}
	},
	extname(path) {
		let startDot = -1;
		let startPart = 0;
		let end = -1;
		let matchedSlash = true;
		let preDotState = 0;
		for (let i = path.length - 1; i >= 0; --i) {
			const code = path.charCodeAt(i);
			if (code === 47) {
				if (!matchedSlash) {
					startPart = i + 1;
					break;
				}
				continue;
			}
			if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (code === 46) {
				if (startDot === -1) startDot = i;
				else if (preDotState !== 1) preDotState = 1;
			} else if (startDot !== -1) preDotState = -1;
		}
		if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) return "";
		return path.slice(startDot, end);
	},
	format: function format(pathObject) {
		if (pathObject === null || typeof pathObject !== "object") throw new TypeError("The \"pathObject\" argument must be of type Object. Received type " + typeof pathObject);
		return _format("/", pathObject);
	},
	parse(path) {
		const ret = {
			root: "",
			dir: "",
			base: "",
			ext: "",
			name: ""
		};
		if (path.length === 0) return ret;
		let code = path.charCodeAt(0);
		const isAbsolute = code === 47;
		let start;
		if (isAbsolute) {
			ret.root = "/";
			start = 1;
		} else start = 0;
		let startDot = -1;
		let startPart = 0;
		let end = -1;
		let matchedSlash = true;
		let i = path.length - 1;
		let preDotState = 0;
		for (; i >= start; --i) {
			code = path.charCodeAt(i);
			if (code === 47) {
				if (!matchedSlash) {
					startPart = i + 1;
					break;
				}
				continue;
			}
			if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (code === 46) {
				if (startDot === -1) startDot = i;
				else if (preDotState !== 1) preDotState = 1;
			} else if (startDot !== -1) preDotState = -1;
		}
		if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
			if (end !== -1) if (startPart === 0 && isAbsolute) ret.base = ret.name = path.slice(1, end);
			else ret.base = ret.name = path.slice(startPart, end);
		} else {
			if (startPart === 0 && isAbsolute) {
				ret.name = path.slice(1, startDot);
				ret.base = path.slice(1, end);
			} else {
				ret.name = path.slice(startPart, startDot);
				ret.base = path.slice(startPart, end);
			}
			ret.ext = path.slice(startDot, end);
		}
		if (startPart > 0) ret.dir = path.slice(0, startPart - 1);
		else if (isAbsolute) ret.dir = "/";
		return ret;
	},
	sep: "/",
	fromFileUrl,
	toFileUrl,
	toNamespacedPath: identity
});
/**
* @since 4.0.0
* @category Layers
*/
var layer$1 = /*#__PURE__*/ succeed$2(Path)(posixImpl);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/LogLevel.js
var LogLevel_exports = /* @__PURE__ */ __exportAll({
	Equivalence: () => Equivalence,
	Order: () => Order,
	getOrdinal: () => getOrdinal,
	isEnabled: () => isEnabled,
	isGreaterThan: () => isGreaterThan,
	isGreaterThanOrEqualTo: () => isGreaterThanOrEqualTo,
	isLessThan: () => isLessThan,
	isLessThanOrEqualTo: () => isLessThanOrEqualTo,
	values: () => values
});
/**
* @since 4.0.0
* @category models
*/
var values = [
	"All",
	"Fatal",
	"Error",
	"Warn",
	"Info",
	"Debug",
	"Trace",
	"None"
];
/**
* An `Order` instance for `LogLevel` that defines the severity ordering.
*
* This order treats "All" as the least restrictive level and "None" as the most restrictive,
* with Fatal being the most severe actual log level.
*
* @example
* ```ts
* import { LogLevel } from "effect"
*
* // Compare log levels using Order
* console.log(LogLevel.Order("Error", "Info")) // 1 (Error > Info)
* console.log(LogLevel.Order("Debug", "Error")) // -1 (Debug < Error)
* console.log(LogLevel.Order("Info", "Info")) // 0 (Info == Info)
* ```
*
* @since 2.0.0
* @category ordering
*/
var Order = LogLevelOrder;
/**
* An `Equivalence` instance for log levels using strict equality (`===`).
*
* @example
* ```ts
* import { LogLevel } from "effect"
*
* console.log(LogLevel.Equivalence("Error", "Error")) // true
* console.log(LogLevel.Equivalence("Error", "Info")) // false
* ```
*
* @category instances
* @since 4.0.0
*/
var Equivalence = /*#__PURE__*/ strictEqual();
/**
* Returns the ordinal value of the log level.
*
* @since 4.0.0
* @category ordering
*/
var getOrdinal = (self) => logLevelToOrder(self);
/**
* Determines if the first log level is more severe than the second.
*
* Returns `true` if `self` represents a more severe level than `that`.
* This is useful for filtering logs based on minimum severity requirements.
*
* @example
* ```ts
* import { LogLevel } from "effect"
*
* // Check if Error is more severe than Info
* console.log(LogLevel.isGreaterThan("Error", "Info")) // true
* console.log(LogLevel.isGreaterThan("Debug", "Error")) // false
*
* // Use with filtering
* const isFatal = LogLevel.isGreaterThan("Fatal", "Warn")
* const isError = LogLevel.isGreaterThan("Error", "Warn")
* const isDebug = LogLevel.isGreaterThan("Debug", "Warn")
* console.log(isFatal) // true
* console.log(isError) // true
* console.log(isDebug) // false
*
* // Curried usage
* const isMoreSevereThanInfo = LogLevel.isGreaterThan("Info")
* console.log(isMoreSevereThanInfo("Error")) // true
* console.log(isMoreSevereThanInfo("Debug")) // false
* ```
*
* @since 2.0.0
* @category ordering
*/
var isGreaterThan = isLogLevelGreaterThan;
/**
* Determines if the first log level is more severe than or equal to the second.
*
* Returns `true` if `self` represents a level that is more severe than or equal to `that`.
* This is the most common function for implementing minimum log level filtering.
*
* @example
* ```ts
* import { Logger, LogLevel } from "effect"
*
* // Check if level meets minimum threshold
* console.log(LogLevel.isGreaterThanOrEqualTo("Error", "Error")) // true
* console.log(LogLevel.isGreaterThanOrEqualTo("Error", "Info")) // true
* console.log(LogLevel.isGreaterThanOrEqualTo("Debug", "Info")) // false
*
* // Create a logger that only logs Info and above
* const infoLogger = Logger.make((options) => {
*   if (LogLevel.isGreaterThanOrEqualTo(options.logLevel, "Info")) {
*     console.log(`[${options.logLevel}] ${options.message}`)
*   }
* })
*
* // Production logger - only Error and Fatal
* const productionLogger = Logger.make((options) => {
*   if (LogLevel.isGreaterThanOrEqualTo(options.logLevel, "Error")) {
*     console.error(
*       `${options.date.toISOString()} [${options.logLevel}] ${options.message}`
*     )
*   }
* })
*
* // Curried usage for filtering
* const isInfoOrAbove = LogLevel.isGreaterThanOrEqualTo("Info")
* const shouldLog = isInfoOrAbove("Error") // true
* ```
*
* @since 2.0.0
* @category ordering
*/
var isGreaterThanOrEqualTo = /*#__PURE__*/ isGreaterThanOrEqualTo$1(Order);
/**
* Determines if the first log level is less severe than the second.
*
* Returns `true` if `self` represents a less severe level than `that`.
* This is useful for filtering out logs that are too verbose.
*
* @example
* ```ts
* import { LogLevel } from "effect"
*
* // Check if Debug is less severe than Info
* console.log(LogLevel.isLessThan("Debug", "Info")) // true
* console.log(LogLevel.isLessThan("Error", "Info")) // false
*
* // Filter out verbose logs
* const isFatalVerbose = LogLevel.isLessThan("Fatal", "Info")
* const isErrorVerbose = LogLevel.isLessThan("Error", "Info")
* const isTraceVerbose = LogLevel.isLessThan("Trace", "Info")
* console.log(isFatalVerbose) // false (Fatal is not verbose)
* console.log(isErrorVerbose) // false (Error is not verbose)
* console.log(isTraceVerbose) // true (Trace is verbose)
*
* // Curried usage
* const isLessSevereThanError = LogLevel.isLessThan("Error")
* console.log(isLessSevereThanError("Info")) // true
* console.log(isLessSevereThanError("Fatal")) // false
* ```
*
* @since 2.0.0
* @category ordering
*/
var isLessThan = /*#__PURE__*/ isLessThan$1(Order);
/**
* Determines if the first log level is less severe than or equal to the second.
*
* Returns `true` if `self` represents a level that is less severe than or equal to `that`.
* This is useful for implementing maximum log level filtering.
*
* @example
* ```ts
* import { Logger, LogLevel } from "effect"
*
* // Check if level is at or below threshold
* console.log(LogLevel.isLessThanOrEqualTo("Info", "Info")) // true
* console.log(LogLevel.isLessThanOrEqualTo("Debug", "Info")) // true
* console.log(LogLevel.isLessThanOrEqualTo("Error", "Info")) // false
*
* // Create a logger that suppresses verbose logs
* const quietLogger = Logger.make((options) => {
*   if (LogLevel.isLessThanOrEqualTo(options.logLevel, "Info")) {
*     console.log(`[${options.logLevel}] ${options.message}`)
*   }
* })
*
* // Development logger - suppress trace logs
* const devLogger = Logger.make((options) => {
*   if (LogLevel.isLessThanOrEqualTo(options.logLevel, "Debug")) {
*     console.log(`[${options.logLevel}] ${options.message}`)
*   }
* })
*
* // Curried usage for filtering
* const isInfoOrBelow = LogLevel.isLessThanOrEqualTo("Info")
* const shouldLog = isInfoOrBelow("Debug") // true
* ```
*
* @since 2.0.0
* @category ordering
*/
var isLessThanOrEqualTo = /*#__PURE__*/ isLessThanOrEqualTo$1(Order);
/**
* Checks whether a given log level is enabled for the current fiber.
*
* A log level is enabled when it is greater than or equal to
* `References.MinimumLogLevel`.
*
* @example
* ```ts
* import { Effect, LogLevel, References } from "effect"
*
* const program = Effect.gen(function*() {
*   const debugEnabled = yield* LogLevel.isEnabled("Debug")
*   const errorEnabled = yield* LogLevel.isEnabled("Error")
*
*   console.log({ debugEnabled, errorEnabled })
* })
*
* const warnOnly = program.pipe(
*   Effect.provideService(References.MinimumLogLevel, "Warn")
* )
* ```
*
* @since 4.0.0
* @category filtering
*/
var isEnabled = (self) => withFiber((fiber) => succeed$3(!isGreaterThan(fiber.getRef(MinimumLogLevel), self)));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ErrorReporter.js
var ErrorReporter_exports = /* @__PURE__ */ __exportAll({
	CurrentErrorReporters: () => CurrentErrorReporters,
	TypeId: () => TypeId$2,
	attributes: () => attributes,
	getAttributes: () => getAttributes,
	getSeverity: () => getSeverity,
	ignore: () => ignore,
	isIgnored: () => isIgnored,
	layer: () => layer,
	make: () => make$2,
	report: () => report,
	severity: () => severity
});
/**
* @since 4.0.0
* @category Type Identifiers
*/
var TypeId$2 = "~effect/ErrorReporter";
/**
* Creates an `ErrorReporter` from a callback.
*
* The returned reporter automatically deduplicates causes and individual
* errors (the same object is never reported twice), skips interruptions,
* and resolves the `ignore`, `severity`, and `attributes` annotations on
* each error before invoking your callback.
*
* @example
* ```ts
* import { ErrorReporter } from "effect"
*
* // Forward every failure to the console
* const consoleReporter = ErrorReporter.make(
*   ({ error, severity, attributes }) => {
*     console.error(`[${severity}]`, error.message, attributes)
*   }
* )
* ```
*
* @since 4.0.0
* @category Constructors
*/
var make$2 = (report) => {
	const reported = /* @__PURE__ */ new WeakSet();
	return {
		[TypeId$2]: TypeId$2,
		report(options) {
			if (reported.has(options.cause)) return;
			reported.add(options.cause);
			for (let i = 0; i < options.cause.reasons.length; i++) {
				const reason = options.cause.reasons[i];
				if (reason._tag === "Interrupt") continue;
				const original = reason._tag === "Fail" ? reason.error : reason.defect;
				const isObject = typeof original === "object" && original !== null;
				if (isObject) {
					if (reported.has(original)) continue;
					reported.add(original);
				}
				if (isIgnored(original)) continue;
				const pretty = causePrettyError(original, reason.annotations);
				report({
					...options,
					error: pretty,
					severity: isObject ? getSeverity(original) : "Info",
					attributes: isObject ? getAttributes(original) : emptyAttributes
				});
			}
		}
	};
};
/**
* A `ServiceMap.Reference` holding the set of active `ErrorReporter`s for the
* current fiber. Defaults to an empty set (no reporting).
*
* Prefer {@link layer} to configure reporters via the `Layer` API. Use this
* reference directly only when you need low-level control (e.g. reading the
* current reporters or swapping them inside a `FiberRef`).
*
* @since 4.0.0
* @category References
*/
var CurrentErrorReporters = CurrentErrorReporters$1;
/**
* Creates a `Layer` that registers one or more `ErrorReporter`s.
*
* Reporters can be plain `ErrorReporter` values or effectful
* `Effect<ErrorReporter>` values that are resolved when the layer is built.
*
* By default the provided reporters **replace** any previously registered
* reporters. Set `mergeWithExisting: true` to add them alongside existing
* ones.
*
* @example
* ```ts
* import { Effect, ErrorReporter } from "effect"
*
* const consoleReporter = ErrorReporter.make(({ error, severity }) => {
*   console.error(`[${severity}]`, error.message)
* })
*
* const metricsReporter = ErrorReporter.make(({ severity }) => {
*   // increment an error counter by severity
* })
*
* // Replace all existing reporters
* const ReporterLive = ErrorReporter.layer([
*   consoleReporter,
*   metricsReporter
* ])
*
* // Add to existing reporters instead of replacing
* const ReporterMerged = ErrorReporter.layer(
*   [metricsReporter],
*   { mergeWithExisting: true }
* )
*
* const program = Effect.gen(function*() {
*   yield* Effect.fail("boom")
* }).pipe(
*   Effect.withErrorReporting,
*   Effect.provide(ReporterLive)
* )
* ```
*
* @since 4.0.0
* @category Layers
*/
var layer = (reporters, options) => effect(CurrentErrorReporters, withFiber$1(fnUntraced(function* (fiber) {
	const currentReporters = new Set(options?.mergeWithExisting === true ? fiber.getRef(CurrentErrorReporters$1) : []);
	for (const reporter of reporters) currentReporters.add(isEffect(reporter) ? yield* reporter : reporter);
	return currentReporters;
})));
/**
* Manually report a `Cause` to all registered `ErrorReporter`s on the
* current fiber.
*
* This is useful when you want to report an error for observability without
* actually failing the fiber.
*
* @example
* ```ts
* import { Cause, Effect, ErrorReporter } from "effect"
*
* // Log the cause for monitoring, then continue with a fallback
* const program = Effect.gen(function*() {
*   const cause = Cause.fail("something went wrong")
*   yield* ErrorReporter.report(cause)
*   return "fallback value"
* })
* ```
*
* @since 4.0.0
* @category Reporting
*/
var report = (cause) => withFiber$1((fiber) => {
	reportCauseUnsafe(fiber, cause);
	return void_;
});
/**
* Symbol key used to mark an error as unreportable.
*
* Set this property to `true` on any error class to prevent it from being
* forwarded to reporters. Useful for expected errors such as HTTP 404s.
*
* @example
* ```ts
* import { Data, ErrorReporter } from "effect"
*
* class NotFoundError extends Data.TaggedError("NotFoundError")<{}> {
*   readonly [ErrorReporter.ignore] = true
* }
* ```
*
* @since 4.0.0
* @category Annotations
*/
var ignore = "~effect/ErrorReporter/ignore";
/**
* Returns `true` if the given value has the `ErrorReporter.ignore` annotation
* set to `true`.
*
* @since 4.0.0
* @category Annotations
*/
var isIgnored = (u) => typeof u === "object" && u !== null && "~effect/ErrorReporter/ignore" in u && u["~effect/ErrorReporter/ignore"] === true;
/**
* Symbol key used to override the severity level of an error.
*
* When set, the reporter callback receives this value as `severity` instead
* of the default `"Error"`. Accepted values are the `LogLevel.Severity`
* literals: `"Trace"`, `"Debug"`, `"Info"`, `"Warn"`, `"Error"`, `"Fatal"`.
*
* @example
* ```ts
* import { Data, ErrorReporter } from "effect"
*
* class DeprecationWarning extends Data.TaggedError("DeprecationWarning")<{}> {
*   readonly [ErrorReporter.severity] = "Warn" as const
* }
* ```
*
* @since 4.0.0
* @category Annotations
*/
var severity = "~effect/ErrorReporter/severity";
/**
* Reads the `ErrorReporter.severity` annotation from an error object,
* falling back to `"Error"` when unset or invalid.
*
* @since 4.0.0
* @category Annotations
*/
var getSeverity = (error) => {
	if ("~effect/ErrorReporter/severity" in error && values.includes(error["~effect/ErrorReporter/severity"])) return error[severity];
	return "Info";
};
/**
* Symbol key used to attach extra key/value metadata to an error report.
*
* Reporters receive these attributes alongside the error, making it easy to
* include contextual information such as user IDs, request IDs, or any
* domain-specific data useful for debugging.
*
* @example
* ```ts
* import { Data, ErrorReporter } from "effect"
*
* class PaymentError extends Data.TaggedError("PaymentError")<{
*   readonly orderId: string
* }> {
*   readonly [ErrorReporter.attributes] = {
*     orderId: this.orderId
*   }
* }
* ```
*
* @since 4.0.0
* @category Annotations
*/
var attributes = "~effect/ErrorReporter/attributes";
/**
* Reads the `ErrorReporter.attributes` annotation from an error object,
* returning an empty record when unset.
*
* @since 4.0.0
* @category Annotations
*/
var getAttributes = (error) => {
	return "~effect/ErrorReporter/attributes" in error ? error[attributes] : emptyAttributes;
};
var emptyAttributes = {};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Pool.js
var Pool_exports = /* @__PURE__ */ __exportAll({
	get: () => get,
	invalidate: () => invalidate,
	isPool: () => isPool,
	make: () => make$1,
	makeWithStrategy: () => makeWithStrategy,
	makeWithTTL: () => makeWithTTL
});
var TypeId$1 = "~effect/Pool";
/**
* Returns `true` if the specified value is a `Pool`, `false` otherwise.
*
* @since 2.0.0
* @category refinements
*/
var isPool = (u) => hasProperty(u, TypeId$1);
/**
* Makes a new pool of the specified fixed size. The pool is returned in a
* `Scope`, which governs the lifetime of the pool. When the pool is shutdown
* because the `Scope` is closed, the individual items allocated by the pool
* will be released in some unspecified order.
*
* By setting the `concurrency` parameter, you can control the level of concurrent
* access per pool item. By default, the number of permits is set to `1`.
*
* `targetUtilization` determines when to create new pool items. It is a value
* between 0 and 1, where 1 means only create new pool items when all the existing
* items are fully utilized.
*
* A `targetUtilization` of 0.5 will create new pool items when the existing items are
* 50% utilized.
*
* @since 2.0.0
* @category constructors
*/
var make$1 = (options) => makeWithStrategy({
	...options,
	min: options.size,
	max: options.size,
	strategy: strategyNoop()
});
/**
* Makes a new pool with the specified minimum and maximum sizes and time to
* live before a pool whose excess items are not being used will be shrunk
* down to the minimum size. The pool is returned in a `Scope`, which governs
* the lifetime of the pool. When the pool is shutdown because the `Scope` is
* used, the individual items allocated by the pool will be released in some
* unspecified order.
*
* By setting the `concurrency` parameter, you can control the level of concurrent
* access per pool item. By default, the number of permits is set to `1`.
*
* `targetUtilization` determines when to create new pool items. It is a value
* between 0 and 1, where 1 means only create new pool items when all the existing
* items are fully utilized.
*
* A `targetUtilization` of 0.5 will create new pool items when the existing items are
* 50% utilized.
*
* The `timeToLiveStrategy` determines how items are invalidated. If set to
* "creation", then items are invalidated based on their creation time. If set
* to "usage", then items are invalidated based on pool usage.
*
* By default, the `timeToLiveStrategy` is set to "usage".
*
* ```ts skip-type-checking
* import { Duration, Effect, Pool } from "effect"
* import { createConnection } from "mysql2"
*
* const acquireDBConnection = Effect.acquireRelease(
*   Effect.sync(() => createConnection("mysql://...")),
*   (connection) => Effect.sync(() => connection.end(() => {}))
* )
*
* const connectionPool = Effect.flatMap(
*   Pool.makeWithTTL({
*     acquire: acquireDBConnection,
*     min: 10,
*     max: 20,
*     timeToLive: Duration.seconds(60)
*   }),
*   (pool) => pool.get
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var makeWithTTL = (options) => flatMap(options.timeToLiveStrategy === "creation" ? strategyCreationTTL(options.timeToLive) : strategyUsageTTL(options.timeToLive), (strategy) => makeWithStrategy({
	...options,
	strategy
}));
/**
* @since 4.0.0
* @category constructors
*/
var makeWithStrategy = (options) => uninterruptibleMask(fnUntraced(function* (restore) {
	const services$1 = yield* services();
	const scope = get$1(services$1, Scope);
	const acquire = updateServices(options.acquire, (input) => merge(services$1, input));
	const concurrency = options.concurrency ?? 1;
	const config = {
		acquire,
		concurrency,
		minSize: options.min,
		maxSize: options.max,
		strategy: options.strategy,
		targetUtilization: Math.min(Math.max(options.targetUtilization ?? 1, .1), 1)
	};
	const state = {
		scope,
		isShuttingDown: false,
		semaphore: makeUnsafe(concurrency * options.max),
		resizeSemaphore: makeUnsafe(1),
		items: /* @__PURE__ */ new Set(),
		available: /* @__PURE__ */ new Set(),
		availableLatch: makeUnsafe$1(false),
		invalidated: /* @__PURE__ */ new Set(),
		waiters: 0
	};
	const self = {
		[TypeId$1]: TypeId$1,
		config,
		state,
		pipe() {
			return pipeArguments(this, arguments);
		}
	};
	yield* addFinalizer(scope, shutdown(self));
	yield* tap(forkDetach(restore(resize(self))), (fiber) => addFinalizer(scope, interrupt$1(fiber)));
	yield* tap(forkDetach(restore(options.strategy.run(self))), (fiber) => addFinalizer(scope, interrupt$1(fiber)));
	return self;
}));
var shutdown = /*#__PURE__*/ fnUntraced(function* (self) {
	if (self.state.isShuttingDown) return;
	self.state.isShuttingDown = true;
	const size = self.state.items.size;
	const semaphore = makeUnsafe(size);
	for (const item of self.state.items) if (item.refCount > 0) {
		item.finalizer = tap(item.finalizer, semaphore.release(1));
		self.state.invalidated.add(item);
		yield* semaphore.take(1);
	} else {
		self.state.items.delete(item);
		self.state.available.delete(item);
		self.state.invalidated.delete(item);
		yield* item.finalizer;
	}
	yield* semaphore.releaseAll;
	self.state.availableLatch.openUnsafe();
	yield* semaphore.take(size);
});
/**
* Retrieves an item from the pool in a scoped effect. Note that if
* acquisition fails, then the returned effect will fail for that same reason.
* Retrying a failed acquisition attempt will repeat the acquisition attempt.
*
* @since 2.0.0
* @category getters
*/
var get = (self) => suspend(() => {
	if (self.state.isShuttingDown) return interrupt;
	return flatMap(getPoolItem(self), (item) => item.exit);
});
var getPoolItem = (self) => uninterruptibleMask((restore) => restore(self.state.semaphore.take(1)).pipe(flatMap(() => scope), flatMap((scope) => getPoolItemInner(self).pipe(ensuring(sync(() => self.state.waiters--)), tap((item) => {
	if (item.exit._tag === "Failure") {
		self.state.items.delete(item);
		self.state.invalidated.delete(item);
		self.state.available.delete(item);
		return self.state.semaphore.release(1);
	}
	item.refCount++;
	self.state.available.delete(item);
	if (item.refCount < self.config.concurrency) self.state.available.add(item);
	return addFinalizerExit(scope, () => flatMap(suspend(() => {
		item.refCount--;
		if (self.state.invalidated.has(item)) return invalidatePoolItem(self, item);
		self.state.available.add(item);
		return void_;
	}), () => self.state.semaphore.release(1)));
}), onInterrupt(() => self.state.semaphore.release(1))))));
var getPoolItemInner = /*#__PURE__*/ fnUntraced(function* (self) {
	self.state.waiters++;
	if (self.state.isShuttingDown) return yield* interrupt;
	else if (targetSize(self) > activeSize(self)) while (true) {
		yield* self.state.resizeSemaphore.withPermitsIfAvailable(1)(forkIn(interruptible(resize(self)), self.state.scope));
		if (self.state.isShuttingDown) return yield* interrupt;
		else if (self.state.available.size > 0) return headUnsafe(self.state.available);
		self.state.availableLatch.closeUnsafe();
		yield* self.state.availableLatch.await;
	}
	return headUnsafe(self.state.available);
});
/**
* Invalidates the specified item. This will cause the pool to eventually
* reallocate the item, although this reallocation may occur lazily rather
* than eagerly.
*
* @since 2.0.0
* @category combinators
*/
var invalidate = /*#__PURE__*/ dual(2, (self, item) => suspend(() => {
	if (self.state.isShuttingDown) return void_;
	for (const poolItem of self.state.items) if (poolItem.exit._tag === "Success" && poolItem.exit.value === item) {
		poolItem.disableReclaim = true;
		return uninterruptible(invalidatePoolItem(self, poolItem));
	}
	return void_;
}));
var invalidatePoolItem = (self, poolItem) => suspend(() => {
	if (!self.state.items.has(poolItem)) return void_;
	else if (poolItem.refCount === 0) {
		self.state.items.delete(poolItem);
		self.state.available.delete(poolItem);
		self.state.invalidated.delete(poolItem);
		return asVoid(flatMap(poolItem.finalizer, () => forkIn(interruptible(resize(self)), self.state.scope)));
	}
	self.state.invalidated.add(poolItem);
	self.state.available.delete(poolItem);
	return void_;
});
var resize = (self) => self.state.resizeSemaphore.withPermits(1)(resizeLoop(self));
var resizeLoop = (self) => suspend(() => {
	const active = activeSize(self);
	const target = targetSize(self);
	if (active >= target) return void_;
	const toAcquire = target - active;
	return self.config.strategy.reclaim(self).pipe(flatMap((item) => item ? succeed$1(item) : allocate(self)), replicateEffect(toAcquire, { concurrency: toAcquire }), tap(self.state.availableLatch.open), flatMap((items) => items.some((_) => _.exit._tag === "Failure") ? void_ : resizeLoop(self)));
});
var allocate = (self) => acquireUseRelease(make$5(), (scope) => self.config.acquire.pipe(provide(scope), exit, flatMap((exit) => {
	const item = {
		exit,
		finalizer: catchCause(close(scope, exit), reportUnhandledError),
		refCount: 0,
		disableReclaim: false
	};
	self.state.items.add(item);
	self.state.available.add(item);
	return as(exit._tag === "Success" ? self.config.strategy.onAcquire(item) : flatMap(item.finalizer, () => self.config.strategy.onAcquire(item)), item);
})), (scope, exit) => exit._tag === "Failure" ? close(scope, exit) : void_);
var currentUsage = (self) => {
	let count = self.state.waiters;
	for (const item of self.state.items) count += item.refCount;
	return count;
};
var targetSize = (self) => {
	if (self.state.isShuttingDown) return 0;
	const utilization = currentUsage(self) / self.config.targetUtilization;
	const target = Math.ceil(utilization / self.config.concurrency);
	return Math.min(Math.max(self.config.minSize, target), self.config.maxSize);
};
var activeSize = (self) => {
	return self.state.items.size - self.state.invalidated.size;
};
var strategyNoop = () => ({
	run: (_) => void_,
	onAcquire: (_) => void_,
	reclaim: (_) => undefined_
});
var strategyCreationTTL = /*#__PURE__*/ fnUntraced(function* (ttl) {
	const clock = yield* Clock;
	const queue = yield* unbounded();
	const ttlMillis = toMillis(fromInputUnsafe(ttl));
	const creationTimes = /* @__PURE__ */ new WeakMap();
	return identity({
		run: (pool) => {
			const process = (item) => suspend(() => {
				if (!pool.state.items.has(item) || pool.state.invalidated.has(item)) return void_;
				const now = clock.currentTimeMillisUnsafe();
				const created = creationTimes.get(item);
				const remaining = ttlMillis - (now - created);
				return remaining > 0 ? delay(process(item), remaining) : invalidatePoolItem(pool, item);
			});
			return take(queue).pipe(tap(process), forever({ disableYield: true }));
		},
		onAcquire: (item) => suspend(() => {
			creationTimes.set(item, clock.currentTimeMillisUnsafe());
			return offer(queue, item);
		}),
		reclaim: (_) => undefined_
	});
});
var strategyUsageTTL = /*#__PURE__*/ fnUntraced(function* (ttl) {
	const queue = yield* unbounded();
	return identity({
		run: (pool) => {
			const process = suspend(() => {
				if (activeSize(pool) - targetSize(pool) <= 0) return void_;
				return take(queue).pipe(tap((item) => invalidatePoolItem(pool, item)), flatMap(() => process));
			});
			return process.pipe(delay(ttl), forever({ disableYield: true }));
		},
		onAcquire: (item) => offer(queue, item),
		reclaim(pool) {
			return suspend(() => {
				if (pool.state.invalidated.size === 0) return undefined_;
				const item = head(filter(pool.state.invalidated, (item) => !item.disableReclaim));
				if (item._tag === "None") return undefined_;
				pool.state.invalidated.delete(item.value);
				if (item.value.refCount < pool.config.concurrency) pool.state.available.add(item.value);
				return as(offer(queue, item.value), item.value);
			});
		}
	});
});
var reportUnhandledError = (cause) => withFiber$1((fiber) => {
	const unhandledLogLevel = fiber.getRef(UnhandledLogLevel);
	if (unhandledLogLevel) return logWithLevel(unhandledLogLevel)("Unhandled error in pool finalizer", cause);
	return void_;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Stdio.js
var Stdio_exports = /* @__PURE__ */ __exportAll({
	Stdio: () => Stdio,
	TypeId: () => TypeId,
	make: () => make
});
/**
* @since 4.0.0
* @category Type IDs
*/
var TypeId = "~effect/Stdio";
/**
* @since 4.0.0
* @category Services
*/
var Stdio = /*#__PURE__*/ Service(TypeId);
/**
* @since 4.0.0
* @category Constructors
*/
var make = (options) => ({
	[TypeId]: TypeId,
	...options
});
//#endregion
export { Brand_exports as _, make$1 as a, ignore as c, Path as d, Path_exports as f, PlatformError_exports as g, Size as h, get as i, LogLevel_exports as l, FileSystem_exports as m, Stdio_exports as n, makeWithTTL as o, FileSystem as p, Pool_exports as r, ErrorReporter_exports as s, Stdio as t, values as u };
