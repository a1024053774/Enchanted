import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import "./useRenderElement-CvLulVDb.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/toolbar/root/ToolbarRootContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var ToolbarRootContext = /*#__PURE__*/ import_react.createContext(void 0);
ToolbarRootContext.displayName = "ToolbarRootContext";
function useToolbarRootContext(optional) {
	const context = import_react.useContext(ToolbarRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: ToolbarRootContext is missing. Toolbar parts must be placed within <Toolbar.Root>.");
	return context;
}
//#endregion
export { useToolbarRootContext as t };
