import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { J as constTrue, Q as dual, R as isTagged, X as constVoid, Z as constant, a as equals, ot as pipeArguments, p as hash, tt as identity$1, x as hasProperty } from "./Equal-CgzkNqbP.js";
import { Dn as exitFail, Et as some, G as fail$2, Jn as NodeInspectSymbol, On as exitFailCause, Q as isSuccess, Qn as format, Qt as Done, Vn as withFiber, X as isFailure, Yn as toJson, at as succeed$1, bt as isSome, kn as exitSucceed, pt as getOrElse, sn as PipeInspectableProto, vn as causeFail, vt as isNone, wt as none } from "./Record-BrB0racz.js";
import { $s as as, Au as isReadonlyArrayNonEmpty, Bo as close, Bu as of, C as callback$2, Cc as fiberJoin, Ci as catchDone, D as catchDefect, Di as isDoneCause, Dt as interrupt$3, G as exit, Go as makeUnsafe$2, Gr as when, Gt as map$1, Hc as makeLatchUnsafe, Hs as ClockRef, Ht as logWithLevel, I as catch_$1, Io as Scope, J as failCauseSync$1, Jo as _await, K as fail$3, Kc as matchCauseEffect, Ko as provide$1, Kr as whileLoop$1, Ks as FiberTypeId, Lr as uninterruptible, Lu as map$2, Os as hasFails, Ou as isArray, Pc as getCurrentFiber, Pi as isString, Pl as isServiceMap, Pr as tryPromise, Ps as isDone, Q as filter$2, Qo as interruptWith, Qs as andThen$1, Ro as addFinalizer, Rr as uninterruptibleMask$1, Sc as fiberInterruptAs, Ss as done, Tc as fiberRunIn, Ti as filterDone, To as buildWithScope, Ts as findError, U as ensuring$1, Uc as makeSemaphore, Ui as nextPow2, Uo as forkUnsafe, Ut as makeSpan, V as die$2, Vc as makeLatch, Wc as makeSemaphoreUnsafe, Wr as void_, Xo as doneUnsafe, Xr as withFiber$1, Y as failSync$1, _c as fiberAwait, _n as promise, _u as empty$2, a as acquireRelease$1, al as suspend$2, an as onError$1, ar as services, bc as fiberInterruptAll, bi as toStepWithMetadata, br as tapError$1, cn as onExit$1, ct as flatMapEager, dr as succeedNone, ds as isFailure$1, en as matchCauseEffect$1, er as scope, et as filterMapEffect$1, fc as exitInterrupt$1, fl as void_$1, fn as onInterrupt, fr as succeedSome, fs as isSuccess$1, ft as fnUntraced, g as asVoid, gc as exitZipRight, gs as void_$2, gt as forkChild, h as asSome, hc as exitVoid, hr as tap$1, hs as succeed$3, ht as forever$1, ic as causeInterrupt, id as headUnsafe, in as never$1, jl as get$2, kl as add, ko as makeMemoMapUnsafe, ku as isArrayNonEmpty, l as andThen, ls as interrupt$2, lt as flatten$1, m as as$1, mi as CurrentMetadata, ml as addSpanStackTrace, mr as sync$1, mt as forEach$1, nl as succeed$4, oi as yieldNow, ol as sync$2, or as servicesWith$1, os as failCause$3, pl as whileLoop, pr as suspend$1, q as failCause$2, st as flatMap$1, tc as callback$1, ts as makeUnsafe$3, uc as endSpan, ul as uninterruptibleMask, ur as succeed$2, us as isExit, vc as fiberAwaitAll, vs as Done$1, vt as forkIn, w as catchCause$1, wc as fiberJoinAll, wi as doneExitFromCause, wo as buildWithMemoMap, wt as gen, wu as fromIterable$2, xc as fiberInterruptAllAs, xi as toStepWithSleep, xl as ParentSpan, xn as provideServices$1, xs as die$1, yc as fiberInterrupt, yl as TracerTimingEnabled, yn as provideService$1, yt as forkScoped, zn as runForkWith, zo as addFinalizerExit } from "./Effect-DrBRDdmt.js";
import { ao as toReadonlyArray } from "./Schema-DuK_yWH0.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/MutableHashMap.js
var MutableHashMap_exports = /* @__PURE__ */ __exportAll({
	clear: () => clear$2,
	empty: () => empty$1,
	forEach: () => forEach,
	fromIterable: () => fromIterable$1,
	get: () => get$1,
	has: () => has,
	isEmpty: () => isEmpty$1,
	keys: () => keys,
	make: () => make$6,
	modify: () => modify,
	modifyAt: () => modifyAt,
	remove: () => remove$1,
	set: () => set$1,
	size: () => size$2,
	values: () => values
});
var TypeId$4 = "~effect/collections/MutableHashMap";
var MutableHashMapProto = {
	[TypeId$4]: TypeId$4,
	[Symbol.iterator]() {
		return this.backing[Symbol.iterator]();
	},
	toString() {
		return `MutableHashMap(${format(Array.from(this))})`;
	},
	toJSON() {
		return {
			_id: "MutableHashMap",
			values: toJson(Array.from(this))
		};
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Creates an empty MutableHashMap.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.empty<string, number>()
*
* // Add some entries
* MutableHashMap.set(map, "key1", 42)
* MutableHashMap.set(map, "key2", 100)
*
* console.log(MutableHashMap.size(map)) // 2
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty$1 = () => {
	const self = Object.create(MutableHashMapProto);
	self.backing = /* @__PURE__ */ new Map();
	self.buckets = /* @__PURE__ */ new Map();
	return self;
};
/**
* Creates a MutableHashMap from a variable number of key-value pairs.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(
*   ["key1", 42],
*   ["key2", 100],
*   ["key3", 200]
* )
*
* console.log(MutableHashMap.get(map, "key1")) // Some(42)
* console.log(MutableHashMap.size(map)) // 3
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$6 = (...entries) => fromIterable$1(entries);
/**
* Creates a MutableHashMap from an iterable collection of key-value pairs.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const entries = [
*   ["apple", 1],
*   ["banana", 2],
*   ["cherry", 3]
* ] as const
*
* const map = MutableHashMap.fromIterable(entries)
*
* console.log(MutableHashMap.get(map, "banana")) // Some(2)
* console.log(MutableHashMap.size(map)) // 3
*
* // Works with any iterable
* const fromMap = MutableHashMap.fromIterable(new Map([["x", 10], ["y", 20]]))
* console.log(MutableHashMap.get(fromMap, "x")) // Some(10)
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromIterable$1 = (entries) => {
	const self = empty$1();
	for (const [key, value] of entries) set$1(self, key, value);
	return self;
};
/**
* Retrieves the value associated with the specified key from the MutableHashMap.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(["key1", 42], ["key2", 100])
*
* console.log(MutableHashMap.get(map, "key1")) // Some(42)
* console.log(MutableHashMap.get(map, "key3")) // None
*
* // Pipe-able version
* const getValue = MutableHashMap.get("key1")
* console.log(getValue(map)) // Some(42)
* ```
*
* @since 2.0.0
* @category elements
*/
var get$1 = /*#__PURE__*/ dual(2, (self, key) => {
	if (self.backing.has(key)) return some(self.backing.get(key));
	else if (isSimpleKey(key)) return none();
	const refKey = referentialKeysCache.get(self);
	if (refKey !== void 0) return self.backing.has(refKey) ? some(self.backing.get(refKey)) : none();
	const hash$1 = hash(key);
	const bucket = self.buckets.get(hash$1);
	if (bucket === void 0) return none();
	return getFromBucket(self, bucket, key);
});
var referentialKeysCache = /*#__PURE__*/ new WeakMap();
var isSimpleKey = (u) => typeof u !== "object" && typeof u !== "function";
/**
* Extracts all keys from the MutableHashMap into an array.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(
*   ["apple", 1],
*   ["banana", 2],
*   ["cherry", 3]
* )
*
* const allKeys = Array.from(MutableHashMap.keys(map))
* console.log(allKeys) // ["apple", "banana", "cherry"]
*
* // Useful for iteration or validation
* const hasRequiredKeys = allKeys.includes("apple") && allKeys.includes("banana")
* ```
*
* @since 3.8.0
* @category elements
*/
var keys = (self) => self.backing.keys();
/**
* Extracts all values from the MutableHashMap into an array.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(
*   ["apple", 1],
*   ["banana", 2],
*   ["cherry", 3]
* )
*
* const allValues = Array.from(MutableHashMap.values(map))
* console.log(allValues) // [1, 2, 3]
*
* // Useful for calculations
* const total = allValues.reduce((sum, value) => sum + value, 0)
* console.log(total) // 6
*
* // Filter values
* const largeValues = allValues.filter((value) => value > 1)
* console.log(largeValues) // [2, 3]
* ```
*
* @since 3.8.0
* @category elements
*/
var values = (self) => self.backing.values();
var getFromBucket = (self, bucket, key) => {
	for (let i = 0, len = bucket.length; i < len; i++) if (equals(key, bucket[i])) {
		const refKey = bucket[i];
		referentialKeysCache.set(key, refKey);
		return some(self.backing.get(refKey));
	}
	return none();
};
/**
* Checks if the MutableHashMap contains the specified key.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(["key1", 42], ["key2", 100])
*
* console.log(MutableHashMap.has(map, "key1")) // true
* console.log(MutableHashMap.has(map, "key3")) // false
*
* // Pipe-able version
* const hasKey = MutableHashMap.has("key1")
* console.log(hasKey(map)) // true
* ```
*
* @since 2.0.0
* @category elements
*/
var has = /*#__PURE__*/ dual(2, (self, key) => isSome(get$1(self, key)));
/**
* Sets a key-value pair in the MutableHashMap, mutating the map in place.
* If the key already exists, its value is updated.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.empty<string, number>()
*
* // Add new entries
* MutableHashMap.set(map, "key1", 42)
* MutableHashMap.set(map, "key2", 100)
*
* console.log(MutableHashMap.get(map, "key1")) // Some(42)
* console.log(MutableHashMap.size(map)) // 2
*
* // Update existing entry
* MutableHashMap.set(map, "key1", 999)
* console.log(MutableHashMap.get(map, "key1")) // Some(999)
*
* // Pipe-able version
* const setKey = MutableHashMap.set("key3", 300)
* setKey(map)
* console.log(MutableHashMap.size(map)) // 3
* ```
*
* @since 2.0.0
* @category mutations
*/
var set$1 = /*#__PURE__*/ dual(3, (self, key, value) => {
	if (self.backing.has(key) || isSimpleKey(key)) {
		self.backing.set(key, value);
		return self;
	}
	let refKey = referentialKeysCache.get(self);
	if (refKey !== void 0 && self.backing.has(refKey)) {
		self.backing.set(refKey, value);
		return self;
	}
	const hash$2 = hash(key);
	const bucket = self.buckets.get(hash$2);
	if (bucket === void 0) {
		self.buckets.set(hash$2, [key]);
		self.backing.set(key, value);
		return self;
	}
	refKey = getRefKey(bucket, key);
	if (refKey === void 0) {
		bucket.push(key);
		refKey = key;
	}
	self.backing.set(refKey, value);
	return self;
});
var getRefKey = (bucket, key) => {
	for (let i = 0, len = bucket.length; i < len; i++) if (equals(key, bucket[i])) {
		referentialKeysCache.set(key, bucket[i]);
		return bucket[i];
	}
};
/**
* Updates the value of the specified key within the MutableHashMap if it exists.
* If the key doesn't exist, the map remains unchanged.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(["count", 5], ["total", 100])
*
* // Increment existing value
* MutableHashMap.modify(map, "count", (n) => n + 1)
* console.log(MutableHashMap.get(map, "count")) // Some(6)
*
* // Double existing value
* MutableHashMap.modify(map, "total", (n) => n * 2)
* console.log(MutableHashMap.get(map, "total")) // Some(200)
*
* // Try to modify non-existent key (no effect)
* MutableHashMap.modify(map, "missing", (n) => n + 1)
* console.log(MutableHashMap.has(map, "missing")) // false
*
* // Pipe-able version
* const increment = MutableHashMap.modify("count", (n: number) => n + 1)
* increment(map)
* ```
*
* @since 2.0.0
* @category mutations
*/
var modify = /*#__PURE__*/ dual(3, (self, key, f) => {
	const hasKey = self.backing.has(key);
	if (hasKey || isSimpleKey(key)) {
		if (hasKey) self.backing.set(key, f(self.backing.get(key)));
		return self;
	}
	let refKey = referentialKeysCache.get(self);
	if (refKey !== void 0 && self.backing.has(refKey)) {
		self.backing.set(refKey, f(self.backing.get(refKey)));
		return self;
	}
	const hash$3 = hash(key);
	const bucket = self.buckets.get(hash$3);
	if (bucket === void 0) return self;
	refKey = getRefKey(bucket, key);
	if (refKey === void 0) return self;
	self.backing.set(refKey, f(self.backing.get(refKey)));
	return self;
});
/**
* Sets or removes the specified key in the MutableHashMap using an update function.
* The function receives the current value as an Option and returns an Option.
* If the function returns Some, the key is set to that value.
* If the function returns None, the key is removed.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
* import * as Option from "effect/Option"
*
* const map = MutableHashMap.make(["count", 5])
*
* // Update existing key
* MutableHashMap.modifyAt(
*   map,
*   "count",
*   (option) => Option.map(option, (n) => n * 2)
* )
* console.log(MutableHashMap.get(map, "count")) // Some(10)
*
* // Add new key
* MutableHashMap.modifyAt(
*   map,
*   "new",
*   (option) => Option.isNone(option) ? Option.some(42) : option
* )
* console.log(MutableHashMap.get(map, "new")) // Some(42)
*
* // Remove key by returning None
* MutableHashMap.modifyAt(map, "count", () => Option.none())
* console.log(MutableHashMap.has(map, "count")) // false
*
* // Conditional update
* MutableHashMap.modifyAt(
*   map,
*   "new",
*   (option) => Option.filter(option, (n) => n > 50) // Remove if <= 50
* )
* console.log(MutableHashMap.has(map, "new")) // false (42 <= 50)
* ```
*
* @since 2.0.0
* @category mutations
*/
var modifyAt = /*#__PURE__*/ dual(3, (self, key, f) => {
	const current = get$1(self, key);
	const result = f(current);
	if (isNone(result)) {
		if (isSome(current)) remove$1(self, key);
		return self;
	}
	set$1(self, key, result.value);
	return self;
});
/**
* Removes the specified key from the MutableHashMap, mutating the map in place.
* If the key doesn't exist, the map remains unchanged.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(
*   ["key1", 42],
*   ["key2", 100],
*   ["key3", 200]
* )
*
* console.log(MutableHashMap.size(map)) // 3
*
* // Remove existing key
* MutableHashMap.remove(map, "key2")
* console.log(MutableHashMap.size(map)) // 2
* console.log(MutableHashMap.has(map, "key2")) // false
*
* // Remove non-existent key (no effect)
* MutableHashMap.remove(map, "nonexistent")
* console.log(MutableHashMap.size(map)) // 2
*
* // Pipe-able version
* const removeKey = MutableHashMap.remove("key1")
* removeKey(map)
* console.log(MutableHashMap.size(map)) // 1
* ```
*
* @since 2.0.0
* @category mutations
*/
var remove$1 = /*#__PURE__*/ dual(2, (self, key_) => {
	if (isSimpleKey(key_)) {
		self.backing.delete(key_);
		return self;
	}
	const key = referentialKeysCache.get(self) ?? key_;
	const hash$4 = hash(key);
	const bucket = self.buckets.get(hash$4);
	if (bucket === void 0) return self;
	for (let i = 0, len = bucket.length; i < len; i++) {
		const bkey = bucket[i];
		if (bkey === key || equals(key, bkey)) {
			self.backing.delete(bkey);
			bucket.splice(i, 1);
			break;
		}
	}
	if (bucket.length === 0) self.buckets.delete(hash$4);
	return self;
});
/**
* Removes all key-value pairs from the MutableHashMap, mutating the map in place.
* The map becomes empty after this operation.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.make(
*   ["key1", 42],
*   ["key2", 100],
*   ["key3", 200]
* )
*
* console.log(MutableHashMap.size(map)) // 3
*
* // Clear all entries
* MutableHashMap.clear(map)
*
* console.log(MutableHashMap.size(map)) // 0
* console.log(MutableHashMap.has(map, "key1")) // false
*
* // Can still add new entries after clearing
* MutableHashMap.set(map, "new", 999)
* console.log(MutableHashMap.size(map)) // 1
* ```
*
* @since 2.0.0
* @category mutations
*/
var clear$2 = (self) => {
	self.backing.clear();
	self.buckets.clear();
	return self;
};
/**
* Returns the number of key-value pairs in the MutableHashMap.
*
* @example
* ```ts
* import * as MutableHashMap from "effect/MutableHashMap"
*
* const map = MutableHashMap.empty<string, number>()
* console.log(MutableHashMap.size(map)) // 0
*
* MutableHashMap.set(map, "key1", 42)
* MutableHashMap.set(map, "key2", 100)
* console.log(MutableHashMap.size(map)) // 2
*
* MutableHashMap.remove(map, "key1")
* console.log(MutableHashMap.size(map)) // 1
*
* MutableHashMap.clear(map)
* console.log(MutableHashMap.size(map)) // 0
* ```
*
* @since 2.0.0
* @category elements
*/
var size$2 = (self) => self.backing.size;
/**
* @since 2.0.0
*/
var isEmpty$1 = (self) => self.backing.size === 0;
/**
* @since 2.0.0
*/
var forEach = /*#__PURE__*/ dual(2, (self, f) => {
	self.backing.forEach(f);
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Fiber.js
var Fiber_exports = /* @__PURE__ */ __exportAll({
	await: () => await_$1,
	awaitAll: () => awaitAll,
	getCurrent: () => getCurrent,
	interrupt: () => interrupt$1,
	interruptAll: () => interruptAll,
	interruptAllAs: () => interruptAllAs,
	interruptAs: () => interruptAs,
	isFiber: () => isFiber,
	join: () => join,
	joinAll: () => joinAll,
	runIn: () => runIn
});
var await_$1 = fiberAwait;
/**
* Waits for all fibers in the provided iterable to complete and returns
* an array of their exit values.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   const fiber1 = yield* Effect.forkChild(Effect.succeed(1))
*   const fiber2 = yield* Effect.forkChild(Effect.succeed(2))
*   const exits = yield* Fiber.awaitAll([fiber1, fiber2])
*   console.log(exits) // [Exit.succeed(1), Exit.succeed(2)]
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var awaitAll = fiberAwaitAll;
/**
* Joins a fiber, blocking until it completes. If the fiber succeeds,
* returns its value. If it fails, the error is propagated.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   const fiber = yield* Effect.forkChild(Effect.succeed(42))
*   const result = yield* Fiber.join(fiber)
*   console.log(result) // 42
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var join = fiberJoin;
/**
* @since 2.0.0
* @category combinators
*/
var joinAll = fiberJoinAll;
/**
* Interrupts a fiber, causing it to stop executing and clean up any
* acquired resources.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   const fiber = yield* Effect.forkChild(
*     Effect.delay("1 second")(Effect.succeed(42))
*   )
*   yield* Fiber.interrupt(fiber)
*   console.log("Fiber interrupted")
* })
* ```
*
* @since 2.0.0
* @category interruption
*/
var interrupt$1 = fiberInterrupt;
/**
* Interrupts a fiber with a specific fiber ID as the interruptor. This allows
* tracking which fiber initiated the interruption.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   const targetFiber = yield* Effect.forkChild(
*     Effect.delay("5 seconds")(Effect.succeed("task completed"))
*   )
*
*   // Interrupt the fiber, specifying fiber ID 123 as the interruptor
*   yield* Fiber.interruptAs(targetFiber, 123)
*   console.log("Fiber interrupted by fiber #123")
* })
* ```
*
* @since 2.0.0
* @category interruption
*/
var interruptAs = fiberInterruptAs;
/**
* Interrupts all fibers in the provided iterable, causing them to stop executing
* and clean up any acquired resources.
*
* @example
* ```ts
* import { Console, Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create multiple long-running fibers
*   const fiber1 = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* Effect.sleep("5 seconds")
*       yield* Console.log("Task 1 completed")
*       return "result1"
*     })
*   )
*
*   const fiber2 = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* Effect.sleep("3 seconds")
*       yield* Console.log("Task 2 completed")
*       return "result2"
*     })
*   )
*
*   const fiber3 = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* Effect.sleep("4 seconds")
*       yield* Console.log("Task 3 completed")
*       return "result3"
*     })
*   )
*
*   // Wait a bit, then interrupt all fibers
*   yield* Effect.sleep("1 second")
*   yield* Console.log("Interrupting all fibers...")
*   yield* Fiber.interruptAll([fiber1, fiber2, fiber3])
*   yield* Console.log("All fibers have been interrupted")
* })
* ```
*
* @since 2.0.0
* @category interruption
*/
var interruptAll = fiberInterruptAll;
/**
* Interrupts all fibers in the provided iterable using the specified fiber ID as the
* interrupting fiber. This allows you to control which fiber is considered the source
* of the interruption, which can be useful for debugging and tracing.
*
* @example
* ```ts
* import { Console, Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a controlling fiber
*   const controllerFiber = yield* Effect.forkChild(Effect.succeed("controller"))
*
*   // Create multiple worker fibers
*   const worker1 = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* Effect.sleep("5 seconds")
*       yield* Console.log("Worker 1 completed")
*       return "worker1"
*     })
*   )
*
*   const worker2 = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* Effect.sleep("3 seconds")
*       yield* Console.log("Worker 2 completed")
*       return "worker2"
*     })
*   )
*
*   // Interrupt all workers using the controller fiber's ID
*   yield* Effect.sleep("1 second")
*   yield* Console.log("Interrupting workers from controller...")
*   yield* Fiber.interruptAllAs([worker1, worker2], controllerFiber.id)
*   yield* Console.log("All workers interrupted by controller")
* })
* ```
*
* @since 2.0.0
* @category interruption
*/
var interruptAllAs = fiberInterruptAllAs;
/**
* Tests if a value is a Fiber. This is a type guard that can be used to
* determine if an unknown value is a Fiber instance.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a fiber
*   const fiber = yield* Effect.forkChild(Effect.succeed(42))
*
*   // Test if values are fibers
*   console.log(Fiber.isFiber(fiber)) // true
*   console.log(Fiber.isFiber("hello")) // false
*   console.log(Fiber.isFiber(42)) // false
*   console.log(Fiber.isFiber(null)) // false
*
*   // Use as a type guard
*   const maybeValue: unknown = fiber
*   if (Fiber.isFiber(maybeValue)) {
*     // TypeScript knows maybeValue is a Fiber here
*     console.log(`Fiber ID: ${maybeValue.id}`)
*   }
* })
* ```
*
* @since 2.0.0
* @category guards
*/
var isFiber = (u) => hasProperty(u, FiberTypeId);
/**
* Returns the current fiber if called from within a fiber context,
* otherwise returns `undefined`.
*
* @example
* ```ts
* import { Effect, Fiber } from "effect"
*
* const program = Effect.gen(function*() {
*   const current = Fiber.getCurrent()
*   if (current) {
*     console.log(`Current fiber ID: ${current.id}`)
*   }
* })
* ```
*
* @since 2.0.0
* @category accessors
*/
var getCurrent = getCurrentFiber;
/**
* Links the lifetime of a fiber to the provided scope.
*
* @since 4.0.0
* @category Scope
*/
var runIn = fiberRunIn;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Latch.js
var Latch_exports = /* @__PURE__ */ __exportAll({
	make: () => make$5,
	makeUnsafe: () => makeUnsafe$1
});
/**
* Creates a new Latch unsafely.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.makeLatchUnsafe`
*
* @example
* ```ts
* import { Effect, Latch } from "effect"
*
* const latch = Latch.makeUnsafe(false)
*
* const waiter = Effect.gen(function*() {
*   yield* Effect.log("Waiting for latch to open...")
*   yield* latch.await
*   yield* Effect.log("Latch opened! Continuing...")
* })
*
* const opener = Effect.gen(function*() {
*   yield* Effect.sleep("2 seconds")
*   yield* Effect.log("Opening latch...")
*   yield* latch.open
* })
*
* const program = Effect.all([waiter, opener])
* ```
*
* @category constructors
* @since 3.8.0
*/
var makeUnsafe$1 = makeLatchUnsafe;
/**
* Creates a new Latch.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.makeLatch`
*
* @example
* ```ts
* import { Effect, Latch } from "effect"
*
* const program = Effect.gen(function*() {
*   const latch = yield* Latch.make(false)
*
*   const waiter = Effect.gen(function*() {
*     yield* Effect.log("Waiting for latch to open...")
*     yield* latch.await
*     yield* Effect.log("Latch opened! Continuing...")
*   })
*
*   const opener = Effect.gen(function*() {
*     yield* Effect.sleep("2 seconds")
*     yield* Effect.log("Opening latch...")
*     yield* latch.open
*   })
*
*   yield* Effect.all([waiter, opener])
* })
* ```
*
* @category constructors
* @since 3.8.0
*/
var make$5 = makeLatch;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/MutableList.js
/**
* @fileoverview
* MutableList is an efficient, mutable linked list implementation optimized for high-throughput
* scenarios like logging, queuing, and streaming. It uses a bucket-based architecture where
* elements are stored in arrays (buckets) linked together, providing optimal performance for
* both append and prepend operations.
*
* The implementation uses a sophisticated bucket system:
* - Each bucket contains an array of elements with an offset pointer
* - Buckets can be marked as mutable or immutable for optimization
* - Elements are taken from the head and added to the tail
* - Memory is efficiently managed through bucket reuse and cleanup
*
* Key Features:
* - Highly optimized for high-frequency append/prepend operations
* - Memory efficient with automatic cleanup of consumed elements
* - Support for bulk operations (appendAll, prependAll, takeN)
* - Filtering and removal operations
* - Zero-copy optimizations for certain scenarios
*
* Performance Characteristics:
* - Append/Prepend: O(1) amortized
* - Take/TakeN: O(1) per element taken
* - Length: O(1)
* - Clear: O(1)
* - Filter: O(n)
*
* Ideal Use Cases:
* - High-throughput logging systems
* - Producer-consumer queues
* - Streaming data buffers
* - Real-time data processing pipelines
*
* @since 4.0.0
* @category data-structures
*/
var MutableList_exports = /* @__PURE__ */ __exportAll({
	Empty: () => Empty,
	append: () => append,
	appendAll: () => appendAll,
	appendAllUnsafe: () => appendAllUnsafe,
	clear: () => clear$1,
	filter: () => filter$1,
	make: () => make$4,
	prepend: () => prepend,
	prependAll: () => prependAll,
	prependAllUnsafe: () => prependAllUnsafe,
	remove: () => remove,
	take: () => take$2,
	takeAll: () => takeAll$2,
	takeN: () => takeN$1,
	takeNVoid: () => takeNVoid,
	toArray: () => toArray,
	toArrayN: () => toArrayN
});
/**
* A unique symbol used to represent an empty result when taking elements from a MutableList.
* This symbol is returned by `take` when the list is empty, allowing for safe type checking.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<string>()
*
* // Take from empty list returns Empty symbol
* const result = MutableList.take(list)
* console.log(result === MutableList.Empty) // true
*
* // Safe pattern for checking emptiness
* const processNext = (queue: MutableList.MutableList<string>) => {
*   const item = MutableList.take(queue)
*   if (item === MutableList.Empty) {
*     console.log("Queue is empty")
*     return null
*   }
*   return item.toUpperCase()
* }
*
* // Compare with other empty results
* MutableList.append(list, "hello")
* const next = MutableList.take(list)
* console.log(next !== MutableList.Empty) // true, got "hello"
*
* const empty = MutableList.take(list)
* console.log(empty === MutableList.Empty) // true, list is empty
* ```
*
* @since 4.0.0
* @category Symbols
*/
var Empty = /*#__PURE__*/ Symbol.for("effect/MutableList/Empty");
/**
* Creates an empty MutableList.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<string>()
*
* // Add elements
* MutableList.append(list, "first")
* MutableList.append(list, "second")
* MutableList.prepend(list, "beginning")
*
* console.log(list.length) // 3
*
* // Take elements in FIFO order (from head)
* console.log(MutableList.take(list)) // "beginning"
* console.log(MutableList.take(list)) // "first"
* console.log(MutableList.take(list)) // "second"
* ```
*
* @since 4.0.0
* @category constructors
*/
var make$4 = () => ({
	head: void 0,
	tail: void 0,
	length: 0
});
var emptyBucket = () => ({
	array: [],
	mutable: true,
	offset: 0,
	next: void 0
});
/**
* Appends an element to the end of the MutableList.
* This operation is optimized for high-frequency usage.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
*
* // Append elements one by one
* MutableList.append(list, 1)
* MutableList.append(list, 2)
* MutableList.append(list, 3)
*
* console.log(list.length) // 3
*
* // Elements are taken from head (FIFO)
* console.log(MutableList.take(list)) // 1
* console.log(MutableList.take(list)) // 2
* console.log(MutableList.take(list)) // 3
*
* // High-throughput usage
* for (let i = 0; i < 10000; i++) {
*   MutableList.append(list, i)
* }
* ```
*
* @since 4.0.0
* @category mutations
*/
var append = (self, message) => {
	if (!self.tail) self.head = self.tail = emptyBucket();
	else if (!self.tail.mutable) {
		self.tail.next = emptyBucket();
		self.tail = self.tail.next;
	}
	self.tail.array.push(message);
	self.length++;
};
/**
* Prepends an element to the beginning of the MutableList.
* This operation is optimized for high-frequency usage.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<string>()
*
* // Prepend elements (they'll be at the front)
* MutableList.prepend(list, "third")
* MutableList.prepend(list, "second")
* MutableList.prepend(list, "first")
*
* console.log(list.length) // 3
*
* // Elements taken from head (most recently prepended first)
* console.log(MutableList.take(list)) // "first"
* console.log(MutableList.take(list)) // "second"
* console.log(MutableList.take(list)) // "third"
*
* // Use case: priority items or stack-like behavior
* MutableList.append(list, "normal")
* MutableList.prepend(list, "priority") // This will be taken first
* console.log(MutableList.take(list)) // "priority"
* ```
*
* @since 4.0.0
* @category mutations
*/
var prepend = (self, message) => {
	self.head = {
		array: [message],
		mutable: true,
		offset: 0,
		next: self.head
	};
	self.length++;
};
/**
* Prepends all elements from an iterable to the beginning of the MutableList.
* The elements are added in order, so the first element in the iterable becomes
* the new head of the list.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.append(list, 4)
* MutableList.append(list, 5)
*
* // Prepend multiple elements
* MutableList.prependAll(list, [1, 2, 3])
*
* console.log(list.length) // 5
*
* // Elements are taken in order: [1, 2, 3, 4, 5]
* console.log(MutableList.takeAll(list)) // [1, 2, 3, 4, 5]
*
* // Works with any iterable
* const newList = MutableList.make<string>()
* MutableList.prependAll(newList, "hello") // Prepends each character
* console.log(MutableList.takeAll(newList)) // ["h", "e", "l", "l", "o"]
* ```
*
* @since 4.0.0
* @category mutations
*/
var prependAll = (self, messages) => prependAllUnsafe(self, fromIterable$2(messages), !Array.isArray(messages));
/**
* Prepends all elements from a ReadonlyArray to the beginning of the MutableList.
* This is an optimized version that can reuse the array when mutable=true.
*
* ⚠️ **Warning**: When mutable=true, the input array may be modified internally.
* Only use mutable=true when you control the array lifecycle.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.append(list, 4)
*
* // Safe usage (default mutable=false)
* const items = [1, 2, 3]
* MutableList.prependAllUnsafe(list, items)
* console.log(items) // [1, 2, 3] - unchanged
*
* // Unsafe but efficient usage (mutable=true)
* const mutableItems = [10, 20, 30]
* MutableList.prependAllUnsafe(list, mutableItems, true)
* // mutableItems may be modified internally for efficiency
*
* console.log(MutableList.takeAll(list)) // [10, 20, 30, 1, 2, 3, 4]
* ```
*
* @since 4.0.0
* @category mutations
*/
var prependAllUnsafe = (self, messages, mutable = false) => {
	self.head = {
		array: messages,
		mutable,
		offset: 0,
		next: self.head
	};
	self.length += self.head.array.length;
};
/**
* Appends all elements from an iterable to the end of the MutableList.
* Returns the number of elements added.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.append(list, 1)
* MutableList.append(list, 2)
*
* // Append multiple elements
* const added = MutableList.appendAll(list, [3, 4, 5])
* console.log(added) // 3
* console.log(list.length) // 5
*
* // Elements maintain order: [1, 2, 3, 4, 5]
* console.log(MutableList.takeAll(list)) // [1, 2, 3, 4, 5]
*
* // Works with any iterable
* const newList = MutableList.make<string>()
* MutableList.appendAll(newList, new Set(["a", "b", "c"]))
* console.log(MutableList.takeAll(newList)) // ["a", "b", "c"]
*
* // Useful for bulk loading
* const bulkList = MutableList.make<number>()
* const count = MutableList.appendAll(
*   bulkList,
*   Array.from({ length: 1000 }, (_, i) => i)
* )
* console.log(count) // 1000
* ```
*
* @since 4.0.0
* @category mutations
*/
var appendAll = (self, messages) => appendAllUnsafe(self, fromIterable$2(messages), !Array.isArray(messages));
/**
* Appends all elements from a ReadonlyArray to the end of the MutableList.
* This is an optimized version that can reuse the array when mutable=true.
* Returns the number of elements added.
*
* ⚠️ **Warning**: When mutable=true, the input array may be modified internally.
* Only use mutable=true when you control the array lifecycle.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.append(list, 1)
*
* // Safe usage (default mutable=false)
* const items = [2, 3, 4]
* const added = MutableList.appendAllUnsafe(list, items)
* console.log(added) // 3
* console.log(items) // [2, 3, 4] - unchanged
*
* // Unsafe but efficient usage (mutable=true)
* const mutableItems = [5, 6, 7]
* MutableList.appendAllUnsafe(list, mutableItems, true)
* // mutableItems may be modified internally for efficiency
*
* console.log(MutableList.takeAll(list)) // [1, 2, 3, 4, 5, 6, 7]
*
* // High-performance bulk operations
* const bigArray = new Array(10000).fill(0).map((_, i) => i)
* MutableList.appendAllUnsafe(list, bigArray, true) // Very efficient
* ```
*
* @since 4.0.0
* @category mutations
*/
var appendAllUnsafe = (self, messages, mutable = false) => {
	const chunk = {
		array: messages,
		mutable,
		offset: 0,
		next: void 0
	};
	if (self.head) self.tail = self.tail.next = chunk;
	else self.head = self.tail = chunk;
	self.length += messages.length;
	return messages.length;
};
/**
* Removes all elements from the MutableList, resetting it to an empty state.
* This operation is highly optimized and releases all internal memory.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.appendAll(list, [1, 2, 3, 4, 5])
*
* console.log(list.length) // 5
*
* // Clear all elements
* MutableList.clear(list)
*
* console.log(list.length) // 0
* console.log(MutableList.take(list)) // Empty
*
* // Can still use the list after clearing
* MutableList.append(list, 42)
* console.log(list.length) // 1
*
* // Useful for resetting queues or buffers
* function resetBuffer<T>(buffer: MutableList.MutableList<T>) {
*   MutableList.clear(buffer)
*   console.log("Buffer cleared and ready for reuse")
* }
* ```
*
* @since 4.0.0
* @category mutations
*/
var clear$1 = (self) => {
	self.head = self.tail = void 0;
	self.length = 0;
};
/**
* Takes up to N elements from the beginning of the MutableList and returns them as an array.
* The taken elements are removed from the list. This operation is optimized for performance
* and includes zero-copy optimizations when possible.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.appendAll(list, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
*
* console.log(list.length) // 10
*
* // Take first 3 elements
* const first3 = MutableList.takeN(list, 3)
* console.log(first3) // [1, 2, 3]
* console.log(list.length) // 7
*
* // Take more than available
* const remaining = MutableList.takeN(list, 20)
* console.log(remaining) // [4, 5, 6, 7, 8, 9, 10]
* console.log(list.length) // 0
*
* // Take from empty list
* const empty = MutableList.takeN(list, 5)
* console.log(empty) // []
*
* // Batch processing pattern
* const queue = MutableList.make<string>()
* MutableList.appendAll(queue, ["task1", "task2", "task3", "task4", "task5"])
*
* while (queue.length > 0) {
*   const batch = MutableList.takeN(queue, 2) // Process 2 at a time
*   console.log("Processing batch:", batch)
* }
* ```
*
* @since 4.0.0
* @category elements
*/
var takeN$1 = (self, n) => {
	if (n <= 0 || !self.head) return [];
	n = Math.min(n, self.length);
	if (n === self.length && self.head?.offset === 0 && !self.head.next) {
		const array = self.head.array;
		clear$1(self);
		return array;
	}
	const array = new Array(n);
	let index = 0;
	let chunk = self.head;
	while (chunk) {
		while (chunk.offset < chunk.array.length) {
			array[index++] = chunk.array[chunk.offset];
			if (chunk.mutable) chunk.array[chunk.offset] = void 0;
			chunk.offset++;
			if (index === n) {
				self.head = chunk;
				self.length -= n;
				if (self.length === 0) clear$1(self);
				return array;
			}
		}
		chunk = chunk.next;
	}
	clear$1(self);
	return array;
};
/**
* @since 4.0.0
* @category elements
*/
var takeNVoid = (self, n) => {
	if (n <= 0 || !self.head) return;
	n = Math.min(n, self.length);
	if (n === self.length && self.head?.offset === 0 && !self.head.next) {
		clear$1(self);
		return;
	}
	let count = 0;
	let chunk = self.head;
	while (chunk) {
		const size = chunk.array.length - chunk.offset;
		if (count + size > n) {
			chunk.offset += n - count;
			self.head = chunk;
			self.length -= n;
			return;
		}
		count += size;
		chunk = chunk.next;
	}
	clear$1(self);
};
/**
* Takes all elements from the MutableList and returns them as an array.
* The list becomes empty after this operation. This is equivalent to takeN(list, list.length).
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<string>()
* MutableList.appendAll(list, ["apple", "banana", "cherry"])
*
* console.log(list.length) // 3
*
* // Take all elements
* const allItems = MutableList.takeAll(list)
* console.log(allItems) // ["apple", "banana", "cherry"]
* console.log(list.length) // 0
*
* // Useful for converting to array and clearing
* const queue = MutableList.make<number>()
* MutableList.appendAll(queue, [1, 2, 3, 4, 5])
*
* const snapshot = MutableList.takeAll(queue)
* console.log("Queue contents:", snapshot)
* console.log("Queue is now empty:", queue.length === 0)
*
* // Drain pattern for processing
* function drainAndProcess<T>(
*   list: MutableList.MutableList<T>,
*   processor: (items: Array<T>) => void
* ) {
*   if (list.length > 0) {
*     const items = MutableList.takeAll(list)
*     processor(items)
*   }
* }
* ```
*
* @since 4.0.0
* @category elements
*/
var takeAll$2 = (self) => takeN$1(self, self.length);
/**
* Takes a single element from the beginning of the MutableList.
* Returns the element if available, or the Empty symbol if the list is empty.
* The taken element is removed from the list.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<string>()
* MutableList.appendAll(list, ["first", "second", "third"])
*
* // Take elements one by one
* console.log(MutableList.take(list)) // "first"
* console.log(list.length) // 2
*
* console.log(MutableList.take(list)) // "second"
* console.log(MutableList.take(list)) // "third"
* console.log(list.length) // 0
*
* // Take from empty list
* console.log(MutableList.take(list)) // Empty symbol
*
* // Check for empty using the Empty symbol
* const result = MutableList.take(list)
* if (result === MutableList.Empty) {
*   console.log("List is empty")
* } else {
*   console.log("Got element:", result)
* }
*
* // Consumer pattern
* function processNext<T>(
*   queue: MutableList.MutableList<T>,
*   processor: (item: T) => void
* ): boolean {
*   const item = MutableList.take(queue)
*   if (item !== MutableList.Empty) {
*     processor(item)
*     return true
*   }
*   return false
* }
* ```
*
* @since 4.0.0
* @category elements
*/
var take$2 = (self) => {
	if (!self.head) return Empty;
	const message = self.head.array[self.head.offset];
	if (self.head.mutable) self.head.array[self.head.offset] = void 0;
	self.head.offset++;
	self.length--;
	if (self.head.offset === self.head.array.length) if (self.head.next) self.head = self.head.next;
	else clear$1(self);
	return message;
};
/**
* @since 4.0.0
* @category elements
*/
var toArrayN = (self, n) => {
	const length = Math.min(n, self.length);
	const out = new Array(length);
	let index = 0;
	let bucket = self.head;
	while (bucket) {
		for (let i = bucket.offset; i < bucket.array.length; i++) {
			out[index++] = bucket.array[i];
			if (index === length) return out;
		}
		bucket = bucket.next;
	}
	return out;
};
/**
* @since 4.0.0
* @category elements
*/
var toArray = (self) => toArrayN(self, self.length);
/**
* Filters the MutableList in place, keeping only elements that satisfy the predicate.
* This operation modifies the list and rebuilds its internal structure for efficiency.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<number>()
* MutableList.appendAll(list, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
*
* console.log(list.length) // 10
*
* // Keep only even numbers
* MutableList.filter(list, (n) => n % 2 === 0)
*
* console.log(list.length) // 5
* console.log(MutableList.takeAll(list)) // [2, 4, 6, 8, 10]
*
* // Filter with index
* const indexed = MutableList.make<string>()
* MutableList.appendAll(indexed, ["a", "b", "c", "d", "e"])
*
* // Keep elements at even indices
* MutableList.filter(indexed, (value, index) => index % 2 === 0)
* console.log(MutableList.takeAll(indexed)) // ["a", "c", "e"]
*
* // Real-world example: filtering a log queue
* const logs = MutableList.make<{ level: string; message: string }>()
* MutableList.appendAll(logs, [
*   { level: "INFO", message: "App started" },
*   { level: "ERROR", message: "Connection failed" },
*   { level: "DEBUG", message: "Cache hit" },
*   { level: "ERROR", message: "Timeout" }
* ])
*
* // Keep only errors
* MutableList.filter(logs, (log) => log.level === "ERROR")
* console.log(MutableList.takeAll(logs)) // Only error logs
* ```
*
* @since 4.0.0
* @category mutations
*/
var filter$1 = (self, f) => {
	const array = [];
	let chunk = self.head;
	while (chunk) {
		for (let i = chunk.offset; i < chunk.array.length; i++) if (f(chunk.array[i], i)) array.push(chunk.array[i]);
		chunk = chunk.next;
	}
	self.head = self.tail = {
		array,
		mutable: true,
		offset: 0,
		next: void 0
	};
};
/**
* Removes all occurrences of a specific value from the MutableList.
* This operation modifies the list in place.
*
* @example
* ```ts
* import * as MutableList from "effect/MutableList"
*
* const list = MutableList.make<string>()
* MutableList.appendAll(list, ["apple", "banana", "apple", "cherry", "apple"])
*
* console.log(list.length) // 5
*
* // Remove all occurrences of "apple"
* MutableList.remove(list, "apple")
*
* console.log(list.length) // 2
* console.log(MutableList.takeAll(list)) // ["banana", "cherry"]
*
* // Remove non-existent value (no effect)
* MutableList.remove(list, "grape")
* console.log(list.length) // 2
*
* // Real-world example: removing completed tasks
* const tasks = MutableList.make<{ id: number; status: string }>()
* MutableList.appendAll(tasks, [
*   { id: 1, status: "pending" },
*   { id: 2, status: "completed" },
*   { id: 3, status: "pending" },
*   { id: 4, status: "completed" }
* ])
*
* // Remove completed tasks by filtering status
* MutableList.filter(tasks, (task) => task.status !== "completed")
* console.log(MutableList.takeAll(tasks)) // Only pending tasks
* ```
*
* @since 4.0.0
* @category mutations
*/
var remove = (self, value) => filter$1(self, (v) => v !== value);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/MutableRef.js
/**
* @fileoverview
* MutableRef provides a mutable reference container that allows safe mutation of values
* in functional programming contexts. It serves as a bridge between functional and imperative
* programming paradigms, offering atomic operations for state management.
*
* Unlike regular variables, MutableRef encapsulates mutable state and provides controlled
* access through a standardized API. It supports atomic compare-and-set operations for
* thread-safe updates and integrates seamlessly with Effect's ecosystem.
*
* Key Features:
* - Mutable reference semantics with functional API
* - Atomic compare-and-set operations for safe concurrent updates
* - Specialized operations for numeric and boolean values
* - Chainable operations that return the reference or the value
* - Integration with Effect's Equal interface for value comparison
*
* Common Use Cases:
* - State containers in functional applications
* - Counters and accumulators
* - Configuration that needs to be updated at runtime
* - Caching and memoization scenarios
* - Inter-module communication via shared references
*
* Performance Characteristics:
* - Get/Set: O(1)
* - Compare-and-set: O(1)
* - All operations: O(1)
*
* @since 2.0.0
* @category data-structures
*/
var MutableRef_exports = /* @__PURE__ */ __exportAll({
	compareAndSet: () => compareAndSet,
	decrement: () => decrement,
	decrementAndGet: () => decrementAndGet,
	get: () => get,
	getAndDecrement: () => getAndDecrement,
	getAndIncrement: () => getAndIncrement,
	getAndSet: () => getAndSet,
	getAndUpdate: () => getAndUpdate,
	increment: () => increment,
	incrementAndGet: () => incrementAndGet,
	make: () => make$3,
	set: () => set,
	setAndGet: () => setAndGet,
	toggle: () => toggle,
	update: () => update,
	updateAndGet: () => updateAndGet
});
var TypeId$3 = "~effect/MutableRef";
var MutableRefProto = {
	[TypeId$3]: TypeId$3,
	...PipeInspectableProto,
	toJSON() {
		return {
			_id: "MutableRef",
			current: toJson(this.current)
		};
	}
};
/**
* Creates a new MutableRef with the specified initial value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* // Create a counter reference
* const counter = MutableRef.make(0)
* console.log(MutableRef.get(counter)) // 0
*
* // Create a configuration reference
* const config = MutableRef.make({ debug: false, timeout: 5000 })
* console.log(MutableRef.get(config)) // { debug: false, timeout: 5000 }
*
* // Create a string reference
* const status = MutableRef.make("idle")
* MutableRef.set(status, "running")
* console.log(MutableRef.get(status)) // "running"
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$3 = (value) => {
	const ref = Object.create(MutableRefProto);
	ref.current = value;
	return ref;
};
/**
* Atomically sets the value to newValue if the current value equals oldValue.
* Returns true if the value was updated, false otherwise.
* Uses Effect's Equal interface for value comparison.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const ref = MutableRef.make("initial")
*
* // Successful compare and set
* const updated = MutableRef.compareAndSet(ref, "initial", "updated")
* console.log(updated) // true
* console.log(MutableRef.get(ref)) // "updated"
*
* // Failed compare and set (value doesn't match)
* const failed = MutableRef.compareAndSet(ref, "initial", "failed")
* console.log(failed) // false
* console.log(MutableRef.get(ref)) // "updated" (unchanged)
*
* // Thread-safe counter increment
* const counter = MutableRef.make(5)
* let current: number
* do {
*   current = MutableRef.get(counter)
* } while (!MutableRef.compareAndSet(counter, current, current + 1))
*
* // Pipe-able version
* const casUpdate = MutableRef.compareAndSet("updated", "final")
* console.log(casUpdate(ref)) // true
* ```
*
* @since 2.0.0
* @category general
*/
var compareAndSet = /*#__PURE__*/ dual(3, (self, oldValue, newValue) => {
	if (equals(oldValue, self.current)) {
		self.current = newValue;
		return true;
	}
	return false;
});
/**
* Decrements a numeric MutableRef by 1 and returns the reference.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Decrement the counter
* MutableRef.decrement(counter)
* console.log(MutableRef.get(counter)) // 4
*
* // Chain operations
* MutableRef.decrement(counter)
* MutableRef.decrement(counter)
* console.log(MutableRef.get(counter)) // 2
*
* // Useful for countdown scenarios
* const countdown = MutableRef.make(10)
* while (MutableRef.get(countdown) > 0) {
*   console.log(MutableRef.get(countdown))
*   MutableRef.decrement(countdown)
* }
* ```
*
* @since 2.0.0
* @category numeric
*/
var decrement = (self) => update(self, (n) => n - 1);
/**
* Decrements a numeric MutableRef by 1 and returns the new value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Decrement and get the new value
* const newValue = MutableRef.decrementAndGet(counter)
* console.log(newValue) // 4
* console.log(MutableRef.get(counter)) // 4
*
* // Use in expressions
* const lives = MutableRef.make(3)
* console.log(`Lives remaining: ${MutableRef.decrementAndGet(lives)}`) // "Lives remaining: 2"
*
* // Conditional logic based on decremented value
* const attempts = MutableRef.make(3)
* while (MutableRef.decrementAndGet(attempts) >= 0) {
*   console.log("Retrying...")
*   // retry logic
* }
* ```
*
* @since 2.0.0
* @category numeric
*/
var decrementAndGet = (self) => updateAndGet(self, (n) => n - 1);
/**
* Gets the current value of the MutableRef.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const ref = MutableRef.make("hello")
* console.log(MutableRef.get(ref)) // "hello"
*
* MutableRef.set(ref, "world")
* console.log(MutableRef.get(ref)) // "world"
*
* // Reading complex objects
* const config = MutableRef.make({ port: 3000, host: "localhost" })
* const currentConfig = MutableRef.get(config)
* console.log(currentConfig.port) // 3000
*
* // Multiple reads return the same value
* const value1 = MutableRef.get(ref)
* const value2 = MutableRef.get(ref)
* console.log(value1 === value2) // true
* ```
*
* @since 2.0.0
* @category general
*/
var get = (self) => self.current;
/**
* Decrements a numeric MutableRef by 1 and returns the previous value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Get current value and then decrement
* const previousValue = MutableRef.getAndDecrement(counter)
* console.log(previousValue) // 5
* console.log(MutableRef.get(counter)) // 4
*
* // Useful for processing where you need the original value
* const itemsLeft = MutableRef.make(10)
* while (MutableRef.get(itemsLeft) > 0) {
*   const currentItem = MutableRef.getAndDecrement(itemsLeft)
*   console.log(`Processing item ${currentItem}`)
* }
*
* // Post-decrement semantics (like i-- in other languages)
* const index = MutableRef.make(3)
* const currentIndex = MutableRef.getAndDecrement(index)
* console.log(`Current: ${currentIndex}, Next: ${MutableRef.get(index)}`) // "Current: 3, Next: 2"
* ```
*
* @since 2.0.0
* @category numeric
*/
var getAndDecrement = (self) => getAndUpdate(self, (n) => n - 1);
/**
* Increments a numeric MutableRef by 1 and returns the previous value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Get current value and then increment
* const previousValue = MutableRef.getAndIncrement(counter)
* console.log(previousValue) // 5
* console.log(MutableRef.get(counter)) // 6
*
* // Useful for ID generation
* const idGenerator = MutableRef.make(0)
* const getId = () => MutableRef.getAndIncrement(idGenerator)
*
* console.log(getId()) // 0
* console.log(getId()) // 1
* console.log(getId()) // 2
*
* // Post-increment semantics (like i++ in other languages)
* const position = MutableRef.make(0)
* const currentPos = MutableRef.getAndIncrement(position)
* console.log(`Was at: ${currentPos}, Now at: ${MutableRef.get(position)}`) // "Was at: 0, Now at: 1"
*
* // Useful for iteration counters
* const iterations = MutableRef.make(0)
* while (MutableRef.get(iterations) < 5) {
*   const iteration = MutableRef.getAndIncrement(iterations)
*   console.log(`Iteration ${iteration}`)
* }
* ```
*
* @since 2.0.0
* @category numeric
*/
var getAndIncrement = (self) => getAndUpdate(self, (n) => n + 1);
/**
* Sets the MutableRef to a new value and returns the previous value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const ref = MutableRef.make("old")
*
* // Set new value and get the previous one
* const previous = MutableRef.getAndSet(ref, "new")
* console.log(previous) // "old"
* console.log(MutableRef.get(ref)) // "new"
*
* // Swapping values
* const counter = MutableRef.make(5)
* const oldValue = MutableRef.getAndSet(counter, 10)
* console.log(`Changed from ${oldValue} to ${MutableRef.get(counter)}`) // "Changed from 5 to 10"
*
* // Pipe-able version
* const setValue = MutableRef.getAndSet("final")
* const previousValue = setValue(ref)
* console.log(previousValue) // "new"
*
* // Useful for atomic swaps in algorithms
* const buffer = MutableRef.make<Array<string>>(["a", "b", "c"])
* const oldBuffer = MutableRef.getAndSet(buffer, [])
* console.log(oldBuffer) // ["a", "b", "c"]
* console.log(MutableRef.get(buffer)) // []
* ```
*
* @since 2.0.0
* @category general
*/
var getAndSet = /*#__PURE__*/ dual(2, (self, value) => {
	const ret = self.current;
	self.current = value;
	return ret;
});
/**
* Updates the MutableRef with the result of applying a function to its current value,
* and returns the previous value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Increment and get the old value
* const oldValue = MutableRef.getAndUpdate(counter, (n) => n + 1)
* console.log(oldValue) // 5
* console.log(MutableRef.get(counter)) // 6
*
* // Double the value and get the previous one
* const previous = MutableRef.getAndUpdate(counter, (n) => n * 2)
* console.log(previous) // 6
* console.log(MutableRef.get(counter)) // 12
*
* // Transform string and get old value
* const message = MutableRef.make("hello")
* const oldMessage = MutableRef.getAndUpdate(message, (s) => s.toUpperCase())
* console.log(oldMessage) // "hello"
* console.log(MutableRef.get(message)) // "HELLO"
*
* // Pipe-able version
* const addOne = MutableRef.getAndUpdate((n: number) => n + 1)
* const result = addOne(counter)
* console.log(result) // Previous value before increment
*
* // Useful for implementing atomic operations
* const list = MutableRef.make<Array<number>>([1, 2, 3])
* const oldList = MutableRef.getAndUpdate(list, (arr) => [...arr, 4])
* console.log(oldList) // [1, 2, 3]
* console.log(MutableRef.get(list)) // [1, 2, 3, 4]
* ```
*
* @since 2.0.0
* @category general
*/
var getAndUpdate = /*#__PURE__*/ dual(2, (self, f) => getAndSet(self, f(get(self))));
/**
* Increments a numeric MutableRef by 1 and returns the reference.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Increment the counter
* MutableRef.increment(counter)
* console.log(MutableRef.get(counter)) // 6
*
* // Chain operations
* MutableRef.increment(counter)
* MutableRef.increment(counter)
* console.log(MutableRef.get(counter)) // 8
*
* // Useful for simple counting
* const visits = MutableRef.make(0)
* MutableRef.increment(visits) // User visited
* MutableRef.increment(visits) // Another visit
* console.log(MutableRef.get(visits)) // 2
*
* // Returns the reference for chaining
* const result = MutableRef.increment(counter)
* console.log(result === counter) // true
* ```
*
* @since 2.0.0
* @category numeric
*/
var increment = (self) => update(self, (n) => n + 1);
/**
* Increments a numeric MutableRef by 1 and returns the new value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Increment and get the new value
* const newValue = MutableRef.incrementAndGet(counter)
* console.log(newValue) // 6
* console.log(MutableRef.get(counter)) // 6
*
* // Use in expressions
* const score = MutableRef.make(100)
* console.log(`New score: ${MutableRef.incrementAndGet(score)}`) // "New score: 101"
*
* // Pre-increment semantics (like ++i in other languages)
* const level = MutableRef.make(0)
* const nextLevel = MutableRef.incrementAndGet(level)
* console.log(`Reached level ${nextLevel}`) // "Reached level 1"
*
* // Conditional logic based on incremented value
* const attempts = MutableRef.make(0)
* if (MutableRef.incrementAndGet(attempts) > 3) {
*   console.log("Too many attempts")
* }
* ```
*
* @since 2.0.0
* @category numeric
*/
var incrementAndGet = (self) => updateAndGet(self, (n) => n + 1);
/**
* Sets the MutableRef to a new value and returns the reference.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const ref = MutableRef.make("initial")
*
* // Set a new value
* MutableRef.set(ref, "updated")
* console.log(MutableRef.get(ref)) // "updated"
*
* // Chain set operations (since it returns the ref)
* const result = MutableRef.set(ref, "final")
* console.log(result === ref) // true (same reference)
* console.log(MutableRef.get(ref)) // "final"
*
* // Set complex objects
* const config = MutableRef.make({ debug: false, verbose: false })
* MutableRef.set(config, { debug: true, verbose: true })
* console.log(MutableRef.get(config)) // { debug: true, verbose: true }
*
* // Pipe-able version
* const setValue = MutableRef.set("new value")
* setValue(ref)
* console.log(MutableRef.get(ref)) // "new value"
*
* // Useful for state management
* const state = MutableRef.make<"idle" | "loading" | "success" | "error">("idle")
* MutableRef.set(state, "loading")
* // ... perform async operation
* MutableRef.set(state, "success")
* ```
*
* @since 2.0.0
* @category general
*/
var set = /*#__PURE__*/ dual(2, (self, value) => {
	self.current = value;
	return self;
});
/**
* Sets the MutableRef to a new value and returns the new value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const ref = MutableRef.make("old")
*
* // Set and get the new value
* const newValue = MutableRef.setAndGet(ref, "new")
* console.log(newValue) // "new"
* console.log(MutableRef.get(ref)) // "new"
*
* // Useful for assignments that need the value
* const counter = MutableRef.make(0)
* const currentValue = MutableRef.setAndGet(counter, 42)
* console.log(`Counter set to: ${currentValue}`) // "Counter set to: 42"
*
* // Pipe-able version
* const setValue = MutableRef.setAndGet("final")
* const result = setValue(ref)
* console.log(result) // "final"
*
* // Difference from set: returns value instead of reference
* const ref1 = MutableRef.make(1)
* const returnedRef = MutableRef.set(ref1, 2) // Returns MutableRef
* const returnedValue = MutableRef.setAndGet(ref1, 3) // Returns value
* console.log(returnedValue) // 3
* ```
*
* @since 2.0.0
* @category general
*/
var setAndGet = /*#__PURE__*/ dual(2, (self, value) => {
	self.current = value;
	return self.current;
});
/**
* Updates the MutableRef with the result of applying a function to its current value,
* and returns the reference.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Increment the counter
* MutableRef.update(counter, (n) => n + 1)
* console.log(MutableRef.get(counter)) // 6
*
* // Chain updates (since it returns the ref)
* const result = MutableRef.update(counter, (n) => n * 2)
* console.log(result === counter) // true (same reference)
* console.log(MutableRef.get(counter)) // 12
*
* // Transform string
* const message = MutableRef.make("hello")
* MutableRef.update(message, (s) => s.toUpperCase())
* console.log(MutableRef.get(message)) // "HELLO"
*
* // Update complex objects
* const user = MutableRef.make({ name: "Alice", age: 30 })
* MutableRef.update(user, (u) => ({ ...u, age: u.age + 1 }))
* console.log(MutableRef.get(user)) // { name: "Alice", age: 31 }
*
* // Pipe-able version
* const double = MutableRef.update((n: number) => n * 2)
* double(counter)
* console.log(MutableRef.get(counter)) // 24
*
* // Array operations
* const list = MutableRef.make<Array<number>>([1, 2, 3])
* MutableRef.update(list, (arr) => [...arr, 4])
* console.log(MutableRef.get(list)) // [1, 2, 3, 4]
* ```
*
* @since 2.0.0
* @category general
*/
var update = /*#__PURE__*/ dual(2, (self, f) => set(self, f(get(self))));
/**
* Updates the MutableRef with the result of applying a function to its current value,
* and returns the new value.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const counter = MutableRef.make(5)
*
* // Increment and get the new value
* const newValue = MutableRef.updateAndGet(counter, (n) => n + 1)
* console.log(newValue) // 6
* console.log(MutableRef.get(counter)) // 6
*
* // Double the value and get the result
* const doubled = MutableRef.updateAndGet(counter, (n) => n * 2)
* console.log(doubled) // 12
*
* // Transform string and get result
* const message = MutableRef.make("hello")
* const upperCase = MutableRef.updateAndGet(message, (s) => s.toUpperCase())
* console.log(upperCase) // "HELLO"
*
* // Pipe-able version
* const increment = MutableRef.updateAndGet((n: number) => n + 1)
* const result = increment(counter)
* console.log(result) // 13 (new value)
*
* // Useful for calculations that need the result
* const score = MutableRef.make(100)
* const bonus = 50
* const newScore = MutableRef.updateAndGet(score, (s) => s + bonus)
* console.log(`New score: ${newScore}`) // "New score: 150"
*
* // Array transformations
* const list = MutableRef.make<Array<number>>([1, 2, 3])
* const newList = MutableRef.updateAndGet(list, (arr) => arr.map((x) => x * 2))
* console.log(newList) // [2, 4, 6]
* console.log(MutableRef.get(list)) // [2, 4, 6]
* ```
*
* @since 2.0.0
* @category general
*/
var updateAndGet = /*#__PURE__*/ dual(2, (self, f) => setAndGet(self, f(get(self))));
/**
* Toggles a boolean MutableRef (true becomes false, false becomes true) and returns the reference.
*
* @example
* ```ts
* import { MutableRef } from "effect"
*
* const flag = MutableRef.make(false)
*
* // Toggle the flag
* MutableRef.toggle(flag)
* console.log(MutableRef.get(flag)) // true
*
* // Toggle again
* MutableRef.toggle(flag)
* console.log(MutableRef.get(flag)) // false
*
* // Useful for state switches
* const isVisible = MutableRef.make(true)
* MutableRef.toggle(isVisible) // Hide
* console.log(MutableRef.get(isVisible)) // false
*
* // Toggle button implementation
* const darkMode = MutableRef.make(false)
* const toggleDarkMode = () => {
*   MutableRef.toggle(darkMode)
*   console.log(`Dark mode: ${MutableRef.get(darkMode) ? "ON" : "OFF"}`)
* }
*
* toggleDarkMode() // "Dark mode: ON"
* toggleDarkMode() // "Dark mode: OFF"
*
* // Returns the reference for chaining
* const result = MutableRef.toggle(flag)
* console.log(result === flag) // true
* ```
*
* @since 2.0.0
* @category boolean
*/
var toggle = (self) => update(self, (_) => !_);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/PubSub.js
/**
* This module provides utilities for working with publish-subscribe (PubSub) systems.
*
* A PubSub is an asynchronous message hub where publishers can publish messages and subscribers
* can subscribe to receive those messages. PubSub supports various backpressure strategies,
* message replay, and concurrent access from multiple producers and consumers.
*
* @example
* ```ts
* import { Effect, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publisher
*   yield* PubSub.publish(pubsub, "Hello")
*   yield* PubSub.publish(pubsub, "World")
*
*   // Subscriber
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*     const message1 = yield* PubSub.take(subscription)
*     const message2 = yield* PubSub.take(subscription)
*     console.log(message1, message2) // "Hello", "World"
*   }))
* })
* ```
*
* @since 2.0.0
*/
var PubSub_exports = /* @__PURE__ */ __exportAll({
	BackPressureStrategy: () => BackPressureStrategy,
	DroppingStrategy: () => DroppingStrategy,
	SlidingStrategy: () => SlidingStrategy,
	awaitShutdown: () => awaitShutdown,
	bounded: () => bounded$1,
	capacity: () => capacity,
	dropping: () => dropping$1,
	isEmpty: () => isEmpty,
	isFull: () => isFull$1,
	isShutdown: () => isShutdown,
	isShutdownUnsafe: () => isShutdownUnsafe,
	make: () => make$2,
	makeAtomicBounded: () => makeAtomicBounded,
	makeAtomicUnbounded: () => makeAtomicUnbounded,
	publish: () => publish,
	publishAll: () => publishAll,
	publishUnsafe: () => publishUnsafe,
	remaining: () => remaining,
	remainingUnsafe: () => remainingUnsafe,
	shutdown: () => shutdown$1,
	size: () => size$1,
	sizeUnsafe: () => sizeUnsafe$1,
	sliding: () => sliding$1,
	subscribe: () => subscribe,
	take: () => take$1,
	takeAll: () => takeAll$1,
	takeBetween: () => takeBetween$1,
	takeUpTo: () => takeUpTo,
	unbounded: () => unbounded$1
});
var TypeId$2 = "~effect/PubSub";
var SubscriptionTypeId = "~effect/PubSub/Subscription";
/**
* Creates a PubSub with a custom atomic implementation and strategy.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create custom PubSub with specific atomic implementation and strategy
*   const pubsub = yield* PubSub.make<string>({
*     atomicPubSub: () => PubSub.makeAtomicBounded(100),
*     strategy: () => new PubSub.BackPressureStrategy()
*   })
*
*   // Use the created PubSub
*   yield* PubSub.publish(pubsub, "Hello")
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var make$2 = (options) => sync$1(() => makePubSubUnsafe(options.atomicPubSub(), /* @__PURE__ */ new Map(), makeUnsafe$2(), makeUnsafe$1(false), make$3(false), options.strategy()));
/**
* Creates a bounded PubSub with backpressure strategy.
*
* The PubSub will retain messages until they have been taken by all subscribers.
* When the PubSub reaches capacity, publishers will be suspended until space becomes available.
* This ensures message delivery guarantees but may slow down fast publishers.
*
* @param capacity - The maximum number of messages the PubSub can hold, or an options object
*                   with capacity and optional replay buffer size
* @returns An Effect that creates a bounded PubSub
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create bounded PubSub with capacity 100
*   const pubsub = yield* PubSub.bounded<string>(100)
*
*   // Create with replay buffer for late subscribers
*   const pubsubWithReplay = yield* PubSub.bounded<string>({
*     capacity: 100,
*     replay: 10 // Last 10 messages replayed to new subscribers
*   })
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var bounded$1 = (capacity) => make$2({
	atomicPubSub: () => makeAtomicBounded(capacity),
	strategy: () => new BackPressureStrategy()
});
/**
* Creates a bounded `PubSub` with the dropping strategy. The `PubSub` will drop new
* messages if the `PubSub` is at capacity.
*
* For best performance use capacities that are powers of two.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create dropping PubSub that drops new messages when full
*   const pubsub = yield* PubSub.dropping<string>(3)
*
*   // With replay buffer for late subscribers
*   const pubsubWithReplay = yield* PubSub.dropping<string>({
*     capacity: 3,
*     replay: 5
*   })
*
*   // Fill the PubSub and see dropping behavior
*   yield* PubSub.publish(pubsub, "msg1") // succeeds
*   yield* PubSub.publish(pubsub, "msg2") // succeeds
*   yield* PubSub.publish(pubsub, "msg3") // succeeds
*   const dropped = yield* PubSub.publish(pubsub, "msg4") // returns false (dropped)
*   console.log("Message dropped:", !dropped)
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var dropping$1 = (capacity) => make$2({
	atomicPubSub: () => makeAtomicBounded(capacity),
	strategy: () => new DroppingStrategy()
});
/**
* Creates a bounded `PubSub` with the sliding strategy. The `PubSub` will add new
* messages and drop old messages if the `PubSub` is at capacity.
*
* For best performance use capacities that are powers of two.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create sliding PubSub that evicts old messages when full
*   const pubsub = yield* PubSub.sliding<string>(3)
*
*   // With replay buffer
*   const pubsubWithReplay = yield* PubSub.sliding<string>({
*     capacity: 3,
*     replay: 2
*   })
*
*   // Fill and overflow the PubSub
*   yield* PubSub.publish(pubsub, "msg1")
*   yield* PubSub.publish(pubsub, "msg2")
*   yield* PubSub.publish(pubsub, "msg3")
*   yield* PubSub.publish(pubsub, "msg4") // "msg1" is evicted
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*     const messages = yield* PubSub.takeAll(subscription)
*     console.log(messages) // ["msg2", "msg3", "msg4"]
*   }))
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var sliding$1 = (capacity) => make$2({
	atomicPubSub: () => makeAtomicBounded(capacity),
	strategy: () => new SlidingStrategy()
});
/**
* Creates an unbounded `PubSub`.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create unbounded PubSub
*   const pubsub = yield* PubSub.unbounded<string>()
*
*   // With replay buffer for late subscribers
*   const pubsubWithReplay = yield* PubSub.unbounded<string>({
*     replay: 10
*   })
*
*   // Can publish unlimited messages
*   for (let i = 0; i < 1000; i++) {
*     yield* PubSub.publish(pubsub, `message-${i}`)
*   }
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*     const message = yield* PubSub.take(subscription)
*     console.log("First message:", message)
*   }))
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var unbounded$1 = (options) => make$2({
	atomicPubSub: () => makeAtomicUnbounded(options),
	strategy: () => new DroppingStrategy()
});
/**
* Creates a bounded atomic PubSub implementation with optional replay buffer.
*
* @since 4.0.0
* @category constructors
*/
var makeAtomicBounded = (capacity) => {
	const options = typeof capacity === "number" ? { capacity } : capacity;
	ensureCapacity(options.capacity);
	const replayBuffer = options.replay && options.replay > 0 ? new ReplayBuffer(Math.ceil(options.replay)) : void 0;
	if (options.capacity === 1) return new BoundedPubSubSingle(replayBuffer);
	else if (nextPow2(options.capacity) === options.capacity) return new BoundedPubSubPow2(options.capacity, replayBuffer);
	else return new BoundedPubSubArb(options.capacity, replayBuffer);
};
/**
* Creates an unbounded atomic PubSub implementation with optional replay buffer.
*
* @since 4.0.0
* @category constructors
*/
var makeAtomicUnbounded = (options) => new UnboundedPubSub(options?.replay ? new ReplayBuffer(options.replay) : void 0);
/**
*  Returns the number of elements the queue can hold.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(100)
*   const cap = PubSub.capacity(pubsub)
*   console.log("PubSub capacity:", cap) // 100
*
*   const unboundedPubsub = yield* PubSub.unbounded<string>()
*   const unboundedCap = PubSub.capacity(unboundedPubsub)
*   console.log("Unbounded capacity:", unboundedCap) // Number.MAX_SAFE_INTEGER
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var capacity = (self) => self.pubsub.capacity;
/**
* Retrieves the size of the queue, which is equal to the number of elements
* in the queue. This may be negative if fibers are suspended waiting for
* elements to be added to the queue.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Initially empty
*   const initialSize = yield* PubSub.size(pubsub)
*   console.log("Initial size:", initialSize) // 0
*
*   // Publish some messages
*   yield* PubSub.publish(pubsub, "msg1")
*   yield* PubSub.publish(pubsub, "msg2")
*
*   const afterPublish = yield* PubSub.size(pubsub)
*   console.log("After publishing:", afterPublish) // 2
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var size$1 = (self) => sync$1(() => sizeUnsafe$1(self));
/**
* Retrieves the size of the queue, which is equal to the number of elements
* in the queue. This may be negative if fibers are suspended waiting for
* elements to be added to the queue.
*
* @example
* ```ts
* import { PubSub } from "effect"
*
* // Unsafe synchronous size check
* declare const pubsub: PubSub.PubSub<string>
*
* const size = PubSub.sizeUnsafe(pubsub)
* console.log("Current size:", size)
* ```
*
* @since 2.0.0
* @category getters
*/
var sizeUnsafe$1 = (self) => {
	if (get(self.shutdownFlag)) return 0;
	return self.pubsub.size();
};
/**
* Returns `true` if the `PubSub` contains at least one element, `false`
* otherwise.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(2)
*
*   // Initially not full
*   const initiallyFull = yield* PubSub.isFull(pubsub)
*   console.log("Initially full:", initiallyFull) // false
*
*   // Fill the PubSub
*   yield* PubSub.publish(pubsub, "msg1")
*   yield* PubSub.publish(pubsub, "msg2")
*
*   const nowFull = yield* PubSub.isFull(pubsub)
*   console.log("Now full:", nowFull) // true
* })
* ```
*
* @since 2.0.0
* @category predicates
*/
var isFull$1 = (self) => map$1(size$1(self), (size) => size === self.pubsub.capacity);
/**
* Returns `true` if the `Pubsub` contains zero elements, `false` otherwise.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Initially empty
*   const initiallyEmpty = yield* PubSub.isEmpty(pubsub)
*   console.log("Initially empty:", initiallyEmpty) // true
*
*   // Publish a message
*   yield* PubSub.publish(pubsub, "Hello")
*
*   const nowEmpty = yield* PubSub.isEmpty(pubsub)
*   console.log("Now empty:", nowEmpty) // false
* })
* ```
*
* @since 2.0.0
* @category predicates
*/
var isEmpty = (self) => map$1(size$1(self), (size) => size === 0);
/**
* Interrupts any fibers that are suspended on `offer` or `take`. Future calls
* to `offer*` and `take*` will be interrupted immediately.
*
* @example
* ```ts
* import { Effect, Fiber, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(1)
*
*   // Start a fiber that will be suspended waiting to publish
*   const publisherFiber = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* PubSub.publish(pubsub, "msg1") // fills the buffer
*       yield* PubSub.publish(pubsub, "msg2") // will suspend here
*     })
*   )
*
*   // Shutdown the PubSub
*   yield* PubSub.shutdown(pubsub)
*
*   // The suspended publisher will be interrupted
*   const result = yield* Fiber.await(publisherFiber)
*   console.log("Publisher interrupted:", result._tag === "Failure")
* })
* ```
*
* @since 2.0.0
* @category lifecycle
*/
var shutdown$1 = (self) => uninterruptible(withFiber$1((fiber) => {
	set(self.shutdownFlag, true);
	return close(self.scope, interrupt$2(fiber.id)).pipe(andThen(self.strategy.shutdown), when(self.shutdownHook.open), asVoid);
}));
/**
* Returns `true` if `shutdown` has been called, otherwise returns `false`.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Initially not shutdown
*   const initiallyShutdown = yield* PubSub.isShutdown(pubsub)
*   console.log("Initially shutdown:", initiallyShutdown) // false
*
*   // Shutdown the PubSub
*   yield* PubSub.shutdown(pubsub)
*
*   const nowShutdown = yield* PubSub.isShutdown(pubsub)
*   console.log("Now shutdown:", nowShutdown) // true
* })
* ```
*
* @since 2.0.0
* @category predicates
*/
var isShutdown = (self) => sync$1(() => isShutdownUnsafe(self));
/**
* Returns `true` if `shutdown` has been called, otherwise returns `false`.
*
* @example
* ```ts
* import { PubSub } from "effect"
*
* declare const pubsub: PubSub.PubSub<string>
*
* // Unsafe synchronous shutdown check
* const isDown = PubSub.isShutdownUnsafe(pubsub)
* if (isDown) {
*   console.log("PubSub is shutdown, cannot publish")
* } else {
*   console.log("PubSub is active")
* }
* ```
*
* @since 4.0.0
* @category predicates
*/
var isShutdownUnsafe = (self) => self.shutdownFlag.current;
/**
* Waits until the queue is shutdown. The `Effect` returned by this method will
* not resume until the queue has been shutdown. If the queue is already
* shutdown, the `Effect` will resume right away.
*
* @example
* ```ts
* import { Effect, Fiber, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Start a fiber that waits for shutdown
*   const waiterFiber = yield* Effect.forkChild(
*     Effect.gen(function*() {
*       yield* PubSub.awaitShutdown(pubsub)
*       console.log("PubSub has been shutdown!")
*     })
*   )
*
*   // Do some work...
*   yield* Effect.sleep("100 millis")
*
*   // Shutdown the PubSub
*   yield* PubSub.shutdown(pubsub)
*
*   // The waiter will now complete
*   yield* Fiber.join(waiterFiber)
* })
* ```
*
* @since 2.0.0
* @category lifecycle
*/
var awaitShutdown = (self) => self.shutdownHook.await;
/**
* Publishes a message to the `PubSub`, returning whether the message was published
* to the `PubSub`.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publish a message
*   const published = yield* PubSub.publish(pubsub, "Hello World")
*   console.log("Message published:", published) // true
*
*   // With a full bounded PubSub using backpressure strategy
*   const smallPubsub = yield* PubSub.bounded<string>(1)
*   yield* PubSub.publish(smallPubsub, "msg1") // succeeds
*
*   // This will suspend until space becomes available
*   const publishEffect = PubSub.publish(smallPubsub, "msg2")
*
*   // Create a subscriber to free up space
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(smallPubsub)
*     yield* PubSub.take(subscription) // frees space
*     const result = yield* publishEffect
*     console.log("Second message published:", result) // true
*   }))
* })
* ```
*
* @since 2.0.0
* @category publishing
*/
var publish = /*#__PURE__*/ dual(2, (self, value) => suspend$1(() => {
	if (self.shutdownFlag.current) return interrupt$3;
	if (self.pubsub.publish(value)) {
		self.strategy.completeSubscribersUnsafe(self.pubsub, self.subscribers);
		return succeed$2(true);
	}
	return self.strategy.handleSurplus(self.pubsub, self.subscribers, [value], self.shutdownFlag);
}));
/**
* Publishes a message to the `PubSub`, returning whether the message was published
* to the `PubSub`.
*
* @example
* ```ts
* import { PubSub } from "effect"
*
* declare const pubsub: PubSub.PubSub<string>
*
* // Unsafe synchronous publish (non-blocking)
* const published = PubSub.publishUnsafe(pubsub, "Hello")
* if (published) {
*   console.log("Message published successfully")
* } else {
*   console.log("Message dropped (PubSub full or shutdown)")
* }
*
* // Useful for scenarios where you don't want to suspend
* const messages = ["msg1", "msg2", "msg3"]
* const publishedCount =
*   messages.filter((msg) => PubSub.publishUnsafe(pubsub, msg)).length
* console.log(`Published ${publishedCount} out of ${messages.length} messages`)
* ```
*
* @since 4.0.0
* @category publishing
*/
var publishUnsafe = /*#__PURE__*/ dual(2, (self, value) => {
	if (self.shutdownFlag.current) return false;
	if (self.pubsub.publish(value)) {
		self.strategy.completeSubscribersUnsafe(self.pubsub, self.subscribers);
		return true;
	}
	return false;
});
/**
* Publishes all of the specified messages to the `PubSub`, returning whether they
* were published to the `PubSub`.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publish multiple messages at once
*   const messages = ["Hello", "World", "from", "Effect"]
*   const allPublished = yield* PubSub.publishAll(pubsub, messages)
*   console.log("All messages published:", allPublished) // true
*
*   // With a smaller capacity
*   const smallPubsub = yield* PubSub.bounded<string>(2)
*   const manyMessages = ["msg1", "msg2", "msg3", "msg4"]
*
*   // Will suspend until space becomes available for all messages
*   const publishAllEffect = PubSub.publishAll(smallPubsub, manyMessages)
*
*   // Subscribe to consume messages and free space
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(smallPubsub)
*     yield* PubSub.takeAll(subscription) // consume all messages
*     const result = yield* publishAllEffect
*     console.log("All messages eventually published:", result)
*   }))
* })
* ```
*
* @since 2.0.0
* @category publishing
*/
var publishAll = /*#__PURE__*/ dual(2, (self, elements) => suspend$1(() => {
	if (self.shutdownFlag.current) return interrupt$3;
	const surplus = self.pubsub.publishAll(elements);
	self.strategy.completeSubscribersUnsafe(self.pubsub, self.subscribers);
	if (surplus.length === 0) return succeed$2(true);
	return self.strategy.handleSurplus(self.pubsub, self.subscribers, surplus, self.shutdownFlag);
}));
/**
* Subscribes to receive messages from the `PubSub`. The resulting subscription can
* be evaluated multiple times within the scope to take a message from the `PubSub`
* each time.
*
* @example
* ```ts
* import { Effect, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publish some messages
*   yield* PubSub.publish(pubsub, "Hello")
*   yield* PubSub.publish(pubsub, "World")
*
*   // Subscribe within a scope for automatic cleanup
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*
*     // Take messages one by one
*     const msg1 = yield* PubSub.take(subscription)
*     const msg2 = yield* PubSub.take(subscription)
*     console.log(msg1, msg2) // "Hello", "World"
*
*     // Subscription is automatically cleaned up when scope exits
*   }))
*
*   // Multiple subscribers can receive the same messages
*   yield* PubSub.publish(pubsub, "Broadcast")
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const sub1 = yield* PubSub.subscribe(pubsub)
*     const sub2 = yield* PubSub.subscribe(pubsub)
*
*     const [msg1, msg2] = yield* Effect.all([
*       PubSub.take(sub1),
*       PubSub.take(sub2)
*     ])
*     console.log("Both received:", msg1, msg2) // "Broadcast", "Broadcast"
*   }))
* })
* ```
*
* @since 2.0.0
* @category subscription
*/
var subscribe = (self) => acquireRelease$1(sync$1(() => makeSubscriptionUnsafe(self.pubsub, self.subscribers, self.strategy)), unsubscribe);
var unsubscribe = (self) => uninterruptible(withFiber$1((state) => {
	set(self.shutdownFlag, true);
	return forEach$1(takeAll$2(self.pollers), (d) => interruptWith(d, state.id), {
		discard: true,
		concurrency: "unbounded"
	}).pipe(tap$1(() => sync$1(() => {
		self.subscribers.delete(self.subscription);
		self.subscription.unsubscribe();
		self.strategy.onPubSubEmptySpaceUnsafe(self.pubsub, self.subscribers);
	})), when(self.shutdownHook.open), asVoid);
}));
/**
* Takes a single message from the subscription. If no messages are available,
* this will suspend until a message becomes available.
*
* @example
* ```ts
* import { Effect, Fiber, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*
*     // Start a fiber to take a message (will suspend)
*     const takeFiber = yield* Effect.forkChild(
*       PubSub.take(subscription)
*     )
*
*     // Publish a message
*     yield* PubSub.publish(pubsub, "Hello")
*
*     // The take will now complete
*     const message = yield* Fiber.join(takeFiber)
*     console.log("Received:", message) // "Hello"
*   }))
* })
* ```
*
* @since 4.0.0
* @category subscription
*/
var take$1 = (self) => suspend$1(() => {
	if (self.shutdownFlag.current) return interrupt$3;
	if (self.replayWindow.remaining > 0) return succeed$2(self.replayWindow.take());
	const message = self.pollers.length === 0 ? self.subscription.poll() : Empty;
	if (message === Empty) return pollForItem(self);
	else {
		self.strategy.onPubSubEmptySpaceUnsafe(self.pubsub, self.subscribers);
		return succeed$2(message);
	}
});
/**
* Takes all available messages from the subscription, suspending if no items
* are available.
*
* @example
* ```ts
* import { Effect, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publish multiple messages
*   yield* PubSub.publishAll(pubsub, ["msg1", "msg2", "msg3"])
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*
*     // Take all available messages at once
*     const allMessages = yield* PubSub.takeAll(subscription)
*     console.log("All messages:", allMessages) // ["msg1", "msg2", "msg3"]
*   }))
* })
* ```
*
* @since 4.0.0
* @category subscription
*/
var takeAll$1 = (self) => suspend$1(function loop(value) {
	if (self.shutdownFlag.current) return interrupt$3;
	let as = self.pollers.length === 0 ? self.subscription.pollUpTo(Number.POSITIVE_INFINITY) : [];
	if (value) as = value.concat(as);
	self.strategy.onPubSubEmptySpaceUnsafe(self.pubsub, self.subscribers);
	if (self.replayWindow.remaining > 0) return succeed$2(self.replayWindow.takeAll().concat(as));
	else if (!isArrayNonEmpty(as)) return flatMap$1(pollForItem(self), (item) => loop([item]));
	return succeed$2(as);
});
var pollForItem = (self) => {
	const deferred = makeUnsafe$3();
	let set = self.subscribers.get(self.subscription);
	if (!set) {
		set = /* @__PURE__ */ new Set();
		self.subscribers.set(self.subscription, set);
	}
	set.add(self.pollers);
	append(self.pollers, deferred);
	self.strategy.completePollersUnsafe(self.pubsub, self.subscribers, self.subscription, self.pollers);
	return onInterrupt(_await(deferred), () => {
		remove(self.pollers, deferred);
		return void_;
	});
};
/**
* Takes up to the specified number of messages from the subscription without suspending.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publish multiple messages
*   yield* PubSub.publishAll(pubsub, ["msg1", "msg2", "msg3", "msg4", "msg5"])
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*
*     // Take up to 3 messages
*     const upTo3 = yield* PubSub.takeUpTo(subscription, 3)
*     console.log("Up to 3:", upTo3) // ["msg1", "msg2", "msg3"]
*
*     // Take up to 5 more (only 2 remaining)
*     const upTo5 = yield* PubSub.takeUpTo(subscription, 5)
*     console.log("Up to 5:", upTo5) // ["msg4", "msg5"]
*
*     // No more messages available
*     const noMore = yield* PubSub.takeUpTo(subscription, 10)
*     console.log("No more:", noMore) // []
*   }))
* })
* ```
*
* @since 4.0.0
* @category subscription
*/
var takeUpTo = /*#__PURE__*/ dual(2, (self, max) => suspend$1(() => {
	if (self.shutdownFlag.current) return interrupt$3;
	let replay = void 0;
	if (self.replayWindow.remaining >= max) return succeed$2(self.replayWindow.takeN(max));
	else if (self.replayWindow.remaining > 0) {
		replay = self.replayWindow.takeAll();
		max = max - replay.length;
	}
	const as = self.pollers.length === 0 ? self.subscription.pollUpTo(max) : [];
	self.strategy.onPubSubEmptySpaceUnsafe(self.pubsub, self.subscribers);
	return replay ? succeed$2(replay.concat(as)) : succeed$2(as);
}));
/**
* Takes between the specified minimum and maximum number of messages from the subscription.
* Will suspend if the minimum number is not immediately available.
*
* @example
* ```ts
* import { Effect, Fiber, PubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*
*     // Start taking between 2 and 5 messages (will suspend)
*     const takeFiber = yield* Effect.forkChild(
*       PubSub.takeBetween(subscription, 2, 5)
*     )
*
*     // Publish 3 messages
*     yield* PubSub.publishAll(pubsub, ["msg1", "msg2", "msg3"])
*
*     // Now the take will complete with 3 messages
*     const messages = yield* Fiber.join(takeFiber)
*     console.log("Between 2-5:", messages) // ["msg1", "msg2", "msg3"]
*   }))
* })
* ```
*
* @since 4.0.0
* @category subscription
*/
var takeBetween$1 = /*#__PURE__*/ dual(3, (self, min, max) => suspend$1(() => takeRemainderLoop(self, min, max, [])));
var takeRemainderLoop = (self, min, max, acc) => {
	if (max < min) return succeed$2(acc);
	return flatMap$1(takeUpTo(self, max), (bs) => {
		acc.push(...bs);
		const remaining = min - bs.length;
		if (remaining === 1) return map$1(take$1(self), (b) => {
			acc.push(b);
			return acc;
		});
		if (remaining > 1) return flatMap$1(take$1(self), (b) => {
			acc.push(b);
			return takeRemainderLoop(self, remaining - 1, max - bs.length - 1, acc);
		});
		return succeed$2(acc);
	});
};
/**
* Returns the number of messages currently available in the subscription.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(10)
*
*   // Publish some messages
*   yield* PubSub.publishAll(pubsub, ["msg1", "msg2", "msg3"])
*
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*
*     // Check how many messages are available
*     const count = yield* PubSub.remaining(subscription)
*     console.log("Messages available:", count) // 3
*
*     // Take one message
*     yield* PubSub.take(subscription)
*
*     const remaining = yield* PubSub.remaining(subscription)
*     console.log("Messages remaining:", remaining) // 2
*   }))
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var remaining = (self) => suspend$1(() => self.shutdownFlag.current ? interrupt$3 : succeed$2(self.subscription.size() + self.replayWindow.remaining));
/**
* Returns the number of messages currently available in the subscription.
*
* @example
* ```ts
* import { PubSub } from "effect"
*
* declare const subscription: PubSub.Subscription<string>
*
* // Unsafe synchronous check for remaining messages
* const remainingOption = PubSub.remainingUnsafe(subscription)
* if (remainingOption) {
*   console.log("Messages available:", remainingOption)
* } else {
*   console.log("Subscription is shutdown")
* }
*
* // Useful for polling or batching scenarios
* if (remainingOption && remainingOption > 10) {
*   // Process messages in batch
* }
* ```
*
* @since 4.0.0
* @category getters
*/
var remainingUnsafe = (self) => {
	if (self.shutdownFlag.current) return;
	return self.subscription.size() + self.replayWindow.remaining;
};
var AbsentValue = /*#__PURE__*/ Symbol.for("effect/PubSub/AbsentValue");
var addSubscribers = (subscribers, subscription, pollers) => {
	if (!subscribers.has(subscription)) subscribers.set(subscription, /* @__PURE__ */ new Set());
	subscribers.get(subscription).add(pollers);
};
var removeSubscribers = (subscribers, subscription, pollers) => {
	if (!subscribers.has(subscription)) return;
	const set = subscribers.get(subscription);
	set.delete(pollers);
	if (set.size === 0) subscribers.delete(subscription);
};
var makeSubscriptionUnsafe = (pubsub, subscribers, strategy) => new SubscriptionImpl(pubsub, subscribers, pubsub.subscribe(), make$4(), makeUnsafe$1(false), make$3(false), strategy, pubsub.replayWindow());
var BoundedPubSubArb = class {
	array;
	publisherIndex = 0;
	subscribers;
	subscriberCount = 0;
	subscribersIndex = 0;
	capacity;
	replayBuffer;
	constructor(capacity, replayBuffer) {
		this.capacity = capacity;
		this.replayBuffer = replayBuffer;
		this.array = Array.from({ length: capacity });
		this.subscribers = Array.from({ length: capacity });
	}
	replayWindow() {
		return this.replayBuffer ? new ReplayWindowImpl(this.replayBuffer) : emptyReplayWindow;
	}
	isEmpty() {
		return this.publisherIndex === this.subscribersIndex;
	}
	isFull() {
		return this.publisherIndex === this.subscribersIndex + this.capacity;
	}
	size() {
		return this.publisherIndex - this.subscribersIndex;
	}
	publish(value) {
		if (this.isFull()) return false;
		if (this.subscriberCount !== 0) {
			const index = this.publisherIndex % this.capacity;
			this.array[index] = value;
			this.subscribers[index] = this.subscriberCount;
			this.publisherIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.offer(value);
		return true;
	}
	publishAll(elements) {
		if (this.subscriberCount === 0) {
			if (this.replayBuffer) this.replayBuffer.offerAll(elements);
			return [];
		}
		const chunk = fromIterable$2(elements);
		const n = chunk.length;
		const size = this.publisherIndex - this.subscribersIndex;
		const available = this.capacity - size;
		const forPubSub = Math.min(n, available);
		if (forPubSub === 0) return chunk;
		let iteratorIndex = 0;
		const publishAllIndex = this.publisherIndex + forPubSub;
		while (this.publisherIndex !== publishAllIndex) {
			const a = chunk[iteratorIndex++];
			const index = this.publisherIndex % this.capacity;
			this.array[index] = a;
			this.subscribers[index] = this.subscriberCount;
			this.publisherIndex += 1;
			if (this.replayBuffer) this.replayBuffer.offer(a);
		}
		return chunk.slice(iteratorIndex);
	}
	slide() {
		if (this.subscribersIndex !== this.publisherIndex) {
			const index = this.subscribersIndex % this.capacity;
			this.array[index] = AbsentValue;
			this.subscribers[index] = 0;
			this.subscribersIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.slide();
	}
	subscribe() {
		this.subscriberCount += 1;
		return new BoundedPubSubArbSubscription(this, this.publisherIndex, false);
	}
};
var BoundedPubSubArbSubscription = class {
	self;
	subscriberIndex;
	unsubscribed;
	constructor(self, subscriberIndex, unsubscribed) {
		this.self = self;
		this.subscriberIndex = subscriberIndex;
		this.unsubscribed = unsubscribed;
	}
	isEmpty() {
		return this.unsubscribed || this.self.publisherIndex === this.subscriberIndex || this.self.publisherIndex === this.self.subscribersIndex;
	}
	size() {
		if (this.unsubscribed) return 0;
		return this.self.publisherIndex - Math.max(this.subscriberIndex, this.self.subscribersIndex);
	}
	poll() {
		if (this.unsubscribed) return Empty;
		this.subscriberIndex = Math.max(this.subscriberIndex, this.self.subscribersIndex);
		if (this.subscriberIndex !== this.self.publisherIndex) {
			const index = this.subscriberIndex % this.self.capacity;
			const elem = this.self.array[index];
			this.self.subscribers[index] -= 1;
			if (this.self.subscribers[index] === 0) {
				this.self.array[index] = AbsentValue;
				this.self.subscribersIndex += 1;
			}
			this.subscriberIndex += 1;
			return elem;
		}
		return Empty;
	}
	pollUpTo(n) {
		if (this.unsubscribed) return [];
		this.subscriberIndex = Math.max(this.subscriberIndex, this.self.subscribersIndex);
		const size = this.self.publisherIndex - this.subscriberIndex;
		const toPoll = Math.min(n, size);
		if (toPoll <= 0) return [];
		const builder = [];
		const pollUpToIndex = this.subscriberIndex + toPoll;
		while (this.subscriberIndex !== pollUpToIndex) {
			const index = this.subscriberIndex % this.self.capacity;
			const a = this.self.array[index];
			this.self.subscribers[index] -= 1;
			if (this.self.subscribers[index] === 0) {
				this.self.array[index] = AbsentValue;
				this.self.subscribersIndex += 1;
			}
			builder.push(a);
			this.subscriberIndex += 1;
		}
		return builder;
	}
	unsubscribe() {
		if (!this.unsubscribed) {
			this.unsubscribed = true;
			this.self.subscriberCount -= 1;
			this.subscriberIndex = Math.max(this.subscriberIndex, this.self.subscribersIndex);
			while (this.subscriberIndex !== this.self.publisherIndex) {
				const index = this.subscriberIndex % this.self.capacity;
				this.self.subscribers[index] -= 1;
				if (this.self.subscribers[index] === 0) {
					this.self.array[index] = AbsentValue;
					this.self.subscribersIndex += 1;
				}
				this.subscriberIndex += 1;
			}
		}
	}
};
var BoundedPubSubPow2 = class {
	array;
	mask;
	publisherIndex = 0;
	subscribers;
	subscriberCount = 0;
	subscribersIndex = 0;
	capacity;
	replayBuffer;
	constructor(capacity, replayBuffer) {
		this.capacity = capacity;
		this.replayBuffer = replayBuffer;
		this.array = Array.from({ length: capacity });
		this.mask = capacity - 1;
		this.subscribers = Array.from({ length: capacity });
	}
	replayWindow() {
		return this.replayBuffer ? new ReplayWindowImpl(this.replayBuffer) : emptyReplayWindow;
	}
	isEmpty() {
		return this.publisherIndex === this.subscribersIndex;
	}
	isFull() {
		return this.publisherIndex === this.subscribersIndex + this.capacity;
	}
	size() {
		return this.publisherIndex - this.subscribersIndex;
	}
	publish(value) {
		if (this.isFull()) return false;
		if (this.subscriberCount !== 0) {
			const index = this.publisherIndex & this.mask;
			this.array[index] = value;
			this.subscribers[index] = this.subscriberCount;
			this.publisherIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.offer(value);
		return true;
	}
	publishAll(elements) {
		if (this.subscriberCount === 0) {
			if (this.replayBuffer) this.replayBuffer.offerAll(elements);
			return [];
		}
		const chunk = fromIterable$2(elements);
		const n = chunk.length;
		const size = this.publisherIndex - this.subscribersIndex;
		const available = this.capacity - size;
		const forPubSub = Math.min(n, available);
		if (forPubSub === 0) return chunk;
		let iteratorIndex = 0;
		const publishAllIndex = this.publisherIndex + forPubSub;
		while (this.publisherIndex !== publishAllIndex) {
			const elem = chunk[iteratorIndex++];
			const index = this.publisherIndex & this.mask;
			this.array[index] = elem;
			this.subscribers[index] = this.subscriberCount;
			this.publisherIndex += 1;
			if (this.replayBuffer) this.replayBuffer.offer(elem);
		}
		return chunk.slice(iteratorIndex);
	}
	slide() {
		if (this.subscribersIndex !== this.publisherIndex) {
			const index = this.subscribersIndex & this.mask;
			this.array[index] = AbsentValue;
			this.subscribers[index] = 0;
			this.subscribersIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.slide();
	}
	subscribe() {
		this.subscriberCount += 1;
		return new BoundedPubSubPow2Subscription(this, this.publisherIndex, false);
	}
};
var BoundedPubSubPow2Subscription = class {
	self;
	subscriberIndex;
	unsubscribed;
	constructor(self, subscriberIndex, unsubscribed) {
		this.self = self;
		this.subscriberIndex = subscriberIndex;
		this.unsubscribed = unsubscribed;
	}
	isEmpty() {
		return this.unsubscribed || this.self.publisherIndex === this.subscriberIndex || this.self.publisherIndex === this.self.subscribersIndex;
	}
	size() {
		if (this.unsubscribed) return 0;
		return this.self.publisherIndex - Math.max(this.subscriberIndex, this.self.subscribersIndex);
	}
	poll() {
		if (this.unsubscribed) return Empty;
		this.subscriberIndex = Math.max(this.subscriberIndex, this.self.subscribersIndex);
		if (this.subscriberIndex !== this.self.publisherIndex) {
			const index = this.subscriberIndex & this.self.mask;
			const elem = this.self.array[index];
			this.self.subscribers[index] -= 1;
			if (this.self.subscribers[index] === 0) {
				this.self.array[index] = AbsentValue;
				this.self.subscribersIndex += 1;
			}
			this.subscriberIndex += 1;
			return elem;
		}
		return Empty;
	}
	pollUpTo(n) {
		if (this.unsubscribed) return [];
		this.subscriberIndex = Math.max(this.subscriberIndex, this.self.subscribersIndex);
		const size = this.self.publisherIndex - this.subscriberIndex;
		const toPoll = Math.min(n, size);
		if (toPoll <= 0) return [];
		const builder = [];
		const pollUpToIndex = this.subscriberIndex + toPoll;
		while (this.subscriberIndex !== pollUpToIndex) {
			const index = this.subscriberIndex & this.self.mask;
			const elem = this.self.array[index];
			this.self.subscribers[index] -= 1;
			if (this.self.subscribers[index] === 0) {
				this.self.array[index] = AbsentValue;
				this.self.subscribersIndex += 1;
			}
			builder.push(elem);
			this.subscriberIndex += 1;
		}
		return builder;
	}
	unsubscribe() {
		if (!this.unsubscribed) {
			this.unsubscribed = true;
			this.self.subscriberCount -= 1;
			this.subscriberIndex = Math.max(this.subscriberIndex, this.self.subscribersIndex);
			while (this.subscriberIndex !== this.self.publisherIndex) {
				const index = this.subscriberIndex & this.self.mask;
				this.self.subscribers[index] -= 1;
				if (this.self.subscribers[index] === 0) {
					this.self.array[index] = AbsentValue;
					this.self.subscribersIndex += 1;
				}
				this.subscriberIndex += 1;
			}
		}
	}
};
var BoundedPubSubSingle = class {
	publisherIndex = 0;
	subscriberCount = 0;
	subscribers = 0;
	value = AbsentValue;
	capacity = 1;
	replayBuffer;
	constructor(replayBuffer) {
		this.replayBuffer = replayBuffer;
	}
	replayWindow() {
		return this.replayBuffer ? new ReplayWindowImpl(this.replayBuffer) : emptyReplayWindow;
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
	isEmpty() {
		return this.subscribers === 0;
	}
	isFull() {
		return !this.isEmpty();
	}
	size() {
		return this.isEmpty() ? 0 : 1;
	}
	publish(value) {
		if (this.isFull()) return false;
		if (this.subscriberCount !== 0) {
			this.value = value;
			this.subscribers = this.subscriberCount;
			this.publisherIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.offer(value);
		return true;
	}
	publishAll(elements) {
		if (this.subscriberCount === 0) {
			if (this.replayBuffer) this.replayBuffer.offerAll(elements);
			return [];
		}
		const chunk = fromIterable$2(elements);
		if (chunk.length === 0) return chunk;
		if (this.publish(chunk[0])) return chunk.slice(1);
		else return chunk;
	}
	slide() {
		if (this.isFull()) {
			this.subscribers = 0;
			this.value = AbsentValue;
		}
		if (this.replayBuffer) this.replayBuffer.slide();
	}
	subscribe() {
		this.subscriberCount += 1;
		return new BoundedPubSubSingleSubscription(this, this.publisherIndex, false);
	}
};
var BoundedPubSubSingleSubscription = class {
	self;
	subscriberIndex;
	unsubscribed;
	constructor(self, subscriberIndex, unsubscribed) {
		this.self = self;
		this.subscriberIndex = subscriberIndex;
		this.unsubscribed = unsubscribed;
	}
	isEmpty() {
		return this.unsubscribed || this.self.subscribers === 0 || this.subscriberIndex === this.self.publisherIndex;
	}
	size() {
		return this.isEmpty() ? 0 : 1;
	}
	poll() {
		if (this.isEmpty()) return Empty;
		const elem = this.self.value;
		this.self.subscribers -= 1;
		if (this.self.subscribers === 0) this.self.value = AbsentValue;
		this.subscriberIndex += 1;
		return elem;
	}
	pollUpTo(n) {
		if (this.isEmpty() || n < 1) return [];
		const a = this.self.value;
		this.self.subscribers -= 1;
		if (this.self.subscribers === 0) this.self.value = AbsentValue;
		this.subscriberIndex += 1;
		return [a];
	}
	unsubscribe() {
		if (!this.unsubscribed) {
			this.unsubscribed = true;
			this.self.subscriberCount -= 1;
			if (this.subscriberIndex !== this.self.publisherIndex) {
				this.self.subscribers -= 1;
				if (this.self.subscribers === 0) this.self.value = AbsentValue;
			}
		}
	}
};
var UnboundedPubSub = class {
	publisherHead = {
		value: AbsentValue,
		subscribers: 0,
		next: null
	};
	publisherTail = this.publisherHead;
	publisherIndex = 0;
	subscribersIndex = 0;
	capacity = Number.MAX_SAFE_INTEGER;
	replayBuffer;
	constructor(replayBuffer) {
		this.replayBuffer = replayBuffer;
	}
	replayWindow() {
		return this.replayBuffer ? new ReplayWindowImpl(this.replayBuffer) : emptyReplayWindow;
	}
	isEmpty() {
		return this.publisherHead === this.publisherTail;
	}
	isFull() {
		return false;
	}
	size() {
		return this.publisherIndex - this.subscribersIndex;
	}
	publish(value) {
		const subscribers = this.publisherTail.subscribers;
		if (subscribers !== 0) {
			this.publisherTail.next = {
				value,
				subscribers,
				next: null
			};
			this.publisherTail = this.publisherTail.next;
			this.publisherIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.offer(value);
		return true;
	}
	publishAll(elements) {
		if (this.publisherTail.subscribers !== 0) for (const a of elements) this.publish(a);
		else if (this.replayBuffer) this.replayBuffer.offerAll(elements);
		return [];
	}
	slide() {
		if (this.publisherHead !== this.publisherTail) {
			this.publisherHead = this.publisherHead.next;
			this.publisherHead.value = AbsentValue;
			this.subscribersIndex += 1;
		}
		if (this.replayBuffer) this.replayBuffer.slide();
	}
	subscribe() {
		this.publisherTail.subscribers += 1;
		return new UnboundedPubSubSubscription(this, this.publisherTail, this.publisherIndex, false);
	}
};
var UnboundedPubSubSubscription = class {
	self;
	subscriberHead;
	subscriberIndex;
	unsubscribed;
	constructor(self, subscriberHead, subscriberIndex, unsubscribed) {
		this.self = self;
		this.subscriberHead = subscriberHead;
		this.subscriberIndex = subscriberIndex;
		this.unsubscribed = unsubscribed;
	}
	isEmpty() {
		if (this.unsubscribed) return true;
		let empty = true;
		let loop = true;
		while (loop) if (this.subscriberHead === this.self.publisherTail) loop = false;
		else if (this.subscriberHead.next.value !== AbsentValue) {
			empty = false;
			loop = false;
		} else {
			this.subscriberHead = this.subscriberHead.next;
			this.subscriberIndex += 1;
		}
		return empty;
	}
	size() {
		if (this.unsubscribed) return 0;
		return this.self.publisherIndex - Math.max(this.subscriberIndex, this.self.subscribersIndex);
	}
	poll() {
		if (this.unsubscribed) return Empty;
		let loop = true;
		let polled = Empty;
		while (loop) if (this.subscriberHead === this.self.publisherTail) loop = false;
		else {
			const elem = this.subscriberHead.next.value;
			if (elem !== AbsentValue) {
				polled = elem;
				this.subscriberHead.subscribers -= 1;
				if (this.subscriberHead.subscribers === 0) {
					this.self.publisherHead = this.self.publisherHead.next;
					this.self.publisherHead.value = AbsentValue;
					this.self.subscribersIndex += 1;
				}
				loop = false;
			}
			this.subscriberHead = this.subscriberHead.next;
			this.subscriberIndex += 1;
		}
		return polled;
	}
	pollUpTo(n) {
		const builder = [];
		let i = 0;
		while (i !== n) {
			const a = this.poll();
			if (a === Empty) i = n;
			else {
				builder.push(a);
				i += 1;
			}
		}
		return builder;
	}
	unsubscribe() {
		if (!this.unsubscribed) {
			this.unsubscribed = true;
			this.self.publisherTail.subscribers -= 1;
			while (this.subscriberHead !== this.self.publisherTail) {
				if (this.subscriberHead.next.value !== AbsentValue) {
					this.subscriberHead.subscribers -= 1;
					if (this.subscriberHead.subscribers === 0) {
						this.self.publisherHead = this.self.publisherHead.next;
						this.self.publisherHead.value = AbsentValue;
						this.self.subscribersIndex += 1;
					}
				}
				this.subscriberHead = this.subscriberHead.next;
			}
		}
	}
};
var SubscriptionImpl = class {
	[SubscriptionTypeId] = { _A: identity$1 };
	pubsub;
	subscribers;
	subscription;
	pollers;
	shutdownHook;
	shutdownFlag;
	strategy;
	replayWindow;
	constructor(pubsub, subscribers, subscription, pollers, shutdownHook, shutdownFlag, strategy, replayWindow) {
		this.pubsub = pubsub;
		this.subscribers = subscribers;
		this.subscription = subscription;
		this.pollers = pollers;
		this.shutdownHook = shutdownHook;
		this.shutdownFlag = shutdownFlag;
		this.strategy = strategy;
		this.replayWindow = replayWindow;
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var PubSubImpl = class {
	[TypeId$2] = { _A: identity$1 };
	pubsub;
	subscribers;
	scope;
	shutdownHook;
	shutdownFlag;
	strategy;
	constructor(pubsub, subscribers, scope, shutdownHook, shutdownFlag, strategy) {
		this.pubsub = pubsub;
		this.subscribers = subscribers;
		this.scope = scope;
		this.shutdownHook = shutdownHook;
		this.shutdownFlag = shutdownFlag;
		this.strategy = strategy;
	}
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makePubSubUnsafe = (pubsub, subscribers, scope, shutdownHook, shutdownFlag, strategy) => new PubSubImpl(pubsub, subscribers, scope, shutdownHook, shutdownFlag, strategy);
var ensureCapacity = (capacity) => {
	if (capacity <= 0) throw new Error(`Cannot construct PubSub with capacity of ${capacity}`);
};
/**
* A strategy that applies back pressure to publishers when the `PubSub` is at
* capacity. This guarantees that all subscribers will receive all messages
* published to the `PubSub` while they are subscribed. However, it creates the
* risk that a slow subscriber will slow down the rate at which messages
* are published and received by other subscribers.
*
* @since 4.0.0
* @category models
*/
var BackPressureStrategy = class {
	publishers = /*#__PURE__*/ make$4();
	get shutdown() {
		return withFiber$1((fiber) => forEach$1(takeAll$2(this.publishers), ([_, deferred, last]) => last ? interruptWith(deferred, fiber.id) : void_, {
			concurrency: "unbounded",
			discard: true
		}));
	}
	handleSurplus(pubsub, subscribers, elements, isShutdown) {
		return suspend$1(() => {
			const deferred = makeUnsafe$3();
			this.offerUnsafe(elements, deferred);
			this.onPubSubEmptySpaceUnsafe(pubsub, subscribers);
			this.completeSubscribersUnsafe(pubsub, subscribers);
			return (get(isShutdown) ? interrupt$3 : _await(deferred)).pipe(onInterrupt(() => {
				this.removeUnsafe(deferred);
				return void_;
			}));
		});
	}
	onPubSubEmptySpaceUnsafe(pubsub, subscribers) {
		let keepPolling = true;
		while (keepPolling && !pubsub.isFull()) {
			const publisher = take$2(this.publishers);
			if (publisher === Empty) keepPolling = false;
			else {
				const [value, deferred] = publisher;
				const published = pubsub.publish(value);
				if (published && publisher[2]) doneUnsafe(deferred, succeed$3(true));
				else if (!published) prepend(this.publishers, publisher);
				this.completeSubscribersUnsafe(pubsub, subscribers);
			}
		}
	}
	completePollersUnsafe(pubsub, subscribers, subscription, pollers) {
		return strategyCompletePollersUnsafe(this, pubsub, subscribers, subscription, pollers);
	}
	completeSubscribersUnsafe(pubsub, subscribers) {
		return strategyCompleteSubscribersUnsafe(this, pubsub, subscribers);
	}
	offerUnsafe(elements, deferred) {
		const iterator = elements[Symbol.iterator]();
		let next = iterator.next();
		if (!next.done) while (1) {
			const value = next.value;
			next = iterator.next();
			if (next.done) {
				append(this.publishers, [
					value,
					deferred,
					true
				]);
				break;
			}
			append(this.publishers, [
				value,
				deferred,
				false
			]);
		}
	}
	removeUnsafe(deferred) {
		filter$1(this.publishers, ([_, d]) => d !== deferred);
	}
};
/**
* A strategy that drops new messages when the `PubSub` is at capacity. This
* guarantees that a slow subscriber will not slow down the rate at which
* messages are published. However, it creates the risk that a slow
* subscriber will slow down the rate at which messages are received by
* other subscribers and that subscribers may not receive all messages
* published to the `PubSub` while they are subscribed.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create PubSub with dropping strategy
*   const pubsub = yield* PubSub.dropping<string>(2)
*
*   // Or explicitly create with dropping strategy
*   const customPubsub = yield* PubSub.make<string>({
*     atomicPubSub: () => PubSub.makeAtomicBounded(2),
*     strategy: () => new PubSub.DroppingStrategy()
*   })
*
*   // Fill the PubSub
*   const pub1 = yield* PubSub.publish(pubsub, "msg1") // true
*   const pub2 = yield* PubSub.publish(pubsub, "msg2") // true
*   const pub3 = yield* PubSub.publish(pubsub, "msg3") // false (dropped)
*
*   console.log("Publication results:", [pub1, pub2, pub3]) // [true, true, false]
*
*   // Subscribers will only see the first two messages
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*     const messages = yield* PubSub.takeAll(subscription)
*     console.log("Received messages:", messages) // ["msg1", "msg2"]
*   }))
* })
* ```
*
* @since 4.0.0
* @category models
*/
var DroppingStrategy = class {
	get shutdown() {
		return void_;
	}
	handleSurplus(_pubsub, _subscribers, _elements, _isShutdown) {
		return succeed$2(false);
	}
	onPubSubEmptySpaceUnsafe(_pubsub, _subscribers) {}
	completePollersUnsafe(pubsub, subscribers, subscription, pollers) {
		return strategyCompletePollersUnsafe(this, pubsub, subscribers, subscription, pollers);
	}
	completeSubscribersUnsafe(pubsub, subscribers) {
		return strategyCompleteSubscribersUnsafe(this, pubsub, subscribers);
	}
};
/**
* A strategy that adds new messages and drops old messages when the `PubSub` is
* at capacity. This guarantees that a slow subscriber will not slow down
* the rate at which messages are published and received by other
* subscribers. However, it creates the risk that a slow subscriber will
* not receive some messages published to the `PubSub` while it is subscribed.
*
* @example
* ```ts
* import { Effect } from "effect"
* import * as PubSub from "effect/PubSub"
*
* const program = Effect.gen(function*() {
*   // Create PubSub with sliding strategy
*   const pubsub = yield* PubSub.sliding<string>(2)
*
*   // Or explicitly create with sliding strategy
*   const customPubsub = yield* PubSub.make<string>({
*     atomicPubSub: () => PubSub.makeAtomicBounded(2),
*     strategy: () => new PubSub.SlidingStrategy()
*   })
*
*   // Publish messages that exceed capacity
*   yield* PubSub.publish(pubsub, "msg1") // stored
*   yield* PubSub.publish(pubsub, "msg2") // stored
*   yield* PubSub.publish(pubsub, "msg3") // "msg1" evicted, "msg3" stored
*   yield* PubSub.publish(pubsub, "msg4") // "msg2" evicted, "msg4" stored
*
*   // Subscribers will see the most recent messages
*   yield* Effect.scoped(Effect.gen(function*() {
*     const subscription = yield* PubSub.subscribe(pubsub)
*     const messages = yield* PubSub.takeAll(subscription)
*     console.log("Recent messages:", messages) // ["msg3", "msg4"]
*   }))
* })
* ```
*
* @since 4.0.0
* @category models
*/
var SlidingStrategy = class {
	get shutdown() {
		return void_;
	}
	handleSurplus(pubsub, subscribers, elements, _isShutdown) {
		return sync$1(() => {
			this.slidingPublishUnsafe(pubsub, elements);
			this.completeSubscribersUnsafe(pubsub, subscribers);
			return true;
		});
	}
	onPubSubEmptySpaceUnsafe(_pubsub, _subscribers) {}
	completePollersUnsafe(pubsub, subscribers, subscription, pollers) {
		return strategyCompletePollersUnsafe(this, pubsub, subscribers, subscription, pollers);
	}
	completeSubscribersUnsafe(pubsub, subscribers) {
		return strategyCompleteSubscribersUnsafe(this, pubsub, subscribers);
	}
	slidingPublishUnsafe(pubsub, elements) {
		const it = elements[Symbol.iterator]();
		let next = it.next();
		if (!next.done && pubsub.capacity > 0) {
			let a = next.value;
			let loop = true;
			while (loop) {
				pubsub.slide();
				const pub = pubsub.publish(a);
				if (pub && (next = it.next()) && !next.done) a = next.value;
				else if (pub) loop = false;
			}
		}
	}
};
var strategyCompletePollersUnsafe = (strategy, pubsub, subscribers, subscription, pollers) => {
	let keepPolling = true;
	while (keepPolling && !subscription.isEmpty()) {
		const poller = take$2(pollers);
		if (poller === Empty) {
			removeSubscribers(subscribers, subscription, pollers);
			if (pollers.length === 0) keepPolling = false;
			else addSubscribers(subscribers, subscription, pollers);
		} else {
			const pollResult = subscription.poll();
			if (pollResult === Empty) prepend(pollers, poller);
			else {
				doneUnsafe(poller, succeed$3(pollResult));
				strategy.onPubSubEmptySpaceUnsafe(pubsub, subscribers);
			}
		}
	}
};
var strategyCompleteSubscribersUnsafe = (strategy, pubsub, subscribers) => {
	for (const [subscription, pollersSet] of subscribers) for (const pollers of pollersSet) strategy.completePollersUnsafe(pubsub, subscribers, subscription, pollers);
};
var ReplayBuffer = class {
	capacity;
	head = {
		value: AbsentValue,
		next: null
	};
	tail = this.head;
	size = 0;
	index = 0;
	constructor(capacity) {
		this.capacity = capacity;
	}
	slide() {
		this.index++;
	}
	offer(a) {
		this.tail.value = a;
		this.tail.next = {
			value: AbsentValue,
			next: null
		};
		this.tail = this.tail.next;
		if (this.size === this.capacity) this.head = this.head.next;
		else this.size += 1;
	}
	offerAll(as) {
		for (const a of as) this.offer(a);
	}
};
var ReplayWindowImpl = class {
	head;
	index;
	remaining;
	buffer;
	constructor(buffer) {
		this.buffer = buffer;
		this.index = buffer.index;
		this.remaining = buffer.size;
		this.head = buffer.head;
	}
	fastForward() {
		while (this.index < this.buffer.index) {
			this.head = this.head.next;
			this.index++;
		}
	}
	take() {
		if (this.remaining === 0) return;
		else if (this.index < this.buffer.index) this.fastForward();
		this.remaining--;
		const value = this.head.value;
		this.head = this.head.next;
		return value;
	}
	takeN(n) {
		if (this.remaining === 0) return [];
		else if (this.index < this.buffer.index) this.fastForward();
		const len = Math.min(n, this.remaining);
		const items = new Array(len);
		for (let i = 0; i < len; i++) {
			const value = this.head.value;
			this.head = this.head.next;
			items[i] = value;
		}
		this.remaining -= len;
		return items;
	}
	takeAll() {
		return this.takeN(this.remaining);
	}
};
var emptyReplayWindow = {
	remaining: 0,
	take: () => void 0,
	takeN: () => [],
	takeAll: () => []
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Queue.js
/**
* @since 3.8.0
*/
var Queue_exports = /* @__PURE__ */ __exportAll({
	asDequeue: () => asDequeue,
	asEnqueue: () => asEnqueue,
	await: () => await_,
	bounded: () => bounded,
	clear: () => clear,
	collect: () => collect,
	dropping: () => dropping,
	end: () => end$1,
	endUnsafe: () => endUnsafe,
	fail: () => fail$1,
	failCause: () => failCause$1,
	failCauseUnsafe: () => failCauseUnsafe,
	interrupt: () => interrupt,
	into: () => into,
	isDequeue: () => isDequeue,
	isEnqueue: () => isEnqueue,
	isFull: () => isFull,
	isFullUnsafe: () => isFullUnsafe,
	isQueue: () => isQueue,
	make: () => make$1,
	offer: () => offer,
	offerAll: () => offerAll,
	offerAllUnsafe: () => offerAllUnsafe,
	offerUnsafe: () => offerUnsafe,
	peek: () => peek,
	poll: () => poll,
	shutdown: () => shutdown,
	size: () => size,
	sizeUnsafe: () => sizeUnsafe,
	sliding: () => sliding,
	take: () => take,
	takeAll: () => takeAll,
	takeBetween: () => takeBetween,
	takeN: () => takeN,
	takeUnsafe: () => takeUnsafe,
	unbounded: () => unbounded
});
var TypeId$1 = "~effect/Queue";
var EnqueueTypeId = "~effect/Queue/Enqueue";
var DequeueTypeId = "~effect/Queue/Dequeue";
/**
* Type guard to check if a value is a Queue.
*
* @since 3.8.0
* @category Guards
*/
var isQueue = (u) => hasProperty(u, TypeId$1);
/**
* Type guard to check if a value is an Enqueue.
*
* @since 4.0.0
* @category Guards
*/
var isEnqueue = (u) => hasProperty(u, EnqueueTypeId);
/**
* Type guard to check if a value is a Dequeue.
*
* @since 4.0.0
* @category Guards
*/
var isDequeue = (u) => hasProperty(u, DequeueTypeId);
/**
* Converts a Queue to an Enqueue (write-only interface).
*
* @since 4.0.0
* @category Conversions
*/
var asEnqueue = (self) => self;
/**
* Convert a Queue to a Dequeue, allowing only read operations.
*
* @since 4.0.0
* @category Conversions
*/
var asDequeue = identity$1;
var variance = {
	_A: identity$1,
	_E: identity$1
};
var QueueProto = {
	[TypeId$1]: variance,
	[EnqueueTypeId]: variance,
	[DequeueTypeId]: variance,
	...PipeInspectableProto,
	toJSON() {
		return {
			_id: "effect/Queue",
			state: this.state._tag,
			size: sizeUnsafe(this)
		};
	}
};
/**
* A `Queue` is an asynchronous queue that can be offered to and taken from.
*
* It also supports signaling that it is done or failed.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Mailbox.make`
*
* @since 3.8.0
* @category Constructors
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
* import * as assert from "node:assert"
*
* Effect.gen(function*() {
*   const queue = yield* Queue.make<number, string | Cause.Done>()
*
*   // add messages to the queue
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*   yield* Queue.offerAll(queue, [3, 4, 5])
*
*   // take messages from the queue
*   const messages = yield* Queue.takeAll(queue)
*   assert.deepStrictEqual(messages, [1, 2, 3, 4, 5])
*
*   // signal that the queue is done
*   yield* Queue.end(queue)
*   const done = yield* Effect.flip(Queue.takeAll(queue))
*   assert.deepStrictEqual(done, Cause.Done)
*
*   // signal that the queue has failed
*   yield* Queue.fail(queue, "boom")
* })
* ```
*/
var make$1 = (options) => withFiber((fiber) => {
	const self = Object.create(QueueProto);
	self.scheduler = fiber.currentScheduler;
	self.capacity = options?.capacity ?? Number.POSITIVE_INFINITY;
	self.strategy = options?.strategy ?? "suspend";
	self.messages = make$4();
	self.scheduleRunning = false;
	self.state = {
		_tag: "Open",
		takers: /* @__PURE__ */ new Set(),
		offers: /* @__PURE__ */ new Set(),
		awaiters: /* @__PURE__ */ new Set()
	};
	return succeed$4(self);
});
/**
* Creates a bounded queue with the specified capacity that uses backpressure strategy.
*
* When the queue reaches capacity, producers will be suspended until space becomes available.
* This ensures all messages are processed but may slow down producers.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<string>(5)
*
*   // This will succeed as queue has capacity
*   yield* Queue.offer(queue, "first")
*   yield* Queue.offer(queue, "second")
*
*   const size = yield* Queue.size(queue)
*   console.log(size) // 2
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var bounded = (capacity) => make$1({ capacity });
/**
* Creates a bounded queue with sliding strategy. When the queue reaches capacity,
* new elements are added and the oldest elements are dropped.
*
* This strategy prevents producers from being blocked but may result in message loss.
* Useful when you want to maintain a rolling window of the most recent messages.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.sliding<number>(3)
*
*   // Fill the queue to capacity
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*   yield* Queue.offer(queue, 3)
*
*   // This will succeed, dropping the oldest element (1)
*   yield* Queue.offer(queue, 4)
*
*   const all = yield* Queue.takeAll(queue)
*   console.log(all) // [2, 3, 4] - oldest element (1) was dropped
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var sliding = (capacity) => make$1({
	capacity,
	strategy: "sliding"
});
/**
* Creates a bounded queue with dropping strategy. When the queue reaches capacity,
* new elements are dropped and the offer operation returns false.
*
* This strategy prevents producers from being blocked and preserves existing messages,
* but new messages may be lost when the queue is full.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.dropping<number>(2)
*
*   // Fill the queue to capacity
*   const success1 = yield* Queue.offer(queue, 1)
*   const success2 = yield* Queue.offer(queue, 2)
*   console.log(success1, success2) // true, true
*
*   // This will be dropped
*   const success3 = yield* Queue.offer(queue, 3)
*   console.log(success3) // false
*
*   const all = yield* Queue.takeAll(queue)
*   console.log(all) // [1, 2] - element 3 was dropped
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var dropping = (capacity) => make$1({
	capacity,
	strategy: "dropping"
});
/**
* Creates an unbounded queue that can grow to any size without blocking producers.
*
* Unlike bounded queues, unbounded queues never apply backpressure - producers
* can always add messages successfully. This is useful when you want to prioritize
* producer throughput over memory usage control.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.unbounded<string>()
*
*   // Producers can always add messages without blocking
*   yield* Queue.offer(queue, "message1")
*   yield* Queue.offer(queue, "message2")
*   yield* Queue.offerAll(queue, ["message3", "message4", "message5"])
*
*   // Check current size
*   const size = yield* Queue.size(queue)
*   console.log(size) // Some(5)
*
*   // Take all messages
*   const messages = yield* Queue.takeAll(queue)
*   console.log(messages) // ["message1", "message2", "message3", "message4", "message5"]
* })
* ```
*
* @since 2.0.0
* @category Constructors
*/
var unbounded = () => make$1();
/**
* Add a message to the queue. Returns `false` if the queue is done.
*
* For bounded queues, this operation may suspend if the queue is at capacity,
* depending on the backpressure strategy. For dropping/sliding queues, it may
* return false or succeed immediately by dropping/sliding existing messages.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(3)
*
*   // Successfully add messages to queue
*   const success1 = yield* Queue.offer(queue, 1)
*   const success2 = yield* Queue.offer(queue, 2)
*   console.log(success1, success2) // true, true
*
*   // Queue state
*   const size = yield* Queue.size(queue)
*   console.log(size) // 2
* })
* ```
*
* @category Offering
* @since 4.0.0
*/
var offer = (self, message) => suspend$2(() => {
	if (self.state._tag !== "Open") return exitFalse;
	else if (self.messages.length >= self.capacity) switch (self.strategy) {
		case "dropping": return exitFalse;
		case "suspend":
			if (self.capacity <= 0 && self.state.takers.size > 0) {
				append(self.messages, message);
				releaseTakers(self);
				return exitTrue;
			}
			return offerRemainingSingle(self, message);
		case "sliding":
			take$2(self.messages);
			append(self.messages, message);
			return exitTrue;
	}
	append(self.messages, message);
	scheduleReleaseTaker(self);
	return exitTrue;
});
/**
* Add a message to the queue synchronously. Returns `false` if the queue is done.
*
* This is an unsafe operation that directly modifies the queue without Effect wrapping.
* Use this only when you're certain about the synchronous nature of the operation.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* // Create a queue effect and extract the queue for unsafe operations
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(3)
*
*   // Add messages synchronously using unsafe API
*   const success1 = Queue.offerUnsafe(queue, 1)
*   const success2 = Queue.offerUnsafe(queue, 2)
*   console.log(success1, success2) // true, true
*
*   // Check current size
*   const size = Queue.sizeUnsafe(queue)
*   console.log(size) // 2
* })
* ```
*
* @category Offering
* @since 4.0.0
*/
var offerUnsafe = (self, message) => {
	if (self.state._tag !== "Open") return false;
	else if (self.messages.length >= self.capacity) {
		if (self.strategy === "sliding") {
			take$2(self.messages);
			append(self.messages, message);
			return true;
		} else if (self.capacity <= 0 && self.state.takers.size > 0) {
			append(self.messages, message);
			releaseTakers(self);
			return true;
		}
		return false;
	}
	append(self.messages, message);
	scheduleReleaseTaker(self);
	return true;
};
/**
* Add multiple messages to the queue. Returns the remaining messages that
* were not added.
*
* For bounded queues, this operation may suspend if the queue doesn't have
* enough capacity. The operation returns an array of messages that couldn't
* be added (empty array means all messages were successfully added).
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(3)
*
*   // Try to add more messages than capacity
*   const remaining1 = yield* Queue.offerAll(queue, [1, 2, 3, 4, 5])
*   console.log(remaining1) // [4, 5] - couldn't fit the last 2
* })
* ```
*
* @category Offering
* @since 4.0.0
*/
var offerAll = (self, messages) => suspend$2(() => {
	if (self.state._tag !== "Open") return succeed$4(fromIterable$2(messages));
	const remaining = offerAllUnsafe(self, messages);
	if (remaining.length === 0) return exitSucceed([]);
	else if (self.strategy === "dropping") return succeed$4(remaining);
	return offerRemainingArray(self, remaining);
});
/**
* Add multiple messages to the queue synchronously. Returns the remaining messages that
* were not added.
*
* This is an unsafe operation that directly modifies the queue without Effect wrapping.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* // Create a bounded queue and use unsafe API
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(3)
*
*   // Try to add 5 messages to capacity-3 queue using unsafe API
*   const remaining = Queue.offerAllUnsafe(queue, [1, 2, 3, 4, 5])
*   console.log(remaining) // [4, 5] - couldn't fit the last 2
*
*   // Check what's in the queue
*   const size = Queue.sizeUnsafe(queue)
*   console.log(size) // 3
* })
* ```
*
* @category Offering
* @since 4.0.0
*/
var offerAllUnsafe = (self, messages) => {
	if (self.state._tag !== "Open") return fromIterable$2(messages);
	else if (self.capacity === Number.POSITIVE_INFINITY || self.strategy === "sliding") {
		appendAll(self.messages, messages);
		if (self.strategy === "sliding") takeN$1(self.messages, self.messages.length - self.capacity);
		scheduleReleaseTaker(self);
		return [];
	}
	const free = self.capacity <= 0 ? self.state.takers.size : self.capacity - self.messages.length;
	if (free === 0) return fromIterable$2(messages);
	const remaining = [];
	let i = 0;
	for (const message of messages) {
		if (i < free) append(self.messages, message);
		else remaining.push(message);
		i++;
	}
	scheduleReleaseTaker(self);
	return remaining;
};
/**
* Fail the queue with an error. If the queue is already done, `false` is
* returned.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, string>(10)
*
*   // Add some messages
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*
*   // Fail the queue with an error
*   const failed = yield* Queue.fail(queue, "Something went wrong")
*   console.log(failed) // true
*
*   // Subsequent operations will reflect the failure
*   // Taking from failed queue will fail with the error
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var fail$1 = (self, error) => failCause$1(self, causeFail(error));
/**
* Fail the queue with a cause. If the queue is already done, `false` is
* returned.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, string>(10)
*
*   // Add some messages
*   yield* Queue.offer(queue, 1)
*
*   // Create a cause and fail the queue
*   const cause = Cause.fail("Queue processing failed")
*   const failed = yield* Queue.failCause(queue, cause)
*   console.log(failed) // true
*
*   // The queue is now in failed state with the specified cause
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var failCause$1 = /*#__PURE__*/ dual(2, (self, cause) => sync$2(() => failCauseUnsafe(self, cause)));
/**
* Fail the queue with a cause synchronously. If the queue is already done, `false` is
* returned.
*
* This is an unsafe operation that directly modifies the queue without Effect wrapping.
*
* @example
* ```ts
* import { Effect, Cause } from "effect"
* import { Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, string>(10)
*
*   // Add some messages
*   Queue.offerUnsafe(queue, 1)
*
*   // Create a cause and fail the queue synchronously
*   const cause = Cause.fail("Processing error")
*   const failed = Queue.failCauseUnsafe(queue, cause)
*   console.log(failed) // true
*
*   // The queue is now in failed state
*   console.log(queue.state._tag) // "Done"
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var failCauseUnsafe = (self, cause) => {
	if (self.state._tag !== "Open") return false;
	const fail = exitZipRight(exitFailCause(cause), exitFailDone);
	if (self.state.offers.size === 0 && self.messages.length === 0) {
		finalize(self, fail);
		return true;
	}
	self.state = {
		...self.state,
		_tag: "Closing",
		exit: fail
	};
	return true;
};
/**
* Signal that the queue is complete. If the queue is already done, `false` is
* returned.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(10)
*
*   // Add some messages
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*
*   // Signal completion - no more messages will be accepted
*   const ended = yield* Queue.end(queue)
*   console.log(ended) // true
*
*   // Trying to offer more messages will return false
*   const offerResult = yield* Queue.offer(queue, 3)
*   console.log(offerResult) // false
*
*   // But we can still take existing messages
*   const message = yield* Queue.take(queue)
*   console.log(message) // 1
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var end$1 = (self) => failCause$1(self, causeFail(Done()));
/**
* Signal that the queue is complete synchronously. If the queue is already done, `false` is
* returned.
*
* This is an unsafe operation that directly modifies the queue without Effect wrapping.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* // Create a queue and use unsafe operations
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(10)
*
*   // Add some messages
*   Queue.offerUnsafe(queue, 1)
*   Queue.offerUnsafe(queue, 2)
*
*   // End the queue synchronously
*   const ended = Queue.endUnsafe(queue)
*   console.log(ended) // true
*
*   // The queue is now done
*   console.log(queue.state._tag) // "Done"
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var endUnsafe = (self) => failCauseUnsafe(self, causeFail(Done()));
/**
* Interrupts the queue gracefully, transitioning it to a closing state.
*
* This operation stops accepting new offers but allows existing messages to be consumed.
* Once all messages are drained, the queue transitions to the Done state with an interrupt cause.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*
*   // Add some messages
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*
*   // Interrupt gracefully - no more offers accepted, but messages can be consumed
*   const interrupted = yield* Queue.interrupt(queue)
*   console.log(interrupted) // true
*
*   // Trying to offer more messages will return false
*   const offerResult = yield* Queue.offer(queue, 3)
*   console.log(offerResult) // false
*
*   // But we can still take existing messages
*   const message1 = yield* Queue.take(queue)
*   console.log(message1) // 1
*
*   const message2 = yield* Queue.take(queue)
*   console.log(message2) // 2
*
*   // After all messages are consumed, queue is done
*   const isDone = queue.state._tag === "Done"
*   console.log(isDone) // true
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var interrupt = (self) => withFiber((fiber) => failCause$1(self, causeInterrupt(fiber.id)));
/**
* Shutdown the queue, canceling any pending operations.
* If the queue is already done, `false` is returned.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(2)
*
*   // Add messages
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*
*   // Try to add more than capacity (will be pending)
*   const pendingOffer = Queue.offer(queue, 3)
*
*   // Shutdown cancels pending operations and clears the queue
*   const wasShutdown = yield* Queue.shutdown(queue)
*   console.log(wasShutdown) // true
*
*   // Queue is now done and cleared
*   const size = yield* Queue.size(queue)
*   console.log(size) // 0
* })
* ```
*
* @category Completion
* @since 4.0.0
*/
var shutdown = (self) => sync$2(() => {
	if (self.state._tag === "Done") return true;
	clear$1(self.messages);
	const offers = self.state.offers;
	finalize(self, self.state._tag === "Open" ? exitInterrupt : self.state.exit);
	if (offers.size > 0) {
		for (const entry of offers) if (entry._tag === "Single") entry.resume(exitFalse);
		else entry.resume(exitSucceed(entry.remaining.slice(entry.offset)));
		offers.clear();
	}
	return true;
});
/**
* Take all messages from the queue, returning an empty array if the queue
* is empty or done.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*
*   // Add several messages
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5])
*
*   // Clear all messages from the queue
*   const messages = yield* Queue.clear(queue)
*   console.log(messages) // [1, 2, 3, 4, 5]
*
*   // Queue is now empty
*   const size = yield* Queue.size(queue)
*   console.log(size) // 0
*
*   // Clearing empty queue returns empty array
*   const empty = yield* Queue.clear(queue)
*   console.log(empty) // []
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var clear = (self) => suspend$2(() => {
	if (self.state._tag === "Done") {
		if (isDoneCause(self.state.exit.cause)) return succeed$4([]);
		return self.state.exit;
	}
	const messages = takeAllUnsafe(self);
	releaseCapacity(self);
	return succeed$4(messages);
});
/**
* Take all messages from the queue, or wait for messages to be available.
*
* If the queue is done, the `done` flag will be `true`. If the queue
* fails, the Effect will fail with the error.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(5)
*
*   // Add several messages
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5])
*
*   // Take all available messages
*   const messages1 = yield* Queue.takeAll(queue)
*   console.log(messages1) // [1, 2, 3, 4, 5]
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var takeAll = (self) => takeBetween(self, 1, Number.POSITIVE_INFINITY);
/**
* Take all messages from the queue, until the queue has errored or is done.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(5)
*
*   // Add several messages
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5])
*   // Some time later, end the queue
*   yield* Effect.forkChild(Queue.end(queue))
*
*   // Collect all available messages
*   const messages = yield* Queue.collect(queue)
*   console.log(messages) // [1, 2, 3, 4, 5]
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var collect = (self) => suspend$2(() => {
	const out = empty$2();
	return as(catchDone(whileLoop({
		while: constTrue,
		body: constant(takeAll(self)),
		step(items) {
			for (let i = 0; i < items.length; i++) out.push(items[i]);
		}
	}), () => void_$1), out);
});
/**
* Take a specified number of messages from the queue. It will only take
* up to the capacity of the queue.
*
* If the queue is done, the `done` flag will be `true`. If the queue
* fails, the Effect will fail with the error.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*
*   // Add several messages
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5, 6, 7])
*
*   // Take exactly 3 messages
*   const first3 = yield* Queue.takeN(queue, 3)
*   console.log(first3) // [1, 2, 3]
*
*   // Take exactly 2 more messages
*   const next2 = yield* Queue.takeN(queue, 2)
*   console.log(next2) // [4, 5]
*
*   // Take remaining messages (will take 2, even though we asked for 5)
*   const remaining = yield* Queue.takeN(queue, 5)
*   console.log(remaining) // [6, 7]
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var takeN = (self, n) => takeBetween(self, n, n);
/**
* Take a variable number of messages from the queue, between specified min and max.
* It will only take up to the capacity of the queue.
*
* If the queue is done, the `done` flag will be `true`. If the queue
* fails, the Effect will fail with the error.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*
*   // Add several messages
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5, 6, 7, 8])
*
*   // Take between 2 and 5 messages
*   const batch1 = yield* Queue.takeBetween(queue, 2, 5)
*   console.log(batch1) // [1, 2, 3, 4, 5] - took 5 (up to max)
*
*   // Take between 1 and 10 messages (but only 3 remain)
*   const batch2 = yield* Queue.takeBetween(queue, 1, 10)
*   console.log(batch2) // [6, 7, 8] - took 3 (all remaining)
*
*   // No more messages available, will wait or return done
*   // const batch3 = yield* Queue.takeBetween(queue, 1, 3)
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var takeBetween = (self, min, max) => suspend$2(() => takeBetweenUnsafe(self, min, max) ?? andThen$1(awaitTake(self), takeBetween(self, 1, max)));
/**
* Take a single message from the queue, or wait for a message to be
* available.
*
* If the queue is done, it will fail with `Done`. If the
* queue fails, the Effect will fail with the error.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<string, Cause.Done>(3)
*
*   // Add some messages
*   yield* Queue.offer(queue, "first")
*   yield* Queue.offer(queue, "second")
*
*   // Take messages one by one
*   const msg1 = yield* Queue.take(queue)
*   const msg2 = yield* Queue.take(queue)
*   console.log(msg1, msg2) // "first", "second"
*
*   // End the queue
*   yield* Queue.end(queue)
*
*   // Taking from ended queue fails with None
*   const result = yield* Effect.match(Queue.take(queue), {
*     onFailure: (error: Cause.Done) => true,
*     onSuccess: (value: string) => false
*   })
*   console.log("Queue ended:", result) // true
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var take = (self) => suspend$2(() => takeUnsafe(self) ?? andThen$1(awaitTake(self), take(self)));
/**
* Tries to take an item from the queue without blocking.
*
* Returns `Option.some` with the item if available, or `Option.none` if the queue is empty or done.
*
* @example
* ```ts
* import { Effect, Option, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*
*   // Poll returns Option.none if empty
*   const maybe1 = yield* Queue.poll(queue)
*   console.log(Option.isNone(maybe1)) // true
*
*   // Add an item
*   yield* Queue.offer(queue, 42)
*
*   // Poll returns Option.some with the item
*   const maybe2 = yield* Queue.poll(queue)
*   console.log(Option.getOrNull(maybe2)) // 42
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var poll = (self) => suspend$2(() => {
	const result = takeUnsafe(self);
	if (result === void 0) return succeed$4(none());
	if (result._tag === "Success") return succeed$4(some(result.value));
	return succeed$4(none());
});
/**
* Views the next item without removing it.
*
* Blocks until an item is available. If the queue is done or fails, the error is propagated.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*   yield* Queue.offer(queue, 42)
*
*   // Peek at the next item without removing it
*   const item = yield* Queue.peek(queue)
*   console.log(item) // 42
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var peek = (self) => suspend$2(() => {
	if (self.state._tag === "Done") return self.state.exit;
	if (self.messages.length > 0 && self.messages.head) return succeed$4(self.messages.head.array[self.messages.head.offset]);
	return andThen$1(awaitTake(self), peek(self));
});
/**
* Take a single message from the queue synchronously, or wait for a message to be
* available.
*
* If the queue is done, it will fail with `Done`. If the
* queue fails, the Effect will fail with the error.
* Returns `undefined` if no message is immediately available.
*
* This is an unsafe operation that directly accesses the queue without Effect wrapping.
*
* @example
* ```ts
* import { Effect, Queue } from "effect"
*
* // Create a queue and use unsafe operations
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number>(10)
*
*   // Add some messages
*   Queue.offerUnsafe(queue, 1)
*   Queue.offerUnsafe(queue, 2)
*
*   // Take a message synchronously
*   const result1 = Queue.takeUnsafe(queue)
*   console.log(result1) // Success(1) or Exit containing value 1
*
*   const result2 = Queue.takeUnsafe(queue)
*   console.log(result2) // Success(2)
*
*   // No more messages - returns undefined
*   const result3 = Queue.takeUnsafe(queue)
*   console.log(result3) // undefined
* })
* ```
*
* @category Taking
* @since 4.0.0
*/
var takeUnsafe = (self) => {
	if (self.state._tag === "Done") return self.state.exit;
	if (self.messages.length > 0) {
		const message = take$2(self.messages);
		releaseCapacity(self);
		return exitSucceed(message);
	} else if (self.capacity <= 0 && self.state.offers.size > 0) {
		self.capacity = 1;
		releaseCapacity(self);
		self.capacity = 0;
		const message = take$2(self.messages);
		releaseCapacity(self);
		return exitSucceed(message);
	}
};
var await_ = (self) => callback$1((resume) => {
	if (self.state._tag === "Done") {
		if (isDoneCause(self.state.exit.cause)) return resume(exitVoid);
		return resume(self.state.exit);
	}
	self.state.awaiters.add(resume);
	return sync$2(() => {
		if (self.state._tag !== "Done") self.state.awaiters.delete(resume);
	});
});
/**
* Check the size of the queue.
*
* If the queue is complete, it will return `None`.
*
* @example
* ```ts
* import { Cause, Effect, Option, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(10)
*
*   // Check size of empty queue
*   const size1 = yield* Queue.size(queue)
*   console.log(size1) // 0
*
*   // Add some messages
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5])
*
*   // Check size after adding messages
*   const size2 = yield* Queue.size(queue)
*   console.log(size2) // 5
*
*   // End the queue
*   yield* Queue.end(queue)
*
*   // Size of ended queue is 0
*   const size3 = yield* Queue.size(queue)
*   console.log(size3) // 0
* })
* ```
*
* @category Size
* @since 4.0.0
*/
var size = (self) => sync$2(() => sizeUnsafe(self));
/**
* Check if the queue is full.
*
* @example
* ```ts
* import { Cause, Effect, Option, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(3)
*
*   console.log(yield* Queue.isFull(queue)) // false
*
*   // Add some messages
*   yield* Queue.offerAll(queue, [1, 2, 3])
*
*   console.log(yield* Queue.isFull(queue)) // true
* })
* ```
*
* @category Size
* @since 4.0.0
*/
var isFull = (self) => sync$2(() => isFullUnsafe(self));
/**
* Check the size of the queue synchronously.
*
* If the queue is complete, it will return `None`.
* This is an unsafe operation that directly accesses the queue without Effect wrapping.
*
* @example
* ```ts
* import { Cause, Effect, Option, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(10)
*
*   // Check size of empty queue
*   const size1 = Queue.sizeUnsafe(queue)
*   console.log(size1) // 0
*
*   // Add some messages
*   Queue.offerUnsafe(queue, 1)
*   Queue.offerUnsafe(queue, 2)
*   Queue.offerUnsafe(queue, 3)
*
*   // Check size after adding messages
*   const size2 = Queue.sizeUnsafe(queue)
*   console.log(size2) // 3
*
*   // End the queue
*   Queue.endUnsafe(queue)
*
*   // Size of ended queue is 0
*   const size3 = Queue.sizeUnsafe(queue)
*   console.log(size3) // 0
* })
* ```
*
* @category Size
* @since 4.0.0
*/
var sizeUnsafe = (self) => self.state._tag === "Done" ? 0 : self.messages.length;
/**
* Check if the queue is full synchronously.
*
* @example
* ```ts
* import { Cause, Effect, Option, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(3)
*
*   console.log(Queue.isFullUnsafe(queue)) // false
*
*   // Add some messages
*   yield* Queue.offerAll(queue, [1, 2, 3])
*
*   console.log(Queue.isFullUnsafe(queue)) // true
* })
* ```
*
* @category Size
* @since 4.0.0
*/
var isFullUnsafe = (self) => sizeUnsafe(self) === self.capacity;
/**
* Run an `Effect` into a `Queue`, where success ends the queue and failure
* fails the queue.
*
* @example
* ```ts
* import { Cause, Effect, Queue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(10)
*
*   // Create an effect that succeeds
*   const dataProcessing = Effect.gen(function*() {
*     yield* Effect.sleep("100 millis")
*     return "Processing completed successfully"
*   })
*
*   // Pipe the effect into the queue
*   // If dataProcessing succeeds, queue ends successfully
*   // If dataProcessing fails, queue fails with the error
*   const effectIntoQueue = Queue.into(queue)(dataProcessing)
*
*   const wasCompleted = yield* effectIntoQueue
*   console.log("Queue operation completed:", wasCompleted) // true
*
*   // Queue state now reflects the effect's outcome
*   console.log("Queue state:", queue.state._tag) // "Done"
* })
* ```
*
* @since 3.8.0
* @category Completion
*/
var into = /*#__PURE__*/ dual(2, (effect, self) => uninterruptibleMask((restore) => matchCauseEffect(restore(effect), {
	onFailure: (cause) => failCause$1(self, cause),
	onSuccess: (_) => end$1(self)
})));
var exitFalse = /*#__PURE__*/ exitSucceed(false);
var exitTrue = /*#__PURE__*/ exitSucceed(true);
var exitFailDone = /*#__PURE__*/ exitFail(/*#__PURE__*/ Done());
var exitInterrupt = /*#__PURE__*/ exitInterrupt$1();
var releaseTakers = (self) => {
	self.scheduleRunning = false;
	if (self.state._tag === "Done" || self.state.takers.size === 0) return;
	for (const taker of self.state.takers) {
		self.state.takers.delete(taker);
		taker(exitVoid);
		if (self.messages.length === 0) break;
	}
};
var scheduleReleaseTaker = (self) => {
	if (self.scheduleRunning || self.state._tag === "Done" || self.state.takers.size === 0) return;
	self.scheduleRunning = true;
	self.scheduler.scheduleTask(() => releaseTakers(self), 0);
};
var takeBetweenUnsafe = (self, min, max) => {
	if (self.state._tag === "Done") return self.state.exit;
	else if (max <= 0 || min <= 0) return exitSucceed([]);
	else if (self.capacity <= 0 && self.state.offers.size > 0) {
		self.capacity = 1;
		releaseCapacity(self);
		self.capacity = 0;
		const messages = [take$2(self.messages)];
		releaseCapacity(self);
		return exitSucceed(messages);
	}
	min = Math.min(min, self.capacity || 1);
	if (min <= self.messages.length) {
		const messages = takeN$1(self.messages, max);
		releaseCapacity(self);
		return exitSucceed(messages);
	}
};
var offerRemainingSingle = (self, message) => {
	return callback$1((resume) => {
		if (self.state._tag !== "Open") return resume(exitFalse);
		const entry = {
			_tag: "Single",
			message,
			resume
		};
		self.state.offers.add(entry);
		return sync$2(() => {
			if (self.state._tag === "Open") self.state.offers.delete(entry);
		});
	});
};
var offerRemainingArray = (self, remaining) => {
	return callback$1((resume) => {
		if (self.state._tag !== "Open") return resume(exitSucceed(remaining));
		const entry = {
			_tag: "Array",
			remaining,
			offset: 0,
			resume
		};
		self.state.offers.add(entry);
		return sync$2(() => {
			if (self.state._tag === "Open") self.state.offers.delete(entry);
		});
	});
};
var releaseCapacity = (self) => {
	if (self.state._tag === "Done") return isDoneCause(self.state.exit.cause);
	else if (self.state.offers.size === 0) {
		if (self.state._tag === "Closing" && self.messages.length === 0) {
			finalize(self, self.state.exit);
			return isDoneCause(self.state.exit.cause);
		}
		return false;
	}
	let n = self.capacity - self.messages.length;
	for (const entry of self.state.offers) if (n === 0) break;
	else if (entry._tag === "Single") {
		append(self.messages, entry.message);
		n--;
		entry.resume(exitTrue);
		self.state.offers.delete(entry);
	} else {
		for (; entry.offset < entry.remaining.length; entry.offset++) {
			if (n === 0) return false;
			append(self.messages, entry.remaining[entry.offset]);
			n--;
		}
		entry.resume(exitSucceed([]));
		self.state.offers.delete(entry);
	}
	return false;
};
var awaitTake = (self) => callback$1((resume) => {
	if (self.state._tag === "Done") return resume(self.state.exit);
	self.state.takers.add(resume);
	return sync$2(() => {
		if (self.state._tag !== "Done") self.state.takers.delete(resume);
	});
});
var takeAllUnsafe = (self) => {
	if (self.messages.length > 0) {
		const messages = takeAll$2(self.messages);
		releaseCapacity(self);
		return messages;
	} else if (self.state._tag !== "Done" && self.state.offers.size > 0) {
		self.capacity = 1;
		releaseCapacity(self);
		self.capacity = 0;
		const messages = [take$2(self.messages)];
		releaseCapacity(self);
		return messages;
	}
	return [];
};
var finalize = (self, exit) => {
	if (self.state._tag === "Done") return;
	const openState = self.state;
	self.state = {
		_tag: "Done",
		exit
	};
	for (const taker of openState.takers) taker(exit);
	openState.takers.clear();
	for (const awaiter of openState.awaiters) awaiter(exit);
	openState.awaiters.clear();
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Semaphore.js
/**
* @since 2.0.0
*/
var Semaphore_exports = /* @__PURE__ */ __exportAll({
	PartitionedTypeId: () => PartitionedTypeId,
	make: () => make,
	makePartitioned: () => makePartitioned,
	makePartitionedUnsafe: () => makePartitionedUnsafe,
	makeUnsafe: () => makeUnsafe
});
/**
* Unsafely creates a new Semaphore.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.makeSemaphoreUnsafe`
*
* @example
* ```ts
* import { Effect, Semaphore } from "effect"
*
* const semaphore = Semaphore.makeUnsafe(3)
*
* const task = (id: number) =>
*   semaphore.withPermits(1)(
*     Effect.gen(function*() {
*       yield* Effect.log(`Task ${id} started`)
*       yield* Effect.sleep("1 second")
*       yield* Effect.log(`Task ${id} completed`)
*     })
*   )
*
* // Only 3 tasks can run concurrently
* const program = Effect.all([
*   task(1),
*   task(2),
*   task(3),
*   task(4),
*   task(5)
* ], { concurrency: "unbounded" })
* ```
*
* @since 2.0.0
* @category constructors
*/
var makeUnsafe = makeSemaphoreUnsafe;
/**
* Creates a new Semaphore.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Effect.makeSemaphore`
*
* @example
* ```ts
* import { Effect, Semaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* Semaphore.make(2)
*
*   const task = (id: number) =>
*     semaphore.withPermits(1)(
*       Effect.gen(function*() {
*         yield* Effect.log(`Task ${id} acquired permit`)
*         yield* Effect.sleep("1 second")
*         yield* Effect.log(`Task ${id} releasing permit`)
*       })
*     )
*
*   // Run 4 tasks, but only 2 can run concurrently
*   yield* Effect.all([task(1), task(2), task(3), task(4)])
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var make = makeSemaphore;
/**
* @since 3.19.4
* @category models
*/
var PartitionedTypeId = "~effect/PartitionedSemaphore";
/**
* Creates a `Partitioned` semaphore unsafely.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `PartitionedSemaphore.makeUnsafe`
*
* @since 3.19.4
* @category constructors
*/
var makePartitionedUnsafe = (options) => {
	const maxPermits = Math.max(0, options.permits);
	if (!Number.isFinite(maxPermits)) return {
		[PartitionedTypeId]: PartitionedTypeId,
		withPermits: () => (effect) => effect
	};
	let totalPermits = maxPermits;
	let waitingPermits = 0;
	const partitions = empty$1();
	const take = (key, permits) => callback$2((resume) => {
		if (maxPermits < permits) {
			resume(never$1);
			return;
		}
		if (totalPermits >= permits) {
			totalPermits -= permits;
			resume(void_);
			return;
		}
		const needed = permits - totalPermits;
		const taken = permits - needed;
		if (totalPermits > 0) totalPermits = 0;
		waitingPermits += needed;
		const waiters = getOrElse(get$1(partitions, key), () => {
			const set = /* @__PURE__ */ new Set();
			set$1(partitions, key, set);
			return set;
		});
		const entry = {
			permits: needed,
			resume: () => {
				cleanup();
				resume(void_);
			}
		};
		const cleanup = () => {
			waiters.delete(entry);
			if (waiters.size === 0) remove$1(partitions, key);
		};
		waiters.add(entry);
		return sync$1(() => {
			cleanup();
			waitingPermits -= entry.permits;
			if (taken > 0) releaseUnsafe(taken);
		});
	});
	let iterator = partitions[Symbol.iterator]();
	const releaseUnsafe = (permits) => {
		while (permits > 0) {
			if (waitingPermits === 0) {
				totalPermits += permits;
				return;
			}
			let state = iterator.next();
			if (state.done) {
				iterator = partitions[Symbol.iterator]();
				state = iterator.next();
				if (state.done) return;
			}
			const waiter = state.value[1].values().next().value;
			if (waiter === void 0) continue;
			waiter.permits -= 1;
			waitingPermits -= 1;
			if (waiter.permits === 0) waiter.resume();
			permits -= 1;
		}
	};
	return {
		[PartitionedTypeId]: PartitionedTypeId,
		withPermits: (key, permits) => {
			const takePermits = take(key, permits);
			return (effect) => uninterruptibleMask$1((restore) => flatMap$1(restore(takePermits), () => ensuring$1(restore(effect), sync$1(() => releaseUnsafe(permits)))));
		}
	};
};
/**
* Creates a `Partitioned` semaphore.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `PartitionedSemaphore.make`
*
* @since 3.19.4
* @category constructors
*/
var makePartitioned = (options) => sync$1(() => makePartitionedUnsafe(options));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Take.js
var Take_exports = /* @__PURE__ */ __exportAll({ toPull: () => toPull$1 });
/**
* @since 4.0.0
* @category Conversions
*/
var toPull$1 = (take) => isExit(take) ? isSuccess$1(take) ? done(take.value) : take : succeed$2(take);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Channel.js
/**
* The `Channel` module provides a powerful abstraction for bi-directional communication
* and streaming operations. A `Channel` is a nexus of I/O operations that supports both
* reading and writing, forming the foundation for Effect's Stream and Sink abstractions.
*
* ## What is a Channel?
*
* A `Channel<OutElem, OutErr, OutDone, InElem, InErr, InDone, Env>` represents:
* - **OutElem**: The type of elements the channel outputs
* - **OutErr**: The type of errors the channel can produce
* - **OutDone**: The type of the final value when the channel completes
* - **InElem**: The type of elements the channel reads
* - **InErr**: The type of errors the channel can receive
* - **InDone**: The type of the final value from upstream
* - **Env**: The environment/context required by the channel
*
* ## Key Features
*
* - **Bi-directional**: Channels can both read and write
* - **Composable**: Channels can be piped, sequenced, and concatenated
* - **Resource-safe**: Automatic cleanup and resource management
* - **Error-handling**: Built-in error propagation and handling
* - **Concurrent**: Support for concurrent operations
*
* ## Composition Patterns
*
* 1. **Piping**: Connect channels where output of one becomes input of another
* 2. **Sequencing**: Use the result of one channel to create another
* 3. **Concatenating**: Combine multiple channels into a single channel
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Simple channel that outputs numbers
* const numberChannel = Channel.succeed(42)
*
* // Transform channel that doubles values
* const doubleChannel = Channel.map(numberChannel, (n) => n * 2)
*
* // Running the channel would output: 84
* ```
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Channel from an array of values
* const arrayChannel = Channel.fromArray([1, 2, 3, 4, 5])
*
* // Transform the channel by mapping over values
* const transformedChannel = Channel.map(arrayChannel, (n) => n * 2)
*
* // This channel will output: 2, 4, 6, 8, 10
* ```
*
* @since 2.0.0
*/
var Channel_exports = /* @__PURE__ */ __exportAll({
	DefaultChunkSize: () => DefaultChunkSize,
	Do: () => Do,
	acquireRelease: () => acquireRelease,
	acquireUseRelease: () => acquireUseRelease,
	bind: () => bind,
	bindTo: () => bindTo,
	buffer: () => buffer,
	bufferArray: () => bufferArray,
	callback: () => callback,
	callbackArray: () => callbackArray,
	catch: () => catch_,
	catchCause: () => catchCause,
	catchCauseFilter: () => catchCauseFilter,
	catchCauseIf: () => catchCauseIf,
	catchFilter: () => catchFilter,
	catchIf: () => catchIf,
	catchReason: () => catchReason,
	catchReasons: () => catchReasons,
	catchTag: () => catchTag,
	combine: () => combine,
	concat: () => concat,
	concatWith: () => concatWith,
	decodeText: () => decodeText,
	die: () => die,
	drain: () => drain,
	embedInput: () => embedInput,
	empty: () => empty,
	encodeText: () => encodeText,
	end: () => end,
	endSync: () => endSync,
	ensuring: () => ensuring,
	fail: () => fail,
	failCause: () => failCause,
	failCauseSync: () => failCauseSync,
	failSync: () => failSync,
	filter: () => filter,
	filterArray: () => filterArray,
	filterArrayEffect: () => filterArrayEffect,
	filterEffect: () => filterEffect,
	filterMap: () => filterMap,
	filterMapArray: () => filterMapArray,
	filterMapArrayEffect: () => filterMapArrayEffect,
	filterMapEffect: () => filterMapEffect,
	flatMap: () => flatMap,
	flatten: () => flatten,
	flattenArray: () => flattenArray,
	flattenTake: () => flattenTake,
	forever: () => forever,
	fromArray: () => fromArray,
	fromAsyncIterable: () => fromAsyncIterable,
	fromAsyncIterableArray: () => fromAsyncIterableArray,
	fromChunk: () => fromChunk,
	fromEffect: () => fromEffect,
	fromEffectDone: () => fromEffectDone,
	fromEffectDrain: () => fromEffectDrain,
	fromEffectTake: () => fromEffectTake,
	fromIterable: () => fromIterable,
	fromIterableArray: () => fromIterableArray,
	fromIterator: () => fromIterator,
	fromIteratorArray: () => fromIteratorArray,
	fromPubSub: () => fromPubSub,
	fromPubSubArray: () => fromPubSubArray,
	fromPubSubTake: () => fromPubSubTake,
	fromPull: () => fromPull,
	fromQueue: () => fromQueue,
	fromQueueArray: () => fromQueueArray,
	fromSchedule: () => fromSchedule,
	fromSubscription: () => fromSubscription,
	fromSubscriptionArray: () => fromSubscriptionArray,
	fromTransform: () => fromTransform,
	fromTransformBracket: () => fromTransformBracket,
	haltWhen: () => haltWhen,
	identity: () => identity,
	ignore: () => ignore,
	ignoreCause: () => ignoreCause,
	interruptWhen: () => interruptWhen,
	isChannel: () => isChannel,
	let: () => let_,
	map: () => map,
	mapAccum: () => mapAccum,
	mapDone: () => mapDone,
	mapDoneEffect: () => mapDoneEffect,
	mapEffect: () => mapEffect,
	mapError: () => mapError,
	mapInput: () => mapInput,
	mapInputError: () => mapInputError,
	merge: () => merge,
	mergeAll: () => mergeAll,
	mergeEffect: () => mergeEffect,
	never: () => never,
	onEnd: () => onEnd,
	onError: () => onError,
	onExit: () => onExit,
	onFirst: () => onFirst,
	onStart: () => onStart,
	orDie: () => orDie,
	orElseIfEmpty: () => orElseIfEmpty,
	pipeTo: () => pipeTo,
	pipeToOrFail: () => pipeToOrFail,
	provide: () => provide,
	provideService: () => provideService,
	provideServiceEffect: () => provideServiceEffect,
	provideServices: () => provideServices,
	repeat: () => repeat,
	retry: () => retry,
	runCollect: () => runCollect,
	runCount: () => runCount,
	runDone: () => runDone,
	runDrain: () => runDrain,
	runFold: () => runFold,
	runFoldEffect: () => runFoldEffect,
	runForEach: () => runForEach,
	runForEachWhile: () => runForEachWhile,
	runHead: () => runHead,
	runIntoPubSub: () => runIntoPubSub,
	runIntoPubSubArray: () => runIntoPubSubArray,
	runIntoQueue: () => runIntoQueue,
	runIntoQueueArray: () => runIntoQueueArray,
	runLast: () => runLast,
	scan: () => scan,
	scanEffect: () => scanEffect,
	schedule: () => schedule,
	scoped: () => scoped,
	servicesWith: () => servicesWith,
	splitLines: () => splitLines,
	succeed: () => succeed,
	suspend: () => suspend,
	switchMap: () => switchMap,
	sync: () => sync,
	tap: () => tap,
	tapCause: () => tapCause,
	tapError: () => tapError,
	toPubSub: () => toPubSub,
	toPubSubArray: () => toPubSubArray,
	toPubSubTake: () => toPubSubTake,
	toPull: () => toPull,
	toPullScoped: () => toPullScoped,
	toQueue: () => toQueue,
	toQueueArray: () => toQueueArray,
	toTransform: () => toTransform,
	transformPull: () => transformPull,
	unwrap: () => unwrap,
	unwrapReason: () => unwrapReason,
	updateService: () => updateService,
	updateServices: () => updateServices,
	withSpan: () => withSpan
});
var TypeId = "~effect/Channel";
/**
* Tests if a value is a `Channel`.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.succeed(42)
* console.log(Channel.isChannel(channel)) // true
* console.log(Channel.isChannel("not a channel")) // false
* ```
*
* @category guards
* @since 3.5.4
*/
var isChannel = (u) => hasProperty(u, TypeId);
var ChannelProto = {
	[TypeId]: {
		_Env: identity$1,
		_InErr: identity$1,
		_InElem: identity$1,
		_OutErr: identity$1,
		_OutElem: identity$1
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Creates a `Channel` from a transformation function that operates on upstream pulls.
*
* @example
* ```ts
* import { Channel, Effect } from "effect"
*
* const channel = Channel.fromTransform((upstream, scope) =>
*   Effect.succeed(upstream)
* )
* ```
*
* @category constructors
* @since 4.0.0
*/
var fromTransform = (transform) => {
	const self = Object.create(ChannelProto);
	self.transform = (upstream, scope) => catchCause$1(transform(upstream, scope), (cause) => succeed$2(failCause$2(cause)));
	return self;
};
/**
* Transforms a Channel by applying a function to its Pull implementation.
*
* @example
* ```ts
* import { Channel, Effect } from "effect"
*
* // Transform a channel by modifying its pull behavior
* const originalChannel = Channel.fromIterable([1, 2, 3])
*
* const transformedChannel = Channel.transformPull(
*   originalChannel,
*   (pull, scope) =>
*     Effect.succeed(
*       Effect.map(pull, (value) => value * 2)
*     )
* )
* // Outputs: 2, 4, 6
* ```
*
* @category constructors
* @since 4.0.0
*/
var transformPull = (self, f) => fromTransform((upstream, scope) => flatMap$1(toTransform(self)(upstream, scope), (pull) => f(pull, scope)));
/**
* Creates a `Channel` from an `Effect` that produces a `Pull`.
*
* @example
* ```ts
* import { Channel, Effect } from "effect"
*
* const channel = Channel.fromPull(
*   Effect.succeed(Effect.succeed(42))
* )
* ```
*
* @category constructors
* @since 4.0.0
*/
var fromPull = (effect) => fromTransform((_, __) => effect);
/**
* Creates a `Channel` from a transformation function that operates on upstream
* pulls, but also provides a forked scope that closes when the resulting
* Channel completes.
*
* @since 4.0.0
* @category constructors
*/
var fromTransformBracket = (f) => fromTransform(fnUntraced(function* (upstream, scope) {
	const closableScope = forkUnsafe(scope);
	const onCause = (cause) => close(closableScope, doneExitFromCause(cause));
	return onError$1(yield* onError$1(f(upstream, scope, closableScope), onCause), onCause);
}));
/**
* Converts a `Channel` back to its underlying transformation function.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.succeed(42)
* const transform = Channel.toTransform(channel)
* // transform can now be used directly
* ```
*
* @category destructors
* @since 4.0.0
*/
var toTransform = (channel) => channel.transform;
/**
* The default chunk size used by channels for batching operations.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* console.log(Channel.DefaultChunkSize) // 4096
* ```
*
* @category constants
* @since 2.0.0
*/
var DefaultChunkSize = 4096;
var asyncQueue = (scope, f, options) => make$1({
	capacity: options?.bufferSize,
	strategy: options?.strategy
}).pipe(tap$1((queue) => addFinalizer(scope, shutdown(queue))), tap$1((queue) => forkIn(provide$1(f(queue), scope), scope)));
/**
* Creates a `Channel` that interacts with a callback function using a queue.
*
* @example
* ```ts
* import { Channel, Effect, Queue } from "effect"
*
* const channel = Channel.callback<number>((queue) =>
*   Effect.gen(function*() {
*     yield* Queue.offer(queue, 1)
*     yield* Queue.offer(queue, 2)
*     yield* Queue.offer(queue, 3)
*   })
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var callback = (f, options) => fromTransform((_, scope) => map$1(asyncQueue(scope, f, options), take));
/**
* Creates a `Channel` that interacts with a callback function using a queue, emitting arrays.
*
* @example
* ```ts
* import { Channel, Effect, Queue } from "effect"
*
* const channel = Channel.callbackArray<number>(Effect.fn(function*(queue) {
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
* }))
* // Emits arrays of numbers instead of individual numbers
* ```
*
* @category constructors
* @since 4.0.0
*/
var callbackArray = (f, options) => fromTransform((_, scope) => map$1(asyncQueue(scope, f, options), takeAll));
/**
* Creates a `Channel` that lazily evaluates to another channel.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.suspend(() => Channel.succeed(42))
* // The inner channel is not created until the suspended channel is run
* ```
*
* @category constructors
* @since 2.0.0
*/
var suspend = (evaluate) => fromTransform((upstream, scope) => suspend$1(() => toTransform(evaluate())(upstream, scope)));
/**
* Creates a `Channel` with resource management using acquire-use-release pattern.
*
* @example
* ```ts
* import { Channel, Effect } from "effect"
*
* const channel = Channel.acquireUseRelease(
*   Effect.succeed("resource"),
*   (resource) => Channel.succeed(resource.toUpperCase()),
*   (resource, exit) => Effect.log(`Released: ${resource}`)
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var acquireUseRelease = (acquire, use, release) => fromTransformBracket(fnUntraced(function* (upstream, scope, forkedScope) {
	let option = none();
	yield* addFinalizerExit(forkedScope, (exit) => isSome(option) ? release(option.value, exit) : void_);
	const value = yield* uninterruptible(acquire);
	option = some(value);
	return yield* toTransform(use(value))(upstream, scope);
}));
/**
* Creates a `Channel` with resource management using acquire-release pattern.
*
* @example
* ```ts
* import { Channel, Effect } from "effect"
*
* const channel = Channel.acquireRelease(
*   Effect.succeed("resource"),
*   (resource, exit) => Effect.log(`Released: ${resource}`)
* )
* ```
*
* @category constructors
* @since 2.0.0
*/
var acquireRelease = /*#__PURE__*/ dual(2, (self, release) => unwrap(map$1(acquireRelease$1(self, release), succeed)));
/**
* Creates a `Channel` from an iterator.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const numbers = [1, 2, 3, 4, 5]
* const channel = Channel.fromIterator(() => numbers[Symbol.iterator]())
* // Emits: 1, 2, 3, 4, 5
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromIterator = (iterator) => fromPull(sync$1(() => {
	const iter = iterator();
	return suspend$1(() => {
		const state = iter.next();
		return state.done ? done(state.value) : succeed$2(state.value);
	});
}));
/**
* Creates a `Channel` that emits all elements from an array.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.fromArray([1, 2, 3, 4, 5])
* // Emits: 1, 2, 3, 4, 5
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromArray = (array) => fromPull(sync$1(() => {
	let index = 0;
	return suspend$1(() => index >= array.length ? done() : succeed$2(array[index++]));
}));
/**
* Creates a `Channel` that emits all elements from a chunk.
*
* @example
* ```ts
* import { Channel, Chunk } from "effect"
*
* const chunk = Chunk.make(1, 2, 3)
* const channel = Channel.fromChunk(chunk)
* // Emits: 1, 2, 3
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromChunk = (chunk) => fromArray(toReadonlyArray(chunk));
/**
* Creates a `Channel` from an iterator that emits arrays of elements.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel from a simple iterator
* const numberIterator = (): Iterator<number, string> => {
*   let count = 0
*   return {
*     next: () => {
*       if (count < 3) {
*         return { value: count++, done: false }
*       }
*       return { value: "finished", done: true }
*     }
*   }
* }
*
* const channel = Channel.fromIteratorArray(() => numberIterator(), 2)
* // This will emit arrays: [0, 1], [2], then complete with "finished"
* ```
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create channel from a generator function
* function* fibonacci(): Generator<number, void, unknown> {
*   let a = 0, b = 1
*   for (let i = 0; i < 5; i++) {
*     yield a
*     ;[a, b] = [b, a + b]
*   }
* }
*
* const fibChannel = Channel.fromIteratorArray(() => fibonacci(), 3)
* // Emits: [0, 1, 1], [2, 3], then completes
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromIteratorArray = (iterator, chunkSize = DefaultChunkSize) => fromPull(sync$1(() => {
	const iter = iterator();
	let done$2 = none();
	return suspend$1(() => {
		if (done$2._tag === "Some") return done(done$2.value);
		const buffer = [];
		while (buffer.length < chunkSize) {
			const state = iter.next();
			if (state.done) {
				if (buffer.length === 0) return done(state.value);
				done$2 = some(state.value);
				break;
			}
			buffer.push(state.value);
		}
		return succeed$2(buffer);
	});
}));
/**
* Creates a `Channel` that emits all elements from an iterable.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const set = new Set([1, 2, 3])
* const channel = Channel.fromIterable(set)
* // Emits: 1, 2, 3
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromIterable = (iterable) => fromIterator(() => iterable[Symbol.iterator]());
/**
* Creates a `Channel` that emits arrays of elements from an iterable.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const numbers = [1, 2, 3, 4, 5]
* const channel = Channel.fromIterableArray(numbers)
* // Emits arrays like: [1, 2, 3, 4], [5] (based on chunk size)
* ```
*
* @category constructors
* @since 2.0.0
*/
var fromIterableArray = (iterable, chunkSize = DefaultChunkSize) => fromIteratorArray(() => iterable[Symbol.iterator](), chunkSize);
/**
* Creates a `Channel` that emits a single value and then ends.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.succeed(42)
* // Emits: 42
* ```
*
* @category constructors
* @since 2.0.0
*/
var succeed = (value) => fromEffect(succeed$2(value));
/**
* Creates a `Channel` that immediately ends with the specified value.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.end("done")
* // Ends immediately with "done", emits nothing
* ```
*
* @category constructors
* @since 4.0.0
*/
var end = (value) => fromPull(succeed$2(done(value)));
/**
* Creates a `Channel` that immediately ends with the lazily evaluated value.
*
* @category constructors
* @since 4.0.0
*/
var endSync = (evaluate) => fromPull(sync$1(() => done(evaluate())));
/**
* Creates a `Channel` that emits a single value computed by a lazy evaluation.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* const channel = Channel.sync(() => Math.random())
* // Emits a random number computed when the channel runs
* ```
*
* @category constructors
* @since 2.0.0
*/
var sync = (evaluate) => fromEffect(sync$1(evaluate));
/**
* Represents an Channel that emits no elements
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create an empty channel
* const emptyChannel = Channel.empty
*
* // Use empty channel in composition
* const combined = Channel.concatWith(emptyChannel, () => Channel.succeed(42))
* // Will immediately provide the second channel's output
*
* // Empty channel can be used as a no-op in conditional logic
* const conditionalChannel = (shouldEmit: boolean) =>
*   shouldEmit ? Channel.succeed("data") : Channel.empty
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty = /*#__PURE__*/ fromPull(/*#__PURE__*/ succeed$2(/*#__PURE__*/ done()));
/**
* Represents an Channel that never completes
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel that never completes
* const neverChannel = Channel.never
*
* // Use in conditional logic
* const withFallback = Channel.concatWith(
*   neverChannel,
*   () => Channel.succeed("fallback")
* )
*
* // Never channel is useful for testing or as a placeholder
* const conditionalChannel = (shouldComplete: boolean) =>
*   shouldComplete ? Channel.succeed("done") : Channel.never
* ```
*
* @since 2.0.0
* @category constructors
*/
var never = /*#__PURE__*/ fromPull(/*#__PURE__*/ succeed$2(never$1));
/**
* Constructs a channel that fails immediately with the specified error.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel that fails with a string error
* const failedChannel = Channel.fail("Something went wrong")
*
* // Create a channel that fails with a custom error
* class CustomError extends Error {
*   constructor(message: string) {
*     super(message)
*     this.name = "CustomError"
*   }
* }
* const customErrorChannel = Channel.fail(new CustomError("Custom error"))
*
* // Use in error handling by piping to another channel
* const channelWithFallback = Channel.concatWith(
*   failedChannel,
*   () => Channel.succeed("fallback value")
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var fail = (error) => fromPull(succeed$2(fail$3(error)));
/**
* Constructs a channel that fails immediately with the specified lazily
* evaluated error.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel that fails with a lazily computed error
* const failedChannel = Channel.failSync(() => {
*   console.log("Computing error...")
*   return new Error("Computed at runtime")
* })
*
* // The error computation is deferred until the channel runs
* const conditionalError = Channel.failSync(() =>
*   Math.random() > 0.5 ? "Error A" : "Error B"
* )
*
* // Use with expensive error construction
* const expensiveError = Channel.failSync(() => {
*   const timestamp = Date.now()
*   return new Error(`Failed at: ${timestamp}`)
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var failSync = (evaluate) => fromPull(failSync$1(evaluate));
/**
* Constructs a channel that fails immediately with the specified `Cause`.
*
* @example
* ```ts
* import { Cause, Channel } from "effect"
*
* // Create a channel that fails with a simple cause
* const simpleCause = Cause.fail("Simple error")
* const failedChannel = Channel.failCause(simpleCause)
*
* // Create a channel with a die cause
* const dieCause = Cause.die(new Error("System error"))
* const dieFailure = Channel.failCause(dieCause)
*
* // Create a channel with a simple fail cause
* const failCause = Cause.fail("Simple error")
* const simpleFail = Channel.failCause(failCause)
* ```
*
* @since 2.0.0
* @category constructors
*/
var failCause = (cause) => fromPull(failCause$2(cause));
/**
* Constructs a channel that fails immediately with the specified lazily
* evaluated `Cause`.
*
* @example
* ```ts
* import { Cause, Channel } from "effect"
*
* // Create a channel that fails with a lazily computed cause
* const failedChannel = Channel.failCauseSync(() => {
*   const errorType = Math.random() > 0.5 ? "A" : "B"
*   return Cause.fail(`Runtime error ${errorType}`)
* })
*
* // Create a channel with die cause computation
* const dieCauseChannel = Channel.failCauseSync(() => {
*   const timestamp = Date.now()
*   return Cause.die(`Error at ${timestamp}`)
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var failCauseSync = (evaluate) => fromPull(failCauseSync$1(evaluate));
/**
* Constructs a channel that fails immediately with the specified defect.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel that dies with a string defect
* const diedChannel = Channel.die("Unrecoverable error")
*
* // Create a channel that dies with an Error object
* const errorDefect = Channel.die(new Error("System failure"))
*
* // Die with any value as a defect
* const objectDefect = Channel.die({
*   code: "SYSTEM_FAILURE",
*   details: "Critical system component failed"
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var die = (defect) => failCause(die$1(defect));
/**
* Use an effect to write a single value to the channel.
*
* @example
* ```ts
* import { Channel, Data, Effect } from "effect"
*
* class DatabaseError extends Data.TaggedError("DatabaseError")<{
*   readonly message: string
* }> {}
*
* // Create a channel from a successful effect
* const successChannel = Channel.fromEffect(
*   Effect.succeed("Hello from effect!")
* )
*
* // Create a channel from an effect that might fail
* const fetchUserChannel = Channel.fromEffect(
*   Effect.tryPromise({
*     try: () => fetch("/api/user").then((res) => res.json()),
*     catch: (error) => new DatabaseError({ message: String(error) })
*   })
* )
*
* // Channel from effect with async computation
* const asyncChannel = Channel.fromEffect(
*   Effect.gen(function*() {
*     yield* Effect.sleep("100 millis")
*     return "Async result"
*   })
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromEffect = (effect) => fromPull(sync$1(() => {
	let done$1 = false;
	return suspend$1(() => {
		if (done$1) return done();
		done$1 = true;
		return effect;
	});
}));
/**
* @since 4.0.0
* @category constructors
*/
var fromEffectDone = (effect) => fromPull(succeed$2(flatMap$1(effect, done)));
/**
* Use an effect and discard its result.
*
* @since 4.0.0
* @category constructors
*/
var fromEffectDrain = (effect) => fromPull(flatMap$1(effect, () => done()));
/**
* @since 4.0.0
* @category constructors
*/
var fromEffectTake = (effect) => fromPull(succeed$2(flatMap$1(effect, toPull$1)));
/**
* Create a channel from a queue
*
* @example
* ```ts
* import { Channel, Data, Effect, Queue } from "effect"
*
* class QueueError extends Data.TaggedError("QueueError")<{
*   readonly reason: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a bounded queue
*   const queue = yield* Queue.bounded<string, QueueError>(10)
*
*   // Add some items to the queue
*   yield* Queue.offer(queue, "item1")
*   yield* Queue.offer(queue, "item2")
*   yield* Queue.offer(queue, "item3")
*
*   // Create a channel from the queue
*   const channel = Channel.fromQueue(queue)
*
*   // The channel will read items from the queue one by one
*   return channel
* })
*
* // Sliding queue example
* const slidingProgram = Effect.gen(function*() {
*   const slidingQueue = yield* Queue.sliding<number, QueueError>(5)
*   yield* Queue.offerAll(slidingQueue, [1, 2, 3, 4, 5, 6])
*   return Channel.fromQueue(slidingQueue)
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromQueue = (queue) => fromPull(succeed$2(take(queue)));
/**
* Create a channel from a queue that emits arrays of elements
*
* @example
* ```ts
* import { Channel, Data, Effect, Queue } from "effect"
*
* class ProcessingError extends Data.TaggedError("ProcessingError")<{
*   readonly stage: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a queue for batch processing
*   const queue = yield* Queue.bounded<number, ProcessingError>(100)
*
*   // Fill queue with data
*   yield* Queue.offerAll(queue, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
*
*   // Create a channel that reads arrays from the queue
*   const arrayChannel = Channel.fromQueueArray(queue)
*
*   // This will emit non-empty arrays of elements instead of individual items
*   // Useful for batch processing scenarios
*   return arrayChannel
* })
*
* // High-throughput processing example
* const batchProcessor = Effect.gen(function*() {
*   const dataQueue = yield* Queue.dropping<string, ProcessingError>(1000)
*   const batchChannel = Channel.fromQueueArray(dataQueue)
*
*   // Process data in batches for better performance
*   return Channel.map(
*     batchChannel,
*     (batch) => batch.map((item) => item.toUpperCase())
*   )
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromQueueArray = (queue) => fromPull(succeed$2(takeAll(queue)));
/**
* @since 2.0.0
* @category Constructors
*/
var identity = () => fromTransform((upstream, _scope) => succeed$2(upstream));
/**
* Create a channel from a PubSub subscription
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class SubscriptionError extends Data.TaggedError("SubscriptionError")<{
*   readonly reason: string
* }> {}
*
* const program = Effect.gen(function*() {
*   // Create a PubSub
*   const pubsub = yield* PubSub.bounded<string>(32)
*
*   // Create a subscription
*   const subscription = yield* PubSub.subscribe(pubsub)
*
*   // Publish some messages
*   yield* PubSub.publish(pubsub, "Hello")
*   yield* PubSub.publish(pubsub, "World")
*   yield* PubSub.publish(pubsub, "from")
*   yield* PubSub.publish(pubsub, "PubSub")
*
*   // Create a channel from the subscription
*   const channel = Channel.fromSubscription(subscription)
*
*   // The channel will receive all published messages
*   return channel
* })
*
* // Real-time notifications example
* const notificationChannel = Effect.gen(function*() {
*   const eventBus = yield* PubSub.unbounded<{ type: string; payload: any }>()
*   const userSubscription = yield* PubSub.subscribe(eventBus)
*
*   return Channel.fromSubscription(userSubscription)
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromSubscription = (subscription) => fromPull(succeed$2(onInterrupt(take$1(subscription), () => done())));
/**
* Create a channel from a PubSub subscription that outputs arrays of values.
*
* This constructor creates a channel that reads from a PubSub subscription and outputs
* arrays of values in chunks. It's useful when you want to process multiple values at once
* for better performance.
*
* @param subscription - The PubSub subscription to read from
* @param chunkSize - The maximum number of elements to read in each chunk (default: 4096)
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class StreamError extends Data.TaggedError("StreamError")<{
*   readonly message: string
* }> {}
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<number>(16)
*   const subscription = yield* PubSub.subscribe(pubsub)
*
*   // Create a channel that reads arrays of values
*   const channel = Channel.fromSubscriptionArray(subscription)
*
*   // Publish some values
*   yield* PubSub.publish(pubsub, 1)
*   yield* PubSub.publish(pubsub, 2)
*   yield* PubSub.publish(pubsub, 3)
*   yield* PubSub.publish(pubsub, 4)
*
*   // The channel will output arrays like [1, 2, 3] and [4]
*   return channel
* })
* ```
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class BatchProcessingError extends Data.TaggedError("BatchProcessingError")<{
*   readonly reason: string
* }> {}
*
* const batchProcessor = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<string>(32)
*   const subscription = yield* PubSub.subscribe(pubsub)
*
*   // Create a channel that processes items in batches
*   const batchChannel = Channel.fromSubscriptionArray(subscription)
*
*   // Transform to process each batch
*   const processedChannel = Channel.map(batchChannel, (batch) => {
*     console.log(`Processing batch of ${batch.length} items:`, batch)
*     return batch.map((item) => item.toUpperCase())
*   })
*
*   return processedChannel
* })
* ```
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class MetricsError extends Data.TaggedError("MetricsError")<{
*   readonly cause: string
* }> {}
*
* const metricsAggregator = Effect.gen(function*() {
*   const metricsPubSub = yield* PubSub.bounded<
*     { timestamp: number; value: number }
*   >(100)
*   const subscription = yield* PubSub.subscribe(metricsPubSub)
*
*   // Create a channel that collects metrics in chunks
*   const metricsChannel = Channel.fromSubscriptionArray(subscription)
*
*   // Transform to calculate aggregate statistics
*   const aggregatedChannel = Channel.map(metricsChannel, (metrics) => {
*     const values = metrics.map((m) => m.value)
*     const sum = values.reduce((a, b) => a + b, 0)
*     const avg = sum / values.length
*     const min = Math.min(...values)
*     const max = Math.max(...values)
*
*     return {
*       count: values.length,
*       sum,
*       average: avg,
*       min,
*       max,
*       timestamp: Date.now()
*     }
*   })
*
*   return aggregatedChannel
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromSubscriptionArray = (subscription) => fromPull(succeed$2(onInterrupt(takeAll$1(subscription), () => done())));
/**
* Create a channel from a PubSub that outputs individual values.
*
* This constructor creates a channel that reads from a PubSub by automatically
* subscribing to it. The channel outputs individual values as they are published
* to the PubSub, making it ideal for real-time streaming scenarios.
*
* @param pubsub - The PubSub to read from
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class StreamError extends Data.TaggedError("StreamError")<{
*   readonly message: string
* }> {}
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<number>(16)
*
*   // Create a channel that reads individual values
*   const channel = Channel.fromPubSub(pubsub)
*
*   // Publish some values
*   yield* PubSub.publish(pubsub, 1)
*   yield* PubSub.publish(pubsub, 2)
*   yield* PubSub.publish(pubsub, 3)
*
*   // The channel will output: 1, 2, 3 (individual values)
*   return channel
* })
* ```
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class NotificationError extends Data.TaggedError("NotificationError")<{
*   readonly reason: string
* }> {}
*
* const notificationService = Effect.gen(function*() {
*   const notificationPubSub = yield* PubSub.bounded<string>(50)
*
*   // Create a channel for real-time notifications
*   const notificationChannel = Channel.fromPubSub(notificationPubSub)
*
*   // Transform notifications to add timestamps
*   const timestampedChannel = Channel.map(notificationChannel, (message) => ({
*     message,
*     timestamp: new Date().toISOString(),
*     id: Math.random().toString(36).substr(2, 9)
*   }))
*
*   return timestampedChannel
* })
* ```
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class EventProcessingError extends Data.TaggedError("EventProcessingError")<{
*   readonly eventType: string
*   readonly cause: string
* }> {}
*
* interface DomainEvent {
*   readonly type: string
*   readonly payload: unknown
*   readonly timestamp: number
* }
*
* const eventProcessor = Effect.gen(function*() {
*   const eventPubSub = yield* PubSub.bounded<DomainEvent>(100)
*
*   // Create a channel for processing domain events
*   const eventChannel = Channel.fromPubSub(eventPubSub)
*
*   // Filter and transform events
*   const processedChannel = Channel.map(eventChannel, (event) => {
*     if (event.type === "user.created") {
*       return {
*         ...event,
*         processed: true,
*         processedAt: Date.now()
*       }
*     }
*     return event
*   })
*
*   return processedChannel
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromPubSub = (pubsub) => unwrap(map$1(subscribe(pubsub), fromSubscription));
/**
* Create a channel from a PubSub that outputs arrays of values.
*
* This constructor creates a channel that reads from a PubSub by automatically
* subscribing to it and collecting values into arrays. The channel outputs
* arrays of values in chunks, making it ideal for batch processing scenarios.
*
* @param pubsub - The PubSub to read from
* @param chunkSize - The maximum number of elements to collect in each array (default: 4096)
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class BatchError extends Data.TaggedError("BatchError")<{
*   readonly message: string
* }> {}
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.bounded<number>(16)
*
*   // Create a channel that reads arrays of values
*   const channel = Channel.fromPubSubArray(pubsub)
*
*   // Publish some values
*   yield* PubSub.publish(pubsub, 1)
*   yield* PubSub.publish(pubsub, 2)
*   yield* PubSub.publish(pubsub, 3)
*   yield* PubSub.publish(pubsub, 4)
*
*   // The channel will output arrays like [1, 2, 3] and [4]
*   return channel
* })
* ```
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class OrderProcessingError extends Data.TaggedError("OrderProcessingError")<{
*   readonly orderId: string
*   readonly reason: string
* }> {}
*
* interface Order {
*   readonly id: string
*   readonly customerId: string
*   readonly items: ReadonlyArray<string>
*   readonly total: number
* }
*
* const orderBatchProcessor = Effect.gen(function*() {
*   const orderPubSub = yield* PubSub.bounded<Order>(100)
*
*   // Create a channel that processes orders in batches
*   const orderChannel = Channel.fromPubSubArray(orderPubSub)
*
*   // Transform to process each batch of orders
*   const processedChannel = Channel.map(orderChannel, (orderBatch) => {
*     const totalRevenue = orderBatch.reduce((sum, order) => sum + order.total, 0)
*     const customerCount = new Set(orderBatch.map((order) =>
*       order.customerId
*     )).size
*
*     return {
*       batchSize: orderBatch.length,
*       totalRevenue,
*       uniqueCustomers: customerCount,
*       processedAt: Date.now(),
*       orders: orderBatch
*     }
*   })
*
*   return processedChannel
* })
* ```
*
* @example
* ```ts
* import { Channel, Data, Effect, PubSub } from "effect"
*
* class LogProcessingError extends Data.TaggedError("LogProcessingError")<{
*   readonly batchId: string
*   readonly cause: string
* }> {}
*
* interface LogEntry {
*   readonly timestamp: number
*   readonly level: "info" | "warn" | "error"
*   readonly message: string
*   readonly source: string
* }
*
* const logAggregator = Effect.gen(function*() {
*   const logPubSub = yield* PubSub.bounded<LogEntry>(500)
*
*   // Create a channel that collects logs in batches
*   const logChannel = Channel.fromPubSubArray(logPubSub)
*
*   // Transform to analyze log batches
*   const analysisChannel = Channel.map(logChannel, (logBatch) => {
*     const errorCount = logBatch.filter((log) => log.level === "error").length
*     const warnCount = logBatch.filter((log) => log.level === "warn").length
*     const infoCount = logBatch.filter((log) => log.level === "info").length
*
*     const timeRange = {
*       start: Math.min(...logBatch.map((log) => log.timestamp)),
*       end: Math.max(...logBatch.map((log) => log.timestamp))
*     }
*
*     return {
*       batchId: Math.random().toString(36).substr(2, 9),
*       totalEntries: logBatch.length,
*       errorCount,
*       warnCount,
*       infoCount,
*       timeRange,
*       sources: [...new Set(logBatch.map((log) => log.source))]
*     }
*   })
*
*   return analysisChannel
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromPubSubArray = (pubsub) => unwrap(map$1(subscribe(pubsub), fromSubscriptionArray));
/**
* @since 4.0.0
* @category constructors
*/
var fromPubSubTake = (pubsub) => unwrap(map$1(subscribe(pubsub), (sub) => fromEffectTake(take$1(sub))));
/**
* Creates a Channel from a Schedule.
*
* @since 4.0.0
* @category constructors
*/
var fromSchedule = (schedule) => fromPull(map$1(toStepWithSleep(schedule), (step) => step(void 0)));
/**
* Creates a Channel from a AsyncIterable.
*
* @since 4.0.0
* @category constructors
*/
var fromAsyncIterable = (iterable, onError) => fromTransform(fnUntraced(function* (_, scope) {
	const iter = iterable[Symbol.asyncIterator]();
	if (iter.return) yield* addFinalizer(scope, promise(() => iter.return()));
	return flatMap$1(tryPromise({
		try: () => iter.next(),
		catch: onError
	}), (result) => result.done ? done(result.value) : succeed$2(result.value));
}));
/**
* Creates a Channel from a AsyncIterable that emits arrays of elements.
*
* @since 4.0.0
* @category constructors
*/
var fromAsyncIterableArray = (iterable, onError) => map(fromAsyncIterable(iterable, onError), of);
/**
* Maps the output of this channel using the specified function.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class TransformError extends Data.TaggedError("TransformError")<{
*   readonly reason: string
* }> {}
*
* // Basic mapping of channel values
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5])
* const doubledChannel = Channel.map(numbersChannel, (n) => n * 2)
* // Outputs: 2, 4, 6, 8, 10
*
* // Transform string data
* const wordsChannel = Channel.fromIterable(["hello", "world", "effect"])
* const upperCaseChannel = Channel.map(wordsChannel, (word) => word.toUpperCase())
* // Outputs: "HELLO", "WORLD", "EFFECT"
*
* // Complex object transformation
* type User = { id: number; name: string }
* type UserDisplay = { displayName: string; isActive: boolean }
*
* const usersChannel = Channel.fromIterable([
*   { id: 1, name: "Alice" },
*   { id: 2, name: "Bob" }
* ])
* const displayChannel = Channel.map(usersChannel, (user): UserDisplay => ({
*   displayName: `User: ${user.name}`,
*   isActive: true
* }))
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var map = /*#__PURE__*/ dual(2, (self, f) => transformPull(self, (pull) => sync$1(() => {
	let i = 0;
	return map$1(pull, (o) => f(o, i++));
})));
/**
* Maps the done value of this channel using the specified function.
*
* @since 2.0.0
* @category Sequencing
*/
var mapDone = /*#__PURE__*/ dual(2, (self, f) => mapDoneEffect(self, (o) => succeed$2(f(o))));
/**
* Maps the done value of this channel using the specified effectful function.
*
* @since 2.0.0
* @category Sequencing
*/
var mapDoneEffect = /*#__PURE__*/ dual(2, (self, f) => transformPull(self, (pull) => succeed$2(catchDone(pull, (done$3) => flatMap$1(f(done$3), done)))));
var concurrencyIsSequential = (concurrency) => concurrency === void 0 || concurrency !== "unbounded" && concurrency <= 1;
/**
* Returns a new channel, which sequentially combines this channel, together
* with the provided factory function, which creates a second channel based on
* the output values of this channel. The result is a channel that will first
* perform the functions of this channel, before performing the functions of
* the created channel (including yielding its terminal value).
*
* @example
* ```ts
* import { Channel, Data, Effect } from "effect"
*
* class NetworkError extends Data.TaggedError("NetworkError")<{
*   readonly url: string
* }> {}
*
* // Transform values using effectful operations
* const urlsChannel = Channel.fromIterable([
*   "/api/users/1",
*   "/api/users/2",
*   "/api/users/3"
* ])
*
* const fetchDataChannel = Channel.mapEffect(
*   urlsChannel,
*   (url) =>
*     Effect.tryPromise({
*       try: () => fetch(url).then((res) => res.json()),
*       catch: () => new NetworkError({ url })
*     })
* )
*
* // Concurrent processing with options
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5])
* const processedChannel = Channel.mapEffect(
*   numbersChannel,
*   (n) =>
*     Effect.gen(function*() {
*       yield* Effect.sleep("100 millis") // Simulate async work
*       return n * n
*     }),
*   { concurrency: 3, unordered: true }
* )
* ```
*
* @since 2.0.0
* @category sequencing
*/
var mapEffect = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, f, options) => concurrencyIsSequential(options?.concurrency) ? mapEffectSequential(self, f) : mapEffectConcurrent(self, f, options));
var mapEffectSequential = (self, f) => fromTransform((upstream, scope) => {
	let i = 0;
	return map$1(toTransform(self)(upstream, scope), flatMap$1((o) => f(o, i++)));
});
var mapEffectConcurrent = (self, f, options) => fromTransformBracket(fnUntraced(function* (upstream, scope, forkedScope) {
	let i = 0;
	const pull = yield* toTransform(self)(upstream, scope);
	const concurrencyN = options.concurrency === "unbounded" ? Number.MAX_SAFE_INTEGER : options.concurrency;
	const queue = yield* bounded(0);
	yield* addFinalizer(forkedScope, shutdown(queue));
	const runFork = runForkWith(yield* services());
	const trackFiber = runIn(forkedScope);
	if (options.unordered) {
		const semaphore = makeUnsafe(concurrencyN);
		const release = constant(semaphore.release(1));
		const handle = matchCauseEffect$1({
			onFailure: (cause) => flatMap$1(failCause$1(queue, cause), release),
			onSuccess: (value) => flatMap$1(offer(queue, value), release)
		});
		yield* semaphore.take(1).pipe(flatMap$1(() => pull), flatMap$1((value) => {
			trackFiber(runFork(handle(f(value, i++))));
			return void_;
		}), forever$1({ disableYield: true }), catchCause$1((cause) => semaphore.withPermits(concurrencyN - 1)(failCause$1(queue, cause))), forkIn(forkedScope));
	} else {
		const effects = yield* bounded(concurrencyN - 2);
		yield* addFinalizer(forkedScope, shutdown(queue));
		yield* take(effects).pipe(flatten$1, flatMap$1((value) => offer(queue, value)), forever$1({ disableYield: true }), catchCause$1((cause) => failCause$1(queue, cause)), forkIn(forkedScope));
		let errorCause;
		const onExit = (exit) => {
			if (exit._tag === "Success") return;
			errorCause = exit.cause;
			failCauseUnsafe(queue, exit.cause);
		};
		yield* pull.pipe(flatMap$1((value) => {
			if (errorCause) return failCause$2(errorCause);
			const fiber = runFork(f(value, i++));
			trackFiber(fiber);
			fiber.addObserver(onExit);
			return offer(effects, join(fiber));
		}), forever$1({ disableYield: true }), catchCause$1((cause) => offer(effects, failCause$3(cause)).pipe(andThen(failCause$1(effects, cause)))), forkIn(forkedScope));
	}
	return take(queue);
}));
/**
* Returns a new channel which is the same as this one but applies the given
* function to the input channel’s input elements.
*
* @since 2.0.0
* @category sequencing
*/
var mapInput = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => toTransform(self)(flatMap$1(upstream, (el) => f(el)), scope)));
/**
* Returns a new channel which is the same as this one but applies the given
* function to the input errors.
*
* @since 2.0.0
* @category sequencing
*/
var mapInputError = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => toTransform(self)(catch_$1(upstream, (err) => {
	if (isDone(err)) return fail$3(err);
	return flatMap$1(f(err), fail$3);
}), scope)));
/**
* Applies a side effect function to each output element of the channel,
* returning a new channel that emits the same elements.
*
* The `tap` function allows you to perform side effects (like logging or
* debugging) on each element emitted by a channel without modifying the
* elements themselves.
*
* @example
* ```ts
* import { Channel, Console, Data } from "effect"
*
* class LogError extends Data.TaggedError("LogError")<{
*   readonly message: string
* }> {}
*
* // Create a channel that outputs numbers
* const numberChannel = Channel.fromIterable([1, 2, 3])
*
* // Tap into each output element to perform side effects
* const tappedChannel = Channel.tap(
*   numberChannel,
*   (n) => Console.log(`Processing number: ${n}`)
* )
*
* // The channel still outputs the same elements but logs each one
* // Outputs: 1, 2, 3 (while logging each)
* ```
*
* @since 4.0.0
* @category sequencing
*/
var tap = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, f, options) => mapEffect(self, (a) => as$1(f(a), a), options));
/**
* Returns a new channel, which sequentially combines this channel, together
* with the provided factory function, which creates a second channel based on
* the output values of this channel. The result is a channel that will first
* perform the functions of this channel, before performing the functions of
* the created channel (including yielding its terminal value).
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class ProcessError extends Data.TaggedError("ProcessError")<{
*   readonly cause: string
* }> {}
*
* // Create a channel that outputs numbers
* const numberChannel = Channel.fromIterable([1, 2, 3])
*
* // FlatMap each number to create new channels
* const flatMappedChannel = Channel.flatMap(
*   numberChannel,
*   (n) =>
*     Channel.fromIterable(Array.from({ length: n }, (_, i) => `item-${n}-${i}`))
* )
*
* // Flattens nested channels into a single stream
* // Outputs: "item-1-0", "item-2-0", "item-2-1", "item-3-0", "item-3-1", "item-3-2"
* ```
*
* @since 2.0.0
* @category sequencing
*/
var flatMap = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, f, options) => concurrencyIsSequential(options?.concurrency) ? flatMapSequential(self, f) : flatMapConcurrent(self, f, options));
var flatMapSequential = (self, f) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => {
	let childPull;
	let childScope;
	const makePull = flatMap$1(pull, (value) => {
		childScope ??= forkUnsafe(scope);
		return flatMapEager(toTransform(f(value))(upstream, childScope), (pull) => {
			childPull = catchHalt(pull);
			return childPull;
		});
	});
	const catchHalt = catchDone((_) => {
		childPull = void 0;
		if (childScope.state._tag === "Open" && childScope.state.finalizers.size === 1) return makePull;
		const close$1 = close(childScope, void_$2);
		childScope = void 0;
		return flatMap$1(close$1, () => makePull);
	});
	return suspend$1(() => childPull ?? makePull);
}));
var flatMapConcurrent = (self, f, options) => self.pipe(map(f), mergeAll(options));
/**
* Concatenates this channel with another channel created from the terminal value
* of this channel. The new channel is created using the provided function.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class ConcatError extends Data.TaggedError("ConcatError")<{
*   readonly reason: string
* }> {}
*
* // Create a channel that outputs numbers and terminates with sum
* const numberChannel = Channel.fromIterable([1, 2, 3]).pipe(
*   Channel.concatWith((sum: void) => Channel.succeed(`Completed processing`))
* )
*
* // Concatenates additional channel based on completion value
* // Outputs: 1, 2, 3, then "Completed processing"
* ```
*
* @since 2.0.0
* @category sequencing
*/
var concatWith = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => sync$1(() => {
	let currentPull;
	const forkedScope = forkUnsafe(scope);
	const makePull = flatMap$1(toTransform(self)(upstream, forkedScope), (pull) => {
		currentPull = catchDone(pull, (leftover) => {
			return close(forkedScope, void_$2).pipe(flatMap$1(() => toTransform(f(leftover))(upstream, scope)), flatMap$1((pull) => {
				currentPull = pull;
				return pull;
			}));
		});
		return currentPull;
	});
	return suspend$1(() => currentPull ?? makePull);
})));
/**
* Concatenates this channel with another channel, so that the second channel
* starts emitting values after the first channel has completed.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class ConcatError extends Data.TaggedError("ConcatError")<{
*   readonly reason: string
* }> {}
*
* // Create two channels
* const firstChannel = Channel.fromIterable([1, 2, 3])
* const secondChannel = Channel.fromIterable(["a", "b", "c"])
*
* // Concatenate them
* const concatenatedChannel = Channel.concat(firstChannel, secondChannel)
*
* // Outputs: 1, 2, 3, "a", "b", "c"
* ```
*
* @since 2.0.0
* @category sequencing
*/
var concat = /*#__PURE__*/ dual(2, (self, that) => concatWith(self, (_) => that));
/**
* Combines the elements from this channel and the specified channel by
* repeatedly applying the function `f` to extract an element using both sides
* and conceptually "offer" it to the destination channel. `f` can maintain
* some internal state to control the combining process, with the initial
* state being specified by `s`.
*
* @since 4.0.0
* @category sequencing
*/
var combine = /*#__PURE__*/ dual(4, (self, that, s, f) => fromTransform(fnUntraced(function* (upstream, scope) {
	const leftPull = yield* toTransform(self)(upstream, scope);
	const rightPull = yield* toTransform(that)(upstream, scope);
	let state = s();
	return suspend$1(() => {
		return map$1(f(state, leftPull, rightPull), ([a, s1]) => {
			state = s1;
			return a;
		});
	});
})));
/**
* @since 2.0.0
* @category sequencing
*/
var orElseIfEmpty = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => sync$1(() => {
	let currentPull;
	const forkedScope = forkUnsafe(scope);
	const makePull = flatMap$1(toTransform(self)(upstream, forkedScope), (pull) => {
		const next = pull.pipe(tap$1(() => {
			currentPull = pull;
			return void_;
		}), catchDone((leftover) => close(forkedScope, succeed$3(leftover)).pipe(andThen(toTransform(f(leftover))(upstream, scope)), flatMap$1((pull) => {
			currentPull = pull;
			return pull;
		}))));
		currentPull = next;
		return next;
	});
	return suspend$1(() => currentPull ?? makePull);
})));
/**
* Flatten a channel of channels.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class FlattenError extends Data.TaggedError("FlattenError")<{
*   readonly cause: string
* }> {}
*
* // Create a channel that outputs channels
* const nestedChannels = Channel.fromIterable([
*   Channel.fromIterable([1, 2]),
*   Channel.fromIterable([3, 4]),
*   Channel.fromIterable([5, 6])
* ])
*
* // Flatten the nested channels
* const flattenedChannel = Channel.flatten(nestedChannels)
*
* // Outputs: 1, 2, 3, 4, 5, 6
* ```
*
* @since 2.0.0
* @category constructors
*/
var flatten = (channels) => flatMap(channels, identity$1);
/**
* Flattens a channel that outputs arrays into a channel that outputs individual elements.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class FlattenError extends Data.TaggedError("FlattenError")<{
*   readonly message: string
* }> {}
*
* // Create a channel that outputs arrays
* const arrayChannel = Channel.fromIterable([
*   [1, 2, 3],
*   [4, 5],
*   [6, 7, 8, 9]
* ])
*
* // Flatten the arrays into individual elements
* const flattenedChannel = Channel.flattenArray(arrayChannel)
*
* // Outputs: 1, 2, 3, 4, 5, 6, 7, 8, 9
* ```
*
* @since 4.0.0
* @category utils
*/
var flattenArray = (self) => transformPull(self, (pull) => {
	let array;
	let index = 0;
	return succeed$2(suspend$1(function loop() {
		if (array === void 0) return flatMap$1(pull, (array_) => {
			switch (array_.length) {
				case 0: return loop();
				case 1: return succeed$2(array_[0]);
				default:
					array = array_;
					return succeed$2(array_[index++]);
			}
		});
		const next = array[index++];
		if (index >= array.length) {
			array = void 0;
			index = 0;
		}
		return succeed$2(next);
	}));
});
/**
* @since 4.0.0
* @category utils
*/
var flattenTake = (self) => mapEffectSequential(self, toPull$1);
/**
* Creates a new channel that consumes all output from the source channel
* but emits nothing, preserving only the completion value.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel that outputs values
* const sourceChannel = Channel.fromIterable([1, 2, 3, 4, 5])
*
* // Drain all output, keeping only the completion
* const drainedChannel = Channel.drain(sourceChannel)
*
* // The channel completes but emits no values
* // Useful for consuming side effects without collecting output
* ```
*
* @since 2.0.0
* @category constructors
*/
var drain = (self) => transformPull(self, (pull) => succeed$2(forever$1(pull, { disableYield: true })));
/**
* Repeats this channel according to the provided schedule.
*
* @since 4.0.0
* @category utils
*/
var repeat = /*#__PURE__*/ dual(2, (self, schedule) => toStepWithMetadata(typeof schedule === "function" ? schedule(identity$1) : schedule).pipe(map$1((step) => {
	let meta = CurrentMetadata.defaultValue();
	const loop = concatWith(provideServiceEffect(self, CurrentMetadata, sync$1(() => meta)), (done) => step(done).pipe(map$1((meta_) => {
		meta = meta_;
		return loop;
	}), catchDone(() => succeed$2(end(done))), unwrap));
	return loop;
}), unwrap));
/**
* Repeats this channel forever.
*
* @since 4.0.0
* @category utils
*/
var forever = (self) => concatWith(self, () => forever(self));
/**
* @since 4.0.0
* @category utils
*/
var schedule = /*#__PURE__*/ dual(2, (self, schedule) => transformPull(self, (pull, _scope) => map$1(toStepWithSleep(schedule), (step) => {
	return tap$1(pull, step);
})));
/**
* Filters the output elements of a channel using a predicate function.
* Elements that don't match the predicate are discarded.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel with mixed numbers
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5, 6, 7, 8])
*
* // Filter to keep only even numbers
* const evenChannel = Channel.filter(numbersChannel, (n) => n % 2 === 0)
* // Outputs: 2, 4, 6, 8
*
* // Filter with type refinement
* const mixedChannel = Channel.fromIterable([1, "hello", 2, "world", 3])
* const numbersOnlyChannel = Channel.filter(
*   mixedChannel,
*   (value): value is number => typeof value === "number"
* )
* // Outputs: 1, 2, 3 (all typed as numbers)
* ```
*
* @since 2.0.0
* @category Filtering
*/
var filter = /*#__PURE__*/ dual(2, (self, predicate) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => flatMap$1(pull, function loop(elem) {
	return predicate(elem) ? succeed$2(elem) : flatMap$1(pull, loop);
}))));
/**
* @since 4.0.0
* @category Filtering
*/
var filterMap = /*#__PURE__*/ dual(2, (self, filter) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => flatMap$1(pull, function loop(elem) {
	const result = filter(elem);
	return isFailure(result) ? flatMap$1(pull, loop) : succeed$2(result.success);
}))));
/**
* @since 4.0.0
* @category Filtering
*/
var filterEffect = /*#__PURE__*/ dual(2, (self, predicate) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => flatMap$1(pull, function loop(elem) {
	return flatMap$1(predicate(elem), (passes) => passes ? succeed$2(elem) : flatMap$1(pull, loop));
}))));
/**
* @since 4.0.0
* @category Filtering
*/
var filterMapEffect = /*#__PURE__*/ dual(2, (self, filter) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => flatMap$1(pull, function loop(elem) {
	return flatMap$1(filter(elem), (result) => isFailure(result) ? flatMap$1(pull, loop) : succeed$2(result.success));
}))));
/**
* Filters arrays of elements emitted by a channel, applying the filter
* to each element within the arrays and only emitting non-empty filtered arrays.
*
* @example
* ```ts
* import { Array, Channel } from "effect"
*
* const nonEmptyArrayPredicate = Array.isReadonlyArrayNonEmpty
*
* // Create a channel that outputs arrays of mixed data
* const arrayChannel = Channel.fromIterable([
*   Array.make(1, 2, 3, 4, 5),
*   Array.make(6, 7, 8, 9, 10),
*   Array.make(11, 12, 13, 14, 15)
* ]).pipe(Channel.filter(nonEmptyArrayPredicate))
*
* // Filter arrays to keep only even numbers
* const evenArraysChannel = Channel.filterArray(arrayChannel, (n) => n % 2 === 0)
* // Outputs: [2, 4], [6, 8, 10], [12, 14]
* // Note: Only non-empty filtered arrays are emitted
*
* // Arrays that would become empty after filtering are discarded entirely
* const oddChannel = Channel.fromIterable([
*   Array.make(1, 3, 5),
*   Array.make(2, 4),
*   Array.make(7, 9)
* ]).pipe(Channel.filter(nonEmptyArrayPredicate))
* const filteredOddChannel = Channel.filterArray(oddChannel, (n) => n % 2 === 0)
* // Outputs: [2, 4] (the arrays [1,3,5] and [7,9] are discarded)
* ```
*
* @since 4.0.0
* @category Filtering
*/
var filterArray = /*#__PURE__*/ dual(2, (self, predicate) => transformPull(self, (pull) => succeed$2(flatMap$1(pull, function loop(arr) {
	const passes = [];
	for (let i = 0; i < arr.length; i++) if (predicate(arr[i])) passes.push(arr[i]);
	return isReadonlyArrayNonEmpty(passes) ? succeed$2(passes) : flatMap$1(pull, loop);
}))));
/**
* @since 4.0.0
* @category Filtering
*/
var filterMapArray = /*#__PURE__*/ dual(2, (self, filter) => transformPull(self, (pull) => succeed$2(flatMap$1(pull, function loop(arr) {
	const passes = [];
	for (let i = 0; i < arr.length; i++) {
		const result = filter(arr[i]);
		if (isSuccess(result)) passes.push(result.success);
	}
	return isReadonlyArrayNonEmpty(passes) ? succeed$2(passes) : flatMap$1(pull, loop);
}))));
/**
* @since 4.0.0
* @category Filtering
*/
var filterArrayEffect = /*#__PURE__*/ dual(2, (self, predicate) => transformPull(self, (pull) => {
	const f = flatMap$1(pull, (arr) => filter$2(arr, predicate));
	return succeed$2(flatMap$1(f, function loop(arr) {
		return isReadonlyArrayNonEmpty(arr) ? succeed$2(arr) : flatMap$1(f, loop);
	}));
}));
/**
* @since 4.0.0
* @category Filtering
*/
var filterMapArrayEffect = /*#__PURE__*/ dual(2, (self, filter) => transformPull(self, (pull) => succeed$2(flatMap$1(pull, function loop(arr) {
	return flatMap$1(filterMapEffect$1(arr, filter), (passes) => isReadonlyArrayNonEmpty(passes) ? succeed$2(passes) : flatMap$1(pull, loop));
}))));
/**
* Statefully maps over a channel with an accumulator, where each element can produce multiple output values.
*
* @example
* ```ts
* import { Channel, Effect } from "effect"
*
* // Create a channel with numbers
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4])
*
* // Use mapAccum to create running sums and emit both current and sum
* const runningSum = Channel.mapAccum(
*   numbersChannel,
*   () => 0, // initial accumulator state
*   (sum, current) => {
*     const newSum = sum + current
*     // Return [newState, outputValues]
*     return [newSum, [current, newSum]] as const
*   }
* )
* // Outputs: 1, 1, 2, 3, 3, 6, 4, 10
*
* // Using with Effect for async processing
* const asyncMapAccum = Channel.mapAccum(
*   numbersChannel,
*   () => "",
*   (acc, value) =>
*     Effect.gen(function*() {
*       const newAcc = acc + value.toString()
*       return [newAcc, [`${value}-processed`, newAcc]] as const
*     })
* )
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var mapAccum = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, initial, f, options) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => {
	let state = initial();
	let current;
	let index = 0;
	let cause;
	const pullNext = matchCauseEffect$1(pull, {
		onFailure(cause_) {
			cause = cause_;
			const b = options?.onHalt && options.onHalt(state);
			return b && b.length > 0 ? succeed$2([state, b]) : failCause$2(cause_);
		},
		onSuccess(a) {
			const b = f(state, a);
			return isArray(b) ? succeed$2(b) : b;
		}
	});
	return suspend$1(function loop() {
		if (current === void 0) {
			if (cause) return failCause$2(cause);
			return flatMap$1(pullNext, ([newState, values]) => {
				state = newState;
				if (values.length === 0) return loop();
				else if (values.length === 1) return succeed$2(values[0]);
				current = values;
				return loop();
			});
		}
		const next = current[index++];
		if (index >= current.length) {
			current = void 0;
			index = 0;
		}
		return succeed$2(next);
	});
})));
/**
* Statefully transforms a channel by scanning over its output with an accumulator function.
* Emits the intermediate results of the scan operation.
*
* @example
* ```ts
* import { Channel } from "effect"
*
* // Create a channel with numbers
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5])
*
* // Scan to create running sum
* const runningSumChannel = Channel.scan(numbersChannel, 0, (sum, n) => sum + n)
* // Outputs: 0, 1, 3, 6, 10, 15
* // Note: emits the initial value and each intermediate result
*
* // Scan with string concatenation
* const wordsChannel = Channel.fromIterable(["hello", "world", "from", "effect"])
* const sentenceChannel = Channel.scan(
*   wordsChannel,
*   "",
*   (sentence, word) => sentence === "" ? word : `${sentence} ${word}`
* )
* // Outputs: "", "hello", "hello world", "hello world from", "hello world from effect"
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var scan = /*#__PURE__*/ dual(3, (self, initial, f) => scanEffect(self, initial, (s, a) => succeed$2(f(s, a))));
/**
* Statefully transforms a channel by scanning over its output with an effectful accumulator function.
* Emits the intermediate results of the scan operation.
*
* @example
* ```ts
* import { Channel, Data, Effect } from "effect"
*
* class ScanError extends Data.TaggedError("ScanError")<{
*   readonly reason: string
* }> {}
*
* // Create a channel with numbers
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4])
*
* // Effectful scan with async operations
* const asyncScanChannel = Channel.scanEffect(
*   numbersChannel,
*   "",
*   (acc, value) =>
*     Effect.gen(function*() {
*       // Simulate async work
*       yield* Effect.sleep("10 millis")
*       return acc + value.toString()
*     })
* )
* // Outputs: "", "1", "12", "123", "1234"
*
* // Scan with error handling
* const errorHandlingScan = Channel.scanEffect(
*   numbersChannel,
*   0,
*   (sum, n) => {
*     if (n < 0) {
*       return Effect.fail(new ScanError({ reason: "negative number" }))
*     }
*     return Effect.succeed(sum + n)
*   }
* )
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var scanEffect = /*#__PURE__*/ dual(3, (self, initial, f) => fromTransform((upstream, scope) => map$1(toTransform(self)(upstream, scope), (pull) => {
	let state = initial;
	let isFirst = true;
	if (isFirst) {
		isFirst = false;
		return succeed$2(state);
	}
	return map$1(flatMap$1(pull, (a) => f(state, a)), (newState) => {
		state = newState;
		return state;
	});
})));
/**
* Catches any cause of failure from the channel and allows recovery by
* creating a new channel based on the caught cause.
*
* @example
* ```ts
* import { Cause, Channel, Data } from "effect"
*
* class ProcessError extends Data.TaggedError("ProcessError")<{
*   readonly reason: string
* }> {}
*
* class RecoveryError extends Data.TaggedError("RecoveryError")<{
*   readonly message: string
* }> {}
*
* // Create a failing channel
* const failingChannel = Channel.fail(
*   new ProcessError({ reason: "network error" })
* )
*
* // Catch the cause and provide recovery
* const recoveredChannel = Channel.catchCause(failingChannel, (cause) => {
*   if (Cause.hasFails(cause)) {
*     return Channel.succeed("Recovered from failure")
*   }
*   return Channel.succeed("Recovered from interruption")
* })
*
* // The channel recovers gracefully from errors
* ```
*
* @since 4.0.0
* @category Error handling
*/
var catchCause = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => {
	let forkedScope = forkUnsafe(scope);
	return map$1(toTransform(self)(upstream, forkedScope), (pull) => {
		let currentPull = pull.pipe(catchCause$1((cause) => {
			if (isDoneCause(cause)) return failCause$2(cause);
			const toClose = forkedScope;
			forkedScope = forkUnsafe(scope);
			return close(toClose, failCause$3(cause)).pipe(andThen(toTransform(f(cause))(upstream, forkedScope)), flatMap$1((childPull) => {
				currentPull = childPull;
				return childPull;
			}));
		}));
		return suspend$1(() => currentPull);
	});
}));
/**
* @since 4.0.0
* @category Error handling
*/
var tapCause = /*#__PURE__*/ dual(2, (self, f) => catchCause(self, (cause) => fromEffectDrain(flatMap$1(f(cause), (_) => failCause$2(cause)))));
/**
* Catches causes of failure that match a specific filter, allowing
* conditional error recovery based on the type of failure.
*
* @since 4.0.0
* @category Error handling
*/
var catchCauseIf = /*#__PURE__*/ dual(3, (self, predicate, f) => catchCause(self, (cause) => {
	return predicate(cause) ? f(cause) : failCause(cause);
}));
/**
* @since 4.0.0
* @category Error handling
*/
var catchCauseFilter = /*#__PURE__*/ dual(3, (self, filter, f) => catchCause(self, (cause) => {
	const result = filter(cause);
	return isFailure(result) ? failCause(result.failure) : f(result.success, cause);
}));
var catch_ = /*#__PURE__*/ dual(2, (self, f) => catchCauseFilter(self, findError, (e) => f(e)));
/**
* @since 4.0.0
* @category Error handling
*/
var tapError = /*#__PURE__*/ dual(2, (self, f) => transformPull(self, (pull) => succeed$2(tapError$1(pull, (err) => isDone(err) ? void_ : asVoid(f(err))))));
/**
* @since 4.0.0
* @category Error handling
*/
var catchIf = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, predicate, f, orElse) => catch_(self, (err) => {
	return predicate(err) ? f(err) : orElse ? orElse(err) : fail(err);
}));
/**
* @since 4.0.0
* @category Error handling
*/
var catchFilter = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, filter, f, orElse) => catch_(self, (err) => {
	const result = filter(err);
	return isFailure(result) ? orElse ? orElse(result.failure) : fail(result.failure) : f(result.success);
}));
/**
* @since 4.0.0
* @category Error handling
*/
var catchTag = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, k, f, orElse) => {
	return catchIf(self, Array.isArray(k) ? (e) => hasProperty(e, "_tag") && k.includes(e._tag) : isTagged(k), f, orElse);
});
/**
* Catches a specific reason within a tagged error.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* const channel = Channel.fail(
*   new AiError({ reason: new RateLimitError({ retryAfter: 60 }) })
* )
*
* const recovered = channel.pipe(
*   Channel.catchReason("AiError", "RateLimitError", (reason) =>
*     Channel.succeed(`retry: ${reason.retryAfter}`)
*   )
* )
* ```
*
* @since 4.0.0
* @category Error handling
*/
var catchReason = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, errorTag, reasonTag, f, orElse) => catch_(self, (error) => {
	if (isTagged(error, errorTag) && hasProperty(error, "reason")) {
		const reason = error.reason;
		if (isTagged(reason, reasonTag)) return f(reason, error);
		return orElse ? orElse(reason, error) : fail(error);
	}
	return fail(error);
}));
/**
* Catches multiple reasons within a tagged error using an object of handlers.
*
* @since 4.0.0
* @category Error handling
*/
var catchReasons = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, errorTag, cases, orElse) => {
	let keys;
	return catch_(self, (error) => {
		if (isTagged(error, errorTag) && hasProperty(error, "reason") && hasProperty(error.reason, "_tag") && isString(error.reason._tag)) {
			const reason = error.reason;
			keys ??= new Set(Object.keys(cases));
			if (keys.has(reason._tag)) return cases[reason._tag](reason, error);
			return orElse ? orElse(reason, error) : fail(error);
		}
		return fail(error);
	});
});
/**
* Promotes nested reason errors into the channel error, replacing the parent error.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* const channel = Channel.fail(
*   new AiError({ reason: new RateLimitError({ retryAfter: 60 }) })
* )
*
* const unwrapped = channel.pipe(Channel.unwrapReason("AiError"))
* ```
*
* @since 4.0.0
* @category Error handling
*/
var unwrapReason = /*#__PURE__*/ dual(2, (self, errorTag) => catchFilter(self, (error) => isTagged(error, errorTag) && hasProperty(error, "reason") ? succeed$1(error.reason) : fail$2(error), fail));
/**
* Returns a new channel, which is the same as this one, except the failure
* value of the returned channel is created by applying the specified function
* to the failure value of this channel.
*
* @since 2.0.0
* @category Error handling
*/
var mapError = /*#__PURE__*/ dual(2, (self, f) => catch_(self, (err) => fail(f(err))));
/**
* Converts all errors in the channel to defects (unrecoverable failures).
* This is useful when you want to treat errors as programming errors.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class ValidationError extends Data.TaggedError("ValidationError")<{
*   readonly field: string
* }> {}
*
* // Create a channel that might fail
* const failingChannel = Channel.fail(new ValidationError({ field: "email" }))
*
* // Convert failures to defects
* const fatalChannel = Channel.orDie(failingChannel)
*
* // Any failure will now become a defect (uncaught exception)
* ```
*
* @since 4.0.0
* @category Error handling
*/
var orDie = (self) => catch_(self, die);
/**
* Ignores all errors in the channel, converting them to an empty channel.
*
* Use the `log` option to emit the full {@link Cause} when the channel fails.
*
* @since 4.0.0
* @category Error handling
*/
var ignore = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, options) => {
	if (!options?.log) return catch_(self, () => empty);
	const logEffect = logWithLevel(options.log === true ? void 0 : options.log);
	return catch_(tapCause(self, (cause) => hasFails(cause) ? logEffect(cause) : void_), () => empty);
});
var ignoreCause_ = (self) => catchCause(self, () => empty);
/**
* Ignores all errors in the channel including defects, converting them to an empty channel.
*
* Use the `log` option to emit the full {@link Cause} when the channel fails.
*
* @since 4.0.0
* @category Error handling
*/
var ignoreCause = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, options) => {
	if (!options?.log) return ignoreCause_(self);
	const logEffect = logWithLevel(options.log === true ? void 0 : options.log);
	return ignoreCause_(tapCause(self, (cause) => logEffect(cause)));
});
/**
* Returns a new channel that retries this channel according to the specified
* schedule whenever it fails.
*
* @since 4.0.0
* @category utils
*/
var retry = /*#__PURE__*/ dual(2, (self, schedule) => suspend(() => {
	let step = void 0;
	let meta = CurrentMetadata.defaultValue();
	const withReset = onFirst(provideServiceEffect(self, CurrentMetadata, sync$1(() => meta)), () => {
		step = void 0;
		return void_;
	});
	const resolvedSchedule = typeof schedule === "function" ? schedule(identity$1) : schedule;
	const loop = catch_(withReset, fnUntraced(function* (error) {
		if (!step) step = yield* toStepWithMetadata(resolvedSchedule);
		meta = yield* step(error);
		return loop;
	}, (effect, error) => catchDone(effect, () => succeed$2(fail(error))), unwrap));
	return loop;
}));
/**
* Returns a new channel, which sequentially combines this channel, together
* with the provided factory function, which creates a second channel based on
* the output values of this channel. The result is a channel that will first
* perform the functions of this channel, before performing the functions of
* the created channel (including yielding its terminal value).
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class SwitchError extends Data.TaggedError("SwitchError")<{
*   readonly reason: string
* }> {}
*
* // Create a channel that outputs numbers
* const numberChannel = Channel.fromIterable([1, 2, 3])
*
* // Switch to new channels based on each value
* const switchedChannel = Channel.switchMap(
*   numberChannel,
*   (n) => Channel.fromIterable([`value-${n}`])
* )
*
* // Outputs: "value-1", "value-2", "value-3"
* ```
*
* @since 2.0.0
* @category sequencing
*/
var switchMap = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, f, options) => self.pipe(map(f), mergeAll({
	...options,
	concurrency: options?.concurrency ?? 1,
	switch: true
})));
/**
* Merges multiple channels with specified concurrency and buffering options.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class MergeAllError extends Data.TaggedError("MergeAllError")<{
*   readonly reason: string
* }> {}
*
* // Create channels that output other channels
* const nestedChannels = Channel.fromIterable([
*   Channel.fromIterable([1, 2]),
*   Channel.fromIterable([3, 4]),
*   Channel.fromIterable([5, 6])
* ])
*
* // Merge all channels with bounded concurrency
* const mergedChannel = Channel.mergeAll({
*   concurrency: 2,
*   bufferSize: 16
* })(nestedChannels)
*
* // Outputs: 1, 2, 3, 4, 5, 6 (order may vary due to concurrency)
* ```
*
* @since 2.0.0
* @category utils
*/
var mergeAll = /*#__PURE__*/ dual(2, (channels, { bufferSize = 16, concurrency, switch: switch_ = false }) => fromTransformBracket(fnUntraced(function* (upstream, scope, forkedScope) {
	const concurrencyN = concurrency === "unbounded" ? Number.MAX_SAFE_INTEGER : Math.max(1, concurrency);
	const semaphore = switch_ ? void 0 : makeUnsafe(concurrencyN);
	const doneLatch = yield* make$5(true);
	const fibers = /* @__PURE__ */ new Set();
	const queue = yield* bounded(bufferSize);
	yield* addFinalizer(forkedScope, shutdown(queue));
	const pull = yield* toTransform(channels)(upstream, scope);
	yield* gen(function* () {
		while (true) {
			if (semaphore) yield* semaphore.take(1);
			const channel = yield* pull;
			const childScope = forkUnsafe(forkedScope);
			const childPull = yield* toTransform(channel)(upstream, childScope);
			while (fibers.size >= concurrencyN) {
				const fiber = headUnsafe(fibers);
				fibers.delete(fiber);
				if (fibers.size === 0) yield* doneLatch.open;
				yield* interrupt$1(fiber);
			}
			const fiber = yield* childPull.pipe(tap$1(() => yieldNow), flatMap$1((value) => offer(queue, value)), forever$1({ disableYield: true }), onError$1(fnUntraced(function* (cause) {
				const halt = filterDone(cause);
				yield* exit(close(childScope, !isFailure(halt) ? succeed$3(halt.success.value) : failCause$3(halt.failure)));
				if (!fibers.has(fiber)) return;
				fibers.delete(fiber);
				if (semaphore) yield* semaphore.release(1);
				if (fibers.size === 0) yield* doneLatch.open;
				if (isSuccess(halt)) return;
				return yield* failCause$1(queue, cause);
			})), forkChild);
			doneLatch.closeUnsafe();
			fibers.add(fiber);
		}
	}).pipe(catchCause$1((cause) => doneLatch.whenOpen(failCause$1(queue, cause))), forkIn(forkedScope));
	return take(queue);
})));
/**
* Returns a new channel, which is the merge of this channel and the specified
* channel.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class MergeError extends Data.TaggedError("MergeError")<{
*   readonly source: string
* }> {}
*
* // Create two channels
* const leftChannel = Channel.fromIterable([1, 2, 3])
* const rightChannel = Channel.fromIterable(["a", "b", "c"])
*
* // Merge them with "either" halt strategy
* const mergedChannel = Channel.merge(leftChannel, rightChannel, {
*   haltStrategy: "either"
* })
*
* // Outputs elements from both channels concurrently
* // Order may vary: 1, "a", 2, "b", 3, "c"
* ```
*
* @since 2.0.0
* @category utils
*/
var merge = /*#__PURE__*/ dual((args) => isChannel(args[0]) && isChannel(args[1]), (left, right, options) => fromTransformBracket(fnUntraced(function* (upstream, _scope, forkedScope) {
	const strategy = options?.haltStrategy ?? "both";
	const queue = yield* bounded(0);
	yield* addFinalizer(forkedScope, shutdown(queue));
	let done = 0;
	function onExit(side, cause) {
		done++;
		if (!isDoneCause(cause)) return failCause$1(queue, cause);
		switch (strategy) {
			case "both": return done === 2 ? failCause$1(queue, cause) : void_;
			case "left":
			case "right": return side === strategy ? failCause$1(queue, cause) : void_;
			case "either": return failCause$1(queue, cause);
		}
	}
	const runSide = (side, channel, scope) => toTransform(channel)(upstream, scope).pipe(flatMap$1((pull) => pull.pipe(flatMap$1((value) => offer(queue, value)), forever$1)), onError$1((cause) => andThen(close(scope, doneExitFromCause(cause)), onExit(side, cause))), forkIn(forkedScope));
	yield* runSide("left", left, forkUnsafe(forkedScope));
	yield* runSide("right", right, forkUnsafe(forkedScope));
	return take(queue);
})));
/**
* @since 4.0.0
* @category utils
*/
var mergeEffect = /*#__PURE__*/ dual(2, (self, effect) => merge(self, fromEffectDrain(effect), { haltStrategy: "left" }));
/**
* @since 2.0.0
* @category String manipulation
*/
var splitLines = () => fromTransform((upstream, _scope) => sync$1(() => {
	let stringBuilder = "";
	let midCRLF = false;
	const splitLinesArray = (chunk) => {
		const chunkBuilder = [];
		for (let i = 0; i < chunk.length; i++) {
			const str = chunk[i];
			if (str.length !== 0) {
				let from = 0;
				let indexOfCR = str.indexOf("\r");
				let indexOfLF = str.indexOf("\n");
				if (midCRLF) {
					if (indexOfLF === 0) {
						chunkBuilder.push(stringBuilder);
						stringBuilder = "";
						from = 1;
						indexOfLF = str.indexOf("\n", from);
					} else stringBuilder = stringBuilder + "\r";
					midCRLF = false;
				}
				while (indexOfCR !== -1 || indexOfLF !== -1) if (indexOfCR === -1 || indexOfLF !== -1 && indexOfLF < indexOfCR) {
					if (stringBuilder.length === 0) chunkBuilder.push(str.substring(from, indexOfLF));
					else {
						chunkBuilder.push(stringBuilder + str.substring(from, indexOfLF));
						stringBuilder = "";
					}
					from = indexOfLF + 1;
					indexOfLF = str.indexOf("\n", from);
				} else if (str.length === indexOfCR + 1) {
					midCRLF = true;
					indexOfCR = -1;
				} else if (indexOfLF === indexOfCR + 1) {
					if (stringBuilder.length === 0) chunkBuilder.push(str.substring(from, indexOfCR));
					else {
						stringBuilder = stringBuilder + str.substring(from, indexOfCR);
						chunkBuilder.push(stringBuilder);
						stringBuilder = "";
					}
					from = indexOfCR + 2;
					indexOfCR = str.indexOf("\r", from);
					indexOfLF = str.indexOf("\n", from);
				} else indexOfCR = str.indexOf("\r", indexOfCR + 1);
				if (midCRLF) stringBuilder = stringBuilder + str.substring(from, str.length - 1);
				else stringBuilder = stringBuilder + str.substring(from, str.length);
			}
		}
		return isReadonlyArrayNonEmpty(chunkBuilder) ? chunkBuilder : null;
	};
	return flatMap$1(upstream, function loop(chunk) {
		const lines = splitLinesArray(chunk);
		return lines !== null ? succeed$2(lines) : flatMap$1(upstream, loop);
	});
}));
/**
* @since 4.0.0
* @category String manipulation
*/
var decodeText = (encoding, options) => fromTransform((upstream, _scope) => sync$1(() => {
	const decoder = new TextDecoder(encoding, options);
	return map$1(upstream, map$2((line) => decoder.decode(line)));
}));
/**
* @since 4.0.0
* @category String manipulation
*/
var encodeText = () => fromTransform((upstream, _scope) => sync$1(() => {
	const encoder = new TextEncoder();
	return map$1(upstream, map$2((line) => encoder.encode(line)));
}));
/**
* Returns a new channel that pipes the output of this channel into the
* specified channel. The returned channel has the input type of this channel,
* and the output type of the specified channel, terminating with the value of
* the specified channel.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class PipeError extends Data.TaggedError("PipeError")<{
*   readonly stage: string
* }> {}
*
* // Create source and transform channels
* const sourceChannel = Channel.fromIterable([1, 2, 3])
* const transformChannel = Channel.map(sourceChannel, (n: number) => n * 2)
*
* // Pipe the source into the transform
* const pipedChannel = Channel.pipeTo(sourceChannel, transformChannel)
*
* // Outputs: 2, 4, 6
* ```
*
* @since 2.0.0
* @category utils
*/
var pipeTo = /*#__PURE__*/ dual(2, (self, that) => fromTransform((upstream, scope) => flatMap$1(toTransform(self)(upstream, scope), (upstream) => toTransform(that)(upstream, scope))));
/**
* Returns a new channel that pipes the output of this channel into the
* specified channel and preserves this channel's failures without providing
* them to the other channel for observation.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class SourceError extends Data.TaggedError("SourceError")<{
*   readonly code: number
* }> {}
*
* // Create a failing source channel
* const failingSource = Channel.fail(new SourceError({ code: 404 }))
* const safeTransform = Channel.succeed("transformed")
*
* // Pipe while preserving source failures
* const safePipedChannel = Channel.pipeToOrFail(failingSource, safeTransform)
*
* // Source errors are preserved and not sent to transform channel
* ```
*
* @since 2.0.0
* @category utils
*/
var pipeToOrFail = /*#__PURE__*/ dual(2, (self, that) => fromTransform((upstream, scope) => flatMap$1(toTransform(self)(upstream, scope), (upstream) => {
	const upstreamPull = catchCause$1(upstream, (cause) => isDoneCause(cause) ? failCause$2(cause) : die$2(Done$1(cause)));
	return map$1(toTransform(that)(upstreamPull, scope), (pull) => catchDefect(pull, (defect) => isDone(defect) ? failCause$2(defect.value) : die$2(defect)));
})));
/**
* Constructs a `Channel` from a scoped effect that will result in a
* `Channel` if successful.
*
* @example
* ```ts
* import { Channel, Data, Effect } from "effect"
*
* class UnwrapError extends Data.TaggedError("UnwrapError")<{
*   readonly reason: string
* }> {}
*
* // Create an effect that produces a channel
* const channelEffect = Effect.succeed(
*   Channel.fromIterable([1, 2, 3])
* )
*
* // Unwrap the effect to get the channel
* const unwrappedChannel = Channel.unwrap(channelEffect)
*
* // The resulting channel outputs: 1, 2, 3
* ```
*
* @since 2.0.0
* @category constructors
*/
var unwrap = (channel) => fromTransform((upstream, scope) => {
	let pull;
	return succeed$2(suspend$1(() => {
		if (pull) return pull;
		return channel.pipe(provide$1(scope), flatMap$1((channel) => toTransform(channel)(upstream, scope)), flatMap$1((pull_) => pull = pull_));
	}));
});
/**
* @since 2.0.0
* @category utils
*/
var scoped = (self) => fromTransformBracket((upstream, scope, forkedScope) => provide$1(toTransform(self)(upstream, scope), forkedScope));
/**
* Returns a new channel which embeds the given input handler into a Channel.
*
* @example
* ```ts
* import { Channel, Data, Effect } from "effect"
*
* class EmbedError extends Data.TaggedError("EmbedError")<{
*   readonly stage: string
* }> {}
*
* // Create a base channel
* const baseChannel = Channel.fromIterable([1, 2, 3])
*
* // Embed input handling - simplified example
* const embeddedChannel = Channel.embedInput(
*   baseChannel,
*   (_upstream) => Effect.void
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var embedInput = /*#__PURE__*/ dual(2, (self, input) => fromTransformBracket((upstream, scope, forkedScope) => andThen(forkIn(input(upstream), forkedScope), toTransform(self)(done(), scope))));
/**
* Allows a faster producer to progress independently of a slower consumer by
* buffering up to `capacity` elements in a queue.
*
* @since 2.0.0
* @category Buffering
*/
var buffer = /*#__PURE__*/ dual(2, (self, options) => fromTransform(fnUntraced(function* (upstream, scope) {
	const pull = yield* toTransform(self)(upstream, scope);
	const queue = yield* make$1({
		capacity: options.capacity === "unbounded" ? void 0 : options.capacity,
		strategy: options.capacity === "unbounded" ? void 0 : options.strategy
	});
	yield* addFinalizer(scope, shutdown(queue));
	yield* pull.pipe(flatMap$1((value) => offer(queue, value)), forever$1({ disableYield: true }), onError$1((cause) => failCause$1(queue, cause)), forkIn(scope));
	return take(queue);
})));
/**
* Allows a faster producer to progress independently of a slower consumer by
* buffering up to `capacity` elements in a queue.
*
* @since 2.0.0
* @category Buffering
*/
var bufferArray = /*#__PURE__*/ dual(2, (self, options) => fromTransform(fnUntraced(function* (upstream, scope) {
	const pull = yield* toTransform(self)(upstream, scope);
	const queue = yield* make$1({
		capacity: options.capacity === "unbounded" ? void 0 : options.capacity,
		strategy: options.capacity === "unbounded" ? void 0 : options.strategy
	});
	yield* addFinalizer(scope, shutdown(queue));
	yield* pull.pipe(flatMap$1((value) => offerAll(queue, value)), forever$1({ disableYield: true }), onError$1((cause) => failCause$1(queue, cause)), forkIn(scope));
	return takeAll(queue);
})));
/**
* Returns a new channel, which is the same as this one, except it will be
* interrupted when the specified effect completes. If the effect completes
* successfully before the underlying channel is done, then the returned
* channel will yield the success value of the effect as its terminal value.
* On the other hand, if the underlying channel finishes first, then the
* returned channel will yield the success value of the underlying channel as
* its terminal value.
*
* @since 2.0.0
* @category utils
*/
var interruptWhen = /*#__PURE__*/ dual(2, (self, effect) => merge(self, fromPull(succeed$2(flatMap$1(effect, done))), { haltStrategy: "either" }));
/**
* @since 4.0.0
* @category utils
*/
var haltWhen = /*#__PURE__*/ dual(2, (self, effect) => fromTransformBracket(fnUntraced(function* (upstream, scope, forkedScope) {
	const pull = yield* toTransform(self)(upstream, scope);
	let haltCause = void 0;
	yield* effect.pipe(catchCause$1((cause) => {
		haltCause = cause;
		return void_;
	}), forkIn(forkedScope));
	return suspend$1(() => haltCause ? failCause$2(haltCause) : pull);
})));
/**
* @since 4.0.0
* @category utils
*/
var onError = /*#__PURE__*/ dual(2, (self, finalizer) => onExit(self, (exit) => isFailure$1(exit) ? finalizer(exit.cause) : void_));
/**
* Returns a new channel with an attached finalizer. The finalizer is
* guaranteed to be executed so long as the channel begins execution (and
* regardless of whether or not it completes).
*
* @example
* ```ts
* import { Channel, Console, Data, Exit } from "effect"
*
* class ExitError extends Data.TaggedError("ExitError")<{
*   readonly stage: string
* }> {}
*
* // Create a channel
* const dataChannel = Channel.fromIterable([1, 2, 3])
*
* // Attach exit handler
* const channelWithExit = Channel.onExit(dataChannel, (exit) => {
*   if (Exit.isSuccess(exit)) {
*     return Console.log(`Channel completed successfully with: ${exit.value}`)
*   } else {
*     return Console.log(`Channel failed with: ${exit.cause}`)
*   }
* })
* ```
*
* @since 4.0.0
* @category utils
*/
var onExit = /*#__PURE__*/ dual(2, (self, finalizer) => fromTransformBracket((upstream, scope, forkedScope) => addFinalizerExit(forkedScope, finalizer).pipe(andThen(toTransform(self)(upstream, scope)))));
/**
* @since 4.0.0
* @category utils
*/
var onStart = /*#__PURE__*/ dual(2, (self, onStart) => unwrap(as$1(onStart, self)));
/**
* @since 4.0.0
* @category utils
*/
var onFirst = /*#__PURE__*/ dual(2, (self, onFirst) => transformPull(self, (pull) => sync$1(() => {
	let isFirst = true;
	const pullFirst = tap$1(pull, (element) => {
		isFirst = false;
		return onFirst(element);
	});
	return suspend$1(() => isFirst ? pullFirst : pull);
})));
/**
* @since 4.0.0
* @category utils
*/
var onEnd = /*#__PURE__*/ dual(2, (self, onEnd) => transformPull(self, (pull) => succeed$2(catchDone(pull, (leftover) => flatMap$1(onEnd, () => done(leftover))))));
/**
* Returns a new channel with an attached finalizer. The finalizer is
* guaranteed to be executed so long as the channel begins execution (and
* regardless of whether or not it completes).
*
* @example
* ```ts
* import { Channel, Console, Data } from "effect"
*
* class EnsureError extends Data.TaggedError("EnsureError")<{
*   readonly operation: string
* }> {}
*
* // Create a channel
* const dataChannel = Channel.fromIterable([1, 2, 3])
*
* // Ensure cleanup always runs
* const channelWithCleanup = Channel.ensuring(
*   dataChannel,
*   Console.log("Cleanup executed regardless of success or failure")
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var ensuring = /*#__PURE__*/ dual(2, (self, finalizer) => onExit(self, (_) => finalizer));
var runWith = (self, f, onHalt) => suspend$1(() => {
	const scope = makeUnsafe$2();
	return catchDone(flatMap$1(toTransform(self)(done(), scope), f), onHalt ? onHalt : succeed$2).pipe(onExit$1((exit) => close(scope, exit)));
});
/**
* Create a channel from the specified services.
*
* @since 2.0.0
* @category Services
*/
var servicesWith = (f) => fromTransform((upstream, scope) => servicesWith$1((services) => toTransform(f(services))(upstream, scope)));
/**
* Provides a layer or service map to the channel, removing the corresponding
* service requirements. Use `options.local` to build the layer every time; by
* default, layers are shared between provide calls.
*
* @since 4.0.0
* @category Services
*/
var provideServices = /*#__PURE__*/ dual(2, (self, services) => fromTransform((upstream, scope) => map$1(provideServices$1(toTransform(self)(upstream, scope), services), provideServices$1(services))));
/**
* @since 4.0.0
* @category Services
*/
var provideService = /*#__PURE__*/ dual(3, (self, key, service) => fromTransform((upstream, scope) => map$1(provideService$1(toTransform(self)(upstream, scope), key, service), provideService$1(key, service))));
/**
* @since 4.0.0
* @category Services
*/
var provideServiceEffect = /*#__PURE__*/ dual(3, (self, key, service) => fromTransform((upstream, scope) => flatMap$1(service, (s) => toTransform(provideService(self, key, s))(upstream, scope))));
/**
* @since 4.0.0
* @category Services
*/
var provide = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, layer, options) => isServiceMap(layer) ? provideServices(self, layer) : fromTransform((upstream, scope) => flatMap$1(options?.local ? buildWithMemoMap(layer, makeMemoMapUnsafe(), scope) : buildWithScope(layer, scope), (services) => map$1(provideServices$1(toTransform(self)(upstream, scope), services), provideServices$1(services)))));
/**
* @since 2.0.0
* @category Services
*/
var updateServices = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => servicesWith$1((services) => {
	return toTransform(provideServices(self, f(services)))(upstream, scope);
})));
/**
* @since 2.0.0
* @category Services
*/
var updateService = /*#__PURE__*/ dual(3, (self, service, f) => updateServices(self, (services) => add(services, service, f(get$2(services, service)))));
/**
* @since 4.0.0
* @category Tracing
*/
var withSpan = function() {
	const dataFirst = isChannel(arguments[0]);
	const name = dataFirst ? arguments[1] : arguments[0];
	const options = addSpanStackTrace(dataFirst ? arguments[2] : arguments[1]);
	if (dataFirst) {
		const self = arguments[0];
		return withSpanImpl(self, name, options);
	}
	return (self) => withSpanImpl(self, name, options);
};
var withSpanImpl = (self, name, options) => acquireUseRelease(makeSpan(name, options), (span) => provideService(self, ParentSpan, span), (span, exit) => withFiber$1((fiber) => {
	return endSpan(span, exit, fiber.getRef(ClockRef), fiber.getRef(TracerTimingEnabled));
}));
/**
* @since 4.0.0
* @category Do notation
*/
var Do = /*#__PURE__*/ succeed({});
var let_ = /*#__PURE__*/ dual(3, (self, name, f) => map(self, (elem) => ({
	...elem,
	[name]: f(elem)
})));
/**
* @since 4.0.0
* @category Do notation
*/
var bind = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, name, f, options) => flatMap(self, (elem) => map(f(elem), (b) => ({
	...elem,
	[name]: b
})), options));
/**
* @since 4.0.0
* @category Do notation
*/
var bindTo = /*#__PURE__*/ dual(2, (self, name) => map(self, (elem) => ({ [name]: elem })));
/**
* Runs a channel and counts the number of elements it outputs.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class CountError extends Data.TaggedError("CountError")<{
*   readonly reason: string
* }> {}
*
* // Create a channel with multiple elements
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5])
*
* // Count the elements
* const countEffect = Channel.runCount(numbersChannel)
*
* // Effect.runSync(countEffect) // Returns: 5
* ```
*
* @since 2.0.0
* @category execution
*/
var runCount = (self) => runFold(self, () => 0, (acc) => acc + 1);
/**
* Runs a channel and discards all output elements, returning only the final result.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class DrainError extends Data.TaggedError("DrainError")<{
*   readonly stage: string
* }> {}
*
* // Create a channel that outputs elements and completes with a result
* const resultChannel = Channel.fromIterable([1, 2, 3])
* const completedChannel = Channel.concatWith(
*   resultChannel,
*   () => Channel.succeed("completed")
* )
*
* // Drain all elements and get only the final result
* const drainEffect = Channel.runDrain(completedChannel)
*
* // Effect.runSync(drainEffect) // Returns: "completed"
* ```
*
* @since 2.0.0
* @category execution
*/
var runDrain = (self) => runWith(self, (pull) => forever$1(pull, { disableYield: true }));
/**
* Runs a channel and applies an effect to each output element.
*
* @example
* ```ts
* import { Channel, Console, Data } from "effect"
*
* class ForEachError extends Data.TaggedError("ForEachError")<{
*   readonly element: unknown
* }> {}
*
* // Create a channel with numbers
* const numbersChannel = Channel.fromIterable([1, 2, 3])
*
* // Run forEach to log each element
* const forEachEffect = Channel.runForEach(
*   numbersChannel,
*   (n) => Console.log(`Processing: ${n}`)
* )
*
* // Logs: "Processing: 1", "Processing: 2", "Processing: 3"
* ```
*
* @since 2.0.0
* @category execution
*/
var runForEach = /*#__PURE__*/ dual(2, (self, f) => runWith(self, (pull) => forever$1(flatMap$1(pull, f), { disableYield: true })));
/**
* @since 2.0.0
* @category execution
*/
var runForEachWhile = /*#__PURE__*/ dual(2, (self, f) => runWith(self, (pull) => pull.pipe(flatMap$1(f), flatMap$1((cont) => cont ? void_ : done()), forever$1({ disableYield: true }))));
/**
* Runs a channel and collects all output elements into an array.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class CollectError extends Data.TaggedError("CollectError")<{
*   readonly reason: string
* }> {}
*
* // Create a channel with elements
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5])
*
* // Collect all elements into an array
* const collectEffect = Channel.runCollect(numbersChannel)
*
* // Effect.runSync(collectEffect) // Returns: [1, 2, 3, 4, 5]
* ```
*
* @since 2.0.0
* @category execution
*/
var runCollect = (self) => runFold(self, () => [], (acc, o) => {
	acc.push(o);
	return acc;
});
/**
* Runs a channel and outputs the done value.
*
* @since 4.0.0
* @category execution
*/
var runDone = (self) => runWith(self, identity$1, succeed$2);
/**
* @since 2.0.0
* @category execution
*/
var runHead = (self) => suspend$1(() => {
	let head = none();
	return runWith(self, (pull) => pull.pipe(asSome, flatMap$1((head_) => {
		head = head_;
		return done();
	})), () => succeed$2(head));
});
/**
* @since 2.0.0
* @category execution
*/
var runLast = (self) => suspend$1(() => {
	const absent = Symbol();
	let last = absent;
	return runWith(self, (pull) => forever$1(flatMap$1(pull, (item) => {
		last = item;
		return void_;
	}), { disableYield: true }), () => last === absent ? succeedNone : succeedSome(last));
});
/**
* Runs a channel and folds over all output elements with an accumulator.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class FoldError extends Data.TaggedError("FoldError")<{
*   readonly operation: string
* }> {}
*
* // Create a channel with numbers
* const numbersChannel = Channel.fromIterable([1, 2, 3, 4, 5])
*
* // Fold to calculate sum
* const sumEffect = Channel.runFold(numbersChannel, () => 0, (acc, n) => acc + n)
*
* // Effect.runSync(sumEffect) // Returns: 15
* ```
*
* @since 2.0.0
* @category execution
*/
var runFold = /*#__PURE__*/ dual(3, (self, initial, f) => suspend$1(() => {
	let state = initial();
	return runWith(self, (pull) => whileLoop$1({
		while: constTrue,
		body: () => pull,
		step: (value) => {
			state = f(state, value);
		}
	}), () => succeed$2(state));
}));
/**
* @since 2.0.0
* @category execution
*/
var runFoldEffect = /*#__PURE__*/ dual(3, (self, initial, f) => suspend$1(() => {
	let state = initial();
	return runWith(self, (pull) => whileLoop$1({
		while: constTrue,
		body: constant(pull.pipe(flatMap$1((o) => f(state, o)), map$1((s) => {
			state = s;
		}))),
		step: constVoid
	}), () => succeed$2(state));
}));
/**
* Converts a channel to a Pull data structure for low-level consumption.
*
* @example
* ```ts
* import { Channel, Data, Effect } from "effect"
*
* class PullError extends Data.TaggedError("PullError")<{
*   readonly step: string
* }> {}
*
* // Create a channel
* const numbersChannel = Channel.fromIterable([1, 2, 3])
*
* // Convert to Pull within a scope
* const pullEffect = Effect.scoped(
*   Channel.toPull(numbersChannel)
* )
*
* // Use the Pull to manually consume elements
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toPull = /*#__PURE__*/ fnUntraced(function* (self) {
	const semaphore = makeUnsafe(1);
	const context = yield* services();
	const scope = get$2(context, Scope);
	return (yield* toTransform(self)(done(), scope)).pipe(provideServices$1(context), semaphore.withPermits(1));
}, /*#__PURE__*/ catchCause$1((cause) => succeed$2(failCause$2(cause))));
/**
* Converts a channel to a Pull within an existing scope.
*
* @example
* ```ts
* import { Channel, Data, Effect, Scope } from "effect"
*
* class ScopedPullError extends Data.TaggedError("ScopedPullError")<{
*   readonly reason: string
* }> {}
*
* // Create a channel
* const numbersChannel = Channel.fromIterable([1, 2, 3])
*
* // Convert to Pull with explicit scope
* const scopedPullEffect = Effect.gen(function*() {
*   const scope = yield* Scope.make()
*   const pull = yield* Channel.toPullScoped(numbersChannel, scope)
*   return pull
* })
* ```
*
* @since 4.0.0
* @category Destructors
*/
var toPullScoped = (self, scope) => toTransform(self)(done(), scope);
/**
* @since 4.0.0
* @category Destructors
*/
var runIntoQueue = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, queue) => uninterruptibleMask$1((restore) => runForEach(self, (value) => offer(queue, value)).pipe(restore, exit, flatMap$1((exit) => {
	if (isSuccess$1(exit)) endUnsafe(queue);
	else failCauseUnsafe(queue, exit.cause);
	return void_;
}))));
/**
* @since 4.0.0
* @category Destructors
*/
var runIntoQueueArray = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, queue) => uninterruptibleMask$1((restore) => runForEach(self, (value) => offerAll(queue, value)).pipe(restore, exit, flatMap$1((exit) => {
	if (isSuccess$1(exit)) endUnsafe(queue);
	else failCauseUnsafe(queue, exit.cause);
	return void_;
}))));
/**
* Converts a channel to a queue for concurrent consumption.
*
* @example
* ```ts
* import { Channel, Data } from "effect"
*
* class QueueError extends Data.TaggedError("QueueError")<{
*   readonly operation: string
* }> {}
*
* // Create a channel with data
* const dataChannel = Channel.fromIterable([1, 2, 3, 4, 5])
*
* // Convert to queue for concurrent processing
* const queueEffect = Channel.toQueue(dataChannel, { capacity: 32 })
*
* // The queue can be used for concurrent consumption
* // Multiple consumers can read from the queue
* ```
*
* @since 4.0.0
* @category Destructors
*/
var toQueue = /*#__PURE__*/ dual((args) => isChannel(args[0]), /*#__PURE__*/ fnUntraced(function* (self, options) {
	const scope$1 = yield* scope;
	const queue = yield* make$1({
		capacity: typeof options.capacity === "number" ? options.capacity : void 0,
		strategy: typeof options.capacity === "number" ? options.strategy : void 0
	});
	yield* addFinalizer(scope$1, shutdown(queue));
	yield* forkIn(runIntoQueue(self, queue), scope$1);
	return queue;
}));
/**
* @since 4.0.0
* @category Destructors
*/
var toQueueArray = /*#__PURE__*/ dual((args) => isChannel(args[0]), /*#__PURE__*/ fnUntraced(function* (self, options) {
	const scope$2 = yield* scope;
	const queue = yield* make$1({
		capacity: typeof options.capacity === "number" ? options.capacity : void 0,
		strategy: typeof options.capacity === "number" ? options.strategy : void 0
	});
	yield* addFinalizer(scope$2, shutdown(queue));
	yield* forkIn(runIntoQueueArray(self, queue), scope$2);
	return queue;
}));
/**
* Converts a channel to a PubSub for concurrent consumption.
*
* `shutdownOnEnd` indicates whether the PubSub should be shut down when the
* channel ends. By default this is `true`.
*
* @since 4.0.0
* @category Destructors
*/
var toPubSub = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, options) {
	const pubsub = yield* makePubSub(options);
	yield* forkScoped(runIntoPubSub(self, pubsub, { shutdownOnEnd: options.shutdownOnEnd !== false }));
	return pubsub;
}));
/**
* @since 4.0.0
* @category Destructors
*/
var runIntoPubSub = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, pubsub, options) => runForEach(self, (value) => publish(pubsub, value)).pipe(options?.shutdownOnEnd === true ? ensuring$1(shutdown$1(pubsub)) : identity$1));
var makePubSub = (options) => acquireRelease$1(options.capacity === "unbounded" ? unbounded$1(options) : options.strategy === "dropping" ? dropping$1(options) : options.strategy === "sliding" ? sliding$1(options) : bounded$1(options), shutdown$1);
/**
* Converts a channel to a PubSub for concurrent consumption.
*
* `shutdownOnEnd` indicates whether the PubSub should be shut down when the
* channel ends. By default this is `true`.
*
* @since 4.0.0
* @category Destructors
*/
var toPubSubArray = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, options) {
	const pubsub = yield* makePubSub(options);
	yield* forkScoped(runIntoPubSubArray(self, pubsub, { shutdownOnEnd: options.shutdownOnEnd !== false }));
	return pubsub;
}));
/**
* @since 4.0.0
* @category Destructors
*/
var runIntoPubSubArray = /*#__PURE__*/ dual((args) => isChannel(args[0]), (self, pubsub, options) => runForEach(self, (value) => publishAll(pubsub, value)).pipe(options?.shutdownOnEnd === true ? ensuring$1(shutdown$1(pubsub)) : identity$1));
/**
* Converts a channel to a PubSub for concurrent consumption.
*
* @since 4.0.0
* @category Destructors
*/
var toPubSubTake = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, options) {
	const pubsub = yield* makePubSub(options);
	yield* runForEach(self, (value) => publish(pubsub, value)).pipe(onExit$1((exit) => publish(pubsub, exit)), forkScoped);
	return pubsub;
}));
//#endregion
export { merge as $, endUnsafe as $t, flattenArray as A, makeUnsafe$1 as An, splitLines as At, fromPull as B, runIn as Bn, toPullScoped as Bt, failSync as C, make$4 as Cn, runHead as Ct, filterMapArray as D, takeNVoid as Dn, scanEffect as Dt, filterArrayEffect as E, takeN$1 as En, runLast as Et, fromEffect as F, interruptAll as Fn, tapCause as Ft, haltWhen as G, get$1 as Gn, Take_exports as Gt, fromSubscriptionArray as H, clear$2 as Hn, unwrap as Ht, fromIterableArray as I, interruptAllAs as In, tapError as It, interruptWhen as J, make$6 as Jn, makeUnsafe as Jt, ignore as K, has as Kn, Semaphore_exports as Kt, fromIteratorArray as L, interruptAs as Ln, toPubSubArray as Lt, forever as M, await_$1 as Mn, suspend as Mt, fromArray as N, getCurrent as Nn, switchMap as Nt, filterMapArrayEffect as O, toArrayN as On, schedule as Ot, fromAsyncIterableArray as P, interrupt$1 as Pn, sync as Pt, mapError as Q, values as Qn, end$1 as Qt, fromPubSubArray as R, join as Rn, toPubSubTake as Rt, failCauseSync as S, appendAllUnsafe as Sn, runForEachWhile as St, filterArray as T, takeAll$2 as Tn, runIntoQueueArray as Tt, fromTransform as U, empty$1 as Un, updateServices as Ut, fromQueueArray as V, MutableHashMap_exports as Vn, toTransform as Vt, fromTransformBracket as W, fromIterable$1 as Wn, withSpan as Wt, mapAccum as X, set$1 as Xn, bounded as Xt, map as Y, remove$1 as Yn, Queue_exports as Yt, mapEffect as Z, size$2 as Zn, collect as Zt, drain as _, MutableRef_exports as _n, retry as _t, callbackArray as a, offerAll as an, onExit as at, fail as b, MutableList_exports as bn, runFoldEffect as bt, catchCauseIf as c, shutdown as cn, orDie as ct, catchReason as d, unbounded as dn, pipeToOrFail as dt, failCause$1 as en, mergeAll as et, catchReasons as f, PubSub_exports as fn, provide as ft, die as g, unbounded$1 as gn, repeat as gt, concatWith as h, publishUnsafe as hn, provideServices as ht, bufferArray as i, offer as in, onError as it, flattenTake as j, Fiber_exports as jn, succeed as jt, flatMap as k, Latch_exports as kn, scoped as kt, catchFilter as l, take as ln, orElseIfEmpty as lt, combine as m, publishAll as mn, provideServiceEffect as mt, DefaultChunkSize as n, into as nn, never as nt, catchCause as o, offerAllUnsafe as on, onFirst as ot, catch_ as p, publish as pn, provideService as pt, ignoreCause as q, keys as qn, make as qt, buffer as r, make$1 as rn, onEnd as rt, catchCauseFilter as s, offerUnsafe as sn, onStart as st, Channel_exports as t, failCauseUnsafe as tn, mergeEffect as tt, catchIf as u, takeAll as un, pipeTo as ut, empty as v, make$3 as vn, runDrain as vt, filter as w, take$2 as wn, runIntoPubSubArray as wt, failCause as x, appendAll as xn, runForEach as xt, ensuring as y, set as yn, runFold as yt, fromPubSubTake as z, joinAll as zn, toPull as zt };
