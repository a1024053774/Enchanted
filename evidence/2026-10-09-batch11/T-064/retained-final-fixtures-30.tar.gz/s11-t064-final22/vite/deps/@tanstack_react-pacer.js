import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_with_selector } from "./with-selector-DWMNlIjb.js";
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/provider/PacerProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var PacerContext = (0, import_react.createContext)(null);
var DEFAULT_OPTIONS = {};
function PacerProvider({ children, defaultOptions = DEFAULT_OPTIONS }) {
	const contextValue = (0, import_react.useMemo)(() => ({ defaultOptions }), [defaultOptions]);
	return /* @__PURE__ */ import_react.createElement(PacerContext.Provider, { value: contextValue }, children);
}
function usePacerContext() {
	return (0, import_react.useContext)(PacerContext);
}
function useDefaultPacerOptions() {
	return (0, import_react.useContext)(PacerContext)?.defaultOptions ?? {};
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/utils.js
function isFunction(value) {
	return typeof value === "function";
}
function parseFunctionOrValue(value, ...args) {
	return isFunction(value) ? value(...args) : value;
}
//#endregion
//#region node_modules/.bun/@tanstack+devtools-event-client@0.4.3/node_modules/@tanstack/devtools-event-client/dist/esm/plugin.js
var EventClient = class {
	#enabled = true;
	#pluginId;
	#eventTarget;
	#debug;
	#queuedEvents;
	#connected;
	#connectIntervalId;
	#connectEveryMs;
	#retryCount = 0;
	#maxRetries = 5;
	#connecting = false;
	#failedToConnect = false;
	#internalEventTarget = null;
	#onConnected = () => {
		this.debugLog("Connected to event bus");
		this.#connected = true;
		this.#connecting = false;
		this.debugLog("Emitting queued events", this.#queuedEvents);
		this.#queuedEvents.forEach((event) => this.emitEventToBus(event));
		this.#queuedEvents = [];
		this.stopConnectLoop();
		this.#eventTarget().removeEventListener("tanstack-connect-success", this.#onConnected);
	};
	#retryConnection = () => {
		if (this.#retryCount < this.#maxRetries) {
			this.#retryCount++;
			this.dispatchCustomEvent("tanstack-connect", {});
			return;
		}
		this.#eventTarget().removeEventListener("tanstack-connect", this.#retryConnection);
		this.#failedToConnect = true;
		this.debugLog("Max retries reached, giving up on connection");
		this.stopConnectLoop();
	};
	#connectFunction = () => {
		if (this.#connecting) return;
		this.#connecting = true;
		this.#eventTarget().addEventListener("tanstack-connect-success", this.#onConnected);
		this.#retryConnection();
	};
	constructor({ pluginId, debug = false, enabled = true, reconnectEveryMs = 300 }) {
		this.#pluginId = pluginId;
		this.#enabled = enabled;
		this.#eventTarget = this.getGlobalTarget;
		this.#debug = debug;
		this.debugLog(" Initializing event subscription for plugin", this.#pluginId);
		this.#queuedEvents = [];
		this.#connected = false;
		this.#failedToConnect = false;
		this.#connectIntervalId = null;
		this.#connectEveryMs = reconnectEveryMs;
	}
	startConnectLoop() {
		if (this.#connectIntervalId !== null || this.#connected) return;
		this.debugLog(`Starting connect loop (every ${this.#connectEveryMs}ms)`);
		this.#connectIntervalId = setInterval(this.#retryConnection, this.#connectEveryMs);
	}
	stopConnectLoop() {
		this.#connecting = false;
		if (this.#connectIntervalId === null) return;
		clearInterval(this.#connectIntervalId);
		this.#connectIntervalId = null;
		this.#queuedEvents = [];
		this.debugLog("Stopped connect loop");
	}
	debugLog(...args) {
		if (this.#debug) console.log(`🌴 [tanstack-devtools:${this.#pluginId}-plugin]`, ...args);
	}
	getGlobalTarget() {
		if (typeof globalThis !== "undefined" && globalThis.__TANSTACK_EVENT_TARGET__) {
			this.debugLog("Using global event target");
			return globalThis.__TANSTACK_EVENT_TARGET__;
		}
		if (typeof window !== "undefined" && typeof window.addEventListener !== "undefined") {
			this.debugLog("Using window as event target");
			return window;
		}
		const eventTarget = typeof EventTarget !== "undefined" ? new EventTarget() : void 0;
		if (typeof eventTarget === "undefined" || typeof eventTarget.addEventListener === "undefined") {
			this.debugLog("No event mechanism available, running in non-web environment");
			return {
				addEventListener: () => {},
				removeEventListener: () => {},
				dispatchEvent: () => false
			};
		}
		this.debugLog("Using new EventTarget as fallback");
		return eventTarget;
	}
	getPluginId() {
		return this.#pluginId;
	}
	dispatchCustomEventShim(eventName, detail) {
		try {
			const event = new Event(eventName, { detail });
			this.#eventTarget().dispatchEvent(event);
		} catch (e) {
			this.debugLog("Failed to dispatch shim event");
		}
	}
	dispatchCustomEvent(eventName, detail) {
		try {
			this.#eventTarget().dispatchEvent(new CustomEvent(eventName, { detail }));
		} catch (e) {
			this.dispatchCustomEventShim(eventName, detail);
		}
	}
	emitEventToBus(event) {
		this.debugLog("Emitting event to client bus", event);
		this.dispatchCustomEvent("tanstack-dispatch-event", event);
	}
	createEventPayload(eventSuffix, payload) {
		return {
			type: `${this.#pluginId}:${eventSuffix}`,
			payload,
			pluginId: this.#pluginId
		};
	}
	emit(eventSuffix, payload) {
		if (!this.#enabled) {
			this.debugLog("Event bus client is disabled, not emitting event", eventSuffix, payload);
			return;
		}
		if (this.#internalEventTarget) {
			this.debugLog("Emitting event to internal event target", eventSuffix, payload);
			this.#internalEventTarget.dispatchEvent(new CustomEvent(`${this.#pluginId}:${eventSuffix}`, { detail: this.createEventPayload(eventSuffix, payload) }));
		}
		if (this.#failedToConnect) {
			this.debugLog("Previously failed to connect, not emitting to bus");
			return;
		}
		if (!this.#connected) {
			this.debugLog("Bus not available, will be pushed as soon as connected");
			this.#queuedEvents.push(this.createEventPayload(eventSuffix, payload));
			if (typeof CustomEvent !== "undefined" && !this.#connecting) {
				this.#connectFunction();
				this.startConnectLoop();
			}
			return;
		}
		return this.emitEventToBus(this.createEventPayload(eventSuffix, payload));
	}
	on(eventSuffix, cb, options) {
		const withEventTarget = options?.withEventTarget ?? false;
		const eventName = `${this.#pluginId}:${eventSuffix}`;
		if (withEventTarget) {
			if (!this.#internalEventTarget) this.#internalEventTarget = new EventTarget();
			this.#internalEventTarget.addEventListener(eventName, (e) => {
				cb(e.detail);
			});
		}
		if (!this.#enabled) {
			this.debugLog("Event bus client is disabled, not registering event", eventName);
			return () => {};
		}
		const handler = (e) => {
			this.debugLog("Received event from bus", e.detail);
			cb(e.detail);
		};
		this.#eventTarget().addEventListener(eventName, handler);
		this.debugLog("Registered event to bus", eventName);
		return () => {
			if (withEventTarget) this.#internalEventTarget?.removeEventListener(eventName, handler);
			this.#eventTarget().removeEventListener(eventName, handler);
		};
	}
	onAll(cb) {
		if (!this.#enabled) {
			this.debugLog("Event bus client is disabled, not registering event");
			return () => {};
		}
		const handler = (e) => {
			const event = e.detail;
			cb(event);
		};
		this.#eventTarget().addEventListener("tanstack-devtools-global", handler);
		return () => this.#eventTarget().removeEventListener("tanstack-devtools-global", handler);
	}
	onAllPluginEvents(cb) {
		if (!this.#enabled) {
			this.debugLog("Event bus client is disabled, not registering event");
			return () => {};
		}
		const handler = (e) => {
			const event = e.detail;
			if (this.#pluginId && event.pluginId !== this.#pluginId) return;
			cb(event);
		};
		this.#eventTarget().addEventListener("tanstack-devtools-global", handler);
		return () => this.#eventTarget().removeEventListener("tanstack-devtools-global", handler);
	}
};
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/event-client.js
var PacerEventClient = class extends EventClient {
	constructor(props) {
		super({
			pluginId: "pacer",
			debug: props?.debug
		});
	}
};
var emitChange = (event, payload) => {
	if (payload.key) pacerEventClient.emit(event, payload);
};
var pacerEventClient = new PacerEventClient();
//#endregion
//#region node_modules/.bun/@tanstack+store@0.8.1/node_modules/@tanstack/store/dist/esm/scheduler.js
var __storeToDerived = /* @__PURE__ */ new WeakMap();
var __derivedToStore = /* @__PURE__ */ new WeakMap();
var __depsThatHaveWrittenThisTick = { current: [] };
var __isFlushing = false;
var __batchDepth = 0;
var __pendingUpdates = /* @__PURE__ */ new Set();
var __initialBatchValues = /* @__PURE__ */ new Map();
function __flush_internals(relatedVals) {
	const sorted = Array.from(relatedVals).sort((a, b) => {
		if (a instanceof Derived && a.options.deps.includes(b)) return 1;
		if (b instanceof Derived && b.options.deps.includes(a)) return -1;
		return 0;
	});
	for (const derived of sorted) {
		if (__depsThatHaveWrittenThisTick.current.includes(derived)) continue;
		__depsThatHaveWrittenThisTick.current.push(derived);
		derived.recompute();
		const stores = __derivedToStore.get(derived);
		if (stores) for (const store of stores) {
			const relatedLinkedDerivedVals = __storeToDerived.get(store);
			if (!relatedLinkedDerivedVals) continue;
			__flush_internals(relatedLinkedDerivedVals);
		}
	}
}
function __notifyListeners(store) {
	const value = {
		prevVal: store.prevState,
		currentVal: store.state
	};
	for (const listener of store.listeners) listener(value);
}
function __notifyDerivedListeners(derived) {
	const value = {
		prevVal: derived.prevState,
		currentVal: derived.state
	};
	for (const listener of derived.listeners) listener(value);
}
function __flush(store) {
	if (__batchDepth > 0 && !__initialBatchValues.has(store)) __initialBatchValues.set(store, store.prevState);
	__pendingUpdates.add(store);
	if (__batchDepth > 0) return;
	if (__isFlushing) return;
	try {
		__isFlushing = true;
		while (__pendingUpdates.size > 0) {
			const stores = Array.from(__pendingUpdates);
			__pendingUpdates.clear();
			for (const store2 of stores) {
				store2.prevState = __initialBatchValues.get(store2) ?? store2.prevState;
				__notifyListeners(store2);
			}
			for (const store2 of stores) {
				const derivedVals = __storeToDerived.get(store2);
				if (!derivedVals) continue;
				__depsThatHaveWrittenThisTick.current.push(store2);
				__flush_internals(derivedVals);
			}
			for (const store2 of stores) {
				const derivedVals = __storeToDerived.get(store2);
				if (!derivedVals) continue;
				for (const derived of derivedVals) __notifyDerivedListeners(derived);
			}
		}
	} finally {
		__isFlushing = false;
		__depsThatHaveWrittenThisTick.current = [];
		__initialBatchValues.clear();
	}
}
//#endregion
//#region node_modules/.bun/@tanstack+store@0.8.1/node_modules/@tanstack/store/dist/esm/types.js
function isUpdaterFunction(updater) {
	return typeof updater === "function";
}
//#endregion
//#region node_modules/.bun/@tanstack+store@0.8.1/node_modules/@tanstack/store/dist/esm/store.js
var Store = class {
	constructor(initialState, options) {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = (listener) => {
			var _a, _b;
			this.listeners.add(listener);
			const unsub = (_b = (_a = this.options) == null ? void 0 : _a.onSubscribe) == null ? void 0 : _b.call(_a, listener, this);
			return () => {
				this.listeners.delete(listener);
				unsub?.();
			};
		};
		this.prevState = initialState;
		this.state = initialState;
		this.options = options;
	}
	setState(updater) {
		var _a, _b, _c;
		this.prevState = this.state;
		if ((_a = this.options) == null ? void 0 : _a.updateFn) this.state = this.options.updateFn(this.prevState)(updater);
		else if (isUpdaterFunction(updater)) this.state = updater(this.prevState);
		else this.state = updater;
		(_c = (_b = this.options) == null ? void 0 : _b.onUpdate) == null || _c.call(_b);
		__flush(this);
	}
};
//#endregion
//#region node_modules/.bun/@tanstack+store@0.8.1/node_modules/@tanstack/store/dist/esm/derived.js
var Derived = class Derived {
	constructor(options) {
		this.listeners = /* @__PURE__ */ new Set();
		this._subscriptions = [];
		this.lastSeenDepValues = [];
		this.getDepVals = () => {
			const l = this.options.deps.length;
			const prevDepVals = new Array(l);
			const currDepVals = new Array(l);
			for (let i = 0; i < l; i++) {
				const dep = this.options.deps[i];
				prevDepVals[i] = dep.prevState;
				currDepVals[i] = dep.state;
			}
			this.lastSeenDepValues = currDepVals;
			return {
				prevDepVals,
				currDepVals,
				prevVal: this.prevState ?? void 0
			};
		};
		this.recompute = () => {
			var _a, _b;
			this.prevState = this.state;
			const depVals = this.getDepVals();
			this.state = this.options.fn(depVals);
			(_b = (_a = this.options).onUpdate) == null || _b.call(_a);
		};
		this.checkIfRecalculationNeededDeeply = () => {
			for (const dep of this.options.deps) if (dep instanceof Derived) dep.checkIfRecalculationNeededDeeply();
			let shouldRecompute = false;
			const lastSeenDepValues = this.lastSeenDepValues;
			const { currDepVals } = this.getDepVals();
			for (let i = 0; i < currDepVals.length; i++) if (currDepVals[i] !== lastSeenDepValues[i]) {
				shouldRecompute = true;
				break;
			}
			if (shouldRecompute) this.recompute();
		};
		this.mount = () => {
			this.registerOnGraph();
			this.checkIfRecalculationNeededDeeply();
			return () => {
				this.unregisterFromGraph();
				for (const cleanup of this._subscriptions) cleanup();
			};
		};
		this.subscribe = (listener) => {
			var _a, _b;
			this.listeners.add(listener);
			const unsub = (_b = (_a = this.options).onSubscribe) == null ? void 0 : _b.call(_a, listener, this);
			return () => {
				this.listeners.delete(listener);
				unsub?.();
			};
		};
		this.options = options;
		this.state = options.fn({
			prevDepVals: void 0,
			prevVal: void 0,
			currDepVals: this.getDepVals().currDepVals
		});
	}
	registerOnGraph(deps = this.options.deps) {
		for (const dep of deps) if (dep instanceof Derived) {
			dep.registerOnGraph();
			this.registerOnGraph(dep.options.deps);
		} else if (dep instanceof Store) {
			let relatedLinkedDerivedVals = __storeToDerived.get(dep);
			if (!relatedLinkedDerivedVals) {
				relatedLinkedDerivedVals = /* @__PURE__ */ new Set();
				__storeToDerived.set(dep, relatedLinkedDerivedVals);
			}
			relatedLinkedDerivedVals.add(this);
			let relatedStores = __derivedToStore.get(this);
			if (!relatedStores) {
				relatedStores = /* @__PURE__ */ new Set();
				__derivedToStore.set(this, relatedStores);
			}
			relatedStores.add(dep);
		}
	}
	unregisterFromGraph(deps = this.options.deps) {
		for (const dep of deps) if (dep instanceof Derived) this.unregisterFromGraph(dep.options.deps);
		else if (dep instanceof Store) {
			const relatedLinkedDerivedVals = __storeToDerived.get(dep);
			if (relatedLinkedDerivedVals) relatedLinkedDerivedVals.delete(this);
			const relatedStores = __derivedToStore.get(this);
			if (relatedStores) relatedStores.delete(dep);
		}
	}
};
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/async-retryer.js
/**
* Creates the default initial state for an AsyncRetryer instance
* @returns The default state with all values reset to initial values
*/
function getDefaultAsyncRetryerState() {
	return {
		currentAttempt: 0,
		executionCount: 0,
		isExecuting: false,
		lastError: void 0,
		lastExecutionTime: 0,
		lastResult: void 0,
		status: "idle",
		totalExecutionTime: 0
	};
}
/**
* Utility function for sharing common `AsyncRetryerOptions` options between different `AsyncRetryer` instances.
*/
function asyncRetryerOptions(options) {
	return options;
}
var defaultOptions$10 = {
	backoff: "exponential",
	baseWait: 1e3,
	maxWait: Infinity,
	enabled: true,
	jitter: 0,
	maxAttempts: 3,
	maxExecutionTime: Infinity,
	maxTotalExecutionTime: Infinity,
	throwOnError: "last"
};
/**
* Provides robust retry functionality for asynchronous functions, supporting configurable backoff strategies,
* attempt limits, timeout controls, and detailed state management. The AsyncRetryer class is designed to help you reliably
* execute async operations that may fail intermittently, such as network requests or database operations,
* by automatically retrying them according to your chosen policy.
*
* ## Retrying Concepts
*
* - **Retrying**: Automatically re-executes a failed async function up to a specified number of attempts.
*   Useful for handling transient errors (e.g., network flakiness, rate limits, temporary server issues).
* - **Backoff Strategies**: Controls the delay between retry attempts (default: `'exponential'`):
*   - `'exponential'`: Wait time doubles with each attempt (1s, 2s, 4s, ...) - **DEFAULT**
*   - `'linear'`: Wait time increases linearly (1s, 2s, 3s, ...)
*   - `'fixed'`: Waits a constant amount of time (`baseWait`) between each attempt
* - **Jitter**: Adds randomness to retry delays to prevent thundering herd problems (default: `0`).
*   Set to a value between 0-1 to apply that percentage of random variation to each delay.
* - **Max Wait**: Caps the maximum wait time between retries (default: `Infinity`).
*   Useful for preventing exponential backoff from growing too large (e.g., cap at 30s even if exponential would be 64s).
* - **Timeout Controls**: Set limits on execution time to prevent hanging operations:
*   - `maxExecutionTime`: Maximum time for a single function call (default: `Infinity`)
*   - `maxTotalExecutionTime`: Maximum time for the entire retry operation (default: `Infinity`)
* - **Abort & Cancellation**: Supports cancellation via an internal `AbortController`. Call `abort()` to stop retries.
*   Use `getAbortSignal()` to make your async function actually cancellable (e.g., with fetch requests).
*
* ## State Management
*
* Uses TanStack Store for fine-grained reactivity. State can be accessed via the `store.state` property.
*
* Available state properties:
* - `currentAttempt`: The current retry attempt number (0 when not executing)
* - `executionCount`: Total number of completed executions (successful or failed)
* - `isExecuting`: Whether the retryer is currently executing the function
* - `lastError`: The most recent error encountered during execution
* - `lastExecutionTime`: Timestamp of the last execution completion in milliseconds
* - `lastResult`: The result from the most recent successful execution
* - `status`: Current execution status ('disabled' | 'idle' | 'executing' | 'retrying')
* - `totalExecutionTime`: Total time spent executing (including retries) in milliseconds
*
* ## Error Handling
*
* The `throwOnError` option controls when errors are thrown (default: `'last'`):
* - `'last'`: Only throws the final error after all retries are exhausted - **DEFAULT**
* - `true`: Throws every error immediately (disables retrying)
* - `false`: Never throws errors, returns `undefined` instead
*
* Callbacks for lifecycle management:
* - `onAbort`: Called when execution is aborted (manually or due to timeouts)
* - `onError`: Called for every error (including during retries)
* - `onLastError`: Called only for the final error after all retries fail
* - `onRetry`: Called before each retry attempt
* - `onSettled`: Called after execution completes (success or failure) of each attempt
* - `onSuccess`: Called when execution succeeds
* - `onExecutionTimeout`: Called when a single execution attempt times out
* - `onTotalExecutionTimeout`: Called when the total execution time times out
*
* ## Usage
*
* - Use for async operations that may fail transiently and benefit from retrying.
* - Configure `maxAttempts`, `backoff`, `baseWait`, `maxWait`, and `jitter` to control retry behavior.
* - Set `maxExecutionTime` and `maxTotalExecutionTime` to prevent hanging operations.
* - Use `onAbort`, `onError`, `onLastError`, `onRetry`, `onSettled`, `onSuccess`, `onExecutionTimeout`, and `onTotalExecutionTimeout` for custom side effects.
* - Call `abort()` to cancel ongoing execution and pending retries.
* - Call `reset()` to reset state and cancel execution.
* - Use `getAbortSignal()` to make your async function cancellable.
* - Use dynamic options (functions) for `maxAttempts`, `baseWait`, and `enabled` based on retryer state.
*
* **Important:** This class is designed for single-use execution. Calling `execute()` multiple times
* on the same instance will abort previous executions. For multiple calls, create a new instance
* each time.
*
* @example
* ```typescript
* // Retry a fetch operation up to 5 times with exponential backoff, jitter, and timeouts
* const retryer = new AsyncRetryer(async (url: string) => {
*   const signal = retryer.getAbortSignal()
*   return await fetch(url, { signal })
* }, {
*   maxAttempts: 5,
*   backoff: 'exponential',
*   baseWait: 1000,
*   jitter: 0.1, // Add 10% random variation to prevent thundering herd
*   maxExecutionTime: 5000, // Abort individual calls after 5 seconds
*   maxTotalExecutionTime: 30000, // Abort entire operation after 30 seconds
*   onRetry: (attempt, error) => console.log(`Retry attempt ${attempt} after error:`, error),
*   onSuccess: (result) => console.log('Success:', result),
*   onError: (error) => console.error('Error:', error),
*   onLastError: (error) => console.error('All retries failed:', error),
* })
*
* const result = await retryer.execute('/api/data')
* ```
*
* @template TFn The async function type to be retried.
*/
var AsyncRetryer = class {
	#abortController = null;
	/**
	* Creates a new AsyncRetryer instance
	* @param fn The async function to retry
	* @param initialOptions Configuration options for the retryer
	*/
	constructor(fn, initialOptions = {}) {
		this.fn = fn;
		this.store = new Store(getDefaultAsyncRetryerState());
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.execute = async (...args) => {
			if (!this.#getEnabled()) return;
			this.abort("new-execution");
			const startTime = Date.now();
			let lastError;
			let result;
			this.#abortController = new AbortController();
			const signal = this.#abortController.signal;
			this.#setState({
				isExecuting: true,
				currentAttempt: 0,
				lastError: void 0
			});
			let totalTimeoutId;
			if (this.options.maxTotalExecutionTime !== Infinity) totalTimeoutId = setTimeout(() => {
				this.options.onTotalExecutionTimeout?.(this);
				this.abort("total-timeout");
			}, this.options.maxTotalExecutionTime);
			let isLastAttempt = false;
			for (let attempt = 1; attempt <= this.#getMaxAttempts(); attempt++) {
				isLastAttempt = attempt === this.#getMaxAttempts();
				this.#setState({ currentAttempt: attempt });
				try {
					if (signal.aborted) return;
					const currentTotalTime = Date.now() - startTime;
					if (this.options.maxTotalExecutionTime !== Infinity && currentTotalTime >= this.options.maxTotalExecutionTime) {
						this.options.onTotalExecutionTimeout?.(this);
						this.abort("total-timeout");
						return;
					}
					if (this.options.maxExecutionTime === Infinity) result = await this.fn(...args);
					else result = await Promise.race([this.fn(...args), new Promise((_, reject) => {
						const timeout = setTimeout(() => {
							this.options.onExecutionTimeout?.(this);
							this.abort("execution-timeout");
							reject(/* @__PURE__ */ new Error(`Execution timeout: ${this.options.maxExecutionTime}ms exceeded`));
						}, this.options.maxExecutionTime);
						signal.addEventListener("abort", () => {
							clearTimeout(timeout);
							reject(/* @__PURE__ */ new Error("Aborted"));
						}, { once: true });
					})]);
					if (signal.aborted) return;
					const totalTime = Date.now() - startTime;
					this.#setState({
						executionCount: this.store.state.executionCount + 1,
						isExecuting: false,
						lastExecutionTime: Date.now(),
						totalExecutionTime: totalTime,
						currentAttempt: 0,
						lastResult: result
					});
					this.options.onSuccess?.(result, args, this);
					return result;
				} catch (error) {
					if (error && typeof error === "object" && "name" in error && error.name === "AbortError") return;
					lastError = error instanceof Error ? error : new Error(String(error));
					this.#setState({ lastError });
					this.options.onError?.(lastError, args, this);
					if (attempt < this.#getMaxAttempts()) {
						this.options.onRetry?.(attempt, lastError, this);
						const wait = this.#calculateWait(attempt);
						if (wait > 0) {
							this.#setState({
								isExecuting: true,
								currentAttempt: attempt + 1
							});
							await new Promise((resolve) => {
								const timeout = setTimeout(() => {
									signal.removeEventListener("abort", onAbort);
									resolve();
								}, wait);
								const onAbort = () => {
									clearTimeout(timeout);
									signal.removeEventListener("abort", onAbort);
									resolve();
								};
								signal.addEventListener("abort", onAbort);
							});
							if (signal.aborted) return;
						}
					}
				} finally {
					this.options.onSettled?.(args, this);
				}
			}
			if (totalTimeoutId) clearTimeout(totalTimeoutId);
			this.#setState({ isExecuting: false });
			this.options.onLastError?.(lastError, this);
			this.options.onSettled?.(args, this);
			if (this.options.throwOnError === "last" && isLastAttempt || this.options.throwOnError === true) throw lastError;
		};
		this.getAbortSignal = () => {
			return this.#abortController?.signal ?? null;
		};
		this.abort = (reason = "manual") => {
			if (this.#abortController) {
				this.#abortController.abort();
				this.#abortController = null;
				this.#setState({ isExecuting: false });
				this.options.onAbort?.(reason, this);
			}
		};
		this.reset = () => {
			this.#setState(getDefaultAsyncRetryerState());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$10,
			...initialOptions,
			throwOnError: initialOptions.throwOnError ?? (initialOptions.onError ? false : defaultOptions$10.throwOnError)
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-AsyncRetryer", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isExecuting, currentAttempt } = combinedState;
			return {
				...combinedState,
				status: !this.#getEnabled() ? "disabled" : isExecuting && currentAttempt === 1 ? "executing" : isExecuting && currentAttempt > 1 ? "retrying" : "idle"
			};
		});
		emitChange("AsyncRetryer", this);
	};
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	#getMaxAttempts = () => {
		return parseFunctionOrValue(this.options.maxAttempts, this);
	};
	#getBaseWait = () => {
		return parseFunctionOrValue(this.options.baseWait, this);
	};
	#getMaxWait = () => {
		return parseFunctionOrValue(this.options.maxWait, this);
	};
	#calculateJitter = (waitTime) => {
		const jitterAmount = this.options.jitter;
		if (jitterAmount <= 0) return 0;
		try {
			const crypto = typeof globalThis !== "undefined" ? globalThis.crypto : void 0;
			if (crypto?.getRandomValues) {
				const array = /* @__PURE__ */ new Uint32Array(1);
				crypto.getRandomValues(array);
				const randomFactor = array[0] / 4294967295 * 2 - 1;
				return Math.floor(waitTime * jitterAmount * randomFactor);
			}
		} catch {}
		return 0;
	};
	#calculateWait = (attempt) => {
		const baseWait = this.#getBaseWait();
		let waitTime;
		switch (this.options.backoff) {
			case "linear":
				waitTime = baseWait * attempt;
				break;
			case "exponential":
				waitTime = baseWait * Math.pow(2, attempt - 1);
				break;
			default:
				waitTime = baseWait;
				break;
		}
		waitTime = Math.min(waitTime, this.#getMaxWait());
		const jitter = this.#calculateJitter(waitTime);
		return Math.max(0, waitTime + jitter);
	};
};
/**
* Creates a retry-enabled version of an async function. This is a convenience wrapper
* around the AsyncRetryer class that returns the execute method.
*
* @param fn The async function to add retry functionality to
* @param initialOptions Configuration options for the retry behavior
* @returns A new function that executes the original with retry logic
*
* @example
* ```typescript
* // Define your async function normally
* async function fetchData(url: string) {
*   const response = await fetch(url)
*   if (!response.ok) throw new Error('Request failed')
*   return response.json()
* }
*
* // Create retry-enabled function
* const fetchWithRetry = asyncRetry(fetchData, {
*   maxAttempts: 3,
*   backoff: 'exponential',
*   baseWait: 1000,
*   jitter: 0.1
* })
*
* // Call it multiple times
* const data1 = await fetchWithRetry('/api/data1')
* const data2 = await fetchWithRetry('/api/data2')
* ```
*/
function asyncRetry(fn, initialOptions = {}) {
	return new AsyncRetryer(fn, initialOptions).execute;
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/async-batcher.js
function getDefaultAsyncBatcherState() {
	return {
		errorCount: 0,
		executeCount: 0,
		failedItems: [],
		isEmpty: true,
		isExecuting: false,
		isPending: false,
		items: [],
		lastResult: void 0,
		settleCount: 0,
		size: 0,
		status: "idle",
		successCount: 0,
		totalItemsProcessed: 0,
		totalItemsFailed: 0
	};
}
/**
* Utility function for sharing common `AsyncBatcherOptions` options between different `AsyncBatcher` instances.
*
*/
function asyncBatcherOptions(options) {
	return options;
}
var defaultOptions$9 = {
	asyncRetryerOptions: { maxAttempts: 1 },
	getShouldExecute: () => false,
	maxSize: Infinity,
	started: true,
	throwOnError: true,
	wait: Infinity
};
/**
* A class that collects items and processes them in batches asynchronously.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync Batcher:
* - Returns promises that can be awaited for batch results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight batch executions
* - Cancel support to prevent pending batches from starting
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
*
* The sync Batcher is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Batching?
* Batching is a technique for grouping multiple operations together to be processed as a single unit.
*
* The AsyncBatcher provides a flexible way to implement async batching with configurable:
* - Maximum batch size (number of items per batch)
* - Time-based batching (process after X milliseconds)
* - Custom batch processing logic via getShouldExecute
* - Event callbacks for monitoring batch operations
* - Error handling for failed batch operations
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error, the batch of items that failed, and batcher instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the AsyncBatcher instance
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async batcher
* - Use `onSuccess` callback to react to successful batch execution and implement custom logic
* - Use `onError` callback to react to batch execution errors and implement custom error handling
* - Use `onSettled` callback to react to batch execution completion (success or error) and implement custom logic
* - Use `onExecute` callback to react to batch execution and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the batcher
* - The state includes total items processed, success/error counts, and execution status
* - State can be accessed via `asyncBatcher.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `asyncBatcher.state`
*
* @example
* ```ts
* const batcher = new AsyncBatcher<number>(
*   async (items) => {
*     const result = await processItems(items);
*     console.log('Processing batch:', items);
*     return result;
*   },
*   {
*     maxSize: 5,
*     wait: 2000,
*     onSuccess: (result) => console.log('Batch succeeded:', result),
*     onError: (error) => console.error('Batch failed:', error)
*   }
* );
*
* batcher.addItem(1);
* batcher.addItem(2);
* // After 2 seconds or when 5 items are added, whichever comes first,
* // the batch will be processed and the result will be available
* // batcher.execute() // manually trigger a batch
* ```
*/
var AsyncBatcher = class {
	#timeoutId = null;
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultAsyncBatcherState());
		this.asyncRetryers = /* @__PURE__ */ new Map();
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.addItem = async (item) => {
			this.#setState({
				items: [...this.store.state.items, item],
				isPending: this.options.wait !== Infinity
			});
			this.options.onItemsChange?.(this);
			if (this.store.state.items.length >= this.options.maxSize || this.options.getShouldExecute(this.store.state.items, this)) return await this.#execute();
			else if (this.options.wait !== Infinity) {
				this.#clearTimeout();
				this.#timeoutId = setTimeout(() => this.#execute(), this.#getWait());
				await new Promise((resolve) => setTimeout(resolve, this.#getWait()));
			}
		};
		this.flush = async () => {
			this.#clearTimeout();
			return await this.#execute();
		};
		this.peekAllItems = () => {
			return [...this.store.state.items];
		};
		this.peekFailedItems = () => {
			return [...this.store.state.failedItems];
		};
		this.clear = () => {
			this.#setState({
				items: [],
				failedItems: [],
				isPending: false
			});
		};
		this.getAbortSignal = (executeCount) => {
			const count = executeCount ?? this.store.state.executeCount;
			return this.asyncRetryers.get(count)?.getAbortSignal() ?? null;
		};
		this.abort = () => {
			this.asyncRetryers.forEach((retryer) => retryer.abort());
			this.asyncRetryers.clear();
			this.#setState({ isExecuting: false });
		};
		this.cancel = () => {
			this.#clearTimeout();
			this.#setState({ isPending: false });
		};
		this.reset = () => {
			this.#setState(getDefaultAsyncBatcherState());
			this.options.onItemsChange?.(this);
			this.asyncRetryers.forEach((retryer) => retryer.reset());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$9,
			...initialOptions,
			throwOnError: initialOptions.throwOnError ?? !initialOptions.onError
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-AsyncBatcher", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isExecuting, isPending, items } = combinedState;
			const size = items.length;
			const isEmpty = size === 0;
			return {
				...combinedState,
				isEmpty,
				size,
				status: isExecuting ? "executing" : isPending ? "pending" : isEmpty ? "idle" : "populated"
			};
		});
		emitChange("AsyncBatcher", this);
	};
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait, this);
	};
	/**
	* Processes the current batch of items asynchronously.
	* This method will automatically be triggered if the batcher is running and any of these conditions are met:
	* - The number of items reaches maxSize
	* - The wait duration has elapsed
	* - The getShouldExecute function returns true upon adding an item
	*
	* You can also call this method manually to process the current batch at any time.
	*
	* @returns A promise that resolves with the result of the batch function, or undefined if an error occurred and was handled by onError
	* @throws The error from the batch function if no onError handler is configured or throwOnError is true
	*/
	#execute = async () => {
		if (this.store.state.items.length === 0) return;
		const currentExecuteCount = this.store.state.executeCount + 1;
		const batch = this.peekAllItems();
		this.clear();
		this.options.onItemsChange?.(this);
		this.#setState({
			isExecuting: true,
			executeCount: currentExecuteCount
		});
		try {
			const currentAsyncRetryer = new AsyncRetryer(this.fn, this.options.asyncRetryerOptions);
			this.asyncRetryers.set(currentExecuteCount, currentAsyncRetryer);
			const result = await currentAsyncRetryer.execute(batch);
			this.#setState({
				totalItemsProcessed: this.store.state.totalItemsProcessed + batch.length,
				lastResult: result,
				successCount: this.store.state.successCount + 1
			});
			this.options.onSuccess?.(result, batch, this);
			return result;
		} catch (error) {
			this.#setState({
				errorCount: this.store.state.errorCount + 1,
				failedItems: [...this.store.state.failedItems, ...batch],
				totalItemsFailed: this.store.state.totalItemsFailed + batch.length
			});
			this.options.onError?.(error, batch, this);
			if (this.options.throwOnError) throw error;
			return;
		} finally {
			this.asyncRetryers.delete(currentExecuteCount);
			this.#setState({
				isExecuting: false,
				settleCount: this.store.state.settleCount + 1
			});
			this.options.onSettled?.(batch, this);
		}
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = null;
		}
	};
};
/**
* Creates an async batcher that processes items in batches.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync batch function:
* - Returns promises that can be awaited for batch results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight batch executions
* - Cancel support to prevent pending batches from starting
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
*
* The sync batch function is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Batching?
* Batching is a technique for grouping multiple operations together to be processed as a single unit.
*
* Configuration Options:
* - `maxSize`: Maximum number of items per batch (default: Infinity)
* - `wait`: Time to wait before processing batch (default: Infinity)
* - `getShouldExecute`: Custom logic to trigger batch processing
* - `asyncRetryerOptions`: Configure retry behavior for batch executions
* - `started`: Whether to start processing immediately (default: true)
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error, the batch of items that failed, and batcher instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncBatcher instance
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async batcher
* - Use `onSuccess` callback to react to successful batch execution and implement custom logic
* - Use `onError` callback to react to batch execution errors and implement custom error handling
* - Use `onSettled` callback to react to batch execution completion (success or error) and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the batcher
* - The state includes total items processed, success/error counts, and execution status
* - State can be accessed via the underlying AsyncBatcher instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* @example
* ```ts
* const batchItems = asyncBatch<number>(
*   async (items) => {
*     const result = await processApiCall(items);
*     console.log('Processing:', items);
*     return result;
*   },
*   {
*     maxSize: 3,
*     wait: 1000,
*     onSuccess: (result) => console.log('Batch succeeded:', result),
*     onError: (error) => console.error('Batch failed:', error)
*   }
* );
*
* batchItems(1);
* batchItems(2);
* batchItems(3); // Triggers batch processing
* ```
*/
function asyncBatch(fn, options) {
	return new AsyncBatcher(fn, options).addItem;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-store@0.8.1+bf16f8eded5e12ee/node_modules/@tanstack/react-store/dist/esm/index.js
var import_with_selector = require_with_selector();
function useStore(store, selector = (d) => d, options = {}) {
	const equal = options.equal ?? shallow;
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(store.subscribe, () => store.state, () => store.state, selector, equal);
}
function shallow(objA, objB) {
	if (Object.is(objA, objB)) return true;
	if (typeof objA !== "object" || objA === null || typeof objB !== "object" || objB === null) return false;
	if (objA instanceof Map && objB instanceof Map) {
		if (objA.size !== objB.size) return false;
		for (const [k, v] of objA) if (!objB.has(k) || !Object.is(v, objB.get(k))) return false;
		return true;
	}
	if (objA instanceof Set && objB instanceof Set) {
		if (objA.size !== objB.size) return false;
		for (const v of objA) if (!objB.has(v)) return false;
		return true;
	}
	if (objA instanceof Date && objB instanceof Date) {
		if (objA.getTime() !== objB.getTime()) return false;
		return true;
	}
	const keysA = getOwnKeys(objA);
	if (keysA.length !== getOwnKeys(objB).length) return false;
	for (let i = 0; i < keysA.length; i++) if (!Object.prototype.hasOwnProperty.call(objB, keysA[i]) || !Object.is(objA[keysA[i]], objB[keysA[i]])) return false;
	return true;
}
function getOwnKeys(obj) {
	return Object.keys(obj).concat(Object.getOwnPropertySymbols(obj));
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-batcher/useAsyncBatcher.js
/**
* A React hook that creates an `AsyncBatcher` instance for managing asynchronous batches of items.
*
* This is the async version of the useBatcher hook. Unlike the sync version, this async batcher:
* - Handles promises and returns results from batch executions
* - Provides error handling with configurable error behavior
* - Tracks success, error, and settle counts separately
* - Has state tracking for when batches are executing
* - Returns the result of the batch function execution
*
* Features:
* - Configurable batch size and wait time
* - Custom batch processing logic via getShouldExecute
* - Event callbacks for monitoring batch operations
* - Error handling for failed batch operations
* - Automatic or manual batch processing
*
* The batcher collects items and processes them in batches based on:
* - Maximum batch size (number of items per batch)
* - Time-based batching (process after X milliseconds)
* - Custom batch processing logic via getShouldExecute
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and batcher instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncBatcher instance
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `batcher.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `errorCount`: Number of batch executions that have resulted in errors
* - `failedItems`: Array of items that failed during batch processing
* - `isEmpty`: Whether the batcher has no items to process
* - `isExecuting`: Whether a batch is currently being processed asynchronously
* - `isPending`: Whether the batcher is waiting for the timeout to trigger batch processing
* - `isRunning`: Whether the batcher is active and will process items automatically
* - `items`: Array of items currently queued for batch processing
* - `lastResult`: The result from the most recent batch execution
* - `settleCount`: Number of batch executions that have completed (success or error)
* - `size`: Number of items currently in the batch queue
* - `status`: Current processing status ('idle' | 'pending' | 'executing' | 'populated')
* - `successCount`: Number of batch executions that have completed successfully
* - `totalItemsProcessed`: Total number of items processed across all batches
* - `totalItemsFailed`: Total number of items that have failed processing
*
* @example
* ```tsx
* // Basic async batcher for API requests - no reactive state subscriptions
* const asyncBatcher = useAsyncBatcher(
*   async (items) => {
*     const results = await Promise.all(items.map(item => processItem(item)));
*     return results;
*   },
*   { maxSize: 10, wait: 2000 }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <asyncBatcher.Subscribe selector={(state) => ({ size: state.size, isExecuting: state.isExecuting })}>
*   {({ size, isExecuting }) => (
*     <div>Batch: {size} items, {isExecuting ? 'Processing' : 'Ready'}</div>
*   )}
* </asyncBatcher.Subscribe>
*
* // Opt-in to re-render when execution state changes at hook level (optimized for loading indicators)
* const asyncBatcher = useAsyncBatcher(
*   async (items) => {
*     const results = await Promise.all(items.map(item => processItem(item)));
*     return results;
*   },
*   { maxSize: 10, wait: 2000 },
*   (state) => ({
*     isExecuting: state.isExecuting,
*     isPending: state.isPending,
*     status: state.status
*   })
* );
*
* // Opt-in to re-render when results are available (optimized for data display)
* const asyncBatcher = useAsyncBatcher(
*   async (items) => {
*     const results = await Promise.all(items.map(item => processItem(item)));
*     return results;
*   },
*   { maxSize: 10, wait: 2000 },
*   (state) => ({
*     lastResult: state.lastResult,
*     successCount: state.successCount,
*     totalItemsProcessed: state.totalItemsProcessed
*   })
* );
*
* // Opt-in to re-render when error state changes (optimized for error handling)
* const asyncBatcher = useAsyncBatcher(
*   async (items) => {
*     const results = await Promise.all(items.map(item => processItem(item)));
*     return results;
*   },
*   {
*     maxSize: 10,
*     wait: 2000,
*     onError: (error) => console.error('Batch processing failed:', error)
*   },
*   (state) => ({
*     errorCount: state.errorCount,
*     failedItems: state.failedItems,
*     totalItemsFailed: state.totalItemsFailed
*   })
* );
*
* // Complete example with all callbacks
* const asyncBatcher = useAsyncBatcher(
*   async (items) => {
*     const results = await Promise.all(items.map(item => processItem(item)));
*     return results;
*   },
*   {
*     maxSize: 10,
*     wait: 2000,
*     onSuccess: (result) => {
*       console.log('Batch processed successfully:', result);
*     },
*     onError: (error) => {
*       console.error('Batch processing failed:', error);
*     }
*   }
* );
*
* // Add items to batch
* asyncBatcher.addItem(newItem);
*
* // Manually execute batch
* const result = await asyncBatcher.execute();
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { isExecuting, lastResult, size } = asyncBatcher.state;
* ```
*/
function useAsyncBatcher(fn, options = {}, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().asyncBatcher,
		...options
	};
	const [asyncBatcher] = (0, import_react.useState)(() => {
		const asyncBatcherInstance = new AsyncBatcher(fn, mergedOptions);
		asyncBatcherInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(asyncBatcherInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return asyncBatcherInstance;
	});
	asyncBatcher.fn = fn;
	asyncBatcher.setOptions(mergedOptions);
	const state = useStore(asyncBatcher.store, selector);
	return (0, import_react.useMemo)(() => ({
		...asyncBatcher,
		state
	}), [asyncBatcher, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-batcher/useAsyncBatchedCallback.js
/**
* A React hook that creates a batched version of an async callback function.
* This hook is a convenient wrapper around the `useAsyncBatcher` hook,
* providing a stable, batched async function reference for use in React components.
*
* The batched async function will collect individual calls into batches and execute them
* when batch conditions are met (max size reached, wait time elapsed, or custom logic).
* The returned function always returns a promise that resolves with undefined (since the
* batch function processes multiple items together).
*
* This hook provides a simpler API compared to `useAsyncBatcher`, making it ideal for basic
* async batching needs. However, it does not expose the underlying AsyncBatcher instance.
*
* For advanced usage requiring features like:
* - Manual batch execution
* - Access to batch results and state
* - Custom useCallback dependencies
*
* Consider using the `useAsyncBatcher` hook instead.
*
* @example
* ```tsx
* // Batch API requests
* const batchApiCall = useAsyncBatchedCallback(async (requests: ApiRequest[]) => {
*   const results = await Promise.all(requests.map(req => fetch(req.url)));
*   return results.map(res => res.json());
* }, {
*   maxSize: 10,   // Process when 10 requests collected
*   wait: 1000     // Or after 1 second
* });
*
* // Use in event handlers
* <button onClick={() => batchApiCall({ url: '/api/analytics', data: eventData })}>
*   Track Event
* </button>
* ```
*/
function useAsyncBatchedCallback(fn, options) {
	const asyncBatchedFn = useAsyncBatcher(fn, options).addItem;
	return (0, import_react.useCallback)(async (...args) => {
		asyncBatchedFn(args[0]);
	}, [asyncBatchedFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/async-debouncer.js
function getDefaultAsyncDebouncerState() {
	return {
		canLeadingExecute: true,
		errorCount: 0,
		isExecuting: false,
		isPending: false,
		lastArgs: void 0,
		lastResult: void 0,
		maybeExecuteCount: 0,
		settleCount: 0,
		status: "idle",
		successCount: 0
	};
}
/**
* Utility function for sharing common `AsyncDebouncerOptions` options between different `AsyncDebouncer` instances.
*/
function asyncDebouncerOptions(options) {
	return options;
}
var defaultOptions$8 = {
	asyncRetryerOptions: { maxAttempts: 1 },
	enabled: true,
	leading: false,
	trailing: true,
	wait: 0
};
/**
* A class that creates an async debounced function.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync Debouncer:
* - Returns promises that can be awaited for debounced function results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight executions
* - Cancel support to prevent pending executions from starting
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
*
* The sync Debouncer is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Debouncing?
* Debouncing ensures that a function is only executed after a specified delay has passed since its last invocation.
* Each new invocation resets the delay timer. This is useful for handling frequent events like window resizing
* or input changes where you only want to execute the handler after the events have stopped occurring.
*
* Unlike throttling which allows execution at regular intervals, debouncing prevents any execution until
* the function stops being called for the specified delay period.
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and debouncer instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying store
*
* State Management:
* - The debouncer uses a reactive store for state management
* - Use `initialState` to provide initial state values when creating the async debouncer
* - The state includes canLeadingExecute, error count, execution status, and success/settle counts
* - State can be accessed via the `store` property and its `state` getter
* - The store is reactive and will notify subscribers of state changes
*
* @example
* ```ts
* const asyncDebouncer = new AsyncDebouncer(async (value: string) => {
*   const results = await searchAPI(value);
*   return results; // Return value is preserved
* }, {
*   wait: 500,
*   onError: (error) => {
*     console.error('Search failed:', error);
*   }
* });
*
* // Called on each keystroke but only executes after 500ms of no typing
* // Returns the API response directly
* const results = await asyncDebouncer.maybeExecute(inputElement.value);
* ```
*/
var AsyncDebouncer = class {
	#timeoutId = null;
	#resolvePreviousPromise = null;
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultAsyncDebouncerState());
		this.asyncRetryers = /* @__PURE__ */ new Map();
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
			if (!this.#getEnabled()) this.cancel();
		};
		this.maybeExecute = async (...args) => {
			if (!this.#getEnabled()) return void 0;
			this.#cancelPendingExecution();
			this.#setState({
				lastArgs: args,
				maybeExecuteCount: this.store.state.maybeExecuteCount + 1
			});
			if (this.options.leading && this.store.state.canLeadingExecute) {
				this.#setState({ canLeadingExecute: false });
				await this.#execute(...args);
				return this.store.state.lastResult;
			}
			if (this.options.trailing && this.#getEnabled()) this.#setState({ isPending: true });
			return new Promise((resolve, reject) => {
				this.#resolvePreviousPromise = resolve;
				this.#timeoutId = setTimeout(async () => {
					if (this.options.trailing && this.store.state.lastArgs) try {
						await this.#execute(...this.store.state.lastArgs);
					} catch (error) {
						reject(error);
					}
					this.#setState({ canLeadingExecute: true });
					this.#resolvePreviousPromise = null;
					resolve(this.store.state.lastResult);
				}, this.#getWait());
			});
		};
		this.flush = async () => {
			if (this.store.state.isPending && this.store.state.lastArgs) {
				const { lastArgs } = this.store.state;
				this.#cancelPendingExecution();
				return await this.#execute(...lastArgs);
			}
		};
		this.getAbortSignal = (maybeExecuteCount) => {
			const count = maybeExecuteCount ?? this.store.state.maybeExecuteCount;
			return this.asyncRetryers.get(count)?.getAbortSignal() ?? null;
		};
		this.abort = () => {
			this.asyncRetryers.forEach((retryer) => retryer.abort());
			this.asyncRetryers.clear();
			this.#setState({ isExecuting: false });
		};
		this.cancel = () => {
			this.#cancelPendingExecution();
			this.#setState({ canLeadingExecute: true });
		};
		this.reset = () => {
			this.#setState(getDefaultAsyncDebouncerState());
			this.asyncRetryers.forEach((retryer) => retryer.reset());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$8,
			...initialOptions,
			throwOnError: initialOptions.throwOnError ?? !initialOptions.onError
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-AsyncDebouncer", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isPending, isExecuting, settleCount } = combinedState;
			return {
				...combinedState,
				status: !this.#getEnabled() ? "disabled" : isPending ? "pending" : isExecuting ? "executing" : settleCount > 0 ? "settled" : "idle"
			};
		});
		emitChange("AsyncDebouncer", this);
	};
	/**
	* Returns the current debouncer enabled state
	*/
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	/**
	* Returns the current debouncer wait state
	*/
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait, this);
	};
	#execute = async (...args) => {
		if (!this.#getEnabled()) return void 0;
		const currentMaybeExecuteCount = this.store.state.maybeExecuteCount + 1;
		try {
			this.#setState({ isExecuting: true });
			const currentAsyncRetryer = new AsyncRetryer(this.fn, {
				...this.options.asyncRetryerOptions,
				key: `${this.key}-retryer-${currentMaybeExecuteCount}`
			});
			this.asyncRetryers.set(currentMaybeExecuteCount, currentAsyncRetryer);
			const result = await currentAsyncRetryer.execute(...args);
			this.#setState({
				lastResult: result,
				successCount: this.store.state.successCount + 1
			});
			this.options.onSuccess?.(result, args, this);
		} catch (error) {
			this.#setState({ errorCount: this.store.state.errorCount + 1 });
			this.options.onError?.(error, args, this);
			if (this.options.throwOnError) throw error;
		} finally {
			this.asyncRetryers.delete(currentMaybeExecuteCount);
			this.#setState({
				isExecuting: false,
				isPending: false,
				lastArgs: void 0,
				settleCount: this.store.state.settleCount + 1
			});
			this.options.onSettled?.(args, this);
		}
		return this.store.state.lastResult;
	};
	#resolvePreviousPromiseInternal = () => {
		if (this.#resolvePreviousPromise) {
			this.#resolvePreviousPromise(this.store.state.lastResult);
			this.#resolvePreviousPromise = null;
		}
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = null;
		}
	};
	/**
	* Internal cancel without resetting the leading execute state
	*/
	#cancelPendingExecution = () => {
		this.#clearTimeout();
		this.#resolvePreviousPromiseInternal();
		this.#setState({
			isPending: false,
			lastArgs: void 0
		});
	};
};
/**
* Creates an async debounced function that delays execution until after a specified wait time.
* The debounced function will only execute once the wait period has elapsed without any new calls.
* If called again during the wait period, the timer resets and a new wait period begins.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync debounce function:
* - Returns promises that can be awaited for debounced function results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight executions
* - Cancel support to prevent pending executions from starting
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
*
* The sync debounce function is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Debouncing?
* Debouncing ensures that a function is only executed after a specified delay has passed since its last invocation.
* Each new invocation resets the delay timer. This is useful for handling frequent events like window resizing
* or input changes where you only want to execute the handler after the events have stopped occurring.
*
* Configuration Options:
* - `wait`: Delay in milliseconds to wait after the last call (required)
* - `leading`: Execute on the leading edge of the timeout (default: false)
* - `trailing`: Execute on the trailing edge of the timeout (default: true)
* - `enabled`: Whether the debouncer is enabled (default: true)
* - `asyncRetryerOptions`: Configure retry behavior for executions
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and debouncer instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - The error state can be checked using the underlying AsyncDebouncer instance
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async debouncer
* - Use `onSuccess` callback to react to successful function execution and implement custom logic
* - Use `onError` callback to react to function execution errors and implement custom error handling
* - Use `onSettled` callback to react to function execution completion (success or error) and implement custom logic
* - The state includes canLeadingExecute, error count, execution status, and success/settle counts
* - State can be accessed via `asyncDebouncer.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `asyncDebouncer.state`
*
* @example
* ```ts
* const debounced = asyncDebounce(async (value: string) => {
*   const result = await saveToAPI(value);
*   return result; // Return value is preserved
* }, {
*   wait: 1000,
*   onError: (error) => {
*     console.error('API call failed:', error);
*   },
*   throwOnError: true // Will both log the error and throw it
* });
*
* // Will only execute once, 1 second after the last call
* // Returns the API response directly
* const result = await debounced("third");
* ```
*/
function asyncDebounce(fn, initialOptions) {
	return new AsyncDebouncer(fn, initialOptions).maybeExecute;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-debouncer/useAsyncDebouncer.js
/**
* A low-level React hook that creates an `AsyncDebouncer` instance to delay execution of an async function.
*
* This hook is designed to be flexible and state-management agnostic - it simply returns a debouncer instance that
* you can integrate with any state management solution (useState, Redux, Zustand, Jotai, etc).
*
* Async debouncing ensures that an async function only executes after a specified delay has passed since its last invocation.
* Each new invocation resets the delay timer. This is useful for handling frequent events like window resizing
* or input changes where you only want to execute the handler after the events have stopped occurring.
*
* Unlike throttling which allows execution at regular intervals, debouncing prevents any execution until
* the function stops being called for the specified delay period.
*
* Unlike the non-async Debouncer, this async version supports returning values from the debounced function,
* making it ideal for API calls and other async operations where you want the result of the `maybeExecute` call
* instead of setting the result on a state variable from within the debounced function.
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and debouncer instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncDebouncer instance
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `debouncer.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `canLeadingExecute`: Whether the debouncer can execute on the leading edge
* - `errorCount`: Number of function executions that have resulted in errors
* - `isExecuting`: Whether the debounced function is currently executing asynchronously
* - `isPending`: Whether the debouncer is waiting for the timeout to trigger execution
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `lastResult`: The result from the most recent successful function execution
* - `settleCount`: Number of function executions that have completed (success or error)
* - `status`: Current execution status ('disabled' | 'idle' | 'pending' | 'executing' | 'settled')
* - `successCount`: Number of function executions that have completed successfully
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const searchDebouncer = useAsyncDebouncer(
*   async (query: string) => {
*     const results = await api.search(query);
*     return results;
*   },
*   { wait: 500 }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <searchDebouncer.Subscribe selector={(state) => ({ isExecuting: state.isExecuting, isPending: state.isPending })}>
*   {({ isExecuting, isPending }) => (
*     <div>{isExecuting || isPending ? 'Loading...' : 'Ready'}</div>
*   )}
* </searchDebouncer.Subscribe>
*
* // Opt-in to re-render when execution state changes at hook level (optimized for loading indicators)
* const searchDebouncer = useAsyncDebouncer(
*   async (query: string) => {
*     const results = await api.search(query);
*     return results;
*   },
*   { wait: 500 },
*   (state) => ({
*     isExecuting: state.isExecuting,
*     isPending: state.isPending
*   })
* );
*
* // Opt-in to re-render when results are available (optimized for data display)
* const searchDebouncer = useAsyncDebouncer(
*   async (query: string) => {
*     const results = await api.search(query);
*     return results;
*   },
*   { wait: 500 },
*   (state) => ({
*     lastResult: state.lastResult,
*     successCount: state.successCount
*   })
* );
*
* // Opt-in to re-render when error state changes (optimized for error handling)
* const searchDebouncer = useAsyncDebouncer(
*   async (query: string) => {
*     const results = await api.search(query);
*     return results;
*   },
*   {
*     wait: 500,
*     onError: (error) => console.error('Search failed:', error)
*   },
*   (state) => ({
*     errorCount: state.errorCount,
*     status: state.status
*   })
* );
*
* // With state management
* const [results, setResults] = useState([]);
* const { maybeExecute, state } = useAsyncDebouncer(
*   async (searchTerm) => {
*     const data = await searchAPI(searchTerm);
*     setResults(data);
*   },
*   {
*     wait: 300,
*     leading: true,   // Execute immediately on first call
*     trailing: false, // Skip trailing edge updates
*     onError: (error) => {
*       console.error('API call failed:', error);
*     }
*   }
* );
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { isExecuting, lastResult } = state;
* ```
*/
function useAsyncDebouncer(fn, options, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().asyncDebouncer,
		...options
	};
	const [asyncDebouncer] = (0, import_react.useState)(() => {
		const asyncDebouncerInstance = new AsyncDebouncer(fn, mergedOptions);
		asyncDebouncerInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(asyncDebouncerInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return asyncDebouncerInstance;
	});
	asyncDebouncer.fn = fn;
	asyncDebouncer.setOptions(mergedOptions);
	const state = useStore(asyncDebouncer.store, selector);
	(0, import_react.useEffect)(() => {
		return () => {
			asyncDebouncer.cancel();
		};
	}, [asyncDebouncer]);
	return (0, import_react.useMemo)(() => ({
		...asyncDebouncer,
		state
	}), [asyncDebouncer, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-debouncer/useAsyncDebouncedCallback.js
/**
* A React hook that creates a debounced version of an async callback function.
* This hook is a convenient wrapper around the `useAsyncDebouncer` hook,
* providing a stable, debounced async function reference for use in React components.
*
* The debounced async function will only execute after the specified wait time has elapsed
* since its last invocation. If called again before the wait time expires, the timer
* resets and starts waiting again. The returned function always returns a promise
* that resolves or rejects with the result of the original async function.
*
* This hook provides a simpler API compared to `useAsyncDebouncer`, making it ideal for basic
* async debouncing needs. However, it does not expose the underlying AsyncDebouncer instance.
*
* For advanced usage requiring features like:
* - Manual cancellation
* - Access to execution/error state
* - Custom useCallback dependencies
*
* Consider using the `useAsyncDebouncer` hook instead.
*
*
* @example
* ```tsx
* // Debounce an async search handler
* const handleSearch = useAsyncDebouncedCallback(async (query: string) => {
*   const results = await fetchSearchResults(query);
*   return results;
* }, {
*   wait: 500 // Wait 500ms between executions
* });
*
* // Use in an input
* <input
*   type="search"
*   onChange={e => handleSearch(e.target.value)}
* />
* ```
*/
function useAsyncDebouncedCallback(fn, options) {
	const asyncDebouncedFn = useAsyncDebouncer(fn, options).maybeExecute;
	return (0, import_react.useCallback)((...args) => asyncDebouncedFn(...args), [asyncDebouncedFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/async-queuer.js
function getDefaultAsyncQueuerState() {
	return {
		activeItems: [],
		addItemCount: 0,
		errorCount: 0,
		executeCount: 0,
		expirationCount: 0,
		isEmpty: true,
		isExecuting: false,
		isFull: false,
		isIdle: true,
		isRunning: true,
		itemTimestamps: [],
		items: [],
		lastResult: null,
		pendingTick: false,
		rejectionCount: 0,
		settledCount: 0,
		size: 0,
		status: "idle",
		successCount: 0
	};
}
/**
* Utility function for sharing common `AsyncQueuerOptions` options between different `AsyncQueuer` instances.
*/
function asyncQueuerOptions(options) {
	return options;
}
var defaultOptions$7 = {
	addItemsTo: "back",
	asyncRetryerOptions: { maxAttempts: 1 },
	concurrency: 1,
	expirationDuration: Infinity,
	getIsExpired: () => false,
	getItemsFrom: "front",
	getPriority: (item) => item?.priority ?? 0,
	initialItems: [],
	maxSize: Infinity,
	started: true,
	wait: 0
};
/**
* A flexible asynchronous queue for processing tasks with configurable concurrency, priority, and expiration.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync Queuer:
* - Returns promises that can be awaited for task results
* - Built-in retry support via AsyncRetryer integration for each queued task
* - Abort support to cancel in-flight task executions
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
* - Concurrent execution support (process multiple items simultaneously)
*
* The sync Queuer is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Queuing?
* Queuing is a technique for managing and processing items sequentially or with controlled concurrency.
* Tasks are processed up to the configured concurrency limit. When a task completes,
* the next pending task is processed if the concurrency limit allows.
*
* Key Features:
* - Priority queue support via the getPriority option
* - Configurable concurrency limit
* - Callbacks for task success, error, completion, and queue state changes
* - FIFO (First In First Out) or LIFO (Last In First Out) queue behavior
* - Pause and resume processing
* - Item expiration to remove stale items from the queue
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and queuer instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together; the handler will be called before any error is thrown
* - The error state can be checked using the AsyncQueuer instance
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async queuer
* - Use `onSuccess` callback to react to successful task execution and implement custom logic
* - Use `onError` callback to react to task execution errors and implement custom error handling
* - Use `onSettled` callback to react to task execution completion (success or error) and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the queue
* - Use `onExpire` callback to react to items expiring and implement custom logic
* - Use `onReject` callback to react to items being rejected when the queue is full
* - The state includes error count, expiration count, rejection count, running status, and success/settle counts
* - State can be accessed via `asyncQueuer.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `asyncQueuer.state`
*
* Example usage:
* ```ts
* const asyncQueuer = new AsyncQueuer<string>(async (item) => {
*   // process item
*   return item.toUpperCase();
* }, {
*   concurrency: 2,
*   onSuccess: (result) => {
*     console.log(result);
*   }
* });
*
* asyncQueuer.addItem('hello');
* asyncQueuer.start();
* ```
*/
var AsyncQueuer = class {
	#timeoutIds = /* @__PURE__ */ new Set();
	constructor(fn, initialOptions = {}) {
		this.fn = fn;
		this.store = new Store(getDefaultAsyncQueuerState());
		this.asyncRetryers = /* @__PURE__ */ new Map();
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.addItem = (item, position = this.options.addItemsTo ?? "back", runOnItemsChange = true) => {
			this.#setState({ addItemCount: this.store.state.addItemCount + 1 });
			if (this.store.state.items.length >= (this.options.maxSize ?? Infinity)) {
				this.#setState({ rejectionCount: this.store.state.rejectionCount + 1 });
				this.options.onReject?.(item, this);
				return false;
			}
			const priority = this.options.getPriority !== defaultOptions$7.getPriority ? this.options.getPriority(item) : item.priority;
			const items = this.store.state.items;
			const itemTimestamps = this.store.state.itemTimestamps;
			if (priority !== void 0) {
				const insertIndex = items.findIndex((existing) => {
					return (this.options.getPriority !== defaultOptions$7.getPriority ? this.options.getPriority(existing) : existing.priority) < priority;
				});
				if (insertIndex === -1) {
					items.push(item);
					itemTimestamps.push(Date.now());
				} else {
					items.splice(insertIndex, 0, item);
					itemTimestamps.splice(insertIndex, 0, Date.now());
				}
			} else if (position === "front") {
				items.unshift(item);
				itemTimestamps.unshift(Date.now());
			} else {
				items.push(item);
				itemTimestamps.push(Date.now());
			}
			this.#setState({
				items,
				itemTimestamps
			});
			if (runOnItemsChange) this.options.onItemsChange?.(this);
			if (this.store.state.isRunning && !this.store.state.pendingTick) this.#tick();
			return true;
		};
		this.getNextItem = (position = this.options.getItemsFrom ?? "front") => {
			const { items, itemTimestamps } = this.store.state;
			let item;
			if (this.options.getPriority !== defaultOptions$7.getPriority || position === "front") {
				item = items[0];
				if (item !== void 0) this.#setState({
					items: items.slice(1),
					itemTimestamps: itemTimestamps.slice(1)
				});
			} else {
				item = items[items.length - 1];
				if (item !== void 0) this.#setState({
					items: items.slice(0, -1),
					itemTimestamps: itemTimestamps.slice(0, -1)
				});
			}
			if (item !== void 0) this.options.onItemsChange?.(this);
			return item;
		};
		this.execute = async (position) => {
			const item = this.getNextItem(position);
			if (item !== void 0) {
				const currentExecuteCount = this.store.state.executeCount + 1;
				this.#setState({
					executeCount: currentExecuteCount,
					isExecuting: true
				});
				try {
					const currentAsyncRetryer = new AsyncRetryer(this.fn, {
						...this.options.asyncRetryerOptions,
						key: `${this.key}-retryer-${currentExecuteCount}`
					});
					this.asyncRetryers.set(currentExecuteCount, currentAsyncRetryer);
					const lastResult = await currentAsyncRetryer.execute(item);
					this.#setState({
						successCount: this.store.state.successCount + 1,
						lastResult
					});
					this.options.onSuccess?.(lastResult, item, this);
				} catch (error) {
					this.#setState({ errorCount: this.store.state.errorCount + 1 });
					this.options.onError?.(error, item, this);
					if (this.options.throwOnError) throw error;
				} finally {
					this.asyncRetryers.delete(currentExecuteCount);
					this.#setState({
						activeItems: this.store.state.activeItems.filter((activeItem) => activeItem !== item),
						isExecuting: false,
						settledCount: this.store.state.settledCount + 1
					});
					this.options.onSettled?.(item, this);
				}
			}
			return item;
		};
		this.flush = async (numberOfItems = this.store.state.items.length, position) => {
			this.#clearTimeouts();
			await Promise.all(Array.from({ length: numberOfItems }, () => this.execute(position)));
		};
		this.flushAsBatch = async (batchFunction) => {
			this.#clearTimeouts();
			await batchFunction(this.#getAllItems());
		};
		this.peekNextItem = (position = "front") => {
			if (position === "front") return this.store.state.items[0];
			return this.store.state.items[this.store.state.items.length - 1];
		};
		this.peekAllItems = () => {
			return [...this.peekActiveItems(), ...this.peekPendingItems()];
		};
		this.peekActiveItems = () => {
			return [...this.store.state.activeItems];
		};
		this.peekPendingItems = () => {
			return [...this.store.state.items];
		};
		this.start = () => {
			this.#setState({ isRunning: true });
			if (!this.store.state.pendingTick && this.store.state.items.length > 0) this.#tick();
		};
		this.stop = () => {
			this.#clearTimeouts();
			this.#setState({
				isRunning: false,
				pendingTick: false
			});
		};
		this.clear = () => {
			this.#setState({
				items: [],
				itemTimestamps: []
			});
			this.options.onItemsChange?.(this);
		};
		this.getAbortSignal = (executeCount) => {
			const count = executeCount ?? this.store.state.executeCount;
			return this.asyncRetryers.get(count)?.getAbortSignal() ?? null;
		};
		this.abort = () => {
			this.asyncRetryers.forEach((retryer) => retryer.abort());
			this.asyncRetryers.clear();
			this.#setState({ isExecuting: false });
		};
		this.reset = () => {
			this.#setState(getDefaultAsyncQueuerState());
			this.options.onItemsChange?.(this);
			this.asyncRetryers.forEach((retryer) => retryer.reset());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$7,
			...initialOptions,
			throwOnError: initialOptions.throwOnError ?? !initialOptions.onError
		};
		const isInitiallyRunning = this.options.initialState?.isRunning ?? this.options.started ?? true;
		this.#setState({
			...this.options.initialState,
			isRunning: isInitiallyRunning
		});
		if (this.options.initialState?.items) {
			if (this.store.state.isRunning) this.#tick();
		} else for (let i = 0; i < (this.options.initialItems?.length ?? 0); i++) {
			const item = this.options.initialItems[i];
			const isLast = i === (this.options.initialItems?.length ?? 0) - 1;
			this.addItem(item, this.options.addItemsTo ?? "back", isLast);
		}
		if (this.key) pacerEventClient.on("d-AsyncQueuer", (e) => {
			if (e.payload.key !== this.key) return;
			this.#setState(e.payload.store.state);
			this.setOptions(e.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { activeItems, items, isRunning } = combinedState;
			const size = items.length;
			const isFull = size >= (this.options.maxSize ?? Infinity);
			const isEmpty = size === 0;
			const isIdle = isRunning && isEmpty && activeItems.length === 0;
			const status = isIdle ? "idle" : isRunning ? "running" : "stopped";
			return {
				...combinedState,
				isEmpty,
				isFull,
				isIdle,
				size,
				status
			};
		});
		emitChange("AsyncQueuer", this);
	};
	/**
	* Returns the current wait time (in milliseconds) between processing items.
	* If a function is provided, it is called with the queuer instance.
	*/
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait ?? 0, this);
	};
	/**
	* Returns the current concurrency limit for processing items.
	* If a function is provided, it is called with the queuer instance.
	*/
	#getConcurrency = () => {
		return parseFunctionOrValue(this.options.concurrency ?? 1, this);
	};
	/**
	* Processes items in the queue up to the concurrency limit. Internal use only.
	*/
	#tick = () => {
		if (!this.store.state.isRunning) {
			this.#setState({ pendingTick: false });
			return;
		}
		this.#setState({ pendingTick: true });
		this.#checkExpiredItems();
		const activeItems = this.store.state.activeItems;
		while (activeItems.length < this.#getConcurrency() && this.store.state.items.length > 0) {
			const nextItem = this.peekNextItem();
			if (!nextItem) break;
			activeItems.push(nextItem);
			this.#setState({ activeItems });
			(async () => {
				await this.execute();
				const wait = this.#getWait();
				if (wait > 0) {
					const timeoutId = setTimeout(() => this.#tick(), wait);
					this.#timeoutIds.add(timeoutId);
					return;
				}
				this.#tick();
			})();
		}
		this.#setState({ pendingTick: false });
	};
	#getAllItems = () => {
		const items = this.peekAllItems();
		this.clear();
		return items;
	};
	/**
	* Checks for expired items in the queue and removes them. Calls onExpire for each expired item.
	* Internal use only.
	*/
	#checkExpiredItems = () => {
		if ((this.options.expirationDuration ?? Infinity) === Infinity && this.options.getIsExpired === defaultOptions$7.getIsExpired) return;
		const now = Date.now();
		const expiredIndices = [];
		for (let i = 0; i < this.store.state.items.length; i++) {
			const timestamp = this.store.state.itemTimestamps[i];
			if (timestamp === void 0) continue;
			const item = this.store.state.items[i];
			if (item === void 0) continue;
			if (this.options.getIsExpired !== defaultOptions$7.getIsExpired ? this.options.getIsExpired(item, timestamp) : now - timestamp > (this.options.expirationDuration ?? Infinity)) expiredIndices.push(i);
		}
		for (let i = expiredIndices.length - 1; i >= 0; i--) {
			const index = expiredIndices[i];
			if (index === void 0) continue;
			const expiredItem = this.store.state.items[index];
			if (expiredItem === void 0) continue;
			const newItems = [...this.store.state.items];
			const newTimestamps = [...this.store.state.itemTimestamps];
			newItems.splice(index, 1);
			newTimestamps.splice(index, 1);
			this.#setState({
				items: newItems,
				itemTimestamps: newTimestamps,
				expirationCount: this.store.state.expirationCount + 1
			});
			this.options.onExpire?.(expiredItem, this);
		}
		if (expiredIndices.length > 0) this.options.onItemsChange?.(this);
	};
	#clearTimeouts = () => {
		this.#timeoutIds.forEach((timeoutId) => clearTimeout(timeoutId));
		this.#timeoutIds.clear();
	};
};
/**
* Creates a new AsyncQueuer instance and returns a bound addItem function for adding tasks.
* The queuer is started automatically and ready to process items.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync queue function:
* - Returns promises that can be awaited for task results
* - Built-in retry support via AsyncRetryer integration for each queued task
* - Abort support to cancel in-flight task executions
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
* - Concurrent execution support (process multiple items simultaneously)
*
* The sync queue function is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Queuing?
* Queuing is a technique for managing and processing items sequentially or with controlled concurrency.
* Tasks are processed up to the configured concurrency limit. When a task completes,
* the next pending task is processed if the concurrency limit allows.
*
* Configuration Options:
* - `concurrency`: Maximum number of concurrent tasks (default: 1)
* - `wait`: Time to wait between processing items (default: 0)
* - `maxSize`: Maximum number of items allowed in the queue (default: Infinity)
* - `getPriority`: Function to determine item priority
* - `addItemsTo`: Default position to add items ('back' or 'front', default: 'back')
* - `getItemsFrom`: Default position to get items ('front' or 'back', default: 'front')
* - `expirationDuration`: Maximum time items can stay in queue
* - `started`: Whether to start processing immediately (default: true)
* - `asyncRetryerOptions`: Configure retry behavior for task executions
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and queuer instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together; the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncQueuer instance
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async queuer
* - Use `onSuccess` callback to react to successful task execution and implement custom logic
* - Use `onError` callback to react to task execution errors and implement custom error handling
* - Use `onSettled` callback to react to task execution completion (success or error) and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the queue
* - Use `onExpire` callback to react to items expiring and implement custom logic
* - Use `onReject` callback to react to items being rejected when the queue is full
* - The state includes error count, expiration count, rejection count, running status, and success/settle counts
* - State can be accessed via the underlying AsyncQueuer instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* @example
* ```ts
* const enqueue = asyncQueue<string>(async (item) => {
*   return item.toUpperCase();
* }, {
*   concurrency: 2,
*   wait: 100,
*   onSuccess: (result) => console.log('Processed:', result)
* });
*
* enqueue('hello');
* ```
*/
function asyncQueue(fn, initialOptions) {
	return new AsyncQueuer(fn, initialOptions).addItem;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-queuer/useAsyncQueuer.js
/**
* A lower-level React hook that creates an `AsyncQueuer` instance for managing an async queue of items.
*
* Features:
* - Priority queue support via getPriority option
* - Configurable concurrency limit
* - Task success/error/completion callbacks
* - FIFO (First In First Out) or LIFO (Last In First Out) queue behavior
* - Pause/resume task processing
* - Task cancellation
* - Item expiration to clear stale items from the queue
*
* Tasks are processed concurrently up to the configured concurrency limit. When a task completes,
* the next pending task is processed if below the concurrency limit.
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and queuer instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncQueuer instance
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `queuer.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `activeItems`: Items currently being processed by the queuer
* - `errorCount`: Number of task executions that have resulted in errors
* - `expirationCount`: Number of items that have been removed due to expiration
* - `isEmpty`: Whether the queuer has no items to process
* - `isFull`: Whether the queuer has reached its maximum capacity
* - `isIdle`: Whether the queuer is not currently processing any items
* - `isRunning`: Whether the queuer is active and will process items automatically
* - `items`: Array of items currently waiting to be processed
* - `itemTimestamps`: Timestamps when items were added for expiration tracking
* - `lastResult`: The result from the most recent task execution
* - `pendingTick`: Whether the queuer has a pending timeout for processing the next item
* - `rejectionCount`: Number of items that have been rejected from being added
* - `settledCount`: Number of task executions that have completed (success or error)
* - `size`: Number of items currently in the queue
* - `status`: Current processing status ('idle' | 'running' | 'stopped')
* - `successCount`: Number of task executions that have completed successfully
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const asyncQueuer = useAsyncQueuer(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: false }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <asyncQueuer.Subscribe selector={(state) => ({ size: state.size, isRunning: state.isRunning })}>
*   {({ size, isRunning }) => (
*     <div>Queue: {size} items, {isRunning ? 'Processing' : 'Idle'}</div>
*   )}
* </asyncQueuer.Subscribe>
*
* // Opt-in to re-render when queue size changes at hook level (optimized for displaying queue length)
* const asyncQueuer = useAsyncQueuer(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: false },
*   (state) => ({
*     size: state.size,
*     isEmpty: state.isEmpty,
*     isFull: state.isFull
*   })
* );
*
* // Opt-in to re-render when processing state changes (optimized for loading indicators)
* const asyncQueuer = useAsyncQueuer(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: false },
*   (state) => ({
*     isRunning: state.isRunning,
*     isIdle: state.isIdle,
*     status: state.status,
*     activeItems: state.activeItems,
*     pendingTick: state.pendingTick
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const asyncQueuer = useAsyncQueuer(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: false },
*   (state) => ({
*     successCount: state.successCount,
*     errorCount: state.errorCount,
*     settledCount: state.settledCount,
*     expirationCount: state.expirationCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Opt-in to re-render when results are available (optimized for data display)
* const asyncQueuer = useAsyncQueuer(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   {
*     concurrency: 2,
*     maxSize: 100,
*     started: false,
*     onSuccess: (result) => {
*       console.log('Item processed:', result);
*     },
*     onError: (error) => {
*       console.error('Processing failed:', error);
*     }
*   },
*   (state) => ({
*     lastResult: state.lastResult,
*     successCount: state.successCount
*   })
* );
*
* // Add items to queue
* asyncQueuer.addItem(newItem);
*
* // Start processing
* asyncQueuer.start();
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { size, isRunning, activeItems } = asyncQueuer.state;
* ```
*/
function useAsyncQueuer(fn, options = {}, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().asyncQueuer,
		...options
	};
	const [asyncQueuer] = (0, import_react.useState)(() => {
		const asyncQueuerInstance = new AsyncQueuer(fn, mergedOptions);
		asyncQueuerInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(asyncQueuerInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return asyncQueuerInstance;
	});
	asyncQueuer.fn = fn;
	asyncQueuer.setOptions(mergedOptions);
	const state = useStore(asyncQueuer.store, selector);
	return (0, import_react.useMemo)(() => ({
		...asyncQueuer,
		state
	}), [asyncQueuer, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-queuer/useAsyncQueuedState.js
/**
* A higher-level React hook that creates an `AsyncQueuer` instance with built-in state management.
*
* This hook combines an AsyncQueuer with React state to automatically track the queue items.
* It returns a tuple containing:
* - The current array of queued items as React state
* - The queuer instance with methods to control the queue
*
* The queue can be configured with:
* - Maximum concurrent operations
* - Maximum queue size
* - Processing function for queue items
* - Various lifecycle callbacks
*
* The state will automatically update whenever items are:
* - Added to the queue
* - Removed from the queue
* - Started processing
* - Completed processing
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying async queuer instance.
* The `selector` parameter allows you to specify which async queuer state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available async queuer state properties:
* - `activeItems`: Items currently being processed by the queuer
* - `errorCount`: Number of task executions that have resulted in errors
* - `expirationCount`: Number of items that have been removed due to expiration
* - `isEmpty`: Whether the queuer has no items to process
* - `isFull`: Whether the queuer has reached its maximum capacity
* - `isIdle`: Whether the queuer is not currently processing any items
* - `isRunning`: Whether the queuer is active and will process items automatically
* - `items`: Array of items currently waiting to be processed
* - `itemTimestamps`: Timestamps when items were added for expiration tracking
* - `lastResult`: The result from the most recent task execution
* - `pendingTick`: Whether the queuer has a pending timeout for processing the next item
* - `rejectionCount`: Number of items that have been rejected from being added
* - `settledCount`: Number of task executions that have completed (success or error)
* - `size`: Number of items currently in the queue
* - `status`: Current processing status ('idle' | 'running' | 'stopped')
* - `successCount`: Number of task executions that have completed successfully
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [queueItems, asyncQueuer] = useAsyncQueuedState(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   {
*     concurrency: 2,
*     maxSize: 100,
*     started: true
*   }
* );
*
* // Opt-in to re-render when queue contents change (optimized for displaying queue items)
* const [queueItems, asyncQueuer] = useAsyncQueuedState(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: true },
*   (state) => ({
*     items: state.items,
*     size: state.size,
*     isEmpty: state.isEmpty,
*     isFull: state.isFull
*   })
* );
*
* // Opt-in to re-render when processing state changes (optimized for loading indicators)
* const [queueItems, asyncQueuer] = useAsyncQueuedState(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: true },
*   (state) => ({
*     isRunning: state.isRunning,
*     isIdle: state.isIdle,
*     status: state.status,
*     activeItems: state.activeItems,
*     pendingTick: state.pendingTick
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const [queueItems, asyncQueuer] = useAsyncQueuedState(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: true },
*   (state) => ({
*     successCount: state.successCount,
*     errorCount: state.errorCount,
*     settledCount: state.settledCount,
*     expirationCount: state.expirationCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Opt-in to re-render when results are available (optimized for data display)
* const [queueItems, asyncQueuer] = useAsyncQueuedState(
*   async (item) => {
*     const result = await processItem(item);
*     return result;
*   },
*   { concurrency: 2, maxSize: 100, started: true },
*   (state) => ({
*     lastResult: state.lastResult,
*     successCount: state.successCount
*   })
* );
*
* // Add items to queue - state updates automatically
* asyncQueuer.addItem(async () => {
*   const result = await fetchData();
*   return result;
* });
*
* // Start processing
* asyncQueuer.start();
*
* // Stop processing
* asyncQueuer.stop();
*
* // queueItems reflects current queue state
* const pendingCount = asyncQueuer.peekPendingItems().length;
*
* // Access the selected async queuer state (will be empty object {} unless selector provided)
* const { size, isRunning, activeItems } = asyncQueuer.state;
* ```
*/
function useAsyncQueuedState(fn, options = {}, selector) {
	const asyncQueuer = useAsyncQueuer(fn, options, selector);
	return [asyncQueuer.state.items, asyncQueuer];
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/async-rate-limiter.js
function getDefaultAsyncRateLimiterState() {
	return {
		errorCount: 0,
		executionTimes: [],
		isExceeded: false,
		isExecuting: false,
		lastResult: void 0,
		maybeExecuteCount: 0,
		rejectionCount: 0,
		settleCount: 0,
		status: "idle",
		successCount: 0
	};
}
/**
* Utility function for sharing common `AsyncRateLimiterOptions` options between different `AsyncRateLimiter` instances.
*/
function asyncRateLimiterOptions(options) {
	return options;
}
var defaultOptions$6 = {
	asyncRetryerOptions: { maxAttempts: 1 },
	enabled: true,
	limit: 1,
	window: 0,
	windowType: "fixed",
	throwOnError: true
};
/**
* A class that creates an async rate-limited function.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync RateLimiter:
* - Returns promises that can be awaited for rate-limited function results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight executions
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts, rejection counts)
* - More sophisticated window management with automatic cleanup
*
* The sync RateLimiter is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Rate Limiting?
* Rate limiting allows a function to execute up to a limit within a time window,
* then blocks all subsequent calls until the window passes. This can lead to "bursty" behavior where
* all executions happen immediately, followed by a complete block.
*
* Window Types:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* When to Use Rate Limiting:
* Rate limiting is best used for hard API limits or resource constraints. For UI updates or
* smoothing out frequent events, throttling or debouncing usually provide better user experience.
* - Throttling: Ensures consistent spacing between executions (e.g. max once per 200ms)
* - Debouncing: Waits for a pause in calls before executing (e.g. after 500ms of no calls)
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the rate limiter
* - `initialState` can be a partial state object
* - Use `onSuccess` callback to react to successful function execution and implement custom logic
* - Use `onError` callback to react to function execution errors and implement custom error handling
* - Use `onSettled` callback to react to function execution completion (success or error) and implement custom logic
* - Use `onReject` callback to react to executions being rejected when rate limit is exceeded
* - The state includes execution times, success/error counts, and current execution status
* - State can be accessed via `asyncRateLimiter.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `asyncRateLimiter.state`
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and rate limiter instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncRateLimiter instance
* - Rate limit rejections (when limit is exceeded) are handled separately from execution errors via the `onReject` handler
*
* @example
* ```ts
* const rateLimiter = new AsyncRateLimiter(
*   async (id: string) => await api.getData(id),
*   {
*     limit: 5,
*     window: 1000,
*     windowType: 'sliding',
*     onError: (error) => {
*       console.error('API call failed:', error);
*     },
*     onReject: (limiter) => {
*       console.log(`Rate limit exceeded. Try again in ${limiter.getMsUntilNextWindow()}ms`);
*     }
*   }
* );
*
* // Will execute immediately until limit reached, then block
* // Returns the API response directly
* const data = await rateLimiter.maybeExecute('123');
* ```
*/
var AsyncRateLimiter = class {
	#timeoutIds = /* @__PURE__ */ new Set();
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultAsyncRateLimiterState());
		this.asyncRetryers = /* @__PURE__ */ new Map();
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.maybeExecute = async (...args) => {
			this.#setState({ maybeExecuteCount: this.store.state.maybeExecuteCount + 1 });
			this.#cleanupOldExecutions();
			if (this.#getExecutionTimesInWindow().length < this.#getLimit()) {
				await this.#execute(...args);
				return this.store.state.lastResult;
			}
			this.#setState({ rejectionCount: this.store.state.rejectionCount + 1 });
			this.options.onReject?.(args, this);
		};
		this.getRemainingInWindow = () => {
			const relevantExecutionTimes = this.#getExecutionTimesInWindow();
			return Math.max(0, this.#getLimit() - relevantExecutionTimes.length);
		};
		this.getMsUntilNextWindow = () => {
			if (this.getRemainingInWindow() > 0) return 0;
			return (this.store.state.executionTimes[0] ?? Infinity) + this.#getWindow() - Date.now();
		};
		this.getAbortSignal = (maybeExecuteCount) => {
			const count = maybeExecuteCount ?? this.store.state.maybeExecuteCount;
			return this.asyncRetryers.get(count)?.getAbortSignal() ?? null;
		};
		this.abort = () => {
			this.asyncRetryers.forEach((retryer) => retryer.abort());
			this.asyncRetryers.clear();
			this.#setState({ isExecuting: false });
		};
		this.reset = () => {
			this.#setState(getDefaultAsyncRateLimiterState());
			this.#clearTimeouts();
			this.asyncRetryers.forEach((retryer) => retryer.reset());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$6,
			...initialOptions,
			throwOnError: initialOptions.throwOnError ?? !initialOptions.onError
		};
		this.#setState(this.options.initialState ?? {});
		for (const executionTime of this.#getExecutionTimesInWindow()) this.#setCleanupTimeout(executionTime);
		if (this.key) pacerEventClient.on("d-AsyncRateLimiter", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const isExceeded = combinedState.executionTimes.length >= this.#getLimit();
			const status = !this.#getEnabled() ? "disabled" : combinedState.isExecuting ? "executing" : isExceeded ? "exceeded" : "idle";
			return {
				...combinedState,
				isExceeded,
				status
			};
		});
		emitChange("AsyncRateLimiter", this);
	};
	/**
	* Returns the current enabled state of the async rate limiter
	*/
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	/**
	* Returns the current limit of executions allowed within the time window
	*/
	#getLimit = () => {
		return parseFunctionOrValue(this.options.limit, this);
	};
	/**
	* Returns the current time window in milliseconds
	*/
	#getWindow = () => {
		return parseFunctionOrValue(this.options.window, this);
	};
	#execute = async (...args) => {
		if (!this.#getEnabled()) return;
		const currentMaybeExecute = this.store.state.maybeExecuteCount;
		const now = Date.now();
		const executionTimes = [...this.store.state.executionTimes, now];
		this.#setState({
			isExecuting: true,
			executionTimes
		});
		try {
			const currentAsyncRetryer = new AsyncRetryer(this.fn, {
				...this.options.asyncRetryerOptions,
				key: `${this.key}-retryer-${currentMaybeExecute}`
			});
			this.asyncRetryers.set(currentMaybeExecute, currentAsyncRetryer);
			const result = await currentAsyncRetryer.execute(...args);
			this.#setCleanupTimeout(now);
			this.#setState({
				successCount: this.store.state.successCount + 1,
				lastResult: result
			});
			this.options.onSuccess?.(result, args, this);
		} catch (error) {
			this.#setState({ errorCount: this.store.state.errorCount + 1 });
			this.options.onError?.(error, args, this);
			if (this.options.throwOnError) throw error;
		} finally {
			this.asyncRetryers.delete(currentMaybeExecute);
			this.#setState({
				isExecuting: false,
				settleCount: this.store.state.settleCount + 1
			});
			this.options.onSettled?.(args, this);
		}
		return this.store.state.lastResult;
	};
	#getExecutionTimesInWindow = () => {
		if (this.options.windowType === "sliding") return this.store.state.executionTimes.filter((time) => time > Date.now() - this.#getWindow());
		else {
			if (this.store.state.executionTimes.length === 0) return [];
			const windowStart = Math.min(...this.store.state.executionTimes);
			const windowEnd = windowStart + this.#getWindow();
			if (Date.now() > windowEnd) return [];
			return this.store.state.executionTimes.filter((time) => time >= windowStart && time <= windowEnd);
		}
	};
	#setCleanupTimeout = (executionTime) => {
		if (this.options.windowType === "sliding" || this.#timeoutIds.size === 0) {
			const timeUntilExpiration = executionTime - Date.now() + this.#getWindow() + 1;
			const timeoutId = setTimeout(() => {
				this.#cleanupOldExecutions();
				this.#clearTimeout(timeoutId);
			}, timeUntilExpiration);
			this.#timeoutIds.add(timeoutId);
		}
	};
	#clearTimeout = (timeoutId) => {
		clearTimeout(timeoutId);
		this.#timeoutIds.delete(timeoutId);
	};
	#clearTimeouts = () => {
		this.#timeoutIds.forEach((timeoutId) => clearTimeout(timeoutId));
		this.#timeoutIds.clear();
	};
	#cleanupOldExecutions = () => {
		this.#setState({ executionTimes: this.#getExecutionTimesInWindow() });
	};
};
/**
* Creates an async rate-limited function that will execute the provided function up to a maximum number of times within a time window.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync rate limit function:
* - Returns promises that can be awaited for rate-limited function results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight executions
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts, rejection counts)
* - More sophisticated window management with automatic cleanup
*
* The sync rate limit function is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Rate Limiting?
* Rate limiting allows a function to execute up to a limit within a time window,
* then blocks all subsequent calls until the window passes. This can lead to "bursty" behavior where
* all executions happen immediately, followed by a complete block.
*
* Window Types:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* Configuration Options:
* - `limit`: Maximum number of executions allowed within the window (required)
* - `window`: Time window in milliseconds (required)
* - `windowType`: 'fixed' or 'sliding' (default: 'fixed')
* - `enabled`: Whether the rate limiter is enabled (default: true)
* - `asyncRetryerOptions`: Configure retry behavior for executions
*
* When to Use Rate Limiting:
* Rate limiting is best used for hard API limits or resource constraints. For UI updates or
* smoothing out frequent events, throttling or debouncing usually provide better user experience.
* - A rate limiter will allow all executions until the limit is reached, then block all subsequent calls until the window resets
* - A throttler ensures even spacing between executions, which can be better for consistent performance
* - A debouncer collapses multiple calls into one, which is better for handling bursts of events
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and rate limiter instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncRateLimiter instance
* - Rate limit rejections (when limit is exceeded) are handled separately from execution errors via the `onReject` handler
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the rate limiter
* - `initialState` can be a partial state object
* - Use `onSuccess` callback to react to successful function execution and implement custom logic
* - Use `onError` callback to react to function execution errors and implement custom error handling
* - Use `onSettled` callback to react to function execution completion (success or error) and implement custom logic
* - Use `onReject` callback to react to executions being rejected when rate limit is exceeded
* - The state includes execution times, success/error counts, and current execution status
* - State can be accessed via the underlying AsyncRateLimiter instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* @example
* ```ts
* // Rate limit to 5 calls per minute with a sliding window
* const rateLimited = asyncRateLimit(makeApiCall, {
*   limit: 5,
*   window: 60000,
*   windowType: 'sliding',
*   onError: (error) => {
*     console.error('API call failed:', error);
*   },
*   onReject: (rateLimiter) => {
*     console.log(`Rate limit exceeded. Try again in ${rateLimiter.getMsUntilNextWindow()}ms`);
*   }
* });
*
* // First 5 calls will execute immediately
* // Additional calls will be rejected until the minute window resets
* // Returns the API response directly
* const result = await rateLimited();
*
* // For more even execution, consider using throttle instead:
* const throttled = throttle(makeApiCall, { wait: 12000 }); // One call every 12 seconds
* ```
*/
function asyncRateLimit(fn, initialOptions) {
	return new AsyncRateLimiter(fn, initialOptions).maybeExecute;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-rate-limiter/useAsyncRateLimiter.js
/**
* A low-level React hook that creates an `AsyncRateLimiter` instance to limit how many times an async function can execute within a time window.
*
* This hook is designed to be flexible and state-management agnostic - it simply returns a rate limiter instance that
* you can integrate with any state management solution (useState, Redux, Zustand, Jotai, etc).
*
* Rate limiting allows an async function to execute up to a specified limit within a time window,
* then blocks subsequent calls until the window passes. This is useful for respecting API rate limits,
* managing resource constraints, or controlling bursts of async operations.
*
* Unlike the non-async RateLimiter, this async version supports returning values from the rate-limited function,
* making it ideal for API calls and other async operations where you want the result of the `maybeExecute` call
* instead of setting the result on a state variable from within the rate-limited function.
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and rate limiter instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncRateLimiter instance
* - Rate limit rejections (when limit is exceeded) are handled separately from execution errors via the `onReject` handler
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `rateLimiter.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `errorCount`: Number of function executions that have resulted in errors
* - `executionTimes`: Array of timestamps when executions occurred for rate limiting calculations
* - `isExecuting`: Whether the rate-limited function is currently executing asynchronously
* - `lastResult`: The result from the most recent successful function execution
* - `rejectionCount`: Number of function executions that have been rejected due to rate limiting
* - `settleCount`: Number of function executions that have completed (success or error)
* - `successCount`: Number of function executions that have completed successfully
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const asyncRateLimiter = useAsyncRateLimiter(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data; // Return value is preserved
*   },
*   { limit: 5, window: 1000 } // 5 calls per second
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <asyncRateLimiter.Subscribe selector={(state) => ({ rejectionCount: state.rejectionCount, isExecuting: state.isExecuting })}>
*   {({ rejectionCount, isExecuting }) => (
*     <div>Rejected: {rejectionCount}, {isExecuting ? 'Executing' : 'Idle'}</div>
*   )}
* </asyncRateLimiter.Subscribe>
*
* // Opt-in to re-render when execution state changes at hook level (optimized for loading indicators)
* const asyncRateLimiter = useAsyncRateLimiter(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { limit: 5, window: 1000 },
*   (state) => ({ isExecuting: state.isExecuting })
* );
*
* // Opt-in to re-render when results are available (optimized for data display)
* const asyncRateLimiter = useAsyncRateLimiter(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { limit: 5, window: 1000 },
*   (state) => ({
*     lastResult: state.lastResult,
*     successCount: state.successCount
*   })
* );
*
* // Opt-in to re-render when error/rejection state changes (optimized for error handling)
* const asyncRateLimiter = useAsyncRateLimiter(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   {
*     limit: 5,
*     window: 1000,
*     onError: (error) => console.error('API call failed:', error),
*     onReject: (rateLimiter) => console.log('Rate limit exceeded')
*   },
*   (state) => ({
*     errorCount: state.errorCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const asyncRateLimiter = useAsyncRateLimiter(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { limit: 5, window: 1000 },
*   (state) => ({
*     successCount: state.successCount,
*     errorCount: state.errorCount,
*     settleCount: state.settleCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Opt-in to re-render when execution times change (optimized for window calculations)
* const asyncRateLimiter = useAsyncRateLimiter(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { limit: 5, window: 1000 },
*   (state) => ({ executionTimes: state.executionTimes })
* );
*
* // With state management and return value
* const [data, setData] = useState(null);
* const { maybeExecute, state } = useAsyncRateLimiter(
*   async (query) => {
*     const result = await searchAPI(query);
*     setData(result);
*     return result; // Return value can be used by the caller
*   },
*   {
*     limit: 10,
*     window: 60000, // 10 calls per minute
*     onReject: (rateLimiter) => {
*       console.log(`Rate limit exceeded. Try again in ${rateLimiter.getMsUntilNextWindow()}ms`);
*     },
*     onError: (error) => {
*       console.error('API call failed:', error);
*     }
*   }
* );
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { isExecuting, lastResult, rejectionCount } = state;
* ```
*/
function useAsyncRateLimiter(fn, options, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().asyncRateLimiter,
		...options
	};
	const [asyncRateLimiter] = (0, import_react.useState)(() => {
		const asyncRateLimiterInstance = new AsyncRateLimiter(fn, mergedOptions);
		asyncRateLimiterInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(asyncRateLimiterInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return asyncRateLimiterInstance;
	});
	asyncRateLimiter.fn = fn;
	asyncRateLimiter.setOptions(mergedOptions);
	const state = useStore(asyncRateLimiter.store, selector);
	return (0, import_react.useMemo)(() => ({
		...asyncRateLimiter,
		state
	}), [asyncRateLimiter, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-rate-limiter/useAsyncRateLimitedCallback.js
/**
* A React hook that creates a rate-limited version of an async callback function.
* This hook is a convenient wrapper around the `useAsyncRateLimiter` hook,
* providing a stable, async rate-limited function reference for use in React components.
*
* Async rate limiting is a "hard limit" approach for async functions: it allows all calls
* until the limit is reached, then blocks (rejects) subsequent calls until the window resets.
* Unlike throttling or debouncing, it does not attempt to space out or collapse calls.
* This can lead to bursts of rapid executions followed by periods where all calls are blocked.
*
* The async rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* For smoother execution patterns, consider:
* - useAsyncThrottledCallback: When you want consistent spacing between executions (e.g. UI updates)
* - useAsyncDebouncedCallback: When you want to collapse rapid calls into a single execution (e.g. search input)
*
* Async rate limiting should primarily be used when you need to enforce strict limits
* on async operations, like API rate limits or other scenarios requiring hard caps
* on execution frequency.
*
* This hook provides a simpler API compared to `useAsyncRateLimiter`, making it ideal for basic
* async rate limiting needs. However, it does not expose the underlying AsyncRateLimiter instance.
*
* For advanced usage requiring features like:
* - Manual cancellation
* - Access to execution counts
* - Custom useCallback dependencies
*
* Consider using the `useAsyncRateLimiter` hook instead.
*
*
* @example
* ```tsx
* // Rate limit async API calls to maximum 5 calls per minute with a sliding window
* const makeApiCall = useAsyncRateLimitedCallback(
*   async (data: ApiData) => {
*     return fetch('/api/endpoint', { method: 'POST', body: JSON.stringify(data) });
*   },
*   {
*     limit: 5,
*     window: 60000, // 1 minute
*     windowType: 'sliding',
*     onReject: () => {
*       console.warn('API rate limit reached. Please wait before trying again.');
*     }
*   }
* );
* ```
*/
function useAsyncRateLimitedCallback(fn, options) {
	const asyncRateLimitedFn = useAsyncRateLimiter(fn, options).maybeExecute;
	return (0, import_react.useCallback)((...args) => asyncRateLimitedFn(...args), [asyncRateLimitedFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/async-throttler.js
function getDefaultAsyncThrottlerState() {
	return {
		errorCount: 0,
		isExecuting: false,
		isPending: false,
		lastArgs: void 0,
		lastExecutionTime: 0,
		lastResult: void 0,
		maybeExecuteCount: 0,
		nextExecutionTime: void 0,
		settleCount: 0,
		status: "idle",
		successCount: 0
	};
}
/**
* Utility function for sharing common `AsyncThrottlerOptions` options between different `AsyncThrottler` instances.
*/
function asyncThrottlerOptions(options) {
	return options;
}
var defaultOptions$5 = {
	asyncRetryerOptions: { maxAttempts: 1 },
	enabled: true,
	leading: true,
	trailing: true,
	wait: 0
};
/**
* A class that creates an async throttled function.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync Throttler:
* - Returns promises that can be awaited for throttled function results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight executions
* - Cancel support to prevent pending executions from starting
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
* - Waits for ongoing executions to complete before scheduling the next one
*
* The sync Throttler is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Throttling?
* Throttling limits how often a function can be executed, allowing only one execution within a specified time window.
* Unlike debouncing which resets the delay timer on each call, throttling ensures the function executes at a
* regular interval regardless of how often it's called.
*
* This is useful for rate-limiting API calls, handling scroll/resize events, or any scenario where you want to
* ensure a maximum execution frequency.
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and throttler instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncThrottler instance
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async throttler
* - Use `onSuccess` callback to react to successful function execution and implement custom logic
* - Use `onError` callback to react to function execution errors and implement custom error handling
* - Use `onSettled` callback to react to function execution completion (success or error) and implement custom logic
* - The state includes error count, execution status, last execution time, and success/settle counts
* - State can be accessed via `asyncThrottler.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `asyncThrottler.state`
*
* @example
* ```ts
* const throttler = new AsyncThrottler(async (value: string) => {
*   const result = await saveToAPI(value);
*   return result; // Return value is preserved
* }, {
*   wait: 1000,
*   onError: (error) => {
*     console.error('API call failed:', error);
*   }
* });
*
* // Will only execute once per second no matter how often called
* // Returns the API response directly
* const result = await throttler.maybeExecute(inputElement.value);
* ```
*/
var AsyncThrottler = class {
	#timeoutId = null;
	#resolvePreviousPromise = null;
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultAsyncThrottlerState());
		this.asyncRetryers = /* @__PURE__ */ new Map();
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
			if (!this.#getEnabled()) this.cancel();
		};
		this.maybeExecute = async (...args) => {
			if (!this.#getEnabled()) return void 0;
			this.#resolvePreviousPromiseInternal();
			this.#setState({
				maybeExecuteCount: this.store.state.maybeExecuteCount + 1,
				lastArgs: args
			});
			const wait = this.#getWait();
			const thisMaybeExecuteNumber = this.store.state.maybeExecuteCount;
			for (let maxNumIterations = wait / 10; this.store.state.isExecuting && maxNumIterations > 0; maxNumIterations--) {
				await new Promise((resolve) => setTimeout(resolve, 10));
				if (this.store.state.maybeExecuteCount !== thisMaybeExecuteNumber) return this.store.state.lastResult;
			}
			const now = Date.now();
			const timeSinceLastExecution = now - this.store.state.lastExecutionTime;
			if (this.options.leading && !this.store.state.isPending && timeSinceLastExecution >= wait) await this.#execute(...args);
			else if (this.options.trailing) {
				this.cancel();
				this.#setState({ isPending: true });
				return new Promise((resolve, reject) => {
					this.#resolvePreviousPromise = resolve;
					const newTimeSinceLastExecution = this.store.state.lastExecutionTime ? now - this.store.state.lastExecutionTime : 0;
					const timeoutDuration = Math.max(0, wait - newTimeSinceLastExecution);
					this.#timeoutId = setTimeout(async () => {
						this.#clearTimeout();
						if (this.store.state.lastArgs !== void 0) try {
							await this.#execute(...this.store.state.lastArgs);
						} catch (error) {
							reject(error);
						}
						this.#resolvePreviousPromise = null;
						resolve(this.store.state.lastResult);
					}, timeoutDuration);
				});
			}
			return this.store.state.lastResult;
		};
		this.flush = async () => {
			if (this.store.state.isPending && this.store.state.lastArgs) {
				const resolvePromise = this.#resolvePreviousPromise;
				this.#clearTimeout();
				this.#setState({ isPending: false });
				const result = await this.#execute(...this.store.state.lastArgs);
				if (resolvePromise) resolvePromise(result);
				return result;
			}
		};
		this.getAbortSignal = (maybeExecuteCount) => {
			const count = maybeExecuteCount ?? this.store.state.maybeExecuteCount;
			return this.asyncRetryers.get(count)?.getAbortSignal() ?? null;
		};
		this.abort = () => {
			this.asyncRetryers.forEach((retryer) => retryer.abort());
			this.asyncRetryers.clear();
			this.#setState({ isExecuting: false });
		};
		this.cancel = () => {
			this.#clearTimeout();
			if (this.#resolvePreviousPromise) {
				this.#resolvePreviousPromiseInternal();
				this.#resolvePreviousPromise = null;
			}
			this.#setState({ isPending: false });
		};
		this.reset = () => {
			this.#setState(getDefaultAsyncThrottlerState());
			this.asyncRetryers.forEach((retryer) => retryer.reset());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$5,
			...initialOptions,
			throwOnError: initialOptions.throwOnError ?? !initialOptions.onError
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-AsyncThrottler", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isPending, isExecuting, settleCount } = combinedState;
			return {
				...combinedState,
				status: !this.#getEnabled() ? "disabled" : isPending ? "pending" : isExecuting ? "executing" : settleCount > 0 ? "settled" : "idle"
			};
		});
		emitChange("AsyncThrottler", this);
	};
	/**
	* Returns the current enabled state of the async throttler
	*/
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	/**
	* Returns the current wait time in milliseconds
	*/
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait, this);
	};
	#execute = async (...args) => {
		if (!this.#getEnabled()) return void 0;
		const currentMaybeExecute = this.store.state.maybeExecuteCount;
		try {
			this.#setState({ isExecuting: true });
			const currentAsyncRetryer = new AsyncRetryer(this.fn, {
				...this.options.asyncRetryerOptions,
				key: `${this.key}-retryer-${currentMaybeExecute}`
			});
			this.asyncRetryers.set(currentMaybeExecute, currentAsyncRetryer);
			const result = await currentAsyncRetryer.execute(...args);
			this.#setState({
				lastResult: result,
				successCount: this.store.state.successCount + 1
			});
			this.options.onSuccess?.(result, args, this);
		} catch (error) {
			this.#setState({ errorCount: this.store.state.errorCount + 1 });
			this.options.onError?.(error, args, this);
			if (this.options.throwOnError) throw error;
		} finally {
			this.asyncRetryers.delete(currentMaybeExecute);
			const lastExecutionTime = Date.now();
			const wait = this.#getWait();
			const nextExecutionTime = lastExecutionTime + wait;
			this.#setState({
				isExecuting: false,
				isPending: !!this.#timeoutId,
				settleCount: this.store.state.settleCount + 1,
				lastExecutionTime,
				nextExecutionTime
			});
			this.options.onSettled?.(args, this);
			setTimeout(() => {
				if (!this.store.state.isPending) this.#setState({ nextExecutionTime: void 0 });
			}, wait);
		}
		return this.store.state.lastResult;
	};
	#resolvePreviousPromiseInternal = () => {
		if (this.#resolvePreviousPromise) {
			this.#resolvePreviousPromise(this.store.state.lastResult);
			this.#resolvePreviousPromise = null;
		}
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = null;
		}
	};
};
/**
* Creates an async throttled function that limits how often the function can execute.
* The throttled function will execute at most once per wait period, even if called multiple times.
* If called while executing, it will wait until execution completes before scheduling the next call.
*
* Async vs Sync Versions:
* The async version provides advanced features over the sync throttle function:
* - Returns promises that can be awaited for throttled function results
* - Built-in retry support via AsyncRetryer integration
* - Abort support to cancel in-flight executions
* - Cancel support to prevent pending executions from starting
* - Comprehensive error handling with onError callbacks and throwOnError control
* - Detailed execution tracking (success/error/settle counts)
* - Waits for ongoing executions to complete before scheduling the next one
*
* The sync throttle function is lighter weight and simpler when you don't need async features,
* return values, or execution control.
*
* What is Throttling?
* Throttling limits how often a function can be executed, allowing only one execution within a specified time window.
* Unlike debouncing which resets the delay timer on each call, throttling ensures the function executes at a
* regular interval regardless of how often it's called.
*
* Configuration Options:
* - `wait`: Time window in milliseconds during which the function can only execute once (required)
* - `leading`: Execute immediately when called (default: true)
* - `trailing`: Execute on the trailing edge of the wait period (default: true)
* - `enabled`: Whether the throttler is enabled (default: true)
* - `asyncRetryerOptions`: Configure retry behavior for executions
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and throttler instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncThrottler instance
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the async throttler
* - Use `onSuccess` callback to react to successful function execution and implement custom logic
* - Use `onError` callback to react to function execution errors and implement custom error handling
* - Use `onSettled` callback to react to function execution completion (success or error) and implement custom logic
* - The state includes error count, execution status, last execution time, and success/settle counts
* - State can be accessed via the underlying AsyncThrottler instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* @example
* ```ts
* const throttled = asyncThrottle(async (value: string) => {
*   const result = await saveToAPI(value);
*   return result; // Return value is preserved
* }, {
*   wait: 1000,
*   onError: (error) => {
*     console.error('API call failed:', error);
*   }
* });
*
* // This will execute at most once per second
* // Returns the API response directly
* const result = await throttled(inputElement.value);
* ```
*/
function asyncThrottle(fn, initialOptions) {
	return new AsyncThrottler(fn, initialOptions).maybeExecute;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-throttler/useAsyncThrottler.js
/**
* A low-level React hook that creates an `AsyncThrottler` instance to limit how often an async function can execute.
*
* This hook is designed to be flexible and state-management agnostic - it simply returns a throttler instance that
* you can integrate with any state management solution (useState, Redux, Zustand, Jotai, etc).
*
* Async throttling ensures an async function executes at most once within a specified time window,
* regardless of how many times it is called. This is useful for rate-limiting expensive API calls,
* database operations, or other async tasks.
*
* Unlike the non-async Throttler, this async version supports returning values from the throttled function,
* making it ideal for API calls and other async operations where you want the result of the `maybeExecute` call
* instead of setting the result on a state variable from within the throttled function.
*
* Error Handling:
* - If an `onError` handler is provided, it will be called with the error and throttler instance
* - If `throwOnError` is true (default when no onError handler is provided), the error will be thrown
* - If `throwOnError` is false (default when onError handler is provided), the error will be swallowed
* - Both onError and throwOnError can be used together - the handler will be called before any error is thrown
* - The error state can be checked using the underlying AsyncThrottler instance
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `throttler.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `errorCount`: Number of function executions that have resulted in errors
* - `isExecuting`: Whether the throttled function is currently executing asynchronously
* - `isPending`: Whether the throttler is waiting for the timeout to trigger execution
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `lastExecutionTime`: Timestamp of the last function execution in milliseconds
* - `lastResult`: The result from the most recent successful function execution
* - `nextExecutionTime`: Timestamp when the next execution can occur in milliseconds
* - `settleCount`: Number of function executions that have completed (success or error)
* - `status`: Current execution status ('disabled' | 'idle' | 'pending' | 'executing' | 'settled')
* - `successCount`: Number of function executions that have completed successfully
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const asyncThrottler = useAsyncThrottler(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data; // Return value is preserved
*   },
*   { wait: 1000 }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <asyncThrottler.Subscribe selector={(state) => ({ isExecuting: state.isExecuting, isPending: state.isPending })}>
*   {({ isExecuting, isPending }) => (
*     <div>{isExecuting || isPending ? 'Loading...' : 'Ready'}</div>
*   )}
* </asyncThrottler.Subscribe>
*
* // Opt-in to re-render when execution state changes at hook level (optimized for loading indicators)
* const asyncThrottler = useAsyncThrottler(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { wait: 1000 },
*   (state) => ({
*     isExecuting: state.isExecuting,
*     isPending: state.isPending,
*     status: state.status
*   })
* );
*
* // Opt-in to re-render when results are available (optimized for data display)
* const asyncThrottler = useAsyncThrottler(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { wait: 1000 },
*   (state) => ({
*     lastResult: state.lastResult,
*     successCount: state.successCount,
*     settleCount: state.settleCount
*   })
* );
*
* // Opt-in to re-render when error state changes (optimized for error handling)
* const asyncThrottler = useAsyncThrottler(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   {
*     wait: 1000,
*     onError: (error) => console.error('API call failed:', error)
*   },
*   (state) => ({
*     errorCount: state.errorCount,
*     status: state.status
*   })
* );
*
* // Opt-in to re-render when timing information changes (optimized for timing displays)
* const asyncThrottler = useAsyncThrottler(
*   async (id: string) => {
*     const data = await api.fetchData(id);
*     return data;
*   },
*   { wait: 1000 },
*   (state) => ({
*     lastExecutionTime: state.lastExecutionTime,
*     nextExecutionTime: state.nextExecutionTime
*   })
* );
*
* // With state management and return value
* const [data, setData] = useState(null);
* const { maybeExecute, state } = useAsyncThrottler(
*   async (query) => {
*     const result = await searchAPI(query);
*     setData(result);
*     return result; // Return value can be used by the caller
*   },
*   {
*     wait: 2000,
*     leading: true,   // Execute immediately on first call
*     trailing: false  // Skip trailing edge updates
*   }
* );
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { isExecuting, lastResult } = state;
* ```
*/
function useAsyncThrottler(fn, options, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().asyncThrottler,
		...options
	};
	const [asyncThrottler] = (0, import_react.useState)(() => {
		const asyncThrottlerInstance = new AsyncThrottler(fn, mergedOptions);
		asyncThrottlerInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(asyncThrottlerInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return asyncThrottlerInstance;
	});
	asyncThrottler.fn = fn;
	asyncThrottler.setOptions(mergedOptions);
	const state = useStore(asyncThrottler.store, selector);
	(0, import_react.useEffect)(() => {
		return () => asyncThrottler.cancel();
	}, [asyncThrottler]);
	return (0, import_react.useMemo)(() => ({
		...asyncThrottler,
		state
	}), [asyncThrottler, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/async-throttler/useAsyncThrottledCallback.js
/**
* A React hook that creates a throttled version of an async callback function.
* This hook is a convenient wrapper around the `useAsyncThrottler` hook,
* providing a stable, throttled async function reference for use in React components.
*
* The throttled async function will execute at most once within the specified wait time period,
* regardless of how many times it is called. If called multiple times during the wait period,
* only the first invocation will execute, and subsequent calls will be ignored until
* the wait period has elapsed. The returned function always returns a promise
* that resolves or rejects with the result of the original async function.
*
* This hook provides a simpler API compared to `useAsyncThrottler`, making it ideal for basic
* async throttling needs. However, it does not expose the underlying AsyncThrottler instance.
*
* For advanced usage requiring features like:
* - Manual cancellation
* - Access to execution/error state
* - Custom useCallback dependencies
*
* Consider using the `useAsyncThrottler` hook instead.
*
*
* @example
* ```tsx
* // Throttle an async API call
* const handleApiCall = useAsyncThrottledCallback(async (data) => {
*   const result = await sendDataToServer(data);
*   return result;
* }, {
*   wait: 200 // Execute at most once every 200ms
* });
*
* // Use in an event handler
* <button onClick={() => handleApiCall(formData)}>Send</button>
* ```
*/
function useAsyncThrottledCallback(fn, options) {
	const asyncThrottledFn = useAsyncThrottler(fn, options).maybeExecute;
	return (0, import_react.useCallback)((...args) => asyncThrottledFn(...args), [asyncThrottledFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/batcher.js
function getDefaultBatcherState() {
	return {
		executionCount: 0,
		isEmpty: true,
		isPending: false,
		totalItemsProcessed: 0,
		items: [],
		size: 0,
		status: "idle"
	};
}
var defaultOptions$4 = {
	getShouldExecute: () => false,
	maxSize: Infinity,
	started: true,
	wait: Infinity
};
/**
* A class that collects items and processes them in batches.
*
* Batching is a technique for grouping multiple operations together to be processed as a single unit.
* This synchronous version is lighter weight and often all you need - upgrade to AsyncBatcher when you need promises, retry support, abort/cancel capabilities, or advanced error handling.
*
* The Batcher provides a flexible way to implement batching with configurable:
* - Maximum batch size (number of items per batch)
* - Time-based batching (process after X milliseconds)
* - Custom batch processing logic via getShouldExecute
* - Event callbacks for monitoring batch operations
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the batcher
* - Use `onExecute` callback to react to batch execution and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the batcher
* - The state includes batch execution count, total items processed, items, and running status
* - State can be accessed via `batcher.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `batcher.state`
*
* @example
* ```ts
* const batcher = new Batcher<number>(
*   (items) => console.log('Processing batch:', items),
*   {
*     maxSize: 5,
*     wait: 2000,
*     onExecute: (batch, batcher) => console.log('Batch executed:', batch)
*   }
* );
*
* batcher.addItem(1);
* batcher.addItem(2);
* // After 2 seconds or when 5 items are added, whichever comes first,
* // the batch will be processed
* // batcher.flush() // manually trigger a batch
* ```
*/
var Batcher = class {
	#timeoutId = null;
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultBatcherState());
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.addItem = (item) => {
			this.#setState({
				items: [...this.store.state.items, item],
				isPending: this.options.wait !== Infinity
			});
			this.options.onItemsChange?.(this);
			if (this.store.state.items.length >= this.options.maxSize || this.options.getShouldExecute(this.store.state.items, this)) this.#execute();
			else if (this.options.wait !== Infinity) {
				this.#clearTimeout();
				this.#timeoutId = setTimeout(() => this.#execute(), this.#getWait());
			}
		};
		this.flush = () => {
			this.#clearTimeout();
			this.#execute();
		};
		this.peekAllItems = () => {
			return [...this.store.state.items];
		};
		this.clear = () => {
			this.#setState({
				items: [],
				isPending: false
			});
		};
		this.cancel = () => {
			this.#clearTimeout();
			this.#setState({ isPending: false });
		};
		this.reset = () => {
			this.#setState(getDefaultBatcherState());
			this.options.onItemsChange?.(this);
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$4,
			...initialOptions
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-Batcher", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isPending, items } = combinedState;
			const size = items.length;
			const isEmpty = size === 0;
			return {
				...combinedState,
				isEmpty,
				size,
				status: isPending ? "pending" : "idle"
			};
		});
		emitChange("Batcher", this);
	};
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait, this);
	};
	/**
	* Processes the current batch of items.
	* This method will automatically be triggered if the batcher is running and any of these conditions are met:
	* - The number of items reaches batchSize
	* - The wait duration has elapsed
	* - The getShouldExecute function returns true upon adding an item
	*
	* You can also call this method manually to process the current batch at any time.
	*/
	#execute = () => {
		if (this.store.state.items.length === 0) return;
		const batch = this.peekAllItems();
		this.clear();
		this.options.onItemsChange?.(this);
		this.fn(batch);
		this.#setState({
			executionCount: this.store.state.executionCount + 1,
			totalItemsProcessed: this.store.state.totalItemsProcessed + batch.length
		});
		this.options.onExecute?.(batch, this);
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = null;
		}
	};
};
/**
* Creates a batcher that processes items in batches.
*
* This synchronous version is lighter weight and often all you need - upgrade to asyncBatch when you need promises, retry support, abort/cancel capabilities, or advanced error handling.
*
* @example
* ```ts
* const batchItems = batch<number>(
*   (items) => console.log('Processing:', items),
*   {
*     maxSize: 3,
*     onExecute: (batch, batcher) => console.log('Batch executed:', batch)
*   }
* );
*
* batchItems(1);
* batchItems(2);
* batchItems(3); // Triggers batch processing
* ```
*/
function batch(fn, options) {
	return new Batcher(fn, options).addItem;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/batcher/useBatcher.js
/**
* A React hook that creates and manages a Batcher instance.
*
* This is a lower-level hook that provides direct access to the Batcher's functionality without
* any built-in state management. This allows you to integrate it with any state management solution
* you prefer (useState, Redux, Zustand, etc.) by utilizing the onItemsChange callback.
*
* The Batcher collects items and processes them in batches based on configurable conditions:
* - Maximum batch size
* - Time-based batching (process after X milliseconds)
* - Custom batch processing logic via getShouldExecute
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `batcher.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `executionCount`: Number of batch executions that have been completed
* - `isEmpty`: Whether the batcher has no items to process
* - `isPending`: Whether the batcher is waiting for the timeout to trigger batch processing
* - `isRunning`: Whether the batcher is active and will process items automatically
* - `items`: Array of items currently queued for batch processing
* - `size`: Number of items currently in the batch queue
* - `status`: Current processing status ('idle' | 'pending')
* - `totalItemsProcessed`: Total number of items processed across all batches
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const batcher = useBatcher<number>(
*   (items) => console.log('Processing batch:', items),
*   { maxSize: 5, wait: 2000 }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <batcher.Subscribe selector={(state) => ({ size: state.size, isPending: state.isPending })}>
*   {({ size, isPending }) => (
*     <div>Batch: {size} items, {isPending ? 'Pending' : 'Ready'}</div>
*   )}
* </batcher.Subscribe>
*
* // Opt-in to re-render when batch size changes at hook level (optimized for displaying queue size)
* const batcher = useBatcher<number>(
*   (items) => console.log('Processing batch:', items),
*   { maxSize: 5, wait: 2000 },
*   (state) => ({
*     size: state.size,
*     isEmpty: state.isEmpty
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const batcher = useBatcher<number>(
*   (items) => console.log('Processing batch:', items),
*   { maxSize: 5, wait: 2000 },
*   (state) => ({
*     executionCount: state.executionCount,
*     totalItemsProcessed: state.totalItemsProcessed
*   })
* );
*
* // Opt-in to re-render when processing state changes (optimized for loading indicators)
* const batcher = useBatcher<number>(
*   (items) => console.log('Processing batch:', items),
*   { maxSize: 5, wait: 2000 },
*   (state) => ({
*     isPending: state.isPending,
*     isRunning: state.isRunning,
*     status: state.status
*   })
* );
*
* // Example with custom state management and batching
* const [items, setItems] = useState([]);
*
* const batcher = useBatcher<number>(
*   (items) => console.log('Processing batch:', items),
*   {
*     maxSize: 5,
*     wait: 2000,
*     onItemsChange: (batcher) => setItems(batcher.peekAllItems()),
*     getShouldExecute: (items) => items.length >= 3
*   }
* );
*
* // Add items to batch - they'll be processed when conditions are met
* batcher.addItem(1);
* batcher.addItem(2);
* batcher.addItem(3); // Triggers batch processing
*
* // Control the batcher
* batcher.stop();  // Pause batching
* batcher.start(); // Resume batching
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { size, isPending } = batcher.state;
* ```
*/
function useBatcher(fn, options = {}, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().batcher,
		...options
	};
	const [batcher] = (0, import_react.useState)(() => {
		const batcherInstance = new Batcher(fn, mergedOptions);
		batcherInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(batcherInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return batcherInstance;
	});
	batcher.fn = fn;
	batcher.setOptions(mergedOptions);
	const state = useStore(batcher.store, selector);
	return (0, import_react.useMemo)(() => ({
		...batcher,
		state
	}), [batcher, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/batcher/useBatchedCallback.js
/**
* A React hook that creates a batched version of a callback function.
* This hook is essentially a wrapper around the basic `batch` function
* that is exported from `@tanstack/pacer`,
* but optimized for React with reactive options and a stable function reference.
*
* The batched function will collect individual calls into batches and execute them
* when batch conditions are met (max size reached, wait time elapsed, or custom logic).
*
* This hook provides a simpler API compared to `useBatcher`, making it ideal for basic
* batching needs. However, it does not expose the underlying Batcher instance.
*
* For advanced usage requiring features like:
* - Manual batch execution
* - Access to batch state and metrics
* - Custom useCallback dependencies
*
* Consider using the `useBatcher` hook instead.
*
* @example
* ```tsx
* // Batch analytics events
* const trackEvents = useBatchedCallback((events: AnalyticsEvent[]) => {
*   sendAnalytics(events);
* }, {
*   maxSize: 5,    // Process when 5 events collected
*   wait: 2000     // Or after 2 seconds
* });
*
* // Use in event handlers
* <button onClick={() => trackEvents({ type: 'click', target: 'button' })}>
*   Click me
* </button>
* ```
*/
function useBatchedCallback(fn, options) {
	const batchedFn = useBatcher(fn, options).addItem;
	return (0, import_react.useCallback)((...args) => batchedFn(args[0]), [batchedFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/debouncer.js
function getDefaultDebouncerState() {
	return {
		canLeadingExecute: true,
		executionCount: 0,
		isPending: false,
		lastArgs: void 0,
		status: "idle",
		maybeExecuteCount: 0
	};
}
/**
* Utility function for sharing common `DebouncerOptions` options between different `Debouncer` instances.
*/
function debouncerOptions(options) {
	return options;
}
var defaultOptions$3 = {
	enabled: true,
	leading: false,
	trailing: true,
	wait: 0
};
/**
* A class that creates a debounced function.
*
* Debouncing ensures that a function is only executed after a certain amount of time has passed
* since its last invocation. This is useful for handling frequent events like window resizing,
* scroll events, or input changes where you want to limit the rate of execution.
* This synchronous version is lighter weight and often all you need - upgrade to AsyncDebouncer when you need promises, retry support, abort/cancel capabilities, or advanced error handling.
*
* The debounced function can be configured to execute either at the start of the delay period
* (leading edge) or at the end (trailing edge, default). Each new call during the wait period
* will reset the timer.
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the debouncer
* - Use `onExecute` callback to react to function execution and implement custom logic
* - The state includes canLeadingExecute, execution count, and isPending status
* - State can be accessed via `debouncer.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `debouncer.state`
*
* @example
* ```ts
* const debouncer = new Debouncer((value: string) => {
*   saveToDatabase(value);
* }, { wait: 500 });
*
* // Will only save after 500ms of no new input
* inputElement.addEventListener('input', () => {
*   debouncer.maybeExecute(inputElement.value);
* });
* ```
*/
var Debouncer = class {
	#timeoutId;
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultDebouncerState());
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
			if (!this.#getEnabled()) this.cancel();
		};
		this.maybeExecute = (...args) => {
			if (!this.#getEnabled()) return void 0;
			this.#setState({ maybeExecuteCount: this.store.state.maybeExecuteCount + 1 });
			let _didLeadingExecute = false;
			if (this.options.leading && this.store.state.canLeadingExecute) {
				this.#setState({ canLeadingExecute: false });
				_didLeadingExecute = true;
				this.#execute(...args);
			}
			if (this.options.trailing) this.#setState({
				isPending: true,
				lastArgs: args
			});
			if (this.#timeoutId) clearTimeout(this.#timeoutId);
			this.#timeoutId = setTimeout(() => {
				this.#setState({ canLeadingExecute: true });
				if (this.options.trailing && !_didLeadingExecute) this.#execute(...args);
			}, this.#getWait());
		};
		this.flush = () => {
			if (this.store.state.isPending && this.store.state.lastArgs) {
				this.#clearTimeout();
				this.#execute(...this.store.state.lastArgs);
			}
		};
		this.cancel = () => {
			this.#clearTimeout();
			this.#setState({
				canLeadingExecute: true,
				isPending: false
			});
		};
		this.reset = () => {
			this.#setState(getDefaultDebouncerState());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$3,
			...initialOptions
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-Debouncer", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isPending } = combinedState;
			return {
				...combinedState,
				status: !this.#getEnabled() ? "disabled" : isPending ? "pending" : "idle"
			};
		});
		emitChange("Debouncer", this);
	};
	/**
	* Returns the current enabled state of the debouncer
	*/
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	/**
	* Returns the current wait time in milliseconds
	*/
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait, this);
	};
	#execute = (...args) => {
		if (!this.#getEnabled()) return void 0;
		this.fn(...args);
		this.#setState({
			executionCount: this.store.state.executionCount + 1,
			isPending: false,
			lastArgs: void 0
		});
		this.options.onExecute?.(args, this);
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = void 0;
		}
	};
};
/**
* Creates a debounced function that delays invoking the provided function until after a specified wait time.
* Multiple calls during the wait period will cancel previous pending invocations and reset the timer.
*
* This synchronous version is lighter weight and often all you need - upgrade to asyncDebounce when you need promises, retry support, abort/cancel capabilities, or advanced error handling.
*
* If leading option is true, the function will execute immediately on the first call, then wait the delay
* before allowing another execution.
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the debouncer
* - Use `onExecute` callback to react to function execution and implement custom logic
* - The state includes canLeadingExecute, execution count, and isPending status
* - State can be accessed via the underlying Debouncer instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* @example
* ```ts
* const debounced = debounce(() => {
*   saveChanges();
* }, { wait: 1000 });
*
* // Called repeatedly but executes at most once per second
* inputElement.addEventListener('input', debounced);
* ```
*/
function debounce(fn, initialOptions) {
	return new Debouncer(fn, initialOptions).maybeExecute;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/debouncer/useDebouncer.js
/**
* A React hook that creates and manages a Debouncer instance.
*
* This is a lower-level hook that provides direct access to the Debouncer's functionality without
* any built-in state management. This allows you to integrate it with any state management solution
* you prefer (useState, Redux, Zustand, etc.).
*
* This hook provides debouncing functionality to limit how often a function can be called,
* waiting for a specified delay before executing the latest call. This is useful for handling
* frequent events like window resizing, scroll events, or real-time search inputs.
*
* The debouncer will only execute the function after the specified wait time has elapsed
* since the last call. If the function is called again before the wait time expires, the
* timer resets and starts waiting again.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `debouncer.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `canLeadingExecute`: Whether the debouncer can execute on the leading edge
* - `executionCount`: Number of function executions that have been completed
* - `isPending`: Whether the debouncer is waiting for the timeout to trigger execution
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `status`: Current execution status ('disabled' | 'idle' | 'pending')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const searchDebouncer = useDebouncer(
*   (query: string) => fetchSearchResults(query),
*   { wait: 500 }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <searchDebouncer.Subscribe selector={(state) => ({ isPending: state.isPending })}>
*   {({ isPending }) => (
*     <div>{isPending ? 'Searching...' : 'Ready'}</div>
*   )}
* </searchDebouncer.Subscribe>
*
* // Opt-in to re-render when isPending changes at hook level (optimized for loading states)
* const searchDebouncer = useDebouncer(
*   (query: string) => fetchSearchResults(query),
*   { wait: 500 },
*   (state) => ({ isPending: state.isPending })
* );
*
* // Opt-in to re-render when executionCount changes (optimized for tracking execution)
* const searchDebouncer = useDebouncer(
*   (query: string) => fetchSearchResults(query),
*   { wait: 500 },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Multiple state properties - re-render when any of these change
* const searchDebouncer = useDebouncer(
*   (query: string) => fetchSearchResults(query),
*   { wait: 500 },
*   (state) => ({
*     isPending: state.isPending,
*     executionCount: state.executionCount,
*     status: state.status
*   })
* );
*
* // In an event handler
* const handleChange = (e) => {
*   searchDebouncer.maybeExecute(e.target.value);
* };
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { isPending } = searchDebouncer.state;
* ```
*/
function useDebouncer(fn, options, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().debouncer,
		...options
	};
	const [debouncer] = (0, import_react.useState)(() => {
		const debouncerInstance = new Debouncer(fn, mergedOptions);
		debouncerInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(debouncerInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return debouncerInstance;
	});
	debouncer.fn = fn;
	debouncer.setOptions(mergedOptions);
	(0, import_react.useEffect)(() => {
		return () => {
			debouncer.cancel();
		};
	}, [debouncer]);
	const state = useStore(debouncer.store, selector);
	return (0, import_react.useMemo)(() => ({
		...debouncer,
		state
	}), [debouncer, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/debouncer/useDebouncedCallback.js
/**
* A React hook that creates a debounced version of a callback function.
* This hook is essentially a wrapper around the basic `debounce` function
* that is exported from `@tanstack/pacer`,
* but optimized for React with reactive options and a stable function reference.
*
* The debounced function will only execute after the specified wait time has elapsed
* since its last invocation. If called again before the wait time expires, the timer
* resets and starts waiting again.
*
* This hook provides a simpler API compared to `useDebouncer`, making it ideal for basic
* debouncing needs. However, it does not expose the underlying Debouncer instance.
*
* For advanced usage requiring features like:
* - Manual cancellation
* - Access to execution counts
* - Custom useCallback dependencies
*
* Consider using the `useDebouncer` hook instead.
*
* @example
* ```tsx
* // Debounce a search handler
* const handleSearch = useDebouncedCallback((query: string) => {
*   fetchSearchResults(query);
* }, {
*   wait: 500 // Wait 500ms between executions
* });
*
* // Use in an input
* <input
*   type="search"
*   onChange={(e) => handleSearch(e.target.value)}
* />
* ```
*/
function useDebouncedCallback(fn, options) {
	const debouncedFn = useDebouncer(fn, options).maybeExecute;
	return (0, import_react.useCallback)((...args) => debouncedFn(...args), [debouncedFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/debouncer/useDebouncedState.js
/**
* A React hook that creates a debounced state value, combining React's useState with debouncing functionality.
* This hook provides both the current debounced value and methods to update it.
*
* The state value is only updated after the specified wait time has elapsed since the last update attempt.
* If another update is attempted before the wait time expires, the timer resets and starts waiting again.
* This is useful for handling frequent state updates that should be throttled, like search input values
* or window resize dimensions.
*
* The hook returns a tuple containing:
* - The current debounced value
* - A function to update the debounced value
* - The debouncer instance with additional control methods
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying debouncer instance.
* The `selector` parameter allows you to specify which debouncer state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available debouncer state properties:
* - `canLeadingExecute`: Whether the debouncer can execute on the leading edge
* - `executionCount`: Number of function executions that have been completed
* - `isPending`: Whether the debouncer is waiting for the timeout to trigger execution
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `status`: Current execution status ('disabled' | 'idle' | 'pending')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [searchTerm, setSearchTerm, debouncer] = useDebouncedState('', {
*   wait: 500 // Wait 500ms after last keystroke
* });
*
* // Opt-in to re-render when pending state changes (optimized for loading indicators)
* const [searchTerm, setSearchTerm, debouncer] = useDebouncedState(
*   '',
*   { wait: 500 },
*   (state) => ({ isPending: state.isPending })
* );
*
* // Opt-in to re-render when execution count changes (optimized for tracking executions)
* const [searchTerm, setSearchTerm, debouncer] = useDebouncedState(
*   '',
*   { wait: 500 },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when debouncing status changes (optimized for status display)
* const [searchTerm, setSearchTerm, debouncer] = useDebouncedState(
*   '',
*   { wait: 500 },
*   (state) => ({
*     status: state.status,
*     canLeadingExecute: state.canLeadingExecute
*   })
* );
*
* // Update value - will be debounced
* const handleChange = (e) => {
*   setSearchTerm(e.target.value);
* };
*
* // Access the selected debouncer state (will be empty object {} unless selector provided)
* const { isPending, executionCount } = debouncer.state;
* ```
*/
function useDebouncedState(value, options, selector) {
	const [debouncedValue, setDebouncedValue] = (0, import_react.useState)(value);
	const debouncer = useDebouncer(setDebouncedValue, options, selector);
	return [
		debouncedValue,
		debouncer.maybeExecute,
		debouncer
	];
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/debouncer/useDebouncedValue.js
/**
* A React hook that creates a debounced value that updates only after a specified delay.
* Unlike useDebouncedState, this hook automatically tracks changes to the input value
* and updates the debounced value accordingly.
*
* The debounced value will only update after the specified wait time has elapsed since
* the last change to the input value. If the input value changes again before the wait
* time expires, the timer resets and starts waiting again.
*
* This is useful for deriving debounced values from props or state that change frequently,
* like search queries or form inputs, where you want to limit how often downstream effects
* or calculations occur.
*
* The hook returns the current debounced value and the underlying debouncer instance.
* The debouncer instance can be used to access additional functionality like cancellation
* and execution counts.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying debouncer instance.
* The `selector` parameter allows you to specify which debouncer state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available debouncer state properties:
* - `canLeadingExecute`: Whether the debouncer can execute on the leading edge
* - `executionCount`: Number of function executions that have been completed
* - `isPending`: Whether the debouncer is waiting for the timeout to trigger execution
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `status`: Current execution status ('disabled' | 'idle' | 'pending')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [searchQuery, setSearchQuery] = useState('');
* const [debouncedQuery, debouncer] = useDebouncedValue(searchQuery, {
*   wait: 500 // Wait 500ms after last change
* });
*
* // Opt-in to re-render when pending state changes (optimized for loading indicators)
* const [debouncedQuery, debouncer] = useDebouncedValue(
*   searchQuery,
*   { wait: 500 },
*   (state) => ({ isPending: state.isPending })
* );
*
* // Opt-in to re-render when execution count changes (optimized for tracking executions)
* const [debouncedQuery, debouncer] = useDebouncedValue(
*   searchQuery,
*   { wait: 500 },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when debouncing status changes (optimized for status display)
* const [debouncedQuery, debouncer] = useDebouncedValue(
*   searchQuery,
*   { wait: 500 },
*   (state) => ({
*     status: state.status,
*     canLeadingExecute: state.canLeadingExecute
*   })
* );
*
* // debouncedQuery will update 500ms after searchQuery stops changing
* useEffect(() => {
*   fetchSearchResults(debouncedQuery);
* }, [debouncedQuery]);
*
* // Handle input changes
* const handleChange = (e) => {
*   setSearchQuery(e.target.value);
* };
*
* // Access the selected debouncer state (will be empty object {} unless selector provided)
* const { isPending, executionCount } = debouncer.state;
* ```
*/
function useDebouncedValue(value, options, selector) {
	const [debouncedValue, setDebouncedValue, debouncer] = useDebouncedState(value, options, selector);
	(0, import_react.useEffect)(() => {
		setDebouncedValue(value);
	}, [value, setDebouncedValue]);
	return [debouncedValue, debouncer];
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/queuer.js
function getDefaultQueuerState() {
	return {
		executionCount: 0,
		expirationCount: 0,
		isEmpty: true,
		isFull: false,
		isIdle: true,
		isRunning: true,
		itemTimestamps: [],
		items: [],
		pendingTick: false,
		rejectionCount: 0,
		size: 0,
		status: "idle",
		addItemCount: 0
	};
}
/**
* Utility function for sharing common `QueuerOptions` options between different `Queuer` instances.
*/
function queuerOptions(options) {
	return options;
}
var defaultOptions$2 = {
	addItemsTo: "back",
	getItemsFrom: "front",
	getPriority: (item) => item?.priority ?? 0,
	getIsExpired: () => false,
	expirationDuration: Infinity,
	initialItems: [],
	maxSize: Infinity,
	started: true,
	wait: 0
};
/**
* A flexible queue that processes items with configurable wait times, expiration, and priority.
*
* This synchronous version is lighter weight and often all you need - upgrade to AsyncQueuer when you need promises, retry support, abort capabilities, concurrent execution, or advanced error handling.
*
* Features:
* - Automatic or manual processing of items
* - FIFO (First In First Out), LIFO (Last In First Out), or double-ended queue behavior
* - Priority-based ordering when getPriority is provided
* - Item expiration and removal of stale items
* - Callbacks for queue state changes, execution, rejection, and expiration
*
* Running behavior:
* - `start()`: Begins automatically processing items in the queue (defaults to isRunning)
* - `stop()`: Pauses processing but maintains queue state
* - `wait`: Configurable delay between processing items
* - `onItemsChange`/`onExecute`: Callbacks for monitoring queue state
*
* Manual processing is also supported when automatic processing is disabled:
* - `execute()`: Processes the next item using the provided function
* - `getNextItem()`: Removes and returns the next item without processing
*
* Queue behavior defaults to FIFO:
* - `addItem(item)`: Adds to the back of the queue
* - Items processed from the front of the queue
*
* Priority queue:
* - Provide a `getPriority` function; higher values are processed first
*
* Stack (LIFO):
* - `addItem(item, 'back')`: Adds to the back
* - `getNextItem('back')`: Removes from the back
*
* Double-ended queue:
* - `addItem(item, position)`: Adds to specified position ('front'/'back')
* - `getNextItem(position)`: Removes from specified position
*
* Item expiration:
* - `expirationDuration`: Maximum time items can stay in the queue
* - `getIsExpired`: Function to override default expiration
* - `onExpire`: Callback for expired items
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the queuer
* - Use `onExecute` callback to react to item execution and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the queue
* - Use `onExpire` callback to react to items expiring and implement custom logic
* - Use `onReject` callback to react to items being rejected when the queue is full
* - The state includes execution count, expiration count, rejection count, and isRunning status
* - State can be accessed via `queuer.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `queuer.state`
*
* Example usage:
* ```ts
* // Auto-processing queue with wait time
* const autoQueue = new Queuer<number>((n) => console.log(n), {
*   started: true, // Begin processing immediately
*   wait: 1000, // Wait 1s between items
*   onExecute: (item, queuer) => console.log(`Processed ${item}`)
* });
* autoQueue.addItem(1); // Will process after 1s
* autoQueue.addItem(2); // Will process 1s after first item
*
* // Manual processing queue
* const manualQueue = new Queuer<number>((n) => console.log(n), {
*   started: false
* });
* manualQueue.addItem(1); // [1]
* manualQueue.addItem(2); // [1, 2]
* manualQueue.execute(); // logs 1, queue is [2]
* manualQueue.getNextItem(); // returns 2, queue is empty
* ```
*/
var Queuer = class {
	#timeoutId = null;
	constructor(fn, initialOptions = {}) {
		this.fn = fn;
		this.store = new Store(getDefaultQueuerState());
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.addItem = (item, position = this.options.addItemsTo ?? "back", runOnItemsChange = true) => {
			this.#setState({ addItemCount: this.store.state.addItemCount + 1 });
			if (this.store.state.items.length >= (this.options.maxSize ?? Infinity)) {
				this.#setState({ rejectionCount: this.store.state.rejectionCount + 1 });
				this.options.onReject?.(item, this);
				return false;
			}
			const priority = this.options.getPriority !== defaultOptions$2.getPriority ? this.options.getPriority(item) : item.priority;
			const items = this.store.state.items;
			const itemTimestamps = this.store.state.itemTimestamps;
			if (priority !== void 0) {
				const insertIndex = items.findIndex((existing) => {
					return (this.options.getPriority !== defaultOptions$2.getPriority ? this.options.getPriority(existing) : existing.priority) < priority;
				});
				if (insertIndex === -1) {
					items.push(item);
					itemTimestamps.push(Date.now());
				} else {
					items.splice(insertIndex, 0, item);
					itemTimestamps.splice(insertIndex, 0, Date.now());
				}
			} else if (position === "front") {
				items.unshift(item);
				itemTimestamps.unshift(Date.now());
			} else {
				items.push(item);
				itemTimestamps.push(Date.now());
			}
			this.#setState({
				items,
				itemTimestamps
			});
			if (runOnItemsChange) this.options.onItemsChange?.(this);
			if (this.store.state.isRunning && !this.store.state.pendingTick) {
				this.#setState({ pendingTick: true });
				this.#tick();
			}
			return true;
		};
		this.getNextItem = (position = this.options.getItemsFrom ?? "front") => {
			const { items, itemTimestamps } = this.store.state;
			let item;
			if (this.options.getPriority !== defaultOptions$2.getPriority || position === "front") {
				item = items[0];
				if (item !== void 0) this.#setState({
					items: items.slice(1),
					itemTimestamps: itemTimestamps.slice(1)
				});
			} else {
				item = items[items.length - 1];
				if (item !== void 0) this.#setState({
					items: items.slice(0, -1),
					itemTimestamps: itemTimestamps.slice(0, -1)
				});
			}
			if (item !== void 0) this.options.onItemsChange?.(this);
			return item;
		};
		this.execute = (position) => {
			const item = this.getNextItem(position);
			if (item !== void 0) {
				this.fn(item);
				this.#setState({ executionCount: this.store.state.executionCount + 1 });
				this.options.onExecute?.(item, this);
			}
			return item;
		};
		this.flush = (numberOfItems = this.store.state.items.length, position) => {
			this.#clearTimeout();
			for (let i = 0; i < numberOfItems; i++) this.execute(position);
			this.#tick();
		};
		this.flushAsBatch = (batchFunction) => {
			const items = this.#getAllItems();
			this.clear();
			batchFunction(items);
		};
		this.peekNextItem = (position = "front") => {
			if (position === "front") return this.store.state.items[0];
			return this.store.state.items[this.store.state.items.length - 1];
		};
		this.peekAllItems = () => {
			return [...this.store.state.items];
		};
		this.start = () => {
			this.#setState({ isRunning: true });
			if (!this.store.state.pendingTick && this.store.state.items.length > 0) this.#tick();
		};
		this.stop = () => {
			this.#clearTimeout();
			this.#setState({
				isRunning: false,
				pendingTick: false
			});
		};
		this.clear = () => {
			this.#setState({
				items: [],
				itemTimestamps: []
			});
			this.options.onItemsChange?.(this);
		};
		this.reset = () => {
			this.#setState(getDefaultQueuerState());
			this.options.onItemsChange?.(this);
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$2,
			...initialOptions
		};
		const isInitiallyRunning = this.options.initialState?.isRunning ?? this.options.started ?? true;
		this.#setState({
			...this.options.initialState,
			isRunning: isInitiallyRunning
		});
		if (this.options.initialState?.items) {
			if (this.store.state.isRunning) this.#tick();
		} else for (let i = 0; i < (this.options.initialItems?.length ?? 0); i++) {
			const item = this.options.initialItems[i];
			const isLast = i === (this.options.initialItems?.length ?? 0) - 1;
			this.addItem(item, this.options.addItemsTo ?? "back", isLast);
		}
		if (this.key) pacerEventClient.on("d-Queuer", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { items, isRunning } = combinedState;
			const size = items.length;
			const isFull = size >= (this.options.maxSize ?? Infinity);
			const isEmpty = size === 0;
			const isIdle = isRunning && isEmpty;
			const status = isIdle ? "idle" : isRunning ? "running" : "stopped";
			return {
				...combinedState,
				isEmpty,
				isFull,
				isIdle,
				size,
				status
			};
		});
		emitChange("Queuer", this);
	};
	/**
	* Returns the current wait time (in milliseconds) between processing items.
	* If a function is provided, it is called with the queuer instance.
	*/
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait ?? 0, this);
	};
	/**
	* Processes items in the queue up to the wait interval. Internal use only.
	*/
	#tick = () => {
		if (!this.store.state.isRunning) {
			this.#setState({ pendingTick: false });
			return;
		}
		this.#setState({ pendingTick: true });
		this.#checkExpiredItems();
		while (this.store.state.items.length > 0) {
			if (this.execute(this.options.getItemsFrom ?? "front") === void 0) break;
			const wait = this.#getWait();
			if (wait > 0) {
				this.#timeoutId = setTimeout(() => this.#tick(), wait);
				return;
			}
			this.#tick();
		}
		this.#setState({ pendingTick: false });
	};
	#getAllItems = () => {
		const items = this.peekAllItems();
		this.clear();
		return items;
	};
	/**
	* Checks for expired items in the queue and removes them. Calls onExpire for each expired item.
	* Internal use only.
	*/
	#checkExpiredItems = () => {
		if ((this.options.expirationDuration ?? Infinity) === Infinity && this.options.getIsExpired === defaultOptions$2.getIsExpired) return;
		const now = Date.now();
		const expiredIndices = [];
		for (let i = 0; i < this.store.state.items.length; i++) {
			const timestamp = this.store.state.itemTimestamps[i];
			if (timestamp === void 0) continue;
			const item = this.store.state.items[i];
			if (item === void 0) continue;
			if (this.options.getIsExpired !== defaultOptions$2.getIsExpired ? this.options.getIsExpired(item, timestamp) : now - timestamp > (this.options.expirationDuration ?? Infinity)) expiredIndices.push(i);
		}
		for (let i = expiredIndices.length - 1; i >= 0; i--) {
			const index = expiredIndices[i];
			if (index === void 0) continue;
			const expiredItem = this.store.state.items[index];
			if (expiredItem === void 0) continue;
			const newItems = [...this.store.state.items];
			const newTimestamps = [...this.store.state.itemTimestamps];
			newItems.splice(index, 1);
			newTimestamps.splice(index, 1);
			this.#setState({
				items: newItems,
				itemTimestamps: newTimestamps,
				expirationCount: this.store.state.expirationCount + 1
			});
			this.options.onExpire?.(expiredItem, this);
		}
		if (expiredIndices.length > 0) this.options.onItemsChange?.(this);
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = null;
		}
	};
};
/**
* Creates a queue that processes items immediately upon addition.
* Items are processed sequentially in FIFO order by default.
*
* This synchronous version is lighter weight and often all you need - upgrade to asyncQueue when you need promises, retry support, abort capabilities, concurrent execution, or advanced error handling.
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the queuer
* - Use `onExecute` callback to react to item execution and implement custom logic
* - Use `onItemsChange` callback to react to items being added or removed from the queue
* - Use `onExpire` callback to react to items expiring and implement custom logic
* - Use `onReject` callback to react to items being rejected when the queue is full
* - The state includes execution count, expiration count, rejection count, and isRunning status
* - State can be accessed via the underlying Queuer instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* Example usage:
* ```ts
* // Basic sequential processing
* const processItems = queue<number>((n) => console.log(n), {
*   wait: 1000,
*   onItemsChange: (queuer) => console.log(queuer.peekAllItems())
* });
* processItems(1); // Logs: 1
* processItems(2); // Logs: 2 after 1 completes
*
* // Priority queue
* const processPriority = queue<number>((n) => console.log(n), {
*   getPriority: n => n // Higher numbers processed first
* });
* processPriority(1);
* processPriority(3); // Processed before 1
* ```
*/
function queue(fn, initialOptions) {
	return new Queuer(fn, initialOptions).addItem;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/queuer/useQueuer.js
/**
* A React hook that creates and manages a Queuer instance.
*
* This is a lower-level hook that provides direct access to the Queuer's functionality without
* any built-in state management. This allows you to integrate it with any state management solution
* you prefer (useState, Redux, Zustand, etc.) by utilizing the onItemsChange callback.
*
* For a hook with built-in state management, see useQueuedState.
*
* The Queuer extends the base Queue to add processing capabilities. Items are processed
* synchronously in order, with optional delays between processing each item. The queuer includes
* an internal tick mechanism that can be started and stopped, making it useful as a scheduler.
* When started, it will process one item per tick, with an optional wait time between ticks.
*
* By default uses FIFO (First In First Out) behavior, but can be configured for LIFO
* (Last In First Out) by specifying 'front' position when adding items.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `queuer.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `executionCount`: Number of items that have been processed by the queuer
* - `expirationCount`: Number of items that have been removed due to expiration
* - `isEmpty`: Whether the queuer has no items to process
* - `isFull`: Whether the queuer has reached its maximum capacity
* - `isIdle`: Whether the queuer is not currently processing any items
* - `isRunning`: Whether the queuer is active and will process items automatically
* - `items`: Array of items currently waiting to be processed
* - `itemTimestamps`: Timestamps when items were added for expiration tracking
* - `pendingTick`: Whether the queuer has a pending timeout for processing the next item
* - `rejectionCount`: Number of items that have been rejected from being added
* - `size`: Number of items currently in the queue
* - `status`: Current processing status ('idle' | 'running' | 'stopped')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const queue = useQueuer(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 }
* );
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <queue.Subscribe selector={(state) => ({ size: state.size, isRunning: state.isRunning })}>
*   {({ size, isRunning }) => (
*     <div>Queue: {size} items, {isRunning ? 'Processing' : 'Idle'}</div>
*   )}
* </queue.Subscribe>
*
* // Opt-in to re-render when queue size changes at hook level (optimized for displaying queue length)
* const queue = useQueuer(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 },
*   (state) => ({
*     size: state.size,
*     isEmpty: state.isEmpty,
*     isFull: state.isFull
*   })
* );
*
* // Opt-in to re-render when processing state changes (optimized for loading indicators)
* const queue = useQueuer(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 },
*   (state) => ({
*     isRunning: state.isRunning,
*     isIdle: state.isIdle,
*     status: state.status,
*     pendingTick: state.pendingTick
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const queue = useQueuer(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 },
*   (state) => ({
*     executionCount: state.executionCount,
*     expirationCount: state.expirationCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Example with custom state management and scheduling
* const [items, setItems] = useState([]);
*
* const queue = useQueuer(
*   (item) => console.log('Processing:', item),
*   {
*     started: true, // Start processing immediately
*     wait: 1000,    // Process one item every second
*     onItemsChange: (queue) => setItems(queue.peekAllItems()),
*     getPriority: (item) => item.priority // Process higher priority items first
*   }
* );
*
* // Add items to process - they'll be handled automatically
* queue.addItem('task1');
* queue.addItem('task2');
*
* // Control the scheduler
* queue.stop();  // Pause processing
* queue.start(); // Resume processing
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { size, isRunning, executionCount } = queue.state;
* ```
*/
function useQueuer(fn, options = {}, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().queuer,
		...options
	};
	const [queuer] = (0, import_react.useState)(() => {
		const queuerInstance = new Queuer(fn, mergedOptions);
		queuerInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(queuerInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return queuerInstance;
	});
	queuer.fn = fn;
	queuer.setOptions(mergedOptions);
	const state = useStore(queuer.store, selector);
	return (0, import_react.useMemo)(() => ({
		...queuer,
		state
	}), [queuer, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/queuer/useQueuedState.js
/**
* A React hook that creates a queuer with managed state, combining React's useState with queuing functionality.
* This hook provides both the current queue state and queue control methods.
*
* The queue state is automatically updated whenever items are added, removed, or reordered in the queue.
* All queue operations are reflected in the state array returned by the hook.
*
* The queue can be started and stopped to automatically process items at a specified interval,
* making it useful as a scheduler. When started, it will process one item per tick, with an
* optional wait time between ticks.
*
* The hook returns a tuple containing:
* - The current queue state as an array
* - The queue instance with methods for queue manipulation
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying queuer instance.
* The `selector` parameter allows you to specify which queuer state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available queuer state properties:
* - `executionCount`: Number of items that have been processed by the queuer
* - `expirationCount`: Number of items that have been removed due to expiration
* - `isEmpty`: Whether the queuer has no items to process
* - `isFull`: Whether the queuer has reached its maximum capacity
* - `isIdle`: Whether the queuer is not currently processing any items
* - `isRunning`: Whether the queuer is active and will process items automatically
* - `items`: Array of items currently waiting to be processed
* - `itemTimestamps`: Timestamps when items were added for expiration tracking
* - `pendingTick`: Whether the queuer has a pending timeout for processing the next item
* - `rejectionCount`: Number of items that have been rejected from being added
* - `size`: Number of items currently in the queue
* - `status`: Current processing status ('idle' | 'running' | 'stopped')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [items, addItem, queue] = useQueuedState(
*   (item) => console.log('Processing:', item),
*   {
*     initialItems: ['item1', 'item2'],
*     started: true,
*     wait: 1000,
*     getPriority: (item) => item.priority
*   }
* );
*
* // Opt-in to re-render when queue contents change (optimized for displaying queue items)
* const [items, addItem, queue] = useQueuedState(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 },
*   (state) => ({
*     items: state.items,
*     size: state.size,
*     isEmpty: state.isEmpty
*   })
* );
*
* // Opt-in to re-render when processing state changes (optimized for loading indicators)
* const [items, addItem, queue] = useQueuedState(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 },
*   (state) => ({
*     isRunning: state.isRunning,
*     isIdle: state.isIdle,
*     status: state.status,
*     pendingTick: state.pendingTick
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const [items, addItem, queue] = useQueuedState(
*   (item) => console.log('Processing:', item),
*   { started: true, wait: 1000 },
*   (state) => ({
*     executionCount: state.executionCount,
*     expirationCount: state.expirationCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Add items to queue
* const handleAdd = (item) => {
*   addItem(item);
* };
*
* // Start automatic processing
* const startProcessing = () => {
*   queue.start();
* };
*
* // Stop automatic processing
* const stopProcessing = () => {
*   queue.stop();
* };
*
* // Manual processing still available
* const handleProcess = () => {
*   const nextItem = queue.getNextItem();
*   if (nextItem) {
*     processItem(nextItem);
*   }
* };
*
* // Access the selected queuer state (will be empty object {} unless selector provided)
* const { size, isRunning, executionCount } = queue.state;
* ```
*/
function useQueuedState(fn, options = {}, selector) {
	const queue = useQueuer(fn, options, selector);
	return [
		queue.state.items,
		queue.addItem,
		queue
	];
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/queuer/useQueuedValue.js
/**
* A React hook that creates a queued value that processes state changes in order with an optional delay.
* This hook uses useQueuer internally to manage a queue of state changes and apply them sequentially.
*
* The queued value will process changes in the order they are received, with optional delays between
* processing each change. This is useful for handling state updates that need to be processed
* in a specific order, like animations or sequential UI updates.
*
* The hook returns a tuple containing:
* - The current queued value
* - The queuer instance with control methods
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying queuer instance.
* The `selector` parameter allows you to specify which queuer state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available queuer state properties:
* - `executionCount`: Number of items that have been processed by the queuer
* - `expirationCount`: Number of items that have been removed due to expiration
* - `isEmpty`: Whether the queuer has no items to process
* - `isFull`: Whether the queuer has reached its maximum capacity
* - `isIdle`: Whether the queuer is not currently processing any items
* - `isRunning`: Whether the queuer is active and will process items automatically
* - `items`: Array of items currently waiting to be processed
* - `itemTimestamps`: Timestamps when items were added for expiration tracking
* - `pendingTick`: Whether the queuer has a pending timeout for processing the next item
* - `rejectionCount`: Number of items that have been rejected from being added
* - `size`: Number of items currently in the queue
* - `status`: Current processing status ('idle' | 'running' | 'stopped')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [value, queuer] = useQueuedValue(initialValue, {
*   wait: 500, // Wait 500ms between processing each change
*   started: true // Start processing immediately
* });
*
* // Opt-in to re-render when queue processing state changes (optimized for loading indicators)
* const [value, queuer] = useQueuedValue(
*   initialValue,
*   { wait: 500, started: true },
*   (state) => ({
*     isRunning: state.isRunning,
*     isIdle: state.isIdle,
*     status: state.status,
*     pendingTick: state.pendingTick
*   })
* );
*
* // Opt-in to re-render when queue contents change (optimized for displaying queue status)
* const [value, queuer] = useQueuedValue(
*   initialValue,
*   { wait: 500, started: true },
*   (state) => ({
*     size: state.size,
*     isEmpty: state.isEmpty,
*     isFull: state.isFull
*   })
* );
*
* // Opt-in to re-render when execution metrics change (optimized for stats display)
* const [value, queuer] = useQueuedValue(
*   initialValue,
*   { wait: 500, started: true },
*   (state) => ({
*     executionCount: state.executionCount,
*     expirationCount: state.expirationCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Add changes to the queue
* const handleChange = (newValue) => {
*   queuer.addItem(newValue);
* };
*
* // Control the queue
* const pauseProcessing = () => {
*   queuer.stop();
* };
*
* const resumeProcessing = () => {
*   queuer.start();
* };
*
* // Access the selected queuer state (will be empty object {} unless selector provided)
* const { size, isRunning, executionCount } = queuer.state;
* ```
*/
function useQueuedValue(initialValue, options = {}, selector) {
	const [value, setValue] = (0, import_react.useState)(initialValue);
	const [, addItem, queuer] = useQueuedState((item) => {
		setValue(item);
	}, options, selector);
	(0, import_react.useEffect)(() => {
		addItem(initialValue);
	}, [initialValue, addItem]);
	return [value, queuer];
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/rate-limiter.js
function getDefaultRateLimiterState() {
	return {
		executionCount: 0,
		executionTimes: [],
		isExceeded: false,
		rejectionCount: 0,
		status: "idle",
		maybeExecuteCount: 0
	};
}
/**
* Utility function for sharing common `RateLimiterOptions` options between different `RateLimiter` instances.
*/
function rateLimiterOptions(options) {
	return options;
}
var defaultOptions$1 = {
	enabled: true,
	limit: 1,
	window: 0,
	windowType: "fixed"
};
/**
* A class that creates a rate-limited function.
*
* Rate limiting is a simple approach that allows a function to execute up to a limit within a time window,
* then blocks all subsequent calls until the window passes. This can lead to "bursty" behavior where
* all executions happen immediately, followed by a complete block.
* This synchronous version is lighter weight and often all you need - upgrade to AsyncRateLimiter when you need promises, retry support, abort capabilities, or advanced error handling.
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* For smoother execution patterns, consider using:
* - Throttling: Ensures consistent spacing between executions (e.g. max once per 200ms)
* - Debouncing: Waits for a pause in calls before executing (e.g. after 500ms of no calls)
*
* Rate limiting is best used for hard API limits or resource constraints. For UI updates or
* smoothing out frequent events, throttling or debouncing usually provide better user experience.
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the rate limiter
* - Use `onExecute` callback to react to function execution and implement custom logic
* - Use `onReject` callback to react to executions being rejected when rate limit is exceeded
* - The state includes execution count, execution times, and rejection count
* - State can be accessed via `rateLimiter.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `rateLimiter.state`
*
* @example
* ```ts
* const rateLimiter = new RateLimiter(
*   (id: string) => api.getData(id),
*   {
*     limit: 5,
*     window: 1000,
*     windowType: 'sliding',
*   }
* );
*
* // Will execute immediately until limit reached, then block
* rateLimiter.maybeExecute('123');
* ```
*/
var RateLimiter = class {
	#timeoutIds = /* @__PURE__ */ new Set();
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultRateLimiterState());
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
		};
		this.maybeExecute = (...args) => {
			this.#setState({ maybeExecuteCount: this.store.state.maybeExecuteCount + 1 });
			this.#cleanupOldExecutions();
			if (this.#getExecutionTimesInWindow().length < this.#getLimit()) {
				this.#execute(...args);
				return true;
			}
			this.#setState({ rejectionCount: this.store.state.rejectionCount + 1 });
			this.options.onReject?.(this);
			return false;
		};
		this.getRemainingInWindow = () => {
			const relevantExecutionTimes = this.#getExecutionTimesInWindow();
			return Math.max(0, this.#getLimit() - relevantExecutionTimes.length);
		};
		this.getMsUntilNextWindow = () => {
			if (this.getRemainingInWindow() > 0) return 0;
			return (this.store.state.executionTimes[0] ?? Infinity) + this.#getWindow() - Date.now();
		};
		this.reset = () => {
			this.#setState(getDefaultRateLimiterState());
			this.#clearTimeouts();
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions$1,
			...initialOptions
		};
		this.#setState(this.options.initialState ?? {});
		for (const executionTime of this.#getExecutionTimesInWindow()) this.#setCleanupTimeout(executionTime);
		if (this.key) pacerEventClient.on("d-RateLimiter", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const isExceeded = combinedState.executionTimes.length >= this.#getLimit();
			const status = !this.#getEnabled() ? "disabled" : isExceeded ? "exceeded" : "idle";
			return {
				...combinedState,
				isExceeded,
				status
			};
		});
		emitChange("RateLimiter", this);
	};
	/**
	* Returns the current enabled state of the rate limiter
	*/
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	/**
	* Returns the current limit of executions allowed within the time window
	*/
	#getLimit = () => {
		return parseFunctionOrValue(this.options.limit, this);
	};
	/**
	* Returns the current time window in milliseconds
	*/
	#getWindow = () => {
		return parseFunctionOrValue(this.options.window, this);
	};
	#execute = (...args) => {
		if (!this.#getEnabled()) return;
		const now = Date.now();
		this.fn(...args);
		this.store.state.executionTimes.push(now);
		this.#setCleanupTimeout(now);
		this.#setState({ executionCount: this.store.state.executionCount + 1 });
		this.options.onExecute?.(args, this);
	};
	#getExecutionTimesInWindow = () => {
		if (this.options.windowType === "sliding") return this.store.state.executionTimes.filter((time) => time > Date.now() - this.#getWindow());
		else {
			if (this.store.state.executionTimes.length === 0) return [];
			const windowStart = Math.min(...this.store.state.executionTimes);
			const windowEnd = windowStart + this.#getWindow();
			if (Date.now() > windowEnd) return [];
			return this.store.state.executionTimes.filter((time) => time >= windowStart && time <= windowEnd);
		}
	};
	#setCleanupTimeout = (executionTime) => {
		if (this.options.windowType === "sliding" || this.#timeoutIds.size === 0) {
			const timeUntilExpiration = executionTime - Date.now() + this.#getWindow() + 1;
			const timeoutId = setTimeout(() => {
				this.#cleanupOldExecutions();
				this.#clearTimeout(timeoutId);
			}, timeUntilExpiration);
			this.#timeoutIds.add(timeoutId);
		}
	};
	#clearTimeout = (timeoutId) => {
		clearTimeout(timeoutId);
		this.#timeoutIds.delete(timeoutId);
	};
	#clearTimeouts = () => {
		this.#timeoutIds.forEach((timeoutId) => clearTimeout(timeoutId));
		this.#timeoutIds.clear();
	};
	#cleanupOldExecutions = () => {
		this.#setState({ executionTimes: this.#getExecutionTimesInWindow() });
	};
};
/**
* Creates a rate-limited function that will execute the provided function up to a maximum number of times within a time window.
*
* This synchronous version is lighter weight and often all you need - upgrade to asyncRateLimit when you need promises, retry support, abort capabilities, or advanced error handling.
*
* Note that rate limiting is a simpler form of execution control compared to throttling or debouncing:
* - A rate limiter will allow all executions until the limit is reached, then block all subsequent calls until the window resets
* - A throttler ensures even spacing between executions, which can be better for consistent performance
* - A debouncer collapses multiple calls into one, which is better for handling bursts of events
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the rate limiter
* - Use `onExecute` callback to react to function execution and implement custom logic
* - Use `onReject` callback to react to executions being rejected when rate limit is exceeded
* - The state includes execution count, execution times, and rejection count
* - State can be accessed via the underlying RateLimiter instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* Consider using throttle() or debounce() if you need more intelligent execution control. Use rate limiting when you specifically
* need to enforce a hard limit on the number of executions within a time period.
*
* @example
* ```ts
* // Rate limit to 5 calls per minute with a sliding window
* const rateLimited = rateLimit(makeApiCall, {
*   limit: 5,
*   window: 60000,
*   windowType: 'sliding',
*   onReject: (rateLimiter) => {
*     console.log(`Rate limit exceeded. Try again in ${rateLimiter.getMsUntilNextWindow()}ms`);
*   }
* });
*
* // First 5 calls will execute immediately
* // Additional calls will be rejected until the minute window resets
* rateLimited();
*
* // For more even execution, consider using throttle instead:
* const throttled = throttle(makeApiCall, { wait: 12000 }); // One call every 12 seconds
* ```
*/
function rateLimit(fn, initialOptions) {
	return new RateLimiter(fn, initialOptions).maybeExecute;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/rate-limiter/useRateLimiter.js
/**
* A low-level React hook that creates a `RateLimiter` instance to enforce rate limits on function execution.
*
* This hook is designed to be flexible and state-management agnostic - it simply returns a rate limiter instance that
* you can integrate with any state management solution (useState, Redux, Zustand, Jotai, etc).
*
* Rate limiting is a simple "hard limit" approach that allows executions until a maximum count is reached within
* a time window, then blocks all subsequent calls until the window resets. Unlike throttling or debouncing,
* it does not attempt to space out or collapse executions intelligently.
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* For smoother execution patterns:
* - Use throttling when you want consistent spacing between executions (e.g. UI updates)
* - Use debouncing when you want to collapse rapid-fire events (e.g. search input)
* - Use rate limiting only when you need to enforce hard limits (e.g. API rate limits)
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `rateLimiter.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `executionCount`: Number of function executions that have been completed
* - `executionTimes`: Array of timestamps when executions occurred for rate limiting calculations
* - `rejectionCount`: Number of function executions that have been rejected due to rate limiting
*
* The hook returns an object containing:
* - maybeExecute: The rate-limited function that respects the configured limits
* - getExecutionCount: Returns the number of successful executions
* - getRejectionCount: Returns the number of rejected executions due to rate limiting
* - getRemainingInWindow: Returns how many more executions are allowed in the current window
* - reset: Resets the execution counts and window timing
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const rateLimiter = useRateLimiter(apiCall, {
*   limit: 5,
*   window: 60000,
*   windowType: 'sliding',
* });
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <rateLimiter.Subscribe selector={(state) => ({ rejectionCount: state.rejectionCount })}>
*   {({ rejectionCount }) => (
*     <div>Rejected: {rejectionCount} requests</div>
*   )}
* </rateLimiter.Subscribe>
*
* // Opt-in to re-render when execution count changes at hook level (optimized for tracking successful executions)
* const rateLimiter = useRateLimiter(
*   apiCall,
*   {
*     limit: 5,
*     window: 60000,
*     windowType: 'sliding',
*   },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when rejection count changes (optimized for tracking rate limit violations)
* const rateLimiter = useRateLimiter(
*   apiCall,
*   {
*     limit: 5,
*     window: 60000,
*     windowType: 'sliding',
*   },
*   (state) => ({ rejectionCount: state.rejectionCount })
* );
*
* // Opt-in to re-render when execution times change (optimized for window calculations)
* const rateLimiter = useRateLimiter(
*   apiCall,
*   {
*     limit: 5,
*     window: 60000,
*     windowType: 'sliding',
*   },
*   (state) => ({ executionTimes: state.executionTimes })
* );
*
* // Multiple state properties - re-render when any of these change
* const rateLimiter = useRateLimiter(
*   apiCall,
*   {
*     limit: 5,
*     window: 60000,
*     windowType: 'sliding',
*   },
*   (state) => ({
*     executionCount: state.executionCount,
*     rejectionCount: state.rejectionCount
*   })
* );
*
* // Monitor rate limit status
* const handleClick = () => {
*   const remaining = rateLimiter.getRemainingInWindow();
*   if (remaining > 0) {
*     rateLimiter.maybeExecute(data);
*   } else {
*     showRateLimitWarning();
*   }
* };
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { executionCount, rejectionCount } = rateLimiter.state;
* ```
*/
function useRateLimiter(fn, options, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().rateLimiter,
		...options
	};
	const [rateLimiter] = (0, import_react.useState)(() => {
		const rateLimiterInstance = new RateLimiter(fn, mergedOptions);
		rateLimiterInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(rateLimiterInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return rateLimiterInstance;
	});
	rateLimiter.fn = fn;
	rateLimiter.setOptions(mergedOptions);
	const state = useStore(rateLimiter.store, selector);
	return (0, import_react.useMemo)(() => ({
		...rateLimiter,
		state
	}), [rateLimiter, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/rate-limiter/useRateLimitedCallback.js
/**
* A React hook that creates a rate-limited version of a callback function.
* This hook is essentially a wrapper around the basic `rateLimiter` function
* that is exported from `@tanstack/pacer`,
* but optimized for React with reactive options and a stable function reference.
*
* Rate limiting is a simple "hard limit" approach - it allows all calls until the limit
* is reached, then blocks subsequent calls until the window resets. Unlike throttling
* or debouncing, it does not attempt to space out or intelligently collapse calls.
* This can lead to bursts of rapid executions followed by periods where all calls
* are blocked.
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All executions within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows executions as old ones expire. This provides a more
*   consistent rate of execution over time.
*
* For smoother execution patterns, consider:
* - useThrottledCallback: When you want consistent spacing between executions (e.g. UI updates)
* - useDebouncedCallback: When you want to collapse rapid calls into a single execution (e.g. search input)
*
* Rate limiting should primarily be used when you need to enforce strict limits,
* like API rate limits or other scenarios requiring hard caps on execution frequency.
*
* This hook provides a simpler API compared to `useRateLimiter`, making it ideal for basic
* rate limiting needs. However, it does not expose the underlying RateLimiter instance.
*
* For advanced usage requiring features like:
* - Manual cancellation
* - Access to execution counts
* - Custom useCallback dependencies
*
* Consider using the `useRateLimiter` hook instead.
*
* @example
* ```tsx
* // Rate limit API calls to maximum 5 calls per minute with a sliding window
* const makeApiCall = useRateLimitedCallback(
*   (data: ApiData) => {
*     return fetch('/api/endpoint', { method: 'POST', body: JSON.stringify(data) });
*   },
*   {
*     limit: 5,
*     window: 60000, // 1 minute
*     windowType: 'sliding',
*     onReject: () => {
*       console.warn('API rate limit reached. Please wait before trying again.');
*     }
*   }
* );
* ```
*/
function useRateLimitedCallback(fn, options) {
	const rateLimitedFn = useRateLimiter(fn, options).maybeExecute;
	return (0, import_react.useCallback)((...args) => rateLimitedFn(...args), [rateLimitedFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/rate-limiter/useRateLimitedState.js
/**
* A React hook that creates a rate-limited state value that enforces a hard limit on state updates within a time window.
* This hook combines React's useState with rate limiting functionality to provide controlled state updates.
*
* Rate limiting is a simple "hard limit" approach - it allows all updates until the limit is reached, then blocks
* subsequent updates until the window resets. Unlike throttling or debouncing, it does not attempt to space out
* or intelligently collapse updates. This can lead to bursts of rapid updates followed by periods of no updates.
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All updates within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows updates as old ones expire. This provides a more
*   consistent rate of updates over time.
*
* For smoother update patterns, consider:
* - useThrottledState: When you want consistent spacing between updates (e.g. UI changes)
* - useDebouncedState: When you want to collapse rapid updates into a single update (e.g. search input)
*
* Rate limiting should primarily be used when you need to enforce strict limits, like API rate limits.
*
* The hook returns a tuple containing:
* - The rate-limited state value
* - A rate-limited setter function that respects the configured limits
* - The rateLimiter instance for additional control
*
* For more direct control over rate limiting without state management,
* consider using the lower-level useRateLimiter hook instead.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying rate limiter instance.
* The `selector` parameter allows you to specify which rate limiter state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available rate limiter state properties:
* - `executionCount`: Number of function executions that have been completed
* - `executionTimes`: Array of timestamps when executions occurred for rate limiting calculations
* - `rejectionCount`: Number of function executions that have been rejected due to rate limiting
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [value, setValue, rateLimiter] = useRateLimitedState(0, {
*   limit: 5,
*   window: 60000,
*   windowType: 'sliding'
* });
*
* // Opt-in to re-render when execution count changes (optimized for tracking successful updates)
* const [value, setValue, rateLimiter] = useRateLimitedState(
*   0,
*   { limit: 5, window: 60000, windowType: 'sliding' },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when rejection count changes (optimized for tracking rate limit violations)
* const [value, setValue, rateLimiter] = useRateLimitedState(
*   0,
*   { limit: 5, window: 60000, windowType: 'sliding' },
*   (state) => ({ rejectionCount: state.rejectionCount })
* );
*
* // Opt-in to re-render when execution times change (optimized for window calculations)
* const [value, setValue, rateLimiter] = useRateLimitedState(
*   0,
*   { limit: 5, window: 60000, windowType: 'sliding' },
*   (state) => ({ executionTimes: state.executionTimes })
* );
*
* // With rejection callback and fixed window
* const [value, setValue] = useRateLimitedState(0, {
*   limit: 3,
*   window: 5000,
*   windowType: 'fixed',
*   onReject: (rateLimiter) => {
*     alert(`Rate limit reached. Try again in ${rateLimiter.getMsUntilNextWindow()}ms`);
*   }
* });
*
* // Access rateLimiter methods if needed
* const handleSubmit = () => {
*   const remaining = rateLimiter.getRemainingInWindow();
*   if (remaining > 0) {
*     setValue(newValue);
*   } else {
*     showRateLimitWarning();
*   }
* };
*
* // Access the selected rate limiter state (will be empty object {} unless selector provided)
* const { executionCount, rejectionCount } = rateLimiter.state;
* ```
*/
function useRateLimitedState(value, options, selector) {
	const [rateLimitedValue, setRateLimitedValue] = (0, import_react.useState)(value);
	const rateLimiter = useRateLimiter(setRateLimitedValue, options, selector);
	return [
		rateLimitedValue,
		rateLimiter.maybeExecute,
		rateLimiter
	];
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/rate-limiter/useRateLimitedValue.js
/**
* A high-level React hook that creates a rate-limited version of a value that updates at most a certain number of times within a time window.
* This hook uses React's useState internally to manage the rate-limited state.
*
* Rate limiting is a simple "hard limit" approach - it allows all updates until the limit is reached, then blocks
* subsequent updates until the window resets. Unlike throttling or debouncing, it does not attempt to space out
* or intelligently collapse updates. This can lead to bursts of rapid updates followed by periods of no updates.
*
* The rate limiter supports two types of windows:
* - 'fixed': A strict window that resets after the window period. All updates within the window count
*   towards the limit, and the window resets completely after the period.
* - 'sliding': A rolling window that allows updates as old ones expire. This provides a more
*   consistent rate of updates over time.
*
* For smoother update patterns, consider:
* - useThrottledValue: When you want consistent spacing between updates (e.g. UI changes)
* - useDebouncedValue: When you want to collapse rapid updates into a single update (e.g. search input)
*
* Rate limiting should primarily be used when you need to enforce strict limits, like API rate limits.
*
* The hook returns a tuple containing:
* - The rate-limited value that updates according to the configured rate limit
* - The rate limiter instance with control methods
*
* For more direct control over rate limiting behavior without React state management,
* consider using the lower-level useRateLimiter hook instead.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying rate limiter instance.
* The `selector` parameter allows you to specify which rate limiter state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available rate limiter state properties:
* - `executionCount`: Number of function executions that have been completed
* - `executionTimes`: Array of timestamps when executions occurred for rate limiting calculations
* - `rejectionCount`: Number of function executions that have been rejected due to rate limiting
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [rateLimitedValue, rateLimiter] = useRateLimitedValue(rawValue, {
*   limit: 5,
*   window: 60000,
*   windowType: 'sliding'
* });
*
* // Opt-in to re-render when execution count changes (optimized for tracking successful updates)
* const [rateLimitedValue, rateLimiter] = useRateLimitedValue(
*   rawValue,
*   { limit: 5, window: 60000, windowType: 'sliding' },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when rejection count changes (optimized for tracking rate limit violations)
* const [rateLimitedValue, rateLimiter] = useRateLimitedValue(
*   rawValue,
*   { limit: 5, window: 60000, windowType: 'sliding' },
*   (state) => ({ rejectionCount: state.rejectionCount })
* );
*
* // Opt-in to re-render when execution times change (optimized for window calculations)
* const [rateLimitedValue, rateLimiter] = useRateLimitedValue(
*   rawValue,
*   { limit: 5, window: 60000, windowType: 'sliding' },
*   (state) => ({ executionTimes: state.executionTimes })
* );
*
* // With rejection callback and fixed window
* const [rateLimitedValue, rateLimiter] = useRateLimitedValue(rawValue, {
*   limit: 3,
*   window: 5000,
*   windowType: 'fixed',
*   onReject: (rateLimiter) => {
*     console.log(`Update rejected. Try again in ${rateLimiter.getMsUntilNextWindow()}ms`);
*   }
* });
*
* // Access the selected rate limiter state (will be empty object {} unless selector provided)
* const { executionCount, rejectionCount } = rateLimiter.state;
* ```
*/
function useRateLimitedValue(value, options, selector) {
	const [rateLimitedValue, setRateLimitedValue, rateLimiter] = useRateLimitedState(value, options, selector);
	(0, import_react.useEffect)(() => {
		setRateLimitedValue(value);
	}, [value, setRateLimitedValue]);
	return [rateLimitedValue, rateLimiter];
}
//#endregion
//#region node_modules/.bun/@tanstack+pacer@0.18.0/node_modules/@tanstack/pacer/dist/throttler.js
function getDefaultThrottlerState() {
	return {
		executionCount: 0,
		isPending: false,
		lastArgs: void 0,
		lastExecutionTime: 0,
		nextExecutionTime: 0,
		status: "idle",
		maybeExecuteCount: 0
	};
}
/**
* Utility function for sharing common `ThrottlerOptions` options between different `Throttler` instances.
*/
function throttlerOptions(options) {
	return options;
}
var defaultOptions = {
	enabled: true,
	leading: true,
	trailing: true,
	wait: 0
};
/**
* A class that creates a throttled function.
*
* Throttling ensures a function is called at most once within a specified time window.
* Unlike debouncing which waits for a pause in calls, throttling guarantees consistent
* execution timing regardless of call frequency.
* This synchronous version is lighter weight and often all you need - upgrade to AsyncThrottler when you need promises, retry support, abort/cancel capabilities, or advanced error handling.
*
* Supports both leading and trailing edge execution:
* - Leading: Execute immediately on first call (default: true)
* - Trailing: Execute after wait period if called during throttle (default: true)
*
* For collapsing rapid-fire events where you only care about the last call, consider using Debouncer.
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the throttler
* - Use `onExecute` callback to react to function execution and implement custom logic
* - The state includes execution count, last execution time, pending status, and more
* - State can be accessed via `throttler.store.state` when using the class directly
* - When using framework adapters (React/Solid), state is accessed from `throttler.state`
*
* @example
* ```ts
* const throttler = new Throttler(
*   (id: string) => api.getData(id),
*   { wait: 1000 } // Execute at most once per second
* );
*
* // First call executes immediately
* throttler.maybeExecute('123');
*
* // Subsequent calls within 1000ms are throttled
* throttler.maybeExecute('123'); // Throttled
* ```
*/
var Throttler = class {
	#timeoutId;
	constructor(fn, initialOptions) {
		this.fn = fn;
		this.store = new Store(getDefaultThrottlerState());
		this.setOptions = (newOptions) => {
			this.options = {
				...this.options,
				...newOptions
			};
			if (!this.#getEnabled()) this.cancel();
		};
		this.maybeExecute = (...args) => {
			this.#setState({ maybeExecuteCount: this.store.state.maybeExecuteCount + 1 });
			const now = Date.now();
			const timeSinceLastExecution = now - this.store.state.lastExecutionTime;
			const wait = this.#getWait();
			if (this.options.leading && timeSinceLastExecution >= wait) this.#execute(...args);
			else {
				this.#setState({ lastArgs: args });
				if (!this.#timeoutId && this.options.trailing) {
					const timeoutDuration = wait - (this.store.state.lastExecutionTime ? now - this.store.state.lastExecutionTime : 0);
					this.#setState({ isPending: true });
					this.#timeoutId = setTimeout(() => {
						const { lastArgs } = this.store.state;
						if (lastArgs !== void 0) this.#execute(...lastArgs);
					}, timeoutDuration);
				}
			}
		};
		this.flush = () => {
			if (this.store.state.isPending && this.store.state.lastArgs) this.#execute(...this.store.state.lastArgs);
		};
		this.cancel = () => {
			this.#clearTimeout();
			this.#setState({
				lastArgs: void 0,
				isPending: false
			});
		};
		this.reset = () => {
			this.#setState(getDefaultThrottlerState());
		};
		this.key = initialOptions.key;
		this.options = {
			...defaultOptions,
			...initialOptions
		};
		this.#setState(this.options.initialState ?? {});
		if (this.key) pacerEventClient.on("d-Throttler", (event) => {
			if (event.payload.key !== this.key) return;
			this.#setState(event.payload.store.state);
			this.setOptions(event.payload.options);
		});
	}
	#setState = (newState) => {
		this.store.setState((state) => {
			const combinedState = {
				...state,
				...newState
			};
			const { isPending } = combinedState;
			return {
				...combinedState,
				status: !this.#getEnabled() ? "disabled" : isPending ? "pending" : "idle"
			};
		});
		emitChange("Throttler", this);
	};
	#getEnabled = () => {
		return !!parseFunctionOrValue(this.options.enabled, this);
	};
	#getWait = () => {
		return parseFunctionOrValue(this.options.wait, this);
	};
	#execute = (...args) => {
		if (!this.#getEnabled()) return;
		this.fn(...args);
		const lastExecutionTime = Date.now();
		const nextExecutionTime = lastExecutionTime + this.#getWait();
		this.#clearTimeout();
		this.#setState({
			executionCount: this.store.state.executionCount + 1,
			lastExecutionTime,
			nextExecutionTime,
			isPending: false,
			lastArgs: void 0
		});
		this.options.onExecute?.(args, this);
		setTimeout(() => {
			if (!this.store.state.isPending) this.#setState({ nextExecutionTime: void 0 });
		}, this.#getWait());
	};
	#clearTimeout = () => {
		if (this.#timeoutId) {
			clearTimeout(this.#timeoutId);
			this.#timeoutId = void 0;
		}
	};
};
/**
* Creates a throttled function that limits how often the provided function can execute.
*
* This synchronous version is lighter weight and often all you need - upgrade to asyncThrottle when you need promises, retry support, abort/cancel capabilities, or advanced error handling.
*
* Throttling ensures a function executes at most once within a specified time window,
* regardless of how many times it is called. This is useful for rate-limiting
* expensive operations or UI updates.
*
* The throttled function can be configured to execute on the leading and/or trailing
* edge of the throttle window via options.
*
* For handling bursts of events, consider using debounce() instead. For hard execution
* limits, consider using rateLimit().
*
* State Management:
* - Uses TanStack Store for reactive state management
* - Use `initialState` to provide initial state values when creating the throttler
* - Use `onExecute` callback to react to function execution and implement custom logic
* - The state includes execution count, last execution time, pending status, and more
* - State can be accessed via the underlying Throttler instance's `store.state` property
* - When using framework adapters (React/Solid), state is accessed from the hook's state property
*
* @example
* ```ts
* // Basic throttling - max once per second
* const throttled = throttle(updateUI, { wait: 1000 });
*
* // Configure leading/trailing execution
* const throttled = throttle(saveData, {
*   wait: 2000,
*   leading: true,  // Execute immediately on first call
*   trailing: true  // Execute again after delay if called during wait
* });
* ```
*/
function throttle(fn, initialOptions) {
	return new Throttler(fn, initialOptions).maybeExecute;
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/throttler/useThrottler.js
/**
* A low-level React hook that creates a `Throttler` instance that limits how often the provided function can execute.
*
* This hook is designed to be flexible and state-management agnostic - it simply returns a throttler instance that
* you can integrate with any state management solution (useState, Redux, Zustand, Jotai, etc). For a simpler and higher-level hook that
* integrates directly with React's useState, see useThrottledState.
*
* Throttling ensures a function executes at most once within a specified time window,
* regardless of how many times it is called. This is useful for rate-limiting
* expensive operations or UI updates.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management. You can subscribe to state changes
* in two ways:
*
* **1. Using `throttler.Subscribe` HOC (Recommended for component tree subscriptions)**
*
* Use the `Subscribe` HOC to subscribe to state changes deep in your component tree without
* needing to pass a selector to the hook. This is ideal when you want to subscribe to state
* in child components.
*
* **2. Using the `selector` parameter (For hook-level subscriptions)**
*
* The `selector` parameter allows you to specify which state changes will trigger a re-render
* at the hook level, optimizing performance by preventing unnecessary re-renders when irrelevant
* state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function or using the `Subscribe` HOC. This prevents unnecessary
* re-renders and gives you full control over when your component updates.
*
* Available state properties:
* - `executionCount`: Number of function executions that have been completed
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `lastExecutionTime`: Timestamp of the last function execution in milliseconds
* - `nextExecutionTime`: Timestamp when the next execution can occur in milliseconds
* - `isPending`: Whether the throttler is waiting for the timeout to trigger execution
* - `status`: Current execution status ('disabled' | 'idle' | 'pending')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [value, setValue] = useState(0);
* const throttler = useThrottler(setValue, { wait: 1000 });
*
* // Subscribe to state changes deep in component tree using Subscribe HOC
* <throttler.Subscribe selector={(state) => ({ isPending: state.isPending })}>
*   {({ isPending }) => (
*     <div>{isPending ? 'Throttling...' : 'Ready'}</div>
*   )}
* </throttler.Subscribe>
*
* // Opt-in to re-render when execution count changes at hook level (optimized for tracking executions)
* const [value, setValue] = useState(0);
* const throttler = useThrottler(
*   setValue,
*   { wait: 1000 },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when throttling state changes (optimized for loading indicators)
* const [value, setValue] = useState(0);
* const throttler = useThrottler(
*   setValue,
*   { wait: 1000 },
*   (state) => ({
*     isPending: state.isPending,
*     status: state.status
*   })
* );
*
* // Opt-in to re-render when timing information changes (optimized for timing displays)
* const [value, setValue] = useState(0);
* const throttler = useThrottler(
*   setValue,
*   { wait: 1000 },
*   (state) => ({
*     lastExecutionTime: state.lastExecutionTime,
*     nextExecutionTime: state.nextExecutionTime
*   })
* );
*
* // With any state manager
* const throttler = useThrottler(
*   (value) => stateManager.setState(value),
*   {
*     wait: 2000,
*     leading: true,   // Execute immediately on first call
*     trailing: false  // Skip trailing edge updates
*   }
* );
*
* // Access the selected state (will be empty object {} unless selector provided)
* const { executionCount, isPending } = throttler.state;
* ```
*/
function useThrottler(fn, options, selector = () => ({})) {
	const mergedOptions = {
		...useDefaultPacerOptions().throttler,
		...options
	};
	const [throttler] = (0, import_react.useState)(() => {
		const throttlerInstance = new Throttler(fn, mergedOptions);
		throttlerInstance.Subscribe = function Subscribe(props) {
			const selected = useStore(throttlerInstance.store, props.selector);
			return typeof props.children === "function" ? props.children(selected) : props.children;
		};
		return throttlerInstance;
	});
	throttler.fn = fn;
	throttler.setOptions(mergedOptions);
	const state = useStore(throttler.store, selector);
	(0, import_react.useEffect)(() => {
		return () => {
			throttler.cancel();
		};
	}, [throttler]);
	return (0, import_react.useMemo)(() => ({
		...throttler,
		state
	}), [throttler, state]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/throttler/useThrottledCallback.js
/**
* A React hook that creates a throttled version of a callback function.
* This hook is essentially a wrapper around the basic `throttle` function
* that is exported from `@tanstack/pacer`,
* but optimized for React with reactive options and a stable function reference.
*
* The throttled function will execute at most once within the specified wait time period,
* regardless of how many times it is called. If called multiple times during the wait period,
* only the first invocation will execute, and subsequent calls will be ignored until
* the wait period has elapsed.
*
* This hook provides a simpler API compared to `useThrottler`, making it ideal for basic
* throttling needs. However, it does not expose the underlying Throttler instance.
*
* For advanced usage requiring features like:
* - Manual cancellation
* - Access to execution counts
* - Custom useCallback dependencies
*
* Consider using the `useThrottler` hook instead.
*
* @example
* ```tsx
* // Throttle a window resize handler
* const handleResize = useThrottledCallback(() => {
*   updateLayoutMeasurements();
* }, {
*   wait: 100 // Execute at most once every 100ms
* });
*
* // Use in an event listener
* useEffect(() => {
*   window.addEventListener('resize', handleResize);
*   return () => window.removeEventListener('resize', handleResize);
* }, [handleResize]);
* ```
*/
function useThrottledCallback(fn, options) {
	const throttledFn = useThrottler(fn, options).maybeExecute;
	return (0, import_react.useCallback)((...args) => throttledFn(...args), [throttledFn]);
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/throttler/useThrottledState.js
/**
* A React hook that creates a throttled state value that updates at most once within a specified time window.
* This hook combines React's useState with throttling functionality to provide controlled state updates.
*
* Throttling ensures state updates occur at a controlled rate regardless of how frequently the setter is called.
* This is useful for rate-limiting expensive re-renders or operations that depend on rapidly changing state.
*
* The hook returns a tuple containing:
* - The throttled state value
* - A throttled setter function that respects the configured wait time
* - The throttler instance for additional control
*
* For more direct control over throttling without state management,
* consider using the lower-level useThrottler hook instead.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying throttler instance.
* The `selector` parameter allows you to specify which throttler state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available throttler state properties:
* - `executionCount`: Number of function executions that have been completed
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `lastExecutionTime`: Timestamp of the last function execution in milliseconds
* - `nextExecutionTime`: Timestamp when the next execution can occur in milliseconds
* - `isPending`: Whether the throttler is waiting for the timeout to trigger execution
* - `status`: Current execution status ('disabled' | 'idle' | 'pending')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [value, setValue, throttler] = useThrottledState(0, { wait: 1000 });
*
* // Opt-in to re-render when execution count changes (optimized for tracking executions)
* const [value, setValue, throttler] = useThrottledState(
*   0,
*   { wait: 1000 },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when throttling state changes (optimized for loading indicators)
* const [value, setValue, throttler] = useThrottledState(
*   0,
*   { wait: 1000 },
*   (state) => ({
*     isPending: state.isPending,
*     status: state.status
*   })
* );
*
* // Opt-in to re-render when timing information changes (optimized for timing displays)
* const [value, setValue, throttler] = useThrottledState(
*   0,
*   { wait: 1000 },
*   (state) => ({
*     lastExecutionTime: state.lastExecutionTime,
*     nextExecutionTime: state.nextExecutionTime
*   })
* );
*
* // With custom leading/trailing behavior
* const [value, setValue] = useThrottledState(0, {
*   wait: 1000,
*   leading: true,   // Update immediately on first change
*   trailing: false  // Skip trailing edge updates
* });
*
* // Access throttler methods if needed
* const handleReset = () => {
*   setValue(0);
*   throttler.cancel(); // Cancel any pending updates
* };
*
* // Access the selected throttler state (will be empty object {} unless selector provided)
* const { executionCount, isPending } = throttler.state;
* ```
*/
function useThrottledState(value, options, selector) {
	const [throttledValue, setThrottledValue] = (0, import_react.useState)(value);
	const throttler = useThrottler(setThrottledValue, options, selector);
	return [
		throttledValue,
		throttler.maybeExecute,
		throttler
	];
}
//#endregion
//#region node_modules/.bun/@tanstack+react-pacer@0.19.4+bf16f8eded5e12ee/node_modules/@tanstack/react-pacer/dist/throttler/useThrottledValue.js
/**
* A high-level React hook that creates a throttled version of a value that updates at most once within a specified time window.
* This hook uses React's useState internally to manage the throttled state.
*
* Throttling ensures the value updates occur at a controlled rate regardless of how frequently the input value changes.
* This is useful for rate-limiting expensive re-renders or API calls that depend on rapidly changing values.
*
* The hook returns a tuple containing:
* - The throttled value that updates according to the leading/trailing edge behavior specified in the options
* - The throttler instance with control methods
*
* For more direct control over throttling behavior without React state management,
* consider using the lower-level useThrottler hook instead.
*
* ## State Management and Selector
*
* The hook uses TanStack Store for reactive state management via the underlying throttler instance.
* The `selector` parameter allows you to specify which throttler state changes will trigger a re-render,
* optimizing performance by preventing unnecessary re-renders when irrelevant state changes occur.
*
* **By default, there will be no reactive state subscriptions** and you must opt-in to state
* tracking by providing a selector function. This prevents unnecessary re-renders and gives you
* full control over when your component updates. Only when you provide a selector will the
* component re-render when the selected state values change.
*
* Available throttler state properties:
* - `executionCount`: Number of function executions that have been completed
* - `lastArgs`: The arguments from the most recent call to maybeExecute
* - `lastExecutionTime`: Timestamp of the last function execution in milliseconds
* - `nextExecutionTime`: Timestamp when the next execution can occur in milliseconds
* - `isPending`: Whether the throttler is waiting for the timeout to trigger execution
* - `status`: Current execution status ('disabled' | 'idle' | 'pending')
*
* @example
* ```tsx
* // Default behavior - no reactive state subscriptions
* const [throttledValue, throttler] = useThrottledValue(rawValue, { wait: 1000 });
*
* // Opt-in to re-render when execution count changes (optimized for tracking executions)
* const [throttledValue, throttler] = useThrottledValue(
*   rawValue,
*   { wait: 1000 },
*   (state) => ({ executionCount: state.executionCount })
* );
*
* // Opt-in to re-render when throttling state changes (optimized for loading indicators)
* const [throttledValue, throttler] = useThrottledValue(
*   rawValue,
*   { wait: 1000 },
*   (state) => ({
*     isPending: state.isPending,
*     status: state.status
*   })
* );
*
* // Opt-in to re-render when timing information changes (optimized for timing displays)
* const [throttledValue, throttler] = useThrottledValue(
*   rawValue,
*   { wait: 1000 },
*   (state) => ({
*     lastExecutionTime: state.lastExecutionTime,
*     nextExecutionTime: state.nextExecutionTime
*   })
* );
*
* // With custom leading/trailing behavior
* const [throttledValue, throttler] = useThrottledValue(rawValue, {
*   wait: 1000,
*   leading: true,   // Update immediately on first change
*   trailing: false  // Skip trailing edge updates
* });
*
* // Access the selected throttler state (will be empty object {} unless selector provided)
* const { executionCount, isPending } = throttler.state;
* ```
*/
function useThrottledValue(value, options, selector) {
	const [throttledValue, setThrottledValue, throttler] = useThrottledState(value, options, selector);
	(0, import_react.useEffect)(() => {
		setThrottledValue(value);
	}, [value, setThrottledValue]);
	return [throttledValue, throttler];
}
//#endregion
export { AsyncBatcher, AsyncDebouncer, AsyncQueuer, AsyncRateLimiter, AsyncRetryer, AsyncThrottler, Batcher, Debouncer, PacerProvider, Queuer, RateLimiter, Throttler, asyncBatch, asyncBatcherOptions, asyncDebounce, asyncDebouncerOptions, asyncQueue, asyncQueuerOptions, asyncRateLimit, asyncRateLimiterOptions, asyncRetry, asyncRetryerOptions, asyncThrottle, asyncThrottlerOptions, batch, debounce, debouncerOptions, isFunction, pacerEventClient, parseFunctionOrValue, queue, queuerOptions, rateLimit, rateLimiterOptions, throttle, throttlerOptions, useAsyncBatchedCallback, useAsyncBatcher, useAsyncDebouncedCallback, useAsyncDebouncer, useAsyncQueuedState, useAsyncQueuer, useAsyncRateLimitedCallback, useAsyncRateLimiter, useAsyncThrottledCallback, useAsyncThrottler, useBatchedCallback, useBatcher, useDebouncedCallback, useDebouncedState, useDebouncedValue, useDebouncer, useDefaultPacerOptions, usePacerContext, useQueuedState, useQueuedValue, useQueuer, useRateLimitedCallback, useRateLimitedState, useRateLimitedValue, useRateLimiter, useThrottledCallback, useThrottledState, useThrottledValue, useThrottler };
