//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/composite/composite.mjs
var ARROW_UP = "ArrowUp";
var ARROW_DOWN = "ArrowDown";
var ARROW_LEFT = "ArrowLeft";
var ARROW_RIGHT = "ArrowRight";
var HOME = "Home";
var PAGE_UP = "PageUp";
var PAGE_DOWN = "PageDown";
var COMPOSITE_KEYS = /* @__PURE__ */ new Set([
	ARROW_UP,
	ARROW_DOWN,
	ARROW_LEFT,
	ARROW_RIGHT,
	HOME,
	"End"
]);
//#endregion
export { COMPOSITE_KEYS as a, PAGE_UP as c, ARROW_UP as i, ARROW_LEFT as n, HOME as o, ARROW_RIGHT as r, PAGE_DOWN as s, ARROW_DOWN as t };
