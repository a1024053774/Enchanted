import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { $ as flow, J as constTrue, K as constFalse, Q as dual, R as isTagged, X as constVoid, Z as constant, a as equals, k as isNotUndefined, ot as pipeArguments, rt as pipe, tt as identity, x as hasProperty } from "./Equal-CgzkNqbP.js";
import { Et as some$1, G as fail$2, St as map$2, X as isFailure, at as succeed$2, bt as isSome, ht as getOrThrow, vt as isNone, wt as none } from "./Record-BrB0racz.js";
import { Al as empty$2, Au as isReadonlyArrayNonEmpty, B as delay, Bn as runPromise, Bo as close, Bu as of, Ci as catchDone, Cn as raceAll$1, Di as isDoneCause, Dt as interrupt, Eu as getUnsafe$1, G as exit, Go as makeUnsafe$2, Gt as map$3, Hn as runPromiseExitWith, Hu as range$1, I as catch_$2, Il as makeUnsafe$3, Io as Scope, J as failCauseSync$2, Jo as _await, K as fail$3, Kl as fromInputUnsafe, Ko as provide$1, Kr as whileLoop, L as clockWith, Lr as uninterruptible, Lu as map$4, Mu as last$1, Nl as getUnsafe, Nu as lastNonEmpty, Pi as isString, Pr as tryPromise, Ql as nanos, Rn as runFork, Ro as addFinalizer, Rr as uninterruptibleMask, Ss as done, Tn as raceFirst, Tr as timeoutOrElse, U as ensuring$2, Un as runPromiseWith, Uo as forkUnsafe, V as die$2, Vs as squash, Wr as void_, Xl as isZero, Xo as doneUnsafe, Xr as withFiber, Y as failSync$2, Yl as isFinite, Yt as mapError$2, Zl as millis, _n as promise, _u as empty$1, a as acquireRelease, an as onError$1, ar as services, as as fail$4, bi as toStepWithMetadata, bo as CurrentMetadata$1, ci as zip$1, cn as onExit$2, dn as onExitPrimitive, ds as isFailure$1, en as matchCauseEffect, er as scope, fs as isSuccess, ft as fnUntraced, g as asVoid, gs as void_$1, gt as forkChild, ho as currentTimeNanos, hr as tap$1, ht as forever$1, in as never$2, jl as get$3, kl as add, kt as interruptibleMask, ku as isArrayNonEmpty, l as andThen, lu as appendAll, m as as$1, mi as CurrentMetadata, ml as addSpanStackTrace, mr as sync$2, mt as forEach$1, nd as forever$3, nr as scopedWith, pi as scheduleFromStep, po as Clock, pr as suspend$2, ps as map$5, q as failCause$2, ql as infinity, ru as zero, sr as sleep, st as flatMap$2, tr as scoped$1, ts as makeUnsafe$1, tu as toMillis, ur as succeed$3, vi as forever$2, vt as forkIn, w as catchCause$2, wt as gen, xi as toStepWithSleep, xn as provideServices$2, yi as spaced, yn as provideService$2, ys as ExceededCapacityError, yu as filter$1, zn as runForkWith, zo as addFinalizerExit } from "./Effect-DrBRDdmt.js";
import { $ as merge$1, $t as endUnsafe, A as flattenArray$1, An as makeUnsafe$5, At as splitLines$1, B as fromPull$1, Bn as runIn, Bt as toPullScoped, C as failSync$3, Cn as make$6, Ct as runHead$1, D as filterMapArray, Dn as takeNVoid, Dt as scanEffect$1, E as filterArrayEffect, En as takeN, Et as runLast$1, F as fromEffect$2, Ft as tapCause$1, G as haltWhen$1, Gn as get$4, H as fromSubscriptionArray, Hn as clear, Ht as unwrap$2, I as fromIterableArray, It as tapError$1, J as interruptWhen$1, Jt as makeUnsafe$4, K as ignore$1, Kn as has$1, L as fromIteratorArray, Lt as toPubSubArray, M as forever$4, Mt as suspend$3, N as fromArray$1, Nn as getCurrent, Nt as switchMap$1, O as filterMapArrayEffect, On as toArrayN, Ot as schedule$1, P as fromAsyncIterableArray, Pn as interrupt$1, Pt as sync$3, Q as mapError$3, Qt as end, R as fromPubSubArray, Rn as join, Rt as toPubSubTake$1, S as failCauseSync$3, Sn as appendAllUnsafe, St as runForEachWhile$1, T as filterArray, Tn as takeAll, Tt as runIntoQueueArray, U as fromTransform$1, Un as empty$3, Ut as updateServices$1, V as fromQueueArray, Vt as toTransform, W as fromTransformBracket, Wt as withSpan$1, X as mapAccum$1, Xn as set, Y as map$6, Yn as remove, Z as mapEffect$2, Zn as size, _ as drain$2, _t as retry$1, a as callbackArray, an as offerAll, at as onExit$3, b as fail$5, bt as runFoldEffect$1, c as catchCauseIf$1, cn as shutdown, ct as orDie$1, d as catchReason$1, dn as unbounded, dt as pipeToOrFail, en as failCause$4, et as mergeAll$1, f as catchReasons$1, ft as provide$2, g as die$3, gt as repeat$1, h as concatWith, ht as provideServices$3, i as bufferArray$1, in as offer, it as onError$2, j as flattenTake$1, jt as succeed$4, k as flatMap$3, kt as scoped$2, l as catchFilter$1, ln as take$3, lt as orElseIfEmpty$1, m as combine$1, mn as publishAll, mt as provideServiceEffect$1, n as DefaultChunkSize$1, nt as never$3, o as catchCause$3, on as offerAllUnsafe, ot as onFirst$1, p as catch_$3, pt as provideService$3, q as ignoreCause$1, qn as keys$1, r as buffer$1, rn as make$5, rt as onEnd$1, s as catchCauseFilter$1, sn as offerUnsafe, st as onStart$1, tn as failCauseUnsafe, tt as mergeEffect$1, u as catchIf$1, un as takeAll$1, ut as pipeTo, v as empty$4, vt as runDrain$1, w as filter$2, wn as take$2, wt as runIntoPubSubArray, x as failCause$3, xn as appendAll$1, xt as runForEach$1, y as ensuring$3, yt as runFold$1, z as fromPubSubTake$1, zn as joinAll, zt as toPull$1 } from "./Channel-BalfMI2y.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/stream.js
var TypeId$4 = "~effect/Stream";
var streamVariance = {
	_R: identity,
	_E: identity,
	_A: identity
};
var StreamProto = {
	[TypeId$4]: streamVariance,
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/** @internal */
var fromChannel$2 = (channel) => {
	const self = Object.create(StreamProto);
	self.channel = channel;
	return self;
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Sink.js
var Sink_exports = /* @__PURE__ */ __exportAll({
	as: () => as,
	catch: () => catch_$1,
	catchCause: () => catchCause$1,
	collect: () => collect$1,
	count: () => count,
	die: () => die$1,
	drain: () => drain$1,
	ensuring: () => ensuring$1,
	every: () => every,
	fail: () => fail$1,
	failCause: () => failCause$1,
	failCauseSync: () => failCauseSync$1,
	failSync: () => failSync$1,
	find: () => find,
	findEffect: () => findEffect,
	flatMap: () => flatMap$1,
	fold: () => fold,
	foldArray: () => foldArray,
	foldUntil: () => foldUntil,
	forEach: () => forEach,
	forEachArray: () => forEachArray,
	forEachWhile: () => forEachWhile,
	forEachWhileArray: () => forEachWhileArray,
	fromChannel: () => fromChannel$1,
	fromEffect: () => fromEffect$1,
	fromEffectEnd: () => fromEffectEnd,
	fromPubSub: () => fromPubSub$1,
	fromQueue: () => fromQueue$1,
	fromTransform: () => fromTransform,
	head: () => head,
	ignoreLeftover: () => ignoreLeftover,
	isSink: () => isSink,
	last: () => last,
	make: () => make$4,
	map: () => map$1,
	mapEffect: () => mapEffect$1,
	mapEffectEnd: () => mapEffectEnd,
	mapEnd: () => mapEnd,
	mapError: () => mapError$1,
	mapInput: () => mapInput,
	mapInputArray: () => mapInputArray,
	mapInputArrayEffect: () => mapInputArrayEffect,
	mapInputEffect: () => mapInputEffect,
	mapLeftover: () => mapLeftover,
	never: () => never$1,
	onExit: () => onExit$1,
	orElse: () => orElse,
	provideService: () => provideService$1,
	provideServices: () => provideServices$1,
	reduce: () => reduce,
	reduceArray: () => reduceArray,
	reduceEffect: () => reduceEffect,
	reduceWhile: () => reduceWhile,
	reduceWhileArray: () => reduceWhileArray,
	reduceWhileArrayEffect: () => reduceWhileArrayEffect,
	reduceWhileEffect: () => reduceWhileEffect,
	some: () => some,
	succeed: () => succeed$1,
	sum: () => sum,
	summarized: () => summarized,
	suspend: () => suspend$1,
	sync: () => sync$1,
	take: () => take$1,
	takeUntil: () => takeUntil$1,
	takeUntilEffect: () => takeUntilEffect$1,
	takeWhile: () => takeWhile$1,
	takeWhileEffect: () => takeWhileEffect$1,
	takeWhileFilter: () => takeWhileFilter$1,
	takeWhileFilterEffect: () => takeWhileFilterEffect,
	timed: () => timed,
	toChannel: () => toChannel$1,
	unwrap: () => unwrap$1,
	withDuration: () => withDuration
});
var TypeId$3 = "~effect/Sink";
var endVoid = /*#__PURE__*/ succeed$3([void 0]);
var sinkVariance = {
	_A: identity,
	_In: identity,
	_L: identity,
	_E: identity,
	_R: identity
};
var SinkProto = {
	[TypeId$3]: sinkVariance,
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Checks if a value is a Sink.
*
* @example
* ```ts
* import { Sink } from "effect"
*
* const sink = Sink.never
* const notStream = { data: [1, 2, 3] }
*
* console.log(Sink.isSink(sink)) // true
* console.log(Sink.isSink(notStream)) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isSink = (u) => hasProperty(u, TypeId$3);
/**
* Creates a sink from a `Channel`.
*
* @since 2.0.0
* @category constructors
*/
var fromChannel$1 = (channel) => fromTransform((upstream, scope) => toTransform(channel)(upstream, scope).pipe(flatMap$2(forever$1({ disableYield: true })), catchDone(succeed$3)));
/**
* @since 4.0.0
* @category constructors
*/
var fromTransform = (transform) => {
	const self = Object.create(SinkProto);
	self.transform = transform;
	return self;
};
/**
* Creates a `Channel` from a Sink.
*
* @example
* ```ts
* import { Sink } from "effect"
*
* // Create a sink and extract its channel
* const sink = Sink.succeed(42)
* const channel = Sink.toChannel(sink)
* ```
*
* @since 2.0.0
* @category constructors
*/
var toChannel$1 = (self) => fromTransform$1((upstream, scope) => succeed$3(flatMap$2(self.transform(upstream, scope), done)));
/**
* @since 4.0.0
* @category constructors
*/
var make$4 = () => (...fns) => fromTransform((upstream, scope) => pipe(fromChannel$2(fromPull$1(succeed$3(upstream))), ...fns, flatMap$2((a) => done([a])), provide$1(scope)));
/**
* @since 4.0.0
* @category constructors
*/
var fromEffectEnd = (effect) => fromTransform(() => effect);
/**
* @since 4.0.0
* @category constructors
*/
var fromEffect$1 = (effect) => fromEffectEnd(map$3(effect, (a) => [a]));
/**
* @since 2.0.0
* @category constructors
*/
var fromQueue$1 = (queue) => fromTransform((upstream) => upstream.pipe(flatMap$2((arr) => offerAll(queue, arr)), forever$1({ disableYield: true }), catchDone((_) => {
	endUnsafe(queue);
	return endVoid;
})));
/**
* @since 2.0.0
* @category constructors
*/
var fromPubSub$1 = (pubsub) => forEachArray((arr) => publishAll(pubsub, arr));
/**
* A sink that immediately ends with the specified value.
*
* @example
* ```ts
* import { Effect, Sink, Stream } from "effect"
*
* // Create a sink that always yields the same value
* const sink = Sink.succeed(42)
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program).then(console.log)
* // Output: 42
* ```
*
* @since 2.0.0
* @category constructors
*/
var succeed$1 = (a, leftovers) => fromEffectEnd(succeed$3([a, leftovers]));
/**
* A sink that immediately ends with the specified lazily evaluated value.
*
* @since 2.0.0
* @category constructors
*/
var sync$1 = (a) => fromEffect$1(sync$2(a));
/**
* A sink that is created from a lazily evaluated sink.
*
* @since 2.0.0
* @category constructors
*/
var suspend$1 = (evaluate) => fromTransform((upstream, scope) => evaluate().transform(upstream, scope));
/**
* A sink that always fails with the specified error.
*
* @example
* ```ts
* import { Effect, Sink, Stream } from "effect"
*
* // Create a sink that always fails
* const sink = Sink.fail(new Error("Sink failed"))
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program).catch(console.log)
* // Output: Error: Sink failed
* ```
*
* @since 2.0.0
* @category constructors
*/
var fail$1 = (e) => fromEffectEnd(fail$3(e));
/**
* A sink that always fails with the specified lazily evaluated error.
*
* @example
* ```ts
* import { Effect, Sink, Stream } from "effect"
*
* // Create a sink that fails with a lazy error
* const sink = Sink.failSync(() => new Error("Lazy error"))
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program).catch(console.log)
* // Output: Error: Lazy error
* ```
*
* @since 2.0.0
* @category constructors
*/
var failSync$1 = (evaluate) => fromEffectEnd(failSync$2(evaluate));
/**
* Creates a sink halting with a specified `Cause`.
*
* @example
* ```ts
* import { Cause, Effect, Sink, Stream } from "effect"
*
* // Create a sink that fails with a specific cause
* const sink = Sink.failCause(Cause.fail(new Error("Custom cause")))
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program).catch(console.log)
* // Output: Error: Custom cause
* ```
*
* @since 2.0.0
* @category constructors
*/
var failCause$1 = (cause) => fromEffectEnd(failCause$2(cause));
/**
* Creates a sink halting with a specified lazily evaluated `Cause`.
*
* @example
* ```ts
* import { Cause, Effect, Sink, Stream } from "effect"
*
* // Create a sink that fails with a lazy cause
* const sink = Sink.failCauseSync(() => Cause.fail(new Error("Lazy cause")))
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program).catch(console.log)
* // Output: Error: Lazy cause
* ```
*
* @since 2.0.0
* @category constructors
*/
var failCauseSync$1 = (evaluate) => fromEffectEnd(failCauseSync$2(evaluate));
/**
* Creates a sink halting with a specified defect.
*
* @example
* ```ts
* import { Effect, Sink, Stream } from "effect"
*
* // Create a sink that dies with a defect
* const sink = Sink.die(new Error("Defect error"))
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program).catch(console.log)
* // Output: Error: Defect error
* ```
*
* @since 2.0.0
* @category constructors
*/
var die$1 = (defect) => fromEffectEnd(die$2(defect));
/**
* A sink that never completes.
*
* @since 2.0.0
* @category constructors
*/
var never$1 = /*#__PURE__*/ fromEffectEnd(never$2);
/**
* Drains the remaining elements from the stream after the sink finishes
*
* @since 2.0.0
* @category utils
*/
var ignoreLeftover = (self) => mapEnd(self, ([a]) => [a]);
/**
* Drains elements from the stream by ignoring all inputs.
*
* @since 2.0.0
* @category constructors
*/
var drain$1 = /*#__PURE__*/ fromTransform((upstream) => catchDone(forever$1(upstream, { disableYield: true }), () => endVoid));
/**
* A sink that folds its inputs with the provided function, termination
* predicate and initial state.
*
* @since 2.0.0
* @category folding
*/
var fold = (s, contFn, f) => fromTransform((upstream) => {
	let state = s();
	return gen(function* () {
		while (true) {
			const arr = yield* upstream;
			for (let i = 0; i < arr.length; i++) {
				state = yield* f(state, arr[i]);
				if (contFn(state)) continue;
				return [state, i + 1 < arr.length ? arr.slice(i + 1) : void 0];
			}
		}
	}).pipe(catchDone(() => succeed$3([state])));
});
/**
* @since 2.0.0
* @category folding
*/
var foldArray = (s, contFn, f) => fromTransform((upstream) => {
	let state = s();
	return gen(function* () {
		while (true) {
			const arr = yield* upstream;
			state = yield* f(state, arr);
			if (contFn(state)) continue;
			return [state];
		}
	}).pipe(catchDone(() => succeed$3([state])));
});
/**
* @since 2.0.0
* @category folding
*/
var foldUntil = (s, max, f) => fold(() => [s(), 0], (tuple) => tuple[1] < max, ([output, count], input) => map$3(f(output, input), (s) => [s, count + 1])).pipe(map$1((tuple) => tuple[0]));
/**
* A sink that returns whether all elements satisfy the specified predicate.
*
* @since 2.0.0
* @category constructors
*/
var every = (predicate) => fold(constTrue, identity, (_, a) => succeed$3(predicate(a)));
/**
* A sink that returns whether an element satisfies the specified predicate.
*
* @since 2.0.0
* @category constructors
*/
var some = (predicate) => fold(constFalse, (b) => !b, (_, a) => succeed$3(predicate(a)));
/**
* Transforms this sink's result.
*
* @since 2.0.0
* @category mapping
*/
var map$1 = /*#__PURE__*/ dual(2, (self, f) => mapEnd(self, ([a, l]) => [f(a), l]));
/**
* Set the sink's result to a constant value.
*
* @since 2.0.0
* @category mapping
*/
var as = /*#__PURE__*/ dual(2, (self, a2) => map$1(self, () => a2));
/**
* Transforms this sink's input elements.
*
* @since 2.0.0
* @category mapping
*/
var mapInput = /*#__PURE__*/ dual(2, (self, f) => mapInputArray(self, map$4(f)));
/**
* Effectfully transforms this sink's input elements.
*
* @since 2.0.0
* @category mapping
*/
var mapInputEffect = /*#__PURE__*/ dual(2, (self, f) => mapInputArrayEffect(self, forEach$1(f)));
/**
* Transforms this sink's input elements.
*
* @since 4.0.0
* @category mapping
*/
var mapInputArray = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => self.transform(map$3(upstream, f), scope)));
/**
* Effectfully transforms this sink's input elements.
*
* @since 4.0.0
* @category mapping
*/
var mapInputArrayEffect = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => self.transform(flatMap$2(upstream, f), scope)));
/**
* Transforms this sink's result.
*
* @since 4.0.0
* @category mapping
*/
var mapEnd = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => map$3(self.transform(upstream, scope), f)));
var transformEffect = (self, f) => fromTransform((upstream, scope) => f(self.transform(upstream, scope)));
/**
* Effectfully transforms this sink's result.
*
* @since 4.0.0
* @category mapping
*/
var mapEffectEnd = /*#__PURE__*/ dual(2, (self, f) => transformEffect(self, flatMap$2(f)));
/**
* Effectfully transforms this sink's result.
*
* @since 2.0.0
* @category mapping
*/
var mapEffect$1 = /*#__PURE__*/ dual(2, (self, f) => mapEffectEnd(self, ([a, l]) => map$3(f(a), (a2) => [a2, l])));
/**
* Transforms the errors emitted by this sink using `f`.
*
* @since 2.0.0
* @category mapping
*/
var mapError$1 = /*#__PURE__*/ dual(2, (self, f) => transformEffect(self, mapError$2(f)));
/**
* Transforms the leftovers emitted by this sink using `f`.
*
* @since 2.0.0
* @category mapping
*/
var mapLeftover = /*#__PURE__*/ dual(2, (self, f) => mapEnd(self, ([a, l]) => [a, l && map$4(l, f)]));
/**
* @since 2.0.0
* @category collecting
*/
var take$1 = (n) => fromTransform((upstream) => {
	const taken = [];
	if (n <= 0) return succeed$3([taken]);
	let leftover = void 0;
	return upstream.pipe(flatMap$2((arr) => {
		if (taken.length + arr.length <= n) {
			taken.push(...arr);
			if (taken.length === n) return done();
			return void_;
		}
		for (let i = 0; i < arr.length; i++) {
			taken.push(arr[i]);
			if (taken.length === n) {
				if (i + 1 < arr.length) leftover = arr.slice(i + 1);
				return done();
			}
		}
		return void_;
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([taken, leftover])));
});
/**
* Runs this sink until it yields a result, then uses that result to create
* another sink from the provided function which will continue to run until it
* yields a result.
*
* This function essentially runs sinks in sequence.
*
* @since 2.0.0
* @category sequencing
*/
var flatMap$1 = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => {
	let upstreamDone = false;
	const pull = catchCause$2(upstream, (cause) => {
		upstreamDone = true;
		return failCause$2(cause);
	});
	return flatMap$2(self.transform(pull, scope), ([a, leftover]) => f(a).transform(suspend$2(() => {
		if (leftover) {
			const arr = leftover;
			leftover = void 0;
			return succeed$3(arr);
		} else if (upstreamDone) return done();
		return upstream;
	}), scope));
}));
/**
* A sink that reduces its inputs using the provided function `f` starting from
* the provided `initial` state while the specified `predicate` returns `true`.
*
* @since 2.0.0
* @category reducing
*/
var reduceWhile = (initial, predicate, f) => fromTransform((upstream) => {
	let state = initial();
	let leftover = void 0;
	if (!predicate(state)) return succeed$3([state]);
	return upstream.pipe(flatMap$2((arr) => {
		for (let i = 0; i < arr.length; i++) {
			state = f(state, arr[i]);
			if (!predicate(state)) {
				if (i + 1 < arr.length) leftover = arr.slice(i + 1);
				return done();
			}
		}
		return void_;
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([state, leftover])));
});
/**
* A sink that reduces its inputs using the provided effectful function `f`
* starting from the provided `initial` state while the specified `predicate`
* returns `true`.
*
* @since 2.0.0
* @category reducing
*/
var reduceWhileEffect = (initial, predicate, f) => fromTransform((upstream) => {
	let state = initial();
	let leftover = void 0;
	if (!predicate(state)) return succeed$3([state]);
	return upstream.pipe(flatMap$2((arr) => {
		let i = 0;
		return whileLoop({
			while: () => i < arr.length,
			body: constant(flatMap$2(suspend$2(() => f(state, arr[i++])), (s) => {
				state = s;
				if (!predicate(state)) {
					if (i < arr.length) leftover = arr.slice(i);
					return done();
				}
				return void_;
			})),
			step: constVoid
		});
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([state, leftover])));
});
/**
* A sink that reduces its inputs using the provided function `f` starting from
* the provided `initial` state while the specified `predicate` returns `true`.
*
* @since 4.0.0
* @category reducing
*/
var reduceWhileArray = (initial, contFn, f) => fromTransform((upstream) => {
	let state = initial();
	if (!contFn(state)) return succeed$3([state]);
	return upstream.pipe(flatMap$2((arr) => {
		for (let i = 0; i < arr.length; i++) {
			state = f(state, arr);
			if (!contFn(state)) return done();
		}
		return void_;
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([state])));
});
/**
* A sink that reduces its inputs using the provided effectful function `f`
* starting from the provided `initial` state while the specified `predicate`
* returns `true`.
*
* @since 4.0.0
* @category reducing
*/
var reduceWhileArrayEffect = (initial, predicate, f) => fromTransform((upstream) => {
	let state = initial();
	if (!predicate(state)) return succeed$3([state]);
	return upstream.pipe(flatMap$2((arr) => f(state, arr)), flatMap$2((s) => {
		state = s;
		if (!predicate(state)) return done();
		return void_;
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([state])));
});
/**
* A sink that reduces its inputs using the provided function `f` starting from
* the provided `initial` state.
*
* @since 2.0.0
* @category reducing
*/
var reduce = (initial, f) => reduceArray(initial, (s, arr) => {
	for (let i = 0; i < arr.length; i++) s = f(s, arr[i]);
	return s;
});
/**
* A sink that reduces its inputs using the provided function `f` starting from
* the specified `initial` state.
*
* @since 2.0.0
* @category reducing
*/
var reduceArray = (initial, f) => fromTransform((upstream) => {
	let state = initial();
	return upstream.pipe(flatMap$2((arr) => {
		state = f(state, arr);
		return void_;
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([state])));
});
/**
* A sink that reduces its inputs using the provided effectful function `f`
* starting from the specified `initial` state.
*
* @since 2.0.0
* @category reducing
*/
var reduceEffect = (initial, f) => reduceWhileEffect(initial, constTrue, f);
var head_ = /*#__PURE__*/ reduceWhile(none, isNone, (_, in_) => some$1(in_));
/**
* Creates a sink containing the first value.
*
* @since 2.0.0
* @category constructors
*/
var head = () => head_;
var last_ = /*#__PURE__*/ reduceArray(none, (_, arr) => last$1(arr));
/**
* Creates a sink containing the last value.
*
* @since 2.0.0
* @category constructors
*/
var last = () => last_;
/**
* Creates a sink containing the first matching value.
*
* @since 4.0.0
* @category constructors
*/
var find = (predicate) => reduceWhile(none, isNone, (acc, in_) => predicate(in_) ? some$1(in_) : acc);
/**
* Creates a sink containing the first matching value.
*
* @since 4.0.0
* @category constructors
*/
var findEffect = (predicate) => reduceWhileEffect(none, isNone, (acc, in_) => map$3(predicate(in_), (b) => b ? some$1(in_) : acc));
/**
* Creates a sink which sums up its inputs.
*
* @since 2.0.0
* @category constructors
*/
var sum = /*#__PURE__*/ reduceArray(() => 0, (s, arr) => {
	for (let i = 0; i < arr.length; i++) s += arr[i];
	return s;
});
/**
* A sink that counts the number of elements fed to it.
*
* @since 2.0.0
* @category constructors
*/
var count = /*#__PURE__*/ reduceArray(() => 0, (s, arr) => s + arr.length);
/**
* Accumulates incoming elements into an array.
*
* @since 2.0.0
* @category constructors
*/
var collect$1 = () => reduceArray(empty$1, (s, arr) => {
	s.push(...arr);
	return s;
});
/**
* @since 4.0.0
* @category constructors
*/
var takeWhile$1 = (predicate) => fromTransform((upstream) => {
	const out = empty$1();
	return upstream.pipe(flatMap$2((arr) => {
		for (let i = 0; i < arr.length; i++) {
			if (!predicate(arr[i])) {
				const leftover = i + 1 < arr.length ? arr.slice(i + 1) : void 0;
				return done([out, leftover]);
			}
			out.push(arr[i]);
		}
		return void_;
	}), forever$1({ disableYield: true }), catchDone((end) => succeed$3(end ?? [out])));
});
/**
* @since 4.0.0
* @category constructors
*/
var takeWhileFilter$1 = (filter) => fromTransform((upstream) => {
	const out = empty$1();
	return upstream.pipe(flatMap$2((arr) => {
		for (let i = 0; i < arr.length; i++) {
			const result = filter(arr[i]);
			if (isFailure(result)) {
				const leftover = i + 1 < arr.length ? arr.slice(i + 1) : void 0;
				return done([out, leftover]);
			}
			out.push(result.success);
		}
		return void_;
	}), forever$1({ disableYield: true }), catchDone((end) => succeed$3(end ?? [out])));
});
/**
* @since 4.0.0
* @category constructors
*/
var takeWhileEffect$1 = (predicate) => fromTransform((upstream) => {
	const out = empty$1();
	let leftover = void 0;
	return upstream.pipe(flatMap$2((arr) => {
		let i = 0;
		return whileLoop({
			while: () => i < arr.length,
			body: constant(flatMap$2(suspend$2(() => {
				const input = arr[i++];
				return map$3(predicate(input), (passes) => [input, passes]);
			}), ([input, passes]) => {
				if (!passes) {
					if (i < arr.length) leftover = arr.slice(i);
					return done();
				}
				out.push(input);
				return void_;
			})),
			step: constVoid
		});
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([out, leftover])));
});
/**
* @since 4.0.0
* @category constructors
*/
var takeWhileFilterEffect = (filter) => fromTransform((upstream) => {
	const out = empty$1();
	let leftover = void 0;
	return upstream.pipe(flatMap$2((arr) => {
		let i = 0;
		return whileLoop({
			while: () => i < arr.length,
			body: constant(flatMap$2(suspend$2(() => filter(arr[i++])), (result) => {
				if (isFailure(result)) {
					if (i < arr.length) leftover = arr.slice(i);
					return done();
				}
				out.push(result.success);
				return void_;
			})),
			step: constVoid
		});
	}), forever$1({ disableYield: true }), catchDone(() => succeed$3([out, leftover])));
});
/**
* @since 4.0.0
* @category constructors
*/
var takeUntil$1 = (predicate) => suspend$1(() => {
	let done = false;
	return takeWhile$1((i) => {
		if (done) return false;
		done = predicate(i);
		return true;
	});
});
/**
* @since 4.0.0
* @category constructors
*/
var takeUntilEffect$1 = (predicate) => suspend$1(() => {
	let done = false;
	return takeWhileEffect$1((input) => {
		if (done) return succeed$3(false);
		return map$3(predicate(input), (b) => {
			done = b;
			return true;
		});
	});
});
/**
* A sink that executes the provided effectful function for every item fed
* to it.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* // Create a sink that logs each item
* const sink = Sink.forEach((item: number) => Console.log(`Processing: ${item}`))
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program)
* // Output:
* // Processing: 1
* // Processing: 2
* // Processing: 3
* ```
*
* @since 2.0.0
* @category constructors
*/
var forEach = (f) => forEachArray(forEach$1((_) => f(_), { discard: true }));
/**
* A sink that executes the provided effectful function for every Chunk fed
* to it.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* // Create a sink that processes chunks
* const sink = Sink.forEachArray((chunk: ReadonlyArray<number>) =>
*   Console.log(
*     `Processing chunk of ${chunk.length} items: [${chunk.join(", ")}]`
*   )
* )
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3, 4, 5)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program)
* // Output: Processing chunk of 5 items: [1, 2, 3, 4, 5]
* ```
*
* @since 4.0.0
* @category constructors
*/
var forEachArray = (f) => fromTransform((upstream) => upstream.pipe(flatMap$2(f), forever$1({ disableYield: true }), catchDone(() => endVoid)));
/**
* @since 2.0.0
* @category constructors
*/
var forEachWhile = (f) => forEachWhileArray(fnUntraced(function* (input) {
	for (let i = 0; i < input.length; i++) if (!(yield* f(input[i]))) return false;
	return true;
}));
/**
* @since 2.0.0
* @category constructors
*/
var forEachWhileArray = (f) => fromTransform((upstream) => upstream.pipe(flatMap$2(f), flatMap$2((cont) => cont ? void_ : done()), forever$1({ disableYield: true }), catchDone(() => endVoid)));
/**
* Creates a sink produced from a scoped effect.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* // Create a sink from an effect that produces a sink
* const sinkEffect = Effect.succeed(
*   Sink.forEach((item: number) => Console.log(`Item: ${item}`))
* )
* const sink = Sink.unwrap(sinkEffect)
*
* // Use it with a stream
* const stream = Stream.make(1, 2, 3)
* const program = Stream.run(stream, sink)
*
* Effect.runPromise(program)
* // Output:
* // Item: 1
* // Item: 2
* // Item: 3
* ```
*
* @since 2.0.0
* @category constructors
*/
var unwrap$1 = (effect) => fromChannel$1(unwrap$2(map$3(effect, toChannel$1)));
/**
* Summarize a sink by running an effect when the sink starts and again when
* it completes.
*
* @since 2.0.0
* @category utils
*/
var summarized = /*#__PURE__*/ dual(3, (self, summary, f) => fromTransform(fnUntraced(function* (upstream, scope) {
	const start = yield* summary;
	const [done, leftover] = yield* self.transform(upstream, scope);
	return [[done, f(start, yield* summary)], leftover];
})));
/**
* Returns the sink that executes this one and times its execution.
*
* @since 2.0.0
* @category utils
*/
var withDuration = (self) => summarized(self, currentTimeNanos, (start, end) => nanos(end - start));
/**
* @since 2.0.0
* @category constructors
*/
var timed = /*#__PURE__*/ map$1(/*#__PURE__*/ withDuration(drain$1), ([, duration]) => duration);
/**
* @since 4.0.0
* @category Services
*/
var provideServices$1 = /*#__PURE__*/ dual(2, (self, services) => fromTransform((upstream, scope) => self.transform(upstream, scope).pipe(provideServices$2(services))));
/**
* @since 4.0.0
* @category Services
*/
var provideService$1 = /*#__PURE__*/ dual(3, (self, key, value) => fromTransform((upstream, scope) => self.transform(upstream, scope).pipe(provideService$2(key, value))));
/**
* @since 2.0.0
* @category Error handling
*/
var orElse = /*#__PURE__*/ dual(2, (self, f) => fromTransform((upstream, scope) => {
	let upstreamDone = false;
	const pull = catchCause$2(upstream, (cause) => {
		upstreamDone = true;
		return failCause$2(cause);
	});
	return catch_$2(self.transform(pull, scope), (error) => f(error).transform(suspend$2(() => {
		if (upstreamDone) return done();
		return upstream;
	}), scope));
}));
/**
* @since 4.0.0
* @category Error handling
*/
var catchCause$1 = /*#__PURE__*/ dual(2, (self, f) => transformEffect(self, catchCause$2((cause) => map$3(f(cause), (a2) => [a2]))));
var catch_$1 = /*#__PURE__*/ dual(2, (self, f) => transformEffect(self, catch_$2((error) => map$3(f(error), (a2) => [a2]))));
/**
* @since 4.0.0
* @category Finalization
*/
var onExit$1 = /*#__PURE__*/ dual(2, (self, f) => transformEffect(self, onExit$2((exit) => f(map$5(exit, ([a]) => a)))));
/**
* @since 4.0.0
* @category Finalization
*/
var ensuring$1 = /*#__PURE__*/ dual(2, (self, effect) => onExit$1(self, () => effect));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/RcMap.js
/**
* @since 3.5.0
*/
var RcMap_exports = /* @__PURE__ */ __exportAll({
	get: () => get$2,
	has: () => has,
	invalidate: () => invalidate$2,
	keys: () => keys,
	make: () => make$3,
	touch: () => touch
});
var TypeId$2 = "~effect/RcMap";
var makeUnsafe = (options) => ({
	[TypeId$2]: TypeId$2,
	lookup: options.lookup,
	services: options.services,
	scope: options.scope,
	idleTimeToLive: options.idleTimeToLive,
	capacity: options.capacity,
	state: {
		_tag: "Open",
		map: empty$3()
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
});
/**
* An `RcMap` can contain multiple reference counted resources that can be indexed
* by a key. The resources are lazily acquired on the first call to `get` and
* released when the last reference is released.
*
* Complex keys can extend `Equal` and `Hash` to allow lookups by value.
*
* **Options**
*
* - `capacity`: The maximum number of resources that can be held in the map.
* - `idleTimeToLive`: When the reference count reaches zero, the resource will be released after this duration.
*
* @since 3.5.0
* @category models
* @example
* ```ts
* import { Effect, RcMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* RcMap.make({
*     lookup: (key: string) =>
*       Effect.acquireRelease(
*         Effect.succeed(`acquired ${key}`),
*         () => Effect.log(`releasing ${key}`)
*       )
*   })
*
*   // Get "foo" from the map twice, which will only acquire it once.
*   // It will then be released once the scope closes.
*   yield* RcMap.get(map, "foo").pipe(
*     Effect.andThen(RcMap.get(map, "foo")),
*     Effect.scoped
*   )
* })
* ```
*/
var make$3 = (options) => withFiber((fiber) => {
	const services = fiber.services;
	const scope = get$3(services, Scope);
	const self = makeUnsafe({
		lookup: options.lookup,
		services,
		scope,
		idleTimeToLive: typeof options.idleTimeToLive === "function" ? flow(options.idleTimeToLive, fromInputUnsafe) : constant(fromInputUnsafe(options.idleTimeToLive ?? zero)),
		capacity: Math.max(options.capacity ?? Number.POSITIVE_INFINITY, 0)
	});
	return as$1(addFinalizerExit(scope, () => {
		if (self.state._tag === "Closed") return void_;
		const map = self.state.map;
		self.state = { _tag: "Closed" };
		return forEach$1(map, ([, entry]) => exit(close(entry.scope, void_$1))).pipe(tap$1(() => sync$2(() => {
			clear(map);
		})));
	}), self);
});
/**
* Retrieves a value from the RcMap by key. If the resource doesn't exist, it will be
* acquired using the lookup function. The resource is reference counted and will be
* released when the scope closes.
*
* @since 3.5.0
* @category combinators
* @example
* ```ts
* import { Effect, RcMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* RcMap.make({
*     lookup: (key: string) =>
*       Effect.acquireRelease(
*         Effect.succeed(`Resource: ${key}`),
*         () => Effect.log(`Released ${key}`)
*       )
*   })
*
*   // Get a resource - it will be acquired on first access
*   const resource = yield* RcMap.get(map, "database")
*   console.log(resource) // "Resource: database"
* }).pipe(Effect.scoped)
* ```
*/
var get$2 = /*#__PURE__*/ dual(2, (self, key) => uninterruptibleMask((restore) => {
	if (self.state._tag === "Closed") return interrupt;
	const state = self.state;
	const parent = getCurrent();
	const o = get$4(state.map, key);
	let entry;
	if (o._tag === "Some") {
		entry = o.value;
		entry.refCount++;
	} else if (Number.isFinite(self.capacity) && size(self.state.map) >= self.capacity) return fail$3(new ExceededCapacityError(`RcMap attempted to exceed capacity of ${self.capacity}`));
	else {
		entry = {
			deferred: makeUnsafe$1(),
			scope: makeUnsafe$2(),
			idleTimeToLive: self.idleTimeToLive(key),
			finalizer: void 0,
			fiber: void 0,
			expiresAt: 0,
			refCount: 1
		};
		entry.finalizer = release(self, key, entry);
		set(state.map, key, entry);
		const services = new Map(self.services.mapUnsafe);
		parent.services.mapUnsafe.forEach((value, key) => {
			services.set(key, value);
		});
		services.set(Scope.key, entry.scope);
		self.lookup(key).pipe(runForkWith(makeUnsafe$3(services)), runIn(entry.scope)).addObserver((exit) => doneUnsafe(entry.deferred, exit));
	}
	return addFinalizer(getUnsafe(parent.services, Scope), entry.finalizer).pipe(andThen(restore(_await(entry.deferred))));
}));
var release = (self, key, entry) => withFiber((fiber) => {
	entry.refCount--;
	if (entry.refCount > 0) return void_;
	else if (self.state._tag === "Closed" || !has$1(self.state.map, key) || isZero(entry.idleTimeToLive)) {
		if (self.state._tag === "Open") remove(self.state.map, key);
		return close(entry.scope, void_$1);
	} else if (!isFinite(entry.idleTimeToLive)) return void_;
	const clock = fiber.getRef(Clock);
	entry.expiresAt = clock.currentTimeMillisUnsafe() + toMillis(entry.idleTimeToLive);
	if (entry.fiber) return void_;
	entry.fiber = interruptibleMask(function loop(restore) {
		const now = clock.currentTimeMillisUnsafe();
		const remaining = entry.expiresAt - now;
		if (remaining <= 0) {
			if (self.state._tag === "Closed" || entry.refCount > 0) return void_;
			remove(self.state.map, key);
			return restore(close(entry.scope, void_$1));
		}
		return flatMap$2(clock.sleep(millis(remaining)), () => loop(restore));
	}).pipe(ensuring$2(sync$2(() => {
		entry.fiber = void 0;
	})), runForkWith(fiber.services), runIn(self.scope));
	return void_;
});
/**
* Returns an array of all keys currently stored in the RcMap.
*
* @since 3.5.0
* @category combinators
* @example
* ```ts
* import { Effect, RcMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* RcMap.make({
*     lookup: (key: string) => Effect.succeed(`value-${key}`)
*   })
*
*   // Add some resources to the map
*   yield* RcMap.get(map, "foo")
*   yield* RcMap.get(map, "bar")
*   yield* RcMap.get(map, "baz")
*
*   // Get all keys currently in the map
*   const allKeys = yield* RcMap.keys(map)
*   console.log(allKeys) // ["foo", "bar", "baz"]
* }).pipe(Effect.scoped)
* ```
*/
var keys = (self) => {
	return suspend$2(() => self.state._tag === "Closed" ? interrupt : succeed$3(keys$1(self.state.map)));
};
/**
* Invalidates and removes a specific key from the RcMap. If the resource is not
* currently in use (reference count is 0), it will be immediately released.
*
* @since 3.5.0
* @category combinators
* @example
* ```ts
* import { Effect, RcMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* RcMap.make({
*     lookup: (key: string) =>
*       Effect.acquireRelease(
*         Effect.succeed(`Resource: ${key}`),
*         () => Effect.log(`Released ${key}`)
*       )
*   })
*
*   // Get a resource
*   yield* RcMap.get(map, "cache")
*
*   // Invalidate the resource - it will be removed from the map
*   // and released if no longer in use
*   yield* RcMap.invalidate(map, "cache")
*
*   // Next access will create a new resource
*   yield* RcMap.get(map, "cache")
* }).pipe(Effect.scoped)
* ```
*/
var invalidate$2 = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, key) {
	if (self.state._tag === "Closed") return;
	const o = get$4(self.state.map, key);
	if (o._tag === "None") return;
	const entry = o.value;
	remove(self.state.map, key);
	if (entry.refCount > 0) return;
	if (entry.fiber) yield* interrupt$1(entry.fiber);
	yield* close(entry.scope, void_$1);
}, uninterruptible));
/**
* @since 3.17.7
* @category combinators
*/
var has = /*#__PURE__*/ dual(2, (self, key) => sync$2(() => {
	if (self.state._tag === "Closed") return false;
	return has$1(self.state.map, key);
}));
/**
* Extends the idle time for a resource in the RcMap. If the RcMap has an
* `idleTimeToLive` configured, calling `touch` will reset the expiration
* timer for the specified key.
*
* @since 3.5.0
* @category combinators
* @example
* ```ts
* import { Effect, RcMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* RcMap.make({
*     lookup: (key: string) =>
*       Effect.acquireRelease(
*         Effect.succeed(`Resource: ${key}`),
*         () => Effect.log(`Released ${key}`)
*       ),
*     idleTimeToLive: "10 seconds"
*   })
*
*   // Get a resource
*   yield* RcMap.get(map, "session")
*
*   // Touch the resource to extend its idle time
*   // This resets the 10-second expiration timer
*   yield* RcMap.touch(map, "session")
*
*   // The resource will now live for another 10 seconds
*   // from the time it was touched
* }).pipe(Effect.scoped)
* ```
*/
var touch = /*#__PURE__*/ dual(2, (self, key) => clockWith((clock) => {
	if (self.state._tag === "Closed") return void_;
	const o = get$4(self.state.map, key);
	if (o._tag === "None" || isZero(o.value.idleTimeToLive)) return void_;
	const entry = o.value;
	entry.expiresAt = clock.currentTimeMillisUnsafe() + toMillis(entry.idleTimeToLive);
	return void_;
}));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/rcRef.js
var TypeId$1 = "~effect/RcRef";
var stateEmpty = { _tag: "Empty" };
var stateClosed = { _tag: "Closed" };
var variance = {
	_A: identity,
	_E: identity
};
var RcRefImpl = class {
	[TypeId$1] = variance;
	pipe() {
		return pipeArguments(this, arguments);
	}
	state = stateEmpty;
	semaphore = /*#__PURE__*/ makeUnsafe$4(1);
	acquire;
	services;
	scope;
	idleTimeToLive;
	constructor(acquire, services, scope, idleTimeToLive) {
		this.acquire = acquire;
		this.services = services;
		this.scope = scope;
		this.idleTimeToLive = idleTimeToLive;
	}
};
/** @internal */
var make$2 = (options) => withFiber((fiber) => {
	const services = fiber.services;
	const scope = get$3(services, Scope);
	const ref = new RcRefImpl(options.acquire, services, scope, options.idleTimeToLive ? fromInputUnsafe(options.idleTimeToLive) : void 0);
	return as$1(addFinalizerExit(scope, () => {
		const close$1 = ref.state._tag === "Acquired" ? close(ref.state.scope, void_$1) : void_;
		ref.state = stateClosed;
		return close$1;
	}), ref);
});
var getState = (self) => uninterruptibleMask((restore) => {
	switch (self.state._tag) {
		case "Closed": return interrupt;
		case "Acquired":
			self.state.refCount++;
			return self.state.fiber ? as$1(interrupt$1(self.state.fiber), self.state) : succeed$3(self.state);
		case "Empty": {
			const scope = makeUnsafe$2();
			return self.semaphore.withPermits(1)(restore(provideServices$2(self.acquire, add(self.services, Scope, scope))).pipe(map$3((value) => {
				const state = {
					_tag: "Acquired",
					value,
					scope,
					fiber: void 0,
					refCount: 1,
					invalidated: false
				};
				self.state = state;
				return state;
			})));
		}
	}
});
/** @internal */
var get$1 = /*#__PURE__*/ fnUntraced(function* (self_) {
	const self = self_;
	const state = yield* getState(self);
	const scope$2 = yield* scope;
	const isFinite$1 = self.idleTimeToLive !== void 0 && isFinite(self.idleTimeToLive);
	yield* addFinalizerExit(scope$2, () => {
		state.refCount--;
		if (state.refCount > 0) return void_;
		if (self.idleTimeToLive === void 0) {
			self.state = stateEmpty;
			return close(state.scope, void_$1);
		} else if (state.invalidated) return close(state.scope, void_$1);
		else if (!isFinite$1) return void_;
		state.fiber = sleep(self.idleTimeToLive).pipe(flatMap$2(() => {
			if (self.state._tag === "Acquired" && self.state.refCount === 0) {
				self.state = stateEmpty;
				return close(state.scope, void_$1);
			}
			return void_;
		}), ensuring$2(sync$2(() => {
			state.fiber = void 0;
		})), runForkWith(self.services), runIn(self.scope));
		return void_;
	});
	return state.value;
});
/** @internal */
var invalidate$1 = (self_) => {
	const self = self_;
	return uninterruptible(suspend$2(() => {
		if (self.state._tag !== "Acquired") return void_;
		const state = self.state;
		self.state = stateEmpty;
		state.invalidated = true;
		if (state.refCount > 0) return void_;
		state.fiber?.interruptUnsafe();
		return close(state.scope, void_$1);
	}));
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/RcRef.js
var RcRef_exports = /* @__PURE__ */ __exportAll({
	get: () => get,
	invalidate: () => invalidate,
	make: () => make$1
});
/**
* Create an `RcRef` from an acquire `Effect`.
*
* An RcRef wraps a reference counted resource that can be acquired and released
* multiple times.
*
* The resource is lazily acquired on the first call to `get` and released when
* the last reference is released.
*
* @since 3.5.0
* @category constructors
* @example
* ```ts
* import { Effect, RcRef } from "effect"
*
* Effect.gen(function*() {
*   const ref = yield* RcRef.make({
*     acquire: Effect.acquireRelease(
*       Effect.succeed("foo"),
*       () => Effect.log("release foo")
*     )
*   })
*
*   // will only acquire the resource once, and release it
*   // when the scope is closed
*   yield* RcRef.get(ref).pipe(
*     Effect.andThen(RcRef.get(ref)),
*     Effect.scoped
*   )
* })
* ```
*/
var make$1 = make$2;
/**
* Get the value from an RcRef.
*
* This will acquire the resource if it hasn't been acquired yet, or increment
* the reference count if it has. The resource will be automatically released
* when the returned scope is closed.
*
* @since 3.5.0
* @category combinators
* @example
* ```ts
* import { Effect, RcRef } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create an RcRef with a resource
*   const ref = yield* RcRef.make({
*     acquire: Effect.acquireRelease(
*       Effect.succeed("shared resource"),
*       (resource) => Effect.log(`Releasing ${resource}`)
*     )
*   })
*
*   // Get the value from the RcRef
*   const value1 = yield* RcRef.get(ref)
*   const value2 = yield* RcRef.get(ref)
*
*   // Both values are the same instance
*   console.log(value1 === value2) // true
*
*   return value1
* })
* ```
*/
var get = get$1;
/**
* @since 3.19.6
* @category combinators
*/
var invalidate = invalidate$1;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Stream.js
/**
* @since 2.0.0
*/
var Stream_exports = /* @__PURE__ */ __exportAll({
	DefaultChunkSize: () => DefaultChunkSize,
	Do: () => Do,
	accumulate: () => accumulate,
	aggregate: () => aggregate,
	aggregateWithin: () => aggregateWithin,
	bind: () => bind,
	bindEffect: () => bindEffect,
	bindTo: () => bindTo,
	broadcast: () => broadcast,
	buffer: () => buffer,
	bufferArray: () => bufferArray,
	callback: () => callback,
	catch: () => catch_,
	catchCause: () => catchCause,
	catchCauseFilter: () => catchCauseFilter,
	catchCauseIf: () => catchCauseIf,
	catchFilter: () => catchFilter,
	catchIf: () => catchIf,
	catchReason: () => catchReason,
	catchReasons: () => catchReasons,
	catchTag: () => catchTag,
	catchTags: () => catchTags,
	changes: () => changes,
	changesWith: () => changesWith,
	changesWithEffect: () => changesWithEffect,
	chunks: () => chunks,
	collect: () => collect,
	combine: () => combine,
	combineArray: () => combineArray,
	concat: () => concat,
	cross: () => cross,
	crossWith: () => crossWith,
	debounce: () => debounce,
	decodeText: () => decodeText,
	die: () => die,
	drain: () => drain,
	drainFork: () => drainFork,
	drop: () => drop,
	dropRight: () => dropRight,
	dropUntil: () => dropUntil,
	dropUntilEffect: () => dropUntilEffect,
	dropWhile: () => dropWhile,
	dropWhileEffect: () => dropWhileEffect,
	dropWhileFilter: () => dropWhileFilter,
	empty: () => empty,
	encodeText: () => encodeText,
	ensuring: () => ensuring,
	fail: () => fail,
	failCause: () => failCause,
	failCauseSync: () => failCauseSync,
	failSync: () => failSync,
	filter: () => filter,
	filterEffect: () => filterEffect,
	filterMap: () => filterMap,
	filterMapEffect: () => filterMapEffect,
	flatMap: () => flatMap,
	flatten: () => flatten,
	flattenArray: () => flattenArray,
	flattenEffect: () => flattenEffect,
	flattenIterable: () => flattenIterable,
	flattenTake: () => flattenTake,
	forever: () => forever,
	fromArray: () => fromArray,
	fromArrayEffect: () => fromArrayEffect,
	fromArrays: () => fromArrays,
	fromAsyncIterable: () => fromAsyncIterable,
	fromChannel: () => fromChannel,
	fromEffect: () => fromEffect,
	fromEffectDrain: () => fromEffectDrain,
	fromEffectRepeat: () => fromEffectRepeat,
	fromEffectSchedule: () => fromEffectSchedule,
	fromEventListener: () => fromEventListener,
	fromIterable: () => fromIterable,
	fromIterableEffect: () => fromIterableEffect,
	fromIterableEffectRepeat: () => fromIterableEffectRepeat,
	fromIteratorSucceed: () => fromIteratorSucceed,
	fromPubSub: () => fromPubSub,
	fromPubSubTake: () => fromPubSubTake,
	fromPull: () => fromPull,
	fromQueue: () => fromQueue,
	fromReadableStream: () => fromReadableStream,
	fromSchedule: () => fromSchedule,
	fromSubscription: () => fromSubscription,
	groupAdjacentBy: () => groupAdjacentBy,
	groupBy: () => groupBy,
	groupByKey: () => groupByKey,
	grouped: () => grouped,
	groupedWithin: () => groupedWithin,
	haltWhen: () => haltWhen,
	ignore: () => ignore,
	ignoreCause: () => ignoreCause,
	interleave: () => interleave,
	interleaveWith: () => interleaveWith,
	interruptWhen: () => interruptWhen,
	intersperse: () => intersperse,
	intersperseAffixes: () => intersperseAffixes,
	isStream: () => isStream,
	iterate: () => iterate,
	let: () => let_,
	make: () => make,
	map: () => map,
	mapAccum: () => mapAccum,
	mapAccumArray: () => mapAccumArray,
	mapAccumArrayEffect: () => mapAccumArrayEffect,
	mapAccumEffect: () => mapAccumEffect,
	mapArray: () => mapArray,
	mapArrayEffect: () => mapArrayEffect,
	mapBoth: () => mapBoth,
	mapEffect: () => mapEffect,
	mapError: () => mapError,
	merge: () => merge,
	mergeAll: () => mergeAll,
	mergeEffect: () => mergeEffect,
	mergeLeft: () => mergeLeft,
	mergeResult: () => mergeResult,
	mergeRight: () => mergeRight,
	mkString: () => mkString,
	mkUint8Array: () => mkUint8Array,
	never: () => never,
	onEnd: () => onEnd,
	onError: () => onError,
	onExit: () => onExit,
	onFirst: () => onFirst,
	onStart: () => onStart,
	orDie: () => orDie,
	orElseIfEmpty: () => orElseIfEmpty,
	orElseSucceed: () => orElseSucceed,
	paginate: () => paginate,
	partition: () => partition,
	partitionEffect: () => partitionEffect,
	partitionQueue: () => partitionQueue,
	peel: () => peel,
	pipeThrough: () => pipeThrough,
	pipeThroughChannel: () => pipeThroughChannel,
	pipeThroughChannelOrFail: () => pipeThroughChannelOrFail,
	prepend: () => prepend,
	provide: () => provide,
	provideService: () => provideService,
	provideServiceEffect: () => provideServiceEffect,
	provideServices: () => provideServices,
	race: () => race,
	raceAll: () => raceAll,
	range: () => range,
	rechunk: () => rechunk,
	repeat: () => repeat,
	repeatElements: () => repeatElements,
	result: () => result,
	retry: () => retry,
	run: () => run,
	runCollect: () => runCollect,
	runCount: () => runCount,
	runDrain: () => runDrain,
	runFold: () => runFold,
	runFoldEffect: () => runFoldEffect,
	runForEach: () => runForEach,
	runForEachArray: () => runForEachArray,
	runForEachWhile: () => runForEachWhile,
	runHead: () => runHead,
	runIntoPubSub: () => runIntoPubSub,
	runIntoQueue: () => runIntoQueue,
	runLast: () => runLast,
	runSum: () => runSum,
	scan: () => scan,
	scanEffect: () => scanEffect,
	schedule: () => schedule,
	scoped: () => scoped,
	share: () => share,
	sliding: () => sliding,
	slidingSize: () => slidingSize,
	split: () => split,
	splitLines: () => splitLines,
	succeed: () => succeed,
	suspend: () => suspend,
	switchMap: () => switchMap,
	sync: () => sync,
	take: () => take,
	takeRight: () => takeRight,
	takeUntil: () => takeUntil,
	takeUntilEffect: () => takeUntilEffect,
	takeWhile: () => takeWhile,
	takeWhileEffect: () => takeWhileEffect,
	takeWhileFilter: () => takeWhileFilter,
	tap: () => tap,
	tapBoth: () => tapBoth,
	tapCause: () => tapCause,
	tapError: () => tapError,
	tapSink: () => tapSink,
	throttle: () => throttle,
	throttleEffect: () => throttleEffect,
	tick: () => tick,
	timeout: () => timeout,
	toAsyncIterable: () => toAsyncIterable,
	toAsyncIterableEffect: () => toAsyncIterableEffect,
	toAsyncIterableWith: () => toAsyncIterableWith,
	toChannel: () => toChannel,
	toPubSub: () => toPubSub,
	toPubSubTake: () => toPubSubTake,
	toPull: () => toPull,
	toQueue: () => toQueue,
	toReadableStream: () => toReadableStream,
	toReadableStreamEffect: () => toReadableStreamEffect,
	toReadableStreamWith: () => toReadableStreamWith,
	transduce: () => transduce,
	transformPull: () => transformPull,
	transformPullBracket: () => transformPullBracket,
	unfold: () => unfold,
	unwrap: () => unwrap,
	updateService: () => updateService,
	updateServices: () => updateServices,
	when: () => when,
	withExecutionPlan: () => withExecutionPlan,
	withSpan: () => withSpan,
	zip: () => zip,
	zipFlatten: () => zipFlatten,
	zipLatest: () => zipLatest,
	zipLatestAll: () => zipLatestAll,
	zipLatestWith: () => zipLatestWith,
	zipLeft: () => zipLeft,
	zipRight: () => zipRight,
	zipWith: () => zipWith,
	zipWithArray: () => zipWithArray,
	zipWithIndex: () => zipWithIndex,
	zipWithNext: () => zipWithNext,
	zipWithPrevious: () => zipWithPrevious,
	zipWithPreviousAndNext: () => zipWithPreviousAndNext
});
var TypeId = "~effect/Stream";
/**
* Checks whether a value is a Stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3)
*   const notStream = { data: [1, 2, 3] }
*
*   yield* Console.log(Stream.isStream(stream))
*   // true
*   yield* Console.log(Stream.isStream(notStream))
*   // false
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Guards
*/
var isStream = (u) => hasProperty(u, TypeId);
/**
* The default chunk size used by Stream constructors and combinators.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.log(Stream.DefaultChunkSize)
* })
*
* Effect.runPromise(program)
* // Output: 4096
* ```
*
* @category Constants
* @since 2.0.0
*/
var DefaultChunkSize = DefaultChunkSize$1;
/**
* Creates a stream from a array-emitting `Channel`.
*
* @example
* ```ts
* import { Channel, Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const channel = Channel.succeed([1, 2, 3] as const)
*   const stream = Stream.fromChannel(channel)
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromChannel = fromChannel$2;
/**
* Either emits the success value of this effect or terminates the stream
* with the failure value of this effect.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromEffect(Effect.succeed(42))
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 42 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromEffect = (effect) => fromChannel(fromEffect$2(map$3(effect, of)));
/**
* Creates a stream that runs the effect and emits no elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Stream.fromEffectDrain(Console.log("Draining side effect")).pipe(
*     Stream.runDrain
*   )
* })
*
* Effect.runPromise(program)
* // Output: Draining side effect
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromEffectDrain = (effect) => fromPull(succeed$3(flatMap$2(effect, () => done())));
/**
* Creates a stream from an effect producing a value of type `A` which repeats forever.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.repeatEffect`
*
* @example
* ```ts
* import { Console, Effect, Random, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromEffectRepeat(Random.nextInt).pipe(
*     Stream.take(5)
*   )
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 3891571149, 4239494205, 2352981603, 2339111046, 1488052210 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromEffectRepeat = (effect) => fromPull(succeed$3(map$3(effect, of)));
/**
* Creates a stream from an effect producing a value of type `A`, which is
* repeated using the specified schedule.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.repeatEffectWithSchedule`
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromEffectSchedule(
*     Effect.succeed("ping"),
*     Schedule.recurs(2)
*   )
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ "ping", "ping", "ping" ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromEffectSchedule = (effect, schedule) => fromPull(gen(function* () {
	const step = yield* toStepWithMetadata(schedule);
	let s = yield* provideService$2(effect, CurrentMetadata, CurrentMetadata.defaultValue());
	let initial = true;
	const pull = suspend$2(() => step(s)).pipe(flatMap$2((meta) => provideService$2(effect, CurrentMetadata, meta)), map$3((next) => {
		s = next;
		return of(next);
	}));
	return suspend$2(() => {
		if (initial) {
			initial = false;
			return succeed$3(of(s));
		}
		return pull;
	});
}));
/**
* Creates a stream that emits void values spaced by the specified duration.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const ticks = yield* Stream.tick("200 millis").pipe(
*     Stream.take(3),
*     Stream.runCollect
*   )
*   yield* Console.log(ticks)
* })
*
* Effect.runPromise(program)
* // Output: [ undefined, undefined, undefined ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var tick = (interval) => fromPull(sync$2(() => {
	let first = true;
	const effect = succeed$3(of(void 0));
	const delayed = delay(effect, interval);
	return suspend$2(() => {
		if (first) {
			first = false;
			return effect;
		}
		return delayed;
	});
}));
/**
* Creates a stream from a pull effect, such as one produced by `Stream.toPull`.
*
* A pull effect yields chunks on demand and completes when the upstream stream ends.
* See `Stream.toPull` for a matching producer.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const source = Stream.make(1, 2, 3)
*     const pull = yield* Stream.toPull(source)
*     const stream = Stream.fromPull(Effect.succeed(pull))
*     const values = yield* Stream.runCollect(stream)
*     yield* Console.log(values)
*   })
* )
*
* Effect.runPromise(program)
* // Output: [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromPull = (pull) => fromChannel(fromPull$1(pull));
/**
* Derive a stream by transforming its pull effect.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const transformed = Stream.transformPull(stream, (pull) => Effect.succeed(pull))
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(transformed)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var transformPull = (self, f) => fromChannel(fromTransform$1((_, scope) => flatMap$2(toPullScoped(self.channel, scope), (pull) => f(pull, scope))));
/**
* Transforms a stream by effectfully transforming its pull effect.
*
* A forked scope is also provided to the transformation function, which is
* closed once the resulting stream has finished processing.
*
* @example
* ```ts
* import { Console, Effect, Scope, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const transformed = Stream.transformPullBracket(
*   stream,
*   (pull, _scope, forkedScope) =>
*     Effect.gen(function*() {
*       yield* Scope.addFinalizer(forkedScope, Console.log("Releasing scope"))
*       return pull
*     })
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(transformed)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [1, 2, 3]
* // Releasing scope
* ```
*
* @since 4.0.0
* @category Constructors
*/
var transformPullBracket = (self, f) => fromChannel(fromTransformBracket((_, scope, forkedScope) => flatMap$2(toPullScoped(self.channel, scope), (pull) => f(pull, scope, forkedScope))));
/**
* Creates a channel from a stream.
*
* @example
* ```ts
* import { Channel, Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3)
*   const channel = Stream.toChannel(stream)
*   const values = yield* Channel.runCollect(channel)
*   yield* Console.log(values.flat())
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var toChannel = (stream) => stream.channel;
/**
* Creates a stream from a callback that can emit values into a queue.
*
* You can use the `Queue` with the apis from the `Queue` module to emit
* values to the stream or to signal the stream ending.
*
* By default it uses an "unbounded" buffer size.
* You can customize the buffer size and strategy by passing an object as the
* second argument with the `bufferSize` and `strategy` fields.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.async`
* - `Stream.asyncEffect`
* - `Stream.asyncPush`
* - `Stream.asyncScoped`
*
* @example
* ```ts
* import { Console, Effect, Queue, Stream } from "effect"
*
* const stream = Stream.callback<number>((queue) =>
*   Effect.sync(() => {
*     // Emit values to the stream
*     Queue.offerUnsafe(queue, 1)
*     Queue.offerUnsafe(queue, 2)
*     Queue.offerUnsafe(queue, 3)
*     // Signal completion
*     Queue.endUnsafe(queue)
*   })
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* stream.pipe(Stream.runCollect)
*   yield* Console.log(values)
*   // [ 1, 2, 3 ]
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Constructors
*/
var callback = (f, options) => fromChannel(callbackArray(f, options));
/**
* Creates an empty stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.empty.pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // []
* ```
*
* @since 4.0.0
* @category Constructors
*/
var empty = /*#__PURE__*/ fromChannel(empty$4);
/**
* Creates a single-valued pure stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.succeed(3).pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // [ 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var succeed = (value) => fromChannel(succeed$4(of(value)));
/**
* Creates a stream from a sequence of values.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values) // [ 1, 2, 3 ]
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Constructors
*/
var make = (...values) => fromArray(values);
/**
* Creates a stream that synchronously evaluates a function and emits the result as a single value.
*
* The function is evaluated each time the stream is run.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.sync(() => 2 + 1).pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var sync = (evaluate) => fromChannel(sync$3(() => of(evaluate())));
/**
* Creates a lazily constructed stream.
*
* The stream factory is evaluated each time the stream is run.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.suspend(() => Stream.make(1, 2, 3)).pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var suspend = (stream) => fromChannel(suspend$3(() => stream().channel));
/**
* Terminates with the specified error.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fail("Uh oh!")
*   const exit = yield* Effect.exit(Stream.runCollect(stream))
*   yield* Console.log(exit)
*   // Output: { _id: 'Exit', _tag: 'Failure', cause: { _id: 'Cause', _tag: 'Fail', failure: 'Uh oh!' } }
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fail = (error) => fromChannel(fail$5(error));
/**
* Terminates with the specified lazily evaluated error.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.failSync(() => "Uh oh!")
*
* const program = Effect.gen(function*() {
*   const exit = yield* Stream.runCollect(stream).pipe(Effect.exit)
*   yield* Console.log(exit)
* })
*
* Effect.runPromise(program)
* // Output:
* // { _id: 'Exit', _tag: 'Failure', cause: { _id: 'Cause', _tag: 'Fail', failure: 'Uh oh!' } }
* ```
*
* @since 2.0.0
* @category Constructors
*/
var failSync = (evaluate) => fromChannel(failSync$3(evaluate));
/**
* Creates a stream that fails with the specified `Cause`.
*
* @example
* ```ts
* import { Cause, Console, Effect, Stream } from "effect"
*
* const stream = Stream.failCause(Cause.fail("Database connection failed")).pipe(
*   Stream.catchCause(() => Stream.succeed("recovered"))
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
*   // Output: [ "recovered" ]
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Constructors
*/
var failCause = (cause) => fromChannel(failCause$3(cause));
/**
* The stream that dies with the specified defect.
*
* @example
* ```ts
* import { Cause, Console, Effect, Exit, Stream } from "effect"
*
* const defect = new Error("Boom")
* const stream = Stream.die(defect)
*
* const program = Effect.gen(function*() {
*   const exit = yield* Effect.exit(Stream.runCollect(stream))
*   const message = Exit.match(exit, {
*     onSuccess: () => "Exit.Success",
*     onFailure: (cause) => {
*       const reason = cause.reasons[0]
*       const defect = Cause.isDieReason(reason) ? String(reason.defect) : "Unexpected reason"
*       return `Exit.Failure(${defect})`
*     }
*   })
*   yield* Console.log(message)
* })
*
* Effect.runPromise(program)
* // Output: Exit.Failure(Error: Boom)
* ```
*
* @since 2.0.0
* @category Constructors
*/
var die = (defect) => fromChannel(die$3(defect));
/**
* The stream that always fails with the specified lazily evaluated `Cause`.
*
* @example
* ```ts
* import { Cause, Console, Effect, Stream } from "effect"
*
* const stream = Stream.failCauseSync(() =>
*   Cause.fail("Connection timeout after retries")
* )
*
* const program = Effect.gen(function*() {
*   const exit = yield* Stream.runCollect(stream).pipe(Effect.exit)
*   yield* Console.log(exit)
* })
*
* Effect.runPromise(program)
* // Output:
* // { _id: 'Exit', _tag: 'Failure', cause: { _id: 'Cause', _tag: 'Fail', failure: 'Connection timeout after retries' } }
* ```
*
* @since 2.0.0
* @category Constructors
*/
var failCauseSync = (evaluate) => fromChannel(failCauseSync$3(evaluate));
/**
* Creates a stream that consumes values from an iterator.
*
* The `maxChunkSize` parameter controls how many values are pulled per chunk.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* function* numbers() {
*   yield 1
*   yield 2
*   yield 3
* }
*
* const stream = Stream.fromIteratorSucceed(numbers())
*
* const program = Effect.gen(function* () {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromIteratorSucceed = (iterator, maxChunkSize) => fromChannel(fromIteratorArray(() => iterator, maxChunkSize));
/**
* Creates a new `Stream` from an iterable collection of values.
*
* **Options**
*
* - `chunkSize`: Maximum number of values emitted per chunk.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const numbers = [1, 2, 3]
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromIterable(numbers)
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromIterable = (iterable, options) => Array.isArray(iterable) && options?.chunkSize === void 0 ? fromArray(iterable) : fromChannel(fromIterableArray(iterable, options?.chunkSize));
/**
* Creates a stream from an effect producing an iterable of values.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap, Stream } from "effect"
*
* class UserRepo extends ServiceMap.Service<UserRepo, {
*   readonly list: Effect.Effect<ReadonlyArray<string>>
* }>()("UserRepo") {}
*
* const listUsers = Effect.service(UserRepo).pipe(
*   Effect.andThen((repo) => repo.list)
* )
*
* const stream = Stream.fromIterableEffect(listUsers)
*
* const program = Effect.gen(function*() {
*   const users = yield* stream.pipe(
*     Stream.provideService(UserRepo, {
*       list: Effect.succeed(["user1", "user2"])
*     }),
*     Stream.runCollect
*   )
*   yield* Console.log(users)
* })
*
* Effect.runPromise(program)
* // Output: [ "user1", "user2" ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromIterableEffect = (iterable) => unwrap(map$3(iterable, fromIterable));
/**
* Creates a stream by repeatedly running an effect that yields an iterable of values.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.repeatEffectChunk`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromIterableEffectRepeat(Effect.succeed([1, 2])).pipe(
*     Stream.take(5)
*   )
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 1, 2, 1 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromIterableEffectRepeat = (iterable) => flatMap(fromEffectRepeat(iterable), fromIterable);
/**
* Creates a stream from an array of values.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.fromChunk`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromArray([1, 2, 3])
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromArray = (array) => isReadonlyArrayNonEmpty(array) ? fromChannel(succeed$4(array)) : empty;
/**
* Creates a stream from an effect that produces an array of values.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromArrayEffect(Effect.succeed(["Ada", "Grace"]))
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ "Ada", "Grace" ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromArrayEffect = (effect) => unwrap(map$3(effect, fromArray));
/**
* Creates a stream from an arbitrary number of arrays.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.fromChunks`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromArrays([1, 2], [3, 4])
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3, 4 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromArrays = (...arrays) => fromChannel(fromArray$1(filter$1(arrays, isReadonlyArrayNonEmpty)));
/**
* Creates a stream from a queue of values.
*
* **Options**
*
* - `maxChunkSize`: The maximum number of queued elements to put in one chunk in the stream
* - `shutdown`: If `true`, the queue will be shutdown after the stream is evaluated (defaults to `false`)
*
* @example
* ```ts
* import { Console, Effect, Queue, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.unbounded<number>()
*   yield* Queue.offer(queue, 1)
*   yield* Queue.offer(queue, 2)
*   yield* Queue.offer(queue, 3)
*   yield* Queue.shutdown(queue)
*
*   const stream = Stream.fromQueue(queue)
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromQueue = (queue) => fromChannel(fromQueueArray(queue));
/**
* Creates a stream from a subscription to a `PubSub`.
*
* @example
* ```ts
* import { Console, Effect, Fiber, PubSub, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.unbounded<number>()
*
*   const fiber = yield* Stream.fromPubSub(pubsub).pipe(
*     Stream.take(3),
*     Stream.runCollect,
*     Effect.forkChild
*   )
*
*   yield* PubSub.publish(pubsub, 1)
*   yield* PubSub.publish(pubsub, 2)
*   yield* PubSub.publish(pubsub, 3)
*
*   const values = yield* Fiber.join(fiber)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromPubSub = (pubsub) => fromChannel(fromPubSubArray(pubsub));
/**
* Creates a stream from a PubSub of `Take` values.
*
* `Take` values include end and failure signals.
*
* @example
* ```ts
* import { Console, Effect, Exit, PubSub, Stream, Take } from "effect"
*
* const program = Effect.gen(function*() {
*   const pubsub = yield* PubSub.unbounded<Take.Take<number, string>>({
*     replay: 3
*   })
*
*   yield* PubSub.publish(pubsub, [1])
*   yield* PubSub.publish(pubsub, [2])
*   yield* PubSub.publish(pubsub, Exit.succeed<void>(undefined))
*
*   const values = yield* Stream.fromPubSubTake(pubsub).pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromPubSubTake = (pubsub) => fromChannel(fromPubSubTake$1(pubsub));
/**
* Creates a stream from a `ReadableStream`.
*
* See https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const readableStream = new ReadableStream({
*   start(controller) {
*     controller.enqueue(1)
*     controller.enqueue(2)
*     controller.enqueue(3)
*     controller.close()
*   }
* })
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromReadableStream({
*     evaluate: () => readableStream,
*     onError: (error) => new Error(String(error))
*   })
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromReadableStream = (options) => fromChannel(fromTransform$1(fnUntraced(function* (_, scope) {
	const reader = options.evaluate().getReader();
	yield* addFinalizer(scope, options.releaseLockOnEnd ? sync$2(() => reader.releaseLock()) : promise(() => reader.cancel()));
	return flatMap$2(tryPromise({
		try: () => reader.read(),
		catch: (reason) => options.onError(reason)
	}), ({ done: done$10, value }) => done$10 ? done() : succeed$3(of(value)));
})));
/**
* Creates a stream from an AsyncIterable.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const iterable = (async function*() {
*   yield 1
*   yield 2
*   yield 3
* })()
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromAsyncIterable(iterable, (error) => new Error(String(error)))
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromAsyncIterable = (iterable, onError) => fromChannel(fromAsyncIterableArray(iterable, onError));
/**
* Creates a stream that emits each output of a schedule that does not require input,
* for as long as the schedule continues.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const schedule = Schedule.spaced("50 millis").pipe(
*     Schedule.compose(Schedule.recurs(2))
*   )
*   const stream = Stream.fromSchedule(schedule)
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 0, 1, 2 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var fromSchedule = (schedule) => fromPull(map$3(toStepWithSleep(schedule), (step) => catchDone(map$3(step(void 0), of), () => done())));
/**
* Creates a stream from a PubSub subscription.
*
* Use `PubSub.subscribe` to create the subscription and `Stream.take` or
* cancellation to control how many values are consumed.
*
* @example
* ```ts
* import { Console, Effect, PubSub, Stream } from "effect"
*
* const program = Effect.scoped(Effect.gen(function*() {
*   const pubsub = yield* PubSub.unbounded<number>()
*   const subscription = yield* PubSub.subscribe(pubsub)
*
*   yield* PubSub.publish(pubsub, 1)
*   yield* PubSub.publish(pubsub, 2)
*
*   const stream = Stream.fromSubscription(subscription)
*   const values = yield* stream.pipe(Stream.take(2), Stream.runCollect)
*   yield* Console.log(values)
* }))
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 4.0.0
* @category Constructors
*/
var fromSubscription = (pubsub) => fromChannel(fromSubscriptionArray(pubsub));
/**
* Creates a stream from an event listener.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* declare const target: Stream.EventListener<number>
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromEventListener(target, "data").pipe(
*     Stream.take(3)
*   )
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 3.1.0
* @category Constructors
*/
var fromEventListener = (target, type, options) => callback((queue) => {
	function emit(event) {
		offerUnsafe(queue, event);
	}
	return acquireRelease(sync$2(() => target.addEventListener(type, emit, options)), () => sync$2(() => target.removeEventListener(type, emit, options)));
}, { bufferSize: typeof options === "object" ? options.bufferSize : void 0 });
/**
* Creates a stream by peeling off successive layers of a state value.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.unfold(1, (n) => Effect.succeed([n, n + 1] as const))
*   const values = yield* Stream.runCollect(stream.pipe(Stream.take(5)))
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3, 4, 5 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var unfold = (s, f) => fromPull(sync$2(() => {
	let state = s;
	return flatMap$2(suspend$2(() => f(state)), (next) => {
		if (next === void 0) return done();
		state = next[1];
		return succeed$3(of(next[0]));
	});
}));
/**
* Like `Stream.unfold`, but allows the emission of values to end one step further
* than the unfolding of the state. This is useful for embedding paginated APIs,
* hence the name.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
* import * as Option from "effect/Option"
*
* const stream = Stream.paginate(0, (n: number) =>
*   Effect.succeed(
*     [
*       [n],
*       n < 3 ? Option.some(n + 1) : Option.none<number>()
*     ] as const
*   ))
*
* Effect.runPromise(Stream.runCollect(stream)).then(console.log)
* // Output: [ 0, 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var paginate = (s, f) => fromPull(sync$2(() => {
	let state = s;
	let done$5 = false;
	return suspend$2(function loop() {
		if (done$5) return done();
		return flatMap$2(f(state), ([a, s]) => {
			if (isNone(s)) done$5 = true;
			else state = s.value;
			if (!isReadonlyArrayNonEmpty(a)) return loop();
			return succeed$3(a);
		});
	});
}));
/**
* Creates an infinite stream by repeatedly applying a function to a seed value.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.iterate(1, (n) => n + 1).pipe(Stream.take(3))
*
* const program = Effect.gen(function* () {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var iterate = (value, next) => unfold(value, (a) => succeed$3([a, next(a)]));
/**
* Constructs a stream from a range of integers, including both endpoints.
*
* If the provided `min` is greater than `max`, the stream will not emit any
* values.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.range(1, 5).pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3, 4, 5 ]
* ```
* @since 4.0.0
* @category Constructors
*/
var range = (min, max, chunkSize = DefaultChunkSize$1) => min > max ? empty : fromPull(sync$2(() => {
	let start = min;
	let done$7 = false;
	return suspend$2(() => {
		if (done$7) return done();
		const remaining = max - start + 1;
		if (remaining > chunkSize) {
			const chunk = range$1(start, start + chunkSize - 1);
			start += chunkSize;
			return succeed$3(chunk);
		}
		const chunk = range$1(start, start + remaining - 1);
		done$7 = true;
		return succeed$3(chunk);
	});
}));
/**
* The stream that never produces any value or fails with any error.
*
* @example
* ```ts
* import { Effect, Stream } from "effect"
*
* const program = Stream.never.pipe(
*   Stream.take(0),
*   Stream.runCollect
* )
*
* Effect.runPromise(program).then(console.log)
* // []
* ```
*
* @since 4.0.0
* @category Constructors
*/
var never = /*#__PURE__*/ fromChannel(never$3);
/**
* Creates a stream produced from an `Effect`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const effect = Effect.succeed(Stream.make(1, 2, 3))
*
* const stream = Stream.unwrap(effect)
*
* const program = Effect.gen(function*() {
*   const chunk = yield* Stream.runCollect(stream)
*   yield* Console.log(chunk)
* })
* // [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var unwrap = (effect) => fromChannel(unwrap$2(map$3(effect, toChannel)));
/**
* Runs a stream that requires `Scope` in a managed scope, ensuring its
* finalizers are run when the stream completes.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.scoped(
*   Stream.fromEffect(
*     Effect.acquireRelease(
*       Console.log("acquire").pipe(Effect.as("resource")),
*       () => Console.log("release")
*     )
*   )
* )
*
* Effect.runPromise(Stream.runCollect(stream)).then(console.log)
* // acquire
* // release
* // [ "resource" ]
* ```
*
* @since 2.0.0
* @category Constructors
*/
var scoped = (self) => fromChannel(scoped$2(self.channel));
/**
* Transforms the elements of this stream using the supplied function.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.fromArray([1, 2, 3]).pipe(Stream.map((n, i) => n + i))
* const program = Stream.runCollect(stream).pipe(
*   Effect.tap((values) => Console.log(values))
* )
*
* Effect.runPromise(program)
* // [ 1, 3, 5 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var map = /*#__PURE__*/ dual(2, (self, f) => suspend(() => {
	let i = 0;
	return fromChannel(map$6(self.channel, map$4((o) => f(o, i++))));
}));
/**
* Maps both the failure and success channels of a stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const mapper = {
*   onFailure: (error: string) => `error: ${error}`,
*   onSuccess: (value: number) => value * 2
* }
*
* const program = Effect.gen(function*() {
*   const success = yield* Stream.make(1, 2).pipe(
*     Stream.mapBoth(mapper),
*     Stream.runCollect
*   )
*   yield* Console.log(success)
*
*   const failure = yield* Stream.fail("boom").pipe(
*     Stream.mapBoth(mapper),
*     Stream.catch((error: string) => Stream.succeed(error)),
*     Stream.runCollect
*   )
*   yield* Console.log(failure)
* })
*
* Effect.runPromise(program)
* // Output: [ 2, 4 ]
* // Output: [ "error: boom" ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapBoth = /*#__PURE__*/ dual(2, (self, options) => self.pipe(map(options.onSuccess), mapError(options.onFailure)));
/**
* Transforms each emitted chunk using the provided function, which receives the chunk and its index.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.mapChunks`
*
* @example
* ```ts
* import { Array, Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3, 4).pipe(
*     Stream.rechunk(2),
*     Stream.mapArray((chunk, index) => Array.map(chunk, (n) => n + index)),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 4, 5 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapArray = /*#__PURE__*/ dual(2, (self, f) => fromChannel(map$6(self.channel, f)));
/**
* Maps over elements of the stream with the specified effectful function.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const mappedStream = stream.pipe(
*   Stream.mapEffect((n) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Processing: ${n}`)
*       return n * 2
*     })
*   )
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(mappedStream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output:
* // Processing: 1
* // Processing: 2
* // Processing: 3
* // [2, 4, 6]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, f, options) => self.channel.pipe(flattenArray$1, mapEffect$2(f, options), map$6(of), fromChannel));
/**
* Flattens a stream of `Effect` values into a stream of their results.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(Effect.succeed(1), Effect.succeed(2), Effect.succeed(3))
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream.pipe(Stream.flattenEffect()))
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var flattenEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => mapEffect(self, identity, options));
/**
* Effectfully maps over non-empty array chunks emitted by the stream.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.mapChunksEffect`
*
* @example
* ```ts
* import { Array, Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.fromArray([1, 2, 3, 4]).pipe(
*     Stream.rechunk(2),
*     Stream.mapArrayEffect((chunk, index) =>
*       Effect.succeed(Array.map(chunk, (n) => n + index * 10))
*     ),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [1, 2, 13, 14]
* ```
*
* @since 4.0.0
* @category Mapping
*/
var mapArrayEffect = /*#__PURE__*/ dual(2, (self, f) => fromChannel(mapEffect$2(self.channel, f)));
/**
* Lifts failures and successes into a `Result`, yielding a stream that cannot fail.
*
* The stream ends after the first failure, emitting a `Result.fail` value.
*
* **Previously Known As:**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.either`
*
* @example
* ```ts
* import { Console, Effect, Result, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const results = yield* Stream.make(1, 2).pipe(
*     Stream.concat(Stream.fail("boom")),
*     Stream.result,
*     Stream.map(Result.match({
*       onFailure: (error) => `failure: ${error}`,
*       onSuccess: (value) => `success: ${value}`
*     })),
*     Stream.runCollect
*   )
*   yield* Console.log(results)
* })
*
* Effect.runPromise(program)
* // Output: [ "success: 1", "success: 2", "failure: boom" ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var result = (self) => self.pipe(map(succeed$2), catch_((e) => succeed(fail$2(e))));
/**
* Runs the provided effect for each element while preserving the elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.fromArray([1, 2, 3]).pipe(
*     Stream.tap((n) => Console.log(`before mapping: ${n}`)),
*     Stream.map((n) => n * 2),
*     Stream.tap((n) => Console.log(`after mapping: ${n}`)),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output:
* // before mapping: 1
* // after mapping: 2
* // before mapping: 2
* // after mapping: 4
* // before mapping: 3
* // after mapping: 6
* // [ 2, 4, 6 ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tap = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, f, options) => mapEffect(self, (a) => as$1(f(a), a), options));
/**
* Returns a stream that effectfully "peeks" at elements and failures.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2).pipe(
*     Stream.concat(Stream.fail("boom")),
*     Stream.tapBoth({
*       onElement: (value) => Console.log(`seen: ${value}`),
*       onError: (error) => Console.log(`error: ${error}`)
*     }),
*     Stream.catch(() => Stream.make(3))
*   )
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output:
* // seen: 1
* // seen: 2
* // error: boom
* // [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tapBoth = /*#__PURE__*/ dual(2, (self, options) => self.pipe(tapError(options.onError), tap(options.onElement, { concurrency: options.concurrency })));
/**
* Sends all elements emitted by this stream to the specified sink in addition
* to emitting them.
*
* @example
* ```ts
* import { Console, Effect, Ref, Sink, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const seen = yield* Ref.make<Array<number>>([])
*   const sink = Sink.forEach((value: number) =>
*     Ref.update(seen, (items) => [...items, value])
*   )
*   const result = yield* Stream.make(1, 2, 3).pipe(
*     Stream.tapSink(sink),
*     Stream.runCollect
*   )
*   const tapped = yield* Ref.get(seen)
*   yield* Console.log(tapped)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [1, 2, 3]
* // Output: [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var tapSink = /*#__PURE__*/ dual(2, (self, sink) => transformPullBracket(self, fnUntraced(function* (pull, _, scope) {
	const upstreamLatch = makeUnsafe$5();
	const sinkLatch = makeUnsafe$5();
	let chunk = void 0;
	let causeSink = void 0;
	let sinkDone = false;
	let streamDone = false;
	const sinkUpstream = upstreamLatch.whenOpen(suspend$2(() => {
		if (chunk) {
			const arr = chunk;
			chunk = void 0;
			if (!streamDone) upstreamLatch.closeUnsafe();
			return as$1(sinkLatch.open, arr);
		}
		return done();
	}));
	yield* suspend$2(() => sink.transform(sinkUpstream, scope)).pipe((eff) => onExitPrimitive(eff, (exit) => {
		sinkDone = true;
		if (isFailure$1(exit)) causeSink = exit.cause;
		return sinkLatch.open;
	}, true), forkIn(scope));
	const pullAndOffer = pull.pipe(flatMap$2((chunk_) => {
		chunk = chunk_;
		sinkLatch.closeUnsafe();
		upstreamLatch.openUnsafe();
		return as$1(sinkLatch.await, chunk_);
	}), catchDone(() => {
		streamDone = true;
		sinkLatch.closeUnsafe();
		upstreamLatch.openUnsafe();
		return flatMap$2(sinkLatch.await, () => done());
	}));
	return suspend$2(() => {
		if (causeSink) return failCause$2(causeSink);
		else if (sinkDone) return pull;
		return pullAndOffer;
	});
})));
/**
* Maps each element to a stream and concatenates the results in order.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.flatMap((n) => Stream.make(n, n * 2)),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 2, 4, 3, 6 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var flatMap = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, f, options) => self.channel.pipe(flattenArray$1, flatMap$3((a) => f(a).channel, options), fromChannel));
/**
* Switches to the latest stream produced by the mapping function, interrupting
* the previous stream when a new element arrives.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Stream.make(1, 2, 3).pipe(
*   Stream.switchMap((n) => (n === 3 ? Stream.make(n) : Stream.never)),
*   Stream.runCollect
* )
*
* Effect.gen(function*() {
*   const result = yield* program
*   yield* Console.log(result)
*   // Output: [ 3 ]
* })
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var switchMap = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, f, options) => self.channel.pipe(flattenArray$1, switchMap$1((a) => f(a).channel, options), fromChannel));
/**
* Flattens a stream of streams into a single stream by concatenating the
* inner streams in strict order.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const streamOfStreams = Stream.make(
*   Stream.make(1, 2),
*   Stream.make(3, 4),
*   Stream.make(5, 6)
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(Stream.flatten(streamOfStreams))
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3, 4, 5, 6 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var flatten = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => flatMap(self, identity, options));
/**
* Flattens a stream of non-empty arrays into a stream of elements.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.flattenChunks`
*
* @example
* ```ts
* import { Array, Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(Array.make(1, 2), Array.make(3))
*
* const program = Effect.gen(function* () {
*   const result = yield* Stream.runCollect(Stream.flattenArray(stream))
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var flattenArray = (self) => fromChannel(flattenArray$1(self.channel));
/**
* Converts this stream to one that runs its effects but emits no elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.range(1, 6).pipe(Stream.drain, Stream.runCollect)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: []
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var drain = (self) => fromChannel(drain$2(self.channel));
/**
* Runs the provided stream in the background while this stream runs, interrupting it
* when this stream completes and failing if the background stream fails or defects.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const foreground = Stream.make(1, 2)
* const background = Stream.fromEffect(Console.log("background task"))
*
* const program = Effect.gen(function*() {
*   const values = yield* foreground.pipe(
*     Stream.drainFork(background),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: background task
* // Output: [ 1, 2 ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var drainFork = /*#__PURE__*/ dual(2, (self, that) => mergeEffect(self, runDrain(that)));
/**
* Repeats the entire stream according to the provided schedule.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function* () {
*   const result = yield* Stream.make(1).pipe(
*     Stream.repeat(Schedule.recurs(4)),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 1, 1, 1, 1 ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var repeat = /*#__PURE__*/ dual(2, (self, schedule) => fromChannel(repeat$1(self.channel, schedule)));
/**
* Spaces the stream's elements according to the provided `schedule`.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3).pipe(
*     Stream.schedule(Schedule.spaced("10 millis")),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var schedule = /*#__PURE__*/ dual(2, (self, schedule) => self.channel.pipe(flattenArray$1, schedule$1(schedule), map$6(of), fromChannel));
/**
* Ends the stream if it does not produce a value within the specified duration.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1).pipe(
*     Stream.concat(Stream.never),
*     Stream.timeout("1 second"),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1 ]
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var timeout = /*#__PURE__*/ dual(2, (self, duration) => transformPull(self, (pull, _scope) => succeed$3(timeoutOrElse(pull, {
	duration,
	onTimeout: () => done()
}))));
/**
* Repeats each element of the stream according to the provided schedule,
* including the original emission.
*
* @since 2.0.0
* @category Sequencing
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make("A", "B", "C").pipe(
*     Stream.repeatElements(Schedule.recurs(1)),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ "A", "A", "B", "B", "C", "C" ]
* ```
*/
var repeatElements = /*#__PURE__*/ dual(2, (self, schedule) => fromChannel(fromTransform$1((upstream, scope) => map$3(toTransform(flattenArray$1(self.channel))(upstream, scope), (pullElement) => {
	let pullRepeat = void 0;
	const pull = gen(function* () {
		const element = yield* pullElement;
		const chunk = of(element);
		pullRepeat = (yield* toStepWithSleep(schedule))(element).pipe(as$1(chunk), catchDone((_) => {
			pullRepeat = void 0;
			return pull;
		}));
		return chunk;
	});
	return suspend$2(() => pullRepeat ?? pull);
}))));
/**
* Repeats this stream forever.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make("A", "B").pipe(
*   Stream.forever,
*   Stream.take(5)
* )
*
* const program = Effect.gen(function*() {
*   const output = yield* Stream.runCollect(stream)
*   yield* Console.log(output)
* })
*
* Effect.runPromise(program)
* // Output: [ "A", "B", "A", "B", "A" ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var forever = (self) => fromChannel(forever$4(self.channel));
/**
* Submerges the iterables emitted by this stream into the stream's structure.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.flattenIterables`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make([1, 2], [3, 4]).pipe(Stream.flattenIterable)
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3, 4 ]
* ```
*
* @since 4.0.0
* @category Mapping
*/
var flattenIterable = (self) => flatMap(self, fromIterable);
/**
* Unwraps `Take` values, emitting elements from non-empty arrays and ending or
* failing when the `Exit` signals completion.
*
* @example
* ```ts
* import { Array, Console, Effect, Exit, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const takes = Stream.make(
*     Array.make(1, 2),
*     Array.make(3),
*     Exit.succeed<void>(undefined)
*   )
*
*   const values = yield* Stream.flattenTake(takes).pipe(Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var flattenTake = (self) => self.channel.pipe(flattenArray$1, flattenTake$1, fromChannel);
/**
* Concatenates two streams, emitting all elements from the first stream
* followed by all elements from the second stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.concat(Stream.make(1, 2, 3), Stream.make(4, 5, 6))
*
* Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
* // Output: [ 1, 2, 3, 4, 5, 6 ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var concat = /*#__PURE__*/ dual(2, (self, that) => flatten(fromArray([self, that])));
/**
* Prepends the values from the provided iterable before the stream's elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(3, 4).pipe(
*     Stream.prepend([1, 2]),
*     Stream.runCollect
*   )
*
*   yield* Console.log(values)
*   // Output: [ 1, 2, 3, 4 ]
* })
*
* Effect.runPromise(program)
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var prepend = /*#__PURE__*/ dual(2, (self, values) => concat(fromIterable(values), self));
/**
* Merges two streams, emitting elements from both as they arrive.
*
* By default, the merged stream ends when both streams end. Use
* `haltStrategy` to change the termination behavior.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const fast = Stream.make(1, 2, 3)
* const slow = Stream.fromEffect(Effect.delay(Effect.succeed(4), "50 millis"))
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(Stream.merge(fast, slow))
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3, 4 ]
* ```
*
* @since 2.0.0
* @category Merging
*/
var merge = /*#__PURE__*/ dual(2, (self, that, options) => fromChannel(merge$1(toChannel(self), toChannel(that), options)));
/**
* Merges this stream with a background effect, keeping the stream's elements.
*
* The effect runs concurrently, fails the stream if it fails, and is interrupted
* when the stream completes.
*
* @since 4.0.0
* @category Merging
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.mergeEffect(Console.log("side task")),
*     Stream.runCollect
*   )
*
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: side task
* // Output: [ 1, 2, 3 ]
* ```
*/
var mergeEffect = /*#__PURE__*/ dual(2, (self, effect) => self.channel.pipe(mergeEffect$1(effect), fromChannel));
/**
* Merges this stream and the specified stream together, tagging values from the
* left stream as `Result.succeed` and values from the right stream as `Result.fail`.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.mergeEither`
*
* @example
* ```ts
* import { Console, Effect, Result, Stream } from "effect"
*
* const left = Stream.fromEffect(Effect.succeed("left"))
* const right = Stream.fromEffect(Effect.delay(Effect.succeed("right"), "10 millis"))
*
* const merged = left.pipe(
*   Stream.mergeResult(right),
*   Stream.map(
*     Result.match({
*       onFailure: (value) => `right:${value}`,
*       onSuccess: (value) => `left:${value}`
*     })
*   )
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(merged)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ "left:left", "right:right" ]
* ```
*
* @since 2.0.0
* @category Merging
*/
var mergeResult = /*#__PURE__*/ dual(2, (self, that) => merge(map(self, succeed$2), map(that, fail$2)));
/**
* Merges two streams while emitting only the values from the left stream.
*
* The right stream still runs for its effects, and any failures from the right
* stream are propagated. The merged stream completes when the left stream
* completes, interrupting the right stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const left = Stream.make(1, 2)
*   const right = Stream.make("a", "b")
*   const values = yield* left.pipe(Stream.mergeLeft(right), Stream.runCollect)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 2.0.0
* @category Merging
*/
var mergeLeft = /*#__PURE__*/ dual(2, (left, right) => mergeEffect(left, runDrain(right)));
/**
* Merges this stream and the specified stream together, emitting only the
* values from the right stream while the left stream runs for its effects.
*
* The merged stream ends when the right stream completes, interrupting the
* left stream. Failures from the left stream still fail the merged stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const left = Stream.make("left-1", "left-2").pipe(
*   Stream.tap(() => Effect.sync(() => undefined))
* )
* const right = Stream.make(1, 2)
*
* const merged = Stream.mergeRight(left, right)
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(merged)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 2.0.0
* @category Merging
*/
var mergeRight = /*#__PURE__*/ dual(2, (left, right) => mergeEffect(right, runDrain(left)));
/**
* Merges a collection of streams, running up to the specified number concurrently.
*
* @since 2.0.0
* @category Merging
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const streams = [
*   Stream.fromEffect(Effect.delay(Effect.succeed("A"), "20 millis")),
*   Stream.fromEffect(Effect.delay(Effect.succeed("B"), "10 millis"))
* ]
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.mergeAll(streams, { concurrency: 2 }).pipe(
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ "B", "A" ]
* ```
*/
var mergeAll = /*#__PURE__*/ dual(2, (streams, options) => flatten(fromIterable(streams), options));
/**
* Creates the cartesian product of two streams, running the `right` stream for
* each element in the `left` stream.
*
* See also `Stream.zip` for the more common point-wise variant.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const left = Stream.make(1, 2)
*   const right = Stream.make("a", "b")
*   const values = yield* Stream.runCollect(Stream.cross(left, right))
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, "a" ], [ 1, "b" ], [ 2, "a" ], [ 2, "b" ] ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var cross = /*#__PURE__*/ dual(2, (left, right) => crossWith(left, right, (l, r) => [l, r]));
/**
* Creates a cartesian product of elements from two streams using a function.
*
* The `right` stream is rerun for every element in the `left` stream.
*
* See also `Stream.zipWith` for the more common point-wise variant.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const left = Stream.make(1, 2)
*   const right = Stream.make("a", "b")
*   const combined = Stream.crossWith(left, right, (n, s) => `${n}-${s}`)
*   const result = yield* Stream.runCollect(combined)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ "1-a", "1-b", "2-a", "2-b" ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var crossWith = /*#__PURE__*/ dual(3, (left, right, f) => flatMap(left, (l) => map(right, (r) => f(l, r))));
/**
* Zips two streams point-wise with a combining function, ending when either stream ends.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream1 = Stream.make(1, 2, 3, 4, 5, 6)
* const stream2 = Stream.make("a", "b", "c")
*
* const zipped = Stream.zipWith(stream1, stream2, (n, s) => `${n}-${s}`)
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(zipped)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ "1-a", "2-b", "3-c" ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWith = /*#__PURE__*/ dual(3, (left, right, f) => zipWithArray(left, right, zipArrays(f)));
var zipArrays = (f) => (leftArr, rightArr) => {
	const minLength = Math.min(leftArr.length, rightArr.length);
	const result = [];
	for (let i = 0; i < minLength; i++) result.push(f(leftArr[i], rightArr[i]));
	return [
		result,
		leftArr.slice(minLength),
		rightArr.slice(minLength)
	];
};
/**
* Zips two streams by applying a function to non-empty arrays of elements.
*
* The function returns output plus leftover arrays that carry into the next pull.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.zipWithChunks`
*
* @example
* ```ts
* import { Array, Console, Effect, Stream } from "effect"
*
* const left = Stream.fromArrays([1, 2, 3], [4, 5])
* const right = Stream.fromArrays(["a", "b"], ["c", "d", "e"])
*
* const zipped = Stream.zipWithArray(left, right, (leftChunk, rightChunk) => {
*   const minLength = Math.min(leftChunk.length, rightChunk.length)
*   const output = Array.makeBy(minLength, (i) => [leftChunk[i], rightChunk[i]] as const)
*
*   return [output, leftChunk.slice(minLength), rightChunk.slice(minLength)]
* })
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(zipped)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [[1, "a"], [2, "b"], [3, "c"], [4, "d"], [5, "e"]]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWithArray = /*#__PURE__*/ dual(3, (left, right, f) => fromChannel(fromTransformBracket(fnUntraced(function* (_, scope) {
	const pullLeft = yield* toPullScoped(left.channel, scope);
	const pullRight = yield* toPullScoped(right.channel, scope);
	const pullBoth = gen(function* () {
		return yield* joinAll([yield* forkIn(pullLeft, scope), yield* forkIn(pullRight, scope)]);
	});
	let state = { _tag: "PullBoth" };
	return gen(function* () {
		const [left, right] = state._tag === "PullBoth" ? yield* pullBoth : state._tag === "PullLeft" ? [yield* pullLeft, state.rightArray] : [state.leftArray, yield* pullRight];
		const result = f(left, right);
		if (isReadonlyArrayNonEmpty(result[1])) state = {
			_tag: "PullRight",
			leftArray: result[1]
		};
		else if (isReadonlyArrayNonEmpty(result[2])) state = {
			_tag: "PullLeft",
			rightArray: result[2]
		};
		else state = { _tag: "PullBoth" };
		return result[0];
	});
}))));
/**
* Zips this stream with another point-wise and emits tuples of elements from
* both streams. The new stream ends when either stream ends.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream1 = Stream.make(1, 2, 3)
* const stream2 = Stream.make("a", "b", "c")
*
* const zipped = Stream.zip(stream1, stream2)
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(zipped)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [[1, "a"], [2, "b"], [3, "c"]]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zip = /*#__PURE__*/ dual(2, (self, that) => zipWith(self, that, (a, a2) => [a, a2]));
/**
* Zips this stream with another point-wise and keeps only the values from
* the left stream.
*
* The resulting stream ends when either side ends.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream1 = Stream.make(1, 2, 3, 4)
* const stream2 = Stream.make("a", "b")
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.zipLeft(stream1, stream2).pipe(Stream.runCollect)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [1, 2]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipLeft = /*#__PURE__*/ dual(2, (left, right) => zipWithArray(left, right, (leftArr, rightArr) => {
	const minLength = Math.min(leftArr.length, rightArr.length);
	return [
		leftArr.slice(0, minLength),
		leftArr.slice(minLength),
		rightArr.slice(minLength)
	];
}));
/**
* Zips this stream with another point-wise, keeping only right values and ending when either stream ends.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream1 = Stream.make(1, 2)
* const stream2 = Stream.make("a", "b", "c", "d")
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.zipRight(stream1, stream2).pipe(Stream.runCollect)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: ["a", "b"]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipRight = /*#__PURE__*/ dual(2, (left, right) => zipWithArray(left, right, (leftArr, rightArr) => {
	const minLength = Math.min(leftArr.length, rightArr.length);
	return [
		rightArr.slice(0, minLength),
		leftArr.slice(minLength),
		rightArr.slice(minLength)
	];
}));
/**
* Zips this stream with another point-wise and emits tuples of elements from
* both streams, flattening the left tuple.
*
* The new stream will end when one of the sides ends.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream1 = Stream.make(
*     [1, "a"] as const,
*     [2, "b"] as const,
*     [3, "c"] as const
*   )
*   const stream2 = Stream.make("x", "y", "z")
*   const result = yield* Stream.zipFlatten(stream1, stream2).pipe(Stream.runCollect)
*
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [[1, "a", "x"], [2, "b", "y"], [3, "c", "z"]]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipFlatten = /*#__PURE__*/ dual(2, (self, that) => zipWith(self, that, (a, a2) => [...a, a2]));
/**
* Zips this stream together with the index of elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const indexed = yield* Stream.make("a", "b", "c", "d").pipe(
*     Stream.zipWithIndex,
*     Stream.runCollect
*   )
*   yield* Console.log(indexed)
* })
*
* Effect.runPromise(program)
* // Output: [["a", 0], ["b", 1], ["c", 2], ["d", 3]]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWithIndex = (self) => map(self, (a, i) => [a, i]);
/**
* Zips each element with the next element, pairing the final element with
* `Option.none()`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.zipWithNext(Stream.make(1, 2, 3, 4))
*
* Effect.runPromise(Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* }))
* // Output: [
* //   [ 1, { _id: 'Option', _tag: 'Some', value: 2 } ],
* //   [ 2, { _id: 'Option', _tag: 'Some', value: 3 } ],
* //   [ 3, { _id: 'Option', _tag: 'Some', value: 4 } ],
* //   [ 4, { _id: 'Option', _tag: 'None' } ]
* // ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWithNext = (self) => mapAccumArray(self, none, (acc, arr) => {
	let i = 0;
	if (acc._tag === "None") {
		i = 1;
		acc = some$1(arr[0]);
	}
	const pairs = empty$1();
	for (; i < arr.length; i++) {
		const value = acc.value;
		acc = some$1(arr[i]);
		pairs.push([value, acc]);
	}
	return [acc, pairs];
}, { onHalt(state) {
	return state._tag === "Some" ? [[state.value, none()]] : [];
} });
/**
* Zips each element with its previous element, starting with `None`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.zipWithPrevious(Stream.make(1, 2, 3, 4))
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [
* //   [ { _id: 'Option', _tag: 'None' }, 1 ],
* //   [ { _id: 'Option', _tag: 'Some', value: 1 }, 2 ],
* //   [ { _id: 'Option', _tag: 'Some', value: 2 }, 3 ],
* //   [ { _id: 'Option', _tag: 'Some', value: 3 }, 4 ]
* // ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWithPrevious = (self) => mapAccumArray(self, none, (acc, arr) => {
	const pairs = empty$1();
	for (let i = 0; i < arr.length; i++) {
		const value = arr[i];
		pairs.push([acc, value]);
		acc = some$1(arr[i]);
	}
	return [acc, pairs];
});
/**
* Zips each element with its previous and next values.
*
* @example
* ```ts
* import { Console, Effect, Option, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.zipWithPreviousAndNext,
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ [Option.none(), 1, Option.some(2)], [Option.some(1), 2, Option.some(3)], [Option.some(2), 3, Option.none()] ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipWithPreviousAndNext = (self) => mapAccumArray(self, () => ({
	prev: none(),
	current: none()
}), (acc, arr) => {
	let i = 0;
	let current;
	if (acc.current._tag === "None") {
		i = 1;
		current = arr[0];
		acc.current = some$1(current);
	} else current = acc.current.value;
	const pairs = empty$1();
	for (; i < arr.length; i++) {
		const element = arr[i];
		acc.current = some$1(element);
		pairs.push([
			acc.prev,
			current,
			acc.current
		]);
		acc.prev = some$1(current);
		current = element;
	}
	return [acc, pairs];
}, { onHalt(acc) {
	return acc.current._tag === "Some" ? [[
		acc.prev,
		acc.current.value,
		none()
	]] : [];
} });
/**
* Zips multiple streams so that when a value is emitted by any stream, it is
* combined with the latest values from the other streams to produce a result.
*
* Note: tracking the latest value is done on a per-array basis. That means
* that emitted elements that are not the last value in arrays will never be
* used for zipping.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.zipLatestAll(
*   Stream.make(1, 2, 3).pipe(Stream.rechunk(1)),
*   Stream.make("a", "b", "c").pipe(Stream.rechunk(1)),
*   Stream.make(true, false, true).pipe(Stream.rechunk(1))
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, "a", true ], [ 2, "a", true ], [ 3, "a", true ], [ 3, "b", true ], [ 3, "c", true ], [ 3, "c", false ], [ 3, "c", true ] ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipLatestAll = (...streams) => fromChannel(suspend$3(() => {
	const latest = [];
	const emitted = /* @__PURE__ */ new Set();
	const readyLatch = makeUnsafe$5();
	return mergeAll$1(fromArray$1(streams.map((s, i) => s.channel.pipe(flattenArray$1, mapEffect$2((a) => {
		latest[i] = a;
		if (!emitted.has(i)) {
			emitted.add(i);
			if (emitted.size < streams.length) return readyLatch.await;
			return as$1(readyLatch.open, of(latest.slice()));
		}
		return succeed$3(of(latest.slice()));
	}), filter$2(isNotUndefined)))), {
		concurrency: "unbounded",
		bufferSize: 0
	});
}));
/**
* Combines two streams by emitting each new element with the latest value from the other stream.
*
* Note: tracking the latest value is done on a per-array basis. That means
* that emitted elements that are not the last value in arrays will never be
* used for zipping.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.zipLatest(
*     Stream.make(1),
*     Stream.make("a")
*   ).pipe(Stream.runCollect)
*
*   yield* Console.log(result)
* })
* // Output: [ [1, "a"] ]
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipLatest = /*#__PURE__*/ dual(2, (left, right) => zipLatestAll(left, right));
/**
* Combines the latest values from both streams whenever either emits, using
* the provided function.
*
* Note: tracking the latest value is done on a per-array basis. That means
* that emitted elements that are not the last value in arrays will never be
* used for zipping.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3).pipe(
*     Stream.rechunk(1),
*     Stream.zipLatestWith(
*       Stream.make(10, 20).pipe(Stream.rechunk(1)),
*       (n, m) => n + m
*     ),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
*   // Output: [ 11, 12, 22, 23 ]
* })
* ```
*
* @since 2.0.0
* @category Zipping
*/
var zipLatestWith = /*#__PURE__*/ dual(3, (left, right, f) => map(zipLatestAll(left, right), ([a, a2]) => f(a, a2)));
/**
* Races multiple streams and emits values from the first stream to produce a value, interrupting the rest.
*
* @since 3.7.0
* @category Racing
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.raceAll(
*     Stream.fromSchedule(Schedule.spaced("1 second")),
*     Stream.make(0, 1, 2)
*   ).pipe(Stream.runCollect)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 0, 1, 2 ]
* ```
*/
var raceAll = (...streams) => fromChannel(fromTransform$1((_, scope) => sync$2(() => {
	let winner;
	const race = raceAll$1(streams.map((stream) => {
		const childScope = forkUnsafe(scope);
		return toPullScoped(stream.channel, childScope).pipe(flatMap$2((pull) => zip$1(succeed$3(pull), pull)), onExit$2((exit) => {
			if (exit._tag === "Success") {
				if (winner) return close(childScope, exit);
				winner = exit.value[0];
				return void_;
			}
			return close(childScope, exit);
		}), map$3(([, chunk]) => chunk));
	}));
	return suspend$2(() => winner ?? race);
})));
/**
* Returns a stream that mirrors the first upstream to emit an item.
* As soon as one stream emits, the other is interrupted and failures propagate.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const stream = Stream.race(
*   Stream.make(0, 1, 2),
*   Stream.fromSchedule(Schedule.spaced("1 second"))
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 0, 1, 2 ]
* ```
*
* @since 3.7.0
* @category Racing
*/
var race = /*#__PURE__*/ dual(2, (left, right) => raceAll(left, right));
/**
* Filters a stream to the elements that satisfy a predicate.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3, 4).pipe(
*     Stream.filter((n) => n % 2 === 0)
*   )
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 2, 4 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var filter = /*#__PURE__*/ dual(2, (self, predicate) => fromChannel(filterArray(toChannel(self), predicate)));
/**
* Filters and maps stream elements in one pass using a `Filter`.
*
* @since 4.0.0
* @category Filtering
*/
var filterMap = /*#__PURE__*/ dual(2, (self, filter) => fromChannel(filterMapArray(toChannel(self), filter)));
/**
* Effectfully filters elements in a single pass.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4).pipe(Stream.filterEffect((n) => Effect.succeed(n > 2)))
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 3, 4 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var filterEffect = /*#__PURE__*/ dual(2, (self, predicate) => fromChannel(filterArrayEffect(toChannel(self), predicate)));
/**
* Effectfully filters and maps elements in a single pass.
*
* @since 4.0.0
* @category Filtering
*/
var filterMapEffect = /*#__PURE__*/ dual(2, (self, filter) => fromChannel(filterMapArrayEffect(toChannel(self), filter)));
/**
* Partitions a stream using a `Filter` and exposes passing and failing values as queues.
*
* Each queue fails with the stream error or `Cause.Done` when the source ends.
*
* @example
* ```ts
* import { Console, Effect, Result, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const [passes, fails] = yield* Stream.make(1, 2, 3, 4).pipe(
*     Stream.partitionQueue((n) => n % 2 === 0 ? Result.succeed(n) : Result.fail(n))
*   )
*
*   const passValues = yield* Stream.fromQueue(passes).pipe(Stream.runCollect)
*   const failValues = yield* Stream.fromQueue(fails).pipe(Stream.runCollect)
*
*   yield* Console.log(passValues)
*   // Output: [ 2, 4 ]
*   yield* Console.log(failValues)
*   // Output: [ 1, 3 ]
* })
*
* Effect.runPromise(Effect.scoped(program))
* ```
*
* @since 4.0.0
* @category Filtering
*/
var partitionQueue = /*#__PURE__*/ dual((args) => isStream(args[0]), /*#__PURE__*/ fnUntraced(function* (self, filter, options) {
	const scope$1 = yield* scope;
	const pull = yield* toPullScoped(self.channel, scope$1);
	const capacity = options?.capacity === "unbounded" ? void 0 : options?.capacity ?? DefaultChunkSize;
	const passes = yield* make$5({ capacity });
	const fails = yield* make$5({ capacity });
	yield* gen(function* () {
		while (true) {
			const chunk = yield* pull;
			const excluded = [];
			const satisfying = [];
			for (let i = 0; i < chunk.length; i++) {
				const result = filter(chunk[i]);
				if (isFailure(result)) excluded.push(result.failure);
				else satisfying.push(result.success);
			}
			let passFiber = void 0;
			if (satisfying.length > 0) {
				const leftover = offerAllUnsafe(passes, satisfying);
				if (leftover.length > 0) passFiber = yield* forkChild(offerAll(passes, leftover));
			}
			if (excluded.length > 0) {
				const leftover = offerAllUnsafe(fails, excluded);
				if (leftover.length > 0) yield* offerAll(fails, leftover);
			}
			if (passFiber) yield* join(passFiber);
		}
	}).pipe(onError$1((cause) => {
		failCauseUnsafe(passes, cause);
		failCauseUnsafe(fails, cause);
		return void_;
	}), forkIn(scope$1));
	return [passes, fails];
}));
/**
* Splits a stream using an effectful `Filter`, producing pass and fail streams.
*
* @since 4.0.0
* @category Filtering
*/
var partitionEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, filter, options) => map$3(partitionQueue(mapEffect(self, (a) => filter(a), options), (result) => result, options), ([passes, fails]) => [fromQueue(passes), fromQueue(fails)]));
/**
* Splits a stream into excluded and satisfying substreams using a `Filter`.
*
* The faster stream may advance up to `bufferSize` elements ahead of the slower
* one.
*
* @since 4.0.0
* @category Filtering
*
* @example
* ```ts
* import { Console, Effect, Result, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const [excluded, satisfying] = yield* Stream.partition(
*     Stream.make(1, 2, 3, 4),
*     (n) => n % 2 === 0 ? Result.succeed(n) : Result.fail(n)
*   )
*   const left = yield* Stream.runCollect(excluded)
*   const right = yield* Stream.runCollect(satisfying)
*   yield* Console.log(left)
*   // Output: [ 1, 3 ]
*   yield* Console.log(right)
*   // Output: [ 2, 4 ]
* })
* ```
*/
var partition = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, filter, options) => map$3(partitionQueue(self, filter, { capacity: options?.bufferSize ?? 16 }), ([passes, fails]) => [fromQueue(fails), fromQueue(passes)]));
/**
* Returns the specified stream if the given condition is satisfied, otherwise
* returns an empty stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(
*     Stream.when(Stream.make(1, 2, 3), Effect.succeed(false))
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: []
* ```
*
* @since 2.0.0
* @category Filtering
*/
var when = /*#__PURE__*/ dual(2, (self, test) => test.pipe(map$3((pass) => pass ? self : empty), unwrap));
/**
* Runs a sink to peel off enough elements to produce a value and returns that
* value with the remaining stream in a scope.
*
* The returned stream is only valid within the scope.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* const stream = Stream.fromArrays([1, 2, 3], [4, 5, 6])
* const sink = Sink.take<number>(3)
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const [peeled, rest] = yield* Stream.peel(stream, sink)
*     const remaining = yield* Stream.runCollect(rest)
*     yield* Console.log([peeled, remaining])
*   })
* )
*
* Effect.runPromise(program)
* // Output: [ [1, 2, 3], [4, 5, 6] ]
* ```
*
* @since 2.0.0
* @category Destructors
*/
var peel = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, sink) {
	let cause = void 0;
	const originalPull = yield* toPull$1(self.channel);
	let stream = fromPull(succeed$3(catchCause$2(originalPull, (cause_) => {
		cause = cause_;
		return failCause$2(cause_);
	})));
	const leftover = yield* run(stream, sink);
	if (cause) return [leftover, empty];
	stream = fromPull(succeed$3(originalPull));
	return [leftover, stream];
}));
/**
* Buffers up to `capacity` elements so a faster producer can progress
* independently of a slower consumer.
*
* Note: This combinator destroys chunking. Use `Stream.rechunk` afterwards if
* you need fixed chunk sizes.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.buffer({ capacity: 1 }),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var buffer = /*#__PURE__*/ dual(2, (self, options) => fromChannel(bufferArray$1(self.channel, options)));
/**
* Allows a faster producer to progress independently of a slower consumer by
* buffering up to `capacity` chunks in a queue.
*
* This combinator preserves chunking and is best with power-of-2 capacities.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.bufferChunks`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.fromArrays([1, 2], [3, 4]).pipe(
*     Stream.bufferArray({ capacity: 2 }),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* // Output: [ 1, 2, 3, 4 ]
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var bufferArray = /*#__PURE__*/ dual(2, (self, options) => fromChannel(buffer$1(self.channel, options)));
/**
* Switches over to the stream produced by the provided function in case this
* one fails. Allows recovery from all causes of failure, including
* interruption if the stream is uninterruptible.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.catchAllCause`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2).pipe(
*   Stream.concat(Stream.fail("Oops!")),
*   Stream.concat(Stream.make(3, 4))
* )
*
* const recovered = stream.pipe(
*   Stream.catchCause(() => Stream.make(999))
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(recovered)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 999 ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchCause = /*#__PURE__*/ dual(2, (self, f) => self.channel.pipe(catchCause$3((cause) => f(cause).channel), fromChannel));
/**
* Runs an effect when the stream fails without changing its values or error,
* unless the tap effect itself fails.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.tapErrorCause`
*
* @example
* ```ts
* import { Cause, Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2).pipe(
*   Stream.concat(Stream.fail("boom")),
*   Stream.tapCause((cause) => Console.log(Cause.isReason(cause))),
*   Stream.catch(() => Stream.succeed(0))
* )
*
* const program = Effect.gen(function* () {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: true
* // Output: [ 1, 2, 0 ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var tapCause = /*#__PURE__*/ dual(2, (self, f) => self.channel.pipe(tapCause$1(f), fromChannel));
var catch_ = /*#__PURE__*/ dual(2, (self, f) => fromChannel(catch_$3(self.channel, (error) => f(error).channel)));
/**
* Effectfully peeks at errors without changing the stream unless the tap fails.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2).pipe(
*   Stream.concat(Stream.fail("boom")),
*   Stream.tapError((error) => Console.log(`tapError: ${error}`)),
*   Stream.catch(() => Stream.make(999))
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output:
* // tapError: boom
* // [ 1, 2, 999 ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var tapError = /*#__PURE__*/ dual(2, (self, f) => self.channel.pipe(tapError$1(f), fromChannel));
/**
* Recovers from errors that match a predicate by switching to a recovery stream.
*
* When a failure matches the filter, the stream switches to the recovery
* stream. Non-matching failures propagate downstream, so the error type is
* preserved unless the filter narrows it.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.catchSome`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2).pipe(
*   Stream.concat(Stream.fail(42)),
*   Stream.catchIf(
*     (error): error is 42 => error === 42,
*     () => Stream.make(999)
*   )
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
*   // Output: [ 1, 2, 999 ]
* })
*
* Effect.runPromise(program)
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchIf = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, predicate, f, orElse) => fromChannel(catchIf$1(toChannel(self), predicate, (e) => f(e).channel, orElse && ((e) => orElse(e).channel))));
/**
* Recovers from errors that match a `Filter` by switching to a recovery
* stream.
*
* @since 4.0.0
* @category Error Handling
*/
var catchFilter = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, filter, f, orElse) => fromChannel(catchFilter$1(toChannel(self), filter, (e) => f(e).channel, orElse && ((e) => orElse(e).channel))));
/**
* Recovers from failures whose `_tag` matches the provided value by switching to
* the stream returned by `f`.
*
* **When to Use**
*
* Use `catchTag` when your error type is a tagged union with a readonly `_tag`
* field and you want to handle a specific error case.
*
* @example
* ```ts
* import { Console, Data, Effect, Stream } from "effect"
*
* class HttpError extends Data.TaggedError("HttpError")<{ message: string }> {}
*
* const stream = Stream.fail(new HttpError({ message: "timeout" }))
*
* const recovered = Stream.catchTag(stream, "HttpError", (error) =>
*   Stream.make(`Recovered: ${error.message}`)
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(recovered)
*   yield* Console.log(values)
*   // Output: [ "Recovered: timeout" ]
* })
*
* Effect.runPromise(program)
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchTag = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, k, f, orElse) => {
	return catchIf(self, Array.isArray(k) ? (e) => hasProperty(e, "_tag") && k.includes(e._tag) : isTagged(k), f, orElse);
});
/**
* Switches to a recovery stream based on matching `_tag` handlers.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* class NotFound {
*   readonly _tag = "NotFound"
*   constructor(readonly resource: string) {}
* }
*
* class Unauthorized {
*   readonly _tag = "Unauthorized"
*   constructor(readonly user: string) {}
* }
*
* const stream = Stream.fail(new NotFound("profile"))
*
* const program = Effect.gen(function* () {
*   const result = yield* stream.pipe(
*     Stream.catchTags({
*       NotFound: () => Stream.succeed("fallback"),
*       Unauthorized: () => Stream.succeed("login")
*     }),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* // Output: [ "fallback" ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchTags = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, cases, orElse) => {
	let keys;
	return catchFilter(self, (e) => {
		keys ??= Object.keys(cases);
		return hasProperty(e, "_tag") && isString(e["_tag"]) && keys.includes(e["_tag"]) ? succeed$2(e) : fail$2(e);
	}, (e) => cases[e["_tag"]](e), orElse);
});
/**
* Catches a specific reason within a tagged error.
*
* Use this to handle nested error causes without removing the parent error
* from the error channel. The handler receives the unwrapped reason.
*
* @example
* ```ts
* import { Console, Data, Effect, Stream } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* const stream = Stream.fail(
*   new AiError({ reason: new RateLimitError({ retryAfter: 60 }) })
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* stream.pipe(
*     Stream.catchReason("AiError", "RateLimitError", (reason) =>
*       Stream.succeed(`retry: ${reason.retryAfter}`)
*     ),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ "retry: 60" ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchReason = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, errorTag, reasonTag, f, orElse) => fromChannel(catchReason$1(toChannel(self), errorTag, reasonTag, (reason, error) => f(reason, error).channel, orElse && ((reason, error) => orElse(reason, error).channel))));
/**
* Catches multiple reasons within a tagged error using an object of handlers.
*
* @example
* ```ts
* import { Console, Data, Effect, Stream } from "effect"
*
* class RateLimitError extends Data.TaggedError("RateLimitError")<{
*   retryAfter: number
* }> {}
*
* class QuotaExceededError extends Data.TaggedError("QuotaExceededError")<{
*   limit: number
* }> {}
*
* class AiError extends Data.TaggedError("AiError")<{
*   reason: RateLimitError | QuotaExceededError
* }> {}
*
* const stream = Stream.fail(
*   new AiError({ reason: new RateLimitError({ retryAfter: 60 }) })
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* stream.pipe(
*     Stream.catchReasons("AiError", {
*       RateLimitError: (reason) => Stream.succeed(`retry: ${reason.retryAfter}`),
*       QuotaExceededError: (reason) => Stream.succeed(`quota: ${reason.limit}`)
*     }),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ "retry: 60" ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchReasons = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, errorTag, cases, orElse) => {
	const handlers = {};
	for (const key of Object.keys(cases)) {
		const handler = cases[key];
		handlers[key] = (reason, error) => handler(reason, error).channel;
	}
	const orElseHandler = orElse && ((reason, error) => orElse(reason, error).channel);
	return fromChannel(catchReasons$1(self.channel, errorTag, handlers, orElseHandler));
});
/**
* Transforms the errors emitted by this stream using `f`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.fail("bad").pipe(
*     Stream.mapError((error) => `mapped: ${error}`),
*     Stream.catch((error) => Stream.make(`recovered from ${error}`)),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ "recovered from mapped: bad" ]
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var mapError = /*#__PURE__*/ dual(2, (self, f) => fromChannel(mapError$3(self.channel, f)));
/**
* Recovers from stream failures by filtering the `Cause` and switching to a recovery stream.
* Non-matching causes are re-emitted as failures.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.catchSomeCause`
*
* @example
* ```ts
* import { Cause, Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const failingStream = Stream.fail("NetworkError")
*   const recovered = Stream.catchCauseIf(
*     failingStream,
*     (cause) => Cause.hasFails(cause),
*     (cause) => Stream.make(`Recovered: ${Cause.squash(cause)}`)
*   )
*
*   const output = yield* Stream.runCollect(recovered)
*   yield* Console.log(output)
* })
*
* Effect.runPromise(program)
* // Output: [ "Recovered: NetworkError" ]
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var catchCauseIf = /*#__PURE__*/ dual(3, (self, predicate, f) => fromChannel(catchCauseIf$1(self.channel, predicate, (cause) => f(cause).channel)));
/**
* Recovers from stream failures by filtering the `Cause` and switching to a
* recovery stream.
*
* @since 4.0.0
* @category Error Handling
*/
var catchCauseFilter = /*#__PURE__*/ dual(3, (self, filter, f) => fromChannel(catchCauseFilter$1(self.channel, filter, (failure, cause) => f(failure, cause).channel)));
/**
* Switches to a fallback stream if this stream is empty.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.empty.pipe(
*     Stream.orElseIfEmpty(() => Stream.make(1, 2)),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var orElseIfEmpty = /*#__PURE__*/ dual(2, (self, orElse) => fromChannel(orElseIfEmpty$1(self.channel, (_) => toChannel(orElse()))));
/**
* Returns a stream that emits a fallback value when this stream fails.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fail("NetworkError").pipe(
*     Stream.orElseSucceed((error) => `Recovered: ${error}`)
*   )
*
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ "Recovered: NetworkError" ]
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var orElseSucceed = /*#__PURE__*/ dual(2, (self, f) => catch_(self, (e) => succeed(f(e))));
/**
* Turns typed failures into defects, making the stream infallible.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.orDie,
*     Stream.runCollect
*   )
*
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var orDie = (self) => fromChannel(orDie$1(self.channel));
/**
* Ignores failures and ends the stream on error.
*
* Use the `log` option to emit the full {@link Cause} when the stream fails.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.concat(Stream.fail("boom")),
*     Stream.ignore,
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @example
* ```ts
* import { Stream } from "effect"
*
* const stream = Stream.fail("boom")
*
* const program = stream.pipe(Stream.ignore({ log: "Error" }))
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var ignore = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => fromChannel(ignore$1(self.channel, options)));
/**
* Ignores the stream's failure cause, including defects, and ends the stream.
*
* Use the `log` option to emit the full {@link Cause} when the stream fails.
*
* @example
* ```ts
* import { Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2).pipe(
*   Stream.concat(Stream.fail("boom")),
*   Stream.ignoreCause({ log: "Error" })
* )
*
* const program = Stream.runCollect(stream)
* ```
*
* @since 4.0.0
* @category Error Handling
*/
var ignoreCause = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => fromChannel(ignoreCause$1(self.channel, options)));
/**
* When the stream fails, retry it according to the given schedule.
*
* This retries the entire stream, so will re-execute all of the stream's
* acquire operations.
*
* The schedule is reset as soon as the first element passes through the
* stream again.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1).pipe(
*     Stream.concat(Stream.fail("boom")),
*     Stream.retry(Schedule.recurs(1)),
*     Stream.take(2),
*     Stream.runCollect
*   )
*
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 1 ]
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var retry = /*#__PURE__*/ dual(2, (self, policy) => fromChannel(retry$1(self.channel, policy)));
/**
* Apply an `ExecutionPlan` to a stream, retrying with step-provided resources
* until it succeeds or the plan is exhausted.
*
* By default, a failing step can fallback even after emitting elements; set
* `preventFallbackOnPartialStream` to fail instead of mixing partial output with
* a later fallback.
*
* @example
* ```ts
* import { Console, Effect, ExecutionPlan, Layer, ServiceMap, Stream } from "effect"
*
* class Service extends ServiceMap.Service<Service>()("Service", {
*   make: Effect.succeed({
*     stream: Stream.fail("A") as Stream.Stream<number, string>
*   })
* }) {
*   static Bad = Layer.succeed(Service, Service.of({ stream: Stream.fail("A") }))
*   static Good = Layer.succeed(Service, Service.of({ stream: Stream.make(1, 2, 3) }))
* }
*
* const plan = ExecutionPlan.make(
*   { provide: Service.Bad },
*   { provide: Service.Good }
* )
*
* const stream = Stream.unwrap(Effect.map(Service.asEffect(), (_) => _.stream))
*
* const program = Effect.gen(function*() {
*   const items = yield* stream.pipe(Stream.withExecutionPlan(plan), Stream.runCollect)
*   yield* Console.log(items)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 3.16.0
* @category Error Handling
* @experimental
*/
var withExecutionPlan = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, policy, options) => suspend(() => {
	const preventFallbackOnPartialStream = options?.preventFallbackOnPartialStream ?? false;
	let i = 0;
	let meta = {
		attempt: 0,
		stepIndex: 0
	};
	const provideMeta = provideServiceEffect(CurrentMetadata$1, sync$2(() => {
		meta = {
			attempt: meta.attempt + 1,
			stepIndex: i
		};
		return meta;
	}));
	let lastError = none();
	const loop = suspend(() => {
		const step = policy.steps[i];
		if (!step) return fail(getOrThrow(lastError));
		let nextStream = provideMeta(provide(self, step.provide));
		let receivedElements = false;
		if (isSome(lastError)) {
			const error = lastError.value;
			let attempted = false;
			const wrapped = nextStream;
			nextStream = suspend(() => {
				if (attempted) return wrapped;
				attempted = true;
				return fail(error);
			});
			nextStream = retry(nextStream, scheduleFromStep(step, false));
		} else {
			const schedule = scheduleFromStep(step, true);
			nextStream = schedule ? retry(nextStream, schedule) : nextStream;
		}
		return catch_(preventFallbackOnPartialStream ? onFirst(nextStream, (_) => {
			receivedElements = true;
			return void_;
		}) : nextStream, (error) => {
			i++;
			if (preventFallbackOnPartialStream && receivedElements) return fail(error);
			lastError = some$1(error);
			return loop;
		});
	});
	return loop;
}));
/**
* Takes the first `n` elements from this stream, returning `Stream.empty` when `n < 1`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.take(3),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var take = /*#__PURE__*/ dual(2, (self, n) => n < 1 ? empty : takeUntil(self, (_, i) => i === n - 1));
/**
* Keeps the last `n` elements from this stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.range(1, 6).pipe(
*     Stream.takeRight(3),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 4, 5, 6 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var takeRight = /*#__PURE__*/ dual(2, (self, n) => mapAccumArray(self, make$6, (list, arr) => {
	appendAll$1(list, arr);
	if (list.length > n) takeNVoid(list, list.length - n);
	return [list, emptyArr];
}, { onHalt(list) {
	return takeAll(list);
} }));
/**
* Takes elements until the predicate matches.
*
* When `excludeLast` is `true`, the matching element is dropped.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.range(1, 5)
*
* const program = Effect.gen(function*() {
*   const inclusive = yield* stream.pipe(
*     Stream.takeUntil((n) => n % 3 === 0),
*     Stream.runCollect
*   )
*   yield* Console.log(inclusive)
*   // Output: [ 1, 2, 3 ]
*
*   const exclusive = yield* stream.pipe(
*     Stream.takeUntil((n) => n % 3 === 0, { excludeLast: true }),
*     Stream.runCollect
*   )
*   yield* Console.log(exclusive)
*   // Output: [ 1, 2 ]
* })
* ```
*
* @since 2.0.0
* @category Filtering
*/
var takeUntil = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, predicate, options) => transformPull(self, (pull, _scope) => sync$2(() => {
	let i = 0;
	let done$4 = false;
	return flatMap$2(suspend$2(() => done$4 ? done() : pull), (chunk) => {
		const index = chunk.findIndex((a) => predicate(a, i++));
		if (index >= 0) {
			done$4 = true;
			const arr = chunk.slice(0, options?.excludeLast ? index : index + 1);
			return isReadonlyArrayNonEmpty(arr) ? succeed$3(arr) : done();
		}
		return succeed$3(chunk);
	});
})));
/**
* Effectful predicate version of `takeUntil`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.range(1, 5).pipe(
*     Stream.takeUntilEffect((n) => Effect.succeed(n % 3 === 0)),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var takeUntilEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, predicate, options) => transformPull(self, (pull, _scope) => sync$2(() => {
	let i = 0;
	let done$3 = false;
	return gen(function* () {
		if (done$3) return yield* done();
		const chunk = yield* pull;
		for (let j = 0; j < chunk.length; j++) if (yield* predicate(chunk[j], i++)) {
			done$3 = true;
			const arr = chunk.slice(0, options?.excludeLast ? j : j + 1);
			return isReadonlyArrayNonEmpty(arr) ? arr : yield* done();
		}
		return chunk;
	});
})));
/**
* Takes the longest initial prefix of elements that satisfy the predicate.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.range(1, 5).pipe(
*   Stream.takeWhile((n) => n % 3 !== 0)
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var takeWhile = /*#__PURE__*/ dual(2, (self, predicate) => transformPull(self, (pull, _scope) => sync$2(() => {
	let i = 0;
	let done$2 = false;
	const pump = flatMap$2(suspend$2(() => done$2 ? done() : pull), (chunk) => {
		const out = [];
		for (let j = 0; j < chunk.length; j++) {
			if (!predicate(chunk[j], i++)) {
				done$2 = true;
				break;
			}
			out.push(chunk[j]);
		}
		return isReadonlyArrayNonEmpty(out) ? succeed$3(out) : done$2 ? done() : pump;
	});
	return pump;
})));
/**
* Takes the longest initial prefix of elements that satisfy the filter.
*
* @since 4.0.0
* @category Filtering
*/
var takeWhileFilter = /*#__PURE__*/ dual(2, (self, filter) => transformPull(self, (pull, _scope) => sync$2(() => {
	let done$1 = false;
	const pump = flatMap$2(suspend$2(() => done$1 ? done() : pull), (chunk) => {
		const out = [];
		for (let j = 0; j < chunk.length; j++) {
			const result = filter(chunk[j]);
			if (isFailure(result)) {
				done$1 = true;
				break;
			}
			out.push(result.success);
		}
		return isReadonlyArrayNonEmpty(out) ? succeed$3(out) : done$1 ? done() : pump;
	});
	return pump;
})));
/**
* Takes elements from the stream while the effectful predicate is `true`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.range(1, 5).pipe(
*     Stream.takeWhileEffect((n) => Effect.succeed(n % 3 !== 0)),
*     Stream.runCollect
*   )
*   Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var takeWhileEffect = /*#__PURE__*/ dual(2, (self, predicate) => takeUntilEffect(self, (a, n) => map$3(predicate(a, n), (b) => !b), { excludeLast: true }));
/**
* Drops the first `n` elements from this stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
* const result = Stream.drop(stream, 2)
*
* const program = Effect.gen(function*() {
*   const items = yield* Stream.runCollect(result)
*   yield* Console.log(items)
* })
*
* Effect.runPromise(program)
* // Output: [ 3, 4, 5 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var drop = /*#__PURE__*/ dual(2, (self, n) => transformPull(self, (pull, _scope) => sync$2(() => {
	let dropped = 0;
	const pump = pull.pipe(flatMap$2((chunk) => {
		if (dropped >= n) return succeed$3(chunk);
		dropped += chunk.length;
		if (dropped <= n) return pump;
		return succeed$3(chunk.slice(n - dropped));
	}));
	return pump;
})));
/**
* Drops elements until the specified predicate evaluates to `true`, then drops
* that matching element.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
* const result = Stream.dropUntil(stream, (n) => n >= 3)
*
* Effect.gen(function*() {
*   const output = yield* Stream.runCollect(result)
*   yield* Console.log(output) // Output: [ 4, 5 ]
* })
* ```
*
* @since 2.0.0
* @category Filtering
*/
var dropUntil = /*#__PURE__*/ dual(2, (self, predicate) => drop(dropWhile(self, (a, i) => !predicate(a, i)), 1));
/**
* Drops all elements of the stream until the specified effectful predicate
* evaluates to `true`.
*
* The first element that satisfies the predicate is also dropped.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.range(1, 5).pipe(
*     Stream.dropUntilEffect((n) => Effect.succeed(n % 3 === 0)),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 4, 5 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var dropUntilEffect = /*#__PURE__*/ dual(2, (self, predicate) => drop(dropWhileEffect(self, (a, i) => map$3(predicate(a, i), (b) => !b)), 1));
/**
* Drops elements from the stream while the specified predicate evaluates to `true`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.dropWhile((n) => n < 3),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 3, 4, 5 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var dropWhile = /*#__PURE__*/ dual(2, (self, predicate) => transformPull(self, (pull, _scope) => sync$2(() => {
	let dropping = true;
	let index = 0;
	const filtered = flatMap$2(pull, (arr) => {
		const found = arr.findIndex((a) => !predicate(a, index++));
		if (found === -1) return filtered;
		dropping = false;
		return succeed$3(arr.slice(found));
	});
	return suspend$2(() => dropping ? filtered : pull);
})));
/**
* Drops elements while the filter succeeds.
*
* @since 4.0.0
* @category Filtering
*/
var dropWhileFilter = /*#__PURE__*/ dual(2, (self, filter) => transformPull(self, (pull, _scope) => sync$2(() => {
	let dropping = true;
	const filtered = flatMap$2(pull, (arr) => {
		const found = arr.findIndex((a) => isFailure(filter(a)));
		if (found === -1) return filtered;
		dropping = false;
		return succeed$3(arr.slice(found));
	});
	return suspend$2(() => dropping ? filtered : pull);
})));
/**
* Drops elements while the specified effectful predicate evaluates to `true`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.dropWhileEffect((n) => Effect.succeed(n < 3)),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 3, 4, 5 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var dropWhileEffect = /*#__PURE__*/ dual(2, (self, predicate) => transformPull(self, (pull, _scope) => sync$2(() => {
	let dropping = true;
	let index = 0;
	const filtered = gen(function* () {
		while (true) {
			const arr = yield* pull;
			for (let i = 0; i < arr.length; i++) {
				if (yield* predicate(arr[i], index++)) continue;
				dropping = false;
				return arr.slice(i);
			}
		}
	});
	return suspend$2(() => dropping ? filtered : pull);
})));
/**
* Drops the last specified number of elements from this stream.
*
* Keeps the last `n` elements in memory to drop them on completion.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.dropRight(2),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Filtering
*/
var dropRight = /*#__PURE__*/ dual(2, (self, n) => {
	if (n <= 0) return self;
	return transformPull(self, (pull, _scope) => sync$2(() => {
		const list = make$6();
		const emit = flatMap$2(pull, (arr) => {
			appendAllUnsafe(list, arr);
			const toTake = list.length - n;
			const items = takeN(list, toTake);
			return isArrayNonEmpty(items) ? succeed$3(items) : emit;
		});
		return emit;
	}));
});
/**
* Exposes the underlying chunks as a stream of non-empty arrays.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const chunks = yield* Stream.make(1, 2, 3, 4).pipe(
*     Stream.rechunk(2),
*     Stream.chunks,
*     Stream.runCollect
*   )
*   yield* Console.log(chunks)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, 2 ], [ 3, 4 ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var chunks = (self) => self.channel.pipe(map$6(of), fromChannel);
/**
* Re-chunks the stream into arrays of the specified size, preserving element order.
*
* The size is clamped to at least 1.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.rechunk(2),
*     Stream.chunks,
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, 2 ], [ 3, 4 ], [ 5 ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var rechunk = /*#__PURE__*/ dual(2, (self, target) => {
	target = Math.max(1, target);
	return transformPull(self, (pull, _scope) => sync$2(() => {
		let chunk = empty$1();
		let index = 0;
		let current;
		let done$8 = false;
		return suspend$2(function loop() {
			if (done$8) return done();
			else if (current === void 0) return flatMap$2(pull, (arr) => {
				if (chunk.length === 0 && arr.length === target) return succeed$3(arr);
				else if (chunk.length + arr.length < target) {
					chunk.push(...arr);
					return loop();
				}
				current = arr;
				return loop();
			});
			for (; index < current.length;) {
				chunk.push(current[index++]);
				if (chunk.length === target) {
					const result = chunk;
					chunk = [];
					return succeed$3(result);
				}
			}
			index = 0;
			current = void 0;
			return loop();
		}).pipe(catchDone(() => {
			if (chunk.length === 0) return done();
			const result = chunk;
			done$8 = true;
			chunk = [];
			return succeed$3(result);
		}));
	}));
});
/**
* Emits a sliding window of `n` elements.
*
* @example
* ```ts
* import { Console, Effect, Stream, pipe } from "effect"
*
* Effect.gen(function*() {
*   const result = yield* pipe(
*     Stream.make(1, 2, 3, 4, 5),
*     Stream.sliding(2),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
* // Output: [ [1, 2], [2, 3], [3, 4], [4, 5] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var sliding = /*#__PURE__*/ dual(2, (self, chunkSize) => slidingSize(self, chunkSize, 1));
/**
* Emits sliding windows of `chunkSize` elements, advancing by `stepSize`.
*
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const chunks = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.slidingSize(3, 2),
*     Stream.runCollect
*   )
*   yield* Console.log(chunks)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, 2, 3 ], [ 3, 4, 5 ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var slidingSize = /*#__PURE__*/ dual(3, (self, chunkSize, stepSize) => transformPull(self, (upstream, _scope) => sync$2(() => {
	let cause = null;
	const list = make$6();
	let emitted = false;
	const pull = matchCauseEffect(upstream, {
		onSuccess(arr) {
			appendAllUnsafe(list, arr);
			if (list.length < chunkSize) return pull;
			emitted = true;
			const chunks = [];
			while (list.length >= chunkSize) if (chunkSize === stepSize) chunks.push(takeN(list, chunkSize));
			else {
				chunks.push(toArrayN(list, chunkSize));
				if (chunkSize === 1) take$2(list);
				else takeNVoid(list, stepSize);
			}
			return succeed$3(chunks);
		},
		onFailure(cause_) {
			if (emitted) takeNVoid(list, chunkSize - stepSize);
			if (list.length === 0) return failCause$2(cause_);
			cause = cause_;
			return succeed$3(of(takeAll(list)));
		}
	});
	return suspend$2(() => cause ? failCause$2(cause) : pull);
})));
/**
* Splits the stream into non-empty groups whenever the predicate matches.
*
* Matching elements act as delimiters and are not included in the output.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.range(0, 9).pipe(
*     Stream.split((n) => n % 4 === 0),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ [1, 2, 3], [5, 6, 7], [9] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var split = /*#__PURE__*/ dual(2, (self, predicate) => mapAccumArray(self, empty$1, (acc, arr) => {
	const out = empty$1();
	for (let i = 0; i < arr.length; i++) if (predicate(arr[i])) {
		if (isArrayNonEmpty(acc)) {
			out.push(acc);
			acc = [];
		}
	} else acc.push(arr[i]);
	return [acc, out];
}, { onHalt(arr) {
	return isArrayNonEmpty(arr) ? of(arr) : emptyArr;
} }));
/**
* Combines elements from this stream and the specified stream by repeatedly
* applying a stateful function that can pull from either side.
*
* Where possible, prefer `Stream.combineArray` for a more efficient
* implementation.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.combine(
*   Stream.make("A", "B", "C"),
*   Stream.make(1, 2, 3),
*   () => true,
*   (takeLeft, pullLeft, pullRight) =>
*     takeLeft
*       ? Effect.map(pullLeft, (value) => [`L:${value}`, false] as const)
*       : Effect.map(pullRight, (value) => [`R:${value}`, true] as const)
* )
*
* const program = Effect.gen(function*() {
*   const output = yield* Stream.runCollect(stream)
*   yield* Console.log(output)
* })
*
* Effect.runPromise(program)
* // Output: [ "L:A", "R:1", "L:B", "R:2", "L:C", "R:3" ]
* ```
*
* @since 2.0.0
* @category Merging
*/
var combine = /*#__PURE__*/ dual(4, (self, that, s, f) => combine$1(flattenArray$1(self.channel), flattenArray$1(that.channel), s, f).pipe(map$6(of), fromChannel));
/**
* Combines the arrays (chunks) from this stream and the specified stream by
* repeatedly applying the function `f` to extract an array using both sides and
* conceptually "offer" it to the destination stream. `f` can maintain some
* internal state to control the combining process, with the initial state
* being specified by `s`.
*
* **Previously Known As**
*
* This API replaces the following from Effect 3.x:
*
* - `Stream.combineChunks`
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2).pipe(
*   Stream.combineArray(
*     Stream.make(10, 20),
*     () => true,
*     (useLeft, pullLeft, pullRight) =>
*       Effect.gen(function*() {
*         const array = useLeft ? yield* pullLeft : yield* pullRight
*         return [array, !useLeft] as const
*       })
*   )
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 10, 20 ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var combineArray = /*#__PURE__*/ dual(4, (self, that, s, f) => fromChannel(combine$1(self.channel, that.channel, s, f)));
/**
* Statefully maps elements, emitting zero or more outputs per input.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const totals = yield* Stream.make(0, 1, 2, 3, 4, 5, 6).pipe(
*     Stream.mapAccum(() => 0, (total, n) => {
*       const next = total + n
*       return [next, [next]] as const
*     }),
*     Stream.runCollect
*   )
*
*   yield* Console.log(totals)
* })
*
* Effect.runPromise(program)
* // Output: [ 0, 1, 3, 6, 10, 15, 21 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapAccum = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, initial, f, options) => fromChannel(mapAccum$1(self.channel, initial, (state, arr) => {
	const acc = empty$1();
	for (let index = 0; index < arr.length; index++) {
		const [newState, values] = f(state, arr[index]);
		state = newState;
		acc.push(...values);
	}
	return [state, isArrayNonEmpty(acc) ? of(acc) : emptyArr];
}, options?.onHalt ? { onHalt(state) {
	const arr = options.onHalt(state);
	return isReadonlyArrayNonEmpty(arr) ? of(arr) : emptyArr;
} } : void 0)));
/**
* Statefully maps over non-empty chunk arrays, emitting zero or more values per chunk.
*
* The mapping function runs once per chunk and the state is threaded across chunks.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const output = yield* Stream.make(1, 2, 3, 4, 5, 6).pipe(
*     Stream.rechunk(2),
*     Stream.mapAccumArray(() => 0, (sum: number, chunk) => {
*       const next = chunk.reduce((acc, n) => acc + n, sum)
*       return [next, [next]]
*     }),
*     Stream.runCollect
*   )
*   yield* Console.log(output)
* })
*
* Effect.runPromise(program)
* // Output: [ 3, 10, 21 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapAccumArray = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, initial, f, options) => fromChannel(mapAccum$1(self.channel, initial, (state, arr) => {
	const [newState, values] = f(state, arr);
	state = newState;
	return [state, isReadonlyArrayNonEmpty(values) ? of(values) : emptyArr];
}, options?.onHalt ? { onHalt(state) {
	const arr = options.onHalt(state);
	return isReadonlyArrayNonEmpty(arr) ? of(arr) : emptyArr;
} } : void 0)));
var emptyArr = /*#__PURE__*/ empty$1();
/**
* Statefully and effectfully maps over the elements of this stream to produce new elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.make(1, 1, 1).pipe(
*     Stream.mapAccumEffect(() => 0, (total, n) =>
*       Effect.succeed([total + n, [total + n]])
*     ),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // Output: [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapAccumEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, initial, f, options) => self.channel.pipe(flattenArray$1, mapAccum$1(initial, (state, a) => map$3(f(state, a), ([state, values]) => [state, isReadonlyArrayNonEmpty(values) ? of(values) : empty$1()]), options?.onHalt ? { onHalt(state) {
	const arr = options.onHalt(state);
	return isReadonlyArrayNonEmpty(arr) ? of(arr) : emptyArr;
} } : void 0), fromChannel));
/**
* Statefully and effectfully maps over chunks of this stream to emit new values.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const totals = yield* Stream.make(1, 2, 3, 4).pipe(
*     Stream.rechunk(2),
*     Stream.mapAccumArrayEffect(() => 0, (total, chunk) =>
*       Effect.gen(function*() {
*         const next = chunk.reduce((sum, value) => sum + value, total)
*         return [next, [next]] as const
*       })
*     ),
*     Stream.runCollect
*   )
*   yield* Console.log(totals)
* })
*
* Effect.runPromise(program)
* // Output: [ 3, 10 ]
* ```
*
* @since 2.0.0
* @category Mapping
*/
var mapAccumArrayEffect = /*#__PURE__*/ dual((args) => isStream(args), (self, initial, f, options) => self.channel.pipe(mapAccum$1(initial, (state, a) => map$3(f(state, a), ([state, values]) => [state, isReadonlyArrayNonEmpty(values) ? of(values) : emptyArr]), options?.onHalt ? { onHalt(state) {
	const arr = options.onHalt(state);
	return isReadonlyArrayNonEmpty(arr) ? of(arr) : emptyArr;
} } : void 0), fromChannel));
/**
* Accumulates state across the stream, emitting the initial state and each updated state.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.scan(0, (acc, n) => acc + n),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ 0, 1, 3, 6 ]
* ```
*
* @since 2.0.0
* @category Accumulation
*/
var scan = /*#__PURE__*/ dual(3, (self, initial, f) => suspend(() => {
	let isFirst = true;
	return fromChannel(mapAccum$1(self.channel, constant(initial), (state, arr) => {
		const states = empty$1();
		if (isFirst) {
			isFirst = false;
			states.push(state);
		}
		for (let index = 0; index < arr.length; index++) {
			state = f(state, arr[index]);
			states.push(state);
		}
		return [state, of(states)];
	}));
}));
/**
* Effectfully accumulates state and emits the initial state plus each accumulated state.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const states = yield* Stream.make(1, 2, 3).pipe(
*     Stream.scanEffect(0, (sum, n) => Effect.succeed(sum + n)),
*     Stream.runCollect
*   )
*   yield* Console.log(states)
*   // Output: [ 0, 1, 3, 6 ]
* })
* ```
*
* @since 2.0.0
* @category Accumulation
*/
var scanEffect = /*#__PURE__*/ dual(3, (self, initial, f) => self.channel.pipe(flattenArray$1, scanEffect$1(initial, f), map$6(of), fromChannel));
/**
* Drops earlier elements within the debounce window and emits only the latest element after the pause.
*
* @example
* ```ts
* import { Console, Duration, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3).pipe(
*   Stream.concat(Stream.fromEffect(Effect.sleep(Duration.millis(50)).pipe(Effect.as(4)))),
*   Stream.concat(Stream.make(5)),
*   Stream.debounce(Duration.millis(30))
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
*   // Output: [ 3, 5 ]
* })
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var debounce = /*#__PURE__*/ dual(2, (self, duration) => transformPull(self, fnUntraced(function* (pull, scope) {
	const clock = yield* Clock;
	const durationMs = toMillis(fromInputUnsafe(duration));
	let lastArr;
	let cause;
	let emitAtMs = Infinity;
	const pullLatch = makeUnsafe$5();
	const emitLatch = makeUnsafe$5();
	const endLatch = makeUnsafe$5();
	yield* pull.pipe(pullLatch.whenOpen, flatMap$2((arr) => {
		emitLatch.openUnsafe();
		lastArr = arr;
		emitAtMs = clock.currentTimeMillisUnsafe() + durationMs;
		return void_;
	}), forever$1({ disableYield: true }), onError$1((cause_) => {
		cause = cause_;
		emitAtMs = clock.currentTimeMillisUnsafe();
		emitLatch.openUnsafe();
		endLatch.openUnsafe();
		return void_;
	}), forkIn(scope));
	const sleepLoop = suspend$2(function loop() {
		const now = clock.currentTimeMillisUnsafe();
		return flatMap$2(raceFirst(sleep(emitAtMs < now ? durationMs : Math.min(durationMs, emitAtMs - now)), endLatch.await), () => {
			if (clock.currentTimeMillisUnsafe() < emitAtMs) return loop();
			else if (lastArr) {
				emitLatch.closeUnsafe();
				pullLatch.closeUnsafe();
				const eff = succeed$3(of(lastNonEmpty(lastArr)));
				lastArr = void 0;
				return eff;
			} else if (cause) return failCause$2(cause);
			return loop();
		});
	});
	return suspend$2(() => {
		if (cause) {
			if (lastArr) {
				const eff = succeed$3(of(lastNonEmpty(lastArr)));
				lastArr = void 0;
				return eff;
			}
			return failCause$2(cause);
		}
		pullLatch.openUnsafe();
		return emitLatch.whenOpen(sleepLoop);
	});
})));
/**
* Delays the arrays of this stream according to the given bandwidth
* parameters using the token bucket algorithm. Allows for burst processing by
* allowing the bucket to accumulate tokens up to a `units + burst` threshold.
* The weight of each array is determined by the effectful `cost` function.
*
* If using the "enforce" strategy, arrays that do not meet the bandwidth
* constraints are dropped. If using the "shape" strategy, arrays are delayed
* until they can be emitted without exceeding the bandwidth constraints.
*
* Defaults to the "shape" strategy.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const stream = Stream.fromSchedule(Schedule.spaced("50 millis")).pipe(
*   Stream.take(6),
*   Stream.throttleEffect({
*     cost: (arr) => Effect.succeed(arr.length),
*     units: 1,
*     duration: "100 millis",
*     strategy: "shape"
*   })
* )
*
* Effect.runPromise(Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* }))
* // Output: [0, 1, 2, 3, 4, 5]
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var throttleEffect = /*#__PURE__*/ dual(2, (self, options) => {
	const burst = options.burst ?? 0;
	if (options.strategy === "enforce") return throttleEnforceEffect(self, options.cost, options.units, options.duration, burst);
	return throttleShapeEffect(self, options.cost, options.units, options.duration, burst);
});
var throttleEnforceEffect = (self, cost, units, duration, burst) => transformPull(self, (pull) => clockWith((clock) => {
	const durationMs = toMillis(fromInputUnsafe(duration));
	const max = units + burst < 0 ? Number.POSITIVE_INFINITY : units + burst;
	let tokens = units;
	let timestampMs = clock.currentTimeMillisUnsafe();
	return succeed$3(flatMap$2(pull, function loop(arr) {
		return flatMap$2(cost(arr), (weight) => {
			const currentMs = clock.currentTimeMillisUnsafe();
			const cycles = (currentMs - timestampMs) / durationMs;
			const sum = tokens + cycles * units;
			const available = sum < 0 ? max : Math.min(sum, max);
			if (weight <= available) {
				tokens = available - weight;
				timestampMs = currentMs;
				return succeed$3(arr);
			}
			return flatMap$2(pull, loop);
		});
	}));
}));
var throttleShapeEffect = (self, cost, units, duration, burst) => transformPull(self, (pull) => clockWith((clock) => {
	const durationMs = toMillis(fromInputUnsafe(duration));
	const max = units + burst < 0 ? Number.POSITIVE_INFINITY : units + burst;
	let tokens = units;
	let timestampMs = clock.currentTimeMillisUnsafe();
	return succeed$3(flatMap$2(pull, (arr) => flatMap$2(cost(arr), (weight) => {
		const currentMs = clock.currentTimeMillisUnsafe();
		const cycles = (currentMs - timestampMs) / durationMs;
		const sum = tokens + cycles * units;
		const remaining = (sum < 0 ? max : Math.min(sum, max)) - weight;
		if (remaining >= 0) {
			tokens = remaining;
			timestampMs = currentMs;
			return succeed$3(arr);
		}
		const waitCycles = -remaining / units;
		const delayMs = Math.max(0, waitCycles * durationMs);
		if (delayMs > 0) return flatMap$2(sleep(delayMs), () => {
			tokens = remaining;
			timestampMs = currentMs;
			return succeed$3(arr);
		});
		tokens = remaining;
		timestampMs = currentMs;
		return succeed$3(arr);
	})));
}));
/**
* Delays the arrays of this stream using a token bucket and a per-array cost.
* Allows bursts by letting the bucket accumulate up to a `units + burst`
* threshold. The weight of each array is determined by the `cost` function.
*
* If using the "enforce" strategy, arrays that do not meet the bandwidth
* constraints are dropped. If using the "shape" strategy, arrays are delayed
* until they can be emitted without exceeding the bandwidth constraints.
*
* Defaults to the "shape" strategy.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Stream } from "effect"
*
* const stream = Stream.fromSchedule(Schedule.spaced("50 millis")).pipe(
*   Stream.take(6),
*   Stream.throttle({
*     cost: (arr) => arr.length,
*     units: 1,
*     duration: "100 millis",
*     strategy: "shape"
*   })
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
*   // Output: [ 0, 1, 2, 3, 4, 5 ]
* })
* ```
*
* @since 2.0.0
* @category Rate Limiting
*/
var throttle = /*#__PURE__*/ dual(2, (self, options) => throttleEffect(self, {
	...options,
	cost: (arr) => succeed$3(options.cost(arr))
}));
/**
* Partitions the stream into non-empty arrays of the specified size.
*
* The final array may be smaller if there are not enough elements to fill it.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const grouped = yield* Stream.range(1, 8).pipe(
*     Stream.grouped(3),
*     Stream.runCollect
*   )
*   yield* Console.log(grouped)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 7, 8 ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var grouped = /*#__PURE__*/ dual(2, (self, n) => chunks(rechunk(self, n)));
/**
* Partitions the stream into arrays, emitting when the chunk size is reached
* or the duration passes.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.groupedWithin(2, "5 seconds"),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output: [ [ 1, 2 ], [ 3 ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var groupedWithin = /*#__PURE__*/ dual(3, (self, chunkSize, duration) => aggregateWithin(self, take$1(chunkSize), spaced(duration)));
/**
* Groups elements into keyed substreams using an effectful classifier.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const grouped = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.groupBy((n) =>
*       Effect.succeed([n % 2 === 0 ? "even" : "odd", n] as const)
*     ),
*     Stream.mapEffect(
*       Effect.fnUntraced(function*([key, stream]) {
*         return [key, yield* Stream.runCollect(stream)] as const
*       }),
*       { concurrency: "unbounded" }
*     ),
*     Stream.runCollect
*   )
*
*   yield* Console.log(grouped)
* })
*
* Effect.runPromise(program)
* // Output: [ [ "odd", [ 1, 3, 5 ] ], [ "even", [ 2, 4 ] ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var groupBy = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, f, options) => groupByImpl(self, fnUntraced(function* (arr, queues, queueMap) {
	for (let i = 0; i < arr.length; i++) {
		const [key, value] = yield* f(arr[i]);
		const oentry = get$4(queueMap, key);
		const queue = isSome(oentry) ? oentry.value : yield* scoped$1(get$2(queues, key));
		yield* touch(queues, key);
		yield* offer(queue, value);
	}
}), options));
/**
* Groups elements by a key and emits a stream per key.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const grouped = yield* Stream.make(1, 2, 3, 4, 5).pipe(
*     Stream.groupByKey((n) => n % 2 === 0 ? "even" : "odd"),
*     Stream.mapEffect(
*       ([key, stream]) =>
*         Stream.runCollect(stream).pipe(
*           Effect.map((values) => [key, values] as const)
*         ),
*       { concurrency: "unbounded" }
*     ),
*     Stream.runCollect
*   )
*   yield* Console.log(grouped)
* })
*
* Effect.runPromise(program)
* // Output: [ [ "odd", [ 1, 3, 5 ] ], [ "even", [ 2, 4 ] ] ]
* ```
*
* @since 2.0.0
* @category Grouping
*/
var groupByKey = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, f, options) => suspend(() => {
	const batch = empty$3();
	return groupByImpl(self, fnUntraced(function* (arr, queues, queueMap) {
		for (let i = 0; i < arr.length; i++) {
			const key = f(arr[i]);
			const ovalues = get$4(batch, key);
			if (isNone(ovalues)) set(batch, key, [arr[i]]);
			else ovalues.value.push(arr[i]);
		}
		for (const [key, values] of batch) {
			const oentry = get$4(queueMap, key);
			const queue = isSome(oentry) ? oentry.value : yield* scoped$1(get$2(queues, key));
			yield* touch(queues, key);
			yield* offerAll(queue, values);
		}
		clear(batch);
	}), options);
}));
var groupByImpl = (self, f, options) => transformPullBracket(self, fnUntraced(function* (pull, scope, forkedScope) {
	const out = yield* unbounded();
	yield* addFinalizer(scope, shutdown(out));
	const queueMap = empty$3();
	const queues = yield* make$3({
		lookup: (key) => acquireRelease(make$5({ capacity: options?.bufferSize ?? 4096 }).pipe(tap$1((queue) => {
			set(queueMap, key, queue);
			return offer(out, [key, fromQueue(queue)]);
		})), (queue) => {
			remove(queueMap, key);
			return end(queue);
		}),
		idleTimeToLive: options?.idleTimeToLive ?? infinity
	}).pipe(provide$1(forkedScope));
	yield* whileLoop({
		while: constTrue,
		body: constant(flatMap$2(pull, (arr) => f(arr, queues, queueMap))),
		step: constVoid
	}).pipe(catchCause$2((cause) => failCause$4(out, cause)), forkIn(scope));
	return takeAll$1(out);
}));
/**
* @since 2.0.0
* @category Grouping
*/
var groupAdjacentBy = /*#__PURE__*/ dual(2, (self, f) => transformPull(self, (pull, _scope) => sync$2(() => {
	let currentKey = void 0;
	let group;
	let toEmit = empty$1();
	const loop = pull.pipe(flatMap$2((chunk) => {
		for (let i = 0; i < chunk.length; i++) {
			const item = chunk[i];
			const key = f(item);
			if (group === void 0) {
				currentKey = key;
				group = [item];
				continue;
			} else if (equals(key, currentKey)) {
				group.push(item);
				continue;
			}
			toEmit.push([currentKey, group]);
			currentKey = key;
			group = [item];
		}
		if (isArrayNonEmpty(toEmit)) {
			const out = toEmit;
			toEmit = [];
			return succeed$3(out);
		}
		return loop;
	}));
	let done$9 = false;
	return catchDone(suspend$2(() => done$9 ? done() : loop), () => {
		done$9 = true;
		const out = group;
		group = void 0;
		return out && isArrayNonEmpty(out) ? succeed$3(of([currentKey, out])) : done();
	});
})));
/**
* Applies a sink transducer to the stream and emits each sink result.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* const program = Effect.gen(function* () {
*   const result = yield* Stream.make(1, 2, 3, 4).pipe(
*     Stream.transduce(Sink.take(2)),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
*   // Output: [ [ 1, 2 ], [ 3, 4 ] ]
* })
* ```
*
* @since 2.0.0
* @category Aggregation
*/
var transduce = /*#__PURE__*/ dual(2, (self, sink) => transformPull(self, (upstream, scope) => sync$2(() => {
	let done$6;
	let leftover;
	const upstreamWithLeftover = suspend$2(() => {
		if (leftover !== void 0) {
			const chunk = leftover;
			leftover = void 0;
			return succeed$3(chunk);
		}
		return upstream;
	}).pipe(catch_$2((error) => {
		done$6 = fail$4(error);
		return done();
	}));
	const pull = map$3(suspend$2(() => sink.transform(upstreamWithLeftover, scope)), ([value, leftover_]) => {
		leftover = leftover_;
		return of(value);
	});
	return suspend$2(() => done$6 ? done$6 : pull);
})));
/**
* Aggregates elements using the provided sink and emits each sink result as a stream element.
*
* The stream runs the upstream and downstream in separate fibers, so the sink can keep
* consuming input while downstream is busy processing the previous output.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* Effect.runPromise(Effect.gen(function* () {
*   const aggregated = yield* Stream.runCollect(
*     Stream.make(1, 2, 3, 4, 5, 6).pipe(
*       Stream.aggregate(
*         Sink.foldUntil(() => 0, 3, (sum, n) => Effect.succeed(sum + n))
*       )
*     )
*   )
*   yield* Console.log(aggregated)
* }))
* // [ 6, 15 ]
* ```
*
* @since 2.0.0
* @category Aggregation
*/
var aggregate = /*#__PURE__*/ dual(2, (self, sink) => aggregateWithin(self, sink, forever$2));
/**
* Aggregates elements with a sink, emitting each result when the sink completes or the schedule triggers.
*
* The schedule can flush the current aggregation even if the sink has not finished.
*
* @example
* ```ts
* import { Console, Effect, Schedule, Sink, Stream } from "effect"
*
* Effect.runPromise(Effect.gen(function* () {
*   const aggregated = yield* Stream.runCollect(
*     Stream.make(1, 2, 3, 4, 5, 6).pipe(
*       Stream.aggregateWithin(
*         Sink.foldUntil(() => 0, 3, (sum, n) => Effect.succeed(sum + n)),
*         Schedule.spaced("1 minute")
*       )
*     )
*   )
*   yield* Console.log(aggregated)
* }))
* // Output: [ 6, 15 ]
* ```
*
* @since 2.0.0
* @category Aggregation
*/
var aggregateWithin = /*#__PURE__*/ dual(3, (self, sink, schedule) => fromChannel(fromTransformBracket(fnUntraced(function* (_upstream, _, scope) {
	const pull = yield* toPullScoped(self.channel, _);
	const pullLatch = makeUnsafe$5(false);
	const scheduleStep = Symbol();
	const buffer = yield* make$5({ capacity: 0 });
	let hadChunk = false;
	yield* pull.pipe(pullLatch.whenOpen, flatMap$2((arr) => {
		hadChunk = true;
		pullLatch.closeUnsafe();
		return offer(buffer, arr);
	}), forever$1, catchCause$2((cause) => failCause$4(buffer, cause)), forkIn(scope));
	let lastOutput = none();
	let leftover;
	const step = yield* toStepWithSleep(schedule);
	const stepToBuffer = suspend$2(function loop() {
		return step(lastOutput).pipe(flatMap$2(() => !hadChunk && leftover === void 0 ? loop() : offer(buffer, scheduleStep)), flatMap$2(() => never$2), catchDone(() => done()));
	});
	const pullFromBuffer = take$3(buffer).pipe(flatMap$2((arr) => arr === scheduleStep ? done() : succeed$3(arr)));
	const sinkUpstream = suspend$2(() => {
		if (leftover !== void 0) {
			const chunk = leftover;
			leftover = void 0;
			return succeed$3(chunk);
		}
		hadChunk = false;
		pullLatch.openUnsafe();
		return pullFromBuffer;
	});
	const catchSinkHalt = flatMap$2(([value, leftover_]) => {
		if (!hadChunk && buffer.state._tag === "Done") return done();
		lastOutput = some$1(value);
		leftover = leftover_;
		return succeed$3(of(value));
	});
	return suspend$2(() => {
		if (buffer.state._tag === "Done") return buffer.state.exit;
		return succeed$3(suspend$2(() => sink.transform(sinkUpstream, scope)));
	}).pipe(flatMap$2((pull) => raceFirst(catchSinkHalt(pull), stepToBuffer)));
}))));
/**
* Creates a PubSub-backed stream that multicasts the source to all subscribers.
*
* The returned stream is scoped and uses the provided PubSub capacity and replay settings.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.scoped(
*   Effect.gen(function* () {
*     const broadcasted = yield* Stream.broadcast(Stream.fromArray([1, 2, 3]), {
*       capacity: 8,
*       replay: 3
*     })
*
*     const [left, right] = yield* Effect.all([
*       Stream.runCollect(broadcasted),
*       Stream.runCollect(broadcasted)
*     ], { concurrency: "unbounded" })
*
*     yield* Console.log([left, right])
*   })
* )
*
* Effect.runPromise(program)
* // Output: [[1, 2, 3], [1, 2, 3]]
* ```
*
* @since 2.0.0
* @category Broadcast
*/
var broadcast = /*#__PURE__*/ dual(2, (self, options) => map$3(toPubSubTake(self, options), fromPubSubTake));
/**
* Returns a new Stream that multicasts the original stream, subscribing when the first consumer starts.
*
* The upstream continues running while there is at least one consumer and is finalized after the last one exits.
* If `idleTimeToLive` is set, the upstream is kept alive for that duration so a later subscriber can continue from
* the next element instead of restarting.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* Effect.runPromise(
*   Effect.scoped(
*     Effect.gen(function*() {
*       const shared = yield* Stream.make(1, 2, 3).pipe(
*         Stream.share({ capacity: 16 })
*       )
*
*       const first = yield* shared.pipe(Stream.take(1), Stream.runCollect)
*       const second = yield* shared.pipe(Stream.take(1), Stream.runCollect)
*
*       yield* Console.log([first, second])
*     })
*   )
* )
* // output: [[1], [1]]
* ```
*
* @since 2.0.0
* @category Broadcast
*/
var share = /*#__PURE__*/ dual(2, (self, options) => map$3(make$1({
	acquire: broadcast(self, options),
	idleTimeToLive: options.idleTimeToLive
}), (ref) => unwrap(get(ref))));
/**
* Pipes this stream through a channel that consumes and emits chunked elements.
*
* The channel receives `NonEmptyReadonlyArray` chunks and can transform both the
* output elements and error type.
*
* @example
* ```ts
* import { Array, Channel, Console, Effect, Stream } from "effect"
*
* type NumberChunk = readonly [number, ...Array<number>]
*
* const doubleChunks = Channel.identity<NumberChunk, never, unknown>().pipe(
*   Channel.map((chunk) => Array.map(chunk, (n) => n * 2))
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.fromArray([1, 2, 3]).pipe(
*     Stream.rechunk(2),
*     Stream.pipeThroughChannel(doubleChunks),
*     Stream.runCollect
*   )
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // => [2, 4, 6]
* ```
*
* @since 2.0.0
* @category Pipe
*/
var pipeThroughChannel = /*#__PURE__*/ dual(2, (self, channel) => fromChannel(pipeTo(self.channel, channel)));
/**
* Pipes values through the provided channel while preserving this stream's
* failures alongside any channel failures.
*
* Upstream failures are not passed to the channel, so the resulting stream can
* fail with either the original stream error or the channel error.
*
* @example
* ```ts
* import type { Channel } from "effect"
* import { Console, Effect, Stream } from "effect"
*
* declare const transformChannel: Channel.Channel<
*   readonly [string, ...Array<string>],
*   "ChannelError",
*   unknown,
*   readonly [number, ...Array<number>],
*   "StreamError",
*   unknown,
*   never
* >
*
* Effect.runPromise(Effect.gen(function*() {
*   const result = yield* Stream.make(1, 2, 3).pipe(
*     Stream.pipeThroughChannelOrFail(transformChannel),
*     Stream.runCollect
*   )
*
*   yield* Console.log(result)
* }))
* // Output:
* // ["1", "2", "3"]
* ```
*
* @since 2.0.0
* @category Pipe
*/
var pipeThroughChannelOrFail = /*#__PURE__*/ dual(2, (self, channel) => fromChannel(pipeToOrFail(self.channel, channel)));
/**
* Pipes the stream through `Sink.toChannel`, emitting only the sink leftovers.
*
* If the sink completes mid-chunk, the remaining elements become the output stream.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const leftovers = yield* Stream.make(1, 2, 3, 4).pipe(
*     Stream.pipeThrough(Sink.take(2)),
*     Stream.runCollect
*   )
*
*   yield* Console.log(leftovers)
* })
*
* Effect.runPromise(program)
* //=> [ 3, 4 ]
* ```
*
* @since 2.0.0
* @category Pipe
*/
var pipeThrough = /*#__PURE__*/ dual(2, (self, sink) => self.channel.pipe(pipeToOrFail(toChannel$1(sink)), concatWith(([_, leftover]) => leftover ? succeed$4(leftover) : empty$4), fromChannel));
/**
* Collects all elements into an array and emits it as a single element.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const program = Effect.gen(function*() {
*   const collected = yield* stream.pipe(Stream.collect, Stream.runCollect)
*   yield* Console.log(collected[0])
* })
*
* Effect.runPromise(program)
* // [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Accumulation
*/
var collect = (self) => fromEffect(runCollect(self));
/**
* Accumulates elements into a growing array, emitting the cumulative array for each input chunk.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const accumulated = yield* Stream.runCollect(
*     Stream.fromArray([1, 2, 3]).pipe(
*       Stream.rechunk(1),
*       Stream.accumulate
*     )
*   )
*   yield* Console.log(accumulated)
* })
*
* Effect.runPromise(program)
* //=> { _id: 'Chunk', values: [ [ 1 ], [ 1, 2 ], [ 1, 2, 3 ] ] }
* ```
*
* @since 2.0.0
* @category Accumulation
*/
var accumulate = (self) => mapAccumArray(self, empty$1, (acc, as) => {
	const combined = appendAll(acc, as);
	return [combined, [combined]];
});
/**
* Emits only elements that differ from the previous one.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.fromIterable([1, 1, 2, 2, 3]).pipe(
*     Stream.changes,
*     Stream.runCollect
*   )
*
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Deduplication
*/
var changes = (self) => changesWith(self, equals);
/**
* Returns a stream that only emits elements that are not equal to the previously emitted element, as determined by the specified predicate.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make("A", "a", "B", "b", "b").pipe(
*   Stream.changesWith((left, right) => left.toLowerCase() === right.toLowerCase())
* )
*
* Effect.runPromise(
*   Effect.gen(function*() {
*     const values = yield* Stream.runCollect(stream)
*     yield* Console.log(values)
*   })
* )
* // ["A", "B"]
* ```
*
* @since 2.0.0
* @category Deduplication
*/
var changesWith = /*#__PURE__*/ dual(2, (self, f) => transformPull(self, (pull, _scope) => sync$2(() => {
	let first = true;
	let last;
	return flatMap$2(pull, function loop(arr) {
		const out = [];
		let i = 0;
		if (first) {
			first = false;
			last = arr[0];
			i = 1;
			out.push(last);
		}
		for (; i < arr.length; i++) {
			const a = arr[i];
			if (f(a, last)) continue;
			last = a;
			out.push(a);
		}
		return isArrayNonEmpty(out) ? succeed$3(out) : flatMap$2(pull, loop);
	});
})));
/**
* Emits only elements that differ from the previous element, using an effectful equality check.
*
* The predicate runs for each element after the first; returning `true` treats it as equal and skips it.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 1, 2, 2, 3, 3).pipe(
*     Stream.changesWithEffect((a, b) => Effect.succeed(a === b))
*   )
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // { _id: "Chunk", values: [ 1, 2, 3 ] }
* ```
*
* @since 2.0.0
* @category Deduplication
*/
var changesWithEffect = /*#__PURE__*/ dual(2, (self, f) => transformPull(self, (pull, _scope) => sync$2(() => {
	let first = true;
	let last;
	return flatMap$2(pull, fnUntraced(function* loop(arr) {
		const out = [];
		let i = 0;
		if (first) {
			first = false;
			last = arr[0];
			i = 1;
			out.push(last);
		}
		for (; i < arr.length; i++) {
			const a = arr[i];
			if (yield* f(a, last)) continue;
			last = a;
			out.push(a);
		}
		return isArrayNonEmpty(out) ? out : yield* flatMap$2(pull, fnUntraced(loop));
	}));
})));
/**
* Decodes Uint8Array chunks into strings using TextDecoder with an optional encoding.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const encoder = new TextEncoder()
* const stream = Stream.make(
*   encoder.encode("Hello"),
*   encoder.encode(" World")
* )
*
* const program = Effect.gen(function*() {
*   const decoded = yield* stream.pipe(
*     Stream.decodeText,
*     Stream.runCollect
*   )
*   yield* Console.log(decoded)
* })
*
* Effect.runPromise(program)
* // ["Hello", " World"]
* ```
*
* @since 2.0.0
* @category Encoding
*/
var decodeText = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => suspend(() => {
	const decoder = new TextDecoder(options?.encoding);
	return map(self, (chunk) => decoder.decode(chunk, { stream: true }));
}));
/**
* Encodes a stream of strings into UTF-8 `Uint8Array` chunks.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make("Hello", " ", "World")
* const program = Effect.gen(function*() {
*   const encoded = Stream.encodeText(stream)
*   const chunks = yield* Stream.runCollect(encoded)
*   const bytes = chunks.map((chunk) => [...chunk])
*   yield* Console.log(bytes)
* })
*
* Effect.runPromise(program)
* // [[72, 101, 108, 108, 111], [32], [87, 111, 114, 108, 100]]
* ```
*
* @since 2.0.0
* @category Encoding
*/
var encodeText = (self) => suspend(() => {
	const encoder = new TextEncoder();
	return map(self, (chunk) => encoder.encode(chunk));
});
/**
* Splits a stream of strings into lines, handling `\n`, `\r`, and `\r\n` delimiters across chunks.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* Effect.runPromise(Effect.gen(function* () {
*   const lines = yield* Stream.runCollect(
*     Stream.make("a\nb\r\n", "c\n").pipe(Stream.splitLines)
*   )
*   yield* Console.log(lines)
* }))
* // ["a", "b", "c"]
* ```
*
* @since 2.0.0
* @category Encoding
*/
var splitLines = (self) => self.channel.pipe(pipeTo(splitLines$1()), fromChannel);
/**
* Inserts the provided element between emitted elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3, 4).pipe(Stream.intersperse(0))
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // [1, 0, 2, 0, 3, 0, 4]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var intersperse = /*#__PURE__*/ dual(2, (self, element) => mapArray(self, (arr, i) => {
	const out = i === 0 ? [] : [element];
	const lastIndex = arr.length - 1;
	for (let j = 0; j < arr.length; j++) if (j === lastIndex) out.push(arr[j]);
	else out.push(arr[j], element);
	return out;
}));
/**
* Intersperse stream elements with a middle value, adding a start and end value.
*
* The start and end values are always emitted, even when the stream is empty.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make("a", "b", "c").pipe(
*   Stream.intersperseAffixes({ start: "[", middle: ",", end: "]" })
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // [ "[", "a", ",", "b", ",", "c", "]" ]
* ```
*
* @since 2.0.0
* @category Sequencing
*/
var intersperseAffixes = /*#__PURE__*/ dual(2, (self, options) => succeed(options.start).pipe(concat(intersperse(self, options.middle)), concat(succeed(options.end))));
/**
* Interleaves this stream with the specified stream by alternating pulls from
* each stream; when one ends, the remaining values from the other stream are
* emitted.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.interleave(
*   Stream.make(2, 3),
*   Stream.make(5, 6, 7)
* )
*
* const program = Effect.gen(function*() {
*   const collected = yield* Stream.runCollect(stream)
*   yield* Console.log(collected)
* })
*
* Effect.runPromise(program)
* // [2, 5, 3, 6, 7]
* ```
* @since 2.0.0
* @category Merging
*/
var interleave = /*#__PURE__*/ dual(2, (self, that) => interleaveWith(self, that, fromIterable(forever$3([true, false]))));
/**
* Interleaves two streams deterministically by following a boolean decider stream.
*
* The decider controls how many elements are pulled; if one side ends, pulls for
* that side are ignored.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const left = Stream.make(1, 3, 5)
*   const right = Stream.make(2, 4, 6)
*   const decider = Stream.make(true, false, false, true, true)
*
*   const values = yield* Stream.runCollect(
*     Stream.interleaveWith(left, right, decider)
*   )
*
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // [ 1, 2, 4, 3, 5 ]
* ```
*
* @since 2.0.0
* @category Merging
*/
var interleaveWith = /*#__PURE__*/ dual(3, (self, that, decider) => fromChannel(fromTransform$1(fnUntraced(function* (upstream, scope) {
	const pullDecider = yield* toTransform(flattenArray$1(decider.channel))(upstream, scope);
	const retry = Symbol();
	let leftDone = false;
	let rightDone = false;
	const pullLeft = (yield* toTransform(flattenArray$1(self.channel))(upstream, scope)).pipe(catchDone(() => {
		leftDone = true;
		return succeed$3(retry);
	}));
	const pullRight = (yield* toTransform(flattenArray$1(that.channel))(upstream, scope)).pipe(catchDone(() => {
		rightDone = true;
		return succeed$3(retry);
	}));
	return gen(function* () {
		while (true) {
			if (leftDone && rightDone) return yield* done();
			const side = yield* pullDecider;
			if (side && leftDone) continue;
			if (!side && rightDone) continue;
			const elem = yield* side ? pullLeft : pullRight;
			if (elem === retry) continue;
			return of(elem);
		}
	});
}))));
/**
* Interrupts the evaluation of this stream when the provided effect
* completes. The given effect will be forked as part of this stream, and its
* success will be discarded. This combinator will also interrupt any
* in-progress element being pulled from upstream.
*
* If the effect completes with a failure before the stream completes, the
* returned stream will emit that failure.
*
* @example
* ```ts
* import { Console, Deferred, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const interrupt = yield* Deferred.make<void>()
*   const stream = Stream.make(1, 2, 3).pipe(
*     Stream.tap((value) =>
*       value === 2
*         ? Deferred.succeed(interrupt, void 0)
*         : Effect.void
*     ),
*     Stream.interruptWhen(Deferred.await(interrupt))
*   )
*
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // => [1, 2]
* ```
*
* @since 2.0.0
* @category Interruption
*/
var interruptWhen = /*#__PURE__*/ dual(2, (self, effect) => fromChannel(interruptWhen$1(self.channel, effect)));
/**
* Halts evaluation after the current element once the provided effect completes; the effect is forked, its success is discarded, failures fail the stream, and it does not interrupt an in-progress pull (use `interruptWhen` for that).
*
* @example
* ```ts
* import { Console, Deferred, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const halt = yield* Deferred.make<void>()
*   const values = yield* Stream.fromArray([1, 2, 3]).pipe(
*     Stream.tap((value) => value === 2 ? Deferred.succeed(halt, void 0) : Effect.void),
*     Stream.haltWhen(Deferred.await(halt)),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output:
* // [1, 2]
* ```
*
* @since 2.0.0
* @category Interruption
*/
var haltWhen = /*#__PURE__*/ dual(2, (self, effect) => fromChannel(haltWhen$1(self.channel, effect)));
/**
* Runs the provided finalizer when the stream exits, passing the exit value.
*
* @example
* ```ts
* import { Console, Effect, Exit, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3).pipe(
*   Stream.onExit((exit) =>
*     Exit.isSuccess(exit)
*       ? Console.log("Stream completed successfully")
*       : Console.log("Stream failed")
*   )
* )
*
* Effect.runPromise(Effect.gen(function*() {
*   yield* Stream.runCollect(stream)
* }))
* // Output:
* // Stream completed successfully
* ```
*
* @since 4.0.0
* @category Finalization
*/
var onExit = /*#__PURE__*/ dual(2, (self, finalizer) => fromChannel(onExit$3(self.channel, finalizer)));
/**
* Runs the provided effect when the stream fails, passing the failure cause.
*
* Note: Unlike `Effect.onError` there is no guarantee that the provided
* effect will not be interrupted.
*
* @example
* ```ts
* import { Cause, Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3).pipe(
*     Stream.concat(Stream.fail("boom")),
*     Stream.onError((cause) => Console.log(`Stream failed: ${Cause.squash(cause)}`))
*   )
*
*   yield* Stream.runCollect(stream)
* })
*
* Effect.runPromiseExit(program)
* // Output:
* // Stream failed: boom
* ```
*
* @since 2.0.0
* @category Error Handling
*/
var onError = /*#__PURE__*/ dual(2, (self, cleanup) => fromChannel(onError$2(self.channel, cleanup)));
/**
* Runs the provided effect before this stream starts.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.fromArray([1, 2, 3]).pipe(
*     Stream.onStart(Console.log("Stream started"))
*   )
*
*   const values = yield* Stream.runCollect(stream)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Output:
* // Stream started
* // [1, 2, 3]
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var onStart = /*#__PURE__*/ dual(2, (self, onStart) => fromChannel(onStart$1(self.channel, onStart)));
/**
* Runs the provided effect with the first element emitted by the stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* Effect.runPromise(Effect.gen(function* () {
*   yield* Stream.fromArray([1, 2, 3]).pipe(
*     Stream.onFirst((value) => Console.log(`first=${value}`)),
*     Stream.runDrain
*   )
* }))
* // Output: first=1
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var onFirst = /*#__PURE__*/ dual(2, (self, onFirst) => fromChannel(onFirst$1(self.channel, (arr) => onFirst(arr[0]))));
/**
* Runs the provided effect when the stream ends successfully.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.make(1, 2, 3).pipe(
*     Stream.onEnd(Console.log("Stream ended")),
*     Stream.runCollect
*   )
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* // Stream ended
* // [1, 2, 3]
* ```
*
* @since 4.0.0
* @category Sequencing
*/
var onEnd = /*#__PURE__*/ dual(2, (self, onEnd) => fromChannel(onEnd$1(self.channel, onEnd)));
/**
* Executes the provided finalizer after this stream's finalizers run.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.fromArray([1, 2]).pipe(
*   Stream.ensuring(Effect.orDie(Console.log("cleanup")))
* )
*
* const program = Effect.gen(function*() {
*   const collected = yield* Stream.runCollect(stream)
*   yield* Console.log(collected)
* })
*
* Effect.runPromise(program)
* //=> cleanup
* //=> [1, 2]
* ```
*
* @since 4.0.0
* @category Finalization
*/
var ensuring = /*#__PURE__*/ dual(2, (self, finalizer) => fromChannel(ensuring$3(self.channel, finalizer)));
/**
* Provides a layer or service map to the stream, removing the corresponding
* service requirements. Use `options.local` to build the layer every time; by
* default, layers are shared between provide calls.
*
* **Previously Known As:** `provideSomeLayer`, `provideSomeContext`.
*
* @example
* ```ts
* import { Console, Effect, Layer, ServiceMap, Stream } from "effect"
*
* class Env extends ServiceMap.Service<Env, { readonly name: string }>()("Env") {}
*
* const layer = Layer.succeed(Env)({ name: "Ada" })
*
* const stream = Stream.fromEffect(
*   Effect.gen(function*() {
*     const env = yield* Effect.service(Env)
*     return `Hello, ${env.name}`
*   })
* )
*
* const withEnv = stream.pipe(Stream.provide(layer))
*
* const program = Stream.runCollect(withEnv).pipe(
*   Effect.flatMap((values) => Console.log(values))
* )
*
* Effect.runPromise(program)
* // Output:
* // ["Hello, Ada"]
* ```
*
* @since 4.0.0
* @category Services
*/
var provide = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, layer, options) => fromChannel(provide$2(self.channel, layer, options)));
/**
* Provides multiple services to the stream using a service map.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap, Stream } from "effect"
*
* class Config extends ServiceMap.Service<Config, { readonly prefix: string }>()("Config") {}
* class Greeter extends ServiceMap.Service<Greeter, { greet: (name: string) => string }>()("Greeter") {}
*
* const services = ServiceMap.make(Config, { prefix: "Hello" }).pipe(
*   ServiceMap.add(Greeter, { greet: (name: string) => `${name}!` })
* )
*
* const stream = Stream.fromEffect(
*   Effect.gen(function*() {
*     const config = yield* Effect.service(Config)
*     const greeter = yield* Effect.service(Greeter)
*     return greeter.greet(config.prefix)
*   })
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(Stream.provideServices(stream, services))
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // ["Hello!"]
* ```
*
* @since 4.0.0
* @category Services
*/
var provideServices = /*#__PURE__*/ dual(2, (self, services) => fromChannel(provideServices$3(self.channel, services)));
/**
* Provides the stream with a single required service, eliminating that
* requirement from its environment.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap, Stream } from "effect"
*
* class Greeter extends ServiceMap.Service<Greeter, {
*   greet: (name: string) => string
* }>()("Greeter") {}
*
* const stream = Stream.fromEffect(
*   Effect.service(Greeter).pipe(
*     Effect.map((greeter) => greeter.greet("Ada"))
*   )
* )
*
* const program = Effect.gen(function*() {
*   const collected = yield* Stream.runCollect(
*     stream.pipe(
*       Stream.provideService(Greeter, {
*         greet: (name) => `Hello, ${name}`
*       })
*     )
*   )
*   yield* Console.log(collected)
* })
*
* Effect.runPromise(program)
* //=> ["Hello, Ada"]
* ```
*
* @since 4.0.0
* @category Services
*/
var provideService = /*#__PURE__*/ dual(3, (self, key, service) => fromChannel(provideService$3(self.channel, key, service)));
/**
* Provides a service to the stream using an effect, removing the requirement and adding the effect's error and environment.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap, Stream } from "effect"
*
* class ApiConfig extends ServiceMap.Service<ApiConfig, { readonly baseUrl: string }>()("ApiConfig") {}
*
* const stream = Stream.fromEffect(
*   Effect.gen(function*() {
*     const config = yield* Effect.service(ApiConfig)
*     return config.baseUrl
*   })
* )
*
* const withConfig = stream.pipe(
*   Stream.provideServiceEffect(
*     ApiConfig,
*     Effect.succeed({ baseUrl: "https://example.com" }).pipe(
*       Effect.tap(() => Console.log("Loading config..."))
*     )
*   )
* )
*
* const program = Stream.runCollect(withConfig).pipe(
*   Effect.flatMap((values) => Console.log(values))
* )
*
* Effect.runPromise(program)
* // Output:
* // Loading config...
* // ["https://example.com"]
* ```
*
* @since 4.0.0
* @category Services
*/
var provideServiceEffect = /*#__PURE__*/ dual(3, (self, key, service) => fromChannel(provideServiceEffect$1(self.channel, key, service)));
/**
* Transforms the stream's required services by mapping the current service map
* to a new one.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap, Stream } from "effect"
*
* class Logger extends ServiceMap.Service<Logger, { prefix: string }>()("Logger") {}
* class Config extends ServiceMap.Service<Config, { name: string }>()("Config") {}
*
* const stream = Stream.fromEffect(
*   Effect.gen(function*() {
*     const logger = yield* Effect.service(Logger)
*     const config = yield* Effect.service(Config)
*     return `${logger.prefix}${config.name}`
*   })
* )
*
* const updated = stream.pipe(
*   Stream.updateServices((services: ServiceMap.ServiceMap<Logger>) =>
*     ServiceMap.add(services, Config, { name: "World" })
*   )
* )
*
* const program = Effect.gen(function*() {
*   const values = yield* Stream.runCollect(updated)
*   yield* Console.log(values)
* })
*
* Effect.runPromise(
*   Effect.provideService(program, Logger, { prefix: "Hello " })
* )
* //=> [ "Hello World" ]
* ```
*
* @since 2.0.0
* @category Services
*/
var updateServices = /*#__PURE__*/ dual(2, (self, f) => fromChannel(updateServices$1(self.channel, f)));
/**
* Updates a single service in the stream environment by applying a function.
*
* @example
* ```ts
* import { Console, Effect, ServiceMap, Stream } from "effect"
*
* class Counter extends ServiceMap.Service<Counter, { count: number }>()("Counter") {}
*
* const stream = Stream.fromEffect(Effect.service(Counter)).pipe(
*   Stream.updateService(Counter, (counter) => ({ count: counter.count + 1 }))
* )
*
* const program = Effect.gen(function*() {
*   const counters = yield* Stream.runCollect(stream)
*   yield* Console.log(`Updated count: ${counters[0].count}`)
* })
*
* Effect.runPromise(Effect.provideService(program, Counter, { count: 0 }))
* // Output: Updated count: 1
* ```
*
* @since 2.0.0
* @category Services
*/
var updateService = /*#__PURE__*/ dual(3, (self, service, f) => updateServices(self, (services) => add(services, service, f(get$3(services, service)))));
/**
* Wraps the stream with a new span for tracing.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.fromArray([1, 2, 3]).pipe(Stream.withSpan("numbers"))
*
* Effect.runPromise(
*   Effect.gen(function*() {
*     const values = yield* Stream.runCollect(stream)
*     yield* Console.log(values)
*   })
* )
* // [1, 2, 3]
* ```
*
* @since 4.0.0
* @category Tracing
*/
var withSpan = function() {
	const dataFirst = isStream(arguments[0]);
	const name = dataFirst ? arguments[1] : arguments[0];
	const options = addSpanStackTrace(dataFirst ? arguments[2] : arguments[1]);
	if (dataFirst) {
		const self = arguments[0];
		return fromChannel(withSpan$1(self.channel, name, options));
	}
	return (self) => fromChannel(withSpan$1(self.channel, name, options));
};
/**
* Provides the entry point for do-notation style stream composition.
*
* @example
* ```ts
* import { Console, Effect, Stream, pipe } from "effect"
*
* const program = pipe(
*   Stream.Do,
*   Stream.bind("value", () => Stream.fromArray([1, 2])),
*   Stream.let("next", ({ value }) => value + 1)
* )
*
* const effect = Effect.gen(function*() {
*   const collected = yield* Stream.runCollect(program)
*   yield* Console.log(collected)
* })
*
* Effect.runPromise(effect)
* //=> [{ value: 1, next: 2 }, { value: 2, next: 3 }]
* ```
*
* @since 4.0.0
* @category Do Notation
*/
var Do = /*#__PURE__*/ succeed({});
var let_ = /*#__PURE__*/ dual(3, (self, name, f) => map(self, (a) => ({
	...a,
	[name]: f(a)
})));
/**
* Binds the result of a stream to a field in the do-notation record.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Stream.Do.pipe(
*   Stream.bind("a", () => Stream.make(1, 2)),
*   Stream.bind("b", ({ a }) => Stream.succeed(a + 1))
* )
*
* const result = Stream.runCollect(program)
*
* Effect.runPromise(Effect.flatMap(result, Console.log))
* // [{ a: 1, b: 2 }, { a: 2, b: 3 }]
* ```
*
* @since 4.0.0
* @category Do Notation
*/
var bind = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, tag, f, options) => flatMap(self, (a) => map(f(a), (b) => ({
	...a,
	[tag]: b
})), options));
/**
* Binds an Effect-produced value into the do-notation record for each stream element.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.Do.pipe(
*   Stream.bind("value", () => Stream.make(1, 2)),
*   Stream.bindEffect("double", ({ value }) => Effect.succeed(value * 2))
* )
*
* const program = Effect.gen(function*() {
*   const result = yield* Stream.runCollect(stream)
*   yield* Console.log(result)
* })
*
* Effect.runPromise(program)
* // [{ value: 1, double: 2 }, { value: 2, double: 4 }]
* ```
*
* @since 4.0.0
* @category Do Notation
*/
var bindEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, tag, f, options) => mapEffect(self, (a) => map$3(f(a), (b) => ({
	...a,
	[tag]: b
})), options));
/**
* Maps each element into a record keyed by the provided name.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3).pipe(Stream.bindTo("value"))
*
* const program = Stream.runCollect(stream).pipe(Effect.flatMap(Console.log))
*
* Effect.runPromise(program)
* // [{ value: 1 }, { value: 2 }, { value: 3 }]
* ```
*
* @category Do Notation
* @since 4.0.0
*/
var bindTo = /*#__PURE__*/ dual(2, (self, name) => map(self, (a) => ({ [name]: a })));
/**
* Runs a stream with a sink and returns the sink result.
*
* @example
* ```ts
* import { Console, Effect, Sink, Stream } from "effect"
*
* const program = Stream.run(Stream.make(1, 2, 3), Sink.sum)
*
* Effect.runPromise(Effect.flatMap(program, Console.log))
* // 6
* ```
*
* @since 2.0.0
* @category Destructors
*/
var run = /*#__PURE__*/ dual(2, (self, sink) => scopedWith((scope) => toPullScoped(self.channel, scope).pipe(flatMap$2((upstream) => sink.transform(upstream, scope)), map$3(([a]) => a))));
/**
* Runs the stream and collects all elements into an array.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
*
* const program = Effect.gen(function*() {
*   const collected = yield* Stream.runCollect(stream)
*   yield* Console.log(collected)
* })
*
* Effect.runPromise(program)
* // [1, 2, 3, 4, 5]
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runCollect = (self) => runFold$1(self.channel, () => [], (acc, chunk) => {
	for (let i = 0; i < chunk.length; i++) acc.push(chunk[i]);
	return acc;
});
/**
* Runs the stream and returns the number of elements emitted.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
*
* const program = Effect.gen(function* () {
*   const count = yield* Stream.runCount(stream)
*   yield* Console.log(count)
* })
*
* Effect.runPromise(program)
* // 5
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runCount = (self) => runFold$1(self.channel, () => 0, (acc, chunk) => acc + chunk.length);
/**
* Runs the stream and returns the numeric sum of its elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const total = yield* Stream.runSum(Stream.make(1, 2, 3))
*   yield* Console.log(total)
* })
*
* Effect.runPromise(program)
* // 6
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runSum = (self) => runFold$1(self.channel, () => 0, (acc, chunk) => {
	for (let i = 0; i < chunk.length; i++) acc += chunk[i];
	return acc;
});
/**
* Runs the stream and folds elements using a pure reducer.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const total = yield* Stream.runFold(
*     Stream.make(1, 2, 3),
*     () => 0,
*     (acc, n) => acc + n
*   )
*   yield* Console.log(total)
* })
*
* Effect.runPromise(program)
* // 6
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runFold = /*#__PURE__*/ dual(3, (self, initial, f) => runFold$1(self.channel, initial, (acc, arr) => {
	for (let i = 0; i < arr.length; i++) acc = f(acc, arr[i]);
	return acc;
}));
/**
* Runs the stream and folds elements using an effectful reducer.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const total = yield* Stream.runFoldEffect(
*     Stream.make(1, 2, 3),
*     () => 0,
*     (acc, n) => Effect.succeed(acc + n)
*   )
*   yield* Console.log(total)
* })
*
* Effect.runPromise(program)
* // 6
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runFoldEffect = /*#__PURE__*/ dual(3, (self, initial, f) => runFoldEffect$1(self.channel, initial, (acc, arr) => {
	let i = 0;
	let s = acc;
	return map$3(whileLoop({
		while: () => i < arr.length,
		body: () => f(s, arr[i]),
		step(z) {
			s = z;
			i++;
		}
	}), () => s);
}));
/**
* Runs the stream and returns the first element as an `Option`.
*
* @example
* ```ts
* import { Console, Effect, Option, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const head = yield* Stream.runHead(Stream.make(1, 2, 3))
*   yield* Console.log(Option.getOrThrow(head))
* })
*
* Effect.runPromise(program)
* // 1
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runHead = (self) => map$3(runHead$1(self.channel), map$2(getUnsafe$1(0)));
/**
* Runs the stream and returns the last element as an `Option`.
*
* @since 2.0.0
* @category Destructors
*/
var runLast = (self) => map$3(runLast$1(self.channel), map$2(lastNonEmpty));
/**
* Runs the provided effectful callback for each element of the stream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const program = Effect.gen(function*() {
*   yield* Stream.runForEach(stream, (n) => Console.log(`Processing: ${n}`))
* })
*
* Effect.runPromise(program)
* // Processing: 1
* // Processing: 2
* // Processing: 3
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runForEach = /*#__PURE__*/ dual(2, (self, f) => runForEach$1(self.channel, (arr) => {
	let i = 0;
	return whileLoop({
		while: () => i < arr.length,
		body: () => f(arr[i++]),
		step: constVoid
	});
}));
/**
* Runs the stream, applying the effectful predicate to each element and
* stopping when it returns `false`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3, 4, 5)
*
*   yield* Stream.runForEachWhile(stream, (n) =>
*     Effect.gen(function*() {
*       yield* Console.log(`Processing: ${n}`)
*       return n < 3
*     })
*   )
* })
*
* Effect.runPromise(program)
* // Processing: 1
* // Processing: 2
* // Processing: 3
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runForEachWhile = /*#__PURE__*/ dual(2, (self, f) => runForEachWhile$1(self.channel, (arr) => {
	let done = false;
	let i = 0;
	return map$3(whileLoop({
		while: () => !done && i < arr.length,
		body: () => f(arr[i]),
		step(b) {
			i++;
			if (!b) done = true;
		}
	}), () => done);
}));
/**
* Consumes the stream in chunks, passing each non-empty array to the callback.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
* const program = Effect.gen(function*() {
*   yield* Stream.runForEachArray(
*     stream,
*     (chunk) => Console.log(`Processing chunk: ${chunk.join(", ")}`)
*   )
* })
*
* Effect.runPromise(program)
* // Processing chunk: 1, 2, 3, 4, 5
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runForEachArray = /*#__PURE__*/ dual(2, (self, f) => runForEach$1(self.channel, f));
/**
* Runs the stream for its effects, discarding emitted elements.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const stream = Stream.make(1, 2, 3).pipe(
*     Stream.mapEffect((n) => Console.log(`Processing: ${n}`))
*   )
*
*   yield* Stream.runDrain(stream)
* })
*
* Effect.runPromise(program)
* // Processing: 1
* // Processing: 2
* // Processing: 3
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runDrain = (self) => runDrain$1(self.channel);
/**
* Returns a scoped pull for manually consuming the stream's output chunks.
*
* The pull fails with `Cause.Done` when the stream ends and with the stream
* error on failure.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const program = Effect.scoped(
*   Effect.gen(function*() {
*     const pull = yield* Stream.toPull(stream)
*     const chunk = yield* pull
*     yield* Console.log(chunk)
*   })
* )
*
* Effect.runPromise(program)
* // [1, 2, 3]
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toPull = (self) => toPull$1(self.channel);
/**
* Concatenates all emitted strings into a single string.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make("Hello", " ", "World", "!")
* const program = Effect.gen(function*() {
*   const text = yield* Stream.mkString(stream)
*   yield* Console.log(text)
* })
*
* Effect.runPromise(program)
* // Hello World!
* ```
*
* @since 2.0.0
* @category Destructors
*/
var mkString = (self) => runFold$1(self.channel, () => "", (acc, chunk) => acc + chunk.join(""));
/**
* Concatenates the stream's `Uint8Array` chunks into a single `Uint8Array`.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(new Uint8Array([1, 2]), new Uint8Array([3, 4]))
* const program = Effect.gen(function*() {
*   const bytes = yield* Stream.mkUint8Array(stream)
*   yield* Console.log([...bytes])
* })
*
* Effect.runPromise(program)
* // [1, 2, 3, 4]
* ```
*
* @since 4.0.0
* @category Destructors
*/
var mkUint8Array = (self) => runFold$1(self.channel, () => /* @__PURE__ */ new Uint8Array(0), (acc, chunk) => {
	let chunkLength = 0;
	for (let i = 0; i < chunk.length; i++) chunkLength += chunk[i].length;
	const result = new Uint8Array(acc.length + chunkLength);
	result.set(acc, 0);
	let offset = acc.length;
	for (let i = 0; i < chunk.length; i++) {
		result.set(chunk[i], offset);
		offset += chunk[i].length;
	}
	return result;
});
/**
* Converts the stream to a `ReadableStream` using the provided services.
*
* See https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream.
*
* @example
* ```ts
* import { ServiceMap, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
* const readableStream = Stream.toReadableStreamWith(stream, ServiceMap.empty())
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toReadableStreamWith = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, services, options) => {
	let currentResolve = void 0;
	let fiber = void 0;
	const latch = makeUnsafe$5(false);
	return new ReadableStream({
		start(controller) {
			fiber = runFork(provideServices$2(runForEachArray(self, (chunk) => latch.whenOpen(sync$2(() => {
				latch.closeUnsafe();
				for (let i = 0; i < chunk.length; i++) controller.enqueue(chunk[i]);
				currentResolve();
				currentResolve = void 0;
			}))), services));
			fiber.addObserver((exit) => {
				if (exit._tag === "Failure") controller.error(squash(exit.cause));
				else controller.close();
			});
		},
		pull() {
			return new Promise((resolve) => {
				currentResolve = resolve;
				latch.openUnsafe();
			});
		},
		cancel() {
			if (!fiber) return;
			return runPromise(asVoid(interrupt$1(fiber)));
		}
	}, options?.strategy);
});
/**
* Converts a stream to a `ReadableStream`.
*
* See https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream.
*
* @example
* ```ts
* import { Stream } from "effect"
*
* const readableStream = Stream.toReadableStream(Stream.make(1, 2, 3))
* const reader = readableStream.getReader()
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toReadableStream = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => toReadableStreamWith(self, empty$2(), options));
/**
* Creates an Effect that builds a ReadableStream from the stream.
*
* See https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3, 4, 5)
*
* const effect = Effect.gen(function*() {
*   const readableStream = yield* Stream.toReadableStreamEffect(stream)
*   yield* Console.log(readableStream instanceof ReadableStream) // true
* })
*
* Effect.runPromise(effect)
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toReadableStreamEffect = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, options) => map$3(services(), (context) => toReadableStreamWith(self, context, options)));
/**
* Converts the stream to an `AsyncIterable` using the provided services.
*
* @example
* ```ts
* import { ServiceMap, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
* const iterable = Stream.toAsyncIterableWith(stream, ServiceMap.empty())
*
* const collect = async () => {
*   const results: Array<number> = []
*   for await (const value of iterable) {
*     results.push(value)
*   }
*   return results
* }
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toAsyncIterableWith = /*#__PURE__*/ dual(2, (self, services) => ({ [Symbol.asyncIterator]() {
	const runPromise = runPromiseWith(services);
	const runPromiseExit = runPromiseExitWith(services);
	const scope = makeUnsafe$2();
	let pull;
	let currentIter;
	return {
		async next() {
			if (currentIter) {
				const next = currentIter.next();
				if (!next.done) return next;
				currentIter = void 0;
			}
			pull ??= await runPromise(toPullScoped(self.channel, scope));
			const exit = await runPromiseExit(pull);
			if (isSuccess(exit)) {
				currentIter = exit.value[Symbol.iterator]();
				return currentIter.next();
			} else if (isDoneCause(exit.cause)) return {
				done: true,
				value: void 0
			};
			throw squash(exit.cause);
		},
		return(_) {
			return runPromise(as$1(close(scope, void_$1), {
				done: true,
				value: void 0
			}));
		}
	};
} }));
/**
* Creates an effect that yields an `AsyncIterable` using the current services.
*
* @example
* ```ts
* import { Console, Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const program = Effect.gen(function*() {
*   const iterable = yield* Stream.toAsyncIterableEffect(stream)
*   const values = yield* Effect.promise(async () => {
*     const collected: Array<number> = []
*     for await (const value of iterable) {
*       collected.push(value)
*     }
*     return collected
*   })
*   yield* Console.log(values)
* })
*
* Effect.runPromise(program)
* //=> [ 1, 2, 3 ]
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toAsyncIterableEffect = (self) => map$3(services(), (services) => toAsyncIterableWith(self, services));
/**
* Converts a stream to an `AsyncIterable` for `for await...of` consumption.
*
* @example
* ```ts
* import { Effect, Stream } from "effect"
*
* const stream = Stream.make(1, 2, 3)
*
* const program = Effect.gen(function* () {
*   const iterable = Stream.toAsyncIterable(stream)
*   const results = yield* Effect.promise(async () => {
*     const values: Array<number> = []
*     for await (const value of iterable) {
*       values.push(value)
*     }
*     return values
*   })
*   return results
* })
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toAsyncIterable = (self) => toAsyncIterableWith(self, empty$2());
/**
* Runs the stream, publishing elements into the provided PubSub.
*
* `shutdownOnEnd` controls whether the PubSub is shut down when the stream ends.
* It only shuts down when set to `true`.
*
* @example
* ```ts
* import { Console, Effect, PubSub, Stream } from "effect"
*
* const program = Effect.scoped(Effect.gen(function* () {
*   const pubsub = yield* PubSub.unbounded<number>()
*   const subscription = yield* PubSub.subscribe(pubsub)
*
*   yield* Stream.runIntoPubSub(Stream.fromIterable([1, 2]), pubsub)
*
*   const first = yield* PubSub.take(subscription)
*   const second = yield* PubSub.take(subscription)
*
*   yield* Console.log(first)
*   yield* Console.log(second)
* }))
*
* Effect.runPromise(program)
* //=> 1
* //=> 2
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runIntoPubSub = /*#__PURE__*/ dual((args) => isStream(args[0]), (self, pubsub, options) => runIntoPubSubArray(self.channel, pubsub, options));
/**
* Converts a stream to a PubSub for concurrent consumption.
*
* `shutdownOnEnd` indicates whether the PubSub should be shut down when the
* stream ends. By default this is `true`.
*
* @example
* ```ts
* import { Console, Effect, PubSub, Stream } from "effect"
*
* const program = Effect.scoped(Effect.gen(function* () {
*   const pubsub = yield* Stream.fromArray([1, 2]).pipe(
*     Stream.toPubSub({ capacity: 8 })
*   )
*   const subscription = yield* PubSub.subscribe(pubsub)
*   const first = yield* PubSub.take(subscription)
*
*   yield* Console.log(first)
* }))
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toPubSub = /*#__PURE__*/ dual(2, (self, options) => toPubSubArray(self.channel, options));
/**
* Converts a stream to a PubSub for concurrent consumption.
*
* `Take` values include the stream's end and failure signals.
*
* @example
* ```ts
* import { Console, Effect, PubSub, Stream } from "effect"
*
* const program = Effect.gen(function* () {
*   const pubsub = yield* Stream.fromArray([1, 2, 3]).pipe(
*     Stream.toPubSubTake({ capacity: 8 })
*   )
*   const subscription = yield* PubSub.subscribe(pubsub)
*   const take = yield* PubSub.take(subscription)
*
*   if (Array.isArray(take)) {
*     yield* Console.log(take)
*   }
* })
* ```
*
* @since 4.0.0
* @category Destructors
*/
var toPubSubTake = /*#__PURE__*/ dual(2, (self, options) => toPubSubTake$1(self.channel, options));
/**
* Converts a stream to a PubSub for concurrent consumption.
*
* @example
* ```ts
* import { Effect, PubSub, Stream } from "effect"
*
* const program = Effect.gen(function* () {
*   const pubSub = yield* Stream.toQueue(Stream.fromIterable([1, 2, 3]), { capacity: 8 })
*   const subscription = yield* PubSub.subscribe(pubSub)
*   return subscription
* })
* ```
*
* @since 2.0.0
* @category Destructors
*/
var toQueue = /*#__PURE__*/ dual(2, (self, options) => toPubSubArray(self.channel, options));
/**
* Runs the stream, offering each element to the provided queue and ending it
* with `Cause.Done` when the stream completes.
*
* @example
* ```ts
* import { Cause, Effect, Queue, Stream } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* Queue.bounded<number, Cause.Done>(4)
*
*   yield* Effect.forkChild(
*     Stream.runIntoQueue(Stream.fromIterable([1, 2, 3]), queue)
*   )
*
*   const values = [
*     yield* Queue.take(queue),
*     yield* Queue.take(queue),
*     yield* Queue.take(queue)
*   ]
*   const done = yield* Effect.flip(Queue.take(queue))
*
*   return { values, done }
* })
* ```
*
* @since 2.0.0
* @category Destructors
*/
var runIntoQueue = /*#__PURE__*/ dual(2, (self, queue) => runIntoQueueArray(self.channel, queue));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/PrimaryKey.js
/**
* This module provides functionality for working with primary keys.
* A `PrimaryKey` is a simple interface that represents a unique identifier
* that can be converted to a string representation.
*
* Primary keys are useful for creating unique identifiers for objects,
* database records, cache keys, or any scenario where you need a
* string-based unique identifier.
*
* @since 2.0.0
*/
var PrimaryKey_exports = /* @__PURE__ */ __exportAll({
	isPrimaryKey: () => isPrimaryKey,
	symbol: () => symbol,
	value: () => value
});
/**
* The unique identifier used to identify objects that implement the `PrimaryKey` interface.
*
* @since 2.0.0
*/
var symbol = "~effect/interfaces/PrimaryKey";
/**
* @category models
* @since 2.0.0
*/
var isPrimaryKey = (u) => hasProperty(u, symbol);
/**
* Extracts the string value from a `PrimaryKey`.
*
* @example
* ```ts
* import { PrimaryKey } from "effect"
*
* class OrderId implements PrimaryKey.PrimaryKey {
*   constructor(private timestamp: number, private sequence: number) {}
*
*   [PrimaryKey.symbol](): string {
*     return `order_${this.timestamp}_${this.sequence}`
*   }
* }
*
* const orderId = new OrderId(1640995200000, 1)
* console.log(PrimaryKey.value(orderId)) // "order_1640995200000_1"
*
* // Can also be used with simple string-based implementations
* const simpleKey = {
*   [PrimaryKey.symbol]: () => "simple-key-123"
* }
* console.log(PrimaryKey.value(simpleKey)) // "simple-key-123"
* ```
*
* @category accessors
* @since 2.0.0
*/
var value = (self) => self[symbol]();
//#endregion
export { fail$1 as A, unwrap as C, invalidate$2 as D, get$2 as E, unwrap$1 as M, make$3 as O, suspend as S, RcMap_exports as T, pipeThroughChannel as _, concat as a, runForEach as b, fromChannel as c, fromPull as d, fromQueue as f, onExit as g, mapError as h, Stream_exports as i, forEach as j, Sink_exports as k, fromEffectRepeat as l, isStream as m, symbol as n, fail as o, fromReadableStream as p, value as r, fromArray as s, PrimaryKey_exports as t, fromPubSub as u, provideServices as v, RcRef_exports as w, runForEachArray as x, run as y };
