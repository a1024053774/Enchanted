import { i as mergePropsN, n as mergeClassNames, r as mergeProps, t as makeEventPreventable } from "./merge-props-BSY6QP_a.js";
export { makeEventPreventable, mergeClassNames, mergeProps, mergePropsN };
