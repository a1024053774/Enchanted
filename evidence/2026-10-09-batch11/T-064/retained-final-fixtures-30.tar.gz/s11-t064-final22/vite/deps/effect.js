import { n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { $ as flow, A as isNull, C as isBoolean, G as coerceUnsafe, I as isString, J as constTrue, L as isSymbol$1, M as isObject, Q as dual, S as isBigInt$1, U as Function_exports, V as isUndefined, W as absurd, X as constVoid, a as equals, at as Pipeable_exports, b as Predicate_exports, et as hole, f as combine, g as string$3, j as isNumber, k as isNotUndefined, l as symbol$1, m as number$2, ot as pipeArguments, p as hash, rt as pipe, t as Equal_exports, tt as identity, u as Hash_exports, w as isDate, x as hasProperty, y as symbol$2 } from "./Equal-CgzkNqbP.js";
import { Bt as isGreaterThan$1, D as mapEntries, Dn as exitFail, E as map$8, Et as some$2, Fn as isExit, G as fail$3, Ht as isLessThan$1, Jn as NodeInspectSymbol, K as failVoid, Kt as max$1, Lt as clamp$1, Nt as Order_exports, Pn as isEffect, Q as isSuccess, Qn as format$1, Tr as make$28, U as Result_exports, Un as Utils_exports, Ut as isLessThanOrEqualTo$1, Vn as withFiber, Vt as isGreaterThanOrEqualTo$1, Yn as toJson, Z as isResult, Zn as Formatter_exports, _r as Equivalence_exports, at as succeed$2, bt as isSome, cr as make$29, ct as flatMap$1, er as formatJson$1, ft as fromUndefinedOr, gt as getOrUndefined, hr as BigInt$2, kn as exitSucceed, kt as BigInt$1, lr as max$2, nr as formatPropertyKey, o as filter$5, ot as Option_exports, pn as YieldableProto, pt as getOrElse, qn as Inspectable_exports, qt as min$1, rr as Redactable_exports, rt as match$2, sn as PipeInspectableProto, sr as Combiner_exports, t as Record_exports, ur as min$2, vt as isNone, wr as Reducer_exports, wt as none, y as isEmptyRecord, zt as isBetween } from "./Record-BrB0racz.js";
import { $c as servicesWith, $o as into, $s as as, $u as empty$7, Ac as forkUnsafe, Ai as String_exports, Ao as provide$1, As as hasInterruptsOnly, At as isEffect$1, Au as isReadonlyArrayNonEmpty, Bc as loggerMake, Bi as Number_exports, Bl as compose, Bn as runPromise, Bo as close, C as callback, Co as Layer_exports, Cs as fail$5, Dc as fnUntraced$1, Di as isDoneCause, Dl as Service$1, Dt as interrupt$1, Ec as flatMap$3, El as Reference, En as repeat, Eo as effect, Fc as ignore, Fn as retryTransaction, Fo as unwrap$1, G as exit, Gc as map$9, Gl as fromInput, Gn as runSyncExit, Go as makeUnsafe$9, Gs as CurrentLoggers$1, Gt as map$11, Hl as toPredicate, Hn as runPromiseExitWith, Hs as ClockRef, I as catch_, Ic as interrupt$2, In as runCallback, Io as Scope, Jo as _await, Js as LogToStderr$1, K as fail$4, Kl as fromInputUnsafe, Kn as runSyncExitWith, Ko as provide$2, Kr as whileLoop, Lc as interruptChildrenPatch, Ll as merge, Ln as runCallbackWith, Lo as Scope_exports, Lr as uninterruptible, Lt as logError, Lu as map$12, Mc as formatLogSpan, Ml as getOption$2, Mo as succeed$5, Mr as transaction, Nc as gen$1, Ni as constantCase$1, Oc as forever, Ol as ServiceMap_exports, Oo as effectServices, Pc as getCurrentFiber, Qc as scopeAddFinalizerExit, Qs as andThen$1, Qt as matchCause, Qu as Iterable_exports, Rn as runFork, Ro as addFinalizer$2, Rr as uninterruptibleMask, Si as Pull_exports, Sl as Tracer_exports, So as CurrentMemoMap, Tl as Scheduler_exports, Tt as ignore$1, Ul as Duration_exports, Un as runPromiseWith, Us as ConsoleRef, V as die, Vl as has$9, Vn as runPromiseExit, Vr as updateServices$1, Vs as squash, Wn as runSync, Wr as void_$1, Xl as isZero, Xo as doneUnsafe, Xr as withFiber$1, Xs as acquireUseRelease, Xt as mapErrorEager, Yc as race$1, Yl as isFinite, Yo as done$1, Ys as acquireRelease, Yt as mapError, Zc as scope, Zs as addFinalizer, _o as Data_exports, _s as Cause_exports, _u as empty$8, a as acquireRelease$1, ac as causePretty, ad as map$10, ai as withTxState, al as suspend$1, ar as services, c as all$1, cc as defaultLogger$1, cl as undefined_, cn as onExit$1, ct as flatMapEager, dc as exit$1, di as request, dl as updateServices, ds as isFailure, ec as asSome, ei as withSpan$1, el as sleep, fi as Request_exports, fl as void_, fs as isSuccess$1, ft as fnUntraced, g as asVoid, gl as CurrentLogSpans, go as Class, gr as tapCause, gs as void_$2, hc as exitVoid, hi as Schedule_exports, hl as CurrentLogAnnotations, hr as tap, hs as succeed$6, id as headUnsafe, il as succeedSome, in as never$2, iu as UndefinedOr_exports, jc as formatLabel, jl as get$16, js as interrupt$3, kc as forkDetach, ki as Cron_exports, ko as makeMemoMapUnsafe, ku as isArrayNonEmpty, l as andThen, ll as uninterruptible$1, lt as flatten, m as as$1, mc as exitIsSuccess, mo as Clock_exports, mr as sync$1, mt as forEach$3, n as Effect_exports, nc as catchCause, nl as succeed$3, o as acquireUseRelease$1, od as Tuple_exports, oi as yieldNow, ol as sync, or as servicesWith$1, os as failCause$1, pc as exitIsFailure, pr as suspend, q as failCause$2, qc as onExit, ql as infinity, qn as runSyncWith, qo as Deferred_exports, rc as catch_$1, rl as succeedNone, rs as Exit_exports, s as addFinalizer$1, sc as consolePretty$1, sl as tracerLogger$1, sr as sleep$1, st as flatMap$2, su as Array_exports, td as filterMap$3, tl as structuredMessage, ts as makeUnsafe$8, tu as toMillis, ui as Metric_exports, ul as uninterruptibleMask$1, ur as succeed$4, vc as fiberAwaitAll, vl as References_exports, vs as Done, vu as ensure, w as catchCause$1, wo as buildWithMemoMap, ws as filterInterruptors, wt as gen, xl as ParentSpan, xn as provideServices, xo as ExecutionPlan_exports, yc as fiberInterrupt, yo as TaggedError, yt as forkScoped, zl as Filter_exports, zn as runForkWith } from "./Effect-DrBRDdmt.js";
import { $a as map$13, $i as add$3, $r as mutableKey, A as Finite, Aa as keys$5, Ar as isStringBigInt, At as Tuple, Ba as toEntries$2, Bi as JsonPatch_exports, Bn as isBetween$1, Br as link, Bt as UndefinedOr, Ca as fromIterable$8, Cn as encodeTo, Co as Encoding_exports, Cr as isPattern, D as ErrorWithStack, Da as hasBy$1, Do as Boolean_exports, Dr as isSchemaError, Dt as Tree, E as ErrorClass, Ea as has$10, Eo as collectBrands, Et as TimeZoneOffset, F as Int, Fa as removeMany$3, Fr as isUUID, Ft as Uint8Array, Ga as appendAll$1, Gi as toJsonSchemaMultiDocument$1, Gn as isDateValid, H as NonEmptyArray, Ha as union$2, Hi as fromASTBlacklist, Hn as isBetweenBigInt, Ia as set$12, In as instanceOf$2, Ja as filter$6, Ji as SchemaParser_exports, Jn as isGreaterThan$2, Ka as drop$1, Ki as JsonPointer_exports, Kn as isEndsWith, Kt as Void, L as Literal, La as setMany$1, Ln as is$2, Lr as isUncapitalized, M as FormData, Ma as map$14, Mr as isStringSymbol, Mt as URL, N as HashMap, Na as reduce$4, Nr as isTrimmed, O as Exit, Oa as hasHash$1, Oo as BigDecimal_exports, Or as isSizeBetween, P as HashSet, Pa as remove$7, Pn as fromJsonString, Pr as isULID, Pt as URLSearchParams, Qa as isNonEmpty$3, Qi as HashSet_exports, Qn as isGreaterThanOrEqualTo$2, R as Literals, Ra as size$13, Ri as Optic_exports, Rn as isBase64, Rr as isUnique, Sa as findFirst$1, St as TemplateLiteral, T as Error$1, Ta as getHash$1, To as RegExp_exports, Tr as isPropertyNames, Tt as TimeZoneNamed, U as NonEmptyString, Ua as Chunk_exports, Ui as fromASTs$1, Un as isBetweenDate, Ur as makeFilterGroup, Ut as UniqueSymbol, V as Never, Va as toValues$1, Vi as fromAST$1, Vt as Union, W as Null, Wa as append$1, Wi as toJsonSchemaDocument$1, Wn as isCapitalized, Wt as Unknown, Xa as head, Xi as decodeUnknownEffect, Xn as isGreaterThanBigInt, Y as ObjectKeyword, Ya as fromIterable$7, Yi as _is, Z as Option, Za as isEmpty$8, Zi as Struct_exports, Zn as isGreaterThanDate, _ as DateTimeZoned, _a as compact$3, _n as encodeEffect, _o as transformOrFail, _r as isMaxSize, _t as Symbol$1, a as Boolean$1, aa as has$11, an as decodeEffect, ar as isLengthBetween, at as ReadonlySet, ba as filter$7, bi as toCodecStringTree, bo as SchemaIssue_exports, br as isMinSize, c as CauseReason, ca as isSubset$1, cr as isLessThanBigInt, da as reduce$5, do as splitKeyValue, dt as SchemaError, ea as difference$1, ei as optional, eo as prepend$1, er as isGreaterThanOrEqualToBigInt, f as Date$1, fa as remove$8, fo as transform, fr as isLessThanOrEqualToBigInt, ft as Schema_exports, ga as HashMap_exports, go as transformOptional, gr as isMaxProperties, gt as StructWithRest, ha as union$3, ho as passthrough, hr as isMaxLength, ht as Struct, i as BigInt$3, ia as fromIterable$9, io as toArray$1, it as ReadonlyMap, ja as make$30, jr as isStringFinite, jt as TupleWithRest, k as File, ka as isEmpty$9, kr as isStartsWith, la as make$31, lo as toEncoded, lr as isLessThanDate, lt as RegExp$1, ma as some$4, mi as tag$2, mo as forbidden, mr as isLowercased, mt as String$1, n as Array$1, na as every$3, no as size$12, nr as isIncludes, oa as intersection$1, oo as SchemaAST_exports, or as isLessThan$2, ot as Record$1, p as DateTimeUtc, pa as size$14, pi as suspend$2, po as SchemaGetter_exports, pr as isLessThanOrEqualToDate, q as Number$1, qa as empty$9, qi as unescapeToken, qn as isFinite$1, r as BigDecimal, ra as filter$8, ro as take$3, rr as isInt, rt as PropertyKey, s as Cause, sa as isEmpty$10, st as Redacted, t as Any, ta as empty$11, ti as optionalKey, to as prependAll$1, tr as isGreaterThanOrEqualToDate, u as Chunk, ua as map$15, un as decodeTo, uo as SchemaTransformation_exports, ur as isLessThanOrEqualTo$2, ut as Result, v as DateValid, va as empty$10, vo as InvalidValue, vr as isMinLength, w as Enum, wa as get$17, wo as DateTime_exports, wr as isPropertiesLengthBetween, wt as TimeZone, x as Duration$1, xa as filterMap$4, xo as Redacted_exports, xr as isMultipleOf, y as Defect, ya as every$2, yi as toCodecJson, yo as Pointer, yr as isMinProperties, za as some$3, zi as JsonSchema_exports, zn as isBase64Url, zr as isUppercased, zt as Undefined } from "./Schema-DuK_yWH0.js";
import { _ as Brand_exports, d as Path, f as Path_exports, g as PlatformError_exports, l as LogLevel_exports, m as FileSystem_exports, n as Stdio_exports, p as FileSystem, r as Pool_exports, s as ErrorReporter_exports, u as values$6 } from "./Stdio-Be9al6EE.js";
import { Bn as runIn, Fn as interruptAll, Gn as get$18, Gt as Take_exports, Hn as clear$7, In as interruptAllAs, Jn as make$32, Jt as makeUnsafe$10, Kn as has$12, Kt as Semaphore_exports, Ln as interruptAs, Mn as await_$1, Nn as getCurrent, Qn as values$7, U as fromTransform, Un as empty$12, Vn as MutableHashMap_exports, Wn as fromIterable$10, Xn as set$13, Yn as remove$9, Yt as Queue_exports, Zn as size$15, _n as MutableRef_exports, bn as MutableList_exports, fn as PubSub_exports, gn as unbounded$2, hn as publishUnsafe, jn as Fiber_exports, kn as Latch_exports, pn as publish$1, qn as keys$6, t as Channel_exports, ut as pipeTo, vn as make$33, yn as set$14 } from "./Channel-BalfMI2y.js";
import { C as unwrap$2, D as invalidate$2, E as get$19, O as make$34, T as RcMap_exports, i as Stream_exports, k as Sink_exports, l as fromEffectRepeat, r as value$2, t as PrimaryKey_exports, u as fromPubSub, w as RcRef_exports } from "./PrimaryKey-BilJj_MP.js";
import { t as FiberSet_exports } from "./FiberSet-CV_RhfQA.js";
import { t as Random_exports } from "./effect_Random.js";
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/BigInt.js
/**
* This module provides utility functions and type class instances for working with the `bigint` type in TypeScript.
* It includes functions for basic arithmetic operations.
*
* @since 2.0.0
*/
var BigInt_exports = /* @__PURE__ */ __exportAll({
	BigInt: () => BigInt,
	CombinerMax: () => CombinerMax,
	CombinerMin: () => CombinerMin,
	Equivalence: () => Equivalence,
	Order: () => Order,
	ReducerMultiply: () => ReducerMultiply,
	ReducerSum: () => ReducerSum,
	abs: () => abs,
	between: () => between,
	clamp: () => clamp,
	decrement: () => decrement,
	divide: () => divide,
	divideUnsafe: () => divideUnsafe,
	fromNumber: () => fromNumber,
	fromString: () => fromString,
	gcd: () => gcd,
	increment: () => increment,
	isBigInt: () => isBigInt,
	isGreaterThan: () => isGreaterThan,
	isGreaterThanOrEqualTo: () => isGreaterThanOrEqualTo,
	isLessThan: () => isLessThan,
	isLessThanOrEqualTo: () => isLessThanOrEqualTo,
	lcm: () => lcm,
	max: () => max,
	min: () => min,
	multiply: () => multiply,
	multiplyAll: () => multiplyAll,
	remainder: () => remainder,
	sign: () => sign,
	sqrt: () => sqrt,
	sqrtUnsafe: () => sqrtUnsafe,
	subtract: () => subtract,
	sum: () => sum,
	sumAll: () => sumAll,
	toNumber: () => toNumber
});
/**
* Reference to the global BigInt constructor.
*
* @example
* ```ts
* import * as BigInt from "effect/BigInt"
*
* const bigInt = BigInt.BigInt(123)
* console.log(bigInt) // 123n
*
* const fromString = BigInt.BigInt("456")
* console.log(fromString) // 456n
* ```
*
* @category constructors
* @since 4.0.0
*/
var BigInt = globalThis.BigInt;
var bigint0 = /*#__PURE__*/ BigInt(0);
var bigint1 = /*#__PURE__*/ BigInt(1);
var bigint2 = /*#__PURE__*/ BigInt(2);
/**
* Tests if a value is a `bigint`.
*
* @example
* ```ts
* import { isBigInt } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isBigInt(1n), true)
* assert.deepStrictEqual(isBigInt(1), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isBigInt = isBigInt$1;
/**
* Provides an addition operation on `bigint`s.
*
* @example
* ```ts
* import { sum } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sum(2n, 3n), 5n)
* ```
*
* @category math
* @since 2.0.0
*/
var sum = /*#__PURE__*/ dual(2, (self, that) => self + that);
/**
* Provides a multiplication operation on `bigint`s.
*
* @example
* ```ts
* import { multiply } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(multiply(2n, 3n), 6n)
* ```
*
* @category math
* @since 2.0.0
*/
var multiply = /*#__PURE__*/ dual(2, (self, that) => self * that);
/**
* Provides a subtraction operation on `bigint`s.
*
* @example
* ```ts
* import { subtract } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(subtract(2n, 3n), -1n)
* ```
*
* @category math
* @since 2.0.0
*/
var subtract = /*#__PURE__*/ dual(2, (self, that) => self - that);
/**
* Provides a division operation on `bigint`s.
*
* If the dividend is not a multiple of the divisor the result will be a `bigint` value
* which represents the integer division rounded down to the nearest integer.
*
* Returns `undefined` if the divisor is `0n`.
*
* @example
* ```ts
* import { divide } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(divide(6n, 3n), 2n)
* assert.deepStrictEqual(divide(6n, 0n), undefined)
* ```
*
* @category math
* @since 2.0.0
*/
var divide = /*#__PURE__*/ dual(2, (self, that) => that === bigint0 ? void 0 : self / that);
/**
* Provides a division operation on `bigint`s.
*
* If the dividend is not a multiple of the divisor the result will be a `bigint` value
* which represents the integer division rounded down to the nearest integer.
*
* Throws a `RangeError` if the divisor is `0n`.
*
* @example
* ```ts
* import { divideUnsafe } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(divideUnsafe(6n, 3n), 2n)
* assert.deepStrictEqual(divideUnsafe(6n, 4n), 1n)
* ```
*
* @category math
* @since 2.0.0
*/
var divideUnsafe = /*#__PURE__*/ dual(2, (self, that) => self / that);
/**
* Returns the result of adding `1n` to a given number.
*
* @example
* ```ts
* import { increment } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(increment(2n), 3n)
* ```
*
* @category math
* @since 2.0.0
*/
var increment = (n) => n + bigint1;
/**
* Decrements a number by `1n`.
*
* @example
* ```ts
* import { decrement } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(decrement(3n), 2n)
* ```
*
* @category math
* @since 2.0.0
*/
var decrement = (n) => n - bigint1;
/**
* Provides an `Order` instance for `bigint` that allows comparing and sorting BigInt values.
*
* @example
* ```ts
* import * as BigInt from "effect/BigInt"
*
* const a = 123n
* const b = 456n
* const c = 123n
*
* console.log(BigInt.Order(a, b)) // -1 (a < b)
* console.log(BigInt.Order(b, a)) // 1 (b > a)
* console.log(BigInt.Order(a, c)) // 0 (a === c)
* ```
*
* @category instances
* @since 2.0.0
*/
var Order = BigInt$1;
/**
* An `Equivalence` instance for bigints using strict equality (`===`).
*
* @example
* ```ts
* import { BigInt } from "effect"
*
* console.log(BigInt.Equivalence(1n, 1n)) // true
* console.log(BigInt.Equivalence(1n, 2n)) // false
* ```
*
* @category instances
* @since 4.0.0
*/
var Equivalence = BigInt$2;
/**
* Returns `true` if the first argument is less than the second, otherwise `false`.
*
* @example
* ```ts
* import { isLessThan } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isLessThan(2n, 3n), true)
* assert.deepStrictEqual(isLessThan(3n, 3n), false)
* assert.deepStrictEqual(isLessThan(4n, 3n), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isLessThan = /*#__PURE__*/ isLessThan$1(Order);
/**
* Returns a function that checks if a given `bigint` is less than or equal to the provided one.
*
* @example
* ```ts
* import { isLessThanOrEqualTo } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isLessThanOrEqualTo(2n, 3n), true)
* assert.deepStrictEqual(isLessThanOrEqualTo(3n, 3n), true)
* assert.deepStrictEqual(isLessThanOrEqualTo(4n, 3n), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isLessThanOrEqualTo = /*#__PURE__*/ isLessThanOrEqualTo$1(Order);
/**
* Returns `true` if the first argument is greater than the second, otherwise `false`.
*
* @example
* ```ts
* import { isGreaterThan } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isGreaterThan(2n, 3n), false)
* assert.deepStrictEqual(isGreaterThan(3n, 3n), false)
* assert.deepStrictEqual(isGreaterThan(4n, 3n), true)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isGreaterThan = /*#__PURE__*/ isGreaterThan$1(Order);
/**
* Returns a function that checks if a given `bigint` is greater than or equal to the provided one.
*
* @example
* ```ts
* import { isGreaterThanOrEqualTo } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(isGreaterThanOrEqualTo(2n, 3n), false)
* assert.deepStrictEqual(isGreaterThanOrEqualTo(3n, 3n), true)
* assert.deepStrictEqual(isGreaterThanOrEqualTo(4n, 3n), true)
* ```
*
* @category predicates
* @since 2.0.0
*/
var isGreaterThanOrEqualTo = /*#__PURE__*/ isGreaterThanOrEqualTo$1(Order);
/**
* Checks if a `bigint` is between a `minimum` and `maximum` value (inclusive).
*
* @example
* ```ts
* import * as BigInt from "effect/BigInt"
* import * as assert from "node:assert"
*
* const between = BigInt.between({ minimum: 0n, maximum: 5n })
*
* assert.deepStrictEqual(between(3n), true)
* assert.deepStrictEqual(between(-1n), false)
* assert.deepStrictEqual(between(6n), false)
* ```
*
* @category predicates
* @since 2.0.0
*/
var between = /*#__PURE__*/ isBetween(Order);
/**
* Restricts the given `bigint` to be within the range specified by the `minimum` and `maximum` values.
*
* - If the `bigint` is less than the `minimum` value, the function returns the `minimum` value.
* - If the `bigint` is greater than the `maximum` value, the function returns the `maximum` value.
* - Otherwise, it returns the original `bigint`.
*
* @example
* ```ts
* import * as BigInt from "effect/BigInt"
* import * as assert from "node:assert"
*
* const clamp = BigInt.clamp({ minimum: 1n, maximum: 5n })
*
* assert.equal(clamp(3n), 3n)
* assert.equal(clamp(0n), 1n)
* assert.equal(clamp(6n), 5n)
* ```
*
* @category math
* @since 2.0.0
*/
var clamp = /*#__PURE__*/ clamp$1(Order);
/**
* Returns the minimum between two `bigint`s.
*
* @example
* ```ts
* import { min } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(min(2n, 3n), 2n)
* ```
*
* @category math
* @since 2.0.0
*/
var min = /*#__PURE__*/ min$1(Order);
/**
* Returns the maximum between two `bigint`s.
*
* @example
* ```ts
* import { max } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(max(2n, 3n), 3n)
* ```
*
* @category math
* @since 2.0.0
*/
var max = /*#__PURE__*/ max$1(Order);
/**
* Determines the sign of a given `bigint`.
*
* @example
* ```ts
* import { sign } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sign(-5n), -1)
* assert.deepStrictEqual(sign(0n), 0)
* assert.deepStrictEqual(sign(5n), 1)
* ```
*
* @category math
* @since 2.0.0
*/
var sign = (n) => BigInt$1(n, bigint0);
/**
* Determines the absolute value of a given `bigint`.
*
* @example
* ```ts
* import { abs } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(abs(-5n), 5n)
* assert.deepStrictEqual(abs(0n), 0n)
* assert.deepStrictEqual(abs(5n), 5n)
* ```
*
* @category math
* @since 2.0.0
*/
var abs = (n) => n < bigint0 ? -n : n;
/**
* Determines the greatest common divisor of two `bigint`s.
*
* @example
* ```ts
* import { gcd } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(gcd(2n, 3n), 1n)
* assert.deepStrictEqual(gcd(2n, 4n), 2n)
* assert.deepStrictEqual(gcd(16n, 24n), 8n)
* ```
*
* @category math
* @since 2.0.0
*/
var gcd = /*#__PURE__*/ dual(2, (self, that) => {
	while (that !== bigint0) {
		const t = that;
		that = self % that;
		self = t;
	}
	return self;
});
/**
* Determines the least common multiple of two `bigint`s.
*
* @example
* ```ts
* import { lcm } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(lcm(2n, 3n), 6n)
* assert.deepStrictEqual(lcm(2n, 4n), 4n)
* assert.deepStrictEqual(lcm(16n, 24n), 48n)
* ```
*
* @category math
* @since 2.0.0
*/
var lcm = /*#__PURE__*/ dual(2, (self, that) => self * that / gcd(self, that));
/**
* Determines the square root of a given `bigint` unsafely. Throws if the given `bigint` is negative.
*
* @example
* ```ts
* import { sqrtUnsafe } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sqrtUnsafe(4n), 2n)
* assert.deepStrictEqual(sqrtUnsafe(9n), 3n)
* assert.deepStrictEqual(sqrtUnsafe(16n), 4n)
* ```
*
* @category math
* @since 2.0.0
*/
var sqrtUnsafe = (n) => {
	if (n < bigint0) throw new RangeError("Cannot take the square root of a negative number");
	if (n < bigint2) return n;
	let x = n / bigint2;
	while (x * x > n) x = (n / x + x) / bigint2;
	return x;
};
/**
* Determines the square root of a given `bigint` safely. Returns `undefined` if
* the given `bigint` is negative.
*
* **Example**
*
* ```ts
* import { BigInt } from "effect"
*
* BigInt.sqrt(4n) // 2n
* BigInt.sqrt(9n) // 3n
* BigInt.sqrt(16n) // 4n
* BigInt.sqrt(-1n) // undefined
* ```
*
* @category math
* @since 2.0.0
*/
var sqrt = (n) => isGreaterThanOrEqualTo(n, bigint0) ? sqrtUnsafe(n) : void 0;
/**
* Takes an `Iterable` of `bigint`s and returns their sum as a single `bigint
*
* @example
* ```ts
* import { sumAll } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(sumAll([2n, 3n, 4n]), 9n)
* ```
*
* @category math
* @since 2.0.0
*/
var sumAll = (collection) => {
	let out = bigint0;
	for (const n of collection) out += n;
	return out;
};
/**
* Takes an `Iterable` of `bigint`s and returns their multiplication as a single `number`.
*
* @example
* ```ts
* import { multiplyAll } from "effect/BigInt"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(multiplyAll([2n, 3n, 4n]), 24n)
* ```
*
* @category math
* @since 2.0.0
*/
var multiplyAll = (collection) => {
	let out = bigint1;
	for (const n of collection) {
		if (n === bigint0) return bigint0;
		out *= n;
	}
	return out;
};
/**
* Converts a `bigint` to a `number`.
*
* If the `bigint` is outside the safe integer range for JavaScript (`Number.MAX_SAFE_INTEGER`
* and `Number.MIN_SAFE_INTEGER`), it returns `undefined`
*
* @example
* ```ts
* import { BigInt as BI } from "effect"
*
* BI.toNumber(42n) // 42
* BI.toNumber(BigInt(Number.MAX_SAFE_INTEGER) + 1n) // undefined
* BI.toNumber(BigInt(Number.MIN_SAFE_INTEGER) - 1n) // undefined
* ```
*
* @category conversions
* @since 2.0.0
*/
var toNumber = (b) => {
	if (b > BigInt(Number.MAX_SAFE_INTEGER) || b < BigInt(Number.MIN_SAFE_INTEGER)) return;
	return Number(b);
};
/**
* Converts a string to a `bigint`.
*
* If the string is empty or contains characters that cannot be converted into a
* `bigint`, it returns `undefined`.
*
* @example
* ```ts
* import { BigInt } from "effect"
*
* BigInt.fromString("42") // 42n
* BigInt.fromString(" ") // undefined
* BigInt.fromString("a") // undefined
* ```
*
* @category conversions
* @since 2.4.12
*/
var fromString = (s) => {
	try {
		return s.trim() === "" ? void 0 : BigInt(s);
	} catch {
		return;
	}
};
/**
* Converts a number to a `bigint`.
*
* If the number is outside the safe integer range for JavaScript
* (`Number.MAX_SAFE_INTEGER` and `Number.MIN_SAFE_INTEGER`) or if the number is
* not a valid `bigint`, it returns `undefined`.
*
* @example
* ```ts
* import { BigInt } from "effect"
*
* BigInt.fromNumber(42) // 42n
*
* BigInt.fromNumber(Number.MAX_SAFE_INTEGER + 1) // undefined
* BigInt.fromNumber(Number.MIN_SAFE_INTEGER - 1) // undefined
* ```
*
* @category conversions
* @since 2.4.12
*/
function fromNumber(n) {
	if (n > Number.MAX_SAFE_INTEGER || n < Number.MIN_SAFE_INTEGER) return;
	try {
		return BigInt(n);
	} catch {
		return;
	}
}
/**
* Returns the remainder of dividing the first `bigint` by the second `bigint`.
*
* @example
* ```ts
* import { BigInt } from "effect"
*
* BigInt.remainder(10n, 3n) // 1n
*
* BigInt.remainder(15n, 4n) // 3n
* ```
*
* @category math
* @since 4.0.0
*/
var remainder = /*#__PURE__*/ dual(2, (self, divisor) => self % divisor);
/**
* A `Reducer` for combining `bigint`s using addition.
*
* @since 4.0.0
*/
var ReducerSum = /*#__PURE__*/ make$28((a, b) => a + b, 0n);
/**
* A `Reducer` for combining `bigint`s using multiplication.
*
* @since 4.0.0
*/
var ReducerMultiply = /*#__PURE__*/ make$28((a, b) => a * b, 1n, (collection) => {
	let acc = 1n;
	for (const n of collection) {
		if (n === 0n) return 0n;
		acc *= n;
	}
	return acc;
});
/**
* A `Combiner` that returns the maximum `bigint`.
*
* @since 4.0.0
*/
var CombinerMax = /*#__PURE__*/ max$2(Order);
/**
* A `Combiner` that returns the minimum `bigint`.
*
* @since 4.0.0
*/
var CombinerMin = /*#__PURE__*/ min$2(Order);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Cache.js
/**
* @since 4.0.0
*/
var Cache_exports = /* @__PURE__ */ __exportAll({
	entries: () => entries$5,
	get: () => get$15,
	getOption: () => getOption$1,
	getSuccess: () => getSuccess$1,
	has: () => has$8,
	invalidate: () => invalidate$1,
	invalidateAll: () => invalidateAll$1,
	invalidateWhen: () => invalidateWhen$1,
	keys: () => keys$4,
	make: () => make$27,
	makeWith: () => makeWith$2,
	refresh: () => refresh$2,
	set: () => set$11,
	size: () => size$11,
	values: () => values$5
});
var TypeId$28 = "~effect/Cache";
/**
* Creates a cache with dynamic time-to-live based on the result and key.
*
* The timeToLive function receives both the exit result and the key, allowing
* for flexible TTL policies based on success/failure state and key characteristics.
*
* @example
* ```ts
* import { Cache, Effect, Exit } from "effect"
*
* // Cache with different TTL for success vs failure
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.makeWith<string, number, string>({
*     capacity: 100,
*     lookup: (key) =>
*       key === "fail"
*         ? Effect.fail("error")
*         : Effect.succeed(key.length),
*     timeToLive: (exit, key) => {
*       if (Exit.isFailure(exit)) return "1 minute" // Short TTL for errors
*       return key.startsWith("temp") ? "5 minutes" : "1 hour"
*     }
*   })
*
*   // Get values with different TTL policies
*   const result1 = yield* Cache.get(cache, "hello")
*   const result2 = yield* Cache.get(cache, "temp_data")
*   console.log({ result1, result2 }) // { result1: 5, result2: 9 }
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect, Exit } from "effect"
*
* // Cache with TTL based on computed value
* const userCache = Effect.gen(function*() {
*   const cache = yield* Cache.makeWith<
*     number,
*     { id: number; active: boolean },
*     never
*   >({
*     capacity: 1000,
*     lookup: (id) => Effect.succeed({ id, active: id % 2 === 0 }),
*     timeToLive: (exit) => {
*       if (Exit.isSuccess(exit)) {
*         const user = exit.value
*         return user.active ? "1 hour" : "5 minutes"
*       }
*       return "30 seconds"
*     }
*   })
*
*   return cache
* })
* ```
*
* @since 4.0.0
* @category Constructors
*/
var makeWith$2 = (options) => servicesWith((services) => {
	const self = Object.create(Proto$10);
	self.lookup = (key) => updateServices(options.lookup(key), (input) => merge(services, input));
	self.map = make$32();
	self.capacity = options.capacity;
	self.timeToLive = options.timeToLive ? (exit, key) => fromInputUnsafe(options.timeToLive(exit, key)) : defaultTimeToLive$1;
	return succeed$3(self);
});
/**
* Creates a cache with a fixed time-to-live for all entries.
*
* This is the basic cache constructor where all entries share the same TTL.
* The lookup function will be called when a key is not found or has expired.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Basic cache with string keys
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make<string, number>({
*     capacity: 100,
*     lookup: (key) => Effect.succeed(key.length)
*   })
*
*   const result1 = yield* Cache.get(cache, "hello")
*   const result2 = yield* Cache.get(cache, "world")
*   console.log({ result1, result2 }) // { result1: 5, result2: 5 }
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Cache with TTL and async lookup
* const fetchUserCache = Effect.gen(function*() {
*   const cache = yield* Cache.make<
*     number,
*     { name: string; email: string },
*     string
*   >({
*     capacity: 500,
*     lookup: (userId) =>
*       Effect.tryPromise({
*         try: () => fetch(`/api/users/${userId}`).then((r) => r.json()),
*         catch: () => "Failed to fetch user"
*       }),
*     timeToLive: "15 minutes"
*   })
*
*   // First call fetches from API, second call returns cached result
*   const user1 = yield* Cache.get(cache, 123)
*   const user2 = yield* Cache.get(cache, 123) // From cache
*   return { user1, user2 }
* })
* ```
*
* @since 4.0.0
* @category Constructors
*/
var make$27 = (options) => makeWith$2({
	...options,
	timeToLive: options.timeToLive ? () => options.timeToLive : defaultTimeToLive$1
});
var Proto$10 = {
	...PipeInspectableProto,
	[TypeId$28]: TypeId$28,
	toJSON() {
		return {
			_id: "Cache",
			capacity: this.capacity,
			map: this.map
		};
	}
};
var defaultTimeToLive$1 = (_, _key) => infinity;
/**
* Retrieves the value associated with the specified key from the cache.
*
* If the key is not present or has expired, it will invoke the lookup function
* to construct the value, store it in the cache, and return it.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Cache miss - triggers lookup function
*   const result1 = yield* Cache.get(cache, "hello")
*   console.log(result1) // 5
*
*   // Cache hit - returns cached value without lookup
*   const result2 = yield* Cache.get(cache, "hello")
*   console.log(result2) // 5 (from cache)
*
*   return { result1, result2 }
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Error handling when lookup fails
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make<string, number, string>({
*     capacity: 10,
*     lookup: (key: string) =>
*       key === "error"
*         ? Effect.fail("Lookup failed")
*         : Effect.succeed(key.length)
*   })
*
*   // Successful lookup
*   const success = yield* Cache.get(cache, "hello")
*   console.log(success) // 5
*
*   // Failed lookup - returns error
*   const failure = yield* Effect.exit(Cache.get(cache, "error"))
*   console.log(failure) // Exit.fail("Lookup failed")
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Concurrent access - multiple gets of same key only invoke lookup once
* const program = Effect.gen(function*() {
*   let lookupCount = 0
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) =>
*       Effect.sync(() => {
*         lookupCount++
*         return key.length
*       })
*   })
*
*   // Multiple concurrent gets
*   const results = yield* Effect.all([
*     Cache.get(cache, "hello"),
*     Cache.get(cache, "hello"),
*     Cache.get(cache, "hello")
*   ], { concurrency: "unbounded" })
*
*   console.log(results) // [5, 5, 5]
*   console.log(lookupCount) // 1 (lookup called only once)
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var get$15 = /*#__PURE__*/ dual(2, (self, key) => withFiber((fiber) => {
	const oentry = get$18(self.map, key);
	if (isSome(oentry) && !hasExpired$1(oentry.value, fiber)) {
		remove$9(self.map, key);
		set$13(self.map, key, oentry.value);
		return _await(oentry.value.deferred);
	}
	const deferred = makeUnsafe$8();
	const entry = {
		expiresAt: void 0,
		deferred
	};
	set$13(self.map, key, entry);
	if (Number.isFinite(self.capacity)) checkCapacity$1(self);
	return onExit(self.lookup(key), (exit) => {
		doneUnsafe(deferred, exit);
		const ttl = self.timeToLive(exit, key);
		if (isFinite(ttl)) entry.expiresAt = fiber.getRef(ClockRef).currentTimeMillisUnsafe() + toMillis(ttl);
		else if (isZero(ttl)) remove$9(self.map, key);
		return void_;
	});
}));
var hasExpired$1 = (entry, fiber) => {
	if (entry.expiresAt === void 0) return false;
	return fiber.getRef(ClockRef).currentTimeMillisUnsafe() >= entry.expiresAt;
};
var checkCapacity$1 = (self) => {
	let diff = size$15(self.map) - self.capacity;
	if (diff <= 0) return;
	for (const [key] of self.map) {
		remove$9(self.map, key);
		diff--;
		if (diff === 0) return;
	}
};
/**
* Retrieves the value associated with the specified key from the cache,
* returning an `Option` that is `Some` if the key exists and has not expired,
* or `None` if the key does not exist or has expired.
*
* Unlike `get`, this function will not invoke the lookup function if the key
* is missing or expired.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // No value in cache yet - returns None without lookup
*   const empty = yield* Cache.getOption(cache, "hello")
*   console.log(empty) // Option.none()
*
*   // Populate cache using get
*   yield* Cache.get(cache, "hello")
*
*   // Now getOption returns the cached value
*   const cached = yield* Cache.getOption(cache, "hello")
*   console.log(cached) // Option.some(5)
*
*   return { empty, cached }
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
* import { TestClock } from "effect/testing"
*
* // Expired entries return None
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length),
*     timeToLive: "1 hour"
*   })
*
*   // Add value to cache
*   yield* Cache.get(cache, "hello")
*
*   // Value exists before expiration
*   const beforeExpiry = yield* Cache.getOption(cache, "hello")
*   console.log(beforeExpiry) // Option.some(5)
*
*   // Simulate time passing
*   yield* TestClock.adjust("2 hours")
*
*   // Value expired - returns None
*   const afterExpiry = yield* Cache.getOption(cache, "hello")
*   console.log(afterExpiry) // Option.none()
* })
* ```
*
* @example
* ```ts
* import { Cache, Deferred, Effect, Fiber } from "effect"
*
* // Waits for ongoing computation to complete
* const program = Effect.gen(function*() {
*   const deferred = yield* Deferred.make<void>()
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (_key: string) => Deferred.await(deferred).pipe(Effect.as(42))
*   })
*
*   // Start lookup in background
*   const getFiber = yield* Effect.forkChild(Cache.get(cache, "key"))
*
*   // getOption waits for ongoing computation
*   const optionFiber = yield* Effect.forkChild(Cache.getOption(cache, "key"))
*
*   // Complete the computation
*   yield* Deferred.succeed(deferred, void 0)
*
*   const result = yield* Fiber.join(optionFiber)
*   console.log(result) // Option.some(42)
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var getOption$1 = /*#__PURE__*/ dual(2, (self, key) => withFiber((fiber) => {
	const entry = getImpl$1(self, key, fiber);
	return entry ? asSome(_await(entry.deferred)) : succeedNone;
}));
var getImpl$1 = (self, key, fiber, isRead = true) => {
	const oentry = get$18(self.map, key);
	if (isNone(oentry)) return;
	else if (hasExpired$1(oentry.value, fiber)) {
		remove$9(self.map, key);
		return;
	} else if (isRead) {
		remove$9(self.map, key);
		set$13(self.map, key, oentry.value);
	}
	return oentry.value;
};
/**
* Retrieves the value associated with the specified key from the cache, only if
* it contains a resolved successful value.
*
* @since 4.0.0
* @category Combinators
*/
var getSuccess$1 = /*#__PURE__*/ dual(2, (self, key) => withFiber((fiber) => {
	const exit = getImpl$1(self, key, fiber)?.deferred.effect;
	if (exit && exitIsSuccess(exit)) return succeedSome(exit.value);
	return succeedNone;
}));
/**
* Sets the value associated with the specified key in the cache. This will
* overwrite any existing value for that key, skipping the lookup function.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 100,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Set a value directly without invoking lookup
*   yield* Cache.set(cache, "hello", 42)
*   const result = yield* Cache.get(cache, "hello")
*   console.log(result) // 42 (not 5 from lookup)
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Overwriting existing cached values
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 100,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // First get populates via lookup
*   const original = yield* Cache.get(cache, "test") // 4
*
*   // Set overwrites the cached value
*   yield* Cache.set(cache, "test", 999)
*   const updated = yield* Cache.get(cache, "test") // 999
*
*   console.log({ original, updated })
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
* import { TestClock } from "effect/testing"
*
* // TTL behavior with set operations
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 100,
*     lookup: (key: string) => Effect.succeed(key.length),
*     timeToLive: "1 hour"
*   })
*
*   // Set value with TTL applied
*   yield* Cache.set(cache, "temporary", 123)
*   console.log(yield* Cache.has(cache, "temporary")) // true
*
*   // Advance time past TTL
*   yield* TestClock.adjust("2 hours")
*   console.log(yield* Cache.has(cache, "temporary")) // false
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Capacity enforcement with set operations
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 2,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Fill cache to capacity
*   yield* Cache.set(cache, "a", 1)
*   yield* Cache.set(cache, "b", 2)
*   console.log(yield* Cache.size(cache)) // 2
*
*   // Adding another entry evicts oldest
*   yield* Cache.set(cache, "c", 3)
*   console.log(yield* Cache.size(cache)) // 2
*   console.log(yield* Cache.has(cache, "a")) // false (evicted)
*   console.log(yield* Cache.has(cache, "c")) // true
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var set$11 = /*#__PURE__*/ dual(3, (self, key, value) => withFiber((fiber) => {
	const exit = exitSucceed(value);
	const deferred = makeUnsafe$8();
	doneUnsafe(deferred, exit);
	const ttl = self.timeToLive(exit, key);
	if (isZero(ttl)) {
		remove$9(self.map, key);
		return void_;
	}
	set$13(self.map, key, {
		deferred,
		expiresAt: isFinite(ttl) ? fiber.getRef(ClockRef).currentTimeMillisUnsafe() + toMillis(ttl) : void 0
	});
	checkCapacity$1(self);
	return void_;
}));
/**
* Checks if the cache contains an entry for the specified key.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 100,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Check non-existent key
*   console.log(yield* Cache.has(cache, "missing")) // false
*
*   // Add entry and check existence
*   yield* Cache.get(cache, "hello")
*   console.log(yield* Cache.has(cache, "hello")) // true
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
* import { TestClock } from "effect/testing"
*
* // TTL expiration behavior
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 100,
*     lookup: (key: string) => Effect.succeed(key.length),
*     timeToLive: "1 hour"
*   })
*
*   // Add entry with TTL
*   yield* Cache.get(cache, "expires")
*   console.log(yield* Cache.has(cache, "expires")) // true
*
*   // Still valid before expiration
*   yield* TestClock.adjust("30 minutes")
*   console.log(yield* Cache.has(cache, "expires")) // true
*
*   // Expired after TTL
*   yield* TestClock.adjust("31 minutes")
*   console.log(yield* Cache.has(cache, "expires")) // false
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Checking multiple keys efficiently
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 100,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Populate some entries
*   yield* Cache.set(cache, "apple", 5)
*   yield* Cache.set(cache, "banana", 6)
*
*   // Check multiple keys
*   const keys = ["apple", "banana", "cherry", "date"]
*   for (const key of keys) {
*     const exists = yield* Cache.has(cache, key)
*     console.log(`${key}: ${exists}`)
*   }
*   // Output:
*   // apple: true
*   // banana: true
*   // cherry: false
*   // date: false
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var has$8 = /*#__PURE__*/ dual(2, (self, key) => withFiber((fiber) => {
	return succeed$3(getImpl$1(self, key, fiber, false) !== void 0);
}));
/**
* Invalidates the entry associated with the specified key in the cache.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Add a value to the cache
*   yield* Cache.get(cache, "hello")
*   console.log(yield* Cache.has(cache, "hello")) // true
*
*   // Invalidate the entry
*   yield* Cache.invalidate(cache, "hello")
*   console.log(yield* Cache.has(cache, "hello")) // false
*
*   // Invalidating non-existent keys doesn't error
*   yield* Cache.invalidate(cache, "nonexistent")
*
*   // Get after invalidation will invoke lookup again
*   let lookupCount = 0
*   const cache2 = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) =>
*       Effect.sync(() => {
*         lookupCount++
*         return key.length
*       })
*   })
*
*   yield* Cache.get(cache2, "test") // lookupCount = 1
*   yield* Cache.invalidate(cache2, "test")
*   yield* Cache.get(cache2, "test") // lookupCount = 2 (lookup called again)
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var invalidate$1 = /*#__PURE__*/ dual(2, (self, key) => sync(() => {
	remove$9(self.map, key);
}));
/**
* Conditionally invalidates the entry associated with the specified key in the cache
* if the predicate returns true for the cached value.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Add values to the cache
*   yield* Cache.get(cache, "hello") // value = 5
*   yield* Cache.get(cache, "hi") // value = 2
*
*   // Invalidate when value equals 5
*   const invalidated1 = yield* Cache.invalidateWhen(
*     cache,
*     "hello",
*     (value) => value === 5
*   )
*   console.log(invalidated1) // true
*   console.log(yield* Cache.has(cache, "hello")) // false
*
*   // Don't invalidate when predicate doesn't match
*   const invalidated2 = yield* Cache.invalidateWhen(
*     cache,
*     "hi",
*     (value) => value === 5
*   )
*   console.log(invalidated2) // false
*   console.log(yield* Cache.has(cache, "hi")) // true (still present)
*
*   // Returns false for non-existent keys
*   const invalidated3 = yield* Cache.invalidateWhen(
*     cache,
*     "nonexistent",
*     () => true
*   )
*   console.log(invalidated3) // false
*
*   // Returns false for failed cached values
*   const cacheWithErrors = yield* Cache.make<string, number, string>({
*     capacity: 10,
*     lookup: (key: string) =>
*       key === "fail" ? Effect.fail("error") : Effect.succeed(key.length)
*   })
*
*   yield* Effect.exit(Cache.get(cacheWithErrors, "fail"))
*   const invalidated4 = yield* Cache.invalidateWhen(
*     cacheWithErrors,
*     "fail",
*     () => true
*   )
*   console.log(invalidated4) // false (can't invalidate failed values)
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var invalidateWhen$1 = /*#__PURE__*/ dual(3, (self, key, f) => withFiber((fiber) => {
	const oentry = getImpl$1(self, key, fiber, false);
	if (oentry === void 0) return succeed$3(false);
	return _await(oentry.deferred).pipe(map$9((value) => {
		if (f(value)) {
			remove$9(self.map, key);
			return true;
		}
		return false;
	}), catchCause(() => succeed$3(false)));
}));
/**
* Forces a refresh of the value associated with the specified key in the cache.
*
* It will always invoke the lookup function to construct a new value,
* overwriting any existing value for that key.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Force refresh of existing cached values
* const program = Effect.gen(function*() {
*   let counter = 0
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.sync(() => `${key}-${++counter}`)
*   })
*
*   // Initial cache population
*   const value1 = yield* Cache.get(cache, "user")
*   console.log(value1) // "user-1"
*
*   // Get from cache (no lookup)
*   const value2 = yield* Cache.get(cache, "user")
*   console.log(value2) // "user-1" (same value)
*
*   // Force refresh - always calls lookup
*   const refreshed = yield* Cache.refresh(cache, "user")
*   console.log(refreshed) // "user-2" (new value)
*
*   // Subsequent gets return refreshed value
*   const value3 = yield* Cache.get(cache, "user")
*   console.log(value3) // "user-2"
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
* import { TestClock } from "effect/testing"
*
* // Refresh resets TTL (Time To Live)
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length),
*     timeToLive: "1 hour"
*   })
*
*   yield* Cache.get(cache, "test")
*   yield* TestClock.adjust("45 minutes")
*
*   // Entry would normally expire in 15 minutes
*   console.log(yield* Cache.has(cache, "test")) // true
*
*   // Refresh resets the TTL to full 1 hour
*   yield* Cache.refresh(cache, "test")
*   yield* TestClock.adjust("30 minutes")
*
*   // Still valid because TTL was reset
*   console.log(yield* Cache.has(cache, "test")) // true
* })
* ```
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Refresh non-existent keys
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(`value-for-${key}`)
*   })
*
*   // Refresh non-existent key creates new entry
*   const result = yield* Cache.refresh(cache, "newKey")
*   console.log(result) // "value-for-newKey"
*
*   // Verify it's now cached
*   console.log(yield* Cache.has(cache, "newKey")) // true
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var refresh$2 = /*#__PURE__*/ dual(2, (self, key) => withFiber((fiber) => {
	const deferred = makeUnsafe$8();
	const entry = {
		expiresAt: void 0,
		deferred
	};
	const existing = getImpl$1(self, key, fiber, false) !== void 0;
	if (!existing) {
		set$13(self.map, key, entry);
		checkCapacity$1(self);
	}
	return onExit(self.lookup(key), (exit) => {
		doneUnsafe(deferred, exit);
		const ttl = self.timeToLive(exit, key);
		if (isZero(ttl)) {
			remove$9(self.map, key);
			return void_;
		}
		entry.expiresAt = isFinite(ttl) ? fiber.getRef(ClockRef).currentTimeMillisUnsafe() + toMillis(ttl) : void 0;
		if (existing) set$13(self.map, key, entry);
		return void_;
	});
}));
/**
* Invalidates all entries in the cache.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Clear all cached entries at once
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Populate cache with multiple entries
*   yield* Cache.get(cache, "apple")
*   yield* Cache.get(cache, "banana")
*   yield* Cache.get(cache, "cherry")
*
*   console.log(yield* Cache.size(cache)) // 3
*   console.log(yield* Cache.has(cache, "apple")) // true
*
*   // Clear all entries
*   yield* Cache.invalidateAll(cache)
*
*   // Verify cache is empty
*   console.log(yield* Cache.size(cache)) // 0
*   console.log(yield* Cache.has(cache, "apple")) // false
*   console.log(yield* Cache.has(cache, "banana")) // false
*   console.log(yield* Cache.has(cache, "cherry")) // false
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var invalidateAll$1 = (self) => sync(() => {
	clear$7(self.map);
});
/**
* Retrieves the approximate number of entries in the cache.
*
* Note that expired entries are counted until they are accessed and removed.
* The size reflects the current number of entries stored, not the number
* of valid entries.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Empty cache has size 0
*   const emptySize = yield* Cache.size(cache)
*   console.log(emptySize) // 0
*
*   // Add entries and check size
*   yield* Cache.get(cache, "hello")
*   yield* Cache.get(cache, "world")
*   const sizeAfterAdding = yield* Cache.size(cache)
*   console.log(sizeAfterAdding) // 2
*
*   // Size decreases after invalidation
*   yield* Cache.invalidate(cache, "hello")
*   const sizeAfterInvalidation = yield* Cache.size(cache)
*   console.log(sizeAfterInvalidation) // 1
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var size$11 = (self) => sync(() => size$15(self.map));
/**
* Retrieves all active keys from the cache, automatically filtering out expired entries.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* // Basic key enumeration
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Add some entries to the cache
*   yield* Cache.get(cache, "hello")
*   yield* Cache.get(cache, "world")
*   yield* Cache.get(cache, "cache")
*
*   // Retrieve all active keys
*   const keys = yield* Cache.keys(cache)
*
*   console.log(Array.from(keys)) // ["hello", "world", "cache"]
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var keys$4 = (self) => withFiber((fiber) => {
	const now = fiber.getRef(ClockRef).currentTimeMillisUnsafe();
	return succeed$3(filterMap$3(self.map, ([key, entry]) => {
		if (entry.expiresAt === void 0 || entry.expiresAt > now) return succeed$2(key);
		remove$9(self.map, key);
		return failVoid;
	}));
});
/**
* Retrieves all successfully cached values from the cache, excluding failed
* lookups and expired entries.
*
* @example
* ```ts
* import { Cache, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* Cache.make({
*     capacity: 10,
*     lookup: (key: string) => Effect.succeed(key.length)
*   })
*
*   // Add some values to the cache
*   yield* Cache.get(cache, "a")
*   yield* Cache.get(cache, "ab")
*   yield* Cache.get(cache, "abc")
*
*   // Retrieve all cached values
*   const values = yield* Cache.values(cache)
*   const valuesArray = Array.from(values).sort()
*
*   console.log(valuesArray) // [1, 2, 3]
* })
* ```
*
* @since 4.0.0
* @category Combinators
*/
var values$5 = (self) => map$9(entries$5(self), map$10(([, value]) => value));
/**
* Retrieves all key-value pairs from the cache as an iterable. This function
* only returns entries with successfully resolved values, filtering out any
* failed lookups or expired entries.
*
* @since 4.0.0
* @category Combinators
*/
var entries$5 = (self) => withFiber((fiber) => {
	const now = fiber.getRef(ClockRef).currentTimeMillisUnsafe();
	return succeed$3(filterMap$3(self.map, ([key, entry]) => {
		if (entry.expiresAt === void 0 || entry.expiresAt > now) {
			const exit = entry.deferred.effect;
			return !isExit(exit) || exitIsFailure(exit) ? failVoid : succeed$2([key, exit.value]);
		}
		remove$9(self.map, key);
		return failVoid;
	}));
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ChannelSchema.js
var ChannelSchema_exports = /* @__PURE__ */ __exportAll({
	decode: () => decode,
	decodeUnknown: () => decodeUnknown,
	duplex: () => duplex,
	duplexUnknown: () => duplexUnknown,
	encode: () => encode,
	encodeUnknown: () => encodeUnknown
});
/**
* @since 4.0.0
* @category constructors
*/
var encode = (schema) => () => {
	const encode = encodeEffect(NonEmptyArray(schema));
	return fromTransform((upstream, _scope) => succeed$4(flatMap$2(upstream, (chunk) => encode(chunk))));
};
/**
* @since 4.0.0
* @category constructors
*/
var encodeUnknown = encode;
/**
* @since 4.0.0
* @category constructors
*/
var decode = (schema) => () => {
	const decode = decodeEffect(NonEmptyArray(schema));
	return fromTransform((upstream, _scope) => succeed$4(flatMap$2(upstream, (chunk) => decode(chunk))));
};
/**
* @since 4.0.0
* @category constructors
*/
var decodeUnknown = decode;
/**
* @since 4.0.0
* @category combinators
*/
var duplex = /*#__PURE__*/ dual(2, (self, options) => encode(options.inputSchema)().pipe(pipeTo(self), pipeTo(decode(options.outputSchema)())));
/**
* @since 4.0.0
* @category combinators
*/
var duplexUnknown = duplex;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ConfigProvider.js
/**
* Provides the data source layer for the `Config` module. A `ConfigProvider`
* knows how to load raw configuration nodes from a backing store (environment
* variables, JSON objects, `.env` files, file trees) and expose them through a
* uniform `Node` interface that `Config` schemas consume.
*
* ## Mental model
*
* - **Node** – a discriminated union (`Value | Record | Array`) that describes
*   what lives at a given path in the configuration tree.
* - **Path** – an array of string or numeric segments used to address a node
*   (e.g. `["database", "host"]`).
* - **ConfigProvider** – an object with a `load(path)` method that resolves a
*   path to a `Node | undefined`. Providers can be composed and transformed.
* - **ServiceMap.Reference** – `ConfigProvider` is registered as a reference
*   service that defaults to `fromEnv()`, so it works without explicit
*   provision.
* - **SourceError** – the typed error returned when a backing store is
*   unreadable (I/O failure, permission error, etc.).
*
* ## Common tasks
*
* - Read from environment variables → {@link fromEnv}
* - Read from a JSON / plain object → {@link fromUnknown}
* - Parse a `.env` string → {@link fromDotEnvContents}
* - Load a `.env` file → {@link fromDotEnv}
* - Read from a directory tree → {@link fromDir}
* - Build a custom provider → {@link make}
* - Fall back to another provider → {@link orElse}
* - Scope a provider under a prefix → {@link nested}
* - Convert path segments to `CONSTANT_CASE` → {@link constantCase}
* - Transform path segments arbitrarily → {@link mapInput}
* - Install a provider as a Layer → {@link layer} / {@link layerAdd}
*
* ## Gotchas
*
* - `fromEnv` joins path segments with `_` for lookup **and** splits env var
*   names on `_` to discover child keys. `DATABASE_HOST=x` is therefore
*   accessible at both `["DATABASE_HOST"]` and `["DATABASE", "HOST"]`.
* - Because of `_` splitting, querying a parent path like `["DATABASE"]`
*   returns a `Record` node with child key `"HOST"`, even if no env var
*   named `DATABASE` exists.
* - When using `fromEnv` with schemas that use camelCase keys, pipe the
*   provider through {@link constantCase} so `databaseHost` resolves to
*   `DATABASE_HOST`.
* - `orElse` only falls back when the primary provider returns `undefined`
*   (path not found). It does **not** catch `SourceError`.
* - `nested` prepends segments to the path *after* `mapInput` has run, so
*   the order of composition matters.
*
* ## Quickstart
*
* **Example** (Reading config from environment variables)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const provider = ConfigProvider.fromEnv({
*   env: { APP_PORT: "3000", APP_HOST: "localhost" }
* })
*
* const port = Config.number("port")
*
* const program = port.parse(
*   provider.pipe(
*     ConfigProvider.nested("app"),
*     ConfigProvider.constantCase
*   )
* )
*
* // Effect.runSync(program) // 3000
* ```
*
* @see {@link make} – build a provider from a lookup function
* @see {@link fromEnv} – the default provider backed by `process.env`
* @see {@link fromUnknown} – provider backed by a plain JS object
*
* @since 4.0.0
*/
var ConfigProvider_exports = /* @__PURE__ */ __exportAll({
	ConfigProvider: () => ConfigProvider,
	SourceError: () => SourceError,
	constantCase: () => constantCase,
	fromDir: () => fromDir,
	fromDotEnv: () => fromDotEnv,
	fromDotEnvContents: () => fromDotEnvContents,
	fromEnv: () => fromEnv,
	fromUnknown: () => fromUnknown,
	layer: () => layer$1,
	layerAdd: () => layerAdd,
	make: () => make$26,
	makeArray: () => makeArray,
	makeRecord: () => makeRecord,
	makeValue: () => makeValue,
	mapInput: () => mapInput,
	nested: () => nested$1,
	orElse: () => orElse$3
});
/**
* Creates a `Value` node representing a terminal string leaf.
*
* When to use:
* - Building nodes inside a custom `ConfigProvider`'s `get` callback.
*
* Does not mutate input. Returns a new plain object.
*
* **Example** (Creating a value node)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const node = ConfigProvider.makeValue("3000")
* // { _tag: "Value", value: "3000" }
* ```
*
* @see {@link makeRecord} – for object-like containers
* @see {@link makeArray} – for array-like containers
*
* @category Constructors
* @since 4.0.0
*/
function makeValue(value) {
	return {
		_tag: "Value",
		value
	};
}
/**
* Creates a `Record` node representing an object-like container with known
* child keys.
*
* When to use:
* - Describing a directory or JSON object inside a custom provider.
*
* The optional `value` allows a node to be both a container and a leaf at the
* same time (e.g. an env var `A=x` that also has children `A_FOO`, `A_BAR`).
*
* **Example** (Creating a record node)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const node = ConfigProvider.makeRecord(new Set(["host", "port"]))
* // { _tag: "Record", keys: Set(["host", "port"]), value: undefined }
* ```
*
* @see {@link makeValue} – for terminal leaves
* @see {@link makeArray} – for array-like containers
*
* @category Constructors
* @since 4.0.0
*/
function makeRecord(keys, value) {
	return {
		_tag: "Record",
		keys,
		value
	};
}
/**
* Creates an `Array` node representing an indexed container with a known
* length.
*
* When to use:
* - Describing a JSON array or a set of numerically-indexed env vars inside a
*   custom provider.
*
* The optional `value` allows a node to be both a container and a leaf at the
* same time.
*
* **Example** (Creating an array node)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const node = ConfigProvider.makeArray(3)
* // { _tag: "Array", length: 3, value: undefined }
* ```
*
* @see {@link makeValue} – for terminal leaves
* @see {@link makeRecord} – for object-like containers
*
* @category Constructors
* @since 4.0.0
*/
function makeArray(length, value) {
	return {
		_tag: "Array",
		length,
		value
	};
}
/**
* Typed error indicating that a configuration source could not be read.
*
* When to use:
* - Return from a custom provider's `get` callback when the underlying store
*   is unreachable or produces an I/O error.
* - Match on in error channels when consuming provider output directly.
*
* Not used for "key not found" — that case is represented by returning
* `undefined` from `load` / `get`.
*
* **Example** (Failing with a SourceError)
*
* ```ts
* import { ConfigProvider, Effect } from "effect"
*
* const provider = ConfigProvider.make((_path) =>
*   Effect.fail(
*     new ConfigProvider.SourceError({ message: "connection refused" })
*   )
* )
* ```
*
* @see {@link ConfigProvider} – the interface whose `load`/`get` may fail
*   with this error
*
* @category Models
* @since 4.0.0
*/
var SourceError = class extends TaggedError("SourceError") {};
/**
* The `ConfigProvider` service reference, registered in the service map with a
* default value of `fromEnv()`.
*
* Because it is a `ServiceMap.Reference`, it is available without explicit
* provision — `Config` schemas automatically resolve it.
*
* When to use:
* - Override the provider for an entire program via
*   `Effect.provideService(ConfigProvider.ConfigProvider, myProvider)`.
* - Retrieve the current provider inside an Effect with
*   `yield* ConfigProvider.ConfigProvider`.
*
* **Example** (Providing a custom provider)
*
* ```ts
* import { ConfigProvider, Effect } from "effect"
*
* const provider = ConfigProvider.fromUnknown({ port: 8080 })
*
* const program = Effect.gen(function*() {
*   const current = yield* ConfigProvider.ConfigProvider
*   return current
* }).pipe(
*   Effect.provideService(ConfigProvider.ConfigProvider, provider)
* )
* ```
*
* @see {@link layer} – install a provider as a Layer
* @see {@link layerAdd} – add a fallback provider as a Layer
*
* @category Services
* @since 4.0.0
*/
var ConfigProvider = /*#__PURE__*/ Reference("effect/ConfigProvider", { defaultValue: () => fromEnv() });
var Proto$9 = {
	...PipeInspectableProto,
	toJSON() {
		return { _id: "ConfigProvider" };
	}
};
/**
* Creates a `ConfigProvider` from a raw lookup function.
*
* When to use:
* - Implementing a provider backed by a custom store (database, remote API,
*   in-memory map, etc.).
*
* The `get` callback receives a `Path` and must return
* `Effect<Node | undefined, SourceError>`. Return `undefined` when the path
* does not exist; fail with `SourceError` only for actual I/O errors.
*
* The optional `mapInput` and `prefix` parameters are wired into the
* resulting `load` method so that combinators like {@link mapInput} and
* {@link nested} can compose without wrapping `get`.
*
* **Example** (A simple in-memory provider)
*
* ```ts
* import { ConfigProvider, Effect } from "effect"
*
* const data: Record<string, string> = {
*   host: "localhost",
*   port: "5432"
* }
*
* const provider = ConfigProvider.make((path) => {
*   const key = path.join(".")
*   const value = data[key]
*   return Effect.succeed(
*     value !== undefined ? ConfigProvider.makeValue(value) : undefined
*   )
* })
* ```
*
* @see {@link fromEnv} – pre-built provider for environment variables
* @see {@link fromUnknown} – pre-built provider for JSON objects
*
* @category Constructors
* @since 4.0.0
*/
function make$26(get, mapInput, prefix) {
	const self = Object.create(Proto$9);
	self.get = get;
	self.mapInput = mapInput;
	self.prefix = prefix;
	self.load = (path) => {
		if (mapInput) path = mapInput(path);
		if (prefix) path = [...prefix, ...path];
		return get(path);
	};
	return self;
}
/**
* Returns a provider that falls back to `that` when `self` returns `undefined`
* for a path.
*
* When to use:
* - Layering multiple config sources (e.g. env vars + defaults file).
* - Providing partial overrides on top of a base config.
*
* Only triggers the fallback when the path is not found (`undefined`). A
* `SourceError` from `self` is **not** caught — it propagates immediately.
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Falling back to a default provider)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const envProvider = ConfigProvider.fromEnv({
*   env: { HOST: "prod.example.com" }
* })
* const defaults = ConfigProvider.fromUnknown({ HOST: "localhost", PORT: "3000" })
*
* const combined = ConfigProvider.orElse(envProvider, defaults)
* ```
*
* @see {@link layerAdd} – install a fallback provider via a Layer
*
* @category Combinators
* @since 4.0.0
*/
var orElse$3 = /*#__PURE__*/ dual(2, (self, that) => make$26((path) => flatMap$2(self.get(path), (node) => node ? succeed$4(node) : that.get(path))));
/**
* Transforms the path segments before they reach the underlying store.
*
* When to use:
* - Renaming or re-casing path segments (see {@link constantCase} for a
*   common specialization).
* - Adding suffixes or other per-segment transformations.
*
* The function `f` receives the full path and must return a new path. If the
* provider already has a `mapInput`, the functions compose (existing first,
* then `f`).
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Uppercasing path segments)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const provider = ConfigProvider.fromEnv({
*   env: { APP_HOST: "localhost" }
* })
*
* const upper = ConfigProvider.mapInput(provider, (path) =>
*   path.map((seg) =>
*     typeof seg === "string" ? seg.toUpperCase() : seg
*   )
* )
* ```
*
* @see {@link constantCase} – a preset that converts to `CONSTANT_CASE`
* @see {@link nested} – for prepending a prefix instead of transforming
*
* @category Combinators
* @since 4.0.0
*/
var mapInput = /*#__PURE__*/ dual(2, (self, f) => {
	return make$26(self.get, self.mapInput ? flow(self.mapInput, f) : f, self.prefix ? f(self.prefix) : void 0);
});
/**
* Converts all string path segments to `CONSTANT_CASE` before lookup.
*
* When to use:
* - Bridging camelCase schema keys to `SCREAMING_SNAKE_CASE` environment
*   variables (the most common pattern).
*
* Numeric segments are left unchanged. This is a specialization of
* {@link mapInput}.
*
* **Example** (Resolving camelCase keys to env vars)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const provider = ConfigProvider.fromEnv({
*   env: { DATABASE_HOST: "localhost" }
* }).pipe(ConfigProvider.constantCase)
*
* // path ["databaseHost"] now resolves to env var DATABASE_HOST
* ```
*
* @see {@link mapInput} – for arbitrary path transformations
*
* @since 4.0.0
* @category Combinators
*/
var constantCase = /*#__PURE__*/ mapInput((path) => path.map((seg) => typeof seg === "number" ? seg : constantCase$1(seg)));
/**
* Scopes a provider so that all lookups are prefixed with the given path
* segments.
*
* When to use:
* - Namespacing config under a prefix like `"app"` or `"database"`.
* - Reusing the same provider shape for multiple sub-configs.
*
* Accepts a single string or a full `Path` array. The prefix is prepended
* *after* any `mapInput` transformation runs, so ordering matters when
* composing with {@link mapInput} or {@link constantCase}.
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Nesting under a prefix)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const provider = ConfigProvider.fromEnv({
*   env: { APP_HOST: "localhost", APP_PORT: "3000" }
* })
*
* // Lookups for ["HOST"] now resolve to ["APP", "HOST"]
* const scoped = ConfigProvider.nested(provider, "APP")
* ```
*
* @see {@link mapInput} – for arbitrary path transformations
*
* @category Combinators
* @since 4.0.0
*/
var nested$1 = /*#__PURE__*/ dual(2, (self, prefix) => {
	const path = typeof prefix === "string" ? [prefix] : prefix;
	return make$26(self.get, self.mapInput, self.prefix ? [...self.prefix, ...path] : path);
});
/**
* Installs a `ConfigProvider` as the active provider for all downstream
* effects, replacing any previously installed provider.
*
* When to use:
* - Setting the config source for an entire application or test suite.
*
* Accepts either a plain `ConfigProvider` or an `Effect` that produces one.
* When given an Effect, it is evaluated once when the layer is built.
*
* **Example** (Using a JSON object as the config source)
*
* ```ts
* import { Config, ConfigProvider, Effect, Layer } from "effect"
*
* const TestLayer = ConfigProvider.layer(
*   ConfigProvider.fromUnknown({ port: 8080 })
* )
*
* const program = Effect.gen(function*() {
*   const port = yield* Config.number("port")
*   return port
* })
*
* // Effect.runSync(Effect.provide(program, TestLayer)) // 8080
* ```
*
* @see {@link layerAdd} – add a provider without replacing the existing one
*
* @category Layers
* @since 4.0.0
*/
var layer$1 = (self) => isEffect$1(self) ? effect(ConfigProvider)(self) : succeed$5(ConfigProvider)(self);
/**
* Creates a Layer that composes a new `ConfigProvider` with the currently
* active one, rather than replacing it.
*
* When to use:
* - Adding defaults that should only apply when the primary provider has no
*   value for a path.
* - Overriding specific keys while keeping the rest from the existing provider
*   (use `asPrimary: true`).
*
* By default, the new provider acts as a **fallback** (consulted only when
* the current provider returns `undefined`). Set `asPrimary: true` to make
* the new provider the **primary** source, with the existing one as fallback.
*
* **Example** (Adding default values)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const defaults = ConfigProvider.fromUnknown({
*   HOST: "localhost",
*   PORT: "3000"
* })
*
* // The current env provider is tried first; `defaults` is the fallback
* const DefaultsLayer = ConfigProvider.layerAdd(defaults)
* ```
*
* @see {@link layer} – replace the provider entirely
* @see {@link orElse} – compose providers without layers
*
* @category Layers
* @since 4.0.0
*/
var layerAdd = (self, options) => effect(ConfigProvider)(gen(function* () {
	const current = yield* ConfigProvider;
	const configProvider = isEffect$1(self) ? yield* self : self;
	return options?.asPrimary ? orElse$3(configProvider, current) : orElse$3(current, configProvider);
}));
/**
* Creates a `ConfigProvider` backed by an in-memory JavaScript value
* (typically a parsed JSON object).
*
* When to use:
* - Unit / integration tests where you want deterministic config without
*   touching the environment.
* - Embedding config directly in code or reading a JSON file.
*
* Path traversal follows standard JS rules: string segments index into
* object keys, numeric segments index into arrays. Returns `undefined`
* for any path that cannot be resolved. Never fails with `SourceError`.
*
* Primitive values (`number`, `boolean`, `bigint`) are stringified via
* `String(...)`.
*
* **Example** (Providing config from a plain object)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const provider = ConfigProvider.fromUnknown({
*   database: {
*     host: "localhost",
*     port: 5432
*   }
* })
*
* const host = Config.string("host").parse(
*   provider.pipe(ConfigProvider.nested("database"))
* )
*
* // Effect.runSync(host) // "localhost"
* ```
*
* @see {@link fromEnv} – for environment variables
* @see {@link make} – for custom backing stores
*
* @category ConfigProviders
* @since 4.0.0
*/
function fromUnknown(root) {
	return make$26((path) => succeed$4(nodeAtJson(root, path)));
}
function nodeAtJson(root, path) {
	let cur = root;
	for (const seg of path) {
		if (cur === null || cur === void 0) return void 0;
		if (Array.isArray(cur)) {
			if (typeof seg !== "number" || !Number.isInteger(seg) || seg < 0 || seg >= cur.length) return void 0;
			cur = cur[seg];
			continue;
		}
		if (isObject(cur)) {
			if (typeof seg !== "string") return void 0;
			if (!Object.hasOwn(cur, seg)) return void 0;
			cur = cur[seg];
			continue;
		}
		return;
	}
	return describeUnknown(cur);
}
function describeUnknown(u) {
	if (u === void 0 || u === null) return void 0;
	if (typeof u === "string") return makeValue(u);
	if (typeof u === "number" || typeof u === "boolean" || typeof u === "bigint") return makeValue(String(u));
	if (Array.isArray(u)) return makeArray(u.length);
	if (isObject(u)) return makeRecord(new Set(Object.keys(u)));
	return makeValue(format$1(u));
}
/**
* Creates a `ConfigProvider` backed by environment variables.
*
* When to use:
* - Reading configuration from `process.env` (the default when no provider
*   is explicitly set).
* - Passing a custom env record for testing or non-Node runtimes.
*
* Path segments are joined with `_` for direct lookup, and env var names are
* also split on `_` to build a trie for child key discovery. This means
* `DATABASE_HOST=localhost` is accessible at both path `["DATABASE_HOST"]`
* and `["DATABASE", "HOST"]`. If all immediate children of a trie node have
* purely numeric names, the node is reported as an `Array`; otherwise as a
* `Record`.
*
* The default environment merges `process.env` and `import.meta.env` (when
* available). Override by passing `{ env: { ... } }`.
*
* Never fails with `SourceError` — all lookups are synchronous.
*
* **Example** (Reading from a custom env record)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     DATABASE_HOST: "localhost",
*     DATABASE_PORT: "5432"
*   }
* })
*
* const host = Config.string("HOST").parse(
*   provider.pipe(ConfigProvider.nested("DATABASE"))
* )
*
* // Effect.runSync(host) // "localhost"
* ```
*
* @see {@link fromUnknown} – for JSON objects
* @see {@link constantCase} – bridge camelCase keys to SCREAMING_SNAKE_CASE
*
* @category ConfigProviders
* @since 4.0.0
*/
function fromEnv(options) {
	const env = options?.env ?? {
		...globalThis?.process?.env,
		...import.meta.env
	};
	const trie = buildEnvTrie(env);
	return make$26((path) => succeed$4(nodeAtEnv(trie, env, path)));
}
function buildEnvTrie(env) {
	const root = {};
	for (const [name, value] of Object.entries(env)) {
		if (value === void 0) continue;
		const segments = name.split("_");
		let node = root;
		for (const seg of segments) {
			node.children ??= {};
			node = node.children[seg] ??= {};
		}
		node.value = value;
	}
	return root;
}
var NUMERIC_INDEX = /^(0|[1-9][0-9]*)$/;
function nodeAtEnv(trie, env, path) {
	const leafValue = env[path.map(String).join("_")];
	const trieNode = trieNodeAt(trie, path);
	const children = trieNode?.children ? Object.keys(trieNode.children) : [];
	if (children.length === 0) return leafValue === void 0 ? void 0 : makeValue(leafValue);
	if (children.every((k) => NUMERIC_INDEX.test(k))) return makeArray(Math.max(...children.map((k) => parseInt(k, 10))) + 1, leafValue);
	return makeRecord(new Set(children), leafValue);
}
function trieNodeAt(root, path) {
	if (path.length === 0) return root;
	let node = root;
	for (const seg of path) {
		node = node?.children?.[String(seg)];
		if (!node) return void 0;
	}
	return node;
}
/**
* Creates a `ConfigProvider` by parsing the string contents of a `.env` file.
*
* When to use:
* - You already have the `.env` contents as a string (e.g. fetched from a
*   remote store or embedded in a test).
* - Use {@link fromDotEnv} instead if you want to read a `.env` file from
*   disk.
*
* Supports `export` prefixes, single/double/backtick quoting, inline
* comments, and escaped newlines. Variable expansion (e.g. `${VAR}`) is
* disabled by default; enable with `{ expandVariables: true }`.
*
* Parsing is based on the `dotenv` / `dotenv-expand` algorithm.
*
* Internally delegates to {@link fromEnv} with the parsed key-value pairs.
*
* **Example** (Parsing .env contents)
*
* ```ts
* import { ConfigProvider } from "effect"
*
* const contents = `
* HOST=localhost
* PORT=3000
* # this is a comment
* `
*
* const provider = ConfigProvider.fromDotEnvContents(contents)
* ```
*
* @see {@link fromDotEnv} – loads a `.env` file from disk
* @see {@link fromEnv} – for raw environment variable access
*
* @category ConfigProviders
* @since 4.0.0
*/
function fromDotEnvContents(lines, options) {
	let env = parseDotEnvContents(lines);
	if (options?.expandVariables) env = dotEnvExpand(env);
	return fromEnv({ env });
}
var DOT_ENV_LINE = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/gm;
function parseDotEnvContents(lines) {
	const obj = {};
	lines = lines.replace(/\r\n?/gm, "\n");
	let match;
	while ((match = DOT_ENV_LINE.exec(lines)) != null) {
		const key = match[1];
		let value = match[2] || "";
		value = value.trim();
		const maybeQuote = value[0];
		value = value.replace(/^(['"`])([\s\S]*)\1$/gm, "$2");
		if (maybeQuote === "\"") {
			value = value.replace(/\\n/g, "\n");
			value = value.replace(/\\r/g, "\r");
		}
		obj[key] = value;
	}
	return obj;
}
function dotEnvExpand(parsed) {
	const newParsed = {};
	for (const configKey in parsed) newParsed[configKey] = interpolate(parsed[configKey], parsed).replace(/\\\$/g, "$");
	return newParsed;
}
function interpolate(envValue, parsed) {
	const lastUnescapedDollarSignIndex = searchLast(envValue, /(?!(?<=\\))\$/g);
	if (lastUnescapedDollarSignIndex === -1) return envValue;
	const match = envValue.slice(lastUnescapedDollarSignIndex).match(/((?!(?<=\\))\${?([\w]+)(?::-([^}\\]*))?}?)/);
	if (match !== null) {
		const [_, group, variableName, defaultValue] = match;
		return interpolate(envValue.replace(group, defaultValue || parsed[variableName] || ""), parsed);
	}
	return envValue;
}
function searchLast(str, rgx) {
	const matches = Array.from(str.matchAll(rgx));
	return matches.length > 0 ? matches.slice(-1)[0].index : -1;
}
/**
* Creates a `ConfigProvider` by reading and parsing a `.env` file from the
* file system.
*
* When to use:
* - Loading environment config from a `.env` file at application startup.
* - Use {@link fromDotEnvContents} if you already have the file contents as
*   a string.
*
* Requires `FileSystem` in the Effect context. Defaults to reading `".env"`
* in the current directory; override with `{ path: "/custom/.env" }`.
*
* Returns an `Effect` that resolves to a `ConfigProvider`. Fails with a
* `PlatformError` if the file cannot be read.
*
* **Example** (Loading a .env file)
*
* ```ts
* import { ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const provider = yield* ConfigProvider.fromDotEnv()
*   return provider
* })
* ```
*
* @see {@link fromDotEnvContents} – parse a `.env` string directly
* @see {@link fromEnv} – read from the runtime environment
*
* @since 4.0.0
*/
var fromDotEnv = /*#__PURE__*/ fnUntraced(function* (options) {
	return fromEnv({ env: parseDotEnvContents(yield* (yield* FileSystem).readFileString(options?.path ?? ".env")) });
});
/**
* Creates a `ConfigProvider` that reads configuration from a directory tree
* on disk, where each file is a leaf value and each directory is a container.
*
* When to use:
* - Kubernetes ConfigMap / Secret volume mounts, where each key is a file
*   under a mount path.
* - Any file-per-key configuration layout.
*
* Resolution rules:
* - Regular file → `Value` node (file contents trimmed).
* - Directory → `Record` node with immediate child names as keys.
* - Not found → tries as file first, then as directory; returns
*   `SourceError` if both fail.
*
* Requires `Path` and `FileSystem` in the Effect context. Defaults to root
* path `/`; override with `{ rootPath: "/etc/config" }`.
*
* **Example** (Reading config from a directory)
*
* ```ts
* import { ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const provider = yield* ConfigProvider.fromDir({
*     rootPath: "/etc/myapp"
*   })
*   return provider
* })
* ```
*
* @see {@link fromEnv} – for environment variables
* @see {@link fromDotEnv} – for `.env` files
*
* @category ConfigProviders
* @since 4.0.0
*/
var fromDir = /*#__PURE__*/ fnUntraced(function* (options) {
	const platformPath = yield* Path;
	const fs = yield* FileSystem;
	const rootPath = options?.rootPath ?? "/";
	return make$26((path) => {
		const fullPath = platformPath.join(rootPath, ...path.map(String));
		const asFile = fs.readFileString(fullPath).pipe(map$11((content) => makeValue(content.trim())));
		const asDirectory = fs.readDirectory(fullPath).pipe(map$11((entries) => {
			const keys = entries.map((e) => typeof e === "string" ? platformPath.basename(e) : format$1(e?.name ?? ""));
			return makeRecord(new Set(keys));
		}));
		return asFile.pipe(catch_(() => asDirectory), mapError((cause) => new SourceError({
			message: `Failed to read file at ${platformPath.join(rootPath, ...path.map(String))}`,
			cause
		})));
	});
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Config.js
var Config_exports = /* @__PURE__ */ __exportAll({
	Boolean: () => Boolean,
	ConfigError: () => ConfigError,
	Duration: () => Duration,
	FalseValues: () => FalseValues,
	LogLevel: () => LogLevel,
	Port: () => Port,
	Record: () => Record,
	TrueValues: () => TrueValues,
	all: () => all,
	boolean: () => boolean$2,
	date: () => date$1,
	duration: () => duration,
	fail: () => fail$2,
	finite: () => finite,
	int: () => int,
	isConfig: () => isConfig,
	literal: () => literal,
	logLevel: () => logLevel,
	make: () => make$25,
	map: () => map$7,
	mapOrFail: () => mapOrFail,
	nested: () => nested,
	nonEmptyString: () => nonEmptyString$2,
	number: () => number$1,
	option: () => option$2,
	orElse: () => orElse$2,
	port: () => port,
	redacted: () => redacted,
	schema: () => schema,
	string: () => string$2,
	succeed: () => succeed$1,
	unwrap: () => unwrap,
	url: () => url,
	withDefault: () => withDefault
});
var TypeId$27 = "~effect/Config";
/**
* Returns `true` if `u` is a `Config` instance.
*
* When to use:
* - Runtime type-checking before calling `.parse()` on an unknown value.
* - Distinguishing a `Config` from a plain value inside {@link unwrap}.
*
* **Example** (Type guard)
*
* ```ts
* import { Config } from "effect"
*
* console.log(Config.isConfig(Config.string("HOST"))) // true
* console.log(Config.isConfig("not a config"))        // false
* ```
*
* @since 4.0.0
* @category Guards
*/
var isConfig = (u) => hasProperty(u, TypeId$27);
/**
* The error type produced when config loading or validation fails.
*
* Wraps either:
* - A `SourceError` — the provider could not read data (I/O failure).
* - A `SchemaError` — the data was found but did not match the schema
*   (wrong type, out of range, missing key, etc.).
*
* When to use:
* - Match on `error.cause._tag` to distinguish source failures from
*   validation failures.
* - Pass to {@link fail} to create a Config that always errors.
*
* @see {@link orElse} – recover from a ConfigError
* @see {@link withDefault} – provide a fallback for missing-data errors
*
* @since 4.0.0
* @category Models
*/
var ConfigError = class {
	_tag = "ConfigError";
	name = "ConfigError";
	cause;
	constructor(cause) {
		this.cause = cause;
	}
	get message() {
		return this.cause.toString();
	}
	toString() {
		return `ConfigError(${this.message})`;
	}
};
var Proto$8 = {
	...PipeInspectableProto,
	...YieldableProto,
	[TypeId$27]: TypeId$27,
	asEffect() {
		return flatMap$2(ConfigProvider.asEffect(), (provider) => this.parse(provider));
	},
	toJSON() {
		return { _id: "Config" };
	}
};
/**
* Creates a `Config` from a raw parsing function.
*
* When to use:
* - Building a custom config that cannot be expressed with {@link schema} or
*   the convenience constructors.
* - Composing configs programmatically.
*
* The `parse` callback receives a `ConfigProvider` and must return
* `Effect<T, ConfigError>`.
*
* **Example** (Custom config that reads two keys)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const hostPort = Config.make((provider) =>
*   Effect.all({
*     host: Config.string("host").parse(provider),
*     port: Config.number("port").parse(provider)
*   })
* )
*
* const provider = ConfigProvider.fromUnknown({ host: "localhost", port: 3000 })
* // Effect.runSync(hostPort.parse(provider))
* // { host: "localhost", port: 3000 }
* ```
*
* @see {@link schema} – higher-level constructor using Schema codecs
*
* @category Constructors
* @since 4.0.0
*/
function make$25(parse) {
	const self = Object.create(Proto$8);
	self.parse = parse;
	return self;
}
/**
* Transforms the parsed value of a config with a pure function.
*
* When to use:
* - Post-processing a config value (e.g. trimming, uppercasing, wrapping).
* - The transformation cannot fail. Use {@link mapOrFail} if it can.
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Uppercasing a string config)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const upper = Config.string("name").pipe(
*   Config.map((s) => s.toUpperCase())
* )
*
* const provider = ConfigProvider.fromUnknown({ name: "alice" })
* // Effect.runSync(upper.parse(provider)) // "ALICE"
* ```
*
* @see {@link mapOrFail} – when the transformation can fail
*
* @category Mapping
* @since 4.0.0
*/
var map$7 = /*#__PURE__*/ dual(2, (self, f) => {
	return make$25((provider) => map$11(self.parse(provider), f));
});
/**
* Transforms the parsed value with a function that may fail.
*
* When to use:
* - Validating or converting a config value where the transformation can
*   produce a `ConfigError` (e.g. parsing a URL, checking a range).
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Wrapping a value in an effectful transformation)
*
* ```ts
* import { Config, Effect } from "effect"
*
* const trimmed = Config.string("name").pipe(
*   Config.mapOrFail((s) => Effect.succeed(s.trim()))
* )
* ```
*
* @see {@link map} – when the transformation cannot fail
*
* @category Mapping
* @since 4.0.0
*/
var mapOrFail = /*#__PURE__*/ dual(2, (self, f) => {
	return make$25((provider) => flatMap$2(self.parse(provider), f));
});
/**
* Falls back to another config when parsing fails with a `ConfigError`.
*
* When to use:
* - Trying an alternative config source when the primary one errors.
* - Providing environment-specific overrides.
*
* Unlike {@link withDefault}, this catches **all** `ConfigError`s (not just
* missing data). The fallback function receives the error and returns a new
* `Config`.
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Falling back to a literal)
*
* ```ts
* import { Config } from "effect"
*
* const hostConfig = Config.string("HOST").pipe(
*   Config.orElse(() => Config.succeed("localhost"))
* )
* ```
*
* @see {@link withDefault} – fallback only on missing data
*
* @since 4.0.0
*/
var orElse$2 = /*#__PURE__*/ dual(2, (self, that) => {
	return make$25((provider) => catch_(self.parse(provider), (error) => that(error).parse(provider)));
});
/**
* Combines multiple configs into a single config that parses all of them.
*
* When to use:
* - Grouping related configs into a tuple or named struct.
*
* Accepts a tuple (preserves positions), an iterable, or a record of configs.
* Returns a config whose parsed value mirrors the input shape.
*
* **Example** (Combining configs as a struct)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const dbConfig = Config.all({
*   host: Config.string("host"),
*   port: Config.number("port")
* })
*
* const provider = ConfigProvider.fromUnknown({ host: "localhost", port: 5432 })
* // Effect.runSync(dbConfig.parse(provider))
* // { host: "localhost", port: 5432 }
* ```
*
* @since 4.0.0
*/
function all(arg) {
	const configs = Array.isArray(arg) ? arg : Symbol.iterator in arg ? [...arg] : arg;
	if (Array.isArray(configs)) return make$25((provider) => all$1(configs.map((config) => config.parse(provider))));
	else return make$25((provider) => all$1(map$8(configs, (config) => config.parse(provider))));
}
function isMissingDataOnly(issue) {
	switch (issue._tag) {
		case "MissingKey": return true;
		case "InvalidType":
		case "InvalidValue": return isNone(issue.actual) || isSome(issue.actual) && issue.actual.value === void 0;
		case "OneOf": return issue.actual === void 0;
		case "Encoding": return isNone(issue.actual) || isSome(issue.actual) && issue.actual.value === void 0 ? true : isMissingDataOnly(issue.issue);
		case "Pointer":
		case "Filter": return isMissingDataOnly(issue.issue);
		case "UnexpectedKey": return false;
		case "Forbidden": return false;
		case "Composite":
		case "AnyOf": return issue.issues.every(isMissingDataOnly);
	}
}
/**
* Provides a fallback value when the config fails due to missing data.
*
* When to use:
* - Making a config key optional with a sensible default.
*
* Only applies when the error is a `SchemaError` caused exclusively by
* missing data (missing keys, undefined values). Validation errors (wrong
* type, out of range) still propagate. The default is lazily evaluated.
*
* Supports both data-last and data-first calling conventions.
*
* **Example** (Defaulting a missing port)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const port = Config.number("port").pipe(Config.withDefault(3000))
*
* const provider = ConfigProvider.fromUnknown({})
* // Effect.runSync(port.parse(provider)) // 3000
* ```
*
* @see {@link option} – returns `Option` instead of a default value
* @see {@link orElse} – catches all errors, not just missing data
*
* @since 4.0.0
*/
var withDefault = /*#__PURE__*/ dual(2, (self, defaultValue) => {
	return orElse$2(self, (err) => {
		if (isSchemaError(err.cause)) {
			const issue = err.cause.issue;
			if (isMissingDataOnly(issue)) return succeed$1(defaultValue);
		}
		return fail$2(err.cause);
	});
});
/**
* Makes a config optional: returns `Some(value)` on success and `None` when
* data is missing.
*
* When to use:
* - A config key may or may not be present and you want to handle both
*   cases explicitly.
*
* Like {@link withDefault}, only missing-data errors produce `None`.
* Validation errors still propagate.
*
* **Example** (Optional config)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const maybePort = Config.option(Config.number("port"))
*
* const provider = ConfigProvider.fromUnknown({})
* // Effect.runSync(maybePort.parse(provider)) // { _tag: "None" }
* ```
*
* @see {@link withDefault} – provide a concrete fallback value instead
*
* @since 4.0.0
*/
var option$2 = (self) => self.pipe(map$7(some$2), withDefault(none()));
/**
* Constructs a `Config<T>` from a value matching `Wrap<T>`.
*
* When to use:
* - Accepting config from callers who may pass either a single `Config` or a
*   record of individual `Config`s.
*
* If the input is already a `Config`, it is returned as-is. Otherwise, each
* key is recursively unwrapped and combined.
*
* **Example** (Unwrapping a record of configs)
*
* ```ts
* import { Config } from "effect"
*
* interface Options {
*   key: string
* }
*
* const makeConfig = (config: Config.Wrap<Options>): Config.Config<Options> =>
*   Config.unwrap(config)
* ```
*
* @see {@link Wrap} – the utility type accepted by this function
*
* @category Wrap
* @since 4.0.0
*/
var unwrap = (wrapped) => {
	if (isConfig(wrapped)) return wrapped;
	return make$25((provider) => {
		return all$1(Object.entries(wrapped).map(([key, config]) => unwrap(config).parse(provider).pipe(map$11((value) => [key, value])))).pipe(map$11(Object.fromEntries));
	});
};
var dump = /*#__PURE__*/ fnUntraced(function* (provider, path) {
	const stat = yield* provider.load(path);
	if (stat === void 0) return void 0;
	switch (stat._tag) {
		case "Value": return stat.value;
		case "Record": {
			if (stat.value !== void 0) return stat.value;
			const out = {};
			for (const key of stat.keys) {
				const child = yield* dump(provider, [...path, key]);
				if (child !== void 0) out[key] = child;
			}
			return out;
		}
		case "Array": {
			if (stat.value !== void 0) return stat.value;
			const out = [];
			for (let i = 0; i < stat.length; i++) out.push(yield* dump(provider, [...path, i]));
			return out;
		}
	}
});
var recur = /*#__PURE__*/ fnUntraced(function* (ast, provider, path) {
	switch (ast._tag) {
		case "Objects": {
			const out = {};
			for (const ps of ast.propertySignatures) {
				const name = ps.name;
				if (typeof name === "string") {
					const value = yield* recur(ps.type, provider, [...path, name]);
					if (value !== void 0) out[name] = value;
				}
			}
			if (ast.indexSignatures.length > 0) {
				const stat = yield* provider.load(path);
				if (stat && stat._tag === "Record") for (const is of ast.indexSignatures) {
					const matches = _is(is.parameter);
					for (const key of stat.keys) if (!Object.hasOwn(out, key) && matches(key)) {
						const value = yield* recur(is.type, provider, [...path, key]);
						if (value !== void 0) out[key] = value;
					}
				}
			}
			return out;
		}
		case "Arrays": {
			const stat = yield* provider.load(path);
			if (stat && stat._tag === "Value") return stat.value;
			const out = [];
			for (let i = 0; i < ast.elements.length; i++) out.push(yield* recur(ast.elements[i], provider, [...path, i]));
			return out;
		}
		case "Union": return yield* dump(provider, path);
		case "Suspend": return yield* recur(ast.thunk(), provider, path);
		default: {
			const stat = yield* provider.load(path);
			if (stat === void 0) return void 0;
			if (stat._tag === "Value") return stat.value;
			if (stat._tag === "Record" && stat.value !== void 0) return stat.value;
			if (stat._tag === "Array" && stat.value !== void 0) return stat.value;
			return;
		}
	}
});
/**
* Creates a `Config<T>` from a `Schema.Codec`.
*
* When to use:
* - Reading structured or validated config (structs, arrays, unions, branded
*   types, etc.).
* - All convenience constructors (`string`, `number`, …) delegate to this.
*
* The optional `path` sets the root path segment(s) for the config lookup.
* Pass a single string for a flat key or an array for nested paths.
*
* The codec is used to decode the raw `StringTree` produced by the provider
* into `T`. Schema validation errors are wrapped in `ConfigError`.
*
* **Example** (Reading a structured config)
*
* ```ts
* import { Config, ConfigProvider, Effect, Schema } from "effect"
*
* const DbConfig = Config.schema(
*   Schema.Struct({
*     host: Schema.String,
*     port: Schema.Int
*   }),
*   "db"
* )
*
* const provider = ConfigProvider.fromUnknown({
*   db: { host: "localhost", port: 5432 }
* })
*
* // Effect.runSync(DbConfig.parse(provider))
* // { host: "localhost", port: 5432 }
* ```
*
* @see {@link string} / {@link number} / {@link boolean} – shortcuts for
*   single-value configs
*
* @category Schema
* @since 4.0.0
*/
function schema(codec, path) {
	const toCodecStringTree$1 = toCodecStringTree(codec);
	const decodeUnknownEffect$1 = decodeUnknownEffect(toCodecStringTree$1);
	const toCodecStringTreeEncoded = toEncoded(toCodecStringTree$1.ast);
	const defaultPath = typeof path === "string" ? [path] : path ?? [];
	return make$25((provider) => {
		const path = provider.prefix ? [...provider.prefix, ...defaultPath] : defaultPath;
		return recur(toCodecStringTreeEncoded, provider, defaultPath).pipe(flatMapEager((tree) => decodeUnknownEffect$1(tree).pipe(mapErrorEager((issue) => new SchemaError(path.length > 0 ? new Pointer(path, issue) : issue)))), mapErrorEager((cause) => new ConfigError(cause)));
	});
}
/** @internal */
var TrueValues = /*#__PURE__*/ Literals([
	"true",
	"yes",
	"on",
	"1",
	"y"
]);
/** @internal */
var FalseValues = /*#__PURE__*/ Literals([
	"false",
	"no",
	"off",
	"0",
	"n"
]);
/**
* A `Schema.Codec` for boolean values encoded as strings.
*
* When to use:
* - Pass to {@link schema} for custom paths, or use the {@link boolean}
*   convenience constructor.
*
* Accepted string values: `true`, `false`, `yes`, `no`, `on`, `off`, `1`,
* `0`, `y`, `n` (case-sensitive).
*
* @see {@link boolean} – convenience constructor
*
* @category Schema
* @since 4.0.0
*/
var Boolean = /*#__PURE__*/ Literals([...TrueValues.literals, ...FalseValues.literals]).pipe(/*#__PURE__*/ decodeTo(Boolean$1, /*#__PURE__*/ transform({
	decode: (value) => value === "true" || value === "yes" || value === "on" || value === "1" || value === "y",
	encode: (value) => value ? "true" : "false"
})));
/**
* A `Schema.Codec` for `Duration` values encoded as strings.
*
* When to use:
* - Pass to {@link schema} for custom paths, or use the {@link duration}
*   convenience constructor.
*
* Accepts any string that `Duration.fromInput` can parse (e.g.
* `"10 seconds"`, `"500 millis"`).
*
* @see {@link duration} – convenience constructor
*
* @category Schema
* @since 4.0.0
*/
var Duration = /*#__PURE__*/ String$1.pipe(/*#__PURE__*/ decodeTo(Duration$1, {
	decode: /*#__PURE__*/ transformOrFail((s) => {
		const d = fromInput(s);
		return d ? succeed$4(d) : fail$4(new InvalidValue(some$2(s)));
	}),
	encode: /*#__PURE__*/ forbidden(() => "Encoding Duration is not supported")
}));
/**
* A `Schema.Codec` for port numbers (integers in 1–65535).
*
* When to use:
* - Pass to {@link schema} for custom paths, or use the {@link port}
*   convenience constructor.
*
* @see {@link port} – convenience constructor
*
* @category Schema
* @since 4.0.0
*/
var Port = /*#__PURE__*/ Int.check(/*#__PURE__*/ isBetween$1({
	minimum: 1,
	maximum: 65535
}));
/**
* A `Schema.Codec` for `LogLevel` string literals.
*
* When to use:
* - Pass to {@link schema} for custom paths, or use the {@link logLevel}
*   convenience constructor.
*
* Accepted values: `"All"`, `"Fatal"`, `"Error"`, `"Warn"`, `"Info"`,
* `"Debug"`, `"Trace"`, `"None"`.
*
* @see {@link logLevel} – convenience constructor
*
* @category Schema
* @since 4.0.0
*/
var LogLevel = /*#__PURE__*/ Literals(values$6);
/**
* A `Schema.Codec` for key-value record types that can also be parsed from
* a flat comma-separated string.
*
* When to use:
* - Reading key-value maps from a single env var (e.g. OpenTelemetry
*   resource attributes).
*
* Accepts either a JSON-like record from the provider or a flat string like
* `"key1=val1,key2=val2"`. The `separator` (default `","`) and
* `keyValueSeparator` (default `"="`) can be customized.
*
* **Example** (Parsing a comma-separated record)
*
* ```ts
* import { Config, ConfigProvider, Effect, Schema } from "effect"
*
* const schema = Config.Record(Schema.String, Schema.String)
* const config = Config.schema(schema, "OTEL_RESOURCE_ATTRIBUTES")
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     OTEL_RESOURCE_ATTRIBUTES:
*       "service.name=my-service,service.version=1.0.0,custom.attribute=value"
*   }
* })
*
* console.dir(Effect.runSync(config.parse(provider)))
* // {
* //   'service.name': 'my-service',
* //   'service.version': '1.0.0',
* //   'custom.attribute': 'value'
* // }
* ```
*
* @category Schemas
* @since 4.0.0
*/
var Record = (key, value, options) => {
	const record = Record$1(key, value);
	return Union([record, String$1.pipe(decodeTo(Record$1(String$1, String$1), splitKeyValue(options)), decodeTo(record))]);
};
/**
* Creates a config that always fails with the given error.
*
* When to use:
* - Inside {@link orElse} to re-raise a specific error.
* - Testing error handling paths.
*
* @category Constructors
* @since 4.0.0
*/
function fail$2(err) {
	return make$25(() => fail$4(new ConfigError(err)));
}
/**
* Creates a config that always succeeds with the given value, ignoring the
* provider entirely.
*
* When to use:
* - Providing a hardcoded constant inside {@link orElse}.
* - Testing.
*
* **Example** (Constant fallback)
*
* ```ts
* import { Config } from "effect"
*
* const host = Config.string("HOST").pipe(
*   Config.orElse(() => Config.succeed("localhost"))
* )
* ```
*
* @category Constructors
* @since 4.0.0
*/
function succeed$1(value) {
	return make$25(() => succeed$4(value));
}
/**
* Creates a config for a single string value.
*
* Shortcut for `Config.schema(Schema.String, name)`.
*
* When to use:
* - Reading a single string env var or config key.
*
* **Example** (Reading a string config)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const host = Config.string("HOST")
*
* const provider = ConfigProvider.fromUnknown({ HOST: "localhost" })
* // Effect.runSync(host.parse(provider)) // "localhost"
* ```
*
* @see {@link nonEmptyString} – rejects empty strings
* @see {@link schema} – for more complex types
*
* @category Constructors
* @since 4.0.0
*/
function string$2(name) {
	return schema(String$1, name);
}
/**
* Creates a config for a non-empty string value. Fails if the value is an
* empty string.
*
* Shortcut for `Config.schema(Schema.NonEmptyString, name)`.
*
* @see {@link string} – allows empty strings
*
* @category Constructors
* @since 4.0.0
*/
function nonEmptyString$2(name) {
	return schema(NonEmptyString, name);
}
/**
* Creates a config for a numeric value (including `NaN`, `Infinity`).
*
* Shortcut for `Config.schema(Schema.Number, name)`.
*
* @see {@link finite} – rejects `NaN` and `Infinity`
* @see {@link int} – only integers
*
* @category Constructors
* @since 4.0.0
*/
function number$1(name) {
	return schema(Number$1, name);
}
/**
* Creates a config for a finite number (rejects `NaN` and `Infinity`).
*
* Shortcut for `Config.schema(Schema.Finite, name)`.
*
* @see {@link number} – allows `NaN` and `Infinity`
* @see {@link int} – only integers
*
* @category Constructors
* @since 4.0.0
*/
function finite(name) {
	return schema(Finite, name);
}
/**
* Creates a config for an integer value. Rejects floats.
*
* Shortcut for `Config.schema(Schema.Int, name)`.
*
* @see {@link number} – allows any number
* @see {@link port} – integers in 1–65535
*
* @category Constructors
* @since 4.0.0
*/
function int(name) {
	return schema(Int, name);
}
/**
* Creates a config that only accepts a specific literal value.
*
* Shortcut for `Config.schema(Schema.Literal(literal), name)`.
*
* **Example** (Restricting to a literal)
*
* ```ts
* import { Config } from "effect"
*
* const env = Config.literal("production", "ENV")
* ```
*
* @category Constructors
* @since 4.0.0
*/
function literal(literal, name) {
	return schema(Literal(literal), name);
}
/**
* Creates a config for a boolean value parsed from common string
* representations.
*
* Shortcut for `Config.schema(Config.Boolean, name)`.
*
* Accepted values: `true`, `false`, `yes`, `no`, `on`, `off`, `1`, `0`,
* `y`, `n`.
*
* **Example** (Reading a boolean flag)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const flag = yield* Config.boolean("FEATURE_FLAG")
*   console.log(flag)
* })
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     FEATURE_FLAG: "yes"
*   }
* })
*
* Effect.runSync(
*   program.pipe(Effect.provideService(ConfigProvider.ConfigProvider, provider))
* )
* // Output: true
* ```
*
* @category Constructors
* @since 4.0.0
*/
function boolean$2(name) {
	return schema(Boolean, name);
}
/**
* Creates a config for a `Duration` value parsed from a human-readable
* string.
*
* Shortcut for `Config.schema(Config.Duration, name)`.
*
* Accepts any string that `Duration.fromInput` can parse (e.g.
* `"10 seconds"`, `"500 millis"`, `"2 minutes"`).
*
* **Example** (Reading a duration)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const duration = yield* Config.duration("DURATION")
*   console.log(duration)
* })
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     DURATION: "10 seconds"
*   }
* })
*
* Effect.runSync(
*   program.pipe(Effect.provideService(ConfigProvider.ConfigProvider, provider))
* )
* // Output: Duration { _tag: "millis", value: 10000 }
* ```
*
* @category Constructors
* @since 4.0.0
*/
function duration(name) {
	return schema(Duration, name);
}
/**
* Creates a config for a port number (integer in 1–65535).
*
* Shortcut for `Config.schema(Config.Port, name)`.
*
* **Example** (Reading a port)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const port = yield* Config.port("PORT")
*   console.log(port)
* })
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     PORT: "8080"
*   }
* })
*
* Effect.runSync(
*   program.pipe(Effect.provideService(ConfigProvider.ConfigProvider, provider))
* )
* // Output: 8080
* ```
*
* @category Constructors
* @since 4.0.0
*/
function port(name) {
	return schema(Port, name);
}
/**
* Creates a config for a log level string.
*
* Shortcut for `Config.schema(Config.LogLevel, name)`.
*
* Accepted values: `"All"`, `"Fatal"`, `"Error"`, `"Warn"`, `"Info"`,
* `"Debug"`, `"Trace"`, `"None"`.
*
* **Example** (Reading a log level)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const logLevel = yield* Config.logLevel("LOG_LEVEL")
*   console.log(logLevel)
* })
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     LOG_LEVEL: "Info"
*   }
* })
*
* Effect.runSync(
*   program.pipe(Effect.provideService(ConfigProvider.ConfigProvider, provider))
* )
* // Output: "Info"
* ```
*
* @category Constructors
* @since 4.0.0
*/
function logLevel(name) {
	return schema(LogLevel, name);
}
/**
* Creates a config for a redacted string value. The parsed result is wrapped
* in a `Redacted` container that hides the value from logs and `toString`.
*
* Shortcut for `Config.schema(Schema.Redacted(Schema.String), name)`.
*
* **Example** (Reading a secret)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const apiKey = yield* Config.redacted("API_KEY")
*   console.log(apiKey)
* })
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     API_KEY: "sk-1234567890abcdef"
*   }
* })
*
* Effect.runSync(
*   program.pipe(Effect.provideService(ConfigProvider.ConfigProvider, provider))
* )
* // Output: <redacted>
* ```
*
* @category Constructors
* @since 4.0.0
*/
function redacted(name) {
	return schema(Redacted(String$1), name);
}
/**
* Creates a config for a `URL` value parsed from a string.
*
* Fails if the string cannot be parsed by the `URL` constructor.
*
* **Example** (Reading a URL)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const url = yield* Config.url("URL")
*   console.log(url)
* })
*
* const provider = ConfigProvider.fromEnv({
*   env: {
*     URL: "https://example.com"
*   }
* })
*
* Effect.runSync(
*   program.pipe(Effect.provideService(ConfigProvider.ConfigProvider, provider))
* )
* // Output:
* // URL {
* //   href: 'https://example.com/',
* //   origin: 'https://example.com',
* //   protocol: 'https:',
* //   username: '',
* //   password: '',
* //   host: 'example.com',
* //   hostname: 'example.com',
* //   port: '',
* //   pathname: '/',
* //   search: '',
* //   searchParams: URLSearchParams {},
* //   hash: ''
* // }
* ```
*
* @category Constructors
* @since 4.0.0
*/
function url(name) {
	return schema(URL, name);
}
/**
* Creates a config for a `Date` value parsed from a string.
*
* Fails with a `SchemaError` if the string produces an invalid `Date`.
*
* Shortcut for `Config.schema(Schema.DateValid, name)`.
*
* **Example** (Reading a date)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const createdAt = Config.date("CREATED_AT")
*
* const provider = ConfigProvider.fromUnknown({ CREATED_AT: "2024-01-15" })
* // Effect.runSync(createdAt.parse(provider))
* // Date("2024-01-15T00:00:00.000Z")
* ```
*
* @category Constructors
* @since 4.0.0
*/
function date$1(name) {
	return schema(DateValid, name);
}
/**
* Scopes a config under a named prefix.
*
* When to use:
* - Grouping related config keys under a common namespace (e.g.
*   `"database"`, `"redis"`).
* - Building reusable config fragments that callers nest at different paths.
*
* The prefix is prepended to every key the inner config reads. With
* `fromUnknown` this means an extra object level; with `fromEnv` it means
* a `_`-separated prefix on env var names.
*
* Multiple `nested` calls compose: the outermost name becomes the
* outermost path segment.
*
* **Example** (Nesting a struct config under `"database"`)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const dbConfig = Config.all({
*   host: Config.string("host"),
*   port: Config.number("port")
* }).pipe(Config.nested("database"))
*
* const provider = ConfigProvider.fromUnknown({
*   database: { host: "localhost", port: "5432" }
* })
* // Effect.runSync(dbConfig.parse(provider))
* // { host: "localhost", port: 5432 }
* ```
*
* **Example** (Env vars with nested prefix)
*
* ```ts
* import { Config, ConfigProvider, Effect } from "effect"
*
* const host = Config.string("host").pipe(Config.nested("database"))
*
* const provider = ConfigProvider.fromEnv({
*   env: { database_host: "localhost" }
* })
* // Effect.runSync(host.parse(provider)) // "localhost"
* ```
*
* @see {@link all} – combine multiple configs into a struct
* @see {@link schema} – read structured config from a schema
*
* @category Combinators
* @since 4.0.0
*/
var nested = /*#__PURE__*/ dual(2, (self, name) => make$25((provider) => self.parse(nested$1(provider, name))));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Console.js
var Console_exports = /* @__PURE__ */ __exportAll({
	Console: () => Console,
	assert: () => assert,
	clear: () => clear$6,
	consoleWith: () => consoleWith,
	count: () => count,
	countReset: () => countReset,
	debug: () => debug,
	dir: () => dir,
	dirxml: () => dirxml,
	error: () => error,
	group: () => group,
	info: () => info,
	log: () => log,
	table: () => table,
	time: () => time,
	timeLog: () => timeLog,
	trace: () => trace,
	warn: () => warn,
	withGroup: () => withGroup,
	withTime: () => withTime
});
/**
* A reference to the current console service in the Effect system.
*
* This reference allows you to access the current console implementation
* from within the Effect context.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Console.consoleWith((console) =>
*   Effect.sync(() => {
*     console.log("Hello from current console!")
*   })
* )
* ```
*
* @since 4.0.0
* @category references
*/
var Console = ConsoleRef;
/**
* Creates an Effect that provides access to the current console instance.
*
* This function allows you to access the console service and perform operations
* with it within an Effect context.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Console.consoleWith((console) =>
*   Effect.sync(() => {
*     console.log("Hello, world!")
*     console.error("This is an error message")
*   })
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var consoleWith = (f) => withFiber((fiber) => f(fiber.getRef(Console)));
/**
* Writes an assertion message to the console if the condition is false.
*
* If the condition is true, nothing happens. If the condition is false,
* the message is logged to the console as an error.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.assert(2 + 2 === 4, "Math is working correctly")
*   yield* Console.assert(2 + 2 === 5, "This will be logged as an error")
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var assert = (condition, ...args) => consoleWith((console) => sync(() => {
	console.assert(condition, ...args);
}));
/**
* Clears the console.
*
* This function clears all previously logged messages from the console.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.log("This will be cleared")
*   yield* Console.clear
*   yield* Console.log("This appears after clearing")
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var clear$6 = /*#__PURE__*/ consoleWith((console) => sync(() => {
	console.clear();
}));
/**
* Logs the number of times that this particular call to count has been called.
*
* This function maintains a counter for each unique label and increments it
* each time count is called with that label.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.count("my-counter")
*   yield* Console.count("my-counter") // Will show: my-counter: 2
*   yield* Console.count() // Default counter
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var count = (label) => consoleWith((console) => sync(() => {
	console.count(label);
}));
/**
* Resets the counter for the given label.
*
* This function resets the counter associated with the specified label
* back to zero.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.count("my-counter")
*   yield* Console.count("my-counter") // Will show: my-counter: 2
*   yield* Console.countReset("my-counter")
*   yield* Console.count("my-counter") // Will show: my-counter: 1
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var countReset = (label) => consoleWith((console) => sync(() => {
	console.countReset(label);
}));
/**
* Outputs a debug message to the console.
*
* This function logs messages at the debug level, which may be filtered
* out in production environments.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.debug("Debug info:", { userId: 123, action: "login" })
*   yield* Console.debug("Processing step", 1, "of", 5)
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var debug = (...args) => consoleWith((console) => sync(() => {
	console.debug(...args);
}));
/**
* Displays an interactive list of the properties of the specified object.
*
* This function provides a detailed view of an object's properties,
* which can be useful for debugging complex data structures.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const obj = { name: "John", age: 30, nested: { city: "New York" } }
*   yield* Console.dir(obj)
*   yield* Console.dir(obj, { depth: 2, colors: true })
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var dir = (item, options) => consoleWith((console) => sync(() => {
	console.dir(item, options);
}));
/**
* Displays an interactive tree of the descendant elements of the specified XML/HTML element.
*
* This function is particularly useful for inspecting DOM elements in browser environments.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   // In a browser environment
*   const element = document.getElementById("myElement")
*   yield* Console.dirxml(element)
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var dirxml = (...args) => consoleWith((console) => sync(() => {
	console.dirxml(...args);
}));
/**
* Outputs an error message to the console.
*
* This function logs messages at the error level, typically displayed
* in red or with an error icon in most console implementations.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.error("Something went wrong!")
*   yield* Console.error("Error details:", {
*     code: 500,
*     message: "Internal Server Error"
*   })
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var error = (...args) => consoleWith((console) => sync(() => {
	console.error(...args);
}));
/**
* Creates a new inline group in the console and returns a scoped Effect.
*
* This function creates a collapsible group of console messages. The group
* is automatically closed when the Effect's scope is finalized.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       yield* Console.group({ label: "User Processing" })
*       yield* Console.log("Loading user data...")
*       yield* Console.log("Validating user...")
*       yield* Console.log("User processed successfully")
*     })
*   )
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var group = (options) => consoleWith((console) => acquireRelease(sync(() => {
	if (options?.collapsed) console.groupCollapsed(options.label);
	else console.group(options?.label);
}), () => sync(() => {
	console.groupEnd();
})));
/**
* Outputs an informational message to the console.
*
* This function logs messages at the info level, typically displayed
* with an info icon in most console implementations.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.info("Application started successfully")
*   yield* Console.info("Server configuration:", {
*     port: 3000,
*     env: "development"
*   })
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var info = (...args) => consoleWith((console) => sync(() => {
	console.info(...args);
}));
/**
* Outputs a message to the console.
*
* This is the most commonly used console method for general purpose logging.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.log("Hello, world!")
*   yield* Console.log("User data:", { name: "John", age: 30 })
*   yield* Console.log("Processing", 42, "items")
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var log = (...args) => consoleWith((console) => sync(() => {
	console.log(...args);
}));
/**
* Displays tabular data as a table in the console.
*
* This function takes tabular data and displays it in a formatted table,
* making it easier to read structured data.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   const users = [
*     { name: "John", age: 30, city: "New York" },
*     { name: "Jane", age: 25, city: "London" },
*     { name: "Bob", age: 35, city: "Paris" }
*   ]
*   yield* Console.table(users)
*   yield* Console.table(users, ["name", "age"]) // Only show specific columns
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var table = (tabularData, properties) => consoleWith((console) => sync(() => {
	console.table(tabularData, properties);
}));
/**
* Starts a timer that can be used to compute the duration of an operation.
*
* This function returns a scoped Effect that starts a timer when entered
* and automatically ends the timer when the scope is finalized.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       yield* Console.time("operation-timer")
*       yield* Effect.sleep("1 second")
*       yield* Console.log("Operation completed")
*       // Timer ends automatically when scope closes
*     })
*   )
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var time = (label) => consoleWith((console) => acquireRelease(sync(() => {
	console.time(label);
}), () => sync(() => {
	console.timeEnd(label);
})));
/**
* Logs the current value of a timer that was previously started by calling time.
*
* This function logs the elapsed time for a timer without stopping it,
* allowing you to track progress of long-running operations.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       yield* Console.time("long-operation")
*       yield* Effect.sleep("500 millis")
*       yield* Console.timeLog("long-operation", "Halfway done")
*       yield* Effect.sleep("500 millis")
*       // Timer ends when scope closes
*     })
*   )
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var timeLog = (label, ...args) => consoleWith((console) => sync(() => {
	console.timeLog(label, ...args);
}));
/**
* Outputs a stack trace to the console.
*
* This function logs the current stack trace, which is useful for debugging
* to understand how the current point in the code was reached.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.trace("Debug trace point")
*   yield* Console.trace("Function call:", { functionName: "processData" })
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var trace = (...args) => consoleWith((console) => sync(() => {
	console.trace(...args);
}));
/**
* Outputs a warning message to the console.
*
* This function logs messages at the warning level, typically displayed
* in yellow or with a warning icon in most console implementations.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.warn("This feature is deprecated")
*   yield* Console.warn("Performance warning:", {
*     slowQuery: "SELECT * FROM large_table"
*   })
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var warn = (...args) => consoleWith((console) => sync(() => {
	console.warn(...args);
}));
/**
* Wraps an Effect with a console group.
*
* This function creates a console group around the execution of an Effect,
* automatically starting the group before the Effect runs and ending it
* after the Effect completes.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.withGroup(
*     Effect.gen(function*() {
*       yield* Console.log("Step 1: Initialize")
*       yield* Console.log("Step 2: Process")
*       yield* Console.log("Step 3: Complete")
*     }),
*     { label: "Processing Steps", collapsed: false }
*   )
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var withGroup = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, options) => consoleWith((console) => acquireUseRelease(sync(() => {
	if (options?.collapsed) console.groupCollapsed(options.label);
	else console.group(options?.label);
}), () => self, () => sync(() => {
	console.groupEnd();
}))));
/**
* Wraps an Effect with a timer.
*
* This function measures the execution time of an Effect, automatically
* starting a timer before the Effect runs and logging the elapsed time
* after the Effect completes.
*
* @example
* ```ts
* import { Console, Effect } from "effect"
*
* const program = Effect.gen(function*() {
*   yield* Console.withTime(
*     Effect.gen(function*() {
*       yield* Effect.sleep("1 second")
*       yield* Console.log("Operation completed")
*     }),
*     "my-operation"
*   )
* })
* ```
*
* @since 2.0.0
* @category accessor
*/
var withTime = /*#__PURE__*/ dual((args) => isEffect(args[0]), (self, label) => consoleWith((console) => acquireUseRelease(sync(() => {
	console.time(label);
}), () => self, () => sync(() => {
	console.timeEnd(label);
}))));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Differ.js
var Differ_exports = /* @__PURE__ */ __exportAll({});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/FiberHandle.js
/**
* @since 2.0.0
*/
var FiberHandle_exports = /* @__PURE__ */ __exportAll({
	awaitEmpty: () => awaitEmpty$1,
	clear: () => clear$5,
	get: () => get$14,
	getUnsafe: () => getUnsafe$7,
	isFiberHandle: () => isFiberHandle,
	join: () => join$1,
	make: () => make$24,
	makeRuntime: () => makeRuntime$1,
	makeRuntimePromise: () => makeRuntimePromise$1,
	run: () => run$1,
	runtime: () => runtime$1,
	runtimePromise: () => runtimePromise$1,
	set: () => set$10,
	setUnsafe: () => setUnsafe$1
});
var TypeId$26 = "~effect/FiberHandle";
/**
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   console.log(FiberHandle.isFiberHandle(handle)) // true
*   console.log(FiberHandle.isFiberHandle("not a handle")) // false
* })
* ```
*
* @since 2.0.0
* @category refinements
*/
var isFiberHandle = (u) => hasProperty(u, TypeId$26);
var Proto$7 = {
	[TypeId$26]: TypeId$26,
	...PipeInspectableProto,
	toJSON() {
		return {
			_id: "FiberHandle",
			state: this.state
		};
	}
};
var makeUnsafe$7 = () => {
	const self = Object.create(Proto$7);
	self.state = {
		_tag: "Open",
		fiber: void 0
	};
	self.deferred = makeUnsafe$8();
	return self;
};
/**
* A FiberHandle can be used to store a single fiber.
* When the associated Scope is closed, the contained fiber will be interrupted.
*
* You can add a fiber to the handle using `FiberHandle.run`, and the fiber will
* be automatically removed from the FiberHandle when it completes.
*
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   // run some effects
*   yield* FiberHandle.run(handle, Effect.never)
*   // this will interrupt the previous fiber
*   yield* FiberHandle.run(handle, Effect.never)
*
*   yield* Effect.sleep(1000)
* }).pipe(
*   Effect.scoped // The fiber will be interrupted when the scope is closed
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$24 = () => acquireRelease$1(sync$1(() => makeUnsafe$7()), (handle) => {
	const state = handle.state;
	if (state._tag === "Closed") return void_$1;
	handle.state = { _tag: "Closed" };
	return state.fiber ? into(asVoid(interruptAs(state.fiber, internalFiberId$1)), handle.deferred) : done$1(handle.deferred, void_$2);
});
/**
* Create an Effect run function that is backed by a FiberHandle.
*
* @example
* ```ts
* import { Effect, Fiber, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const run = yield* FiberHandle.makeRuntime<never>()
*
*   // Run effects and get fibers back
*   const fiberA = run(Effect.succeed("first"))
*   const fiberB = run(Effect.succeed("second"))
*
*   // The second fiber will interrupt the first
*   const resultA = yield* Fiber.await(fiberA)
*   const resultB = yield* Fiber.await(fiberB)
* }).pipe(Effect.scoped)
* ```
*
* @since 2.0.0
* @category constructors
*/
var makeRuntime$1 = () => flatMap$2(make$24(), (self) => runtime$1(self)());
/**
* Create an Effect run function that is backed by a FiberHandle.
*
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const run = yield* FiberHandle.makeRuntimePromise()
*
*   // Run effects and get promises back
*   const promise = run(Effect.succeed("hello"))
*   const result = yield* Effect.promise(() => promise)
*   console.log(result) // "hello"
* }).pipe(Effect.scoped)
* ```
*
* @since 3.13.0
* @category constructors
*/
var makeRuntimePromise$1 = () => flatMap$2(make$24(), (self) => runtimePromise$1(self)());
var internalFiberId$1 = -1;
var isInternalInterruption$1 = /*#__PURE__*/ toPredicate(/*#__PURE__*/ compose(filterInterruptors, /*#__PURE__*/ has$9(internalFiberId$1)));
/**
* Set the fiber in a FiberHandle. When the fiber completes, it will be removed from the FiberHandle.
* If a fiber is already running, it will be interrupted unless `options.onlyIfMissing` is set.
*
* @example
* ```ts
* import { Effect, Fiber, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*   const fiber = Effect.runFork(Effect.succeed("hello"))
*
*   // Set the fiber directly (unsafe)
*   FiberHandle.setUnsafe(handle, fiber)
*
*   // The fiber is now managed by the handle
*   const result = yield* Fiber.await(fiber)
*   console.log(result) // "hello"
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var setUnsafe$1 = /*#__PURE__*/ dual((args) => isFiberHandle(args[0]), (self, fiber, options) => {
	if (self.state._tag === "Closed") {
		fiber.interruptUnsafe(internalFiberId$1);
		return;
	} else if (self.state.fiber !== void 0) {
		if (options?.onlyIfMissing === true) {
			fiber.interruptUnsafe(internalFiberId$1);
			return;
		} else if (self.state.fiber === fiber) return;
		self.state.fiber.interruptUnsafe(internalFiberId$1);
		self.state.fiber = void 0;
	}
	self.state.fiber = fiber;
	fiber.addObserver((exit) => {
		if (self.state._tag === "Open" && fiber === self.state.fiber) self.state.fiber = void 0;
		if (isFailure(exit) && (options?.propagateInterruption === true ? !isInternalInterruption$1(exit.cause) : !hasInterruptsOnly(exit.cause))) doneUnsafe(self.deferred, exit);
	});
});
/**
* Set the fiber in the `FiberHandle`. When the fiber completes, it will be
* removed from the `FiberHandle`.
*
* If a fiber already exists in the `FiberHandle`, it will be interrupted
* unless `options.onlyIfMissing` is set.
*
* @example
* ```ts
* import { Effect, Fiber, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*   const fiber = Effect.runFork(Effect.succeed("hello"))
*
*   // Set the fiber safely
*   yield* FiberHandle.set(handle, fiber)
*
*   // The fiber is now managed by the handle
*   const result = yield* Fiber.await(fiber)
*   console.log(result) // "hello"
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var set$10 = /*#__PURE__*/ dual((args) => isFiberHandle(args[0]), (self, fiber, options) => sync$1(() => setUnsafe$1(self, fiber, {
	onlyIfMissing: options?.onlyIfMissing,
	propagateInterruption: options?.propagateInterruption
})));
/**
* Retrieve the fiber from the FiberHandle.
*
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   // No fiber initially
*   const emptyFiber = FiberHandle.getUnsafe(handle)
*   console.log(emptyFiber === undefined) // true
*
*   // Add a fiber
*   yield* FiberHandle.run(handle, Effect.succeed("hello"))
*   const fiber = FiberHandle.getUnsafe(handle)
*   console.log(fiber !== undefined) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
function getUnsafe$7(self) {
	return self.state._tag === "Closed" ? void 0 : self.state.fiber;
}
/**
* Retrieve the fiber from the FiberHandle.
*
* @example
* ```ts
* import { Effect, Fiber, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   // Add a fiber
*   yield* FiberHandle.run(handle, Effect.succeed("hello"))
*
*   // Get the fiber (fails if no fiber)
*   const fiber = yield* FiberHandle.get(handle)
*   if (fiber) {
*     const result = yield* Fiber.await(fiber)
*     console.log(result) // "hello"
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
function get$14(self) {
	return suspend(() => succeed$4(getUnsafe$7(self)));
}
/**
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   // Add a fiber
*   yield* FiberHandle.run(handle, Effect.never)
*
*   // Clear the handle, interrupting the fiber
*   yield* FiberHandle.clear(handle)
*
*   // The handle is now empty
*   const fiber = FiberHandle.getUnsafe(handle)
*   console.log(fiber) // undefined
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var clear$5 = (self) => uninterruptibleMask((restore) => {
	if (self.state._tag === "Closed" || self.state.fiber === void 0) return void_$1;
	return andThen(restore(interruptAs(self.state.fiber, internalFiberId$1)), sync$1(() => {
		if (self.state._tag === "Open") self.state.fiber = void 0;
	}));
});
var constInterruptedFiber$1 = /*#__PURE__*/ function() {
	let fiber = void 0;
	return () => {
		if (fiber === void 0) fiber = runFork(interrupt$1);
		return fiber;
	};
}();
/**
* Run an Effect and add the forked fiber to the FiberHandle.
* When the fiber completes, it will be removed from the FiberHandle.
*
* @example
* ```ts
* import { Effect, Fiber, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   // Run an effect and get the fiber
*   const fiber = yield* FiberHandle.run(handle, Effect.succeed("hello"))
*   const result = yield* Fiber.await(fiber)
*   console.log(result) // "hello"
*
*   // Running another effect will interrupt the previous one
*   const fiber2 = yield* FiberHandle.run(handle, Effect.succeed("world"))
*   const result2 = yield* Fiber.await(fiber2)
*   console.log(result2) // "world"
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var run$1 = function() {
	const self = arguments[0];
	if (isEffect$1(arguments[1])) return runImpl$1(self, arguments[1], arguments[2]);
	const options = arguments[1];
	return (effect) => runImpl$1(self, effect, options);
};
var runImpl$1 = (self, effect, options) => withFiber$1((parent) => {
	if (self.state._tag === "Closed") return interrupt$1;
	else if (self.state.fiber !== void 0 && options?.onlyIfMissing === true) return sync$1(constInterruptedFiber$1);
	const fiber = runForkWith(parent.services)(effect);
	setUnsafe$1(self, fiber, options);
	return succeed$4(fiber);
});
/**
* Capture a Runtime and use it to fork Effect's, adding the forked fibers to the FiberHandle.
*
* @example
* ```ts
* import { Effect, FiberHandle, ServiceMap } from "effect"
*
* interface Users {
*   readonly _: unique symbol
* }
* const Users = ServiceMap.Service<Users, {
*   getAll: Effect.Effect<Array<unknown>>
* }>("Users")
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*   const run = yield* FiberHandle.runtime(handle)<Users>()
*
*   // run an effect and set the fiber in the handle
*   run(Effect.andThen(Users.asEffect(), (_) => _.getAll))
*
*   // this will interrupt the previous fiber
*   run(Effect.andThen(Users.asEffect(), (_) => _.getAll))
* }).pipe(
*   Effect.scoped // The fiber will be interrupted when the scope is closed
* )
* ```
*
* @since 2.0.0
* @category combinators
*/
var runtime$1 = (self) => () => map$11(services(), (services) => {
	const runFork = runForkWith(services);
	return (effect, options) => {
		if (self.state._tag === "Closed") return constInterruptedFiber$1();
		else if (self.state.fiber !== void 0 && options?.onlyIfMissing === true) return constInterruptedFiber$1();
		const fiber = runFork(effect, options);
		setUnsafe$1(self, fiber, options);
		return fiber;
	};
});
/**
* Capture a Runtime and use it to fork Effect's, adding the forked fibers to the FiberHandle.
*
* The returned run function will return Promise's that will resolve when the
* fiber completes.
*
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*   const runPromise = yield* FiberHandle.runtimePromise(handle)<never>()
*
*   // Run an effect and get a promise
*   const promise = runPromise(Effect.succeed("hello"))
*   const result = yield* Effect.promise(() => promise)
*   console.log(result) // "hello"
* })
* ```
*
* @since 3.13.0
* @category combinators
*/
var runtimePromise$1 = (self) => () => map$11(runtime$1(self)(), (runFork) => (effect, options) => new Promise((resolve, reject) => runFork(effect, options).addObserver((exit) => {
	if (isSuccess$1(exit)) resolve(exit.value);
	else reject(squash(exit.cause));
})));
/**
* If any of the Fiber's in the handle terminate with a failure,
* the returned Effect will terminate with the first failure that occurred.
*
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*   yield* FiberHandle.set(handle, Effect.runFork(Effect.fail("error")))
*
*   // parent fiber will fail with "error"
*   yield* FiberHandle.join(handle)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var join$1 = (self) => _await(self.deferred);
/**
* Wait for the fiber in the FiberHandle to complete.
*
* @example
* ```ts
* import { Effect, FiberHandle } from "effect"
*
* Effect.gen(function*() {
*   const handle = yield* FiberHandle.make()
*
*   // Start a long-running effect
*   yield* FiberHandle.run(handle, Effect.sleep(1000))
*
*   // Wait for the fiber to complete
*   yield* FiberHandle.awaitEmpty(handle)
*
*   console.log("Fiber completed")
* })
* ```
*
* @since 3.13.0
* @category combinators
*/
var awaitEmpty$1 = (self) => suspend(() => {
	if (self.state._tag === "Closed" || self.state.fiber === void 0) return void_$1;
	return await_$1(self.state.fiber);
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/FiberMap.js
/**
* @since 2.0.0
*/
var FiberMap_exports = /* @__PURE__ */ __exportAll({
	awaitEmpty: () => awaitEmpty,
	clear: () => clear$4,
	get: () => get$13,
	getUnsafe: () => getUnsafe$6,
	has: () => has$7,
	hasUnsafe: () => hasUnsafe,
	isFiberMap: () => isFiberMap,
	join: () => join,
	make: () => make$23,
	makeRuntime: () => makeRuntime,
	makeRuntimePromise: () => makeRuntimePromise,
	remove: () => remove$6,
	run: () => run,
	runtime: () => runtime,
	runtimePromise: () => runtimePromise,
	set: () => set$9,
	setUnsafe: () => setUnsafe,
	size: () => size$10
});
var TypeId$25 = "~effect/FiberMap";
/**
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   console.log(FiberMap.isFiberMap(map)) // true
*   console.log(FiberMap.isFiberMap({})) // false
*   console.log(FiberMap.isFiberMap(null)) // false
* })
* ```
*
* @since 2.0.0
* @category refinements
*/
var isFiberMap = (u) => hasProperty(u, TypeId$25);
var Proto$6 = {
	[TypeId$25]: TypeId$25,
	[Symbol.iterator]() {
		if (this.state._tag === "Closed") return empty$7();
		return this.state.backing[Symbol.iterator]();
	},
	...PipeInspectableProto,
	toJSON() {
		return {
			_id: "FiberMap",
			state: this.state
		};
	}
};
var makeUnsafe$6 = (backing, deferred) => {
	const self = Object.create(Proto$6);
	self.state = {
		_tag: "Open",
		backing
	};
	self.deferred = deferred;
	return self;
};
/**
* A FiberMap can be used to store a collection of fibers, indexed by some key.
* When the associated Scope is closed, all fibers in the map will be interrupted.
*
* You can add fibers to the map using `FiberMap.set` or `FiberMap.run`, and the fibers will
* be automatically removed from the FiberMap when they complete.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // run some effects and add the fibers to the map
*   yield* FiberMap.run(map, "fiber a", Effect.never)
*   yield* FiberMap.run(map, "fiber b", Effect.never)
*
*   yield* Effect.sleep(1000)
* }).pipe(
*   Effect.scoped // The fibers will be interrupted when the scope is closed
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$23 = () => acquireRelease$1(sync$1(() => makeUnsafe$6(empty$12(), makeUnsafe$8())), (map) => suspend(() => {
	const state = map.state;
	if (state._tag === "Closed") return void_$1;
	map.state = { _tag: "Closed" };
	return interruptAll(values$7(state.backing)).pipe(into(map.deferred));
}));
/**
* Create an Effect run function that is backed by a FiberMap.
*
* @example
* ```ts
* import { Effect, Fiber, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const run = yield* FiberMap.makeRuntime<never, string>()
*
*   // Run effects and get back fibers
*   const fiber1 = run("task1", Effect.succeed("Hello"))
*   const fiber2 = run("task2", Effect.succeed("World"))
*
*   // Await the results
*   const result1 = yield* Fiber.await(fiber1)
*   const result2 = yield* Fiber.await(fiber2)
*
*   console.log(result1, result2) // "Hello", "World"
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var makeRuntime = () => flatMap$2(make$23(), (self) => runtime(self)());
/**
* Create an Effect run function that is backed by a FiberMap.
* Returns a Promise instead of a Fiber for more convenient use with async/await.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const run = yield* FiberMap.makeRuntimePromise<never, string>()
*
*   // Run effects and get back promises
*   const promise1 = run("task1", Effect.succeed("Hello"))
*   const promise2 = run("task2", Effect.succeed("World"))
*
*   // Convert to Effect and await
*   const result1 = yield* Effect.promise(() => promise1)
*   const result2 = yield* Effect.promise(() => promise2)
*
*   console.log(result1, result2) // "Hello", "World"
* })
* ```
*
* @since 3.13.0
* @category constructors
*/
var makeRuntimePromise = () => flatMap$2(make$23(), (self) => runtimePromise(self)());
var internalFiberId = -1;
var isInternalInterruption = /*#__PURE__*/ toPredicate(/*#__PURE__*/ compose(filterInterruptors, /*#__PURE__*/ has$9(internalFiberId)));
/**
* Add a fiber to the FiberMap. When the fiber completes, it will be removed from the FiberMap.
* If the key already exists in the FiberMap, the previous fiber will be interrupted.
*
* @example
* ```ts
* import { Effect, Fiber, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Create a fiber and add it to the map
*   const fiber = yield* Effect.forkChild(Effect.succeed("Hello"))
*   FiberMap.setUnsafe(map, "greeting", fiber)
*
*   // The fiber will be automatically removed when it completes
*   const result = yield* Fiber.await(fiber)
*   console.log(result) // "Hello"
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var setUnsafe = /*#__PURE__*/ dual((args) => isFiberMap(args[0]), (self, key, fiber, options) => {
	if (self.state._tag === "Closed") {
		fiber.interruptUnsafe(internalFiberId);
		return;
	}
	const previous = get$18(self.state.backing, key);
	if (previous._tag === "Some") {
		if (options?.onlyIfMissing === true) {
			fiber.interruptUnsafe(internalFiberId);
			return;
		} else if (previous.value === fiber) return;
		previous.value.interruptUnsafe(internalFiberId);
	}
	set$13(self.state.backing, key, fiber);
	fiber.addObserver((exit) => {
		if (self.state._tag === "Closed") return;
		const current = get$18(self.state.backing, key);
		if (isSome(current) && fiber === current.value) remove$9(self.state.backing, key);
		if (isFailure(exit) && (options?.propagateInterruption === true ? !isInternalInterruption(exit.cause) : !hasInterruptsOnly(exit.cause))) doneUnsafe(self.deferred, exit);
	});
});
/**
* Add a fiber to the FiberMap. When the fiber completes, it will be removed from the FiberMap.
* If the key already exists in the FiberMap, the previous fiber will be interrupted.
* This is the Effect-wrapped version of `setUnsafe`.
*
* @example
* ```ts
* import { Effect, Fiber, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Create a fiber and add it to the map using Effect
*   const fiber = yield* Effect.forkChild(Effect.succeed("Hello"))
*   yield* FiberMap.set(map, "greeting", fiber)
*
*   // The fiber will be automatically removed when it completes
*   const result = yield* Fiber.await(fiber)
*   console.log(result) // "Hello"
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var set$9 = /*#__PURE__*/ dual((args) => isFiberMap(args[0]), (self, key, fiber, options) => sync$1(() => setUnsafe(self, key, fiber, options)));
/**
* Retrieve a fiber from the FiberMap.
*
* @example
* ```ts
* import { Effect, Fiber, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add a fiber to the map
*   const fiber = yield* Effect.forkChild(Effect.succeed("Hello"))
*   FiberMap.setUnsafe(map, "greeting", fiber)
*
*   // Retrieve the fiber
*   const retrieved = FiberMap.getUnsafe(map, "greeting")
*   if (retrieved) {
*     const result = yield* Fiber.await(retrieved)
*     console.log(result) // "Hello"
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var getUnsafe$6 = /*#__PURE__*/ dual(2, (self, key) => {
	return self.state._tag === "Closed" ? void 0 : getOrUndefined(get$18(self.state.backing, key));
});
/**
* Retrieve a fiber from the FiberMap.
*
* Returns an Effect that fails with `NoSuchElementError` if the key is not found.
*
* @example
* ```ts
* import { Effect, Fiber, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add a fiber to the map
*   const fiber = yield* Effect.forkChild(Effect.succeed("Hello"))
*   yield* FiberMap.set(map, "greeting", fiber)
*
*   // Retrieve the fiber with error handling
*   const retrieved = yield* FiberMap.get(map, "greeting")
*   if (retrieved) {
*     const result = yield* Fiber.await(retrieved)
*     console.log(result) // "Hello"
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var get$13 = /*#__PURE__*/ dual(2, (self, key) => suspend(() => succeed$4(getUnsafe$6(self, key))));
/**
* Check if a key exists in the FiberMap.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add a fiber to the map
*   yield* FiberMap.run(map, "task1", Effect.succeed("Hello"))
*
*   // Check if keys exist
*   console.log(FiberMap.hasUnsafe(map, "task1")) // true
*   console.log(FiberMap.hasUnsafe(map, "task2")) // false
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var hasUnsafe = /*#__PURE__*/ dual(2, (self, key) => self.state._tag === "Closed" ? false : has$12(self.state.backing, key));
/**
* Check if a key exists in the FiberMap.
* This is the Effect-wrapped version of `hasUnsafe`.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add a fiber to the map
*   yield* FiberMap.run(map, "task1", Effect.succeed("Hello"))
*
*   // Check if keys exist using Effect
*   const exists1 = yield* FiberMap.has(map, "task1")
*   const exists2 = yield* FiberMap.has(map, "task2")
*
*   console.log(exists1) // true
*   console.log(exists2) // false
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var has$7 = /*#__PURE__*/ dual(2, (self, key) => sync$1(() => hasUnsafe(self, key)));
/**
* Remove a fiber from the FiberMap, interrupting it if it exists.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add some fibers to the map
*   yield* FiberMap.run(map, "task1", Effect.never)
*   yield* FiberMap.run(map, "task2", Effect.never)
*
*   console.log(yield* FiberMap.size(map)) // 2
*
*   // Remove a specific fiber (this will interrupt it)
*   yield* FiberMap.remove(map, "task1")
*
*   console.log(yield* FiberMap.size(map)) // 1
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var remove$6 = /*#__PURE__*/ dual(2, (self, key) => suspend(() => {
	if (self.state._tag === "Closed") return void_$1;
	const fiber = get$18(self.state.backing, key);
	if (fiber._tag === "None") return void_$1;
	return interruptAs(fiber.value, internalFiberId);
}));
/**
* Remove all fibers from the FiberMap, interrupting them.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add some fibers to the map
*   yield* FiberMap.run(map, "task1", Effect.never)
*   yield* FiberMap.run(map, "task2", Effect.never)
*   yield* FiberMap.run(map, "task3", Effect.never)
*
*   console.log(yield* FiberMap.size(map)) // 3
*
*   // Clear all fibers (this will interrupt all of them)
*   yield* FiberMap.clear(map)
*
*   console.log(yield* FiberMap.size(map)) // 0
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var clear$4 = (self) => suspend(() => {
	if (self.state._tag === "Closed") return void_$1;
	return interruptAllAs(values$7(self.state.backing), internalFiberId);
});
var constInterruptedFiber = /*#__PURE__*/ function() {
	let fiber = void 0;
	return () => {
		if (fiber === void 0) fiber = runFork(interrupt$1);
		return fiber;
	};
}();
/**
* Run an Effect and add the forked fiber to the FiberMap.
* When the fiber completes, it will be removed from the FiberMap.
*
* @example
* ```ts
* import { Effect, Fiber, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Run effects and add the fibers to the map
*   const fiber1 = yield* FiberMap.run(map, "task1", Effect.succeed("Hello"))
*   const fiber2 = yield* FiberMap.run(map, "task2", Effect.succeed("World"))
*
*   // Wait for the results
*   const result1 = yield* Fiber.await(fiber1)
*   const result2 = yield* Fiber.await(fiber2)
*
*   console.log(result1, result2) // "Hello", "World"
*   console.log(yield* FiberMap.size(map)) // 0 (fibers are removed after completion)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var run = function() {
	const self = arguments[0];
	if (isEffect$1(arguments[2])) return runImpl(self, arguments[1], arguments[2], arguments[3]);
	const key = arguments[1];
	const options = arguments[2];
	return (effect) => runImpl(self, key, effect, options);
};
var runImpl = (self, key, effect, options) => withFiber$1((parent) => {
	if (self.state._tag === "Closed") return interrupt$1;
	else if (options?.onlyIfMissing === true && hasUnsafe(self, key)) return sync$1(constInterruptedFiber);
	const fiber = runForkWith(parent.services)(effect);
	setUnsafe(self, key, fiber, options);
	return succeed$4(fiber);
});
/**
* Capture a Runtime and use it to fork Effect's, adding the forked fibers to the FiberMap.
*
* @example
* ```ts
* import { Effect, FiberMap, ServiceMap } from "effect"
*
* interface Users {
*   readonly _: unique symbol
* }
* const Users = ServiceMap.Service<Users, {
*   getAll: Effect.Effect<Array<unknown>>
* }>("Users")
*
* Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*   const run = yield* FiberMap.runtime(map)<Users>()
*
*   // run some effects and add the fibers to the map
*   run("effect-a", Effect.andThen(Users.asEffect(), (_) => _.getAll))
*   run("effect-b", Effect.andThen(Users.asEffect(), (_) => _.getAll))
* }).pipe(
*   Effect.scoped // The fibers will be interrupted when the scope is closed
* )
* ```
*
* @since 2.0.0
* @category combinators
*/
var runtime = (self) => () => map$11(services(), (services) => {
	const runFork = runForkWith(services);
	return (key, effect, options) => {
		if (self.state._tag === "Closed") return constInterruptedFiber();
		else if (options?.onlyIfMissing === true && hasUnsafe(self, key)) return constInterruptedFiber();
		const fiber = runFork(effect, options);
		setUnsafe(self, key, fiber, options);
		return fiber;
	};
});
/**
* Capture a Runtime and use it to fork Effect's, adding the forked fibers to the FiberMap.
* Returns a Promise instead of a Fiber for convenience.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*   const runPromise = yield* FiberMap.runtimePromise(map)<never>()
*
*   // Create promises that will be backed by fibers in the map
*   const promise1 = runPromise("task1", Effect.succeed("Hello"))
*   const promise2 = runPromise("task2", Effect.succeed("World"))
*
*   // Convert promises back to Effects and await
*   const result1 = yield* Effect.promise(() => promise1)
*   const result2 = yield* Effect.promise(() => promise2)
*
*   console.log(result1, result2) // "Hello", "World"
* })
* ```
*
* @since 3.13.0
* @category combinators
*/
var runtimePromise = (self) => () => map$11(runtime(self)(), (runFork) => (key, effect, options) => new Promise((resolve, reject) => runFork(key, effect, options).addObserver((exit) => {
	if (isSuccess$1(exit)) resolve(exit.value);
	else reject(squash(exit.cause));
})));
/**
* Get the number of fibers currently in the FiberMap.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   console.log(yield* FiberMap.size(map)) // 0
*
*   // Add some fibers
*   yield* FiberMap.run(map, "task1", Effect.never)
*   yield* FiberMap.run(map, "task2", Effect.never)
*
*   console.log(yield* FiberMap.size(map)) // 2
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var size$10 = (self) => sync$1(() => self.state._tag === "Closed" ? 0 : size$15(self.state.backing));
/**
* Join all fibers in the FiberMap. If any of the Fiber's in the map terminate with a failure,
* the returned Effect will terminate with the first failure that occurred.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* Effect.gen(function*() {
*   const map = yield* FiberMap.make()
*   yield* FiberMap.set(map, "a", Effect.runFork(Effect.fail("error")))
*
*   // parent fiber will fail with "error"
*   yield* FiberMap.join(map)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var join = (self) => _await(self.deferred);
/**
* Wait for the FiberMap to be empty.
* This will wait for all currently running fibers to complete.
*
* @example
* ```ts
* import { Effect, FiberMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const map = yield* FiberMap.make<string>()
*
*   // Add some fibers that will complete after a delay
*   yield* FiberMap.run(map, "task1", Effect.sleep(1000))
*   yield* FiberMap.run(map, "task2", Effect.sleep(2000))
*
*   console.log("Waiting for all fibers to complete...")
*
*   // Wait for the map to be empty
*   yield* FiberMap.awaitEmpty(map)
*
*   console.log("All fibers completed!")
*   console.log(yield* FiberMap.size(map)) // 0
* })
* ```
*
* @since 3.13.0
* @category combinators
*/
var awaitEmpty = (self) => whileLoop({
	while: () => self.state._tag === "Open" && size$15(self.state.backing) > 0,
	body: () => await_$1(headUnsafe(self)[1]),
	step: constVoid
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Graph.js
/**
* @since 4.0.0
*/
var Graph_exports = /* @__PURE__ */ __exportAll({
	Edge: () => Edge,
	GraphError: () => GraphError,
	Walker: () => Walker,
	addEdge: () => addEdge,
	addNode: () => addNode,
	astar: () => astar,
	beginMutation: () => beginMutation,
	bellmanFord: () => bellmanFord,
	bfs: () => bfs,
	connectedComponents: () => connectedComponents,
	dfs: () => dfs,
	dfsPostOrder: () => dfsPostOrder,
	dijkstra: () => dijkstra,
	directed: () => directed,
	edgeCount: () => edgeCount,
	edges: () => edges,
	endMutation: () => endMutation,
	entries: () => entries$4,
	externals: () => externals,
	filterEdges: () => filterEdges,
	filterMapEdges: () => filterMapEdges,
	filterMapNodes: () => filterMapNodes,
	filterNodes: () => filterNodes,
	findEdge: () => findEdge,
	findEdges: () => findEdges,
	findNode: () => findNode,
	findNodes: () => findNodes,
	floydWarshall: () => floydWarshall,
	getEdge: () => getEdge,
	getNode: () => getNode,
	hasEdge: () => hasEdge,
	hasNode: () => hasNode,
	indices: () => indices,
	isAcyclic: () => isAcyclic,
	isBipartite: () => isBipartite,
	isGraph: () => isGraph,
	mapEdges: () => mapEdges,
	mapNodes: () => mapNodes,
	mutate: () => mutate,
	neighbors: () => neighbors,
	neighborsDirected: () => neighborsDirected,
	nodeCount: () => nodeCount,
	nodes: () => nodes,
	removeEdge: () => removeEdge,
	removeNode: () => removeNode,
	reverse: () => reverse$1,
	stronglyConnectedComponents: () => stronglyConnectedComponents,
	toGraphViz: () => toGraphViz,
	toMermaid: () => toMermaid,
	topo: () => topo,
	undirected: () => undirected,
	updateEdge: () => updateEdge,
	updateNode: () => updateNode,
	values: () => values$4
});
var TypeId$24 = "~effect/collections/Graph";
/**
* Edge data containing source, target, and user data.
*
* @since 4.0.0
* @category models
*/
var Edge = class extends Class {};
/** @internal */
var ProtoGraph = {
	[TypeId$24]: TypeId$24,
	[Symbol.iterator]() {
		return this.nodes[Symbol.iterator]();
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	[symbol$1](that) {
		if (isGraph(that)) {
			if (this.nodes.size !== that.nodes.size || this.edges.size !== that.edges.size || this.type !== that.type) return false;
			for (const [nodeIndex, nodeData] of this.nodes) {
				if (!that.nodes.has(nodeIndex)) return false;
				if (!equals(nodeData, that.nodes.get(nodeIndex))) return false;
			}
			for (const [edgeIndex, edgeData] of this.edges) {
				if (!that.edges.has(edgeIndex)) return false;
				if (!equals(edgeData, that.edges.get(edgeIndex))) return false;
			}
			return true;
		}
		return false;
	},
	[symbol$2]() {
		let hash$2 = string$3("Graph");
		hash$2 = hash$2 ^ string$3(this.type);
		hash$2 = hash$2 ^ number$2(this.nodes.size);
		hash$2 = hash$2 ^ number$2(this.edges.size);
		for (const [nodeIndex, nodeData] of this.nodes) hash$2 = hash$2 ^ hash(nodeIndex) + hash(nodeData);
		for (const [edgeIndex, edgeData] of this.edges) hash$2 = hash$2 ^ hash(edgeIndex) + hash(edgeData);
		return hash$2;
	},
	toJSON() {
		return {
			_id: "Graph",
			nodeCount: this.nodes.size,
			edgeCount: this.edges.size,
			type: this.type
		};
	},
	toString() {
		return `Graph(${this.type}, ${this.nodes.size}, ${this.edges.size})`;
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* @since 4.0.0
* @category errors
*/
var GraphError = class extends TaggedError("GraphError") {};
/** @internal */
var missingNode = (node) => new GraphError({ message: `Node ${node} does not exist` });
/**
* @since 4.0.0
* @category Guards
*/
var isGraph = (u) => typeof u === "object" && u !== null && TypeId$24 in u;
/**
* Creates a directed graph, optionally with initial mutations.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* // Directed graph with initial nodes and edges
* const graph = Graph.directed<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, "A->B")
*   Graph.addEdge(mutable, b, c, "B->C")
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var directed = (mutate) => {
	const graph = Object.create(ProtoGraph);
	graph.type = "directed";
	graph.nodes = /* @__PURE__ */ new Map();
	graph.edges = /* @__PURE__ */ new Map();
	graph.adjacency = /* @__PURE__ */ new Map();
	graph.reverseAdjacency = /* @__PURE__ */ new Map();
	graph.nextNodeIndex = 0;
	graph.nextEdgeIndex = 0;
	graph.acyclic = true;
	graph.mutable = false;
	if (mutate) {
		const mutable = beginMutation(graph);
		mutate(mutable);
		return endMutation(mutable);
	}
	return graph;
};
/**
* Creates an undirected graph, optionally with initial mutations.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* // Undirected graph with initial nodes and edges
* const graph = Graph.undirected<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, "A-B")
*   Graph.addEdge(mutable, b, c, "B-C")
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var undirected = (mutate) => {
	const graph = Object.create(ProtoGraph);
	graph.type = "undirected";
	graph.nodes = /* @__PURE__ */ new Map();
	graph.edges = /* @__PURE__ */ new Map();
	graph.adjacency = /* @__PURE__ */ new Map();
	graph.reverseAdjacency = /* @__PURE__ */ new Map();
	graph.nextNodeIndex = 0;
	graph.nextEdgeIndex = 0;
	graph.acyclic = true;
	graph.mutable = false;
	if (mutate) {
		const mutable = beginMutation(graph);
		mutate(mutable);
		return endMutation(mutable);
	}
	return graph;
};
/**
* Creates a mutable scope for safe graph mutations by copying the data structure.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>()
* const mutable = Graph.beginMutation(graph)
* // Now mutable can be safely modified without affecting original graph
* ```
*
* @since 4.0.0
* @category mutations
*/
var beginMutation = (graph) => {
	const adjacency = /* @__PURE__ */ new Map();
	const reverseAdjacency = /* @__PURE__ */ new Map();
	for (const [nodeIndex, edges] of graph.adjacency) adjacency.set(nodeIndex, [...edges]);
	for (const [nodeIndex, edges] of graph.reverseAdjacency) reverseAdjacency.set(nodeIndex, [...edges]);
	const mutable = Object.create(ProtoGraph);
	mutable.type = graph.type;
	mutable.nodes = new Map(graph.nodes);
	mutable.edges = new Map(graph.edges);
	mutable.adjacency = adjacency;
	mutable.reverseAdjacency = reverseAdjacency;
	mutable.nextNodeIndex = graph.nextNodeIndex;
	mutable.nextEdgeIndex = graph.nextEdgeIndex;
	mutable.acyclic = graph.acyclic;
	mutable.mutable = true;
	return mutable;
};
/**
* Converts a mutable graph back to an immutable graph, ending the mutation scope.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>()
* const mutable = Graph.beginMutation(graph)
* // ... perform mutations on mutable ...
* const newGraph = Graph.endMutation(mutable)
* ```
*
* @since 4.0.0
* @category mutations
*/
var endMutation = (mutable) => {
	const graph = Object.create(ProtoGraph);
	graph.type = mutable.type;
	graph.nodes = new Map(mutable.nodes);
	graph.edges = new Map(mutable.edges);
	graph.adjacency = mutable.adjacency;
	graph.reverseAdjacency = mutable.reverseAdjacency;
	graph.nextNodeIndex = mutable.nextNodeIndex;
	graph.nextEdgeIndex = mutable.nextEdgeIndex;
	graph.acyclic = mutable.acyclic;
	graph.mutable = false;
	return graph;
};
/**
* Performs scoped mutations on a graph, automatically managing the mutation lifecycle.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>()
* const newGraph = Graph.mutate(graph, (mutable) => {
*   // Safe mutations go here
*   // mutable gets automatically converted back to immutable
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var mutate = /*#__PURE__*/ dual(2, (graph, f) => {
	const mutable = beginMutation(graph);
	f(mutable);
	return endMutation(mutable);
});
/**
* Adds a new node to a mutable graph and returns its index.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const result = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   console.log(nodeA) // NodeIndex with value 0
*   console.log(nodeB) // NodeIndex with value 1
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var addNode = (mutable, data) => {
	const nodeIndex = mutable.nextNodeIndex;
	mutable.nodes.set(nodeIndex, data);
	mutable.adjacency.set(nodeIndex, []);
	mutable.reverseAdjacency.set(nodeIndex, []);
	mutable.nextNodeIndex = mutable.nextNodeIndex + 1;
	return nodeIndex;
};
/**
* Gets the data associated with a node index, if it exists.
*
* @example
* ```ts
* import { Graph } from "effect"
* import * as Option from "effect/Option"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   Graph.addNode(mutable, "Node A")
* })
*
* const nodeIndex = 0
* const nodeData = Graph.getNode(graph, nodeIndex)
*
* if (Option.isSome(nodeData)) {
*   console.log(nodeData.value) // "Node A"
* }
* ```
*
* @since 4.0.0
* @category getters
*/
var getNode = /*#__PURE__*/ dual(2, (graph, nodeIndex) => graph.nodes.has(nodeIndex) ? some$2(graph.nodes.get(nodeIndex)) : none());
/**
* Checks if a node with the given index exists in the graph.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   Graph.addNode(mutable, "Node A")
* })
*
* const nodeIndex = 0
* const exists = Graph.hasNode(graph, nodeIndex)
* console.log(exists) // true
*
* const nonExistentIndex = 999
* const notExists = Graph.hasNode(graph, nonExistentIndex)
* console.log(notExists) // false
* ```
*
* @since 4.0.0
* @category getters
*/
var hasNode = /*#__PURE__*/ dual(2, (graph, nodeIndex) => graph.nodes.has(nodeIndex));
/**
* Returns the number of nodes in the graph.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const emptyGraph = Graph.directed<string, number>()
* console.log(Graph.nodeCount(emptyGraph)) // 0
*
* const graphWithNodes = Graph.mutate(emptyGraph, (mutable) => {
*   Graph.addNode(mutable, "Node A")
*   Graph.addNode(mutable, "Node B")
*   Graph.addNode(mutable, "Node C")
* })
*
* console.log(Graph.nodeCount(graphWithNodes)) // 3
* ```
*
* @since 4.0.0
* @category getters
*/
var nodeCount = (graph) => graph.nodes.size;
/**
* Finds the first node that matches the given predicate.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   Graph.addNode(mutable, "Node A")
*   Graph.addNode(mutable, "Node B")
*   Graph.addNode(mutable, "Node C")
* })
*
* const result = Graph.findNode(graph, (data) => data.startsWith("Node B"))
* console.log(result) // 1
*
* const notFound = Graph.findNode(graph, (data) => data === "Node D")
* console.log(notFound) // undefined
* ```
*
* @since 4.0.0
* @category getters
*/
var findNode = /*#__PURE__*/ dual(2, (graph, predicate) => {
	for (const [index, data] of graph.nodes) if (predicate(data)) return index;
});
/**
* Finds all nodes that match the given predicate.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   Graph.addNode(mutable, "Start A")
*   Graph.addNode(mutable, "Node B")
*   Graph.addNode(mutable, "Start C")
* })
*
* const result = Graph.findNodes(graph, (data) => data.startsWith("Start"))
* console.log(result) // [0, 2]
*
* const empty = Graph.findNodes(graph, (data) => data === "Not Found")
* console.log(empty) // []
* ```
*
* @since 4.0.0
* @category getters
*/
var findNodes = /*#__PURE__*/ dual(2, (graph, predicate) => {
	const results = [];
	for (const [index, data] of graph.nodes) if (predicate(data)) results.push(index);
	return results;
});
/**
* Finds the first edge that matches the given predicate.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const nodeC = Graph.addNode(mutable, "Node C")
*   Graph.addEdge(mutable, nodeA, nodeB, 10)
*   Graph.addEdge(mutable, nodeB, nodeC, 20)
* })
*
* const result = Graph.findEdge(graph, (data) => data > 15)
* console.log(result) // 1
*
* const notFound = Graph.findEdge(graph, (data) => data > 100)
* console.log(notFound) // undefined
* ```
*
* @since 4.0.0
* @category getters
*/
var findEdge = /*#__PURE__*/ dual(2, (graph, predicate) => {
	for (const [edgeIndex, edgeData] of graph.edges) if (predicate(edgeData.data, edgeData.source, edgeData.target)) return edgeIndex;
});
/**
* Finds all edges that match the given predicate.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const nodeC = Graph.addNode(mutable, "Node C")
*   Graph.addEdge(mutable, nodeA, nodeB, 10)
*   Graph.addEdge(mutable, nodeB, nodeC, 20)
*   Graph.addEdge(mutable, nodeC, nodeA, 30)
* })
*
* const result = Graph.findEdges(graph, (data) => data >= 20)
* console.log(result) // [1, 2]
*
* const empty = Graph.findEdges(graph, (data) => data > 100)
* console.log(empty) // []
* ```
*
* @since 4.0.0
* @category getters
*/
var findEdges = /*#__PURE__*/ dual(2, (graph, predicate) => {
	const results = [];
	for (const [edgeIndex, edgeData] of graph.edges) if (predicate(edgeData.data, edgeData.source, edgeData.target)) results.push(edgeIndex);
	return results;
});
/**
* Updates a single node's data by applying a transformation function.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   Graph.addNode(mutable, "Node A")
*   Graph.addNode(mutable, "Node B")
*   Graph.updateNode(mutable, 0, (data) => data.toUpperCase())
* })
*
* const nodeData = Graph.getNode(graph, 0)
* console.log(nodeData) // Option.some("NODE A")
* ```
*
* @since 4.0.0
* @category transformations
*/
var updateNode = (mutable, index, f) => {
	if (!mutable.nodes.has(index)) return;
	const newData = f(mutable.nodes.get(index));
	mutable.nodes.set(index, newData);
};
/**
* Updates a single edge's data by applying a transformation function.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const result = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const edgeIndex = Graph.addEdge(mutable, nodeA, nodeB, 10)
*   Graph.updateEdge(mutable, edgeIndex, (data) => data * 2)
* })
*
* const edgeData = Graph.getEdge(result, 0)
* console.log(edgeData) // new Graph.Edge({ source: 0, target: 1, data: 20 })
* ```
*
* @since 4.0.0
* @category mutations
*/
var updateEdge = (mutable, edgeIndex, f) => {
	if (!mutable.edges.has(edgeIndex)) return;
	const currentEdge = mutable.edges.get(edgeIndex);
	const newData = f(currentEdge.data);
	mutable.edges.set(edgeIndex, new Edge({
		...currentEdge,
		data: newData
	}));
};
/**
* Creates a new graph with transformed node data using the provided mapping function.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   Graph.addNode(mutable, "node a")
*   Graph.addNode(mutable, "node b")
*   Graph.addNode(mutable, "node c")
*   Graph.mapNodes(mutable, (data) => data.toUpperCase())
* })
*
* const nodeData = Graph.getNode(graph, 0)
* console.log(nodeData) // new Graph.Node("NODE A")
* ```
*
* @since 4.0.0
* @category transformations
*/
var mapNodes = (mutable, f) => {
	for (const [index, data] of mutable.nodes) {
		const newData = f(data);
		mutable.nodes.set(index, newData);
	}
};
/**
* Transforms all edge data in a mutable graph using the provided mapping function.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 10)
*   Graph.addEdge(mutable, b, c, 20)
*   Graph.mapEdges(mutable, (data) => data * 2)
* })
*
* const edgeData = Graph.getEdge(graph, 0)
* console.log(edgeData) // new Graph.Edge({ source: 0, target: 1, data: 20 })
* ```
*
* @since 4.0.0
* @category transformations
*/
var mapEdges = (mutable, f) => {
	for (const [index, edgeData] of mutable.edges) {
		const newData = f(edgeData.data);
		mutable.edges.set(index, {
			...edgeData,
			data: newData
		});
	}
};
/**
* Reverses all edge directions in a mutable graph by swapping source and target nodes.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 1) // A -> B
*   Graph.addEdge(mutable, b, c, 2) // B -> C
*   Graph.reverse(mutable) // Now B -> A, C -> B
* })
*
* const edge0 = Graph.getEdge(graph, 0)
* console.log(edge0) // new Graph.Edge({ source: 1, target: 0, data: 1 }) - B -> A
* ```
*
* @since 4.0.0
* @category transformations
*/
var reverse$1 = (mutable) => {
	for (const [index, edgeData] of mutable.edges) mutable.edges.set(index, new Edge({
		source: edgeData.target,
		target: edgeData.source,
		data: edgeData.data
	}));
	mutable.adjacency.clear();
	mutable.reverseAdjacency.clear();
	for (const [edgeIndex, edgeData] of mutable.edges) {
		const sourceEdges = mutable.adjacency.get(edgeData.source) || [];
		sourceEdges.push(edgeIndex);
		mutable.adjacency.set(edgeData.source, sourceEdges);
		const targetEdges = mutable.reverseAdjacency.get(edgeData.target) || [];
		targetEdges.push(edgeIndex);
		mutable.reverseAdjacency.set(edgeData.target, targetEdges);
	}
	mutable.acyclic = void 0;
};
/**
* Filters and optionally transforms nodes in a mutable graph using a predicate function.
* Nodes that return Option.none are removed along with all their connected edges.
*
* @example
* ```ts
* import { Graph } from "effect"
* import * as Option from "effect/Option"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "active")
*   const b = Graph.addNode(mutable, "inactive")
*   const c = Graph.addNode(mutable, "active")
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, c, 2)
*
*   // Keep only "active" nodes and transform to uppercase
*   Graph.filterMapNodes(
*     mutable,
*     (data) =>
*       data === "active" ? Option.some(data.toUpperCase()) : Option.none()
*   )
* })
*
* console.log(Graph.nodeCount(graph)) // 2 (only "active" nodes remain)
* ```
*
* @since 4.0.0
* @category transformations
*/
var filterMapNodes = (mutable, f) => {
	const nodesToRemove = [];
	for (const [index, data] of mutable.nodes) {
		const result = f(data);
		if (isSome(result)) mutable.nodes.set(index, result.value);
		else nodesToRemove.push(index);
	}
	for (const nodeIndex of nodesToRemove) removeNode(mutable, nodeIndex);
};
/**
* Filters and optionally transforms edges in a mutable graph using a predicate function.
* Edges that return Option.none are removed from the graph.
*
* @example
* ```ts
* import { Graph } from "effect"
* import * as Option from "effect/Option"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 5)
*   Graph.addEdge(mutable, b, c, 15)
*   Graph.addEdge(mutable, c, a, 25)
*
*   // Keep only edges with weight >= 10 and double their weight
*   Graph.filterMapEdges(
*     mutable,
*     (data) => data >= 10 ? Option.some(data * 2) : Option.none()
*   )
* })
*
* console.log(Graph.edgeCount(graph)) // 2 (edges with weight 5 removed)
* ```
*
* @since 4.0.0
* @category transformations
*/
var filterMapEdges = (mutable, f) => {
	const edgesToRemove = [];
	for (const [index, edgeData] of mutable.edges) {
		const result = f(edgeData.data);
		if (isSome(result)) mutable.edges.set(index, {
			...edgeData,
			data: result.value
		});
		else edgesToRemove.push(index);
	}
	for (const edgeIndex of edgesToRemove) removeEdge(mutable, edgeIndex);
};
/**
* Filters nodes by removing those that don't match the predicate.
* This function modifies the mutable graph in place.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   Graph.addNode(mutable, "active")
*   Graph.addNode(mutable, "inactive")
*   Graph.addNode(mutable, "pending")
*   Graph.addNode(mutable, "active")
*
*   // Keep only "active" nodes
*   Graph.filterNodes(mutable, (data) => data === "active")
* })
*
* console.log(Graph.nodeCount(graph)) // 2 (only "active" nodes remain)
* ```
*
* @since 4.0.0
* @category transformations
*/
var filterNodes = (mutable, predicate) => {
	const nodesToRemove = [];
	for (const [index, data] of mutable.nodes) if (!predicate(data)) nodesToRemove.push(index);
	for (const nodeIndex of nodesToRemove) removeNode(mutable, nodeIndex);
};
/**
* Filters edges by removing those that don't match the predicate.
* This function modifies the mutable graph in place.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*
*   Graph.addEdge(mutable, a, b, 5)
*   Graph.addEdge(mutable, b, c, 15)
*   Graph.addEdge(mutable, c, a, 25)
*
*   // Keep only edges with weight >= 10
*   Graph.filterEdges(mutable, (data) => data >= 10)
* })
*
* console.log(Graph.edgeCount(graph)) // 2 (edge with weight 5 removed)
* ```
*
* @since 4.0.0
* @category transformations
*/
var filterEdges = (mutable, predicate) => {
	const edgesToRemove = [];
	for (const [index, edgeData] of mutable.edges) if (!predicate(edgeData.data)) edgesToRemove.push(index);
	for (const edgeIndex of edgesToRemove) removeEdge(mutable, edgeIndex);
};
/** @internal */
var invalidateCycleFlagOnRemoval = (mutable) => {
	if (mutable.acyclic === false) mutable.acyclic = void 0;
};
/** @internal */
var invalidateCycleFlagOnAddition = (mutable) => {
	if (mutable.acyclic === true) mutable.acyclic = void 0;
};
/**
* Adds a new edge to a mutable graph and returns its index.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const result = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const edge = Graph.addEdge(mutable, nodeA, nodeB, 42)
*   console.log(edge) // EdgeIndex with value 0
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var addEdge = (mutable, source, target, data) => {
	if (!mutable.nodes.has(source)) throw missingNode(source);
	if (!mutable.nodes.has(target)) throw missingNode(target);
	const edgeIndex = mutable.nextEdgeIndex;
	const edgeData = new Edge({
		source,
		target,
		data
	});
	mutable.edges.set(edgeIndex, edgeData);
	const sourceAdjacency = mutable.adjacency.get(source);
	if (sourceAdjacency !== void 0) sourceAdjacency.push(edgeIndex);
	const targetReverseAdjacency = mutable.reverseAdjacency.get(target);
	if (targetReverseAdjacency !== void 0) targetReverseAdjacency.push(edgeIndex);
	if (mutable.type === "undirected") {
		const targetAdjacency = mutable.adjacency.get(target);
		if (targetAdjacency !== void 0) targetAdjacency.push(edgeIndex);
		const sourceReverseAdjacency = mutable.reverseAdjacency.get(source);
		if (sourceReverseAdjacency !== void 0) sourceReverseAdjacency.push(edgeIndex);
	}
	mutable.nextEdgeIndex = mutable.nextEdgeIndex + 1;
	invalidateCycleFlagOnAddition(mutable);
	return edgeIndex;
};
/**
* Removes a node and all its incident edges from a mutable graph.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const result = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   Graph.addEdge(mutable, nodeA, nodeB, 42)
*
*   // Remove nodeA and all edges connected to it
*   Graph.removeNode(mutable, nodeA)
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var removeNode = (mutable, nodeIndex) => {
	if (!mutable.nodes.has(nodeIndex)) return;
	const edgesToRemove = [];
	const outgoingEdges = mutable.adjacency.get(nodeIndex);
	if (outgoingEdges !== void 0) for (const edge of outgoingEdges) edgesToRemove.push(edge);
	const incomingEdges = mutable.reverseAdjacency.get(nodeIndex);
	if (incomingEdges !== void 0) for (const edge of incomingEdges) edgesToRemove.push(edge);
	for (const edgeIndex of edgesToRemove) removeEdgeInternal(mutable, edgeIndex);
	mutable.nodes.delete(nodeIndex);
	mutable.adjacency.delete(nodeIndex);
	mutable.reverseAdjacency.delete(nodeIndex);
	invalidateCycleFlagOnRemoval(mutable);
};
/**
* Removes an edge from a mutable graph.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const result = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const edge = Graph.addEdge(mutable, nodeA, nodeB, 42)
*
*   // Remove the edge
*   Graph.removeEdge(mutable, edge)
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var removeEdge = (mutable, edgeIndex) => {
	if (removeEdgeInternal(mutable, edgeIndex)) invalidateCycleFlagOnRemoval(mutable);
};
/** @internal */
var removeEdgeInternal = (mutable, edgeIndex) => {
	const edge = mutable.edges.get(edgeIndex);
	if (edge === void 0) return false;
	const { source, target } = edge;
	const sourceAdjacency = mutable.adjacency.get(source);
	if (sourceAdjacency !== void 0) {
		const index = sourceAdjacency.indexOf(edgeIndex);
		if (index !== -1) sourceAdjacency.splice(index, 1);
	}
	const targetReverseAdjacency = mutable.reverseAdjacency.get(target);
	if (targetReverseAdjacency !== void 0) {
		const index = targetReverseAdjacency.indexOf(edgeIndex);
		if (index !== -1) targetReverseAdjacency.splice(index, 1);
	}
	if (mutable.type === "undirected") {
		const targetAdjacency = mutable.adjacency.get(target);
		if (targetAdjacency !== void 0) {
			const index = targetAdjacency.indexOf(edgeIndex);
			if (index !== -1) targetAdjacency.splice(index, 1);
		}
		const sourceReverseAdjacency = mutable.reverseAdjacency.get(source);
		if (sourceReverseAdjacency !== void 0) {
			const index = sourceReverseAdjacency.indexOf(edgeIndex);
			if (index !== -1) sourceReverseAdjacency.splice(index, 1);
		}
	}
	mutable.edges.delete(edgeIndex);
	return true;
};
/**
* Gets the edge data associated with an edge index, if it exists.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   Graph.addEdge(mutable, nodeA, nodeB, 42)
* })
*
* const edgeIndex = 0
* const edgeData = Graph.getEdge(graph, edgeIndex)
*
* if (edgeData !== undefined) {
*   console.log(edgeData.data) // 42
*   console.log(edgeData.source) // NodeIndex(0)
*   console.log(edgeData.target) // NodeIndex(1)
* }
* ```
*
* @since 4.0.0
* @category getters
*/
var getEdge = /*#__PURE__*/ dual(2, (graph, edgeIndex) => graph.edges.get(edgeIndex));
/**
* Checks if an edge exists between two nodes in the graph.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const nodeC = Graph.addNode(mutable, "Node C")
*   Graph.addEdge(mutable, nodeA, nodeB, 42)
* })
*
* const nodeA = 0
* const nodeB = 1
* const nodeC = 2
*
* const hasAB = Graph.hasEdge(graph, nodeA, nodeB)
* console.log(hasAB) // true
*
* const hasAC = Graph.hasEdge(graph, nodeA, nodeC)
* console.log(hasAC) // false
* ```
*
* @since 4.0.0
* @category getters
*/
var hasEdge = /*#__PURE__*/ dual(3, (graph, source, target) => {
	const adjacencyList = graph.adjacency.get(source);
	if (adjacencyList === void 0) return false;
	for (const edgeIndex of adjacencyList) {
		const edge = graph.edges.get(edgeIndex);
		if (edge !== void 0 && edge.target === target) return true;
	}
	return false;
});
/**
* Returns the number of edges in the graph.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const emptyGraph = Graph.directed<string, number>()
* console.log(Graph.edgeCount(emptyGraph)) // 0
*
* const graphWithEdges = Graph.mutate(emptyGraph, (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const nodeC = Graph.addNode(mutable, "Node C")
*   Graph.addEdge(mutable, nodeA, nodeB, 1)
*   Graph.addEdge(mutable, nodeB, nodeC, 2)
*   Graph.addEdge(mutable, nodeC, nodeA, 3)
* })
*
* console.log(Graph.edgeCount(graphWithEdges)) // 3
* ```
*
* @since 4.0.0
* @category getters
*/
var edgeCount = (graph) => graph.edges.size;
/**
* Returns the neighboring nodes (targets of outgoing edges) for a given node.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const nodeC = Graph.addNode(mutable, "Node C")
*   Graph.addEdge(mutable, nodeA, nodeB, 1)
*   Graph.addEdge(mutable, nodeA, nodeC, 2)
* })
*
* const nodeA = 0
* const nodeB = 1
* const nodeC = 2
*
* const neighborsA = Graph.neighbors(graph, nodeA)
* console.log(neighborsA) // [NodeIndex(1), NodeIndex(2)]
*
* const neighborsB = Graph.neighbors(graph, nodeB)
* console.log(neighborsB) // []
* ```
*
* @since 4.0.0
* @category getters
*/
var neighbors = /*#__PURE__*/ dual(2, (graph, nodeIndex) => {
	if (graph.type === "undirected") return getUndirectedNeighbors(graph, nodeIndex);
	const adjacencyList = graph.adjacency.get(nodeIndex);
	if (adjacencyList === void 0) return [];
	const result = [];
	for (const edgeIndex of adjacencyList) {
		const edge = graph.edges.get(edgeIndex);
		if (edge !== void 0) result.push(edge.target);
	}
	return result;
});
/**
* Get neighbors of a node in a specific direction for bidirectional traversal.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, "A->B")
* })
*
* const nodeA = 0
* const nodeB = 1
*
* // Get outgoing neighbors (nodes that nodeA points to)
* const outgoing = Graph.neighborsDirected(graph, nodeA, "outgoing")
*
* // Get incoming neighbors (nodes that point to nodeB)
* const incoming = Graph.neighborsDirected(graph, nodeB, "incoming")
* ```
*
* @since 4.0.0
* @category queries
*/
var neighborsDirected = /*#__PURE__*/ dual(3, (graph, nodeIndex, direction) => {
	const adjacencyList = (direction === "incoming" ? graph.reverseAdjacency : graph.adjacency).get(nodeIndex);
	if (adjacencyList === void 0) return [];
	const result = [];
	for (const edgeIndex of adjacencyList) {
		const edge = graph.edges.get(edgeIndex);
		if (edge !== void 0) {
			const neighborNode = direction === "incoming" ? edge.source : edge.target;
			result.push(neighborNode);
		}
	}
	return result;
});
/**
* Exports a graph to GraphViz DOT format for visualization.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.mutate(Graph.directed<string, number>(), (mutable) => {
*   const nodeA = Graph.addNode(mutable, "Node A")
*   const nodeB = Graph.addNode(mutable, "Node B")
*   const nodeC = Graph.addNode(mutable, "Node C")
*   Graph.addEdge(mutable, nodeA, nodeB, 1)
*   Graph.addEdge(mutable, nodeB, nodeC, 2)
*   Graph.addEdge(mutable, nodeC, nodeA, 3)
* })
*
* const dot = Graph.toGraphViz(graph)
* console.log(dot)
* // digraph G {
* //   "0" [label="Node A"];
* //   "1" [label="Node B"];
* //   "2" [label="Node C"];
* //   "0" -> "1" [label="1"];
* //   "1" -> "2" [label="2"];
* //   "2" -> "0" [label="3"];
* // }
* ```
*
* @since 4.0.0
* @category utils
*/
var toGraphViz = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, options) => {
	const { edgeLabel = (data) => String(data), graphName = "G", nodeLabel = (data) => String(data) } = options ?? {};
	const isDirected = graph.type === "directed";
	const graphType = isDirected ? "digraph" : "graph";
	const edgeOperator = isDirected ? "->" : "--";
	const lines = [];
	lines.push(`${graphType} ${graphName} {`);
	for (const [nodeIndex, nodeData] of graph.nodes) {
		const label = nodeLabel(nodeData).replace(/"/g, "\\\"");
		lines.push(`  "${nodeIndex}" [label="${label}"];`);
	}
	for (const [, edgeData] of graph.edges) {
		const label = edgeLabel(edgeData.data).replace(/"/g, "\\\"");
		lines.push(`  "${edgeData.source}" ${edgeOperator} "${edgeData.target}" [label="${label}"];`);
	}
	lines.push("}");
	return lines.join("\n");
});
/**
* Escapes special characters in labels for Mermaid syntax compatibility.
*/
var escapeMermaidLabel = (label) => {
	return label.replace(/#/g, "#35;").replace(/"/g, "#quot;").replace(/</g, "#lt;").replace(/>/g, "#gt;").replace(/&/g, "#amp;").replace(/\[/g, "#91;").replace(/\]/g, "#93;").replace(/\{/g, "#123;").replace(/\}/g, "#125;").replace(/\(/g, "#40;").replace(/\)/g, "#41;").replace(/\|/g, "#124;").replace(/\\/g, "#92;").replace(/\n/g, "<br/>");
};
/**
* Formats a Mermaid node with the specified shape and label.
*/
var formatMermaidNode = (nodeId, label, shape) => {
	switch (shape) {
		case "rectangle": return `${nodeId}["${label}"]`;
		case "rounded": return `${nodeId}("${label}")`;
		case "circle": return `${nodeId}(("${label}"))`;
		case "diamond": return `${nodeId}{"${label}"}`;
		case "hexagon": return `${nodeId}{{"${label}"}}`;
		case "stadium": return `${nodeId}(["${label}"])`;
		case "subroutine": return `${nodeId}[["${label}"]]`;
		case "cylindrical": return `${nodeId}[("${label}")]`;
		default: return `${nodeId}["${label}"]`;
	}
};
/**
* Exports a graph to Mermaid diagram format for visualization.
*
* Mermaid is a popular diagram-as-code tool that generates flowcharts and other
* visualizations from text-based definitions. This function converts Effect Graph
* structures to valid Mermaid syntax for use in documentation, web applications,
* and visualization tools.
*
* @example
* ```ts
* import * as Graph from "effect/Graph"
*
* // Basic directed graph export
* const graph = Graph.directed<string, number>((mutable) => {
*   const app = Graph.addNode(mutable, "App")
*   const db = Graph.addNode(mutable, "Database")
*   const cache = Graph.addNode(mutable, "Cache")
*   Graph.addEdge(mutable, app, db, 1)
*   Graph.addEdge(mutable, app, cache, 2)
* })
*
* const mermaid = Graph.toMermaid(graph)
* console.log(mermaid)
* // flowchart TD
* //   0["App"]
* //   1["Database"]
* //   2["Cache"]
* //   0 -->|"1"| 1
* //   0 -->|"2"| 2
* ```
*
* @example
* ```ts
* import * as Graph from "effect/Graph"
*
* // Undirected graph with custom labels and direction
* const socialGraph = Graph.undirected<{ name: string }, string>((mutable) => {
*   const alice = Graph.addNode(mutable, { name: "Alice" })
*   const bob = Graph.addNode(mutable, { name: "Bob" })
*   const charlie = Graph.addNode(mutable, { name: "Charlie" })
*   Graph.addEdge(mutable, alice, bob, "friends")
*   Graph.addEdge(mutable, bob, charlie, "colleagues")
* })
*
* const mermaid = Graph.toMermaid(socialGraph, {
*   nodeLabel: (person) => person.name,
*   edgeLabel: (relationship) => relationship,
*   direction: "LR"
* })
* console.log(mermaid)
* // graph LR
* //   0["Alice"]
* //   1["Bob"]
* //   2["Charlie"]
* //   0 ---|"friends"| 1
* //   1 ---|"colleagues"| 2
* ```
*
* @example
* ```ts
* import * as Graph from "effect/Graph"
*
* // Advanced styling with node shapes for flowchart
* const workflow = Graph.directed<{ type: string; name: string }, string>(
*   (mutable) => {
*     const start = Graph.addNode(mutable, { type: "start", name: "Begin" })
*     const process = Graph.addNode(mutable, {
*       type: "process",
*       name: "Process Data"
*     })
*     const decision = Graph.addNode(mutable, {
*       type: "decision",
*       name: "Valid?"
*     })
*     const end = Graph.addNode(mutable, { type: "end", name: "Complete" })
*     Graph.addEdge(mutable, start, process, "")
*     Graph.addEdge(mutable, process, decision, "")
*     Graph.addEdge(mutable, decision, end, "yes")
*   }
* )
*
* const mermaid = Graph.toMermaid(workflow, {
*   nodeLabel: (node) => node.name,
*   nodeShape: (node) => {
*     switch (node.type) {
*       case "start":
*         return "stadium"
*       case "process":
*         return "rectangle"
*       case "decision":
*         return "diamond"
*       case "end":
*         return "stadium"
*       default:
*         return "rectangle"
*     }
*   }
* })
* console.log(mermaid)
* // flowchart TD
* //   0(["Begin"])
* //   1["Process Data"]
* //   2{"Valid?"}
* //   3(["Complete"])
* //   0 --> 1
* //   1 --> 2
* //   2 --> 3
* ```
*
* @example
* ```ts
* import * as Graph from "effect/Graph"
*
* // Real-world example: Software dependency graph
* interface Dependency {
*   name: string
*   version: string
*   type: "library" | "framework" | "tool"
* }
*
* const dependencyGraph = Graph.directed<Dependency, string>((mutable) => {
*   const app = Graph.addNode(mutable, {
*     name: "MyApp",
*     version: "1.0.0",
*     type: "library"
*   })
*   const react = Graph.addNode(mutable, {
*     name: "React",
*     version: "18.0.0",
*     type: "framework"
*   })
*   const lodash = Graph.addNode(mutable, {
*     name: "Lodash",
*     version: "4.17.0",
*     type: "library"
*   })
*   const webpack = Graph.addNode(mutable, {
*     name: "Webpack",
*     version: "5.0.0",
*     type: "tool"
*   })
*
*   Graph.addEdge(mutable, app, react, "depends on")
*   Graph.addEdge(mutable, app, lodash, "depends on")
*   Graph.addEdge(mutable, app, webpack, "builds with")
* })
*
* const dependencyDiagram = Graph.toMermaid(dependencyGraph, {
*   nodeLabel: (dep) => `${dep.name}\\nv${dep.version}`,
*   edgeLabel: (edge) => edge,
*   nodeShape: (dep) =>
*     dep.type === "framework" ?
*       "hexagon" :
*       dep.type === "tool"
*       ? "diamond"
*       : "rectangle",
*   direction: "TB"
* })
*
* console.log(dependencyDiagram)
* // flowchart TB
* //   0["MyApp\nv1.0.0"]
* //   1{{"React\nv18.0.0"}}
* //   2["Lodash\nv4.17.0"]
* //   3{"Webpack\nv5.0.0"}
* //   0 -->|"depends on"| 1
* //   0 -->|"depends on"| 2
* //   0 -->|"builds with"| 3
* ```
*
* @param graph - The graph to export (directed or undirected)
* @param options - Optional configuration for the Mermaid output
* @returns Mermaid diagram syntax as a string
*
* @since 4.0.0
* @category utils
*/
var toMermaid = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, options) => {
	const { diagramType, direction = "TD", edgeLabel = (data) => String(data), nodeLabel = (data) => String(data), nodeShape = () => "rectangle" } = options ?? {};
	const finalDiagramType = diagramType ?? (graph.type === "directed" ? "flowchart" : "graph");
	const lines = [];
	lines.push(`${finalDiagramType} ${direction}`);
	for (const [nodeIndex, nodeData] of graph.nodes) {
		const formattedNode = formatMermaidNode(String(nodeIndex), escapeMermaidLabel(nodeLabel(nodeData)), nodeShape(nodeData));
		lines.push(`  ${formattedNode}`);
	}
	const edgeOperator = finalDiagramType === "flowchart" ? "-->" : "---";
	for (const [, edgeData] of graph.edges) {
		const sourceId = String(edgeData.source);
		const targetId = String(edgeData.target);
		const label = escapeMermaidLabel(edgeLabel(edgeData.data));
		if (label) lines.push(`  ${sourceId} ${edgeOperator}|"${label}"| ${targetId}`);
		else lines.push(`  ${sourceId} ${edgeOperator} ${targetId}`);
	}
	return lines.join("\n");
});
/**
* Checks if the graph is acyclic (contains no cycles).
*
* Uses depth-first search to detect back edges, which indicate cycles.
* For directed graphs, any back edge creates a cycle. For undirected graphs,
* a back edge that doesn't go to the immediate parent creates a cycle.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* // Acyclic directed graph (DAG)
* const dag = Graph.directed<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, "A->B")
*   Graph.addEdge(mutable, b, c, "B->C")
* })
* console.log(Graph.isAcyclic(dag)) // true
*
* // Cyclic directed graph
* const cyclic = Graph.directed<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, "A->B")
*   Graph.addEdge(mutable, b, a, "B->A") // Creates cycle
* })
* console.log(Graph.isAcyclic(cyclic)) // false
* ```
*
* @since 4.0.0
* @category algorithms
*/
var isAcyclic = (graph) => {
	if (graph.acyclic !== void 0) return graph.acyclic;
	const visited = /* @__PURE__ */ new Set();
	const recursionStack = /* @__PURE__ */ new Set();
	for (const startNode of graph.nodes.keys()) {
		if (visited.has(startNode)) continue;
		const stack = [[
			startNode,
			[],
			0,
			true
		]];
		while (stack.length > 0) {
			const [node, neighbors, neighborIndex, isFirstVisit] = stack[stack.length - 1];
			if (isFirstVisit) {
				if (recursionStack.has(node)) {
					graph.acyclic = false;
					return false;
				}
				if (visited.has(node)) {
					stack.pop();
					continue;
				}
				visited.add(node);
				recursionStack.add(node);
				const nodeNeighbors = Array.from(neighborsDirected(graph, node, "outgoing"));
				stack[stack.length - 1] = [
					node,
					nodeNeighbors,
					0,
					false
				];
				continue;
			}
			if (neighborIndex < neighbors.length) {
				const neighbor = neighbors[neighborIndex];
				stack[stack.length - 1] = [
					node,
					neighbors,
					neighborIndex + 1,
					false
				];
				if (recursionStack.has(neighbor)) {
					graph.acyclic = false;
					return false;
				}
				if (!visited.has(neighbor)) stack.push([
					neighbor,
					[],
					0,
					true
				]);
			} else {
				recursionStack.delete(node);
				stack.pop();
			}
		}
	}
	graph.acyclic = true;
	return true;
};
/**
* Checks if an undirected graph is bipartite.
*
* A bipartite graph is one whose vertices can be divided into two disjoint sets
* such that no two vertices within the same set are adjacent. Uses BFS coloring
* to determine bipartiteness.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* // Bipartite graph (alternating coloring possible)
* const bipartite = Graph.undirected<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   const d = Graph.addNode(mutable, "D")
*   Graph.addEdge(mutable, a, b, "edge") // Set 1: {A, C}, Set 2: {B, D}
*   Graph.addEdge(mutable, b, c, "edge")
*   Graph.addEdge(mutable, c, d, "edge")
* })
* console.log(Graph.isBipartite(bipartite)) // true
*
* // Non-bipartite graph (odd cycle)
* const triangle = Graph.undirected<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, "edge")
*   Graph.addEdge(mutable, b, c, "edge")
*   Graph.addEdge(mutable, c, a, "edge") // Triangle (3-cycle)
* })
* console.log(Graph.isBipartite(triangle)) // false
* ```
*
* @since 4.0.0
* @category algorithms
*/
var isBipartite = (graph) => {
	const coloring = /* @__PURE__ */ new Map();
	const discovered = /* @__PURE__ */ new Set();
	let isBipartiteGraph = true;
	for (const startNode of graph.nodes.keys()) if (!discovered.has(startNode)) {
		const queue = [startNode];
		coloring.set(startNode, 0);
		discovered.add(startNode);
		while (queue.length > 0 && isBipartiteGraph) {
			const current = queue.shift();
			const currentColor = coloring.get(current);
			const neighborColor = currentColor === 0 ? 1 : 0;
			const nodeNeighbors = getUndirectedNeighbors(graph, current);
			for (const neighbor of nodeNeighbors) if (!discovered.has(neighbor)) {
				coloring.set(neighbor, neighborColor);
				discovered.add(neighbor);
				queue.push(neighbor);
			} else if (coloring.get(neighbor) === currentColor) {
				isBipartiteGraph = false;
				break;
			}
		}
		if (!isBipartiteGraph) break;
	}
	return isBipartiteGraph;
};
/**
* Get neighbors for undirected graphs by checking both adjacency and reverse adjacency.
* For undirected graphs, we need to find the other endpoint of each edge incident to the node.
*/
var getUndirectedNeighbors = (graph, nodeIndex) => {
	const neighbors = /* @__PURE__ */ new Set();
	const adjacencyList = graph.adjacency.get(nodeIndex);
	if (adjacencyList !== void 0) for (const edgeIndex of adjacencyList) {
		const edge = graph.edges.get(edgeIndex);
		if (edge !== void 0) {
			const otherNode = edge.source === nodeIndex ? edge.target : edge.source;
			neighbors.add(otherNode);
		}
	}
	return Array.from(neighbors);
};
/**
* Find connected components in an undirected graph.
* Each component is represented as an array of node indices.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.undirected<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   const d = Graph.addNode(mutable, "D")
*   Graph.addEdge(mutable, a, b, "edge") // Component 1: A-B
*   Graph.addEdge(mutable, c, d, "edge") // Component 2: C-D
* })
*
* const components = Graph.connectedComponents(graph)
* console.log(components) // [[0, 1], [2, 3]]
* ```
*
* @since 4.0.0
* @category algorithms
*/
var connectedComponents = (graph) => {
	const visited = /* @__PURE__ */ new Set();
	const components = [];
	for (const startNode of graph.nodes.keys()) if (!visited.has(startNode)) {
		const component = [];
		const stack = [startNode];
		while (stack.length > 0) {
			const current = stack.pop();
			if (!visited.has(current)) {
				visited.add(current);
				component.push(current);
				const nodeNeighbors = getUndirectedNeighbors(graph, current);
				for (const neighbor of nodeNeighbors) if (!visited.has(neighbor)) stack.push(neighbor);
			}
		}
		components.push(component);
	}
	return components;
};
/**
* Find strongly connected components in a directed graph using Kosaraju's algorithm.
* Each SCC is represented as an array of node indices.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, string>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, "A->B")
*   Graph.addEdge(mutable, b, c, "B->C")
*   Graph.addEdge(mutable, c, a, "C->A") // Creates SCC: A-B-C
* })
*
* const sccs = Graph.stronglyConnectedComponents(graph)
* console.log(sccs) // [[0, 1, 2]]
* ```
*
* @since 4.0.0
* @category algorithms
*/
var stronglyConnectedComponents = (graph) => {
	const visited = /* @__PURE__ */ new Set();
	const finishOrder = [];
	for (const startNode of graph.nodes.keys()) {
		if (visited.has(startNode)) continue;
		const stack = [[
			startNode,
			[],
			0,
			true
		]];
		while (stack.length > 0) {
			const [node, nodeNeighbors, neighborIndex, isFirstVisit] = stack[stack.length - 1];
			if (isFirstVisit) {
				if (visited.has(node)) {
					stack.pop();
					continue;
				}
				visited.add(node);
				const nodeNeighborsList = neighbors(graph, node);
				stack[stack.length - 1] = [
					node,
					nodeNeighborsList,
					0,
					false
				];
				continue;
			}
			if (neighborIndex < nodeNeighbors.length) {
				const neighbor = nodeNeighbors[neighborIndex];
				stack[stack.length - 1] = [
					node,
					nodeNeighbors,
					neighborIndex + 1,
					false
				];
				if (!visited.has(neighbor)) stack.push([
					neighbor,
					[],
					0,
					true
				]);
			} else {
				finishOrder.push(node);
				stack.pop();
			}
		}
	}
	visited.clear();
	const sccs = [];
	for (let i = finishOrder.length - 1; i >= 0; i--) {
		const startNode = finishOrder[i];
		if (visited.has(startNode)) continue;
		const scc = [];
		const stack = [startNode];
		while (stack.length > 0) {
			const node = stack.pop();
			if (visited.has(node)) continue;
			visited.add(node);
			scc.push(node);
			const reverseAdjacency = graph.reverseAdjacency.get(node);
			if (reverseAdjacency !== void 0) for (const edgeIndex of reverseAdjacency) {
				const edge = graph.edges.get(edgeIndex);
				if (edge !== void 0) {
					const predecessor = edge.source;
					if (!visited.has(predecessor)) stack.push(predecessor);
				}
			}
		}
		sccs.push(scc);
	}
	return sccs;
};
/**
* Find the shortest path between two nodes using Dijkstra's algorithm.
*
* Dijkstra's algorithm works with non-negative edge weights and finds the shortest
* path from a source node to a target node in O((V + E) log V) time complexity.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 5)
*   Graph.addEdge(mutable, a, c, 10)
*   Graph.addEdge(mutable, b, c, 2)
* })
*
* const result = Graph.dijkstra(graph, {
*   source: 0,
*   target: 2,
*   cost: (edgeData) => edgeData
* })
*
* if (result !== undefined) {
*   console.log(result.path) // [0, 1, 2] - shortest path A->B->C
*   console.log(result.distance) // 7 - total distance
* }
* ```
*
* @since 4.0.0
* @category algorithms
*/
var dijkstra = /*#__PURE__*/ dual(2, (graph, config) => {
	if (!graph.nodes.has(config.source)) throw missingNode(config.source);
	if (!graph.nodes.has(config.target)) throw missingNode(config.target);
	if (config.source === config.target) return {
		path: [config.source],
		distance: 0,
		costs: []
	};
	const distances = /* @__PURE__ */ new Map();
	const previous = /* @__PURE__ */ new Map();
	const visited = /* @__PURE__ */ new Set();
	for (const node of graph.nodes.keys()) {
		distances.set(node, node === config.source ? 0 : Infinity);
		previous.set(node, null);
	}
	const priorityQueue = [{
		node: config.source,
		distance: 0
	}];
	while (priorityQueue.length > 0) {
		let minIndex = 0;
		for (let i = 1; i < priorityQueue.length; i++) if (priorityQueue[i].distance < priorityQueue[minIndex].distance) minIndex = i;
		const currentNode = priorityQueue.splice(minIndex, 1)[0].node;
		if (visited.has(currentNode)) continue;
		visited.add(currentNode);
		if (currentNode === config.target) break;
		const currentDistance = distances.get(currentNode);
		const adjacencyList = graph.adjacency.get(currentNode);
		if (adjacencyList !== void 0) for (const edgeIndex of adjacencyList) {
			const edge = graph.edges.get(edgeIndex);
			if (edge !== void 0) {
				const neighbor = edge.target;
				const cost = config.cost(edge.data);
				if (cost < 0) throw new GraphError({ message: "Dijkstra's algorithm requires non-negative edge weights" });
				const newDistance = currentDistance + cost;
				if (newDistance < distances.get(neighbor)) {
					distances.set(neighbor, newDistance);
					previous.set(neighbor, {
						node: currentNode,
						edgeData: edge.data
					});
					if (!visited.has(neighbor)) priorityQueue.push({
						node: neighbor,
						distance: newDistance
					});
				}
			}
		}
	}
	const distance = distances.get(config.target);
	if (distance === Infinity) return;
	const path = [];
	const costs = [];
	let currentNode = config.target;
	while (currentNode !== null) {
		path.unshift(currentNode);
		const prev = previous.get(currentNode);
		if (prev !== null) {
			costs.unshift(prev.edgeData);
			currentNode = prev.node;
		} else currentNode = null;
	}
	return {
		path,
		distance,
		costs
	};
});
/**
* Find shortest paths between all pairs of nodes using Floyd-Warshall algorithm.
*
* Floyd-Warshall algorithm computes shortest paths between all pairs of nodes in O(V³) time.
* It can handle negative edge weights and detect negative cycles.
*
* Throws if a negative cycle is detected that affects the path to target.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 3)
*   Graph.addEdge(mutable, b, c, 2)
*   Graph.addEdge(mutable, a, c, 7)
* })
*
* const result = Graph.floydWarshall(graph, (edgeData) => edgeData)
* const distanceAToC = result.distances.get(0)?.get(2) // 5 (A->B->C)
* const pathAToC = result.paths.get(0)?.get(2) // [0, 1, 2]
* ```
*
* @since 4.0.0
* @category algorithms
*/
var floydWarshall = /*#__PURE__*/ dual(2, (graph, cost) => {
	const allNodes = Array.from(graph.nodes.keys());
	const distances = /* @__PURE__ */ new Map();
	const next = /* @__PURE__ */ new Map();
	const edgeMatrix = /* @__PURE__ */ new Map();
	for (const i of allNodes) {
		distances.set(i, /* @__PURE__ */ new Map());
		next.set(i, /* @__PURE__ */ new Map());
		edgeMatrix.set(i, /* @__PURE__ */ new Map());
		for (const j of allNodes) {
			distances.get(i).set(j, i === j ? 0 : Infinity);
			next.get(i).set(j, null);
			edgeMatrix.get(i).set(j, null);
		}
	}
	for (const [, edgeData] of graph.edges) {
		const weight = cost(edgeData.data);
		const i = edgeData.source;
		const j = edgeData.target;
		if (weight < distances.get(i).get(j)) {
			distances.get(i).set(j, weight);
			next.get(i).set(j, j);
			edgeMatrix.get(i).set(j, edgeData.data);
		}
	}
	for (const k of allNodes) for (const i of allNodes) for (const j of allNodes) {
		const distIK = distances.get(i).get(k);
		const distKJ = distances.get(k).get(j);
		const distIJ = distances.get(i).get(j);
		if (distIK !== Infinity && distKJ !== Infinity && distIK + distKJ < distIJ) {
			distances.get(i).set(j, distIK + distKJ);
			next.get(i).set(j, next.get(i).get(k));
		}
	}
	for (const i of allNodes) if (distances.get(i).get(i) < 0) throw new GraphError({ message: `Negative cycle detected involving node ${i}` });
	const paths = /* @__PURE__ */ new Map();
	const costs = /* @__PURE__ */ new Map();
	for (const i of allNodes) {
		paths.set(i, /* @__PURE__ */ new Map());
		costs.set(i, /* @__PURE__ */ new Map());
		for (const j of allNodes) if (i === j) {
			paths.get(i).set(j, [i]);
			costs.get(i).set(j, []);
		} else if (distances.get(i).get(j) === Infinity) {
			paths.get(i).set(j, null);
			costs.get(i).set(j, []);
		} else {
			const path = [];
			const weights = [];
			let current = i;
			path.push(current);
			while (current !== j) {
				const nextNode = next.get(current).get(j);
				if (nextNode === null) break;
				const edgeData = edgeMatrix.get(current).get(nextNode);
				if (edgeData !== null) weights.push(edgeData);
				current = nextNode;
				path.push(current);
			}
			paths.get(i).set(j, path);
			costs.get(i).set(j, weights);
		}
	}
	return {
		distances,
		paths,
		costs
	};
});
/**
* Find the shortest path between two nodes using A* pathfinding algorithm.
*
* A* is an extension of Dijkstra's algorithm that uses a heuristic function to guide
* the search towards the target, potentially finding paths faster than Dijkstra's.
* The heuristic must be admissible (never overestimate the actual cost).
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<{ x: number; y: number }, number>((mutable) => {
*   const a = Graph.addNode(mutable, { x: 0, y: 0 })
*   const b = Graph.addNode(mutable, { x: 1, y: 0 })
*   const c = Graph.addNode(mutable, { x: 2, y: 0 })
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, c, 1)
* })
*
* // Manhattan distance heuristic
* const heuristic = (
*   nodeData: { x: number; y: number },
*   targetData: { x: number; y: number }
* ) => Math.abs(nodeData.x - targetData.x) + Math.abs(nodeData.y - targetData.y)
*
* const result = Graph.astar(graph, {
*   source: 0,
*   target: 2,
*   cost: (edgeData) => edgeData,
*   heuristic
* })
*
* if (result !== undefined) {
*   console.log(result.path) // [0, 1, 2] - shortest path
*   console.log(result.distance) // 2 - total distance
* }
* ```
*
* @since 4.0.0
* @category algorithms
*/
var astar = /*#__PURE__*/ dual(2, (graph, config) => {
	if (!graph.nodes.has(config.source)) throw missingNode(config.source);
	if (!graph.nodes.has(config.target)) throw missingNode(config.target);
	if (config.source === config.target) return {
		path: [config.source],
		distance: 0,
		costs: []
	};
	const targetNodeData = getNode(graph, config.target);
	if (isNone(targetNodeData)) throw new GraphError({ message: `Missing node data for target node ${config.target}` });
	const gScore = /* @__PURE__ */ new Map();
	const fScore = /* @__PURE__ */ new Map();
	const previous = /* @__PURE__ */ new Map();
	const visited = /* @__PURE__ */ new Set();
	for (const node of graph.nodes.keys()) {
		gScore.set(node, node === config.source ? 0 : Infinity);
		fScore.set(node, Infinity);
		previous.set(node, null);
	}
	const sourceNodeData = getNode(graph, config.source);
	if (isSome(sourceNodeData)) {
		const h = config.heuristic(sourceNodeData.value, targetNodeData.value);
		fScore.set(config.source, h);
	}
	const openSet = [{
		node: config.source,
		fScore: fScore.get(config.source)
	}];
	while (openSet.length > 0) {
		let minIndex = 0;
		for (let i = 1; i < openSet.length; i++) if (openSet[i].fScore < openSet[minIndex].fScore) minIndex = i;
		const currentNode = openSet.splice(minIndex, 1)[0].node;
		if (visited.has(currentNode)) continue;
		visited.add(currentNode);
		if (currentNode === config.target) break;
		const currentGScore = gScore.get(currentNode);
		const adjacencyList = graph.adjacency.get(currentNode);
		if (adjacencyList !== void 0) for (const edgeIndex of adjacencyList) {
			const edge = graph.edges.get(edgeIndex);
			if (edge !== void 0) {
				const neighbor = edge.target;
				const weight = config.cost(edge.data);
				if (weight < 0) throw new GraphError({ message: "A* algorithm requires non-negative edge weights" });
				const tentativeGScore = currentGScore + weight;
				if (tentativeGScore < gScore.get(neighbor)) {
					gScore.set(neighbor, tentativeGScore);
					previous.set(neighbor, {
						node: currentNode,
						edgeData: edge.data
					});
					const neighborNodeData = getNode(graph, neighbor);
					if (isSome(neighborNodeData)) {
						const f = tentativeGScore + config.heuristic(neighborNodeData.value, targetNodeData.value);
						fScore.set(neighbor, f);
						if (!visited.has(neighbor)) openSet.push({
							node: neighbor,
							fScore: f
						});
					}
				}
			}
		}
	}
	const distance = gScore.get(config.target);
	if (distance === Infinity) return;
	const path = [];
	const costs = [];
	let currentNode = config.target;
	while (currentNode !== null) {
		path.unshift(currentNode);
		const prev = previous.get(currentNode) ?? null;
		if (prev !== null) {
			costs.unshift(prev.edgeData);
			currentNode = prev.node;
		} else currentNode = null;
	}
	return {
		path,
		distance,
		costs
	};
});
/**
* Find the shortest path between two nodes using Bellman-Ford algorithm.
*
* Bellman-Ford algorithm can handle negative edge weights and detects negative cycles.
* It has O(VE) time complexity, slower than Dijkstra's but more versatile.
* Returns Option.none() if a negative cycle is detected that affects the path.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, -1) // Negative weight allowed
*   Graph.addEdge(mutable, b, c, 3)
*   Graph.addEdge(mutable, a, c, 5)
* })
*
* const result = Graph.bellmanFord(graph, {
*   source: 0,
*   target: 2,
*   cost: (edgeData) => edgeData
* })
*
* if (result !== undefined) {
*   console.log(result.path) // [0, 1, 2] - shortest path A->B->C
*   console.log(result.distance) // 2 - total distance
* }
* ```
*
* @since 4.0.0
* @category algorithms
*/
var bellmanFord = /*#__PURE__*/ dual(2, (graph, config) => {
	if (!graph.nodes.has(config.source)) throw missingNode(config.source);
	if (!graph.nodes.has(config.target)) throw missingNode(config.target);
	if (config.source === config.target) return {
		path: [config.source],
		distance: 0,
		costs: []
	};
	const distances = /* @__PURE__ */ new Map();
	const previous = /* @__PURE__ */ new Map();
	for (const node of graph.nodes.keys()) {
		distances.set(node, node === config.source ? 0 : Infinity);
		previous.set(node, null);
	}
	const edges = [];
	for (const [, edgeData] of graph.edges) {
		const weight = config.cost(edgeData.data);
		edges.push({
			source: edgeData.source,
			target: edgeData.target,
			weight,
			edgeData: edgeData.data
		});
	}
	const nodeCount = graph.nodes.size;
	for (let i = 0; i < nodeCount - 1; i++) {
		let hasUpdate = false;
		for (const edge of edges) {
			const sourceDistance = distances.get(edge.source);
			const targetDistance = distances.get(edge.target);
			if (sourceDistance !== Infinity && sourceDistance + edge.weight < targetDistance) {
				distances.set(edge.target, sourceDistance + edge.weight);
				previous.set(edge.target, {
					node: edge.source,
					edgeData: edge.edgeData
				});
				hasUpdate = true;
			}
		}
		if (!hasUpdate) break;
	}
	for (const edge of edges) {
		const sourceDistance = distances.get(edge.source);
		const targetDistance = distances.get(edge.target);
		if (sourceDistance !== Infinity && sourceDistance + edge.weight < targetDistance) {
			const affectedNodes = /* @__PURE__ */ new Set();
			const queue = [edge.target];
			while (queue.length > 0) {
				const node = queue.shift();
				if (affectedNodes.has(node)) continue;
				affectedNodes.add(node);
				const adjacencyList = graph.adjacency.get(node);
				if (adjacencyList !== void 0) for (const edgeIndex of adjacencyList) {
					const edge = graph.edges.get(edgeIndex);
					if (edge !== void 0) queue.push(edge.target);
				}
			}
			if (affectedNodes.has(config.target)) return;
		}
	}
	const distance = distances.get(config.target);
	if (distance === Infinity) return;
	const path = [];
	const costs = [];
	let currentNode = config.target;
	while (currentNode !== null) {
		path.unshift(currentNode);
		const prev = previous.get(currentNode);
		if (prev !== null) {
			costs.unshift(prev.edgeData);
			currentNode = prev.node;
		} else currentNode = null;
	}
	return {
		path,
		distance,
		costs
	};
});
/**
* Concrete class for iterables that produce [NodeIndex, NodeData] tuples.
*
* This class provides a common abstraction for all iterables that return node data,
* including traversal iterators (DFS, BFS, etc.) and element iterators (nodes, externals).
* It uses a mapEntry function pattern for flexible iteration and transformation.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, 1)
* })
*
* // Both traversal and element iterators return NodeWalker
* const dfsNodes: Graph.NodeWalker<string> = Graph.dfs(graph, { start: [0] })
* const allNodes: Graph.NodeWalker<string> = Graph.nodes(graph)
*
* // Common interface for working with node iterables
* function processNodes<N>(nodeIterable: Graph.NodeWalker<N>): Array<number> {
*   return Array.from(Graph.indices(nodeIterable))
* }
*
* // Access node data using values() or entries()
* const nodeData = Array.from(Graph.values(dfsNodes)) // ["A", "B"]
* const nodeEntries = Array.from(Graph.entries(allNodes)) // [[0, "A"], [1, "B"]]
* ```
*
* @since 4.0.0
* @category models
*/
var Walker = class {
	[Symbol.iterator];
	/**
	* Visits each element and maps it to a value using the provided function.
	*
	* Takes a function that receives the index and data,
	* and returns an iterable of the mapped values. Skips elements that
	* no longer exist in the graph.
	*
	* @example
	* ```ts
	* import { Graph } from "effect"
	*
	* const graph = Graph.directed<string, number>((mutable) => {
	*   const a = Graph.addNode(mutable, "A")
	*   const b = Graph.addNode(mutable, "B")
	*   Graph.addEdge(mutable, a, b, 1)
	* })
	*
	* const dfs = Graph.dfs(graph, { start: [0] })
	*
	* // Map to just the node data
	* const values = Array.from(dfs.visit((index, data) => data))
	* console.log(values) // ["A", "B"]
	*
	* // Map to custom objects
	* const custom = Array.from(
	*   dfs.visit((index, data) => ({ id: index, name: data }))
	* )
	* console.log(custom) // [{ id: 0, name: "A" }, { id: 1, name: "B" }]
	* ```
	*
	* @since 4.0.0
	* @category iterators
	*/
	visit;
	constructor(visit) {
		this.visit = visit;
		this[Symbol.iterator] = visit((index, data) => [index, data])[Symbol.iterator];
	}
};
/**
* Returns an iterator over the indices in the walker.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, 1)
* })
*
* const dfs = Graph.dfs(graph, { start: [0] })
* const indices = Array.from(Graph.indices(dfs))
* console.log(indices) // [0, 1]
* ```
*
* @since 4.0.0
* @category utilities
*/
var indices = (walker) => walker.visit((index, _) => index);
/**
* Returns an iterator over the values (data) in the walker.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, 1)
* })
*
* const dfs = Graph.dfs(graph, { start: [0] })
* const values = Array.from(Graph.values(dfs))
* console.log(values) // ["A", "B"]
* ```
*
* @since 4.0.0
* @category utilities
*/
var values$4 = (walker) => walker.visit((_, data) => data);
/**
* Returns an iterator over [index, data] entries in the walker.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, 1)
* })
*
* const dfs = Graph.dfs(graph, { start: [0] })
* const entries = Array.from(Graph.entries(dfs))
* console.log(entries) // [[0, "A"], [1, "B"]]
* ```
*
* @since 4.0.0
* @category utilities
*/
var entries$4 = (walker) => walker.visit((index, data) => [index, data]);
/**
* Creates a new DFS iterator with optional configuration.
*
* The iterator maintains a stack of nodes to visit and tracks discovered nodes.
* It provides lazy evaluation of the depth-first search.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, c, 1)
* })
*
* // Start from a specific node
* const dfs1 = Graph.dfs(graph, { start: [0] })
* for (const nodeIndex of Graph.indices(dfs1)) {
*   console.log(nodeIndex) // Traverses in DFS order: 0, 1, 2
* }
*
* // Empty iterator (no starting nodes)
* const dfs2 = Graph.dfs(graph)
* // Can be used programmatically
* ```
*
* @since 4.0.0
* @category iterators
*/
var dfs = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, config = {}) => {
	const start = config.start ?? [];
	const direction = config.direction ?? "outgoing";
	for (const nodeIndex of start) if (!hasNode(graph, nodeIndex)) throw missingNode(nodeIndex);
	return new Walker((f) => ({ [Symbol.iterator]: () => {
		const stack = [...start];
		const discovered = /* @__PURE__ */ new Set();
		const nextMapped = () => {
			while (stack.length > 0) {
				const current = stack.pop();
				if (discovered.has(current)) continue;
				discovered.add(current);
				const nodeDataOption = getNode(graph, current);
				if (isNone(nodeDataOption)) continue;
				const neighbors = neighborsDirected(graph, current, direction);
				for (let i = neighbors.length - 1; i >= 0; i--) {
					const neighbor = neighbors[i];
					if (!discovered.has(neighbor)) stack.push(neighbor);
				}
				return {
					done: false,
					value: f(current, nodeDataOption.value)
				};
			}
			return {
				done: true,
				value: void 0
			};
		};
		return { next: nextMapped };
	} }));
});
/**
* Creates a new BFS iterator with optional configuration.
*
* The iterator maintains a queue of nodes to visit and tracks discovered nodes.
* It provides lazy evaluation of the breadth-first search.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, c, 1)
* })
*
* // Start from a specific node
* const bfs1 = Graph.bfs(graph, { start: [0] })
* for (const nodeIndex of Graph.indices(bfs1)) {
*   console.log(nodeIndex) // Traverses in BFS order: 0, 1, 2
* }
*
* // Empty iterator (no starting nodes)
* const bfs2 = Graph.bfs(graph)
* // Can be used programmatically
* ```
*
* @since 4.0.0
* @category iterators
*/
var bfs = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, config = {}) => {
	const start = config.start ?? [];
	const direction = config.direction ?? "outgoing";
	for (const nodeIndex of start) if (!hasNode(graph, nodeIndex)) throw missingNode(nodeIndex);
	return new Walker((f) => ({ [Symbol.iterator]: () => {
		const queue = [...start];
		const discovered = /* @__PURE__ */ new Set();
		const nextMapped = () => {
			while (queue.length > 0) {
				const current = queue.shift();
				if (!discovered.has(current)) {
					discovered.add(current);
					const neighbors = neighborsDirected(graph, current, direction);
					for (const neighbor of neighbors) if (!discovered.has(neighbor)) queue.push(neighbor);
					const nodeData = getNode(graph, current);
					if (isSome(nodeData)) return {
						done: false,
						value: f(current, nodeData.value)
					};
					return nextMapped();
				}
			}
			return {
				done: true,
				value: void 0
			};
		};
		return { next: nextMapped };
	} }));
});
/**
* Creates a new topological sort iterator with optional configuration.
*
* The iterator uses Kahn's algorithm to lazily produce nodes in topological order.
* Throws an error if the graph contains cycles.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, c, 1)
* })
*
* // Standard topological sort
* const topo1 = Graph.topo(graph)
* for (const nodeIndex of Graph.indices(topo1)) {
*   console.log(nodeIndex) // 0, 1, 2 (topological order)
* }
*
* // With initial nodes
* const topo2 = Graph.topo(graph, { initials: [0] })
*
* // Throws error for cyclic graph
* const cyclicGraph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, a, 2) // Creates cycle
* })
*
* try {
*   Graph.topo(cyclicGraph) // Throws: "Cannot perform topological sort on cyclic graph"
* } catch (error) {
*   console.log((error as Error).message)
* }
* ```
*
* @since 4.0.0
* @category iterators
*/
var topo = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, config = {}) => {
	if (!isAcyclic(graph)) throw new GraphError({ message: "Cannot perform topological sort on cyclic graph" });
	const initials = config.initials ?? [];
	for (const nodeIndex of initials) if (!hasNode(graph, nodeIndex)) throw missingNode(nodeIndex);
	return new Walker((f) => ({ [Symbol.iterator]: () => {
		const inDegree = /* @__PURE__ */ new Map();
		const remaining = /* @__PURE__ */ new Set();
		const queue = [...initials];
		for (const [nodeIndex] of graph.nodes) {
			inDegree.set(nodeIndex, 0);
			remaining.add(nodeIndex);
		}
		for (const [, edgeData] of graph.edges) {
			const currentInDegree = inDegree.get(edgeData.target) || 0;
			inDegree.set(edgeData.target, currentInDegree + 1);
		}
		if (initials.length === 0) {
			for (const [nodeIndex, degree] of inDegree) if (degree === 0) queue.push(nodeIndex);
		}
		const nextMapped = () => {
			while (queue.length > 0) {
				const current = queue.shift();
				if (remaining.has(current)) {
					remaining.delete(current);
					const neighbors = neighborsDirected(graph, current, "outgoing");
					for (const neighbor of neighbors) if (remaining.has(neighbor)) {
						const newInDegree = (inDegree.get(neighbor) || 0) - 1;
						inDegree.set(neighbor, newInDegree);
						if (newInDegree === 0) queue.push(neighbor);
					}
					const nodeData = getNode(graph, current);
					if (isSome(nodeData)) return {
						done: false,
						value: f(current, nodeData.value)
					};
					return nextMapped();
				}
			}
			return {
				done: true,
				value: void 0
			};
		};
		return { next: nextMapped };
	} }));
});
/**
* Creates a new DFS postorder iterator with optional configuration.
*
* The iterator maintains a stack with visit state tracking and emits nodes
* in postorder (after all descendants have been processed). Essential for
* dependency resolution and tree destruction algorithms.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const root = Graph.addNode(mutable, "root")
*   const child1 = Graph.addNode(mutable, "child1")
*   const child2 = Graph.addNode(mutable, "child2")
*   Graph.addEdge(mutable, root, child1, 1)
*   Graph.addEdge(mutable, root, child2, 1)
* })
*
* // Postorder: children before parents
* const postOrder = Graph.dfsPostOrder(graph, { start: [0] })
* for (const node of postOrder) {
*   console.log(node) // 1, 2, 0
* }
* ```
*
* @since 4.0.0
* @category iterators
*/
var dfsPostOrder = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, config = {}) => {
	const start = config.start ?? [];
	const direction = config.direction ?? "outgoing";
	for (const nodeIndex of start) if (!hasNode(graph, nodeIndex)) throw missingNode(nodeIndex);
	return new Walker((f) => ({ [Symbol.iterator]: () => {
		const stack = [];
		const discovered = /* @__PURE__ */ new Set();
		const finished = /* @__PURE__ */ new Set();
		for (let i = start.length - 1; i >= 0; i--) stack.push({
			node: start[i],
			visitedChildren: false
		});
		const nextMapped = () => {
			while (stack.length > 0) {
				const current = stack[stack.length - 1];
				if (!discovered.has(current.node)) {
					discovered.add(current.node);
					current.visitedChildren = false;
				}
				if (!current.visitedChildren) {
					current.visitedChildren = true;
					const neighbors = neighborsDirected(graph, current.node, direction);
					for (let i = neighbors.length - 1; i >= 0; i--) {
						const neighbor = neighbors[i];
						if (!discovered.has(neighbor) && !finished.has(neighbor)) stack.push({
							node: neighbor,
							visitedChildren: false
						});
					}
				} else {
					const nodeToEmit = stack.pop().node;
					if (!finished.has(nodeToEmit)) {
						finished.add(nodeToEmit);
						const nodeData = getNode(graph, nodeToEmit);
						if (isSome(nodeData)) return {
							done: false,
							value: f(nodeToEmit, nodeData.value)
						};
						return nextMapped();
					}
				}
			}
			return {
				done: true,
				value: void 0
			};
		};
		return { next: nextMapped };
	} }));
});
/**
* Creates an iterator over all node indices in the graph.
*
* The iterator produces node indices in the order they were added to the graph.
* This provides access to all nodes regardless of connectivity.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 1)
* })
*
* const indices = Array.from(Graph.indices(Graph.nodes(graph)))
* console.log(indices) // [0, 1, 2]
* ```
*
* @since 4.0.0
* @category iterators
*/
var nodes = (graph) => new Walker((f) => ({ [Symbol.iterator]() {
	const iterator = graph.nodes.entries();
	return { next() {
		const result = iterator.next();
		if (result.done) return {
			done: true,
			value: void 0
		};
		const [nodeIndex, nodeData] = result.value;
		return {
			done: false,
			value: f(nodeIndex, nodeData)
		};
	} };
} }));
/**
* Creates an iterator over all edge indices in the graph.
*
* The iterator produces edge indices in the order they were added to the graph.
* This provides access to all edges regardless of connectivity.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const a = Graph.addNode(mutable, "A")
*   const b = Graph.addNode(mutable, "B")
*   const c = Graph.addNode(mutable, "C")
*   Graph.addEdge(mutable, a, b, 1)
*   Graph.addEdge(mutable, b, c, 2)
* })
*
* const indices = Array.from(Graph.indices(Graph.edges(graph)))
* console.log(indices) // [0, 1]
* ```
*
* @since 4.0.0
* @category iterators
*/
var edges = (graph) => new Walker((f) => ({ [Symbol.iterator]() {
	const iterator = graph.edges.entries();
	return { next() {
		const result = iterator.next();
		if (result.done) return {
			done: true,
			value: void 0
		};
		const [edgeIndex, edgeData] = result.value;
		return {
			done: false,
			value: f(edgeIndex, edgeData)
		};
	} };
} }));
/**
* Creates an iterator over external nodes (nodes without edges in specified direction).
*
* External nodes are nodes that have no outgoing edges (direction="outgoing") or
* no incoming edges (direction="incoming"). These are useful for finding
* sources, sinks, or isolated nodes.
*
* @example
* ```ts
* import { Graph } from "effect"
*
* const graph = Graph.directed<string, number>((mutable) => {
*   const source = Graph.addNode(mutable, "source") // 0 - no incoming
*   const middle = Graph.addNode(mutable, "middle") // 1 - has both
*   const sink = Graph.addNode(mutable, "sink") // 2 - no outgoing
*   const isolated = Graph.addNode(mutable, "isolated") // 3 - no edges
*
*   Graph.addEdge(mutable, source, middle, 1)
*   Graph.addEdge(mutable, middle, sink, 2)
* })
*
* // Nodes with no outgoing edges (sinks + isolated)
* const sinks = Array.from(
*   Graph.indices(Graph.externals(graph, { direction: "outgoing" }))
* )
* console.log(sinks) // [2, 3]
*
* // Nodes with no incoming edges (sources + isolated)
* const sources = Array.from(
*   Graph.indices(Graph.externals(graph, { direction: "incoming" }))
* )
* console.log(sources) // [0, 3]
* ```
*
* @since 4.0.0
* @category iterators
*/
var externals = /*#__PURE__*/ dual((args) => isGraph(args[0]), (graph, config = {}) => {
	const direction = config.direction ?? "outgoing";
	return new Walker((f) => ({ [Symbol.iterator]: () => {
		const nodeMap = graph.nodes;
		const adjacencyMap = direction === "incoming" ? graph.reverseAdjacency : graph.adjacency;
		const nodeIterator = nodeMap.entries();
		const nextMapped = () => {
			let current = nodeIterator.next();
			while (!current.done) {
				const [nodeIndex, nodeData] = current.value;
				const adjacencyList = adjacencyMap.get(nodeIndex);
				if (adjacencyList === void 0 || adjacencyList.length === 0) return {
					done: false,
					value: f(nodeIndex, nodeData)
				};
				current = nodeIterator.next();
			}
			return {
				done: true,
				value: void 0
			};
		};
		return { next: nextMapped };
	} }));
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/HashRing.js
/**
* @since 4.0.0
*/
var HashRing_exports = /* @__PURE__ */ __exportAll({
	add: () => add$2,
	addMany: () => addMany,
	get: () => get$12,
	getShards: () => getShards,
	has: () => has$6,
	isHashRing: () => isHashRing,
	make: () => make$22,
	remove: () => remove$5
});
var TypeId$23 = "~effect/cluster/HashRing";
/**
* @since 4.0.0
* @category Guards
*/
var isHashRing = (u) => hasProperty(u, TypeId$23);
/**
* @since 4.0.0
* @category Constructors
*/
var make$22 = (options) => {
	const self = Object.create(Proto$5);
	self.baseWeight = Math.max(options?.baseWeight ?? 128, 1);
	self.totalWeightCache = 0;
	self.nodes = /* @__PURE__ */ new Map();
	self.ring = [];
	return self;
};
var Proto$5 = {
	...PipeInspectableProto,
	[TypeId$23]: TypeId$23,
	[Symbol.iterator]() {
		return map$10(this.nodes.values(), ([n]) => n)[Symbol.iterator]();
	},
	toJSON() {
		return {
			_id: "HashRing",
			baseWeight: this.baseWeight,
			nodes: this.ring.map(([, n]) => this.nodes.get(n)[0])
		};
	}
};
/**
* Add new nodes to the ring. If a node already exists in the ring, it
* will be updated. For example, you can use this to update the node's weight.
*
* @since 4.0.0
* @category Combinators
*/
var addMany = /*#__PURE__*/ dual((args) => isHashRing(args[0]), (self, nodes, options) => {
	const weight = Math.max(options?.weight ?? 1, .1);
	const keys = [];
	let toRemove;
	for (const node of nodes) {
		const key = value$2(node);
		const entry = self.nodes.get(key);
		if (entry) {
			if (entry[1] === weight) continue;
			toRemove ??= /* @__PURE__ */ new Set();
			toRemove.add(key);
			self.totalWeightCache -= entry[1];
			self.totalWeightCache += weight;
			entry[1] = weight;
		} else {
			self.nodes.set(key, [node, weight]);
			self.totalWeightCache += weight;
		}
		keys.push(key);
	}
	if (toRemove) self.ring = self.ring.filter(([, n]) => !toRemove.has(n));
	addNodesToRing(self, keys, Math.round(weight * self.baseWeight));
	return self;
});
function addNodesToRing(self, keys, weight) {
	for (let i = weight; i > 0; i--) for (let j = 0; j < keys.length; j++) {
		const key = keys[j];
		self.ring.push([string$3(`${key}:${i}`), key]);
	}
	self.ring.sort((a, b) => a[0] - b[0]);
}
/**
* Add a new node to the ring. If the node already exists in the ring, it
* will be updated. For example, you can use this to update the node's weight.
*
* @since 4.0.0
* @category Combinators
*/
var add$2 = /*#__PURE__*/ dual((args) => isHashRing(args[0]), (self, node, options) => addMany(self, [node], options));
/**
* Removes the node from the ring. No-op's if the node does not exist.
*
* @since 4.0.0
* @category Combinators
*/
var remove$5 = /*#__PURE__*/ dual(2, (self, node) => {
	const key = value$2(node);
	const entry = self.nodes.get(key);
	if (entry) {
		self.nodes.delete(key);
		self.ring = self.ring.filter(([, n]) => n !== key);
		self.totalWeightCache -= entry[1];
	}
	return self;
});
/**
* @since 4.0.0
* @category Combinators
*/
var has$6 = /*#__PURE__*/ dual(2, (self, node) => self.nodes.has(value$2(node)));
/**
* Gets the node which should handle the given input. Returns undefined if
* the hashring has no elements with weight.
*
* @since 4.0.0
* @category Combinators
*/
var get$12 = (self, input) => {
	if (self.ring.length === 0) return;
	const index = getIndexForInput(self, string$3(input))[0];
	const node = self.ring[index][1];
	return self.nodes.get(node)[0];
};
/**
* Distributes `count` shards across the nodes in the ring, attempting to
* balance the number of shards allocated to each node. Returns undefined if
* the hashring has no elements with weight.
*
* @since 4.0.0
* @category Combinators
*/
var getShards = (self, count) => {
	if (self.ring.length === 0) return;
	const shards = new Array(count);
	const allocations = /* @__PURE__ */ new Map();
	const remaining = /* @__PURE__ */ new Set();
	const exclude = /* @__PURE__ */ new Set();
	const distances = new Array(count);
	for (let shard = 0; shard < count; shard++) {
		const [index, distance] = getIndexForInput(self, shardHashes[shard] ??= string$3(`shard-${shard}`));
		const node = self.ring[index][1];
		distances[shard] = [
			shard,
			node,
			distance
		];
		remaining.add(shard);
	}
	distances.sort((a, b) => a[2] - b[2]);
	for (let i = 0; i < count; i++) {
		const [shard, node] = distances[i];
		if (exclude.has(node)) continue;
		const [value, weight] = self.nodes.get(node);
		shards[shard] = value;
		remaining.delete(shard);
		const nodeCount = (allocations.get(node) ?? 0) + 1;
		allocations.set(node, nodeCount);
		if (nodeCount >= Math.max(1, Math.floor(count * (weight / self.totalWeightCache)))) exclude.add(node);
	}
	let allAtMax = exclude.size === self.nodes.size;
	remaining.forEach((shard) => {
		const index = getIndexForInput(self, shardHashes[shard], allAtMax ? void 0 : exclude)[0];
		const node = self.ring[index][1];
		const [value, weight] = self.nodes.get(node);
		shards[shard] = value;
		if (allAtMax) return;
		const nodeCount = (allocations.get(node) ?? 0) + 1;
		allocations.set(node, nodeCount);
		if (nodeCount >= Math.max(1, Math.floor(count * (weight / self.totalWeightCache)))) {
			exclude.add(node);
			if (exclude.size === self.nodes.size) allAtMax = true;
		}
	});
	return shards;
};
var shardHashes = [];
function getIndexForInput(self, hash, exclude) {
	const ring = self.ring;
	const len = ring.length;
	let mid;
	let lo = 0;
	let hi = len - 1;
	while (lo <= hi) {
		mid = (lo + hi) / 2 >>> 0;
		if (ring[mid][0] >= hash) hi = mid - 1;
		else lo = mid + 1;
	}
	const a = lo === len ? lo - 1 : lo;
	const distA = Math.abs(ring[a][0] - hash);
	if (exclude === void 0) {
		const b = lo - 1;
		if (b < 0) return [a, distA];
		const distB = Math.abs(ring[b][0] - hash);
		return distA <= distB ? [a, distA] : [b, distB];
	} else if (!exclude.has(ring[a][1])) return [a, distA];
	const range = Math.max(lo, len - lo);
	for (let i = 1; i < range; i++) {
		let index = lo - i;
		if (index >= 0 && index < len && !exclude.has(ring[index][1])) return [index, Math.abs(ring[index][0] - hash)];
		index = lo + i;
		if (index >= 0 && index < len && !exclude.has(ring[index][1])) return [index, Math.abs(ring[index][0] - hash)];
	}
	return [a, distA];
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/HKT.js
var HKT_exports = /* @__PURE__ */ __exportAll({});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/LayerMap.js
var LayerMap_exports = /* @__PURE__ */ __exportAll({
	Service: () => Service,
	fromRecord: () => fromRecord,
	make: () => make$21
});
var TypeId$22 = "~effect/LayerMap";
/**
* @since 3.14.0
* @category Constructors
*
* A `LayerMap` allows you to create a map of Layer's that can be used to
* dynamically access resources based on a key.
*
* @example
* ```ts
* import { Effect, Layer, LayerMap, ServiceMap } from "effect"
*
* // Define a service key
* const DatabaseService = ServiceMap.Service<{
*   readonly query: (sql: string) => Effect.Effect<string>
* }>("Database")
*
* // Create a LayerMap that provides different database configurations
* const program = Effect.gen(function*() {
*   const layerMap = yield* LayerMap.make(
*     (env: string) =>
*       Layer.succeed(DatabaseService)({
*         query: (sql) => Effect.succeed(`${env}: ${sql}`)
*       }),
*     { idleTimeToLive: "5 seconds" }
*   )
*
*   // Get a layer for a specific environment
*   const devLayer = layerMap.get("development")
*
*   // Use the layer to provide the service
*   const result = yield* Effect.provide(
*     Effect.gen(function*() {
*       const db = yield* DatabaseService
*       return yield* db.query("SELECT * FROM users")
*     }),
*     devLayer
*   )
*
*   console.log(result) // "development: SELECT * FROM users"
* })
* ```
*/
var make$21 = /*#__PURE__*/ fnUntraced(function* (lookup, options) {
	const services$1 = yield* services();
	const memoMap = CurrentMemoMap.getOrCreate(services$1);
	const rcMap = yield* make$34({
		lookup: (key) => servicesWith$1((_) => buildWithMemoMap(lookup(key), memoMap, get$16(_, Scope))),
		idleTimeToLive: options?.idleTimeToLive
	});
	return identity({
		[TypeId$22]: TypeId$22,
		rcMap,
		get: (key) => effectServices(get$19(rcMap, key)),
		services: (key) => get$19(rcMap, key),
		invalidate: (key) => invalidate$2(rcMap, key)
	});
});
/**
* @since 3.14.0
* @category Constructors
* @example
* ```ts
* import { Effect, Layer, LayerMap, ServiceMap } from "effect"
*
* // Define service keys
* const DevDatabase = ServiceMap.Service<{
*   readonly query: (sql: string) => Effect.Effect<string>
* }>("DevDatabase")
*
* const ProdDatabase = ServiceMap.Service<{
*   readonly query: (sql: string) => Effect.Effect<string>
* }>("ProdDatabase")
*
* // Create predefined layers
* const layers = {
*   development: Layer.succeed(DevDatabase)({
*     query: (sql) => Effect.succeed(`DEV: ${sql}`)
*   }),
*   production: Layer.succeed(ProdDatabase)({
*     query: (sql) => Effect.succeed(`PROD: ${sql}`)
*   })
* } as const
*
* // Create a LayerMap from the record
* const program = Effect.gen(function*() {
*   const layerMap = yield* LayerMap.fromRecord(layers, {
*     idleTimeToLive: "10 seconds"
*   })
*
*   // Get layers by key
*   const devLayer = layerMap.get("development")
*   const prodLayer = layerMap.get("production")
*
*   console.log("LayerMap created from record")
* })
* ```
*/
var fromRecord = (layers, options) => make$21((key) => layers[key], {
	...options,
	preloadKeys: options?.preload ? Object.keys(layers) : void 0
});
/**
* @since 3.14.0
* @category Service
*
* Create a `LayerMap` service that provides a dynamic set of resources based on
* a key.
*
* @example
* ```ts
* import { Console, Effect, Layer, LayerMap, ServiceMap } from "effect"
*
* // Define a service key
* const Greeter = ServiceMap.Service<{
*   readonly greet: Effect.Effect<string>
* }>("Greeter")
*
* // Create a service that wraps a LayerMap
* class GreeterMap extends LayerMap.Service<GreeterMap>()("GreeterMap", {
*   // Define the lookup function for the layer map
*   lookup: (name: string) =>
*     Layer.succeed(Greeter)({
*       greet: Effect.succeed(`Hello, ${name}!`)
*     }),
*
*   // If a layer is not used for a certain amount of time, it can be removed
*   idleTimeToLive: "5 seconds"
* }) {}
*
* // Usage
* const program = Effect.gen(function*() {
*   // Access and use the Greeter service
*   const greeter = yield* Greeter
*   yield* Console.log(yield* greeter.greet)
* }).pipe(
*   // Use the GreeterMap service to provide a variant of the Greeter service
*   Effect.provide(GreeterMap.get("John"))
* ).pipe(
*   // Provide the GreeterMap layer
*   Effect.provide(GreeterMap.layer)
* )
* ```
*/
var Service = () => (id, options) => {
	const Err = globalThis.Error;
	const limit = Err.stackTraceLimit;
	Err.stackTraceLimit = 2;
	const creationError = new Err();
	Err.stackTraceLimit = limit;
	function TagClass() {}
	const TagClass_ = TagClass;
	Object.setPrototypeOf(TagClass, Object.getPrototypeOf(Service$1(id)));
	TagClass.key = id;
	Object.defineProperty(TagClass, "stack", { get() {
		return creationError.stack;
	} });
	TagClass_.layerNoDeps = effect(TagClass_)("lookup" in options ? make$21(options.lookup, options) : fromRecord(options.layers, options));
	TagClass_.layer = options.dependencies && options.dependencies.length > 0 ? provide$1(TagClass_.layerNoDeps, options.dependencies) : TagClass_.layerNoDeps;
	TagClass_.get = (key) => unwrap$1(map$11(TagClass_.asEffect(), (layerMap) => layerMap.get(key)));
	TagClass_.services = (key) => flatMap$2(TagClass_.asEffect(), (layerMap) => layerMap.services(key));
	TagClass_.invalidate = (key) => flatMap$2(TagClass_.asEffect(), (layerMap) => layerMap.invalidate(key));
	return TagClass;
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Logger.js
/**
* @since 2.0.0
*
* The `Logger` module provides a robust and flexible logging system for Effect applications.
* It offers structured logging, multiple output formats, and seamless integration with the
* Effect runtime's tracing and context management.
*
* ## Key Features
*
* - **Structured Logging**: Built-in support for structured log messages with metadata
* - **Multiple Formats**: JSON, LogFmt, Pretty, and custom formatting options
* - **Context Integration**: Automatic capture of fiber context, spans, and annotations
* - **Batching**: Efficient log aggregation and batch processing
* - **File Output**: Direct file writing with configurable batch windows
* - **Composable**: Transform and compose loggers using functional patterns
*
* ## Basic Usage
*
* ```ts
* import { Effect } from "effect"
*
* // Basic logging
* const program = Effect.gen(function*() {
*   yield* Effect.log("Application started")
*   yield* Effect.logInfo("Processing user request")
*   yield* Effect.logWarning("Resource limit approaching")
*   yield* Effect.logError("Database connection failed")
* })
*
* // With structured data
* const structuredLog = Effect.gen(function*() {
*   yield* Effect.log("User action", { userId: 123, action: "login" })
*   yield* Effect.logInfo("Request processed", { duration: 150, statusCode: 200 })
* })
* ```
*
* ## Custom Loggers
*
* ```ts
* import { Effect, Logger } from "effect"
*
* // Create a custom logger
* const customLogger = Logger.make((options) => {
*   console.log(`[${options.logLevel}] ${options.message}`)
* })
*
* // Use JSON format for production
* const jsonLogger = Logger.consoleJson
*
* // Pretty format for development
* const prettyLogger = Logger.consolePretty()
*
* const program = Effect.log("Hello World").pipe(
*   Effect.provide(Logger.layer([jsonLogger]))
* )
* ```
*
* ## Multiple Loggers
*
* ```ts
* import { Effect, Logger } from "effect"
*
* // Combine multiple loggers
* const CombinedLoggerLive = Logger.layer([
*   Logger.consoleJson,
*   Logger.consolePretty()
* ])
*
* const program = Effect.log("Application event").pipe(
*   Effect.provide(CombinedLoggerLive)
* )
* ```
*
* ## Batched Logging
*
* ```ts
* import { Duration, Effect, Logger } from "effect"
*
* const batchedLogger = Logger.batched(Logger.formatJson, {
*   window: Duration.seconds(5),
*   flush: (messages) =>
*     Effect.sync(() => {
*       // Process batch of log messages
*       console.log("Flushing", messages.length, "log entries")
*     })
* })
*
* const program = Effect.gen(function*() {
*   const logger = yield* batchedLogger
*   yield* Effect.provide(
*     Effect.all([
*       Effect.log("Event 1"),
*       Effect.log("Event 2"),
*       Effect.log("Event 3")
*     ]),
*     Logger.layer([logger])
*   )
* })
* ```
*/
var Logger_exports = /* @__PURE__ */ __exportAll({
	CurrentLoggers: () => CurrentLoggers,
	LogToStderr: () => LogToStderr,
	batched: () => batched,
	consoleJson: () => consoleJson,
	consoleLogFmt: () => consoleLogFmt,
	consolePretty: () => consolePretty,
	consoleStructured: () => consoleStructured,
	defaultLogger: () => defaultLogger,
	formatJson: () => formatJson,
	formatLogFmt: () => formatLogFmt,
	formatSimple: () => formatSimple,
	formatStructured: () => formatStructured,
	isLogger: () => isLogger,
	layer: () => layer,
	make: () => make$20,
	map: () => map$6,
	toFile: () => toFile,
	tracerLogger: () => tracerLogger,
	withConsoleError: () => withConsoleError,
	withConsoleLog: () => withConsoleLog,
	withLeveledConsole: () => withLeveledConsole
});
var TypeId$21 = "~effect/Logger";
/**
* Returns `true` if the specified value is a `Logger`, otherwise returns `false`.
*
* @example
* ```ts
* import { Logger } from "effect"
*
* const myLogger = Logger.make((options) => {
*   console.log(options.message)
* })
*
* console.log(Logger.isLogger(myLogger)) // true
* console.log(Logger.isLogger("not a logger")) // false
* console.log(Logger.isLogger({ log: () => {} })) // false
* ```
*
* @since 2.0.0
* @category guards
*/
var isLogger = (u) => hasProperty(u, TypeId$21);
/**
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Access current loggers from fiber context
* const program = Effect.gen(function*() {
*   const currentLoggers = yield* Effect.service(Logger.CurrentLoggers)
*   console.log(`Number of active loggers: ${currentLoggers.size}`)
*
*   // Add a custom logger to the set
*   const customLogger = Logger.make((options) => {
*     console.log(`Custom: ${options.message}`)
*   })
*
*   yield* Effect.log("Hello from custom logger").pipe(
*     Effect.provide(Logger.layer([customLogger]))
*   )
* })
* ```
*
* @since 4.0.0
* @category references
*/
var CurrentLoggers = CurrentLoggers$1;
/**
* @since 4.0.0
* @category references
*/
var LogToStderr = LogToStderr$1;
/**
* Transforms the output of a `Logger` using the provided function.
*
* This allows you to modify, enhance, or completely change the output format
* of an existing logger without recreating the entire logging logic.
*
* @example
* ```ts
* import { Logger } from "effect"
*
* // Create a logger that outputs objects
* const structuredLogger = Logger.make((options) => ({
*   level: options.logLevel,
*   message: options.message,
*   timestamp: options.date.toISOString()
* }))
*
* // Transform the output to JSON strings
* const jsonStringLogger = Logger.map(
*   structuredLogger,
*   (output) => JSON.stringify(output)
* )
*
* // Transform to uppercase messages
* const uppercaseLogger = Logger.map(
*   structuredLogger,
*   (output) => ({ ...output, message: String(output.message).toUpperCase() })
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var map$6 = /*#__PURE__*/ dual(2, (self, f) => loggerMake((options) => f(self.log(options))));
/**
* Returns a new `Logger` that writes all output of the specified `Logger` to
* the console using `console.log`.
*
* This is useful for taking any logger that produces string or object output
* and routing it to the console for development or debugging purposes.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Create a custom formatter
* const customFormatter = Logger.make((options) =>
*   `[${options.date.toISOString()}] ${options.logLevel}: ${options.message}`
* )
*
* // Route to console
* const consoleLogger = Logger.withConsoleLog(customFormatter)
*
* const program = Effect.log("Hello World").pipe(
*   Effect.provide(Logger.layer([consoleLogger]))
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var withConsoleLog = (self) => loggerMake((options) => {
	return options.fiber.getRef(ConsoleRef).log(self.log(options));
});
/**
* Returns a new `Logger` that writes all output of the specified `Logger` to
* the console using `console.error`.
*
* This is particularly useful for error logging where you want to ensure
* log messages appear in the error stream (stderr) rather than standard output.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Create an error-specific formatter
* const errorFormatter = Logger.make((options) =>
*   `ERROR [${options.date.toISOString()}]: ${options.message}`
* )
*
* // Route to console.error
* const errorLogger = Logger.withConsoleError(errorFormatter)
*
* const program = Effect.logError("Database connection failed").pipe(
*   Effect.provide(Logger.layer([errorLogger]))
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var withConsoleError = (self) => loggerMake((options) => {
	return options.fiber.getRef(ConsoleRef).error(self.log(options));
});
/**
* Returns a new `Logger` that writes all output of the specified `Logger` to
* the console.
*
* Will use the appropriate console method (i.e. `console.log`, `console.error`,
* etc.) based upon the current `LogLevel`.
*
* - `Debug` -> `console.debug`
* - `Info` -> `console.info`
* - `Trace` -> `console.trace`
* - `Warn` -> `console.warn`
* - `Error` and `Fatal` -> `console.error`
* - Others -> `console.log`
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* const formatter = Logger.make((options) =>
*   `[${options.logLevel}] ${options.message}`
* )
*
* const leveledLogger = Logger.withLeveledConsole(formatter)
*
* const program = Effect.gen(function*() {
*   yield* Effect.logInfo("Info message") // -> console.info
*   yield* Effect.logWarning("Warning") // -> console.warn
*   yield* Effect.logError("Error occurred") // -> console.error
*   yield* Effect.logDebug("Debug info") // -> console.debug
* }).pipe(
*   Effect.provide(Logger.layer([leveledLogger]))
* )
* ```
*
* @since 2.0.0
* @category utils
*/
var withLeveledConsole = (self) => loggerMake((options) => {
	const console = options.fiber.getRef(ConsoleRef);
	const output = self.log(options);
	switch (options.logLevel) {
		case "Debug": return console.debug(output);
		case "Info": return console.info(output);
		case "Trace": return console.trace(output);
		case "Warn": return console.warn(output);
		case "Error":
		case "Fatal": return console.error(output);
		default: return console.log(output);
	}
});
/**
* Match strings that do not contain any whitespace characters, double quotes,
* or equal signs.
*/
var textOnly = /^[^\s"=]*$/;
/**
* Escapes double quotes in a string.
*/
var escapeDoubleQuotes = (s) => `"${s.replace(/\\([\s\S])|(")/g, "\\$1$2")}"`;
/**
* Formats the identifier of a `Fiber` by prefixing it with a hash tag.
*/
var formatFiberId = (fiberId) => `#${fiberId}`;
/**
* Used by both {@link formatSimple} and {@link formatLogFmt} to render a log
* message.
*
* @internal
*/
var format = (quoteValue, space) => ({ cause, date, fiber, logLevel, message }) => {
	const formatValue = (value) => value.match(textOnly) ? value : quoteValue(value);
	const format = (label, value) => `${formatLabel(label)}=${formatValue(value)}`;
	const append = (label, value) => " " + format(label, value);
	let out = format("timestamp", date.toISOString());
	out += append("level", logLevel);
	out += append("fiber", formatFiberId(fiber.id));
	const messages = ensure(message);
	for (let i = 0; i < messages.length; i++) out += append("message", format$1(messages[i], { space }));
	if (cause.reasons.length > 0) out += append("cause", causePretty(cause));
	const now = date.getTime();
	const spans = fiber.getRef(CurrentLogSpans);
	for (const span of spans) out += " " + formatLogSpan(span, now);
	const annotations = fiber.getRef(CurrentLogAnnotations);
	for (const [label, value] of Object.entries(annotations)) out += append(label, format$1(value, { space }));
	return out;
};
/**
* Creates a new `Logger` from a log function.
*
* The log function receives an options object containing the message, log level,
* cause, fiber information, and timestamp, and should return the desired output.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
* import { CurrentLogAnnotations } from "effect/References"
*
* // Simple text logger
* const textLogger = Logger.make((options) =>
*   `${options.date.toISOString()} [${options.logLevel}] ${options.message}`
* )
*
* // Structured object logger
* const objectLogger = Logger.make((options) => ({
*   timestamp: options.date.toISOString(),
*   level: options.logLevel,
*   message: options.message,
*   fiberId: options.fiber.id,
*   annotations: options.fiber.getRef(CurrentLogAnnotations)
* }))
*
* // Custom filtering logger
* const filteredLogger = Logger.make((options) => {
*   if (options.logLevel === "Debug") {
*     return // Skip debug messages
*   }
*   return `${options.logLevel}: ${options.message}`
* })
*
* const program = Effect.log("Hello World").pipe(
*   Effect.provide(Logger.layer([textLogger]))
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$20 = loggerMake;
/**
* The default logging implementation used by the Effect runtime.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the default logger (automatically used by Effect runtime)
* const program = Effect.gen(function*() {
*   yield* Effect.log("This uses the default logger")
*   yield* Effect.logInfo("Info message")
*   yield* Effect.logError("Error message")
* })
*
* // Explicitly use the default logger
* const withDefaultLogger = Effect.log("Explicit default").pipe(
*   Effect.provide(Logger.layer([Logger.defaultLogger]))
* )
*
* // Compare with custom logger
* const customLogger = Logger.make((options) => {
*   console.log(`CUSTOM: ${options.message}`)
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var defaultLogger = defaultLogger$1;
/**
* A `Logger` which outputs logs as a string.
*
* For example:
* ```
* timestamp=2025-01-03T14:22:47.570Z level=INFO fiber=#1 message=hello
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the simple format logger
* const simpleLoggerProgram = Effect.log("Hello Simple Format").pipe(
*   Effect.provide(Logger.layer([Logger.formatSimple]))
* )
*
* // Combine with console output
* const consoleSimpleLogger = Logger.withConsoleLog(Logger.formatSimple)
*
* const program = Effect.gen(function*() {
*   yield* Effect.log("Application started")
*   yield* Effect.logInfo("Processing data")
*   yield* Effect.logWarning("Memory usage high")
* }).pipe(
*   Effect.provide(Logger.layer([consoleSimpleLogger]))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var formatSimple = /*#__PURE__*/ loggerMake(/*#__PURE__*/ format(escapeDoubleQuotes));
/**
* A `Logger` which outputs logs using the [logfmt](https://brandur.org/logfmt)
* style.
*
* For example:
* ```
* timestamp=2025-01-03T14:22:47.570Z level=INFO fiber=#1 message=hello
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the logfmt format logger
* const logfmtLoggerProgram = Effect.log("Hello LogFmt Format").pipe(
*   Effect.provide(Logger.layer([Logger.formatLogFmt]))
* )
*
* // Perfect for structured logging systems
* const structuredProgram = Effect.gen(function*() {
*   yield* Effect.log("User login", { userId: 123, method: "OAuth" })
*   yield* Effect.logInfo("Request processed", {
*     duration: 45,
*     status: "success"
*   })
* }).pipe(
*   Effect.provide(Logger.layer([Logger.withConsoleLog(Logger.formatLogFmt)]))
* )
*
* // Good for log aggregation systems like Splunk, ELK
* const productionLogger = Logger.formatLogFmt
* ```
*
* @since 4.0.0
* @category constructors
*/
var formatLogFmt = /*#__PURE__*/ loggerMake(/*#__PURE__*/ format(JSON.stringify, 0));
/**
* A `Logger` which outputs logs using a structured format.
*
* For example:
* ```
* {
*   message: [ 'hello' ],
*   level: 'INFO',
*   timestamp: '2025-01-03T14:25:39.666Z',
*   annotations: { key: 'value' },
*   spans: { label: 0 },
*   fiberId: '#1'
* }
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the structured format logger
* const structuredLoggerProgram = Effect.log("Hello Structured Format").pipe(
*   Effect.provide(Logger.layer([Logger.formatStructured]))
* )
*
* // Perfect for JSON processing and analytics
* const analyticsProgram = Effect.gen(function*() {
*   yield* Effect.log("User action", { action: "click", element: "button" })
*   yield* Effect.logInfo("API call", { endpoint: "/users", duration: 150 })
* }).pipe(
*   Effect.annotateLogs("sessionId", "abc123"),
*   Effect.withLogSpan("request"),
*   Effect.provide(Logger.layer([Logger.formatStructured]))
* )
*
* // Process structured output
* const processingLogger = Logger.map(Logger.formatStructured, (output) => {
*   // Process the structured object
*   const enhanced = { ...output, processed: true }
*   return enhanced
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var formatStructured = /*#__PURE__*/ loggerMake(({ cause, date, fiber, logLevel, message }) => {
	const annotationsObj = {};
	const spansObj = {};
	const annotations = fiber.getRef(CurrentLogAnnotations);
	for (const [key, value] of Object.entries(annotations)) annotationsObj[key] = structuredMessage(value);
	const now = date.getTime();
	const spans = fiber.getRef(CurrentLogSpans);
	for (const [label, timestamp] of spans) spansObj[label] = now - timestamp;
	const messageArr = ensure(message);
	return {
		message: messageArr.length === 1 ? structuredMessage(messageArr[0]) : messageArr.map(structuredMessage),
		level: logLevel.toUpperCase(),
		timestamp: date.toISOString(),
		cause: cause.reasons.length > 0 ? causePretty(cause) : void 0,
		annotations: annotationsObj,
		spans: spansObj,
		fiberId: formatFiberId(fiber.id)
	};
});
/**
* A `Logger` which outputs logs using a structured format serialized as JSON
* on a single line.
*
* For example:
* ```
* {"message":["hello"],"level":"INFO","timestamp":"2025-01-03T14:28:57.508Z","annotations":{"key":"value"},"spans":{"label":0},"fiberId":"#1"}
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the JSON format logger
* const jsonLoggerProgram = Effect.log("Hello JSON Format").pipe(
*   Effect.provide(Logger.layer([Logger.formatJson]))
* )
*
* // Perfect for log aggregation and processing systems
* const productionProgram = Effect.gen(function*() {
*   yield* Effect.log("Server started", { port: 3000, env: "production" })
*   yield* Effect.logInfo("Request received", {
*     method: "GET",
*     path: "/api/users"
*   })
*   yield* Effect.logError("Database error", { error: "Connection timeout" })
* }).pipe(
*   Effect.annotateLogs("service", "api-server"),
*   Effect.withLogSpan("request-processing"),
*   Effect.provide(Logger.layer([Logger.formatJson]))
* )
*
* // Send to external logging service
* const externalLogger = Logger.map(Logger.formatJson, (jsonString) => {
*   // Send to Elasticsearch, CloudWatch, etc.
*   console.log("Sending to external service:", jsonString)
*   return jsonString
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var formatJson = /*#__PURE__*/ map$6(formatStructured, formatJson$1);
/**
* Returns a new `Logger` which will aggregate logs output by the specified
* `Logger` over the provided `window`. After the `window` has elapsed, the
* provided `flush` function will be called with the logs aggregated during
* the last `window`.
*
* This is useful for implementing efficient batch processing of logs, such as
* writing multiple log entries to a database or file in a single operation.
*
* @example
* ```ts
* import { Duration, Effect, Logger } from "effect"
*
* // Create a batched logger that flushes every 5 seconds
* const batchedLogger = Logger.batched(Logger.formatJson, {
*   window: Duration.seconds(5),
*   flush: (messages) =>
*     Effect.sync(() => {
*       console.log(`Flushing ${messages.length} log entries:`)
*       messages.forEach((msg, i) => console.log(`${i + 1}. ${msg}`))
*     })
* })
*
* const program = Effect.gen(function*() {
*   const logger = yield* batchedLogger
*
*   yield* Effect.provide(
*     Effect.all([
*       Effect.log("Event 1"),
*       Effect.log("Event 2"),
*       Effect.log("Event 3"),
*       Effect.sleep(Duration.seconds(6)), // Trigger flush
*       Effect.log("Event 4")
*     ]),
*     Logger.layer([logger])
*   )
* })
*
* // Remote batch logging example
* const remoteBatchLogger = Logger.batched(Logger.formatStructured, {
*   window: Duration.seconds(10),
*   flush: (entries) =>
*     Effect.sync(() => {
*       // Send batch to remote logging service
*       console.log(`Sending ${entries.length} log entries to remote service`)
*     })
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var batched = /*#__PURE__*/ dual(2, (self, options) => flatMap$3(scope, (scope) => {
	let buffer = [];
	const flush = suspend$1(() => {
		if (buffer.length === 0) return void_;
		const arr = buffer;
		buffer = [];
		return options.flush(arr);
	});
	return uninterruptibleMask$1((restore) => restore(sleep(options.window).pipe(andThen$1(flush), forever)).pipe(forkDetach, flatMap$3((fiber) => scopeAddFinalizerExit(scope, () => fiberInterrupt(fiber))), andThen$1(addFinalizer(() => flush)), as(loggerMake((options) => {
		buffer.push(self.log(options));
	}))));
}));
/**
* A `Logger` which outputs logs in a "pretty" format and writes them to the
* console.
*
* For example:
* ```
* [09:37:17.579] INFO (#1) label=0ms: hello
*   key: value
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the pretty console logger with default settings
* const basicPretty = Effect.log("Hello Pretty Format").pipe(
*   Effect.provide(Logger.layer([Logger.consolePretty()]))
* )
*
* // Configure pretty logger options
* const customPretty = Logger.consolePretty({
*   colors: true,
*   stderr: false,
*   mode: "tty",
*   formatDate: (date) => date.toLocaleTimeString()
* })
*
* // Perfect for development environment
* const developmentProgram = Effect.gen(function*() {
*   yield* Effect.log("Application starting")
*   yield* Effect.logInfo("Database connected")
*   yield* Effect.logWarning("High memory usage detected")
* }).pipe(
*   Effect.annotateLogs("environment", "development"),
*   Effect.withLogSpan("startup"),
*   Effect.provide(Logger.layer([customPretty]))
* )
*
* // Disable colors for CI/CD environments
* const ciLogger = Logger.consolePretty({ colors: false })
* ```
*
* @since 4.0.0
* @category constructors
*/
var consolePretty = consolePretty$1;
/**
* A `Logger` which outputs logs using the [logfmt](https://brandur.org/logfmt)
* style and writes them to the console.
*
* For example:
* ```
* timestamp=2025-01-03T14:22:47.570Z level=INFO fiber=#1 message=info
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the console logfmt logger
* const logfmtProgram = Effect.log("Hello LogFmt Console").pipe(
*   Effect.provide(Logger.layer([Logger.consoleLogFmt]))
* )
*
* // Great for production environments
* const productionProgram = Effect.gen(function*() {
*   yield* Effect.log("Server started", { port: 8080, version: "1.0.0" })
*   yield* Effect.logInfo("Request processed", { userId: 123, duration: 45 })
*   yield* Effect.logError("Validation failed", {
*     field: "email",
*     value: "invalid"
*   })
* }).pipe(
*   Effect.annotateLogs("service", "api"),
*   Effect.withLogSpan("request-handler"),
*   Effect.provide(Logger.layer([Logger.consoleLogFmt]))
* )
*
* // Combine with other loggers
* const multiLoggerLive = Logger.layer([
*   Logger.consoleLogFmt,
*   Logger.consolePretty()
* ])
* ```
*
* @since 2.0.0
* @category constructors
*/
var consoleLogFmt = /*#__PURE__*/ withConsoleLog(formatLogFmt);
/**
* A `Logger` which outputs logs using a strctured format and writes them to
* the console.
*
* For example:
* ```
* {
*   message: [ 'info', 'message' ],
*   level: 'INFO',
*   timestamp: '2025-01-03T14:25:39.666Z',
*   annotations: { key: 'value' },
*   spans: { label: 0 },
*   fiberId: '#1'
* }
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the console structured logger
* const structuredProgram = Effect.log("Hello Structured Console").pipe(
*   Effect.provide(Logger.layer([Logger.consoleStructured]))
* )
*
* // Perfect for development debugging
* const debugProgram = Effect.gen(function*() {
*   yield* Effect.log("User event", {
*     userId: 123,
*     action: "login",
*     ip: "192.168.1.1"
*   })
*   yield* Effect.logInfo("API call", {
*     endpoint: "/users",
*     method: "GET",
*     duration: 120
*   })
* }).pipe(
*   Effect.annotateLogs("requestId", "req-123"),
*   Effect.withLogSpan("authentication"),
*   Effect.provide(Logger.layer([Logger.consoleStructured]))
* )
*
* // Easy to parse and inspect object structure
* const inspectionProgram = Effect.gen(function*() {
*   yield* Effect.log("Complex data", {
*     user: { id: 1, name: "John" },
*     metadata: { source: "api", version: 2 }
*   })
* }).pipe(
*   Effect.provide(Logger.layer([Logger.consoleStructured]))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var consoleStructured = /*#__PURE__*/ withConsoleLog(formatStructured);
/**
* A `Logger` which outputs logs using a structured format serialized as JSON
* on a single line and writes them to the console.
*
* For example:
* ```
* {"message":["hello"],"level":"INFO","timestamp":"2025-01-03T14:28:57.508Z","annotations":{"key":"value"},"spans":{"label":0},"fiberId":"#1"}
* ```
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Use the console JSON logger
* const jsonProgram = Effect.log("Hello JSON Console").pipe(
*   Effect.provide(Logger.layer([Logger.consoleJson]))
* )
*
* // Perfect for production logging and log aggregation
* const productionProgram = Effect.gen(function*() {
*   yield* Effect.log("Server started", { port: 3000, env: "production" })
*   yield* Effect.logInfo("Request", {
*     method: "POST",
*     url: "/api/users",
*     body: { name: "Alice" }
*   })
*   yield* Effect.logError("Database error", {
*     error: "Connection timeout",
*     retryCount: 3
*   })
* }).pipe(
*   Effect.annotateLogs("service", "user-api"),
*   Effect.annotateLogs("version", "1.2.3"),
*   Effect.withLogSpan("request-processing"),
*   Effect.provide(Logger.layer([Logger.consoleJson]))
* )
*
* // Easy to pipe to log aggregation services
* const productionSetup = Logger.layer([
*   Logger.consoleJson, // For stdout JSON logs
*   Logger.consolePretty() // For local debugging
* ])
*
* // Ideal for containerized environments (Docker, Kubernetes)
* const containerProgram = Effect.log("Container ready", {
*   containerId: "abc123",
*   image: "myapp:latest"
* }).pipe(
*   Effect.provide(Logger.layer([Logger.consoleJson]))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var consoleJson = /*#__PURE__*/ withConsoleLog(formatJson);
/**
* A `Logger` which includes log messages as tracer span events.
*
* This logger integrates logging with distributed tracing by recording
* all log messages as events on the current trace span, making them visible
* in tracing tools like OpenTelemetry, Jaeger, or Zipkin.
*
* **Note**: This logger is included in the default set of loggers for all
* Effect programs, so log messages automatically appear as span events unless
* you override the default loggers.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Tracer logger is included by default - logs automatically become span events
* const defaultProgram = Effect.gen(function*() {
*   yield* Effect.log("This automatically becomes a span event")
*   yield* Effect.logInfo("Processing data")
* })
*
* // Explicitly combine tracer logger with other loggers
* const observabilityProgram = Effect.gen(function*() {
*   yield* Effect.log("Operation started")
*   yield* Effect.logInfo("Processing data")
*   yield* Effect.logError("Error occurred")
* }).pipe(
*   Effect.withLogSpan("data-processing"),
*   Effect.provide(Logger.layer([
*     Logger.tracerLogger,
*     Logger.consoleJson
*   ]))
* )
*
* // Perfect for correlating logs with traces in distributed systems
* const distributedProgram = Effect.gen(function*() {
*   yield* Effect.log("Step 1: Fetching user data")
*   yield* Effect.sleep("100 millis")
*   yield* Effect.log("Step 2: Processing payment")
*   yield* Effect.sleep("200 millis")
*   yield* Effect.log("Step 3: Sending confirmation")
* }).pipe(
*   Effect.withLogSpan("payment-workflow"),
*   Effect.annotateLogs("userId", "user-123"),
*   Effect.provide(Logger.layer([Logger.tracerLogger]))
* )
* ```
*
* @since 4.0.0
* @category constructors
*/
var tracerLogger = tracerLogger$1;
/**
* Creates a `Layer` which will overwrite the current set of loggers with the
* specified array of `loggers`.
*
* If the specified array of `loggers` should be _merged_ with the current set
* of loggers (instead of overwriting them), set `mergeWithExisting` to `true`.
*
* @example
* ```ts
* import { Effect, Logger } from "effect"
*
* // Single logger layer
* const JsonLoggerLive = Logger.layer([Logger.consoleJson])
*
* // Multiple loggers layer
* const MultiLoggerLive = Logger.layer([
*   Logger.consoleJson,
*   Logger.consolePretty(),
*   Logger.formatStructured
* ])
*
* // Merge with existing loggers
* const AdditionalLoggerLive = Logger.layer(
*   [Logger.consoleJson],
*   { mergeWithExisting: true }
* )
*
* // Using multiple logger formats
* const jsonLogger = Logger.consoleJson
* const prettyLogger = Logger.consolePretty()
*
* const CustomLoggerLive = Logger.layer([jsonLogger, prettyLogger])
*
* const program = Effect.log("Application started").pipe(
*   Effect.provide(CustomLoggerLive)
* )
* ```
*
* @since 4.0.0
* @category context
*/
var layer = (loggers, options) => effect(CurrentLoggers, withFiber(fnUntraced$1(function* (fiber) {
	const currentLoggers = new Set(options?.mergeWithExisting === true ? fiber.getRef(CurrentLoggers$1) : []);
	for (const logger of loggers) currentLoggers.add(isEffect(logger) ? yield* logger : logger);
	return currentLoggers;
})));
/**
* Create a Logger from another string Logger that writes to the specified file.
*
* **Example**
*
* ```ts
* import { NodeFileSystem, NodeRuntime } from "@effect/platform-node"
* import { Effect, Layer, Logger } from "effect"
*
* const fileLogger = Logger.formatJson.pipe(
*   Logger.toFile("/tmp/log.txt")
* )
* const LoggerLive = Logger.layer([fileLogger]).pipe(
*   Layer.provide(NodeFileSystem.layer)
* )
*
* Effect.log("a").pipe(
*   Effect.andThen(Effect.log("b")),
*   Effect.andThen(Effect.log("c")),
*   Effect.provide(LoggerLive),
*   NodeRuntime.runMain
* )
* ```
*
* @example
* ```ts
* import { NodeFileSystem } from "@effect/platform-node"
* import { Duration, Effect, Logger } from "effect"
*
* // Basic file logging
* const basicFileLogger = Effect.gen(function*() {
*   const fileLogger = yield* Logger.formatJson.pipe(
*     Logger.toFile("/tmp/app.log")
*   )
*
*   yield* Effect.log("Application started").pipe(
*     Effect.provide(Logger.layer([fileLogger]))
*   )
* }).pipe(
*   Effect.provide(NodeFileSystem.layer)
* )
*
* // File logger with custom batch window
* const batchedFileLogger = Effect.gen(function*() {
*   const fileLogger = yield* Logger.formatLogFmt.pipe(
*     Logger.toFile("/var/log/myapp.log", {
*       flag: "a",
*       batchWindow: Duration.seconds(5)
*     })
*   )
*
*   yield* Effect.all([
*     Effect.log("Event 1"),
*     Effect.log("Event 2"),
*     Effect.log("Event 3")
*   ]).pipe(
*     Effect.provide(Logger.layer([fileLogger]))
*   )
* }).pipe(
*   Effect.provide(NodeFileSystem.layer)
* )
*
* // Multiple loggers: console + file
* const multiLogger = Effect.gen(function*() {
*   const fileLogger = yield* Logger.formatJson.pipe(
*     Logger.toFile("/tmp/production.log")
*   )
*
*   const loggerLive = Logger.layer([
*     Logger.consolePretty(),
*     fileLogger
*   ])
*
*   yield* Effect.log("Production event").pipe(
*     Effect.provide(loggerLive)
*   )
* }).pipe(
*   Effect.provide(NodeFileSystem.layer)
* )
* ```
*
* @since 4.0.0
* @category file
*/
var toFile = /*#__PURE__*/ dual((args) => isLogger(args[0]), (self, path, options) => gen$1(function* () {
	const logFile = yield* (yield* FileSystem).open(path, {
		flag: "a+",
		...options
	});
	const encoder = new TextEncoder();
	return yield* batched(self, {
		window: options?.batchWindow ?? 1e3,
		flush: (output) => ignore(logFile.write(encoder.encode(output.join("\n") + "\n")))
	});
}));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ManagedRuntime.js
/**
* @since 2.0.0
*/
var ManagedRuntime_exports = /* @__PURE__ */ __exportAll({
	isManagedRuntime: () => isManagedRuntime,
	make: () => make$19
});
var TypeId$20 = "~effect/ManagedRuntime";
/**
* Checks if the provided argument is a `ManagedRuntime`.
*
* @since 3.9.0
* @category guards
*/
var isManagedRuntime = (input) => hasProperty(input, TypeId$20);
/**
* Convert a Layer into an ManagedRuntime, that can be used to run Effect's using
* your services.
*
* @since 2.0.0
* @category runtime class
* @example
* ```ts
* import { Console, Effect, Layer, ManagedRuntime, ServiceMap } from "effect"
*
* class Notifications extends ServiceMap.Service<Notifications, {
*   readonly notify: (message: string) => Effect.Effect<void>
* }>()("Notifications") {
*   static readonly layer = Layer.succeed(this)({
*     notify: (message) => Console.log(message)
*   })
* }
*
* async function main() {
*   const runtime = ManagedRuntime.make(Notifications.layer)
*   await runtime.runPromise(Effect.flatMap(
*     Notifications.asEffect(),
*     (_) => _.notify("Hello, world!")
*   ))
*   await runtime.dispose()
* }
*
* main()
* ```
*/
var make$19 = (layer, options) => {
	const memoMap = options?.memoMap ?? makeMemoMapUnsafe();
	const scope = makeUnsafe$9();
	let buildFiber;
	const servicesEffect = withFiber$1((fiber) => {
		if (!buildFiber) buildFiber = runIn(runFork(tap(buildWithMemoMap(layer, memoMap, scope), (services) => sync$1(() => {
			self.cachedServices = services;
		})), { scheduler: fiber.currentScheduler }), scope);
		return flatten(await_$1(buildFiber));
	});
	const self = {
		[TypeId$20]: TypeId$20,
		memoMap,
		scope,
		servicesEffect,
		cachedServices: void 0,
		services() {
			return self.cachedServices === void 0 ? runPromise(self.servicesEffect) : Promise.resolve(self.cachedServices);
		},
		dispose() {
			return runPromise(self.disposeEffect);
		},
		disposeEffect: suspend(() => {
			self.servicesEffect = die("ManagedRuntime disposed");
			self.cachedServices = void 0;
			return close(self.scope, void_$2);
		}),
		runFork(effect, options) {
			return self.cachedServices === void 0 ? runFork(provide(self, effect), options) : runForkWith(self.cachedServices)(effect, options);
		},
		runCallback(effect, options) {
			return self.cachedServices === void 0 ? runCallback(provide(self, effect), options) : runCallbackWith(self.cachedServices)(effect, options);
		},
		runSyncExit(effect) {
			return self.cachedServices === void 0 ? runSyncExit(provide(self, effect)) : runSyncExitWith(self.cachedServices)(effect);
		},
		runSync(effect) {
			return self.cachedServices === void 0 ? runSync(provide(self, effect)) : runSyncWith(self.cachedServices)(effect);
		},
		runPromiseExit(effect, options) {
			return self.cachedServices === void 0 ? runPromiseExit(provide(self, effect), options) : runPromiseExitWith(self.cachedServices)(effect, options);
		},
		runPromise(effect, options) {
			return self.cachedServices === void 0 ? runPromise(provide(self, effect), options) : runPromiseWith(self.cachedServices)(effect, options);
		}
	};
	return self;
};
function provide(managed, effect) {
	return flatMap$2(managed.servicesEffect, (services) => provideServices(effect, services));
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/matcher.js
/** @internal */
var TypeId$19 = "~effect/match/Match/Matcher";
var TypeMatcherProto = {
	[TypeId$19]: {
		_input: identity,
		_filters: identity,
		_remaining: identity,
		_result: identity,
		_return: identity
	},
	_tag: "TypeMatcher",
	add(_case) {
		return makeTypeMatcher([...this.cases, _case]);
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
function makeTypeMatcher(cases) {
	const matcher = Object.create(TypeMatcherProto);
	matcher.cases = cases;
	return matcher;
}
var ValueMatcherProto = {
	[TypeId$19]: {
		_input: identity,
		_filters: identity,
		_result: identity,
		_return: identity
	},
	_tag: "ValueMatcher",
	add(_case) {
		if (isSuccess(this.value)) return this;
		if (_case._tag === "When" && _case.guard(this.provided) === true) return makeValueMatcher(this.provided, succeed$2(_case.evaluate(this.provided)));
		else if (_case._tag === "Not" && _case.guard(this.provided) === false) return makeValueMatcher(this.provided, succeed$2(_case.evaluate(this.provided)));
		return this;
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
function makeValueMatcher(provided, value) {
	const matcher = Object.create(ValueMatcherProto);
	matcher.provided = provided;
	matcher.value = value;
	return matcher;
}
var makeWhen = (guard, evaluate) => ({
	_tag: "When",
	guard,
	evaluate
});
var makeNot = (guard, evaluate) => ({
	_tag: "Not",
	guard,
	evaluate
});
var makePredicate = (pattern) => {
	if (typeof pattern === "function") return pattern;
	else if (Array.isArray(pattern)) {
		const predicates = pattern.map(makePredicate);
		const len = predicates.length;
		return (u) => {
			if (!Array.isArray(u)) return false;
			for (let i = 0; i < len; i++) if (predicates[i](u[i]) === false) return false;
			return true;
		};
	} else if (pattern !== null && typeof pattern === "object") {
		const keysAndPredicates = Object.entries(pattern).map(([k, p]) => [k, makePredicate(p)]);
		const len = keysAndPredicates.length;
		return (u) => {
			if (typeof u !== "object" || u === null) return false;
			for (let i = 0; i < len; i++) {
				const [key, predicate] = keysAndPredicates[i];
				if (!(key in u) || predicate(u[key]) === false) return false;
			}
			return true;
		};
	}
	return (u) => u === pattern;
};
var makeOrPredicate = (patterns) => {
	const predicates = patterns.map(makePredicate);
	const len = predicates.length;
	return (u) => {
		for (let i = 0; i < len; i++) if (predicates[i](u) === true) return true;
		return false;
	};
};
var makeAndPredicate = (patterns) => {
	const predicates = patterns.map(makePredicate);
	const len = predicates.length;
	return (u) => {
		for (let i = 0; i < len; i++) if (predicates[i](u) === false) return false;
		return true;
	};
};
/** @internal */
var type$1 = () => makeTypeMatcher([]);
/** @internal */
var value$1 = (i) => makeValueMatcher(i, fail$3(i));
/** @internal */
var valueTags$1 = /*#__PURE__*/ dual(2, (input, fields) => {
	return tagsExhaustive$1(fields)(makeTypeMatcher([]))(input);
});
/** @internal */
var typeTags$1 = () => (fields) => {
	const match = tagsExhaustive$1(fields)(makeTypeMatcher([]));
	return (input) => match(input);
};
/** @internal */
var withReturnType$1 = () => (self) => self;
/** @internal */
var when$1 = (pattern, f) => (self) => self.add(makeWhen(makePredicate(pattern), f));
/** @internal */
var whenOr$1 = (...args) => (self) => {
	const onMatch = args[args.length - 1];
	const patterns = args.slice(0, -1);
	return self.add(makeWhen(makeOrPredicate(patterns), onMatch));
};
/** @internal */
var whenAnd$1 = (...args) => (self) => {
	const onMatch = args[args.length - 1];
	const patterns = args.slice(0, -1);
	return self.add(makeWhen(makeAndPredicate(patterns), onMatch));
};
/** @internal */
var discriminator$1 = (field) => (...pattern) => {
	const f = pattern[pattern.length - 1];
	const values = pattern.slice(0, -1);
	const pred = values.length === 1 ? (_) => _ != null && _[field] === values[0] : (_) => _ != null && values.includes(_[field]);
	return (self) => self.add(makeWhen(pred, f));
};
/** @internal */
var discriminatorStartsWith$1 = (field) => (pattern, f) => {
	const pred = (_) => _ != null && typeof _[field] === "string" && _[field].startsWith(pattern);
	return (self) => self.add(makeWhen(pred, f));
};
/** @internal */
var discriminators$1 = (field) => (fields) => {
	const predicate = makeWhen((arg) => arg != null && arg[field] in fields, (data) => fields[data[field]](data));
	return (self) => self.add(predicate);
};
/** @internal */
var discriminatorsExhaustive$1 = (field) => (fields) => {
	const addCases = discriminators$1(field)(fields);
	return (matcher) => exhaustive$1(addCases(matcher));
};
/** @internal */
var tag$1 = /*#__PURE__*/ discriminator$1("_tag");
/** @internal */
var tagStartsWith$1 = /*#__PURE__*/ discriminatorStartsWith$1("_tag");
/** @internal */
var tags$1 = /*#__PURE__*/ discriminators$1("_tag");
/** @internal */
var tagsExhaustive$1 = /*#__PURE__*/ discriminatorsExhaustive$1("_tag");
/** @internal */
var not$1 = (pattern, f) => (self) => self.add(makeNot(makePredicate(pattern), f));
/** @internal */
var nonEmptyString$1 = (u) => typeof u === "string" && u.length > 0;
/** @internal */
var is$1 = (...literals) => {
	const len = literals.length;
	return (u) => {
		for (let i = 0; i < len; i++) if (u === literals[i]) return true;
		return false;
	};
};
/** @internal */
var any$1 = () => true;
/** @internal */
var defined$1 = (u) => u !== void 0 && u !== null;
/** @internal */
var instanceOf$1 = (constructor) => (u) => u instanceof constructor;
/** @internal */
var orElse$1 = (f) => (self) => {
	const toResult = result$1(self);
	if (isResult(toResult)) return toResult._tag === "Success" ? toResult.success : f(toResult.failure);
	return (input) => {
		const a = toResult(input);
		return isSuccess(a) ? a.success : f(a.failure);
	};
};
/** @internal */
var orElseAbsurd$1 = (self) => orElse$1(() => {
	throw new Error("effect/Match/orElseAbsurd: absurd");
})(self);
/** @internal */
var result$1 = (self) => {
	if (self._tag === "ValueMatcher") return self.value;
	const len = self.cases.length;
	if (len === 1) {
		const _case = self.cases[0];
		return (input) => {
			if (_case._tag === "When" && _case.guard(input) === true) return succeed$2(_case.evaluate(input));
			else if (_case._tag === "Not" && _case.guard(input) === false) return succeed$2(_case.evaluate(input));
			return fail$3(input);
		};
	}
	return (input) => {
		for (let i = 0; i < len; i++) {
			const _case = self.cases[i];
			if (_case._tag === "When" && _case.guard(input) === true) return succeed$2(_case.evaluate(input));
			else if (_case._tag === "Not" && _case.guard(input) === false) return succeed$2(_case.evaluate(input));
		}
		return fail$3(input);
	};
};
/** @internal */
var option$1 = (self) => {
	const toResult = result$1(self);
	if (isResult(toResult)) return match$2(toResult, {
		onFailure: () => none(),
		onSuccess: some$2
	});
	return (input) => match$2(toResult(input), {
		onFailure: () => none(),
		onSuccess: some$2
	});
};
var getExhaustiveAbsurdErrorMessage = "effect/match/Match/exhaustive: absurd";
/** @internal */
var exhaustive$1 = (self) => {
	const toResult = result$1(self);
	if (isResult(toResult)) {
		if (isSuccess(toResult)) return toResult.success;
		throw new Error(getExhaustiveAbsurdErrorMessage);
	}
	return (u) => {
		const result = toResult(u);
		if (isSuccess(result)) return result.success;
		throw new Error(getExhaustiveAbsurdErrorMessage);
	};
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Match.js
/**
* The `effect/match` module provides a type-safe pattern matching system for
* TypeScript. Inspired by functional programming, it simplifies conditional
* logic by replacing verbose if/else or switch statements with a structured and
* expressive API.
*
* This module supports matching against types, values, and discriminated unions
* while enforcing exhaustiveness checking to ensure all cases are handled.
*
* Although pattern matching is not yet a native JavaScript feature,
* `effect/match` offers a reliable implementation that is available today.
*
* **How Pattern Matching Works**
*
* Pattern matching follows a structured process:
*
* - **Creating a matcher**: Define a `Matcher` that operates on either a
*   specific `Match.type` or `Match.value`.
*
* - **Defining patterns**: Use combinators such as `Match.when`, `Match.not`,
*   and `Match.tag` to specify matching conditions.
*
* - **Completing the match**: Apply a finalizer such as `Match.exhaustive`,
*   `Match.orElse`, or `Match.option` to determine how unmatched cases should
*   be handled.
*
* @since 4.0.0
*/
var Match_exports = /* @__PURE__ */ __exportAll({
	any: () => any,
	bigint: () => bigint,
	boolean: () => boolean$1,
	date: () => date,
	defined: () => defined,
	discriminator: () => discriminator,
	discriminatorStartsWith: () => discriminatorStartsWith,
	discriminators: () => discriminators,
	discriminatorsExhaustive: () => discriminatorsExhaustive,
	exhaustive: () => exhaustive,
	instanceOf: () => instanceOf,
	instanceOfUnsafe: () => instanceOfUnsafe,
	is: () => is,
	nonEmptyString: () => nonEmptyString,
	not: () => not,
	null: () => _null,
	number: () => number,
	option: () => option,
	orElse: () => orElse,
	orElseAbsurd: () => orElseAbsurd,
	record: () => record,
	result: () => result,
	string: () => string$1,
	symbol: () => symbol,
	tag: () => tag,
	tagStartsWith: () => tagStartsWith,
	tags: () => tags,
	tagsExhaustive: () => tagsExhaustive,
	type: () => type,
	typeTags: () => typeTags,
	undefined: () => _undefined,
	value: () => value,
	valueTags: () => valueTags,
	when: () => when,
	whenAnd: () => whenAnd,
	whenOr: () => whenOr,
	withReturnType: () => withReturnType
});
/**
* Creates a matcher for a specific type.
*
* **Details**
*
* This function defines a `Matcher` that operates on a given type, allowing you
* to specify conditions for handling different cases. Once the matcher is
* created, you can use pattern-matching functions like {@link when} to define
* how different values should be processed.
*
* @example (Matching Numbers and Strings)
*
* ```ts
* import { Match } from "effect"
*
* // Create a matcher for values that are either strings or numbers
* //
* //      ┌─── (u: string | number) => string
* //      ▼
* const match = Match.type<string | number>().pipe(
*   // Match when the value is a number
*   Match.when(Match.number, (n) => `number: ${n}`),
*   // Match when the value is a string
*   Match.when(Match.string, (s) => `string: ${s}`),
*   // Ensure all possible cases are handled
*   Match.exhaustive
* )
*
* console.log(match(0))
* // Output: "number: 0"
*
* console.log(match("hello"))
* // Output: "string: hello"
* ```
*
* @see {@link value} for creating a matcher from a specific value.
*
* @category Creating a matcher
* @since 4.0.0
*/
var type = type$1;
/**
* Creates a matcher from a specific value.
*
* **Details**
*
* This function allows you to define a `Matcher` directly from a given value,
* rather than from a type. This is useful when working with known values,
* enabling structured pattern matching on objects, primitives, or any data
* structure.
*
* Once the matcher is created, you can use pattern-matching functions like
* {@link when} to define how different cases should be handled.
*
* @example (Matching an Object by Property)
*
* ```ts
* import { Match } from "effect"
*
* const input = { name: "John", age: 30 }
*
* // Create a matcher for the specific object
* const result = Match.value(input).pipe(
*   // Match when the 'name' property is "John"
*   Match.when(
*     { name: "John" },
*     (user) => `${user.name} is ${user.age} years old`
*   ),
*   // Provide a fallback if no match is found
*   Match.orElse(() => "Oh, not John")
* )
*
* console.log(result)
* // Output: "John is 30 years old"
* ```
*
* @see {@link type} for creating a matcher from a specific type.
*
* @category Creating a matcher
* @since 4.0.0
*/
var value = value$1;
/**
* Creates a match function for a specific value with discriminated union handling.
*
* This function provides a convenient way to pattern match on discriminated unions
* by providing an object that maps each `_tag` value to its corresponding handler.
* It's similar to a switch statement but with better type safety and exhaustiveness checking.
*
* @example
* ```ts
* import { Match } from "effect"
*
* type Status = { readonly _tag: "Success"; readonly data: string }
*
* const success: Status = { _tag: "Success", data: "Hello" }
*
* // Simple valueTags usage
* const message = Match.valueTags(success, {
*   Success: (result) => `Success: ${result.data}`
* })
*
* console.log(message) // "Success: Hello"
* ```
*
* @category Creating a matcher
* @since 4.0.0
*/
var valueTags = valueTags$1;
/**
* Creates a type-safe match function for discriminated unions based on `_tag` field.
*
* This function allows you to define exhaustive pattern matching for discriminated unions
* by providing handlers for each possible `_tag` value. It ensures type safety and
* can optionally enforce a specific return type across all branches.
*
* @example
* ```ts
* import { Match } from "effect"
*
* type Result =
*   | { readonly _tag: "Success"; readonly data: string }
*   | { readonly _tag: "Error"; readonly message: string }
*   | { readonly _tag: "Loading" }
*
* // Create a matcher with specific return type
* const formatResult = Match.typeTags<Result, string>()({
*   Success: (result) => `Data: ${result.data}`,
*   Error: (result) => `Error: ${result.message}`,
*   Loading: () => "Loading..."
* })
*
* console.log(formatResult({ _tag: "Success", data: "Hello World" }))
* // Output: "Data: Hello World"
*
* console.log(formatResult({ _tag: "Error", message: "Network failed" }))
* // Output: "Error: Network failed"
*
* // Create a matcher with inferred return type
* const processResult = Match.typeTags<Result>()({
*   Success: (result) => ({ type: "ok", value: result.data }),
*   Error: (result) => ({ type: "error", error: result.message }),
*   Loading: () => ({ type: "pending" })
* })
*
* console.log(processResult({ _tag: "Loading" }))
* // Output: { type: "pending" }
* ```
*
* @category Creating a matcher
* @since 4.0.0
*/
var typeTags = typeTags$1;
/**
* Ensures that all branches of a matcher return a specific type.
*
* **Details**
*
* This function enforces a consistent return type across all pattern-matching
* branches. By specifying a return type, TypeScript will check that every
* matching condition produces a value of the expected type.
*
* **Important:** This function must be the first step in the matcher pipeline.
* If used later, TypeScript will not enforce type consistency correctly.
*
* @example (Validating Return Type Consistency)
*
* ```ts
* import { Match } from "effect"
*
* const match = Match.type<{ a: number } | { b: string }>().pipe(
*   // Ensure all branches return a string
*   Match.withReturnType<string>(),
*   // ❌ Type error: 'number' is not assignable to type 'string'
*   // @ts-expect-error
*   Match.when({ a: Match.number }, (_) => _.a),
*   // ✅ Correct: returns a string
*   Match.when({ b: Match.string }, (_) => _.b),
*   Match.exhaustive
* )
* ```
*
* @category utils
* @since 4.0.0
*/
var withReturnType = withReturnType$1;
/**
* Defines a condition for matching values.
*
* **Details**
*
* This function enables pattern matching by checking whether a given value
* satisfies a condition. It supports both direct value comparisons and
* predicate functions. If the condition is met, the associated function is
* executed.
*
* This function is useful when defining matchers that need to check for
* specific values or apply logical conditions to determine a match. It works
* well with structured objects and primitive types.
*
* @example (Matching with Values and Predicates)
*
* ```ts
* import { Match } from "effect"
*
* // Create a matcher for objects with an "age" property
* const match = Match.type<{ age: number }>().pipe(
*   // Match when age is greater than 18
*   Match.when(
*     { age: (age: number) => age > 18 },
*     (user: { age: number }) => `Age: ${user.age}`
*   ),
*   // Match when age is exactly 18
*   Match.when({ age: 18 }, () => "You can vote"),
*   // Fallback case for all other ages
*   Match.orElse((user: { age: number }) => `${user.age} is too young`)
* )
*
* console.log(match({ age: 20 }))
* // Output: "Age: 20"
*
* console.log(match({ age: 18 }))
* // Output: "You can vote"
*
* console.log(match({ age: 4 }))
* // Output: "4 is too young"
* ```
*
* @see {@link whenOr} Use this when multiple patterns should match in a single
* condition.
* @see {@link whenAnd} Use this when a value must match all provided patterns.
* @see {@link orElse} Provides a fallback when no patterns match.
*
* @category Defining patterns
* @since 4.0.0
*/
var when = when$1;
/**
* Matches one of multiple patterns in a single condition.
*
* **Details**
*
* This function allows defining a condition where a value matches any of the
* provided patterns. If a match is found, the associated function is executed.
* It simplifies cases where multiple patterns share the same handling logic.
*
* Unlike {@link when}, which requires separate conditions for each pattern,
* this function enables combining them into a single statement, making the
* matcher more concise.
*
* @example
* ```ts
* import { Match } from "effect"
*
* type ErrorType =
*   | { readonly _tag: "NetworkError"; readonly message: string }
*   | { readonly _tag: "TimeoutError"; readonly duration: number }
*   | { readonly _tag: "ValidationError"; readonly field: string }
*
* const handleError = Match.type<ErrorType>().pipe(
*   Match.whenOr(
*     { _tag: "NetworkError" },
*     { _tag: "TimeoutError" },
*     () => "Retry the request"
*   ),
*   Match.when({ _tag: "ValidationError" }, (_) => `Invalid field: ${_.field}`),
*   Match.exhaustive
* )
*
* console.log(handleError({ _tag: "NetworkError", message: "No connection" }))
* // Output: "Retry the request"
*
* console.log(handleError({ _tag: "ValidationError", field: "email" }))
* // Output: "Invalid field: email"
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var whenOr = whenOr$1;
/**
* Matches a value that satisfies all provided patterns.
*
* **Details**
*
* This function allows defining a condition where a value must match all the
* given patterns simultaneously. If the value satisfies every pattern, the
* associated function is executed.
*
* Unlike {@link when}, which matches a single pattern at a time, this function
* ensures that multiple conditions are met before executing the callback. It is
* useful when checking for values that need to fulfill multiple criteria at
* once.
*
* @example
* ```ts
* import { Match } from "effect"
*
* type User = { readonly age: number; readonly role: "admin" | "user" }
*
* const checkUser = Match.type<User>().pipe(
*   Match.whenAnd(
*     { age: (n) => n >= 18 },
*     { role: "admin" },
*     () => "Admin access granted"
*   ),
*   Match.orElse(() => "Access denied")
* )
*
* console.log(checkUser({ age: 20, role: "admin" }))
* // Output: "Admin access granted"
*
* console.log(checkUser({ age: 20, role: "user" }))
* // Output: "Access denied"
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var whenAnd = whenAnd$1;
/**
* Matches values based on a specified discriminant field.
*
* **Details**
*
* This function is used to define pattern matching on objects that follow a
* **discriminated union** structure, where a specific field (e.g., `type`,
* `kind`, `_tag`) determines the variant of the object. It allows matching
* multiple values of the discriminant and provides a function to handle the
* matched cases.
*
* @example
* ```ts
* import { Match, pipe } from "effect"
*
* const match = pipe(
*   Match.type<
*     { type: "A"; a: string } | { type: "B"; b: number } | {
*       type: "C"
*       c: boolean
*     }
*   >(),
*   Match.discriminator("type")("A", "B", (_) => `A or B: ${_.type}`),
*   Match.discriminator("type")("C", (_) => `C(${_.c})`),
*   Match.exhaustive
* )
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var discriminator = discriminator$1;
/**
* Matches values where a specified field starts with a given prefix.
*
* **Details**
*
* This function is useful for working with discriminated unions where the
* discriminant field follows a hierarchical or namespaced structure. It allows
* you to match values based on whether the specified field starts with a given
* prefix, making it easier to handle grouped cases.
*
* Instead of checking for exact matches, this function lets you match values
* that share a common prefix. For example, if your discriminant field contains
* hierarchical names like `"A"`, `"A.A"`, and `"B"`, you can match all values
* starting with `"A"` using a single rule.
*
* @example
* ```ts
* import { Match, pipe } from "effect"
*
* const match = pipe(
*   Match.type<{ type: "A" } | { type: "B" } | { type: "A.A" } | {}>(),
*   Match.discriminatorStartsWith("type")("A", (_) => 1 as const),
*   Match.discriminatorStartsWith("type")("B", (_) => 2 as const),
*   Match.orElse((_) => 3 as const)
* )
*
* console.log(match({ type: "A" })) // 1
* console.log(match({ type: "B" })) // 2
* console.log(match({ type: "A.A" })) // 1
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var discriminatorStartsWith = discriminatorStartsWith$1;
/**
* Matches values based on a field that serves as a discriminator, mapping each
* possible value to a corresponding handler.
*
* **Details**
*
* This function simplifies working with discriminated unions by letting you
* define a set of handlers for each possible value of a given field. Instead of
* chaining multiple calls to {@link discriminator}, this function allows
* defining all possible cases at once using an object where the keys are the
* possible values of the field, and the values are the corresponding handler
* functions.
*
* @example
* ```ts
* import { Match, pipe } from "effect"
*
* const match = pipe(
*   Match.type<
*     { type: "A"; a: string } | { type: "B"; b: number } | {
*       type: "C"
*       c: boolean
*     }
*   >(),
*   Match.discriminators("type")({
*     A: (a) => a.a,
*     B: (b) => b.b,
*     C: (c) => c.c
*   }),
*   Match.exhaustive
* )
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var discriminators = discriminators$1;
/**
* Matches values based on a discriminator field and **ensures all cases are
* handled**.
*
* **Details*+
*
* This function is similar to {@link discriminators}, but **requires that all
* possible cases** are explicitly handled. It is useful when working with
* discriminated unions, where a specific field (e.g., `"type"`) determines the
* shape of an object. Each possible value of the field must have a
* corresponding handler, ensuring **exhaustiveness checking** at compile time.
*
* This function **does not require** `Match.exhaustive` at the end of the
* pipeline because it enforces exhaustiveness by design.
*
* @example
* ```ts
* import { Match, pipe } from "effect"
*
* const match = pipe(
*   Match.type<
*     { type: "A"; a: string } | { type: "B"; b: number } | {
*       type: "C"
*       c: boolean
*     }
*   >(),
*   Match.discriminatorsExhaustive("type")({
*     A: (a) => a.a,
*     B: (b) => b.b,
*     C: (c) => c.c
*   })
* )
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var discriminatorsExhaustive = discriminatorsExhaustive$1;
/**
* The `Match.tag` function allows pattern matching based on the `_tag` field in
* a [Discriminated Union](https://www.typescriptlang.org/docs/handbook/typescript-in-5-minutes-func.html#discriminated-unions).
* You can specify multiple tags to match within a single pattern.
*
* **Note**
*
* The `Match.tag` function relies on the convention within the Effect ecosystem
* of naming the tag field as `"_tag"`. Ensure that your discriminated unions
* follow this naming convention for proper functionality.
*
* @example (Matching a Discriminated Union by Tag)
*
* ```ts
* import { Match } from "effect"
*
* type Event =
*   | { readonly _tag: "fetch" }
*   | { readonly _tag: "success"; readonly data: string }
*   | { readonly _tag: "error"; readonly error: Error }
*   | { readonly _tag: "cancel" }
*
* const match = Match.type<Event>().pipe(
*   // Match either "fetch" or "success"
*   Match.tag("fetch", "success", () => `Ok!`),
*   // Match "error" and extract the error message
*   Match.tag("error", (event) => `Error: ${event.error.message}`),
*   // Match "cancel"
*   Match.tag("cancel", () => "Cancelled"),
*   Match.exhaustive
* )
*
* console.log(match({ _tag: "success", data: "Hello" }))
* // Output: "Ok!"
*
* console.log(match({ _tag: "error", error: new Error("Oops!") }))
* // Output: "Error: Oops!"
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var tag = tag$1;
/**
* Matches values where the `_tag` field starts with a given prefix.
*
* **Details**
*
* This function allows you to match on values in a **discriminated union**
* based on whether the `_tag` field starts with a specified prefix. It is
* useful for handling hierarchical or namespaced tags, where multiple related
* cases share a common prefix.
*
* @example
```ts
* import { pipe } from "effect"
* import { Match } from "effect"
*
* const match = pipe(
*   Match.type<{ _tag: "A" } | { _tag: "B" } | { _tag: "A.A" } | {}>(),
*   Match.tagStartsWith("A", (_) => 1 as const),
*   Match.tagStartsWith("B", (_) => 2 as const),
*   Match.orElse((_) => 3 as const)
* )
*
* console.log(match({ _tag: "A" })) // 1
* console.log(match({ _tag: "B" })) // 2
* console.log(match({ _tag: "A.A" })) // 1
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var tagStartsWith = tagStartsWith$1;
/**
* Matches values based on their `_tag` field, mapping each tag to a
* corresponding handler.
*
* **Details**
*
* This function provides a way to handle discriminated unions by mapping `_tag`
* values to specific functions. Each handler receives the matched value and
* returns a transformed result. If all possible tags are handled, you can
* enforce exhaustiveness using `Match.exhaustive` to ensure no case is missed.
*
* @example
* ```ts
* import { Match, pipe } from "effect"
*
* const match = pipe(
*   Match.type<
*     { _tag: "A"; a: string } | { _tag: "B"; b: number } | {
*       _tag: "C"
*       c: boolean
*     }
*   >(),
*   Match.tags({
*     A: (a) => a.a,
*     B: (b) => b.b,
*     C: (c) => c.c
*   }),
*   Match.exhaustive
* )
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var tags = tags$1;
/**
* Matches values based on their `_tag` field and requires handling of all
* possible cases.
*
* **Details**
*
* This function is designed for **discriminated unions** where every possible
* `_tag` value must have a corresponding handler. Unlike {@link tags}, this
* function ensures **exhaustiveness**, meaning all cases must be explicitly
* handled. If a `_tag` value is missing from the mapping, TypeScript will
* report an error.
*
* @example
* ```ts
* import { Match, pipe } from "effect"
*
* const match = pipe(
*   Match.type<
*     { _tag: "A"; a: string } | { _tag: "B"; b: number } | {
*       _tag: "C"
*       c: boolean
*     }
*   >(),
*   Match.tagsExhaustive({
*     A: (a) => a.a,
*     B: (b) => b.b,
*     C: (c) => c.c
*   })
* )
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var tagsExhaustive = tagsExhaustive$1;
/**
* Excludes a specific value from matching while allowing all others.
*
* **Details**
*
* This function is useful when you need to **handle all values except one or
* more specific cases**. Instead of listing all possible matches manually, this
* function simplifies the logic by allowing you to specify values to exclude.
* Any excluded value will bypass the provided function and continue matching
* through other cases.
*
* @example (Ignoring a Specific Value)
*
* ```ts
* import { Match } from "effect"
*
* // Create a matcher for string or number values
* const match = Match.type<string | number>().pipe(
*   // Match any value except "hi", returning "ok"
*   Match.not("hi", () => "ok"),
*   // Fallback case for when the value is "hi"
*   Match.orElse(() => "fallback")
* )
*
* console.log(match("hello"))
* // Output: "ok"
*
* console.log(match("hi"))
* // Output: "fallback"
* ```
*
* @category Defining patterns
* @since 4.0.0
*/
var not = not$1;
/**
* Matches non-empty strings.
*
* This predicate matches any string that contains at least one character,
* effectively filtering out empty strings ("").
*
* @example
* ```ts
* import { Match } from "effect"
*
* const processInput = Match.type<string>()
*   .pipe(
*     Match.when(Match.nonEmptyString, (str) => `Valid input: ${str}`),
*     Match.orElse(() => "Input cannot be empty")
*   )
*
* console.log(processInput("hello"))
* // Output: "Valid input: hello"
*
* console.log(processInput(""))
* // Output: "Input cannot be empty"
*
* console.log(processInput("   "))
* // Output: "Valid input:    " (whitespace-only strings are considered non-empty)
* ```
*
* @category Predicates
* @since 4.0.0
*/
var nonEmptyString = nonEmptyString$1;
/**
* Matches a specific set of literal values (e.g., `Match.is("a", 42, true)`).
*
* This function creates a predicate that matches any of the provided literal values.
* It's useful for matching against multiple specific values in a single pattern.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const handleStatus = Match.type<string | number>()
*   .pipe(
*     Match.when(Match.is("success", "ok", 200), () => "Operation successful"),
*     Match.when(Match.is("error", "failed", 500), () => "Operation failed"),
*     Match.when(Match.is(0, false, null), () => "Falsy value"),
*     Match.orElse((value) => `Unknown status: ${value}`)
*   )
*
* console.log(handleStatus("success"))
* // Output: "Operation successful"
*
* console.log(handleStatus(200))
* // Output: "Operation successful"
*
* console.log(handleStatus("failed"))
* // Output: "Operation failed"
*
* console.log(handleStatus(0))
* // Output: "Falsy value"
*
* console.log(handleStatus("pending"))
* // Output: "Unknown status: pending"
* ```
*
* @category Predicates
* @since 4.0.0
*/
var is = is$1;
/**
* Matches values of type `string`.
*
* This predicate refines unknown values to strings, allowing pattern matching
* on string types. It's commonly used in type-based matchers to handle string cases.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const processValue = Match.type<string | number | boolean>().pipe(
*   Match.when(Match.string, (str) => `String: ${str.toUpperCase()}`),
*   Match.when(Match.number, (num) => `Number: ${num * 2}`),
*   Match.when(Match.boolean, (bool) => `Boolean: ${bool ? "yes" : "no"}`),
*   Match.exhaustive
* )
*
* console.log(processValue("hello")) // "String: HELLO"
* console.log(processValue(42)) // "Number: 84"
* console.log(processValue(true)) // "Boolean: yes"
* ```
*
* @category predicates
* @since 4.0.0
*/
var string$1 = isString;
/**
* Matches values of type `number`.
*
* This predicate refines unknown values to numbers, allowing pattern matching
* on numeric types. It matches all number values including integers, floats,
* `Infinity`, `-Infinity`, and `NaN`.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const categorizeNumber = Match.type<unknown>().pipe(
*   Match.when(Match.number, (num) => {
*     if (Number.isNaN(num)) return "Not a number"
*     if (!Number.isFinite(num)) return "Infinite"
*     if (Number.isInteger(num)) return `Integer: ${num}`
*     return `Float: ${num.toFixed(2)}`
*   }),
*   Match.orElse(() => "Not a number type")
* )
*
* console.log(categorizeNumber(42)) // "Integer: 42"
* console.log(categorizeNumber(3.14)) // "Float: 3.14"
* console.log(categorizeNumber(NaN)) // "Not a number"
* console.log(categorizeNumber("hello")) // "Not a number type"
* ```
*
* @category predicates
* @since 4.0.0
*/
var number = isNumber;
/**
* Matches any value without restrictions.
*
* This predicate matches absolutely any value, including `undefined`, `null`,
* objects, primitives, functions, etc. It's useful as a catch-all pattern
* or when you need to match any remaining cases.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const describeValue = Match.type<unknown>()
*   .pipe(
*     Match.when(Match.string, (str) => `String: ${str}`),
*     Match.when(Match.number, (num) => `Number: ${num}`),
*     Match.when(Match.boolean, (bool) => `Boolean: ${bool}`),
*     Match.when(Match.any, (value) => `Other: ${typeof value}`),
*     Match.exhaustive
*   )
*
* console.log(describeValue("hello"))
* // Output: "String: hello"
*
* console.log(describeValue(42))
* // Output: "Number: 42"
*
* console.log(describeValue([1, 2, 3]))
* // Output: "Other: object"
*
* console.log(describeValue(null))
* // Output: "Other: object"
* ```
*
* @category Predicates
* @since 4.0.0
*/
var any = any$1;
/**
* Matches any defined (non-null and non-undefined) value.
*
* This predicate matches values that are neither `null` nor `undefined`,
* effectively filtering out nullish values while preserving all other types.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const processValue = Match.type<string | number | null | undefined>()
*   .pipe(
*     Match.when(Match.defined, (value) => `Defined value: ${value}`),
*     Match.orElse(() => "Value is null or undefined")
*   )
*
* console.log(processValue("hello"))
* // Output: "Defined value: hello"
*
* console.log(processValue(42))
* // Output: "Defined value: 42"
*
* console.log(processValue(0))
* // Output: "Defined value: 0"
*
* console.log(processValue(""))
* // Output: "Defined value: "
*
* console.log(processValue(null))
* // Output: "Value is null or undefined"
*
* console.log(processValue(undefined))
* // Output: "Value is null or undefined"
* ```
*
* @category Predicates
* @since 4.0.0
*/
var defined = defined$1;
/**
* Matches values of type `boolean`.
*
* This predicate refines unknown values to booleans, allowing pattern matching
* on boolean types. It only matches the primitive boolean values `true` and `false`.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const describeTruthiness = Match.type<unknown>().pipe(
*   Match.when(
*     Match.boolean,
*     (bool) => bool ? "Definitely true" : "Definitely false"
*   ),
*   Match.when(0, () => "Falsy number"),
*   Match.when("", () => "Empty string"),
*   Match.when(Match.null, () => "Null value"),
*   Match.orElse(() => "Some other truthy value")
* )
*
* console.log(describeTruthiness(true)) // "Definitely true"
* console.log(describeTruthiness(false)) // "Definitely false"
* console.log(describeTruthiness(0)) // "Falsy number"
* console.log(describeTruthiness(1)) // "Some other truthy value"
* ```
*
* @category predicates
* @since 4.0.0
*/
var boolean$1 = isBoolean;
var _undefined = isUndefined;
var _null = isNull;
/**
* Matches values of type `bigint`.
*
* This predicate refines unknown values to bigints, allowing pattern matching
* on bigint types. BigInts are used for representing integers with arbitrary precision.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const processLargeNumber = Match.type<unknown>().pipe(
*   Match.when(Match.bigint, (big) => {
*     if (big > 9007199254740991n) {
*       return `Large integer: ${big.toString()}`
*     }
*     return `BigInt: ${big.toString()}`
*   }),
*   Match.when(Match.number, (num) => `Regular number: ${num}`),
*   Match.orElse(() => "Not a numeric type")
* )
*
* console.log(processLargeNumber(123n)) // "BigInt: 123"
* console.log(processLargeNumber(9007199254740992n)) // "Large integer: 9007199254740992"
* console.log(processLargeNumber(123)) // "Regular number: 123"
* console.log(processLargeNumber("123")) // "Not a numeric type"
* ```
*
* @category predicates
* @since 4.0.0
*/
var bigint = isBigInt$1;
/**
* Matches values of type `symbol`.
*
* This predicate refines unknown values to symbols, allowing pattern matching
* on symbol types. Symbols are unique identifiers that are often used as
* object keys or for creating private properties.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const mySymbol = Symbol("my-symbol")
* const globalSymbol = Symbol.for("global-symbol")
*
* const handleSymbol = Match.type<unknown>().pipe(
*   Match.when(Match.symbol, (sym) => {
*     const description = sym.description
*     if (description) {
*       return `Symbol with description: ${description}`
*     }
*     return "Symbol without description"
*   }),
*   Match.orElse(() => "Not a symbol")
* )
*
* console.log(handleSymbol(mySymbol)) // "Symbol with description: my-symbol"
* console.log(handleSymbol(Symbol())) // "Symbol without description"
* console.log(handleSymbol("string")) // "Not a symbol"
* ```
*
* @category predicates
* @since 4.0.0
*/
var symbol = isSymbol$1;
/**
* Matches values that are instances of `Date`.
*
* This predicate refines unknown values to Date instances, allowing pattern
* matching on Date objects. It only matches actual Date instances, not
* date strings or timestamps.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const processDateValue = Match.type<unknown>().pipe(
*   Match.when(Match.date, (date) => {
*     if (isNaN(date.getTime())) {
*       return "Invalid date"
*     }
*     return `Date: ${date.toISOString().split("T")[0]}`
*   }),
*   Match.when(Match.string, (str) => `Date string: ${str}`),
*   Match.when(
*     Match.number,
*     (num) => `Timestamp: ${new Date(num).toISOString()}`
*   ),
*   Match.orElse(() => "Not a date-related value")
* )
*
* console.log(processDateValue(new Date("2024-01-01"))) // "Date: 2024-01-01"
* console.log(processDateValue(new Date("invalid"))) // "Invalid date"
* console.log(processDateValue("2024-01-01")) // "Date string: 2024-01-01"
* console.log(processDateValue(1704067200000)) // "Timestamp: 2024-01-01T00:00:00.000Z"
* ```
*
* @category predicates
* @since 4.0.0
*/
var date = isDate;
/**
* Matches objects where keys are `string` or `symbol` and values are `unknown`.
*
* This predicate refines unknown values to record objects, allowing pattern
* matching on plain objects. It excludes arrays, functions, dates, and other
* special object types, matching only plain objects and object literals.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const analyzeValue = Match.type<unknown>().pipe(
*   Match.when(Match.record, (obj) => {
*     const keys = Object.keys(obj)
*     const valueCount = keys.length
*     return `Object with ${valueCount} properties: [${keys.join(", ")}]`
*   }),
*   Match.when(
*     Match.instanceOf(Array),
*     (arr) => `Array with ${arr.length} items`
*   ),
*   Match.when(Match.date, () => "Date object"),
*   Match.orElse(() => "Not an object")
* )
*
* console.log(analyzeValue({ name: "Alice", age: 30 }))
* // "Object with 2 properties: [name, age]"
* console.log(analyzeValue([1, 2, 3]))
* // "Array with 3 items"
* console.log(analyzeValue(new Date()))
* // "Date object"
* console.log(analyzeValue("hello"))
* // "Not an object"
* ```
*
* @category predicates
* @since 4.0.0
*/
var record = isObject;
/**
* Matches instances of a given class.
*
* This predicate checks if a value is an instance of the specified constructor,
* providing type-safe matching for class instances and built-in objects.
*
* @example
* ```ts
* import { Match } from "effect"
*
* class CustomError extends Error {
*   constructor(message: string, public code: number) {
*     super(message)
*   }
* }
*
* const handleValue = Match.type<unknown>()
*   .pipe(
*     Match.when(
*       Match.instanceOf(CustomError),
*       (err) => `Custom error: ${err.message} (code: ${err.code})`
*     ),
*     Match.when(
*       Match.instanceOf(Error),
*       (err) => `Standard error: ${err.message}`
*     ),
*     Match.when(Match.instanceOf(Date), (date) => `Date: ${date.toISOString()}`),
*     Match.when(
*       Match.instanceOf(Array),
*       (arr) => `Array with ${arr.length} items`
*     ),
*     Match.orElse((value) => `Other: ${typeof value}`)
*   )
*
* console.log(handleValue(new CustomError("Failed", 404)))
* // Output: "Custom error: Failed (code: 404)"
*
* console.log(handleValue(new Error("Generic error")))
* // Output: "Standard error: Generic error"
*
* console.log(handleValue(new Date()))
* // Output: "Date: 2024-01-01T00:00:00.000Z"
*
* console.log(handleValue([1, 2, 3]))
* // Output: "Array with 3 items"
* ```
*
* @category Predicates
* @since 4.0.0
*/
var instanceOf = instanceOf$1;
/**
* Unsafe variant of `instanceOf` that allows matching without type narrowing.
*
* This predicate checks if a value is an instance of the specified constructor
* but doesn't provide the same type safety guarantees as the regular `instanceOf`.
* Use this when you need more flexibility but understand the type safety implications.
*
* @example
* ```ts
* import { Match } from "effect"
*
* class CustomError extends Error {
*   constructor(message: string, public code: number) {
*     super(message)
*   }
* }
*
* // When you need to match instances but handle type narrowing manually
* const handleError = Match.type<unknown>().pipe(
*   Match.when(Match.instanceOfUnsafe(CustomError), (err: any) => {
*     // Manual type assertion needed
*     const customErr = err as CustomError
*     return `Custom error ${customErr.code}: ${customErr.message}`
*   }),
*   Match.orElse(() => "Not a CustomError")
* )
* ```
*
* @category predicates
* @since 4.0.0
*/
var instanceOfUnsafe = instanceOf$1;
/**
* Provides a fallback value when no patterns match.
*
* **Details**
*
* This function ensures that a matcher always returns a valid result, even if
* no defined patterns match. It acts as a default case, similar to the
* `default` clause in a `switch` statement or the final `else` in an `if-else`
* chain.
*
* @example (Providing a Default Value When No Patterns Match)
*
* ```ts
* import { Match } from "effect"
*
* // Create a matcher for string or number values
* const match = Match.type<string | number>().pipe(
*   // Match when the value is "a"
*   Match.when("a", () => "ok"),
*   // Fallback when no patterns match
*   Match.orElse(() => "fallback")
* )
*
* console.log(match("a"))
* // Output: "ok"
*
* console.log(match("b"))
* // Output: "fallback"
* ```
*
* @category Completion
* @since 4.0.0
*/
var orElse = orElse$1;
/**
* Throws an error if no pattern matches.
*
* **Details**
*
* This function finalizes a matcher by ensuring that if no patterns match, an
* error is thrown. It is useful when all cases should be covered, and any
* unexpected input should trigger an error instead of returning a default
* value.
*
* When used, this function removes the need for an explicit fallback case and
* ensures that an unmatched value is never silently ignored.
*
* @example
* ```ts
* import { Match } from "effect"
*
* const strictMatcher = Match.type<"a" | "b">().pipe(
*   Match.when("a", () => "Found A"),
*   Match.when("b", () => "Found B"),
*   // Will throw if input is neither "a" nor "b"
*   Match.orElseAbsurd
* )
*
* console.log(strictMatcher("a")) // "Found A"
* console.log(strictMatcher("b")) // "Found B"
*
* // This would throw an error at runtime:
* // strictMatcher("c" as any) // throws
* ```
*
* @category completion
* @since 4.0.0
*/
var orElseAbsurd = orElseAbsurd$1;
/**
* Wraps the match result in a `Result`, distinguishing matched and unmatched
* cases.
*
* **Details**
*
* This function ensures that the result of a matcher is always wrapped in an
* `Result`, allowing clear differentiation between successful matches
* (`Ok(value)`) and cases where no pattern matched (`Err(unmatched
* value)`).
*
* This approach is particularly useful when handling optional values or when an
* unmatched case should be explicitly handled rather than returning a default
* value or throwing an error.
*
* @example (Extracting a User Role with `Match.result`)
*
* ```ts
* import { Match } from "effect"
*
* type User = { readonly role: "admin" | "editor" | "viewer" }
*
* // Create a matcher to extract user roles
* const getRole = Match.type<User>().pipe(
*   Match.when({ role: "admin" }, () => "Has full access"),
*   Match.when({ role: "editor" }, () => "Can edit content"),
*   Match.result // Wrap the result in an Result
* )
*
* console.log(getRole({ role: "admin" }))
* // Output: { _id: 'Result', _tag: 'Ok', ok: 'Has full access' }
*
* console.log(getRole({ role: "viewer" }))
* // Output: { _id: 'Result', _tag: 'Err', err: { role: 'viewer' } }
* ```
*
* @category Completion
* @since 4.0.0
*/
var result = result$1;
/**
* Wraps the match result in an `Option`, representing an optional match.
*
* **Details**
*
* This function ensures that the result of a matcher is wrapped in an `Option`,
* making it easy to handle cases where no pattern matches. If a match is found,
* it returns `Some(value)`, otherwise, it returns `None`.
*
* This is useful in cases where a missing match is expected and should be
* handled explicitly rather than throwing an error or returning a default
* value.
*
* @example (Extracting a User Role with `Match.option`)
*
* ```ts
* import { Match } from "effect"
*
* type User = { readonly role: "admin" | "editor" | "viewer" }
*
* // Create a matcher to extract user roles
* const getRole = Match.type<User>().pipe(
*   Match.when({ role: "admin" }, () => "Has full access"),
*   Match.when({ role: "editor" }, () => "Can edit content"),
*   Match.option // Wrap the result in an Option
* )
*
* console.log(getRole({ role: "admin" }))
* // Output: { _id: 'Option', _tag: 'Some', value: 'Has full access' }
*
* console.log(getRole({ role: "viewer" }))
* // Output: { _id: 'Option', _tag: 'None' }
* ```
*
* @category Completion
* @since 4.0.0
*/
var option = option$1;
/**
* The `Match.exhaustive` method finalizes the pattern matching process by
* ensuring that all possible cases are accounted for. If any case is missing,
* TypeScript will produce a type error. This is particularly useful when
* working with unions, as it helps prevent unintended gaps in pattern matching.
*
* @example (Ensuring All Cases Are Covered)
*
* ```ts
* import { Match } from "effect"
*
* // Create a matcher for string or number values
* const match = Match.type<string | number>().pipe(
*   // Match when the value is a number
*   Match.when(Match.number, (n) => `number: ${n}`),
*   // Mark the match as exhaustive, ensuring all cases are handled
*   // TypeScript will throw an error if any case is missing
*   // @ts-expect-error Type 'string' is not assignable to type 'never'
*   Match.exhaustive
* )
* ```
*
* @category Completion
* @since 4.0.0
*/
var exhaustive = exhaustive$1;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/MutableHashSet.js
/**
* @fileoverview
* MutableHashSet is a high-performance, mutable set implementation that provides efficient storage
* and retrieval of unique values. Built on top of MutableHashMap, it inherits the same performance
* characteristics and support for both structural and referential equality.
*
* The implementation uses a MutableHashMap internally where each value is stored as a key with a
* boolean flag, providing O(1) average-case performance for all operations.
*
* Key Features:
* - Mutable operations for performance-critical scenarios
* - Supports both structural and referential equality
* - Efficient duplicate detection and removal
* - Iterable interface for easy traversal
* - Memory-efficient storage with automatic deduplication
* - Seamless integration with Effect's Equal and Hash interfaces
*
* Performance Characteristics:
* - Add/Has/Remove: O(1) average, O(n) worst case (hash collisions)
* - Clear: O(1)
* - Size: O(1)
* - Iteration: O(n)
*
* @since 2.0.0
* @category data-structures
*/
var MutableHashSet_exports = /* @__PURE__ */ __exportAll({
	add: () => add$1,
	clear: () => clear$3,
	empty: () => empty$6,
	fromIterable: () => fromIterable$6,
	has: () => has$5,
	make: () => make$18,
	remove: () => remove$4,
	size: () => size$9
});
var TypeId$18 = "~effect/collections/MutableHashSet";
var MutableHashSetProto = {
	[TypeId$18]: TypeId$18,
	[Symbol.iterator]() {
		return Array.from(this.keyMap).map(([_]) => _)[Symbol.iterator]();
	},
	toString() {
		return `MutableHashSet(${format$1(Array.from(this))})`;
	},
	toJSON() {
		return {
			_id: "MutableHashSet",
			values: toJson(Array.from(this))
		};
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var fromHashMap$1 = (keyMap) => {
	const set = Object.create(MutableHashSetProto);
	set.keyMap = keyMap;
	return set;
};
/**
* Creates an empty MutableHashSet.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.empty<string>()
*
* // Add some values
* MutableHashSet.add(set, "apple")
* MutableHashSet.add(set, "banana")
* MutableHashSet.add(set, "apple") // Duplicate, no effect
*
* console.log(MutableHashSet.size(set)) // 2
* console.log(Array.from(set)) // ["apple", "banana"]
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty$6 = () => fromHashMap$1(empty$12());
/**
* Creates a MutableHashSet from an iterable collection of values.
* Duplicates are automatically removed.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const values = ["apple", "banana", "apple", "cherry", "banana"]
* const set = MutableHashSet.fromIterable(values)
*
* console.log(MutableHashSet.size(set)) // 3
* console.log(Array.from(set)) // ["apple", "banana", "cherry"]
*
* // Works with any iterable
* const fromSet = MutableHashSet.fromIterable(new Set([1, 2, 3]))
* console.log(MutableHashSet.size(fromSet)) // 3
*
* // From string characters
* const fromString = MutableHashSet.fromIterable("hello")
* console.log(Array.from(fromString)) // ["h", "e", "l", "o"]
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromIterable$6 = (keys) => fromHashMap$1(fromIterable$10(Array.from(keys).map((k) => [k, true])));
/**
* Creates a MutableHashSet from a variable number of values.
* Duplicates are automatically removed.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.make("apple", "banana", "apple", "cherry")
*
* console.log(MutableHashSet.size(set)) // 3
* console.log(Array.from(set)) // ["apple", "banana", "cherry"]
*
* // With numbers
* const numbers = MutableHashSet.make(1, 2, 3, 2, 1)
* console.log(MutableHashSet.size(numbers)) // 3
* console.log(Array.from(numbers)) // [1, 2, 3]
*
* // Mixed types
* const mixed = MutableHashSet.make("hello", 42, true, "hello")
* console.log(MutableHashSet.size(mixed)) // 3
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$18 = (...keys) => fromIterable$6(keys);
/**
* Adds a value to the MutableHashSet, mutating the set in place.
* If the value already exists, the set remains unchanged.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.empty<string>()
*
* // Add new values
* MutableHashSet.add(set, "apple")
* MutableHashSet.add(set, "banana")
*
* console.log(MutableHashSet.size(set)) // 2
* console.log(MutableHashSet.has(set, "apple")) // true
*
* // Add duplicate (no effect)
* MutableHashSet.add(set, "apple")
* console.log(MutableHashSet.size(set)) // 2
*
* // Pipe-able version
* const addFruit = MutableHashSet.add("cherry")
* addFruit(set)
* console.log(MutableHashSet.size(set)) // 3
* ```
*
* @since 2.0.0
* @category mutations
*/
var add$1 = /*#__PURE__*/ dual(2, (self, key) => (set$13(self.keyMap, key, true), self));
/**
* Checks if the MutableHashSet contains the specified value.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.make("apple", "banana", "cherry")
*
* console.log(MutableHashSet.has(set, "apple")) // true
* console.log(MutableHashSet.has(set, "grape")) // false
*
* // Pipe-able version
* const hasApple = MutableHashSet.has("apple")
* console.log(hasApple(set)) // true
*
* // Check after adding
* MutableHashSet.add(set, "grape")
* console.log(MutableHashSet.has(set, "grape")) // true
* ```
*
* @since 2.0.0
* @category elements
*/
var has$5 = /*#__PURE__*/ dual(2, (self, key) => has$12(self.keyMap, key));
/**
* Removes the specified value from the MutableHashSet, mutating the set in place.
* If the value doesn't exist, the set remains unchanged.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.make("apple", "banana", "cherry")
*
* console.log(MutableHashSet.size(set)) // 3
*
* // Remove existing value
* MutableHashSet.remove(set, "banana")
* console.log(MutableHashSet.size(set)) // 2
* console.log(MutableHashSet.has(set, "banana")) // false
*
* // Remove non-existent value (no effect)
* MutableHashSet.remove(set, "grape")
* console.log(MutableHashSet.size(set)) // 2
*
* // Pipe-able version
* const removeFruit = MutableHashSet.remove("apple")
* removeFruit(set)
* console.log(MutableHashSet.size(set)) // 1
* ```
*
* @since 2.0.0
* @category mutations
*/
var remove$4 = /*#__PURE__*/ dual(2, (self, key) => (remove$9(self.keyMap, key), self));
/**
* Returns the number of unique values in the MutableHashSet.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.empty<string>()
* console.log(MutableHashSet.size(set)) // 0
*
* MutableHashSet.add(set, "apple")
* MutableHashSet.add(set, "banana")
* MutableHashSet.add(set, "apple") // Duplicate
* console.log(MutableHashSet.size(set)) // 2
*
* MutableHashSet.remove(set, "apple")
* console.log(MutableHashSet.size(set)) // 1
*
* MutableHashSet.clear(set)
* console.log(MutableHashSet.size(set)) // 0
* ```
*
* @since 2.0.0
* @category elements
*/
var size$9 = (self) => size$15(self.keyMap);
/**
* Removes all values from the MutableHashSet, mutating the set in place.
* The set becomes empty after this operation.
*
* @example
* ```ts
* import { MutableHashSet } from "effect"
*
* const set = MutableHashSet.make("apple", "banana", "cherry")
*
* console.log(MutableHashSet.size(set)) // 3
*
* // Clear all values
* MutableHashSet.clear(set)
*
* console.log(MutableHashSet.size(set)) // 0
* console.log(MutableHashSet.has(set, "apple")) // false
* console.log(Array.from(set)) // []
*
* // Can still add new values after clearing
* MutableHashSet.add(set, "new")
* console.log(MutableHashSet.size(set)) // 1
* ```
*
* @since 2.0.0
* @category mutations
*/
var clear$3 = (self) => (clear$7(self.keyMap), self);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/NonEmptyIterable.js
var NonEmptyIterable_exports = /* @__PURE__ */ __exportAll({ unprepend: () => unprepend });
/**
* @since 2.0.0
*
* The `NonEmptyIterable` module provides types and utilities for working with iterables
* that are guaranteed to contain at least one element. This provides compile-time
* safety when working with collections that must not be empty.
*
* ## Key Features
*
* - **Type Safety**: Compile-time guarantee that the iterable contains at least one element
* - **Iterator Protocol**: Fully compatible with JavaScript's built-in iteration protocol
* - **Functional Operations**: Safe operations that preserve the non-empty property
* - **Lightweight**: Minimal overhead with maximum type safety
*
* ## Why NonEmptyIterable?
*
* Many operations require non-empty collections to be meaningful:
* - Finding the maximum or minimum value
* - Getting the first or last element
* - Reducing without an initial value
* - Operations that would otherwise need runtime checks
*
* ## Basic Usage
*
* ```ts
* import * as NonEmptyIterable from "effect/NonEmptyIterable"
*
* // NonEmptyIterable is a type that represents any iterable with at least one element
* function processNonEmpty<A>(data: NonEmptyIterable.NonEmptyIterable<A>): A {
*   // Safe to get the first element - guaranteed to exist
*   const [first] = NonEmptyIterable.unprepend(data)
*   return first
* }
*
* // Using Array.make to create non-empty arrays
* const numbers = Array.make(
*   1,
*   2,
*   3,
*   4,
*   5
* ) as unknown as NonEmptyIterable.NonEmptyIterable<number>
* const firstNumber = processNonEmpty(numbers) // number
*
* // Regular arrays can be asserted as NonEmptyIterable when known to be non-empty
* const values = [1, 2, 3] as unknown as NonEmptyIterable.NonEmptyIterable<number>
* const firstValue = processNonEmpty(values) // number
*
* // Custom iterables that are guaranteed non-empty
* function* generateNumbers(): NonEmptyIterable.NonEmptyIterable<number> {
*   yield 1
*   yield 2
*   yield 3
* }
*
* const firstGenerated = processNonEmpty(generateNumbers()) // number
* ```
*
* ## Working with Different Iterable Types
*
* ```ts
* import { Array } from "effect"
*
* // Creating non-empty arrays
* const nonEmptyArray = Array.make(
*   1,
*   2,
*   3
* ) as unknown as NonEmptyIterable.NonEmptyIterable<number>
*
* // Working with strings (assert as NonEmptyIterable when known to be non-empty)
* const nonEmptyString = "hello" as unknown as NonEmptyIterable.NonEmptyIterable<
*   string
* >
* const [firstChar] = NonEmptyIterable.unprepend(nonEmptyString)
* console.log(firstChar) // "h"
*
* // Working with Maps (assert when known to be non-empty)
* const nonEmptyMap = new Map([
*   ["key1", "value1"],
*   ["key2", "value2"]
* ]) as unknown as NonEmptyIterable.NonEmptyIterable<[string, string]>
* const [firstEntry] = NonEmptyIterable.unprepend(nonEmptyMap)
* console.log(firstEntry) // ["key1", "value1"]
*
* // Custom generator functions
* function* fibonacci(): NonEmptyIterable.NonEmptyIterable<number> {
*   let a = 1, b = 1
*   yield a
*   while (true) {
*     yield b
*     const next = a + b
*     a = b
*     b = next
*   }
* }
*
* const [firstFib, restFib] = NonEmptyIterable.unprepend(
*   fibonacci() as unknown as NonEmptyIterable.NonEmptyIterable<number>
* )
* console.log(firstFib) // 1
* ```
*
* ## Integration with Effect Arrays
*
* ```ts
* import { Array, pipe } from "effect"
* import type * as NonEmptyIterable from "effect/NonEmptyIterable"
* import type * as NonEmptyIterable from "effect/NonEmptyIterable"
*
* // Many Array functions work with NonEmptyIterable
* declare const nonEmptyData: NonEmptyIterable.NonEmptyIterable<number>
*
* const processData = pipe(
*   nonEmptyData,
*   Array.fromIterable,
*   Array.map((x) => x * 2),
*   Array.filter((x) => x > 5)
*   // Result is a regular array since filtering might make it empty
* )
*
* // Safe operations that preserve non-emptiness
* const doubledData = pipe(
*   nonEmptyData,
*   Array.fromIterable,
*   Array.map((x) => x * 2)
*   // This would still be non-empty if the source was non-empty
* )
* ```
*/
/**
* Safely extracts the first element and remaining elements from a non-empty iterable.
*
* This function provides a safe way to deconstruct a `NonEmptyIterable` into its
* head (first element) and tail (remaining elements as an iterator). Since the
* iterable is guaranteed to be non-empty, the first element is always available.
*
* @param self - The non-empty iterable to deconstruct
* @returns A tuple containing the first element and an iterator for the remaining elements
*
* @example
* ```ts
* import { Array } from "effect"
* import * as Chunk from "effect/Chunk"
* import * as NonEmptyIterable from "effect/NonEmptyIterable"
*
* // Helper to make iterator iterable for Array.from
* const iteratorToIterable = <T>(iterator: Iterator<T>): Iterable<T> => ({
*   [Symbol.iterator]() {
*     return iterator
*   }
* })
*
* // With NonEmptyArray from Array.make (cast to NonEmptyIterable)
* const numbers = Array.make(
*   1,
*   2,
*   3,
*   4,
*   5
* ) as unknown as NonEmptyIterable.NonEmptyIterable<number>
* const [first, rest] = NonEmptyIterable.unprepend(numbers)
* console.log(first) // 1
* console.log(globalThis.Array.from(iteratorToIterable(rest))) // [2, 3, 4, 5]
*
* // With strings (assert when known to be non-empty)
* const text = "hello" as unknown as NonEmptyIterable.NonEmptyIterable<string>
* const [firstChar, restChars] = NonEmptyIterable.unprepend(text)
* console.log(firstChar) // "h"
* console.log(globalThis.Array.from(iteratorToIterable(restChars)).join("")) // "ello"
*
* // With Sets (assert when known to be non-empty)
* const uniqueNumbers = new Set([
*   10,
*   20,
*   30
* ]) as unknown as NonEmptyIterable.NonEmptyIterable<number>
* const [firstUnique, restUnique] = NonEmptyIterable.unprepend(uniqueNumbers)
* console.log(firstUnique) // 10 (or any element, Set order is not guaranteed)
* console.log(globalThis.Array.from(iteratorToIterable(restUnique))) // [20, 30] (in some order)
*
* // With Maps (assert when known to be non-empty)
* const keyValuePairs = new Map([["a", 1], ["b", 2], [
*   "c",
*   3
* ]]) as unknown as NonEmptyIterable.NonEmptyIterable<[string, number]>
* const [firstPair, restPairs] = NonEmptyIterable.unprepend(keyValuePairs)
* console.log(firstPair) // ["a", 1]
* console.log(globalThis.Array.from(iteratorToIterable(restPairs))) // [["b", 2], ["c", 3]]
*
* // With custom generators
* function* fibonacci(): Generator<number> {
*   let a = 1, b = 1
*   yield a
*   for (let i = 0; i < 10; i++) {
*     yield b
*     const next = a + b
*     a = b
*     b = next
*   }
* }
*
* const generator = Chunk.fromIterable(
*   fibonacci()
* ) as unknown as NonEmptyIterable.NonEmptyIterable<number>
* const [firstFib, restFib] = NonEmptyIterable.unprepend(generator)
* console.log(firstFib) // 1
* console.log(globalThis.Array.from(iteratorToIterable(restFib))) // [1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
*
* // Practical usage: implementing reduce for non-empty iterables
* function reduceNonEmpty<A, B>(
*   data: NonEmptyIterable.NonEmptyIterable<A>,
*   f: (acc: B, current: A) => B,
*   initial: B
* ): B {
*   const [first, rest] = NonEmptyIterable.unprepend(data)
*   let result = f(initial, first)
*
*   // Convert iterator to iterable for iteration
*   const iterable = {
*     [Symbol.iterator]() {
*       return rest
*     }
*   }
*   for (const item of iterable) {
*     result = f(result, item)
*   }
*
*   return result
* }
*
* const data = Array.make(
*   1,
*   2,
*   3,
*   4
* ) as unknown as NonEmptyIterable.NonEmptyIterable<number>
* const sum = reduceNonEmpty(data, (acc, x) => acc + x, 0) // 10
* ```
*
* @category getters
* @since 2.0.0
*/
var unprepend = (self) => {
	const iterator = self[Symbol.iterator]();
	const next = iterator.next();
	if (next.done) throw new Error("BUG: NonEmptyIterator should not be empty - please report an issue at https://github.com/Effect-TS/effect/issues");
	return [next.value, iterator];
};
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/NullOr.js
/**
* This module provides small, allocation-free utilities for working with values of type
* `A | null`, where `null` means "no value".
*
* Why not `Option<A>`?
* In TypeScript, `Option<A>` is often unnecessary. If `null` already models absence
* in your domain, using `A | null` keeps types simple, avoids extra wrappers, and
* reduces overhead. The key is that `A` itself must not include `null`; in this
* module `null` is reserved to mean "no value".
*
* When to use `A | null`:
* - Absence can be represented by `null` in your domain model.
* - You do not need to distinguish between "no value" and "value is null".
* - You want straightforward ergonomics and zero extra allocations.
*
* When to prefer `Option<A>`:
* - You must distinguish `None` from `Some(null)` (that is, `null` is a valid
*   payload and carries meaning on its own).
* - You need a tagged representation for serialization or pattern matching across
*   boundaries where `null` would be ambiguous.
* - You want the richer `Option` API and are comfortable with the extra wrapper.
*
* Lawfulness note:
* All helpers treat `null` as absence. Do not use these utilities with payloads
* where `A` can itself be `null`, or you will lose information. If you need to
* carry `null` as a valid payload, use `Option<A>` instead.
*
* @since 4.0.0
*/
var NullOr_exports = /* @__PURE__ */ __exportAll({
	getOrThrow: () => getOrThrow,
	getOrThrowWith: () => getOrThrowWith,
	liftThrowable: () => liftThrowable,
	makeCombinerFailFast: () => makeCombinerFailFast,
	makeReducer: () => makeReducer,
	makeReducerFailFast: () => makeReducerFailFast,
	map: () => map$5,
	match: () => match$1
});
/**
* @since 4.0.0
*/
var map$5 = /*#__PURE__*/ dual(2, (self, f) => self === null ? null : f(self));
/**
* @since 4.0.0
*/
var match$1 = /*#__PURE__*/ dual(2, (self, { onNotNull, onNull }) => self === null ? onNull() : onNotNull(self));
/**
* @since 4.0.0
*/
var getOrThrowWith = /*#__PURE__*/ dual(2, (self, onNull) => {
	if (self !== null) return self;
	throw onNull();
});
/**
* @since 4.0.0
*/
var getOrThrow = /*#__PURE__*/ getOrThrowWith(() => /* @__PURE__ */ new Error("getOrThrow called on a null"));
/**
* @since 4.0.0
*/
var liftThrowable = (f) => (...a) => {
	try {
		return f(...a);
	} catch {
		return null;
	}
};
/**
* Creates a `Reducer` for `NullOr<A>` that prioritizes the first non-`null`
* value and combines values when both operands are present.
*
* This `Reducer` is useful for scenarios where you want to:
* - Take the first available value (like a fallback chain)
* - Combine values when both are present
* - Maintain a `null` state only when all values are `null`
*
* The `initialValue` of the `Reducer` is `null`.
*
* **Behavior:**
* - `null` + `null` = `null`
* - `a` + `null` = `a` (first value wins)
* - `null` + `b` = `b` (second value wins)
* - `a` + `b` = `a + b` (values combined)
*
* @since 4.0.0
*/
function makeReducer(combiner) {
	return make$28((self, that) => {
		if (self === null) return that;
		if (that === null) return self;
		return combiner.combine(self, that);
	}, null);
}
/**
* Creates a `Combiner` for `NullOr<A>` that only combines values when both
* operands are not `null`, failing fast if either is `null`.
*
* This `Combiner` is useful for scenarios where you need both values to be
* present to perform an operation, such as:
* - Mathematical operations that require two operands
* - Data validation that needs both fields
* - Operations that can't proceed with partial data
*
* **Behavior:**
* - `null` + `null` = `null`
* - `a` + `null` = `null` (fails fast)
* - `null` + `b` = `null` (fails fast)
* - `a` + `b` = `a + b` (values combined)
*
* @see {@link makeReducerFailFast} if you have a `Reducer` and want to lift it
* to `NullOr` values.
*
* @since 4.0.0
*/
function makeCombinerFailFast(combiner) {
	return make$29((self, that) => {
		if (self === null || that === null) return null;
		return combiner.combine(self, that);
	});
}
/**
* Creates a `Reducer` for `NullOr<A>` by wrapping an existing `Reducer` with
* fail-fast semantics for `NullOr` values.
*
* This function lifts a regular `Reducer` into the `NullOr` context, allowing
* you to use existing `Reducer`s with `NullOr` values while maintaining the
* fail-fast behavior where any `null` value causes the entire reduction to fail.
*
* The initial value is `some(reducer.initialValue)`, ensuring the `Reducer`
* starts with a valid `NullOr` value.
*
* **Behavior:**
* - Fails fast (returns `null`) if any operand is `null`
* - Uses the underlying reducer's combine logic when both values are present
*
* @see {@link makeCombinerFailFast} if you only have a `Combiner` and want to
* lift it to `NullOr` values.
*
* @since 4.0.0
*/
function makeReducerFailFast(reducer) {
	const combine = makeCombinerFailFast(reducer).combine;
	const initialValue = reducer.initialValue;
	return make$28(combine, initialValue, (collection) => {
		let out = initialValue;
		for (const value of collection) {
			out = combine(out, value);
			if (out === null) return out;
		}
		return out;
	});
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Ordering.js
var Ordering_exports = /* @__PURE__ */ __exportAll({
	Reducer: () => Reducer,
	match: () => match,
	reverse: () => reverse
});
/**
* Inverts the ordering of the input Ordering.
* This is useful for creating descending sort orders from ascending ones.
*
* @example
* ```ts
* import { Ordering } from "effect"
*
* // Basic reversal
* console.log(Ordering.reverse(1)) // -1 (greater becomes less)
* console.log(Ordering.reverse(-1)) // 1 (less becomes greater)
* console.log(Ordering.reverse(0)) // 0 (equal stays equal)
*
* // Creating descending sort from ascending comparison
* const compareNumbers = (a: number, b: number): Ordering.Ordering =>
*   a < b ? -1 : a > b ? 1 : 0
*
* const compareDescending = (a: number, b: number): Ordering.Ordering =>
*   Ordering.reverse(compareNumbers(a, b))
*
* const numbers = [3, 1, 4, 1, 5]
* numbers.sort(compareNumbers) // [1, 1, 3, 4, 5] (ascending)
* numbers.sort(compareDescending) // [5, 4, 3, 1, 1] (descending)
*
* // Useful for toggling sort direction
* const createSorter = (ascending: boolean) => (a: number, b: number) => {
*   const ordering = compareNumbers(a, b)
*   return ascending ? ordering : Ordering.reverse(ordering)
* }
* ```
*
* @category transformations
* @since 2.0.0
*/
var reverse = (o) => o === -1 ? 1 : o === 1 ? -1 : 0;
/**
* Depending on the `Ordering` parameter given to it, returns a value produced by one of the 3 functions provided as parameters.
*
* @example
* ```ts
* import { Ordering } from "effect"
* import { constant } from "effect/Function"
* import * as assert from "node:assert"
*
* const toMessage = Ordering.match({
*   onLessThan: constant("less than"),
*   onEqual: constant("equal"),
*   onGreaterThan: constant("greater than")
* })
*
* assert.deepStrictEqual(toMessage(-1), "less than")
* assert.deepStrictEqual(toMessage(0), "equal")
* assert.deepStrictEqual(toMessage(1), "greater than")
* ```
*
* @category pattern matching
* @since 2.0.0
*/
var match = /*#__PURE__*/ dual(2, (self, { onEqual, onGreaterThan, onLessThan }) => self === -1 ? onLessThan() : self === 0 ? onEqual() : onGreaterThan());
/**
* A `Reducer` for combining `Ordering`s.
*
* If any of the `Ordering`s is non-zero, the result is the first non-zero `Ordering`.
* If all the `Ordering`s are zero, the result is zero.
*
* @since 4.0.0
*/
var Reducer = /*#__PURE__*/ make$28((self, that) => self !== 0 ? self : that, 0, (collection) => {
	let ordering = 0;
	for (ordering of collection) if (ordering !== 0) return ordering;
	return ordering;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Ref.js
/**
* This module provides utilities for working with mutable references in a functional context.
*
* A Ref is a mutable reference that can be read, written, and atomically modified. Unlike plain
* mutable variables, Refs are thread-safe and work seamlessly with Effect's concurrency model.
* They provide atomic operations for safe state management in concurrent programs.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a ref with initial value
*   const counter = yield* Ref.make(0)
*
*   // Atomic operations
*   yield* Ref.update(counter, (n) => n + 1)
*   yield* Ref.update(counter, (n) => n * 2)
*
*   const value = yield* Ref.get(counter)
*   console.log(value) // 2
*
*   // Atomic modify with return value
*   const previous = yield* Ref.getAndSet(counter, 100)
*   console.log(previous) // 2
* })
* ```
*
* @since 2.0.0
*/
var Ref_exports = /* @__PURE__ */ __exportAll({
	get: () => get$11,
	getAndSet: () => getAndSet$3,
	getAndUpdate: () => getAndUpdate$3,
	getAndUpdateSome: () => getAndUpdateSome$2,
	getUnsafe: () => getUnsafe$5,
	make: () => make$17,
	makeUnsafe: () => makeUnsafe$5,
	modify: () => modify$8,
	modifySome: () => modifySome$2,
	set: () => set$8,
	setAndGet: () => setAndGet$2,
	update: () => update$5,
	updateAndGet: () => updateAndGet$3,
	updateSome: () => updateSome$2,
	updateSomeAndGet: () => updateSomeAndGet$2
});
var RefProto = {
	["~effect/Ref"]: { _A: identity },
	...PipeInspectableProto,
	toJSON() {
		return {
			_id: "Ref",
			ref: this.ref
		};
	}
};
/**
* Creates a new Ref with the specified initial value (unsafe version).
*
* This function creates a Ref synchronously without wrapping in Effect.
* Use this only when you're sure about the safety of immediate creation.
*
* @example
* ```ts
* import { Ref } from "effect"
*
* // Create a ref directly without Effect
* const counter = Ref.makeUnsafe(0)
*
* // Get the current value
* const value = Ref.getUnsafe(counter)
* console.log(value) // 0
*
* // Note: This is unsafe and should be used carefully
* // Prefer Ref.make for Effect-wrapped creation
* ```
*
* @since 4.0.0
* @category constructors
*/
var makeUnsafe$5 = (value) => {
	const self = Object.create(RefProto);
	self.ref = make$33(value);
	return self;
};
/**
* Creates a new Ref with the specified initial value.
*
* @param value - The initial value for the Ref
* @returns An Effect that creates a new Ref
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* Ref.make(42)
*   const value = yield* Ref.get(ref)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$17 = (value) => sync$1(() => makeUnsafe$5(value));
/**
* Gets the current value of the Ref.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* Ref.make(42)
*   const value = yield* Ref.get(ref)
*   console.log(value) // 42
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var get$11 = (self) => sync$1(() => self.ref.current);
/**
* Sets the value of the Ref to the specified value.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* Ref.make(0)
*   yield* Ref.set(ref, 42)
*   const value = yield* Ref.get(ref)
*   console.log(value) // 42
* })
*
* // Using multiple operations
* const program2 = Effect.gen(function*() {
*   const ref = yield* Ref.make(0)
*   yield* Ref.set(ref, 100)
*   const value = yield* Ref.get(ref)
*   console.log(value) // 100
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var set$8 = /*#__PURE__*/ dual(2, (self, value) => sync$1(() => set$14(self.ref, value)));
/**
* Atomically gets the current value of the Ref and sets it to the specified value.
*
* Returns the value that was in the Ref before the update.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* Ref.make("initial")
*
*   // Get current value and set new value atomically
*   const previous = yield* Ref.getAndSet(ref, "updated")
*   console.log(previous) // "initial"
*
*   const current = yield* Ref.get(ref)
*   console.log(current) // "updated"
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var getAndSet$3 = /*#__PURE__*/ dual(2, (self, value) => sync$1(() => {
	const current = self.ref.current;
	self.ref.current = value;
	return current;
}));
/**
* Atomically gets the current value of the Ref and updates it with the given function.
*
* Returns the value that was in the Ref before the update.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(10)
*
*   // Get current value and update it atomically
*   const previous = yield* Ref.getAndUpdate(counter, (n) => n * 2)
*   console.log(previous) // 10
*
*   const current = yield* Ref.get(counter)
*   console.log(current) // 20
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var getAndUpdate$3 = /*#__PURE__*/ dual(2, (self, f) => sync$1(() => {
	const current = self.ref.current;
	self.ref.current = f(current);
	return current;
}));
/**
* Atomically gets the current value of the Ref and updates it with the given partial function.
*
* If the partial function returns `Option.some`, the Ref is updated with the new value.
* If it returns `Option.none`, the Ref is left unchanged.
* Always returns the value that was in the Ref before the attempted update.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
* import * as Option from "effect/Option"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(5)
*
*   // Only update if value is greater than 3
*   const previous1 = yield* Ref.getAndUpdateSome(
*     counter,
*     (n) => n > 3 ? Option.some(n * 2) : Option.none()
*   )
*   console.log(previous1) // 5
*
*   const current1 = yield* Ref.get(counter)
*   console.log(current1) // 10
*
*   // Try to update again (won't update since 10 > 3 is true but let's say condition is n < 3)
*   const previous2 = yield* Ref.getAndUpdateSome(
*     counter,
*     (n) => n < 3 ? Option.some(n * 2) : Option.none()
*   )
*   console.log(previous2) // 10
*
*   const current2 = yield* Ref.get(counter)
*   console.log(current2) // 10 (unchanged)
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var getAndUpdateSome$2 = /*#__PURE__*/ dual(2, (self, pf) => sync$1(() => {
	const current = self.ref.current;
	const option = pf(current);
	if (option._tag === "Some") self.ref.current = option.value;
	return current;
}));
/**
* Atomically sets the value of the Ref to the specified value and returns the new value.
*
* This is useful when you want to set a value and immediately get it back in one atomic operation.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* Ref.make(10)
*
*   // Set new value and get it back in one operation
*   const newValue = yield* Ref.setAndGet(ref, 42)
*   console.log(newValue) // 42
*
*   // Verify the ref contains the new value
*   const current = yield* Ref.get(ref)
*   console.log(current) // 42
* })
*
* // Useful for sequential operations
* const program2 = Effect.gen(function*() {
*   const counter = yield* Ref.make(0)
*
*   const newValue = yield* Ref.setAndGet(counter, 20)
*   console.log(newValue) // 20
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var setAndGet$2 = /*#__PURE__*/ dual(2, (self, value) => sync$1(() => self.ref.current = value));
/**
* Atomically modifies the value of the Ref using the given function.
*
* The function receives the current value and returns a tuple of [result, newValue].
* The Ref is updated with the newValue and the result is returned.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(10)
*
*   // Modify the ref and return some computation result
*   const result = yield* Ref.modify(counter, (n) => [
*     `Previous value was ${n}`, // Return value
*     n * 2 // New ref value
*   ])
*
*   console.log(result) // "Previous value was 10"
*
*   const current = yield* Ref.get(counter)
*   console.log(current) // 20
* })
*
* // Example with more complex computation
* const program2 = Effect.gen(function*() {
*   const state = yield* Ref.make({ count: 0, total: 0 })
*
*   const incremented = yield* Ref.modify(state, (s) => [
*     s.count, // Return previous count
*     { count: s.count + 1, total: s.total + s.count + 1 } // New state
*   ])
*
*   console.log(incremented) // 0
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var modify$8 = /*#__PURE__*/ dual(2, (self, f) => sync$1(() => {
	const [b, a] = f(self.ref.current);
	self.ref.current = a;
	return b;
}));
/**
* Atomically modifies the value of the Ref using the given partial function.
*
* The function receives the current value and returns an Option of [result, newValue].
* If the function returns `Option.some([result, newValue])`, the Ref is updated with newValue and result is returned.
* If it returns `Option.none()`, the Ref is left unchanged and the fallback value is returned.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
* import * as Option from "effect/Option"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(5)
*
*   // Only modify if value is greater than 3
*   const result1 = yield* Ref.modifySome(
*     counter,
*     (n) =>
*       n > 3
*         ? [`incremented ${n}`, Option.some(n + 10)]
*         : ["no change", Option.none()]
*   )
*
*   console.log(result1) // "incremented 5"
*
*   const current1 = yield* Ref.get(counter)
*   console.log(current1) // 15
*
*   // Try to modify with a condition that fails
*   const result2 = yield* Ref.modifySome(
*     counter,
*     (n) =>
*       n < 10
*         ? [`decremented ${n}`, Option.some(n - 5)]
*         : ["no change", Option.none()]
*   )
*
*   console.log(result2) // "no change"
*
*   const current2 = yield* Ref.get(counter)
*   console.log(current2) // 15 (unchanged)
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var modifySome$2 = /*#__PURE__*/ dual(2, (self, pf) => modify$8(self, (value) => {
	const [b, option] = pf(value);
	return [b, option._tag === "None" ? value : option.value];
}));
/**
* Atomically updates the value of the Ref using the given function.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(5)
*
*   // Update the value
*   yield* Ref.update(counter, (n) => n * 2)
*
*   const value = yield* Ref.get(counter)
*   console.log(value) // 10
* })
*
* // Using multiple operations
* const program2 = Effect.gen(function*() {
*   const counter = yield* Ref.make(5)
*   yield* Ref.update(counter, (n: number) => n + 10)
*   const value = yield* Ref.get(counter)
*   console.log(value) // 15
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var update$5 = /*#__PURE__*/ dual(2, (self, f) => sync$1(() => {
	self.ref.current = f(self.ref.current);
}));
/**
* Atomically updates the value of the Ref using the given function and returns the new value.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(5)
*
*   // Update and get the new value in one operation
*   const newValue = yield* Ref.updateAndGet(counter, (n) => n * 3)
*   console.log(newValue) // 15
*
*   // Verify the ref contains the new value
*   const current = yield* Ref.get(counter)
*   console.log(current) // 15
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var updateAndGet$3 = /*#__PURE__*/ dual(2, (self, f) => sync$1(() => self.ref.current = f(self.ref.current)));
/**
* Atomically updates the value of the Ref using the given partial function.
*
* If the partial function returns `Option.some`, the Ref is updated with the new value.
* If it returns `Option.none`, the Ref is left unchanged.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
* import * as Option from "effect/Option"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(5)
*
*   // Only update if value is even
*   yield* Ref.updateSome(
*     counter,
*     (n) => n % 2 === 0 ? Option.some(n * 2) : Option.none()
*   )
*
*   let current = yield* Ref.get(counter)
*   console.log(current) // 5 (unchanged because 5 is odd)
*
*   // Set to even number and try again
*   yield* Ref.set(counter, 6)
*   yield* Ref.updateSome(
*     counter,
*     (n) => n % 2 === 0 ? Option.some(n * 2) : Option.none()
*   )
*
*   current = yield* Ref.get(counter)
*   console.log(current) // 12 (updated because 6 is even)
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var updateSome$2 = /*#__PURE__*/ dual(2, (self, f) => sync$1(() => {
	const option = f(self.ref.current);
	if (option._tag === "Some") self.ref.current = option.value;
}));
/**
* Atomically updates the value of the Ref using the given partial function and returns the current value.
*
* If the partial function returns `Option.some`, the Ref is updated with the new value.
* If it returns `Option.none`, the Ref is left unchanged.
* Returns the current value of the Ref after the potential update.
*
* @example
* ```ts
* import { Effect, Ref } from "effect"
* import * as Option from "effect/Option"
*
* const program = Effect.gen(function*() {
*   const counter = yield* Ref.make(10)
*
*   // Only update if value is greater than 5
*   const result1 = yield* Ref.updateSomeAndGet(
*     counter,
*     (n) => n > 5 ? Option.some(n / 2) : Option.none()
*   )
*   console.log(result1) // 5 (updated and returned)
*
*   // Try to update again with same condition
*   const result2 = yield* Ref.updateSomeAndGet(
*     counter,
*     (n) => n > 5 ? Option.some(n / 2) : Option.none()
*   )
*   console.log(result2) // 5 (unchanged because 5 is not > 5)
* })
* ```
*
* @since 2.0.0
* @category utils
*/
var updateSomeAndGet$2 = /*#__PURE__*/ dual(2, (self, pf) => sync$1(() => {
	const option = pf(self.ref.current);
	if (option._tag === "Some") self.ref.current = option.value;
	return self.ref.current;
}));
/**
* Gets the current value of the Ref synchronously (unsafe version).
*
* This function reads the current value without wrapping in Effect.
* Use this only when you're sure about the safety of immediate access.
*
* @example
* ```ts
* import { Ref } from "effect"
*
* // Create a ref directly
* const counter = Ref.makeUnsafe(42)
*
* // Get the value synchronously
* const value = Ref.getUnsafe(counter)
* console.log(value) // 42
*
* // Note: This is unsafe and should be used carefully
* // Prefer Ref.get for Effect-wrapped access
* ```
*
* @since 2.0.0
* @category getters
*/
var getUnsafe$5 = (self) => self.ref.current;
ErrorClass("~effect/persistence/Persistence/PersistenceError")({
	_tag: /*#__PURE__*/ tag$2("PersistenceError"),
	message: String$1,
	cause: /*#__PURE__*/ optional(Defect)
});
/**
* @since 4.0.0
* @category Models
*/
var Persistence = class extends Service$1()("effect/persistence/Persistence") {};
Service$1()("effect/persistence/BackingPersistence");
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/RequestResolver.js
var RequestResolver_exports = /* @__PURE__ */ __exportAll({
	around: () => around,
	asCache: () => asCache,
	batchN: () => batchN,
	fromEffect: () => fromEffect,
	fromEffectTagged: () => fromEffectTagged,
	fromFunction: () => fromFunction,
	fromFunctionBatched: () => fromFunctionBatched,
	grouped: () => grouped,
	isRequestResolver: () => isRequestResolver,
	make: () => make$16,
	makeGrouped: () => makeGrouped,
	makeWith: () => makeWith$1,
	never: () => never$1,
	persisted: () => persisted,
	race: () => race,
	setDelay: () => setDelay,
	setDelayEffect: () => setDelayEffect,
	withCache: () => withCache,
	withSpan: () => withSpan
});
var TypeId$17 = "~effect/RequestResolver";
var RequestResolverProto = {
	[TypeId$17]: {
		_A: identity,
		_R: identity
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Returns `true` if the specified value is a `RequestResolver`, `false` otherwise.
*
* @since 2.0.0
* @category guards
*/
var isRequestResolver = (u) => hasProperty(u, TypeId$17);
/**
* Low-level constructor for creating a request resolver with fine-grained
* control over its behavior.
*
* @since 4.0.0
* @category constructors
*/
var makeWith$1 = (options) => {
	const self = Object.create(RequestResolverProto);
	self.batchKey = options.batchKey;
	self.preCheck = options.preCheck;
	self.delay = options.delay;
	self.collectWhile = options.collectWhile;
	self.runAll = options.runAll;
	return self;
};
var defaultKeyObject = {};
var defaultKey = (_request) => defaultKeyObject;
/**
* Constructs a request resolver with the specified method to run requests.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* // Define a request type
* interface GetUserRequest extends Request.Request<string, Error> {
*   readonly _tag: "GetUserRequest"
*   readonly id: number
* }
* const GetUserRequest = Request.tagged<GetUserRequest>("GetUserRequest")
*
* // Create a resolver that handles the requests
* const UserResolver = RequestResolver.make<GetUserRequest>((entries) =>
*   Effect.sync(() => {
*     for (const entry of entries) {
*       // Complete each request with a result
*       entry.completeUnsafe(Exit.succeed(`User ${entry.request.id}`))
*     }
*   })
* )
*
* // Use the resolver to handle requests
* const getUserEffect = Effect.request(GetUserRequest({ id: 123 }), Effect.succeed(UserResolver))
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$16 = (runAll) => makeWith$1({
	batchKey: defaultKey,
	delay: yieldNow,
	collectWhile: constTrue,
	runAll
});
/**
* Constructs a request resolver with the requests grouped by a calculated key.
*
* The key can use the Equal trait to determine if two keys are equal.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetUserByRole extends Request.Request<string, Error> {
*   readonly _tag: "GetUserByRole"
*   readonly role: string
*   readonly id: number
* }
* const GetUserByRole = Request.tagged<GetUserByRole>("GetUserByRole")
*
* // Group requests by role for efficient batch processing
* const UserByRoleResolver = RequestResolver.makeGrouped<GetUserByRole, string>({
*   key: ({ request }) => request.role,
*   resolver: (entries, role) =>
*     Effect.sync(() => {
*       console.log(`Processing ${entries.length} requests for role: ${role}`)
*       for (const entry of entries) {
*         entry.completeUnsafe(
*           Exit.succeed(`User ${entry.request.id} with role ${role}`)
*         )
*       }
*     })
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var makeGrouped = (options) => makeWith$1({
	batchKey: hashGroupKey(options.key),
	delay: yieldNow,
	collectWhile: constTrue,
	runAll: options.resolver
});
var hashGroupKey = (get) => {
	const groupKeys = empty$12();
	return (entry) => {
		const key = get(entry);
		const okey = get$18(groupKeys, key);
		if (okey._tag === "Some") return okey.value;
		set$13(groupKeys, key, key);
		return key;
	};
};
/**
* Constructs a request resolver from a pure function.
*
* @example
* ```ts
* import { Effect, Request, RequestResolver } from "effect"
*
* interface GetSquareRequest extends Request.Request<number> {
*   readonly _tag: "GetSquareRequest"
*   readonly value: number
* }
* const GetSquareRequest = Request.tagged<GetSquareRequest>("GetSquareRequest")
*
* // Create a resolver from a pure function
* const SquareResolver = RequestResolver.fromFunction<GetSquareRequest>(
*   (entry) => entry.request.value * entry.request.value
* )
*
* // Usage
* const getSquareEffect = Effect.request(
*   GetSquareRequest({ value: 5 }),
*   Effect.succeed(SquareResolver)
* )
* // Will resolve to 25
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromFunction = (f) => make$16((entries) => sync$1(() => {
	for (let i = 0; i < entries.length; i++) {
		const entry = entries[i];
		entry.completeUnsafe(exitSucceed(f(entry)));
	}
}));
/**
* Constructs a request resolver from a pure function that takes a list of requests
* and returns a list of results of the same size. Each item in the result
* list must correspond to the item at the same index in the request list.
*
* @example
* ```ts
* import { Effect, Request, RequestResolver } from "effect"
*
* interface GetDoubleRequest extends Request.Request<number> {
*   readonly _tag: "GetDoubleRequest"
*   readonly value: number
* }
* const GetDoubleRequest = Request.tagged<GetDoubleRequest>("GetDoubleRequest")
*
* // Create a resolver that processes multiple requests in a batch
* const DoubleResolver = RequestResolver.fromFunctionBatched<GetDoubleRequest>(
*   (entries) => entries.map((entry) => entry.request.value * 2)
* )
*
* // Usage with multiple requests
* const effects = [1, 2, 3].map((value) =>
*   Effect.request(GetDoubleRequest({ value }), Effect.succeed(DoubleResolver))
* )
* const batchedEffect = Effect.all(effects) // [2, 4, 6]
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromFunctionBatched = (f) => make$16((entries) => sync$1(() => {
	let i = 0;
	for (const result of f(entries)) entries[i++].completeUnsafe(exitSucceed(result));
}));
/**
* Constructs a request resolver from an effectual function.
*
* @example
* ```ts
* import { Effect, Request, RequestResolver } from "effect"
*
* interface GetUserFromAPIRequest extends Request.Request<string> {
*   readonly _tag: "GetUserFromAPIRequest"
*   readonly id: number
* }
* const GetUserFromAPIRequest = Request.tagged<GetUserFromAPIRequest>(
*   "GetUserFromAPIRequest"
* )
*
* // Create a resolver that uses effects (like HTTP calls)
* const UserAPIResolver = RequestResolver.fromEffect<GetUserFromAPIRequest>(
*   (entry) =>
*     Effect.gen(function*() {
*       // Simulate an API call
*       yield* Effect.sleep("100 millis")
*       // Just return the result without error handling for simplicity
*       return `User ${entry.request.id} from API`
*     })
* )
*
* // Usage
* const getUserEffect = Effect.request(
*   GetUserFromAPIRequest({ id: 123 }),
*   Effect.succeed(UserAPIResolver)
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromEffect = (f) => {
	interruptChildrenPatch();
	return make$16((entries) => callback((resume) => {
		const parent = getCurrentFiber();
		let done = 0;
		for (let i = 0; i < entries.length; i++) {
			const entry = entries[i];
			forkUnsafe(parent, f(entry), true).addObserver((exit) => {
				entry.completeUnsafe(exit);
				done++;
				if (done === entries.length) resume(void_);
			});
		}
	}));
};
/**
* Constructs a request resolver from a list of tags paired to functions, that takes
* a list of requests and returns a list of results of the same size. Each item
* in the result list must correspond to the item at the same index in the
* request list.
*
* @example
* ```ts
* import type { Request } from "effect"
* import { Effect, RequestResolver } from "effect"
*
* interface GetUser extends Request.Request<string, Error> {
*   readonly _tag: "GetUser"
*   readonly id: number
* }
*
* interface GetPost extends Request.Request<string, Error> {
*   readonly _tag: "GetPost"
*   readonly id: number
* }
*
* type MyRequest = GetUser | GetPost
*
* // Create a resolver that handles different request types
* const MyResolver = RequestResolver.fromEffectTagged<MyRequest>()({
*   GetUser: (requests) =>
*     Effect.succeed(requests.map((req) => `User ${req.request.id}`)),
*   GetPost: (requests) =>
*     Effect.succeed(requests.map((req) => `Post ${req.request.id}`))
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromEffectTagged = () => (fns) => make$16((entries) => {
	const grouped = /* @__PURE__ */ new Map();
	for (let i = 0, len = entries.length; i < len; i++) {
		const group = grouped.get(entries[i].request._tag);
		if (group) group.push(entries[i]);
		else grouped.set(entries[i].request._tag, [entries[i]]);
	}
	return forEach$3(grouped, ([tag, requests]) => matchCause(fns[tag](requests), {
		onFailure: (cause) => {
			for (let i = 0; i < requests.length; i++) requests[i].completeUnsafe(exitFail(cause));
		},
		onSuccess: (res) => {
			for (let i = 0; i < res.length; i++) requests[i].completeUnsafe(exitSucceed(res[i]));
		}
	}), {
		concurrency: "unbounded",
		discard: true
	});
});
/**
* Sets the batch delay effect for this request resolver.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetDataRequest extends Request.Request<string> {
*   readonly _tag: "GetDataRequest"
* }
* const GetDataRequest = Request.tagged<GetDataRequest>("GetDataRequest")
*
* const resolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.sync(() => {
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed("data"))
*     }
*   })
* )
*
* // Set a custom delay effect (e.g., with logging)
* const resolverWithCustomDelay = RequestResolver.setDelayEffect(
*   resolver,
*   Effect.gen(function*() {
*     yield* Effect.log("Waiting before processing batch...")
*     yield* Effect.sleep("50 millis")
*   })
* )
* ```
*
* @since 4.0.0
* @category delay
*/
var setDelayEffect = /*#__PURE__*/ dual(2, (self, delay) => makeWith$1({
	...self,
	delay
}));
/**
* Sets the batch delay window for this request resolver to the specified duration.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetDataRequest extends Request.Request<string> {
*   readonly _tag: "GetDataRequest"
* }
* const GetDataRequest = Request.tagged<GetDataRequest>("GetDataRequest")
*
* const resolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.sync(() => {
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed("data"))
*     }
*   })
* )
*
* // Add a 100ms delay to batch requests together
* const delayedResolver = RequestResolver.setDelay(resolver, "100 millis")
*
* // Can also use number for milliseconds
* const delayedResolver2 = RequestResolver.setDelay(resolver, 100)
* ```
*
* @since 4.0.0
* @category delay
*/
var setDelay = /*#__PURE__*/ dual(2, (self, duration) => makeWith$1({
	...self,
	delay: sleep$1(duration)
}));
/**
* A request resolver aspect that executes requests between two effects, `before`
* and `after`, where the result of `before` can be used by `after`.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetDataRequest extends Request.Request<string> {
*   readonly _tag: "GetDataRequest"
* }
* const GetDataRequest = Request.tagged<GetDataRequest>("GetDataRequest")
*
* const resolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.sync(() => {
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed("data"))
*     }
*   })
* )
*
* // Add setup and cleanup around request execution
* const resolverWithAround = RequestResolver.around(
*   resolver,
*   (entries) =>
*     Effect.gen(function*() {
*       yield* Effect.log(`Starting batch of ${entries.length} requests`)
*       return Date.now()
*     }),
*   (entries, startTime) =>
*     Effect.gen(function*() {
*       const duration = Date.now() - startTime
*       yield* Effect.log(`Batch completed in ${duration}ms`)
*     })
* )
* ```
*
* @since 2.0.0
* @category combinators
*/
var around = /*#__PURE__*/ dual(3, (self, before, after) => makeWith$1({
	...self,
	runAll: (entries, key) => acquireUseRelease$1(before(entries), () => self.runAll(entries, key), (a) => after(entries, a))
}));
/**
* A request resolver that never executes requests.
*
* @since 2.0.0
* @category constructors
*/
var never$1 = /*#__PURE__*/ make$16(() => never$2);
/**
* Returns a request resolver that executes at most `n` requests in parallel.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetDataRequest extends Request.Request<string> {
*   readonly _tag: "GetDataRequest"
*   readonly id: number
* }
* const GetDataRequest = Request.tagged<GetDataRequest>("GetDataRequest")
*
* const resolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.sync(() => {
*     console.log(`Processing batch of ${entries.length} requests`)
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed(`data-${entry.request.id}`))
*     }
*   })
* )
*
* // Limit batches to maximum 5 requests
* const limitedResolver = RequestResolver.batchN(resolver, 5)
*
* // When more than 5 requests are made, they'll be split into multiple batches
* const requests = Array.from(
*   { length: 12 },
*   (_, i) => Effect.request(GetDataRequest({ id: i }), Effect.succeed(limitedResolver))
* )
* ```
*
* @since 2.0.0
* @category combinators
*/
var batchN = /*#__PURE__*/ dual(2, (self, n) => makeWith$1({
	...self,
	collectWhile: (requests) => requests.size < n
}));
/**
* Transform a request resolver by grouping requests using the specified key
* function.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetUserRequest extends Request.Request<string> {
*   readonly _tag: "GetUserRequest"
*   readonly userId: number
*   readonly department: string
* }
* const GetUserRequest = Request.tagged<GetUserRequest>("GetUserRequest")
*
* const resolver = RequestResolver.make<GetUserRequest>((entries) =>
*   Effect.sync(() => {
*     console.log(`Processing ${entries.length} users`)
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed(`User ${entry.request.userId}`))
*     }
*   })
* )
*
* // Group requests by department for more efficient processing
* const groupedResolver = RequestResolver.grouped(
*   resolver,
*   ({ request }) => request.department
* )
*
* // Requests for the same department will be batched together
* const requests = [
*   Effect.request(
*     GetUserRequest({ userId: 1, department: "Engineering" }),
*     Effect.succeed(groupedResolver)
*   ),
*   Effect.request(
*     GetUserRequest({ userId: 2, department: "Engineering" }),
*     Effect.succeed(groupedResolver)
*   ),
*   Effect.request(
*     GetUserRequest({ userId: 3, department: "Marketing" }),
*     Effect.succeed(groupedResolver)
*   )
* ]
* ```
*
* @since 4.0.0
* @category combinators
*/
var grouped = /*#__PURE__*/ dual(2, (self, f) => makeWith$1({
	...self,
	batchKey: hashGroupKey(f)
}));
/**
* Returns a new request resolver that executes requests by sending them to this
* request resolver and that request resolver, returning the results from the first data
* source to complete and safely interrupting the loser.
*
* The batch delay is determined by the first request resolver.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetDataRequest extends Request.Request<string> {
*   readonly _tag: "GetDataRequest"
*   readonly id: number
* }
* const GetDataRequest = Request.tagged<GetDataRequest>("GetDataRequest")
*
* // Fast resolver (simulating cache)
* const fastResolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.gen(function*() {
*     yield* Effect.sleep("10 millis")
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed(`fast-${entry.request.id}`))
*     }
*   })
* )
*
* // Slow resolver (simulating database)
* const slowResolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.gen(function*() {
*     yield* Effect.sleep("100 millis")
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed(`slow-${entry.request.id}`))
*     }
*   })
* )
*
* // Race resolvers - will use whichever completes first
* const racingResolver = RequestResolver.race(fastResolver, slowResolver)
* ```
*
* @since 2.0.0
* @category combinators
*/
var race = /*#__PURE__*/ dual(2, (self, that) => make$16((requests, key) => race$1(self.runAll(requests, key), that.runAll(requests, key))));
/**
* Add a tracing span to the request resolver, which will also add any span
* links from the request's.
*
* @example
* ```ts
* import { Effect, Exit, Request, RequestResolver } from "effect"
*
* interface GetDataRequest extends Request.Request<string> {
*   readonly _tag: "GetDataRequest"
*   readonly id: number
* }
* const GetDataRequest = Request.tagged<GetDataRequest>("GetDataRequest")
*
* const resolver = RequestResolver.make<GetDataRequest>((entries) =>
*   Effect.sync(() => {
*     for (const entry of entries) {
*       entry.completeUnsafe(Exit.succeed(`data-${entry.request.id}`))
*     }
*   })
* )
*
* // Add tracing span with custom name and attributes
* const tracedResolver = RequestResolver.withSpan(
*   resolver,
*   "user-data-resolver",
*   {
*     attributes: {
*       "resolver.type": "user-data",
*       "resolver.version": "1.0"
*     }
*   }
* )
*
* // Spans will automatically include batch size and request links
* const effect = Effect.request(GetDataRequest({ id: 123 }), Effect.succeed(tracedResolver))
* ```
*
* @since 4.0.0
* @category combinators
*/
var withSpan = /*#__PURE__*/ dual((args) => isRequestResolver(args[0]), (self, name, options) => makeWith$1({
	...self,
	runAll: (entries, key) => suspend(() => {
		const opts = typeof options === "function" ? options(entries) : options;
		const links = opts?.links ? opts.links.slice() : [];
		const seen = /* @__PURE__ */ new Set();
		for (const entry of entries) {
			const span = getOption$2(entry.services, ParentSpan);
			if (span._tag === "None" || seen.has(span.value)) continue;
			seen.add(span.value);
			links.push({
				span: span.value,
				attributes: {}
			});
		}
		return withSpan$1(self.runAll(entries, key), name, {
			...options,
			links,
			attributes: {
				batchSize: entries.length,
				...opts?.attributes
			}
		});
	})
}));
/**
* Wraps a request resolver in a cache, allowing it to cache results up to a
* specified capacity and optional time-to-live.
*
* @since 4.0.0
* @category Caching
*/
var asCache = /*#__PURE__*/ dual(2, (self, options) => makeWith$2({
	capacity: options.capacity,
	timeToLive: options.timeToLive,
	requireServicesAt: options.requireServicesAt ?? "lookup",
	lookup: (req) => request(req, succeed$4(self))
}));
/**
* Adds caching capabilities to a request resolver, allowing it to cache
* results up to a specified capacity.
*
* @since 4.0.0
* @category Caching
*/
var withCache = /*#__PURE__*/ dual(2, (self, options) => sync$1(() => {
	const strategy = options.strategy ?? "lru";
	const cache = empty$12();
	return makeWith$1({
		...self,
		runAll(entries, key) {
			return onExit$1(self.runAll(entries, key), () => {
				let toRemove = size$15(cache) - options.capacity;
				if (toRemove <= 0) return void_$1;
				for (const k of keys$6(cache)) {
					remove$9(cache, k);
					toRemove--;
					if (toRemove <= 0) break;
				}
				return void_$1;
			});
		},
		preCheck(entry) {
			const ocached = get$18(cache, entry.request);
			if (ocached._tag === "None") {
				const cached = {
					entry,
					exit: void 0
				};
				set$13(cache, entry.request, cached);
				const prevComplete = entry.completeUnsafe;
				entry.completeUnsafe = function(exit) {
					cached.exit = exit;
					prevComplete(exit);
				};
				return true;
			}
			const cached = ocached.value;
			if (cached.exit) {
				if (strategy === "lru") {
					remove$9(cache, cached.entry.request);
					set$13(cache, cached.entry.request, cached);
				}
				entry.completeUnsafe(cached.exit);
			} else {
				cached.entry.uninterruptible = true;
				const prevComplete = cached.entry.completeUnsafe;
				cached.entry.completeUnsafe = function(exit) {
					prevComplete(exit);
					entry.completeUnsafe(exit);
				};
			}
			return false;
		}
	});
}));
/**
* @since 4.0.0
* @category Persistence
*/
var persisted = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, options) {
	const store = yield* (yield* Persistence).make(options);
	return makeWith$1({
		...self,
		runAll: fnUntraced(function* (entries, key) {
			const results = yield* store.getMany(map$10(entries, (_) => _.request)).pipe(provideServices(entries[0].services));
			const leftover = [];
			const toPersist = /* @__PURE__ */ new Map();
			for (let i = 0; i < results.length; i++) {
				const entry = entries[i];
				const exit = results[i];
				if (exit === void 0 || options.staleWhileRevalidate && options.staleWhileRevalidate(exit, entry.request)) {
					const prevComplete = entry.completeUnsafe;
					entry.completeUnsafe = function(exit) {
						toPersist.set(entry.request, exit);
						prevComplete(exit);
					};
					leftover.push(entry);
					if (exit === void 0) continue;
				}
				entry.completeUnsafe(exit);
			}
			if (!isArrayNonEmpty(leftover)) return;
			yield* catchCause$1(self.runAll(leftover, key), (cause) => {
				for (let i = 0; i < leftover.length; i++) {
					const entry = leftover[i];
					if (!toPersist.has(entry.request)) continue;
					entry.completeUnsafe(failCause$1(cause));
				}
				return void_$1;
			});
			yield* store.setMany(toPersist).pipe(provideServices(entries[0].services));
		})
	});
}));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/SynchronizedRef.js
/**
* @since 2.0.0
*/
var SynchronizedRef_exports = /* @__PURE__ */ __exportAll({
	get: () => get$10,
	getAndSet: () => getAndSet$2,
	getAndUpdate: () => getAndUpdate$2,
	getAndUpdateEffect: () => getAndUpdateEffect$1,
	getAndUpdateSome: () => getAndUpdateSome$1,
	getAndUpdateSomeEffect: () => getAndUpdateSomeEffect$1,
	getUnsafe: () => getUnsafe$4,
	make: () => make$15,
	makeUnsafe: () => makeUnsafe$4,
	modify: () => modify$7,
	modifyEffect: () => modifyEffect$1,
	modifySome: () => modifySome$1,
	modifySomeEffect: () => modifySomeEffect$1,
	set: () => set$7,
	setAndGet: () => setAndGet$1,
	update: () => update$4,
	updateAndGet: () => updateAndGet$2,
	updateAndGetEffect: () => updateAndGetEffect$1,
	updateEffect: () => updateEffect$1,
	updateSome: () => updateSome$1,
	updateSomeAndGet: () => updateSomeAndGet$1,
	updateSomeAndGetEffect: () => updateSomeAndGetEffect$1,
	updateSomeEffect: () => updateSomeEffect$1
});
var TypeId$16 = "~effect/SynchronizedRef";
var Proto$4 = {
	...PipeInspectableProto,
	[TypeId$16]: TypeId$16,
	toJSON() {
		return {
			_id: "SynchronizedRef",
			value: this.backing.ref.current
		};
	}
};
/**
* @since 4.0.0
* @category constructors
*/
var makeUnsafe$4 = (value) => {
	const self = Object.create(Proto$4);
	self.semaphore = makeUnsafe$10(1);
	self.backing = makeUnsafe$5(value);
	return self;
};
/**
* @since 2.0.0
* @category constructors
*/
var make$15 = (value) => sync$1(() => makeUnsafe$4(value));
/**
* @since 2.0.0
* @category getters
*/
var getUnsafe$4 = (self) => self.backing.ref.current;
/**
* @since 2.0.0
* @category getters
*/
var get$10 = (self) => sync$1(() => getUnsafe$4(self));
/**
* @since 2.0.0
* @category utils
*/
var getAndSet$2 = /*#__PURE__*/ dual(2, (self, value) => self.semaphore.withPermit(getAndSet$3(self.backing, value)));
/**
* @since 2.0.0
* @category utils
*/
var getAndUpdate$2 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(getAndUpdate$3(self.backing, f)));
/**
* @since 2.0.0
* @category utils
*/
var getAndUpdateEffect$1 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(suspend(() => {
	const value = getUnsafe$4(self);
	return map$11(f(value), (newValue) => {
		self.backing.ref.current = newValue;
		return value;
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var getAndUpdateSome$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(getAndUpdateSome$2(self, pf)));
/**
* @since 2.0.0
* @category utils
*/
var getAndUpdateSomeEffect$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(suspend(() => {
	const value = getUnsafe$4(self);
	return flatMap$2(pf(value), (option) => {
		if (isNone(option)) return succeed$4(value);
		self.backing.ref.current = option.value;
		return succeed$4(value);
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var modify$7 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(modify$8(self.backing, f)));
/**
* @since 2.0.0
* @category utils
*/
var modifyEffect$1 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(suspend(() => {
	return map$11(f(getUnsafe$4(self)), ([b, a]) => {
		self.backing.ref.current = a;
		return b;
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var modifySome$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(modifySome$2(self.backing, pf)));
/**
* @since 2.0.0
* @category utils
*/
var modifySomeEffect$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(suspend(() => {
	return flatMap$2(pf(getUnsafe$4(self)), ([b, maybeA]) => {
		if (isNone(maybeA)) return succeed$4(b);
		self.backing.ref.current = maybeA.value;
		return succeed$4(b);
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var set$7 = /*#__PURE__*/ dual(2, (self, value) => self.semaphore.withPermit(set$8(self.backing, value)));
/**
* @since 2.0.0
* @category utils
*/
var setAndGet$1 = /*#__PURE__*/ dual(2, (self, value) => self.semaphore.withPermit(setAndGet$2(self.backing, value)));
/**
* @since 2.0.0
* @category utils
*/
var update$4 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(update$5(self.backing, f)));
/**
* @since 2.0.0
* @category utils
*/
var updateEffect$1 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(suspend(() => {
	return map$11(f(getUnsafe$4(self)), (newValue) => {
		self.backing.ref.current = newValue;
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var updateAndGet$2 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(updateAndGet$3(self.backing, f)));
/**
* @since 2.0.0
* @category utils
*/
var updateAndGetEffect$1 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(suspend(() => {
	return map$11(f(getUnsafe$4(self)), (newValue) => {
		self.backing.ref.current = newValue;
		return newValue;
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var updateSome$1 = /*#__PURE__*/ dual(2, (self, f) => self.semaphore.withPermit(updateSome$2(self.backing, f)));
/**
* @since 2.0.0
* @category utils
*/
var updateSomeEffect$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(suspend(() => {
	return map$11(pf(getUnsafe$4(self)), (option) => {
		if (isNone(option)) return;
		self.backing.ref.current = option.value;
	});
})));
/**
* @since 2.0.0
* @category utils
*/
var updateSomeAndGet$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(updateSomeAndGet$2(self.backing, pf)));
/**
* @since 2.0.0
* @category utils
*/
var updateSomeAndGetEffect$1 = /*#__PURE__*/ dual(2, (self, pf) => self.semaphore.withPermit(suspend(() => {
	const value = getUnsafe$4(self);
	return flatMap$2(pf(value), (option) => {
		if (isNone(option)) return succeed$4(value);
		self.backing.ref.current = option.value;
		return succeed$4(option.value);
	});
})));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ScopedRef.js
/**
* @since 2.0.0
*/
var ScopedRef_exports = /* @__PURE__ */ __exportAll({
	fromAcquire: () => fromAcquire,
	get: () => get$9,
	getUnsafe: () => getUnsafe$3,
	make: () => make$14,
	set: () => set$6
});
var TypeId$15 = "~effect/ScopedRef";
var Proto$3 = {
	...PipeInspectableProto,
	[TypeId$15]: TypeId$15,
	toJSON() {
		return {
			_id: "ScopedRef",
			value: this.backing.backing.ref.current[1]
		};
	}
};
var makeUnsafe$3 = (scope, value) => {
	const self = Object.create(Proto$3);
	self.backing = makeUnsafe$4([scope, value]);
	return self;
};
/**
* Creates a new `ScopedRef` from an effect that resourcefully produces a
* value.
*
* @since 2.0.0
* @category constructors
*/
var fromAcquire = /*#__PURE__*/ fnUntraced(function* (acquire) {
	const scope = makeUnsafe$9();
	const self = makeUnsafe$3(scope, yield* acquire.pipe(provide$2(scope), tapCause((cause) => close(scope, failCause$1(cause)))));
	yield* addFinalizer$1((exit) => close(self.backing.backing.ref.current[0], exit));
	return self;
}, uninterruptible);
/**
* Retrieves the current value of the scoped reference.
*
* @since 4.0.0
* @category getters
*/
var getUnsafe$3 = (self) => self.backing.backing.ref.current[1];
/**
* Retrieves the current value of the scoped reference.
*
* @since 2.0.0
* @category getters
*/
var get$9 = (self) => sync$1(() => getUnsafe$3(self));
/**
* Creates a new `ScopedRef` from the specified value. This method should
* not be used for values whose creation require the acquisition of resources.
*
* @since 2.0.0
* @category constructors
*/
var make$14 = (evaluate) => suspend(() => {
	const self = makeUnsafe$3(makeUnsafe$9(), evaluate());
	return as$1(addFinalizer$1((exit) => close(self.backing.backing.ref.current[0], exit)), self);
});
/**
* Sets the value of this reference to the specified resourcefully-created
* value. Any resources associated with the old value will be released.
*
* This method will not return until either the reference is successfully
* changed to the new value, with old resources released, or until the attempt
* to acquire a new value fails.
*
* @since 2.0.0
* @category getters
*/
var set$6 = /*#__PURE__*/ dual(2, /*#__PURE__*/ fnUntraced(function* (self, acquire) {
	yield* close(self.backing.backing.ref.current[0], void_$2);
	const scope = makeUnsafe$9();
	const value = yield* acquire.pipe(provide$2(scope), tapCause((cause) => close(scope, failCause$1(cause))));
	self.backing.backing.ref.current = [scope, value];
}, uninterruptible, (effect, self) => self.backing.semaphore.withPermit(effect)));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Resource.js
/**
* @since 2.0.0
*/
var Resource_exports = /* @__PURE__ */ __exportAll({
	auto: () => auto,
	get: () => get$8,
	isResource: () => isResource,
	manual: () => manual,
	refresh: () => refresh$1
});
var TypeId$14 = "~effect/Resource";
/**
* @since 2.0.0
* @category guards
*/
var isResource = (u) => typeof u === "object" && u !== null && TypeId$14 in u;
var Proto$2 = {
	...PipeInspectableProto,
	[TypeId$14]: TypeId$14,
	toJSON() {
		return { _id: "Resource" };
	}
};
var makeUnsafe$2 = (scopedRef, acquire) => {
	const self = Object.create(Proto$2);
	self.scopedRef = scopedRef;
	self.acquire = acquire;
	return self;
};
/**
* Creates a `Resource` that must be refreshed manually.
*
* @since 2.0.0
* @category constructors
*/
var manual = (acquire) => servicesWith$1((services) => {
	const providedAcquire = updateServices$1(acquire, (input) => merge(services, input));
	return map$11(fromAcquire(exit(providedAcquire)), (scopedRef) => makeUnsafe$2(scopedRef, providedAcquire));
});
/**
* Creates a `Resource` that refreshes automatically according to the supplied
* schedule.
*
* @since 2.0.0
* @category constructors
*/
var auto = (acquire, policy) => tap(manual(acquire), (self) => forkScoped(repeat(refresh$1(self), policy)));
/**
* Retrieves the current value stored in this resource.
*
* @since 2.0.0
* @category getters
*/
var get$8 = (self) => flatMap$2(get$9(self.scopedRef), identity);
/**
* Refreshes this resource.
*
* @since 2.0.0
* @category utils
*/
var refresh$1 = (self) => set$6(self.scopedRef, map$11(self.acquire, succeed$6));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Runtime.js
/**
* This module provides utilities for running Effect programs and managing their execution lifecycle.
*
* The Runtime module contains functions for creating main program runners that handle process
* teardown, error reporting, and exit code management. These utilities are particularly useful
* for creating CLI applications and server processes that need to manage their lifecycle properly.
*
* @example
* ```ts
* import { Effect, Fiber, Runtime } from "effect"
*
* // Create a main runner for Node.js
* const runMain = Runtime.makeRunMain((options) => {
*   process.on("SIGINT", () => Effect.runFork(Fiber.interrupt(options.fiber)))
*   process.on("SIGTERM", () => Effect.runFork(Fiber.interrupt(options.fiber)))
*
*   options.fiber.addObserver((exit) => {
*     options.teardown(exit, (code) => process.exit(code))
*   })
* })
*
* // Use the runner
* const program = Effect.log("Hello, World!")
* runMain(program)
* ```
*
* @since 4.0.0
*/
var Runtime_exports = /* @__PURE__ */ __exportAll({
	defaultTeardown: () => defaultTeardown,
	makeRunMain: () => makeRunMain
});
/**
* The default teardown function that determines exit codes based on Effect completion.
*
* This teardown function follows standard Unix conventions:
* - Returns exit code 0 for successful completion
* - Returns exit code 1 for failures (except interruption-only failures)
* - Returns exit code 0 for interruption-only failures
*
* @example
* ```ts
* import { Effect, Exit, Runtime } from "effect"
*
* // The default teardown behavior
* const program1 = Effect.succeed(42)
* const program2 = Effect.fail("error")
* const program3 = Effect.interrupt
*
* // Using defaultTeardown directly
* const logExitCode = (exit: Exit.Exit<any, any>) => {
*   Runtime.defaultTeardown(exit, (code) => {
*     console.log(`Exit code: ${code}`)
*   })
* }
*
* // Success case - exit code 0
* logExitCode(Exit.succeed(42))
*
* // Failure case - exit code 1
* logExitCode(Exit.fail("error"))
*
* // Interruption case - exit code 0
* logExitCode(Exit.interrupt(123))
* ```
*
* @category Teardown
* @since 4.0.0
*/
var defaultTeardown = (exit, onExit) => {
	onExit(isFailure(exit) ? hasInterruptsOnly(exit.cause) ? 130 : 1 : 0);
};
/**
* Creates a platform-specific main program runner that handles Effect execution lifecycle.
*
* This function creates a runner that can execute Effect programs as main entry points,
* handling process signals, fiber management, and teardown operations. The provided
* function receives a fiber and teardown callback to implement platform-specific behavior.
*
* @param f - Function that sets up platform-specific behavior for the running Effect
*
* @example
* ```ts
* import { Effect, Fiber, Runtime } from "effect"
*
* // Create a simple runner for a hypothetical platform
* const runMain = Runtime.makeRunMain(({ fiber, teardown }) => {
*   // Set up signal handling
*   const handleSignal = () => {
*     Effect.runSync(Fiber.interrupt(fiber))
*   }
*
*   // Add signal listeners (platform-specific)
*   // process.on('SIGINT', handleSignal)
*   // process.on('SIGTERM', handleSignal)
*
*   // Handle fiber completion
*   fiber.addObserver((exit) => {
*     teardown(exit, (code) => {
*       console.log(`Program finished with exit code: ${code}`)
*       // process.exit(code)
*     })
*   })
* })
*
* // Use the runner
* const program = Effect.gen(function*() {
*   yield* Effect.log("Starting program")
*   yield* Effect.sleep(1000)
*   yield* Effect.log("Program completed")
*   return "success"
* })
*
* // Run with default options
* runMain(program)
*
* // Run with custom teardown
* runMain(program, {
*   teardown: (exit, onExit) => {
*     console.log("Custom teardown logic")
*     Runtime.defaultTeardown(exit, onExit)
*   }
* })
* ```
*
* @category Run main
* @since 4.0.0
*/
var makeRunMain = (f) => dual((args) => isEffect$1(args[0]), (effect, options) => {
	const fiber = options?.disableErrorReporting === true ? runFork(effect) : runFork(tapCause(effect, (cause) => {
		if (hasInterruptsOnly(cause)) return void_$1;
		return logError(cause);
	}));
	try {
		const keepAlive = globalThis.setInterval(constVoid, 2147483647);
		fiber.addObserver(() => {
			clearInterval(keepAlive);
		});
	} catch {}
	return f({
		fiber,
		teardown: options?.teardown ?? defaultTeardown
	});
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/SchemaRepresentation.js
/**
* Serializable intermediate representation (IR) of Effect Schema types.
*
* `SchemaRepresentation` sits between the internal `SchemaAST` and external
* formats (JSON Schema, generated TypeScript code, serialized JSON). A
* {@link Representation} is a discriminated union describing the *shape* of a
* schema — its types, checks, annotations, and references — in a form that
* can be round-tripped through JSON and used for code generation.
*
* ## Mental model
*
* - **Representation**: A tagged union (`_tag`) of all supported schema shapes:
*   primitives, literals, objects, arrays, unions, declarations, references,
*   and suspensions.
* - **Document**: A single {@link Representation} paired with a map of named
*   {@link References} (analogous to JSON Schema `$defs`).
* - **MultiDocument**: Like `Document` but holds one or more representations
*   sharing the same references.
* - **Check / Filter / FilterGroup**: Validation constraints (min length,
*   pattern, integer, etc.) attached to types that support them.
* - **Meta types**: Typed metadata for checks on each category — e.g.
*   {@link StringMeta}, {@link NumberMeta}, {@link ArraysMeta}.
* - **Reviver**: A callback used by {@link toSchema} and {@link toCodeDocument}
*   to handle `Declaration` nodes (custom types like `Option`, `Date`, etc.).
* - **Code / CodeDocument**: Output of {@link toCodeDocument} — TypeScript
*   source strings for runtime schemas and their type-level counterparts.
*
* ## Common tasks
*
* - Convert a Schema AST to a Document → {@link fromAST}
* - Convert multiple ASTs to a MultiDocument → {@link fromASTs}
* - Reconstruct a runtime Schema from a Document → {@link toSchema}
* - Convert a Document to JSON Schema → {@link toJsonSchemaDocument}
* - Convert a MultiDocument to JSON Schema → {@link toJsonSchemaMultiDocument}
* - Parse a JSON Schema document into a Document → {@link fromJsonSchemaDocument}
* - Parse a JSON Schema multi-document → {@link fromJsonSchemaMultiDocument}
* - Generate TypeScript code from a MultiDocument → {@link toCodeDocument}
* - Serialize/deserialize a Document as JSON → {@link DocumentFromJson}
* - Serialize/deserialize a MultiDocument as JSON → {@link MultiDocumentFromJson}
* - Wrap a Document as a MultiDocument → {@link toMultiDocument}
*
* ## Gotchas
*
* - `Declaration` nodes require a {@link Reviver} to reconstruct complex types
*   (e.g. `Option`, `Date`). Without one, `toSchema` falls back to the
*   declaration's `encodedSchema`. Use {@link toSchemaDefaultReviver} for
*   built-in Effect types.
* - `Reference` nodes are resolved against the `references` map in the
*   `Document`. An unresolvable `$ref` throws at runtime.
* - `Suspend` wraps a single `thunk` representation; it is used for recursive
*   schemas. Circular references are handled by lazy resolution in
*   {@link toSchema}.
* - The `$`-prefixed exports (e.g. {@link $Representation}, {@link $Document})
*   are Schema codecs for the representation types themselves — use them to
*   validate or encode/decode representation data, not application data.
*
* ## Quickstart
*
* **Example** (Round-trip through JSON)
*
* ```ts
* import { Schema, SchemaRepresentation } from "effect"
*
* const Person = Schema.Struct({
*   name: Schema.String,
*   age: Schema.Int
* })
*
* // Schema AST → Document
* const doc = SchemaRepresentation.fromAST(Person.ast)
*
* // Document → JSON Schema
* const jsonSchema = SchemaRepresentation.toJsonSchemaDocument(doc)
*
* // Document → runtime Schema
* const reconstructed = SchemaRepresentation.toSchema(doc)
* ```
*
* ## See also
*
* - {@link Representation} — the core tagged union
* - {@link Document} — single-schema container
* - {@link fromAST} — entry point from Schema AST
* - {@link toSchema} — reconstruct a runtime Schema
* - {@link toCodeDocument} — generate TypeScript code
*
* @since 4.0.0
*/
var SchemaRepresentation_exports = /* @__PURE__ */ __exportAll({
	$Annotations: () => $Annotations,
	$Any: () => $Any,
	$Arrays: () => $Arrays,
	$BigInt: () => $BigInt,
	$Boolean: () => $Boolean,
	$DateMeta: () => $DateMeta,
	$Declaration: () => $Declaration,
	$DeclarationMeta: () => $DeclarationMeta,
	$Document: () => $Document,
	$Element: () => $Element,
	$Enum: () => $Enum,
	$IndexSignature: () => $IndexSignature,
	$Literal: () => $Literal,
	$LiteralValue: () => $LiteralValue,
	$MultiDocument: () => $MultiDocument,
	$Never: () => $Never,
	$Null: () => $Null,
	$Number: () => $Number,
	$NumberMeta: () => $NumberMeta,
	$ObjectKeyword: () => $ObjectKeyword,
	$Objects: () => $Objects,
	$ObjectsMeta: () => $ObjectsMeta,
	$PrimitiveTree: () => $PrimitiveTree,
	$PropertySignature: () => $PropertySignature,
	$Reference: () => $Reference,
	$Representation: () => $Representation,
	$SizeMeta: () => $SizeMeta,
	$String: () => $String,
	$StringMeta: () => $StringMeta,
	$Suspend: () => $Suspend,
	$Symbol: () => $Symbol,
	$TemplateLiteral: () => $TemplateLiteral,
	$Undefined: () => $Undefined,
	$Union: () => $Union,
	$UniqueSymbol: () => $UniqueSymbol,
	$Unknown: () => $Unknown,
	$Void: () => $Void,
	DocumentFromJson: () => DocumentFromJson,
	MultiDocumentFromJson: () => MultiDocumentFromJson,
	fromAST: () => fromAST,
	fromASTs: () => fromASTs,
	fromJsonSchemaDocument: () => fromJsonSchemaDocument,
	fromJsonSchemaMultiDocument: () => fromJsonSchemaMultiDocument,
	makeCode: () => makeCode,
	sanitizeJavaScriptIdentifier: () => sanitizeJavaScriptIdentifier,
	toCodeDocument: () => toCodeDocument,
	toJsonSchemaDocument: () => toJsonSchemaDocument,
	toJsonSchemaMultiDocument: () => toJsonSchemaMultiDocument,
	toMultiDocument: () => toMultiDocument,
	toSchema: () => toSchema,
	toSchemaDefaultReviver: () => toSchemaDefaultReviver,
	topologicalSort: () => topologicalSort
});
var Representation$ref = /*#__PURE__*/ suspend$2(() => $Representation);
var toJsonAnnotationsBlacklist = /*#__PURE__*/ new Set([
	...fromASTBlacklist,
	"expected",
	"contentMediaType",
	"contentSchema"
]);
/**
* Schema codec for {@link PrimitiveTree}.
*
* @category Schema
* @since 4.0.0
*/
var $PrimitiveTree = /*#__PURE__*/ Tree(/*#__PURE__*/ Union([
	Null,
	Number$1,
	Boolean$1,
	BigInt$3,
	Symbol$1,
	String$1
]));
var isPrimitiveTree = /*#__PURE__*/ is$2($PrimitiveTree);
/**
* Schema codec for `Schema.Annotations.Annotations`. Filters out internal
* annotation keys and non-primitive values during encoding.
*
* @category Schema
* @since 4.0.0
*/
var $Annotations = /*#__PURE__*/ Record$1(String$1, Unknown).pipe(encodeTo(Record$1(String$1, $PrimitiveTree), {
	decode: passthrough(),
	encode: transformOptional(flatMap$1((r) => {
		const out = {};
		for (const [k, v] of Object.entries(r)) if (!toJsonAnnotationsBlacklist.has(k) && isPrimitiveTree(v)) out[k] = v;
		return isEmptyRecord(out) ? none() : some$2(out);
	}))
})).annotate({ identifier: "Annotations" });
/**
* Schema codec for the {@link Null} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Null = /*#__PURE__*/ Struct({
	_tag: tag$2("Null"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Null" });
/**
* Schema codec for the {@link Undefined} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Undefined = /*#__PURE__*/ Struct({
	_tag: tag$2("Undefined"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Undefined" });
/**
* Schema codec for the {@link Void} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Void = /*#__PURE__*/ Struct({
	_tag: tag$2("Void"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Void" });
/**
* Schema codec for the {@link Never} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Never = /*#__PURE__*/ Struct({
	_tag: tag$2("Never"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Never" });
/**
* Schema codec for the {@link Unknown} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Unknown = /*#__PURE__*/ Struct({
	_tag: tag$2("Unknown"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Unknown" });
/**
* Schema codec for the {@link Any} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Any = /*#__PURE__*/ Struct({
	_tag: tag$2("Any"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Any" });
var $IsStringFinite = /*#__PURE__*/ Struct({
	_tag: tag$2("isStringFinite"),
	regExp: RegExp$1
}).annotate({ identifier: "IsStringFinite" });
var $IsStringBigInt = /*#__PURE__*/ Struct({
	_tag: tag$2("isStringBigInt"),
	regExp: RegExp$1
}).annotate({ identifier: "IsStringBigInt" });
var $IsStringSymbol = /*#__PURE__*/ Struct({
	_tag: tag$2("isStringSymbol"),
	regExp: RegExp$1
}).annotate({ identifier: "IsStringSymbol" });
var $IsTrimmed = /*#__PURE__*/ Struct({
	_tag: tag$2("isTrimmed"),
	regExp: RegExp$1
}).annotate({ identifier: "IsTrimmed" });
var $IsUUID = /*#__PURE__*/ Struct({
	_tag: tag$2("isUUID"),
	regExp: RegExp$1,
	version: UndefinedOr(Literals([
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	]))
}).annotate({ identifier: "IsUUID" });
var $IsULID = /*#__PURE__*/ Struct({
	_tag: tag$2("isULID"),
	regExp: RegExp$1
}).annotate({ identifier: "IsULID" });
var $IsBase64 = /*#__PURE__*/ Struct({
	_tag: tag$2("isBase64"),
	regExp: RegExp$1
}).annotate({ identifier: "IsBase64" });
var $IsBase64Url = /*#__PURE__*/ Struct({
	_tag: tag$2("isBase64Url"),
	regExp: RegExp$1
}).annotate({ identifier: "IsBase64Url" });
var $IsStartsWith = /*#__PURE__*/ Struct({
	_tag: tag$2("isStartsWith"),
	startsWith: String$1,
	regExp: RegExp$1
}).annotate({ identifier: "IsStartsWith" });
var $IsEndsWith = /*#__PURE__*/ Struct({
	_tag: tag$2("isEndsWith"),
	endsWith: String$1,
	regExp: RegExp$1
}).annotate({ identifier: "IsEndsWith" });
var $IsIncludes = /*#__PURE__*/ Struct({
	_tag: tag$2("isIncludes"),
	includes: String$1,
	regExp: RegExp$1
}).annotate({ identifier: "IsIncludes" });
var $IsUppercased = /*#__PURE__*/ Struct({
	_tag: tag$2("isUppercased"),
	regExp: RegExp$1
}).annotate({ identifier: "IsUppercased" });
var $IsLowercased = /*#__PURE__*/ Struct({
	_tag: tag$2("isLowercased"),
	regExp: RegExp$1
}).annotate({ identifier: "IsLowercased" });
var $IsCapitalized = /*#__PURE__*/ Struct({
	_tag: tag$2("isCapitalized"),
	regExp: RegExp$1
}).annotate({ identifier: "IsCapitalized" });
var $IsUncapitalized = /*#__PURE__*/ Struct({
	_tag: tag$2("isUncapitalized"),
	regExp: RegExp$1
}).annotate({ identifier: "IsUncapitalized" });
var NonNegativeInt = /*#__PURE__*/ Int.check(/*#__PURE__*/ isGreaterThanOrEqualTo$2(0));
var $IsMinLength = /*#__PURE__*/ Struct({
	_tag: tag$2("isMinLength"),
	minLength: NonNegativeInt
}).annotate({ identifier: "IsMinLength" });
var $IsMaxLength = /*#__PURE__*/ Struct({
	_tag: tag$2("isMaxLength"),
	maxLength: NonNegativeInt
}).annotate({ identifier: "IsMaxLength" });
var $IsLengthBetween = /*#__PURE__*/ Struct({
	_tag: tag$2("isLengthBetween"),
	minimum: NonNegativeInt,
	maximum: NonNegativeInt
}).annotate({ identifier: "IsLengthBetween" });
/**
* Schema codec for {@link StringMeta}.
*
* @category Schema
* @since 4.0.0
*/
var $StringMeta = /*#__PURE__*/ Union([
	$IsStringFinite,
	$IsStringBigInt,
	$IsStringSymbol,
	$IsTrimmed,
	$IsUUID,
	$IsULID,
	$IsBase64,
	$IsBase64Url,
	$IsStartsWith,
	$IsEndsWith,
	$IsIncludes,
	$IsUppercased,
	$IsLowercased,
	$IsCapitalized,
	$IsUncapitalized,
	$IsMinLength,
	$IsMaxLength,
	/* @__PURE__ */ Struct({
		_tag: tag$2("isPattern"),
		regExp: RegExp$1
	}).annotate({ identifier: "IsPattern" }),
	$IsLengthBetween
]).annotate({ identifier: "StringMeta" });
function makeCheck(meta, identifier) {
	const Check$ref = suspend$2(() => Check);
	const Check = Union([Struct({
		_tag: tag$2("Filter"),
		annotations: optional($Annotations),
		meta
	}).annotate({ identifier: `${identifier}Filter` }), Struct({
		_tag: tag$2("FilterGroup"),
		annotations: optional($Annotations),
		checks: NonEmptyArray(Check$ref)
	}).annotate({ identifier: `${identifier}FilterGroup` })]).annotate({ identifier: `${identifier}Check` });
	return Check;
}
/**
* Schema codec for the {@link String} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $String = /*#__PURE__*/ Struct({
	_tag: tag$2("String"),
	annotations: optional($Annotations),
	checks: Array$1(makeCheck($StringMeta, "String")),
	contentMediaType: optional(String$1),
	contentSchema: optional(Representation$ref)
}).annotate({ identifier: "String" });
/**
* Schema codec for {@link NumberMeta}.
*
* @category Schema
* @since 4.0.0
*/
var $NumberMeta = /*#__PURE__*/ Union([
	/* @__PURE__ */ Struct({ _tag: tag$2("isInt") }).annotate({ identifier: "IsInt" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isMultipleOf"),
		divisor: Finite
	}).annotate({ identifier: "IsMultipleOf" }),
	/* @__PURE__ */ Struct({ _tag: tag$2("isFinite") }).annotate({ identifier: "IsFinite" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isGreaterThan"),
		exclusiveMinimum: Finite
	}).annotate({ identifier: "IsGreaterThan" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isGreaterThanOrEqualTo"),
		minimum: Finite
	}).annotate({ identifier: "IsGreaterThanOrEqualTo" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isLessThan"),
		exclusiveMaximum: Finite
	}).annotate({ identifier: "IsLessThan" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isLessThanOrEqualTo"),
		maximum: Finite
	}).annotate({ identifier: "IsLessThanOrEqualTo" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isBetween"),
		minimum: Finite,
		maximum: Finite,
		exclusiveMinimum: optional(Boolean$1),
		exclusiveMaximum: optional(Boolean$1)
	}).annotate({ identifier: "IsBetween" })
]).annotate({ identifier: "NumberMeta" });
/**
* Schema codec for the {@link Number} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Number = /*#__PURE__*/ Struct({
	_tag: tag$2("Number"),
	annotations: optional($Annotations),
	checks: Array$1(makeCheck($NumberMeta, "Number"))
}).annotate({ identifier: "Number" });
/**
* Schema codec for the {@link Boolean} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Boolean = /*#__PURE__*/ Struct({
	_tag: tag$2("Boolean"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Boolean" });
var $BigIntMeta = /*#__PURE__*/ Union([
	/* @__PURE__ */ Struct({
		_tag: tag$2("isGreaterThanBigInt"),
		exclusiveMinimum: BigInt$3
	}).annotate({ identifier: "IsGreaterThanBigInt" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isGreaterThanOrEqualToBigInt"),
		minimum: BigInt$3
	}).annotate({ identifier: "IsGreaterThanOrEqualToBigInt" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isLessThanBigInt"),
		exclusiveMaximum: BigInt$3
	}).annotate({ identifier: "IsLessThanBigInt" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isLessThanOrEqualToBigInt"),
		maximum: BigInt$3
	}).annotate({ identifier: "IsLessThanOrEqualToBigInt" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isBetweenBigInt"),
		minimum: BigInt$3,
		maximum: BigInt$3,
		exclusiveMinimum: optional(Boolean$1),
		exclusiveMaximum: optional(Boolean$1)
	}).annotate({ identifier: "IsBetweenBigInt" })
]).annotate({ identifier: "BigIntMeta" });
/**
* Schema codec for the {@link BigInt} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $BigInt = /*#__PURE__*/ Struct({
	_tag: tag$2("BigInt"),
	annotations: optional($Annotations),
	checks: Array$1(makeCheck($BigIntMeta, "BigInt"))
}).annotate({ identifier: "BigInt" });
/**
* Schema codec for the {@link Symbol} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Symbol = /*#__PURE__*/ Struct({
	_tag: tag$2("Symbol"),
	annotations: optional($Annotations)
}).annotate({ identifier: "Symbol" });
/**
* Schema codec for the literal value types allowed in a {@link Literal} node
* (string, finite number, boolean, or bigint).
*
* @category Schema
* @since 4.0.0
*/
var $LiteralValue = /*#__PURE__*/ Union([
	String$1,
	Finite,
	Boolean$1,
	BigInt$3
]).annotate({ identifier: "LiteralValue" });
/**
* Schema codec for the {@link Literal} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Literal = /*#__PURE__*/ Struct({
	_tag: tag$2("Literal"),
	annotations: optional($Annotations),
	literal: $LiteralValue
}).annotate({ identifier: "Literal" });
/**
* Schema codec for the {@link UniqueSymbol} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $UniqueSymbol = /*#__PURE__*/ Struct({
	_tag: tag$2("UniqueSymbol"),
	annotations: optional($Annotations),
	symbol: Symbol$1
}).annotate({ identifier: "UniqueSymbol" });
/**
* Schema codec for the {@link ObjectKeyword} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $ObjectKeyword = /*#__PURE__*/ Struct({
	_tag: tag$2("ObjectKeyword"),
	annotations: optional($Annotations)
}).annotate({ identifier: "ObjectKeyword" });
/**
* Schema codec for the {@link Enum} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Enum = /*#__PURE__*/ Struct({
	_tag: tag$2("Enum"),
	annotations: optional($Annotations),
	enums: Array$1(Tuple([String$1, Union([String$1, Number$1])]))
}).annotate({ identifier: "Enum" });
/**
* Schema codec for the {@link TemplateLiteral} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $TemplateLiteral = /*#__PURE__*/ Struct({
	_tag: tag$2("TemplateLiteral"),
	annotations: optional($Annotations),
	parts: Array$1(Representation$ref)
}).annotate({ identifier: "TemplateLiteral" });
/**
* Schema codec for the {@link Element} type (positional tuple element).
*
* @category Schema
* @since 4.0.0
*/
var $Element = /*#__PURE__*/ Struct({
	isOptional: Boolean$1,
	type: Representation$ref,
	annotations: optional($Annotations)
}).annotate({ identifier: "Element" });
var $ArraysMeta = /*#__PURE__*/ Union([
	$IsMinLength,
	$IsMaxLength,
	$IsLengthBetween,
	/* @__PURE__ */ Struct({ _tag: tag$2("isUnique") }).annotate({ identifier: "IsUnique" })
]).annotate({ identifier: "ArraysMeta" });
/**
* Schema codec for the {@link Arrays} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Arrays = /*#__PURE__*/ Struct({
	_tag: tag$2("Arrays"),
	annotations: optional($Annotations),
	elements: Array$1($Element),
	rest: Array$1(Representation$ref),
	checks: Array$1(makeCheck($ArraysMeta, "Arrays"))
}).annotate({ identifier: "Arrays" });
/**
* Schema codec for the {@link PropertySignature} type.
*
* @category Schema
* @since 4.0.0
*/
var $PropertySignature = /*#__PURE__*/ Struct({
	annotations: optional($Annotations),
	name: PropertyKey,
	type: Representation$ref,
	isOptional: Boolean$1,
	isMutable: Boolean$1
}).annotate({ identifier: "PropertySignature" });
/**
* Schema codec for the {@link IndexSignature} type.
*
* @category Schema
* @since 4.0.0
*/
var $IndexSignature = /*#__PURE__*/ Struct({
	parameter: Representation$ref,
	type: Representation$ref
}).annotate({ identifier: "IndexSignature" });
/**
* Schema codec for {@link ObjectsMeta}.
*
* @category Schema
* @since 4.0.0
*/
var $ObjectsMeta = /*#__PURE__*/ Union([
	/* @__PURE__ */ Struct({
		_tag: tag$2("isMinProperties"),
		minProperties: NonNegativeInt
	}).annotate({ identifier: "IsMinProperties" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isMaxProperties"),
		maxProperties: NonNegativeInt
	}).annotate({ identifier: "IsMaxProperties" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isPropertiesLengthBetween"),
		minimum: NonNegativeInt,
		maximum: NonNegativeInt
	}).annotate({ identifier: "IsPropertiesLengthBetween" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isPropertyNames"),
		propertyNames: Representation$ref
	}).annotate({ identifier: "IsPropertyNames" })
]).annotate({ identifier: "ObjectsMeta" });
/**
* Schema codec for the {@link Objects} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Objects = /*#__PURE__*/ Struct({
	_tag: tag$2("Objects"),
	annotations: optional($Annotations),
	propertySignatures: Array$1($PropertySignature),
	indexSignatures: Array$1($IndexSignature),
	checks: Array$1(makeCheck($ObjectsMeta, "Objects"))
}).annotate({ identifier: "Objects" });
/**
* Schema codec for the {@link Union} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Union = /*#__PURE__*/ Struct({
	_tag: tag$2("Union"),
	annotations: optional($Annotations),
	types: Array$1(Representation$ref),
	mode: Literals(["anyOf", "oneOf"])
}).annotate({ identifier: "Union" });
/**
* Schema codec for the {@link Reference} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Reference = /*#__PURE__*/ Struct({
	_tag: tag$2("Reference"),
	$ref: String$1
}).annotate({ identifier: "Reference" });
/**
* Schema codec for {@link DateMeta}.
*
* @category Schema
* @since 4.0.0
*/
var $DateMeta = /*#__PURE__*/ Union([
	/* @__PURE__ */ Struct({ _tag: tag$2("isDateValid") }).annotate({ identifier: "IsDateValid" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isGreaterThanDate"),
		exclusiveMinimum: Date$1
	}).annotate({ identifier: "IsGreaterThanDate" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isGreaterThanOrEqualToDate"),
		minimum: Date$1
	}).annotate({ identifier: "IsGreaterThanOrEqualToDate" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isLessThanDate"),
		exclusiveMaximum: Date$1
	}).annotate({ identifier: "IsLessThanDate" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isLessThanOrEqualToDate"),
		maximum: Date$1
	}).annotate({ identifier: "IsLessThanOrEqualToDate" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isBetweenDate"),
		minimum: Date$1,
		maximum: Date$1,
		exclusiveMinimum: optional(Boolean$1),
		exclusiveMaximum: optional(Boolean$1)
	}).annotate({ identifier: "IsBetweenDate" })
]).annotate({ identifier: "DateMeta" });
/**
* Schema codec for {@link SizeMeta}.
*
* @category Schema
* @since 4.0.0
*/
var $SizeMeta = /*#__PURE__*/ Union([
	/* @__PURE__ */ Struct({
		_tag: tag$2("isMinSize"),
		minSize: NonNegativeInt
	}).annotate({ identifier: "IsMinSize" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isMaxSize"),
		maxSize: NonNegativeInt
	}).annotate({ identifier: "IsMaxSize" }),
	/* @__PURE__ */ Struct({
		_tag: tag$2("isSizeBetween"),
		minimum: NonNegativeInt,
		maximum: NonNegativeInt
	}).annotate({ identifier: "IsSizeBetween" })
]).annotate({ identifier: "SizeMeta" });
/**
* Schema codec for {@link DeclarationMeta}.
*
* @category Schema
* @since 4.0.0
*/
var $DeclarationMeta = /*#__PURE__*/ Union([$DateMeta, $SizeMeta]).annotate({ identifier: "DeclarationMeta" });
/**
* Schema codec for the {@link Declaration} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Declaration = /*#__PURE__*/ Struct({
	_tag: tag$2("Declaration"),
	annotations: optional($Annotations),
	typeParameters: Array$1(Representation$ref),
	checks: Array$1(makeCheck($DeclarationMeta, "Declaration")),
	encodedSchema: Representation$ref
}).annotate({ identifier: "Declaration" });
/**
* Schema codec for the {@link Suspend} representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Suspend = /*#__PURE__*/ Struct({
	_tag: tag$2("Suspend"),
	annotations: optional($Annotations),
	checks: Tuple([]),
	thunk: Representation$ref
}).annotate({ identifier: "Suspend" });
/**
* Schema codec for the full {@link Representation} union. This is the
* recursive codec that can validate/encode any representation node.
*
* @category Schema
* @since 4.0.0
*/
var $Representation = /*#__PURE__*/ Union([
	$Null,
	$Undefined,
	$Void,
	$Never,
	$Unknown,
	$Any,
	$String,
	$Number,
	$Boolean,
	$BigInt,
	$Symbol,
	$Literal,
	$UniqueSymbol,
	$ObjectKeyword,
	$Enum,
	$TemplateLiteral,
	$Arrays,
	$Objects,
	$Union,
	$Reference,
	$Declaration,
	$Suspend
]).annotate({ identifier: "Schema" });
/**
* Schema codec for {@link Document}. Use with `Schema.decodeUnknownSync` or
* `Schema.encodeSync` to validate or serialize document data.
*
* @category Schema
* @since 4.0.0
*/
var $Document = /*#__PURE__*/ Struct({
	representation: $Representation,
	references: Record$1(String$1, $Representation)
}).annotate({ identifier: "Document" });
/**
* Schema codec for {@link MultiDocument}.
*
* @category Schema
* @since 4.0.0
*/
var $MultiDocument = /*#__PURE__*/ Struct({
	representations: NonEmptyArray($Representation),
	references: Record$1(String$1, $Representation)
}).annotate({ identifier: "MultiDocument" });
/**
* Converts a Schema AST into a {@link Document}.
*
* - Use when you have a single schema and need its representation.
* - Pure function; does not mutate the input AST.
* - Shared/recursive sub-schemas are extracted into the `references` map.
*
* **Example** (Converting a Schema to a Document)
*
* ```ts
* import { Schema, SchemaRepresentation } from "effect"
*
* const Person = Schema.Struct({
*   name: Schema.String,
*   age: Schema.Number
* })
*
* const doc = SchemaRepresentation.fromAST(Person.ast)
* console.log(doc.representation._tag)
* // "Objects"
* ```
*
* @see {@link Document}
* @see {@link fromASTs}
*
* @since 4.0.0
*/
var fromAST = fromAST$1;
/**
* Converts one or more Schema ASTs into a {@link MultiDocument}.
*
* - Use when you have multiple schemas that may share references.
* - Pure function; does not mutate the input ASTs.
* - All schemas share a single `references` map.
*
* @see {@link MultiDocument}
* @see {@link fromAST}
*
* @since 4.0.0
*/
var fromASTs = fromASTs$1;
/**
* Schema codec that decodes a {@link Document} from JSON and encodes it back.
*
* - Use with `Schema.decodeUnknownSync` / `Schema.encodeSync` to
*   serialize/deserialize documents.
*
* **Example** (Round-tripping a Document through JSON)
*
* ```ts
* import { Schema, SchemaRepresentation } from "effect"
*
* const doc = SchemaRepresentation.fromAST(Schema.String.ast)
* const json = Schema.encodeSync(SchemaRepresentation.DocumentFromJson)(doc)
* const back = Schema.decodeUnknownSync(SchemaRepresentation.DocumentFromJson)(json)
* ```
*
* @see {@link $Document}
* @see {@link MultiDocumentFromJson}
*
* @since 4.0.0
*/
var DocumentFromJson = /*#__PURE__*/ toCodecJson($Document);
/**
* Schema codec that decodes a {@link MultiDocument} from JSON and encodes it
* back.
*
* @see {@link $MultiDocument}
* @see {@link DocumentFromJson}
*
* @since 4.0.0
*/
var MultiDocumentFromJson = /*#__PURE__*/ toCodecJson($MultiDocument);
/**
* Wraps a single {@link Document} as a {@link MultiDocument} with one
* representation.
*
* - Use when an API expects a `MultiDocument` but you only have a single
*   `Document`.
* - Pure function; does not mutate the input.
*
* @see {@link Document}
* @see {@link MultiDocument}
*
* @since 4.0.0
*/
function toMultiDocument(document) {
	return {
		representations: [document.representation],
		references: document.references
	};
}
/**
* Default {@link Reviver} for {@link toSchema} that handles built-in Effect
* types (Option, Result, Redacted, Cause, Exit, ReadonlyMap, HashMap,
* ReadonlySet,
* Date, Duration, URL, RegExp, etc.).
*
* - Pass as `options.reviver` to {@link toSchema} to reconstruct schemas that
*   use these types.
* - Returns `undefined` for unrecognized declarations, causing fallback to
*   `encodedSchema`.
*
* @see {@link toSchema}
* @see {@link Reviver}
*
* @since 4.0.0
*/
var toSchemaDefaultReviver = (s, recur) => {
	const typeConstructor = s.annotations?.typeConstructor;
	if (isObject(typeConstructor) && typeof typeConstructor._tag === "string") {
		const typeParameters = s.typeParameters.map(recur);
		switch (typeConstructor._tag) {
			case "Date": return Date$1;
			case "Error": return Error$1;
			case "ErrorWithStack": return ErrorWithStack;
			case "File": return File;
			case "FormData": return FormData;
			case "ReadonlyMap": return ReadonlyMap(typeParameters[0], typeParameters[1]);
			case "ReadonlySet": return ReadonlySet(typeParameters[0]);
			case "RegExp": return RegExp$1;
			case "Uint8Array": return Uint8Array;
			case "URL": return URL;
			case "URLSearchParams": return URLSearchParams;
			case "effect/DateTime.TimeZone": return TimeZone;
			case "effect/DateTime.TimeZone.Named": return TimeZoneNamed;
			case "effect/DateTime.TimeZone.Offset": return TimeZoneOffset;
			case "effect/DateTime.Utc": return DateTimeUtc;
			case "effect/DateTime.Zoned": return DateTimeZoned;
			case "effect/BigDecimal": return BigDecimal;
			case "effect/Cause": return Cause(typeParameters[0], typeParameters[1]);
			case "effect/Cause/Failure": return CauseReason(typeParameters[0], typeParameters[1]);
			case "effect/Duration": return Duration$1;
			case "effect/Exit": return Exit(typeParameters[0], typeParameters[1], typeParameters[2]);
			case "effect/HashMap": return HashMap(typeParameters[0], typeParameters[1]);
			case "effect/Option": return Option(typeParameters[0]);
			case "effect/Redacted": return Redacted(typeParameters[0]);
			case "effect/Result": return Result(typeParameters[0], typeParameters[1]);
			case "effect/HashSet": return HashSet(typeParameters[0]);
			case "effect/Chunk": return Chunk(typeParameters[0]);
		}
	}
};
/**
* Reconstructs a runtime Schema from a {@link Document}.
*
* - Use when you have a serialized or computed representation and need a
*   working Schema for decoding/encoding.
* - Pass `options.reviver` (e.g. {@link toSchemaDefaultReviver}) to handle
*   {@link Declaration} nodes for types like `Date`, `Option`, etc.
* - Without a reviver, declarations fall back to their `encodedSchema`.
* - Handles circular references via lazy `Schema.suspend`.
* - Throws if a `$ref` is not found in `document.references`.
*
* **Example** (Reconstructing a Schema)
*
* ```ts
* import { Schema, SchemaRepresentation } from "effect"
*
* const doc = SchemaRepresentation.fromAST(
*   Schema.Struct({ name: Schema.String }).ast
* )
*
* const schema = SchemaRepresentation.toSchema(doc)
* console.log(JSON.stringify(Schema.toJsonSchemaDocument(schema), null, 2))
* ```
*
* @see {@link Document}
* @see {@link Reviver}
* @see {@link toSchemaDefaultReviver}
*
* @category Runtime Generation
* @since 4.0.0
*/
function toSchema(document, options) {
	const slots = /* @__PURE__ */ new Map();
	return recur(document.representation);
	function recur(r) {
		let out = on(r);
		if ("annotations" in r && r.annotations) out = out.annotate(r.annotations);
		out = toSchemaChecks(out, r);
		return out;
	}
	function getSlot(identifier) {
		const existing = slots.get(identifier);
		if (existing) return existing;
		const slot = {
			state: 0,
			value: void 0,
			ref: suspend$2(() => {
				if (slot.value === void 0) return Unknown;
				return slot.value;
			})
		};
		slots.set(identifier, slot);
		return slot;
	}
	function resolveReference($ref) {
		const definition = document.references[$ref];
		if (definition === void 0) throw new Error(`Reference ${$ref} not found`);
		const slot = getSlot($ref);
		if (slot.state === 2) return slot.value;
		if (slot.state === 1) return slot.ref;
		slot.state = 1;
		try {
			slot.value = recur(definition);
			slot.state = 2;
			return slot.value;
		} catch (e) {
			slot.state = 0;
			slot.value = void 0;
			throw e;
		}
	}
	function on(r) {
		switch (r._tag) {
			case "Declaration": return options?.reviver?.(r, recur) ?? recur(r.encodedSchema);
			case "Reference": return resolveReference(r.$ref);
			case "Suspend": return recur(r.thunk);
			case "Null": return Null;
			case "Undefined": return Undefined;
			case "Void": return Void;
			case "Never": return Never;
			case "Unknown": return Unknown;
			case "Any": return Any;
			case "String": {
				const contentMediaType = r.contentMediaType;
				const contentSchema = r.contentSchema;
				if (contentMediaType === "application/json" && contentSchema !== void 0) return fromJsonString(recur(contentSchema));
				return String$1;
			}
			case "Number": return Number$1;
			case "Boolean": return Boolean$1;
			case "BigInt": return BigInt$3;
			case "Symbol": return Symbol$1;
			case "Literal": return Literal(r.literal);
			case "UniqueSymbol": return UniqueSymbol(r.symbol);
			case "ObjectKeyword": return ObjectKeyword;
			case "Enum": return Enum(Object.fromEntries(r.enums));
			case "TemplateLiteral": return TemplateLiteral(r.parts.map(recur));
			case "Arrays": {
				const elements = r.elements.map((e) => {
					const s = recur(e.type);
					return e.isOptional ? optionalKey(s) : s;
				});
				const rest = r.rest.map(recur);
				if (isArrayNonEmpty(rest)) {
					if (r.elements.length === 0 && r.rest.length === 1) return Array$1(rest[0]);
					return TupleWithRest(Tuple(elements), rest);
				}
				return Tuple(elements);
			}
			case "Objects": {
				const fields = {};
				for (const ps of r.propertySignatures) {
					const s = recur(ps.type);
					const withOptional = ps.isOptional ? optionalKey(s) : s;
					fields[ps.name] = ps.isMutable ? mutableKey(withOptional) : withOptional;
				}
				const indexSignatures = r.indexSignatures.map((is) => Record$1(recur(is.parameter), recur(is.type)));
				if (isArrayNonEmpty(indexSignatures)) {
					if (r.propertySignatures.length === 0 && indexSignatures.length === 1) return indexSignatures[0];
					return StructWithRest(Struct(fields), indexSignatures);
				}
				return Struct(fields);
			}
			case "Union":
				if (r.types.length === 0) return Never;
				if (r.types.every((t) => t._tag === "Literal")) {
					if (r.types.length === 1) return Literal(r.types[0].literal);
					return Literals(r.types.map((t) => t.literal));
				}
				return Union(r.types.map(recur), { mode: r.mode });
		}
	}
	function toSchemaChecks(top, schema) {
		switch (schema._tag) {
			default: return top;
			case "String":
			case "Number":
			case "BigInt":
			case "Arrays":
			case "Objects":
			case "Declaration": {
				const checks = schema.checks.map(toSchemaCheck);
				return isArrayNonEmpty(checks) ? top.check(...checks) : top;
			}
		}
	}
	function toSchemaCheck(check) {
		switch (check._tag) {
			case "Filter": return toSchemaFilter(check);
			case "FilterGroup": return makeFilterGroup(map$12(check.checks, toSchemaCheck), check.annotations);
		}
	}
	function toSchemaFilter(filter) {
		const a = filter.annotations;
		switch (filter.meta._tag) {
			case "isStringFinite": return isStringFinite(a);
			case "isStringBigInt": return isStringBigInt(a);
			case "isStringSymbol": return isStringSymbol(a);
			case "isMinLength": return isMinLength(filter.meta.minLength, a);
			case "isMaxLength": return isMaxLength(filter.meta.maxLength, a);
			case "isLengthBetween": return isLengthBetween(filter.meta.minimum, filter.meta.maximum, a);
			case "isPattern": return isPattern(filter.meta.regExp, a);
			case "isTrimmed": return isTrimmed(a);
			case "isUUID": return isUUID(filter.meta.version, a);
			case "isULID": return isULID(a);
			case "isBase64": return isBase64(a);
			case "isBase64Url": return isBase64Url(a);
			case "isStartsWith": return isStartsWith(filter.meta.startsWith, a);
			case "isEndsWith": return isEndsWith(filter.meta.endsWith, a);
			case "isIncludes": return isIncludes(filter.meta.includes, a);
			case "isUppercased": return isUppercased(a);
			case "isLowercased": return isLowercased(a);
			case "isCapitalized": return isCapitalized(a);
			case "isUncapitalized": return isUncapitalized(a);
			case "isFinite": return isFinite$1(a);
			case "isInt": return isInt(a);
			case "isMultipleOf": return isMultipleOf(filter.meta.divisor, a);
			case "isGreaterThan": return isGreaterThan$2(filter.meta.exclusiveMinimum, a);
			case "isGreaterThanOrEqualTo": return isGreaterThanOrEqualTo$2(filter.meta.minimum, a);
			case "isLessThan": return isLessThan$2(filter.meta.exclusiveMaximum, a);
			case "isLessThanOrEqualTo": return isLessThanOrEqualTo$2(filter.meta.maximum, a);
			case "isBetween": return isBetween$1(filter.meta, a);
			case "isGreaterThanBigInt": return isGreaterThanBigInt(filter.meta.exclusiveMinimum, a);
			case "isGreaterThanOrEqualToBigInt": return isGreaterThanOrEqualToBigInt(filter.meta.minimum, a);
			case "isLessThanBigInt": return isLessThanBigInt(filter.meta.exclusiveMaximum, a);
			case "isLessThanOrEqualToBigInt": return isLessThanOrEqualToBigInt(filter.meta.maximum, a);
			case "isBetweenBigInt": return isBetweenBigInt(filter.meta, a);
			case "isMinProperties": return isMinProperties(filter.meta.minProperties, a);
			case "isMaxProperties": return isMaxProperties(filter.meta.maxProperties, a);
			case "isPropertiesLengthBetween": return isPropertiesLengthBetween(filter.meta.minimum, filter.meta.maximum, a);
			case "isPropertyNames": return isPropertyNames(recur(filter.meta.propertyNames), a);
			case "isUnique": return isUnique(a);
			case "isDateValid": return isDateValid(a);
			case "isGreaterThanDate": return isGreaterThanDate(filter.meta.exclusiveMinimum, a);
			case "isGreaterThanOrEqualToDate": return isGreaterThanOrEqualToDate(filter.meta.minimum, a);
			case "isLessThanDate": return isLessThanDate(filter.meta.exclusiveMaximum, a);
			case "isLessThanOrEqualToDate": return isLessThanOrEqualToDate(filter.meta.maximum, a);
			case "isBetweenDate": return isBetweenDate(filter.meta, a);
			case "isMinSize": return isMinSize(filter.meta.minSize, a);
			case "isMaxSize": return isMaxSize(filter.meta.maxSize, a);
			case "isSizeBetween": return isSizeBetween(filter.meta.minimum, filter.meta.maximum, a);
		}
	}
}
/**
* Converts a {@link Document} to a Draft 2020-12 JSON Schema document.
*
* - Use to produce a standard JSON Schema from an Effect Schema representation.
* - Pure function; does not mutate the input.
*
* **Example** (Generating JSON Schema)
*
* ```ts
* import { Schema, SchemaRepresentation } from "effect"
*
* const doc = SchemaRepresentation.fromAST(Schema.String.ast)
* const jsonSchema = SchemaRepresentation.toJsonSchemaDocument(doc)
* console.log(jsonSchema.schema.type)
* // "string"
* ```
*
* @see {@link Document}
* @see {@link toJsonSchemaMultiDocument}
* @see {@link fromJsonSchemaDocument}
*
* @since 4.0.0
*/
var toJsonSchemaDocument = toJsonSchemaDocument$1;
/**
* Converts a {@link MultiDocument} to a Draft 2020-12 JSON Schema
* multi-document.
*
* - Use when you have multiple schemas sharing references.
* - Pure function; does not mutate the input.
*
* @see {@link MultiDocument}
* @see {@link toJsonSchemaDocument}
* @see {@link fromJsonSchemaMultiDocument}
*
* @since 4.0.0
*/
var toJsonSchemaMultiDocument = toJsonSchemaMultiDocument$1;
/**
* Constructs a {@link Code} value from a runtime expression string and a
* TypeScript type string.
*
* @see {@link Code}
*
* @category Code Generation
* @since 4.0.0
*/
function makeCode(runtime, Type) {
	return {
		runtime,
		Type
	};
}
/**
* Generates TypeScript code strings from a {@link MultiDocument}.
*
* - Use to produce source code for Schema definitions (e.g. for codegen tools).
* - `options.reviver` can customize code generation for {@link Declaration}
*   nodes. Return `undefined` to fall back to the default logic (which uses
*   `generation` annotations or the encoded schema).
* - Performs topological sorting of references to emit non-recursive
*   definitions before their dependents.
* - Produces sanitized JavaScript identifiers for `$ref` keys.
*
* **Example** (Generating TypeScript code)
*
* ```ts
* import { Schema, SchemaRepresentation } from "effect"
*
* const Person = Schema.Struct({
*   name: Schema.String,
*   age: Schema.Int
* })
*
* const multi = SchemaRepresentation.toMultiDocument(
*   SchemaRepresentation.fromAST(Person.ast)
* )
* const codeDoc = SchemaRepresentation.toCodeDocument(multi)
* console.log(codeDoc.codes[0].runtime)
* // Schema.Struct({ ... })
* ```
*
* @see {@link CodeDocument}
* @see {@link MultiDocument}
* @see {@link Reviver}
*
* @category Code Generation
* @since 4.0.0
*/
function toCodeDocument(multiDocument, options) {
	const artifacts = [];
	const ts = topologicalSort(multiDocument.references);
	const sanitizedReferenceMap = /* @__PURE__ */ new Map();
	const uniqueSanitizedReferences = /* @__PURE__ */ new Set();
	const referenceCount = /* @__PURE__ */ new Map();
	const allRefs = [...ts.nonRecursives.map(({ $ref }) => $ref), ...Object.keys(ts.recursives)];
	for (const ref of allRefs) ensureUniqueSanitized(ref);
	const nonRecursives = ts.nonRecursives.map(({ $ref, representation }) => ({
		$ref: sanitizedReferenceMap.get($ref),
		code: recur(representation)
	}));
	const recursives = mapEntries(ts.recursives, (representation, $ref) => [sanitizedReferenceMap.get($ref), recur(representation)]);
	return {
		codes: multiDocument.representations.map(recur),
		references: {
			nonRecursives: nonRecursives.filter(({ $ref }) => (referenceCount.get($ref) ?? 0) > 0),
			recursives: filter$5(recursives, (_, $ref) => (referenceCount.get($ref) ?? 0) > 0)
		},
		artifacts
	};
	function ensureUniqueSanitized(originalRef) {
		const sanitized = sanitizedReferenceMap.get(originalRef);
		if (sanitized !== void 0) return sanitized;
		const seed = sanitizeJavaScriptIdentifier(originalRef);
		let candidate = seed;
		let suffix = 0;
		while (uniqueSanitizedReferences.has(candidate)) candidate = `${seed}${++suffix}`;
		uniqueSanitizedReferences.add(candidate);
		sanitizedReferenceMap.set(originalRef, candidate);
		return candidate;
	}
	function addSymbol(s) {
		const identifier = ensureUniqueSanitized("_symbol");
		const key = globalThis.Symbol.keyFor(s);
		const description = s.description;
		const generation = key === void 0 ? makeCode(`Symbol(${description === void 0 ? "" : format$1(description)})`, `typeof ${identifier}`) : makeCode(`Symbol.for(${format$1(key)})`, `typeof ${identifier}`);
		artifacts.push({
			_tag: "Symbol",
			identifier,
			generation
		});
		return identifier;
	}
	function addEnum(s) {
		const identifier = ensureUniqueSanitized("_Enum");
		artifacts.push({
			_tag: "Enum",
			identifier,
			generation: makeCode(`enum ${identifier} { ${s.enums.map(([name, value]) => `${format$1(name)}: ${format$1(value)}`).join(", ")} }`, `typeof ${identifier}`)
		});
		return identifier;
	}
	function addImport(importDeclaration) {
		if (!artifacts.some((a) => a._tag === "Import" && a.importDeclaration === importDeclaration)) artifacts.push({
			_tag: "Import",
			importDeclaration
		});
	}
	function recur(s) {
		const g = on(s);
		switch (s._tag) {
			default: return makeCode(g.runtime + toRuntimeAnnotate(s.annotations) + toRuntimeBrand(s.annotations), g.Type + toTypeBrand(s.annotations));
			case "Reference": return g;
			case "Declaration":
			case "String":
			case "Number":
			case "BigInt":
			case "Arrays":
			case "Objects":
			case "Suspend": return makeCode(g.runtime + toRuntimeAnnotate(s.annotations) + toRuntimeBrand(s.annotations) + toRuntimeChecks(s.checks), g.Type + toTypeBrand(s.annotations) + toTypeChecks(s.checks));
		}
	}
	function on(s) {
		switch (s._tag) {
			case "Declaration": {
				if (options?.reviver !== void 0) {
					const out = options.reviver(s, recur);
					if (out !== void 0) return out;
				}
				const generation = s.annotations?.generation;
				if (isObject(generation) && typeof generation.runtime === "string" && typeof generation.Type === "string") {
					const typeParameters = s.typeParameters.map(recur);
					if (typeof generation.importDeclaration === "string") addImport(generation.importDeclaration);
					return makeCode(replacePlaceholders(generation.runtime, typeParameters.map((p) => p.runtime)), replacePlaceholders(generation.Type, typeParameters.map((p) => p.Type)));
				}
				return recur(s.encodedSchema);
			}
			case "Reference": {
				const sanitized = ensureUniqueSanitized(s.$ref);
				referenceCount.set(sanitized, (referenceCount.get(sanitized) ?? 0) + 1);
				return makeCode(sanitized, sanitized);
			}
			case "Suspend": {
				const thunk = recur(s.thunk);
				return makeCode(`Schema.suspend((): Schema.Codec<${thunk.Type}> => ${thunk.runtime})`, thunk.Type);
			}
			case "Null": return makeCode(`Schema.Null`, "null");
			case "Undefined": return makeCode(`Schema.Undefined`, "undefined");
			case "Void": return makeCode(`Schema.Void`, "void");
			case "Never": return makeCode(`Schema.Never`, "never");
			case "Unknown": return makeCode(`Schema.Unknown`, "unknown");
			case "Any": return makeCode(`Schema.Any`, "any");
			case "Number": return makeCode(`Schema.Number`, "number");
			case "Boolean": return makeCode(`Schema.Boolean`, "boolean");
			case "BigInt": return makeCode(`Schema.BigInt`, "bigint");
			case "Symbol": return makeCode(`Schema.Symbol`, "symbol");
			case "String": {
				const contentMediaType = s.contentMediaType;
				const contentSchema = s.contentSchema;
				if (contentMediaType === "application/json" && contentSchema !== void 0) return makeCode(`Schema.fromJsonString(${recur(contentSchema)})`, "string");
				else return makeCode(`Schema.String`, "string");
			}
			case "Literal": {
				const literal = format$1(s.literal);
				return makeCode(`Schema.Literal(${literal})`, literal);
			}
			case "UniqueSymbol": {
				const identifier = addSymbol(s.symbol);
				return makeCode(`Schema.UniqueSymbol(${identifier})`, `typeof ${identifier}`);
			}
			case "ObjectKeyword": return makeCode(`Schema.ObjectKeyword`, "object");
			case "Enum": {
				const identifier = addEnum(s);
				return makeCode(`Schema.Enum(${identifier})`, `typeof ${identifier}`);
			}
			case "TemplateLiteral": {
				const parts = s.parts.map(recur);
				const type = toTypeParts(s.parts).map((p) => "`" + p + "`").join(" | ");
				return makeCode(`Schema.TemplateLiteral([${parts.map((p) => p.runtime).join(", ")}])`, type);
			}
			case "Arrays": {
				const elements = s.elements.map((e) => {
					return {
						isOptional: e.isOptional,
						type: recur(e.type),
						annotations: e.annotations
					};
				});
				const rest = s.rest.map(recur);
				if (isArrayNonEmpty(rest)) {
					const item = rest[0];
					if (elements.length === 0 && rest.length === 1) return makeCode(`Schema.Array(${item.runtime})`, `ReadonlyArray<${item.Type}>`);
					const post = rest.slice(1);
					return makeCode(`Schema.TupleWithRest(Schema.Tuple([${elements.map((e) => toRuntimeIsOptional(e.isOptional, e.type.runtime) + toRuntimeAnnotateKey(e.annotations)).join(", ")}]), [${rest.map((r) => r.runtime).join(", ")}])`, `readonly [${elements.map((e) => toTypeIsOptional(e.isOptional, e.type.Type)).join(", ")}, ...Array<${item.Type}>${post.length > 0 ? `, ${post.map((p) => p.Type).join(", ")}` : ""}]`);
				}
				return makeCode(`Schema.Tuple([${elements.map((e) => toRuntimeIsOptional(e.isOptional, e.type.runtime) + toRuntimeAnnotateKey(e.annotations)).join(", ")}])`, `readonly [${elements.map((e) => toTypeIsOptional(e.isOptional, e.type.Type)).join(", ")}]`);
			}
			case "Objects": {
				const pss = s.propertySignatures.map((p) => {
					const isSymbol = typeof p.name === "symbol";
					const name = isSymbol ? addSymbol(p.name) : formatPropertyKey(p.name);
					const nameType = toTypeIsOptional(p.isOptional, toTypeIsMutable(p.isMutable, isSymbol ? `[typeof ${name}]` : name));
					const type = recur(p.type);
					return makeCode(`${isSymbol ? `[${name}]` : name}: ${toRuntimeIsOptional(p.isOptional, toRuntimeIsMutable(p.isMutable, type.runtime))}` + toRuntimeAnnotateKey(p.annotations), `${nameType}: ${type.Type}`);
				});
				const iss = s.indexSignatures.map((is) => {
					return {
						parameter: recur(is.parameter),
						type: recur(is.type)
					};
				});
				if (iss.length === 0) return makeCode(`Schema.Struct({ ${pss.map((p) => p.runtime).join(", ")} })`, `{ ${pss.map((p) => p.Type).join(", ")} }`);
				else if (pss.length === 0 && iss.length === 1) return makeCode(`Schema.Record(${iss[0].parameter.runtime}, ${iss[0].type.runtime})`, `{ readonly [x: ${iss[0].parameter.Type}]: ${iss[0].type.Type} }`);
				else return makeCode(`Schema.StructWithRest(Schema.Struct({ ${pss.map((p) => p.runtime).join(", ")} }), [${iss.map((is) => `Schema.Record(${is.parameter.runtime}, ${is.type.runtime})`).join(", ")}])`, `{ ${pss.map((p) => p.Type).join(", ")}, ${iss.map((is) => `readonly [x: ${is.parameter.Type}]: ${is.type.Type}`).join(", ")} }`);
			}
			case "Union": {
				if (s.types.length === 0) return makeCode("Schema.Never", "never");
				if (s.types.every((t) => t._tag === "Literal")) {
					const literals = s.types.map((l) => format$1(l.literal));
					if (literals.length === 1) return makeCode(`Schema.Literal(${literals[0]})`, literals[0]);
					return makeCode(`Schema.Literals([${literals.join(", ")}])`, literals.join(" | "));
				}
				const mode = s.mode === "anyOf" ? "" : `, { mode: "oneOf" }`;
				const types = s.types.map((t) => recur(t));
				return makeCode(`Schema.Union([${types.map((t) => t.runtime).join(", ")}]${mode})`, types.map((t) => t.Type).join(" | "));
			}
		}
	}
	function toTypeBrand(annotations) {
		const brands = collectBrands(annotations);
		if (brands.length === 0) return "";
		addImport(`import type * as Brand from "effect/Brand"`);
		return brands.map((b) => ` & Brand.Brand<${format$1(b)}>`).join("");
	}
	function toTypeChecks(checks) {
		return checks.map((c) => toTypeCheck(c)).join("");
	}
	function toTypeCheck(check) {
		switch (check._tag) {
			case "Filter": return toTypeBrand(check.annotations);
			case "FilterGroup": return toTypeChecks(check.checks);
		}
	}
	function toRuntimeChecks(checks) {
		return checks.map((c) => `.check(${toRuntimeCheck(c)})` + toRuntimeBrand(c.annotations)).join("");
	}
	function toRuntimeCheck(check) {
		switch (check._tag) {
			case "Filter": return toRuntimeFilter(check);
			case "FilterGroup": {
				const a = toRuntimeAnnotations(check.annotations);
				const ca = a === "" ? "" : `, ${a}`;
				return `Schema.makeFilterGroup([${check.checks.map((c) => toRuntimeCheck(c)).join(", ")}]${ca})`;
			}
		}
	}
	function toRuntimeFilter(filter) {
		const a = toRuntimeAnnotations(filter.annotations);
		const ca = a === "" ? "" : `, ${a}`;
		switch (filter.meta._tag) {
			case "isTrimmed":
			case "isULID":
			case "isBase64":
			case "isBase64Url":
			case "isUppercased":
			case "isLowercased":
			case "isCapitalized":
			case "isUncapitalized":
			case "isFinite":
			case "isInt":
			case "isUnique":
			case "isDateValid": return `Schema.${filter.meta._tag}(${ca})`;
			case "isStringFinite":
			case "isStringBigInt":
			case "isStringSymbol":
			case "isPattern": return `Schema.${filter.meta._tag}(${toRuntimeRegExp(filter.meta.regExp)}${ca})`;
			case "isMinLength": return `Schema.isMinLength(${filter.meta.minLength}${ca})`;
			case "isMaxLength": return `Schema.isMaxLength(${filter.meta.maxLength}${ca})`;
			case "isLengthBetween": return `Schema.isLengthBetween(${filter.meta.minimum}, ${filter.meta.maximum}${ca})`;
			case "isUUID": return `Schema.isUUID(${filter.meta.version}${ca})`;
			case "isStartsWith": return `Schema.isStartsWith(${format$1(filter.meta.startsWith)}${ca})`;
			case "isEndsWith": return `Schema.isEndsWith(${format$1(filter.meta.endsWith)}${ca})`;
			case "isIncludes": return `Schema.isIncludes(${format$1(filter.meta.includes)}${ca})`;
			case "isGreaterThan":
			case "isGreaterThanBigInt":
			case "isGreaterThanDate": return `Schema.${filter.meta._tag}(${toRuntimeValue(filter.meta.exclusiveMinimum)}${ca})`;
			case "isGreaterThanOrEqualTo":
			case "isGreaterThanOrEqualToBigInt":
			case "isGreaterThanOrEqualToDate": return `Schema.${filter.meta._tag}(${toRuntimeValue(filter.meta.minimum)}${ca})`;
			case "isLessThan":
			case "isLessThanBigInt":
			case "isLessThanDate": return `Schema.${filter.meta._tag}(${toRuntimeValue(filter.meta.exclusiveMaximum)}${ca})`;
			case "isLessThanOrEqualTo":
			case "isLessThanOrEqualToBigInt":
			case "isLessThanOrEqualToDate": return `Schema.${filter.meta._tag}(${toRuntimeValue(filter.meta.maximum)}${ca})`;
			case "isBetween":
			case "isBetweenBigInt":
			case "isBetweenDate": return `Schema.${filter.meta._tag}({ minimum: ${toRuntimeValue(filter.meta.minimum)}, maximum: ${toRuntimeValue(filter.meta.maximum)}, exclusiveMinimum: ${toRuntimeValue(filter.meta.exclusiveMinimum)}, exclusiveMaximum: ${toRuntimeValue(filter.meta.exclusiveMaximum)}${ca})`;
			case "isMultipleOf": return `Schema.isMultipleOf(${filter.meta.divisor}${ca})`;
			case "isMinProperties": return `Schema.isMinProperties(${filter.meta.minProperties}${ca})`;
			case "isMaxProperties": return `Schema.isMaxProperties(${filter.meta.maxProperties}${ca})`;
			case "isPropertiesLengthBetween": return `Schema.isPropertiesLengthBetween(${filter.meta.minimum}, ${filter.meta.maximum}${ca})`;
			case "isPropertyNames": return `Schema.isPropertyNames(${recur(filter.meta.propertyNames).runtime}${ca})`;
			case "isMinSize": return `Schema.isMinSize(${filter.meta.minSize}${ca})`;
			case "isMaxSize": return `Schema.isMaxSize(${filter.meta.maxSize}${ca})`;
			case "isSizeBetween": return `Schema.isSizeBetween(${filter.meta.minimum}, ${filter.meta.maximum}${ca})`;
		}
	}
}
var VALID_ASCII_UPPER_JAVASCRIPT_IDENTIFIER_REGEXP = /^[A-Z_$][A-Za-z0-9_$]*$/;
/**
* Converts an arbitrary string into a valid (ASCII) JavaScript identifier
* starting with an uppercase letter, `$`, or `_`.
*
* - Replaces invalid identifier characters with `_`
* - Uppercases a leading ASCII letter
* - If the first character is a digit, prefixes `_`
* - Empty input becomes `_`
*
* @internal
*/
function sanitizeJavaScriptIdentifier(s) {
	if (s.length === 0) return "_";
	if (VALID_ASCII_UPPER_JAVASCRIPT_IDENTIFIER_REGEXP.test(s)) return s;
	const out = [];
	let needsPrefix = false;
	let i = 0;
	for (const ch of s) {
		if (i === 0) if (ch === "_" || ch === "$" || ch >= "A" && ch <= "Z") out.push(ch);
		else if (ch >= "a" && ch <= "z") out.push(ch.toUpperCase());
		else if (ch >= "0" && ch <= "9") {
			out.push(ch);
			needsPrefix = true;
		} else out.push("_");
		else out.push(isAsciiIdPart(ch) ? ch : "_");
		i++;
	}
	return needsPrefix ? "_" + out.join("") : out.join("");
}
function isAsciiIdStart(ch) {
	return ch === "_" || ch === "$" || ch >= "A" && ch <= "Z" || ch >= "a" && ch <= "z";
}
function isAsciiIdPart(ch) {
	return isAsciiIdStart(ch) || ch >= "0" && ch <= "9";
}
function replacePlaceholders(template, items) {
	let i = 0;
	return template.replace(/\?/g, () => items[i++]);
}
function toTypeParts(parts) {
	if (parts.length === 0) return [""];
	const [first, ...rest] = parts;
	const restPatterns = toTypeParts(rest);
	return toTypePart(first).flatMap((f) => restPatterns.map((r) => f + r));
}
function toTypePart(r) {
	switch (r._tag) {
		case "Literal": return [globalThis.String(r.literal)];
		case "String": return ["${string}"];
		case "Number": return ["${number}"];
		case "BigInt": return ["${bigint}"];
		case "TemplateLiteral": return toTypeParts(r.parts);
		case "Union": return r.types.flatMap(toTypePart);
		default: return [];
	}
}
var toCodeAnnotationsBlacklist = /*#__PURE__*/ new Set([
	...toJsonAnnotationsBlacklist,
	"typeConstructor",
	"generation",
	"brands"
]);
function toRuntimeAnnotations(annotations) {
	if (!annotations) return "";
	const entries = [];
	for (const [key, value] of Object.entries(annotations)) {
		if (toCodeAnnotationsBlacklist.has(key)) continue;
		entries.push(`${formatPropertyKey(key)}: ${format$1(value)}`);
	}
	if (entries.length === 0) return "";
	return `{ ${entries.join(", ")} }`;
}
function toRuntimeBrand(annotations) {
	const brands = collectBrands(annotations);
	return brands.length > 0 ? `.pipe(${brands.map((b) => `Schema.brand(${format$1(b)})`).join(", ")})` : "";
}
function toRuntimeAnnotate(annotations) {
	const s = toRuntimeAnnotations(annotations);
	return s === "" ? "" : `.annotate(${s})`;
}
function toRuntimeAnnotateKey(annotations) {
	const s = toRuntimeAnnotations(annotations);
	return s === "" ? "" : `.annotateKey(${s})`;
}
function toRuntimeIsOptional(isOptional, runtime) {
	return isOptional ? `Schema.optionalKey(${runtime})` : runtime;
}
function toTypeIsOptional(isOptional, type) {
	return isOptional ? `${type}?` : type;
}
function toRuntimeIsMutable(isMutable, runtime) {
	return isMutable ? `Schema.mutableKey(${runtime})` : runtime;
}
function toTypeIsMutable(isMutable, type) {
	return isMutable ? type : `readonly ${type}`;
}
function toRuntimeValue(value) {
	if (value instanceof Date) return `new Date(${value.getTime()})`;
	return format$1(value);
}
function toRuntimeRegExp(regExp) {
	const args = [format$1(regExp.source)];
	const flags = regExp.flags.trim();
	if (flags !== "") args.push(format$1(flags));
	return `new RegExp(${args.join(", ")})`;
}
/**
* Parses a Draft 2020-12 JSON Schema document into a {@link Document}.
*
* - Use to import external JSON Schemas into the Effect representation system.
* - `options.onEnter` is an optional hook called on each JSON Schema node
*   before processing, allowing pre-transformation.
* - Throws if a `$ref` cannot be resolved within the document's definitions.
* - Circular `$ref`s are detected and cause an error.
*
* @see {@link Document}
* @see {@link toJsonSchemaDocument}
* @see {@link fromJsonSchemaMultiDocument}
*
* @since 4.0.0
*/
function fromJsonSchemaDocument(document, options) {
	const { references, representations: schemas } = fromJsonSchemaMultiDocument({
		dialect: document.dialect,
		schemas: [document.schema],
		definitions: document.definitions
	}, options);
	return {
		representation: schemas[0],
		references
	};
}
/**
* Parses a Draft 2020-12 JSON Schema multi-document into a
* {@link MultiDocument}.
*
* - Use to import multiple JSON Schemas sharing definitions.
* - `options.onEnter` is an optional hook called on each JSON Schema node
*   before processing.
* - Throws if a `$ref` cannot be resolved.
*
* @see {@link MultiDocument}
* @see {@link toJsonSchemaMultiDocument}
* @see {@link fromJsonSchemaDocument}
*
* @since 4.0.0
*/
function fromJsonSchemaMultiDocument(document, options) {
	let visited;
	const references = {};
	const slots = /* @__PURE__ */ new Map();
	function getSlot(identifier) {
		const existing = slots.get(identifier);
		if (existing) return existing;
		const slot = {
			state: 0,
			value: void 0
		};
		slots.set(identifier, slot);
		return slot;
	}
	function resolveReference($ref) {
		const definition = document.definitions[$ref];
		if (definition === void 0) throw new Error(`Reference ${$ref} not found`);
		const slot = getSlot($ref);
		if (slot.state === 2) return slot.value;
		if (slot.state === 1) throw new Error(`Circular reference detected: ${$ref}`);
		slot.state = 1;
		const value = recur(definition);
		slot.value = value._tag === "Reference" ? resolveReference(value.$ref) : value;
		slot.state = 2;
		return slot.value;
	}
	Object.entries(document.definitions).forEach(([identifier, definition]) => {
		visited = /* @__PURE__ */ new Set([identifier]);
		references[identifier] = recur(definition);
	});
	visited = /* @__PURE__ */ new Set();
	return {
		representations: map$12(document.schemas, recur),
		references
	};
	function recur(u) {
		if (u === false) return never;
		if (!isObject(u)) return unknown;
		let js = options?.onEnter?.(u) ?? u;
		if (Array.isArray(js.type)) if (js.type.every(isType)) {
			const { type, ...rest } = js;
			js = {
				anyOf: type.map((type) => ({ type })),
				...rest
			};
		} else js = {};
		let out = on(js);
		const annotations = collectAnnotations(js);
		if (annotations !== void 0) out = combine(out, {
			_tag: "Unknown",
			annotations
		});
		if (Array.isArray(js.allOf)) return js.allOf.reduce((acc, curr) => combine(acc, recur(curr)), out);
		return out;
	}
	function on(js) {
		if (typeof js.$ref === "string") {
			const $ref = js.$ref.slice(2).split("/").at(-1);
			if ($ref !== void 0) {
				const reference = {
					_tag: "Reference",
					$ref: unescapeToken($ref)
				};
				if (visited.has($ref)) return {
					_tag: "Suspend",
					thunk: reference,
					checks: []
				};
				else return reference;
			}
		} else if ("const" in js) {
			if (isLiteralValue(js.const)) return {
				_tag: "Literal",
				literal: js.const
			};
			else if (js.const === null) return null_;
		} else if (Array.isArray(js.enum)) {
			const types = [];
			for (const e of js.enum) if (isLiteralValue(e)) types.push({
				_tag: "Literal",
				literal: e
			});
			else if (e === null) types.push(null_);
			else types.push(recur(e));
			if (types.length === 1) return types[0];
			else return {
				_tag: "Union",
				types,
				mode: "anyOf"
			};
		} else if (Array.isArray(js.anyOf)) return {
			_tag: "Union",
			types: js.anyOf.map((type) => recur(type)),
			mode: "anyOf"
		};
		else if (Array.isArray(js.oneOf)) return {
			_tag: "Union",
			types: js.oneOf.map((type) => recur(type)),
			mode: "oneOf"
		};
		const type = isType(js.type) ? js.type : getType(js);
		if (type !== void 0) switch (type) {
			case "null": return null_;
			case "string": {
				const checks = collectStringChecks(js);
				if (checks.length > 0) return {
					...string,
					checks
				};
				return string;
			}
			case "number": return {
				_tag: "Number",
				checks: [{
					_tag: "Filter",
					meta: { _tag: "isFinite" }
				}, ...collectNumberChecks(js)]
			};
			case "integer": return {
				_tag: "Number",
				checks: [{
					_tag: "Filter",
					meta: { _tag: "isInt" }
				}, ...collectNumberChecks(js)]
			};
			case "boolean": return boolean;
			case "array": {
				const minItems = typeof js.minItems === "number" ? js.minItems : 0;
				return {
					_tag: "Arrays",
					elements: (Array.isArray(js.prefixItems) ? js.prefixItems : []).map((e, i) => ({
						isOptional: i + 1 > minItems,
						type: recur(e)
					})),
					rest: js.items !== void 0 ? [recur(js.items)] : js.prefixItems !== void 0 && typeof js.maxItems === "number" ? [] : [unknown],
					checks: collectArraysChecks(js)
				};
			}
			case "object": return {
				_tag: "Objects",
				propertySignatures: collectProperties(js),
				indexSignatures: collectIndexSignatures(js),
				checks: collectObjectsChecks(js)
			};
		}
		return { _tag: "Unknown" };
	}
	function collectObjectsChecks(js) {
		const checks = [];
		if (typeof js.minProperties === "number") checks.push({
			_tag: "Filter",
			meta: {
				_tag: "isMinProperties",
				minProperties: js.minProperties
			}
		});
		if (typeof js.maxProperties === "number") checks.push({
			_tag: "Filter",
			meta: {
				_tag: "isMaxProperties",
				maxProperties: js.maxProperties
			}
		});
		if (js.propertyNames !== void 0) {
			const propertyNames = recur(js.propertyNames);
			checks.push({
				_tag: "Filter",
				meta: {
					_tag: "isPropertyNames",
					propertyNames
				}
			});
		}
		return checks;
	}
	function combine(a, b) {
		switch (a._tag) {
			default: return never;
			case "Reference": return combine(resolveReference(a.$ref), b);
			case "Never": return a;
			case "Unknown": switch (b._tag) {
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return {
					...b,
					...combineAnnotations(a.annotations, b.annotations)
				};
			}
			case "Null": switch (b._tag) {
				case "Unknown":
				case "Null": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "String": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "String": {
					const checks = combineChecks(a.checks, b.checks, b.annotations);
					return {
						_tag: "String",
						checks: checks ?? a.checks,
						...combineAnnotations(a.annotations, checks ? void 0 : b.annotations)
					};
				}
				case "Literal": return typeof b.literal === "string" ? {
					...b,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "Number": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Number": {
					const checks = combineNumberChecks(a.checks, b.checks, b.annotations);
					return {
						_tag: "Number",
						checks: checks ?? a.checks,
						...combineAnnotations(a.annotations, checks ? void 0 : b.annotations)
					};
				}
				case "Literal": return typeof b.literal === "number" ? {
					...b,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "Boolean": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Boolean": return {
					_tag: "Boolean",
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Literal": return typeof b.literal === "boolean" ? {
					...b,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "Literal": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Literal": return a.literal === b.literal ? {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "String": return typeof a.literal === "string" ? {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "Number": return typeof a.literal === "number" ? {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "Boolean": return typeof a.literal === "boolean" ? {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				} : never;
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "Arrays": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Arrays": {
					const checks = combineArraysChecks(a.checks, b.checks, b.annotations);
					return {
						_tag: "Arrays",
						elements: combineElements(a.elements, b.elements),
						rest: combineRest(a.rest, b.rest),
						checks: checks ?? a.checks,
						...combineAnnotations(a.annotations, checks ? void 0 : b.annotations)
					};
				}
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "Objects": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				case "Objects": {
					const checks = combineChecks(a.checks, b.checks, b.annotations);
					return {
						_tag: "Objects",
						propertySignatures: combinePropertySignatures(a.propertySignatures, b.propertySignatures),
						indexSignatures: combineIndexSignatures(a.indexSignatures, b.indexSignatures),
						checks: checks ?? a.checks,
						...combineAnnotations(a.annotations, checks ? void 0 : b.annotations)
					};
				}
				case "Union": return combine(b, a);
				case "Reference": return combine(a, resolveReference(b.$ref));
				default: return never;
			}
			case "Union": switch (b._tag) {
				case "Unknown": return {
					...a,
					...combineAnnotations(a.annotations, b.annotations)
				};
				default: {
					const types = a.types.map((s) => combine(s, b)).filter((s) => s !== never);
					if (types.length === 0) return never;
					return {
						_tag: "Union",
						types,
						mode: "anyOf",
						...makeAnnotations(a.annotations)
					};
				}
			}
		}
	}
	function collectProperties(js) {
		const properties = isObject(js.properties) ? js.properties : {};
		const required = Array.isArray(js.required) ? js.required : [];
		required.forEach((key) => {
			if (!Object.hasOwn(properties, key)) properties[key] = {};
		});
		return Object.entries(properties).map(([key, v]) => ({
			name: key,
			type: recur(v),
			isOptional: !required.includes(key),
			isMutable: false
		}));
	}
	function collectIndexSignatures(js) {
		const out = [];
		if (isObject(js.patternProperties)) for (const [pattern, value] of Object.entries(js.patternProperties)) out.push({
			parameter: recur({ pattern }),
			type: recur(value)
		});
		if (js.additionalProperties === void 0 || js.additionalProperties === true) out.push({
			parameter: string,
			type: unknown
		});
		else if (isObject(js.additionalProperties)) out.push({
			parameter: string,
			type: recur(js.additionalProperties)
		});
		return out;
	}
	function combineElements(a, b) {
		const len = Math.max(a.length, b.length);
		let out = [];
		for (let i = 0; i < len; i++) out.push({
			isOptional: a[i].isOptional && b[i].isOptional,
			type: combine(a[i].type, b[i].type)
		});
		if (a.length > len) out = [...out, ...a.slice(len)];
		else if (b.length > len) out = [...out, ...b.slice(len)];
		return out;
	}
	function combineRest(a, b) {
		const len = Math.max(a.length, b.length);
		let out = [];
		for (let i = 0; i < len; i++) out.push(combine(a[i], b[i]));
		if (a.length > len) out = [...out, ...a.slice(len)];
		else if (b.length > len) out = [...out, ...b.slice(len)];
		return out;
	}
	function combinePropertySignatures(a, b) {
		const propertySignatures = [];
		const thatPropertiesMap = {};
		for (const p of b) thatPropertiesMap[p.name] = p;
		const keys = /* @__PURE__ */ new Set();
		for (const p of a) {
			keys.add(p.name);
			const thatp = thatPropertiesMap[p.name];
			if (thatp) propertySignatures.push({
				name: p.name,
				type: combine(p.type, thatp.type),
				isOptional: p.isOptional && thatp.isOptional,
				isMutable: p.isMutable
			});
			else propertySignatures.push(p);
		}
		for (const p of b) if (!keys.has(p.name)) propertySignatures.push(p);
		return propertySignatures;
	}
	function combineIndexSignatures(a, b) {
		if (a.length === 0 || b.length === 0) return [];
		const out = [...a];
		for (const is of b) if (is.parameter === string) {
			const i = a.findIndex((is) => is.parameter === string);
			if (i !== -1) out[i] = {
				parameter: string,
				type: combine(a[i].type, is.type)
			};
			else out.push(is);
		} else out.push(is);
		return out;
	}
}
function asChecks(checks, annotations) {
	if (isReadonlyArrayNonEmpty(checks)) {
		if (annotations !== void 0) if (checks.length === 1) {
			const check = checks[0];
			if (check.annotations === void 0) return [{
				...check,
				annotations
			}];
			else return [{
				_tag: "FilterGroup",
				checks,
				annotations
			}];
		} else return [{
			_tag: "FilterGroup",
			checks,
			annotations
		}];
		return checks;
	}
}
function combineChecks(a, b, annotations) {
	const checks = asChecks(b, annotations);
	if (checks) return [...a, ...checks];
}
function combineNumberChecks(a, b, annotations) {
	if (a.some((c) => c._tag === "Filter" && c.meta._tag === "isFinite")) b = b.filter((c) => c._tag !== "Filter" || c.meta._tag !== "isFinite");
	if (a.some((c) => c._tag === "Filter" && c.meta._tag === "isInt")) b = b.filter((c) => c._tag !== "Filter" || c.meta._tag !== "isInt");
	return combineChecks(a, b, annotations);
}
function combineArraysChecks(a, b, annotations) {
	if (a.some((c) => c._tag === "Filter" && c.meta._tag === "isUnique")) b = b.filter((c) => c._tag !== "Filter" || c.meta._tag !== "isUnique");
	return combineChecks(a, b, annotations);
}
function makeAnnotations(annotations) {
	return annotations ? { annotations } : void 0;
}
function combineAnnotations(a, b) {
	if (a === void 0) return makeAnnotations(b);
	if (b === void 0) return makeAnnotations(a);
	return { annotations: {
		...a,
		...b
	} };
}
function collectStringChecks(js) {
	const checks = [];
	if (typeof js.minLength === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isMinLength",
			minLength: js.minLength
		}
	});
	if (typeof js.maxLength === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isMaxLength",
			maxLength: js.maxLength
		}
	});
	if (typeof js.pattern === "string") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isPattern",
			regExp: new RegExp(js.pattern)
		}
	});
	return checks;
}
function collectNumberChecks(js) {
	const checks = [];
	if (typeof js.minimum === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isGreaterThanOrEqualTo",
			minimum: js.minimum
		}
	});
	if (typeof js.maximum === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isLessThanOrEqualTo",
			maximum: js.maximum
		}
	});
	if (typeof js.exclusiveMinimum === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isGreaterThan",
			exclusiveMinimum: js.exclusiveMinimum
		}
	});
	if (typeof js.exclusiveMaximum === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isLessThan",
			exclusiveMaximum: js.exclusiveMaximum
		}
	});
	if (typeof js.multipleOf === "number") checks.push({
		_tag: "Filter",
		meta: {
			_tag: "isMultipleOf",
			divisor: js.multipleOf
		}
	});
	return checks;
}
function collectArraysChecks(js) {
	const checks = [];
	if (js.prefixItems === void 0) {
		if (typeof js.minItems === "number") checks.push({
			_tag: "Filter",
			meta: {
				_tag: "isMinLength",
				minLength: js.minItems
			}
		});
		if (typeof js.maxItems === "number") checks.push({
			_tag: "Filter",
			meta: {
				_tag: "isMaxLength",
				maxLength: js.maxItems
			}
		});
	}
	if (typeof js.uniqueItems === "boolean") checks.push({
		_tag: "Filter",
		meta: { _tag: "isUnique" }
	});
	return checks;
}
var unknown = { _tag: "Unknown" };
var never = { _tag: "Never" };
var null_ = { _tag: "Null" };
var string = {
	_tag: "String",
	checks: []
};
var boolean = { _tag: "Boolean" };
function collectAnnotations(schema) {
	const as = {};
	if (typeof schema.title === "string") as.title = schema.title;
	if (typeof schema.description === "string") as.description = schema.description;
	if (schema.default !== void 0) as.default = schema.default;
	if (Array.isArray(schema.examples)) as.examples = schema.examples;
	if (typeof schema.readOnly === "boolean") as.readOnly = schema.readOnly;
	if (typeof schema.writeOnly === "boolean") as.writeOnly = schema.writeOnly;
	if (typeof schema.format === "string") as.format = schema.format;
	if (typeof schema.contentEncoding === "string") as.contentEncoding = schema.contentEncoding;
	if (typeof schema.contentMediaType === "string") as.contentMediaType = schema.contentMediaType;
	return isEmptyRecord(as) ? void 0 : as;
}
function isLiteralValue(value) {
	return typeof value === "string" || typeof value === "number" || typeof value === "boolean";
}
var stringKeys = [
	"minLength",
	"maxLength",
	"pattern",
	"format",
	"contentMediaType",
	"contentSchema"
];
var numberKeys = [
	"minimum",
	"maximum",
	"exclusiveMinimum",
	"exclusiveMaximum",
	"multipleOf"
];
var objectKeys = [
	"properties",
	"required",
	"additionalProperties",
	"patternProperties",
	"propertyNames",
	"minProperties",
	"maxProperties"
];
var arrayKeys = [
	"items",
	"prefixItems",
	"additionalItems",
	"minItems",
	"maxItems",
	"uniqueItems"
];
function getType(js) {
	if (stringKeys.some((key) => js[key] !== void 0)) return "string";
	if (numberKeys.some((key) => js[key] !== void 0)) return "number";
	if (objectKeys.some((key) => js[key] !== void 0)) return "object";
	if (arrayKeys.some((key) => js[key] !== void 0)) return "array";
}
var types = [
	"null",
	"string",
	"number",
	"integer",
	"boolean",
	"object",
	"array"
];
function isType(type) {
	return typeof type === "string" && types.includes(type);
}
/** @internal */
function topologicalSort(references) {
	const identifiers = Object.keys(references);
	const identifierSet = new Set(identifiers);
	const collectRefs = (root) => {
		const refs = /* @__PURE__ */ new Set();
		const visited = /* @__PURE__ */ new WeakSet();
		const stack = [root];
		while (stack.length > 0) {
			const r = stack.pop();
			if (visited.has(r)) continue;
			visited.add(r);
			if (r._tag === "Reference") {
				if (identifierSet.has(r.$ref)) refs.add(r.$ref);
			}
			switch (r._tag) {
				case "Declaration":
					for (const typeParam of r.typeParameters) stack.push(typeParam);
					stack.push(r.encodedSchema);
					break;
				case "Suspend":
					stack.push(r.thunk);
					break;
				case "String":
					if (r.contentSchema !== void 0) stack.push(r.contentSchema);
					break;
				case "TemplateLiteral":
					for (const part of r.parts) stack.push(part);
					break;
				case "Arrays":
					for (const element of r.elements) stack.push(element.type);
					for (const rest of r.rest) stack.push(rest);
					break;
				case "Objects":
					for (const propertySignature of r.propertySignatures) stack.push(propertySignature.type);
					for (const indexSignature of r.indexSignatures) {
						stack.push(indexSignature.parameter);
						stack.push(indexSignature.type);
					}
					break;
				case "Union":
					for (const type of r.types) stack.push(type);
					break;
			}
		}
		return refs;
	};
	const dependencies = new Map(identifiers.map((id) => [id, collectRefs(references[id])]));
	const recursive = /* @__PURE__ */ new Set();
	const state = /* @__PURE__ */ new Map();
	const stack = [];
	const indexInStack = /* @__PURE__ */ new Map();
	const dfs = (id) => {
		const s = state.get(id) ?? 0;
		if (s === 1) {
			const start = indexInStack.get(id);
			if (start !== void 0) for (let i = start; i < stack.length; i++) recursive.add(stack[i]);
			return;
		}
		if (s === 2) return;
		state.set(id, 1);
		indexInStack.set(id, stack.length);
		stack.push(id);
		for (const dep of dependencies.get(id) ?? []) dfs(dep);
		stack.pop();
		indexInStack.delete(id);
		state.set(id, 2);
	};
	for (const id of identifiers) dfs(id);
	const inDegree = /* @__PURE__ */ new Map();
	const dependents = /* @__PURE__ */ new Map();
	for (const id of identifiers) if (!recursive.has(id)) {
		inDegree.set(id, 0);
		dependents.set(id, /* @__PURE__ */ new Set());
	}
	for (const [id, deps] of dependencies) {
		if (recursive.has(id)) continue;
		for (const dep of deps) {
			if (recursive.has(dep)) continue;
			inDegree.set(id, (inDegree.get(id) ?? 0) + 1);
			dependents.get(dep)?.add(id);
		}
	}
	const queue = [];
	for (const [id, deg] of inDegree) if (deg === 0) queue.push(id);
	const nonRecursives = [];
	for (let i = 0; i < queue.length; i++) {
		const $ref = queue[i];
		nonRecursives.push({
			$ref,
			representation: references[$ref]
		});
		for (const next of dependents.get($ref) ?? []) {
			const deg = (inDegree.get(next) ?? 0) - 1;
			inDegree.set(next, deg);
			if (deg === 0) queue.push(next);
		}
	}
	const recursives = {};
	for (const $ref of recursive) recursives[$ref] = references[$ref];
	return {
		nonRecursives,
		recursives
	};
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/SchemaUtils.js
/**
* @since 4.0.0
*/
var SchemaUtils_exports = /* @__PURE__ */ __exportAll({ getNativeClassSchema: () => getNativeClassSchema });
/**
* @since 4.0.0
* @experimental
*/
function getNativeClassSchema(constructor, options) {
	const transformation = transform({
		decode: (props) => new constructor(props),
		encode: identity
	});
	return instanceOf$2(constructor, {
		toCodec: () => link()(options.encoding, transformation),
		...options.annotations
	}).pipe(encodeTo(options.encoding, transformation));
}
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/ScopedCache.js
/**
* @since 4.0.0
*/
var ScopedCache_exports = /* @__PURE__ */ __exportAll({
	entries: () => entries$3,
	get: () => get$7,
	getOption: () => getOption,
	getSuccess: () => getSuccess,
	has: () => has$4,
	invalidate: () => invalidate,
	invalidateAll: () => invalidateAll,
	invalidateWhen: () => invalidateWhen,
	keys: () => keys$3,
	make: () => make$13,
	makeWith: () => makeWith,
	refresh: () => refresh,
	set: () => set$5,
	size: () => size$8,
	values: () => values$3
});
var TypeId$13 = "~effect/ScopedCache";
/**
* @since 4.0.0
* @category Constructors
*/
var makeWith = (options) => servicesWith((services) => {
	const scope = get$16(services, Scope);
	const self = Object.create(Proto$1);
	self.lookup = (key) => updateServices(options.lookup(key), (input) => merge(services, input));
	const map = empty$12();
	self.state = {
		_tag: "Open",
		map
	};
	self.capacity = options.capacity;
	self.timeToLive = options.timeToLive ? (exit, key) => fromInputUnsafe(options.timeToLive(exit, key)) : defaultTimeToLive;
	return as(addFinalizer$2(scope, withFiber((fiber) => {
		self.state = { _tag: "Closed" };
		return invalidateAllImpl(fiber, map);
	})), self);
});
/**
* @since 4.0.0
* @category Constructors
*/
var make$13 = (options) => makeWith({
	...options,
	timeToLive: options.timeToLive ? () => options.timeToLive : defaultTimeToLive
});
var Proto$1 = {
	...PipeInspectableProto,
	[TypeId$13]: TypeId$13,
	toJSON() {
		return {
			_id: "ScopedCache",
			capacity: this.capacity,
			state: this.state
		};
	}
};
var defaultTimeToLive = (_, _key) => infinity;
/**
* @since 4.0.0
* @category Combinators
*/
var get$7 = /*#__PURE__*/ dual(2, (self, key) => uninterruptibleMask$1((restore) => withFiber((fiber) => {
	const state = self.state;
	if (state._tag === "Closed") return interrupt$2;
	const oentry = get$18(state.map, key);
	if (isSome(oentry) && !hasExpired(oentry.value, fiber)) {
		remove$9(state.map, key);
		set$13(state.map, key, oentry.value);
		return restore(_await(oentry.value.deferred));
	}
	const scope = makeUnsafe$9();
	const deferred = makeUnsafe$8();
	const entry = {
		expiresAt: void 0,
		deferred,
		scope
	};
	set$13(state.map, key, entry);
	return checkCapacity(fiber, state.map, self.capacity).pipe(isSome(oentry) ? flatMap$3(() => close(oentry.value.scope, exitVoid)) : identity, flatMap$3(() => provide$2(restore(self.lookup(key)), scope)), onExit((exit) => {
		doneUnsafe(deferred, exit);
		const ttl = self.timeToLive(exit, key);
		if (isFinite(ttl)) entry.expiresAt = fiber.getRef(ClockRef).currentTimeMillisUnsafe() + toMillis(ttl);
		return void_;
	}));
})));
var hasExpired = (entry, fiber) => {
	if (entry.expiresAt === void 0) return false;
	return fiber.getRef(ClockRef).currentTimeMillisUnsafe() >= entry.expiresAt;
};
var checkCapacity = (parent, map, capacity) => {
	if (!Number.isFinite(capacity)) return void_;
	let diff = size$15(map) - capacity;
	if (diff <= 0) return void_;
	const fibers = empty$8();
	for (const [key, entry] of map) {
		remove$9(map, key);
		fibers.push(forkUnsafe(parent, close(entry.scope, exitVoid), true));
		diff--;
		if (diff === 0) break;
	}
	return fiberAwaitAll(fibers);
};
/**
* @since 4.0.0
* @category Combinators
*/
var getOption = /*#__PURE__*/ dual(2, (self, key) => uninterruptibleMask$1((restore) => withFiber((fiber) => flatMap$3(getImpl(self, key, fiber), (entry) => entry ? asSome(restore(_await(entry.deferred))) : succeedNone))));
var getImpl = (self, key, fiber, isRead = true) => {
	if (self.state._tag === "Closed") return interrupt$2;
	const state = self.state;
	const oentry = get$18(state.map, key);
	if (isNone(oentry)) return undefined_;
	else if (hasExpired(oentry.value, fiber)) {
		remove$9(state.map, key);
		return as(close(oentry.value.scope, exitVoid), void 0);
	} else if (isRead) {
		remove$9(state.map, key);
		set$13(state.map, key, oentry.value);
	}
	return succeed$3(oentry.value);
};
/**
* Retrieves the value associated with the specified key from the cache, only if
* it contains a resolved successful value.
*
* @since 4.0.0
* @category Combinators
*/
var getSuccess = /*#__PURE__*/ dual(2, (self, key) => uninterruptible$1(withFiber((fiber) => map$9(getImpl(self, key, fiber), (entry) => {
	const exit = entry?.deferred.effect;
	if (exit && exitIsSuccess(exit)) return some$2(exit.value);
	return none();
}))));
/**
* Sets the value associated with the specified key in the cache. This will
* overwrite any existing value for that key, skipping the lookup function.
*
* @since 4.0.0
* @category Combinators
*/
var set$5 = /*#__PURE__*/ dual(3, (self, key, value) => uninterruptible$1(withFiber((fiber) => {
	if (self.state._tag === "Closed") return interrupt$2;
	const oentry = get$18(self.state.map, key);
	const state = self.state;
	const exit = exitSucceed(value);
	const deferred = makeUnsafe$8();
	doneUnsafe(deferred, exit);
	const ttl = self.timeToLive(exit, key);
	set$13(state.map, key, {
		scope: makeUnsafe$9(),
		deferred,
		expiresAt: isFinite(ttl) ? fiber.getRef(ClockRef).currentTimeMillisUnsafe() + toMillis(ttl) : void 0
	});
	const check = checkCapacity(fiber, state.map, self.capacity);
	return isSome(oentry) ? flatMap$3(close(oentry.value.scope, exitVoid), () => check) : check;
})));
/**
* Checks if the cache contains an entry for the specified key.
*
* @since 4.0.0
* @category Combinators
*/
var has$4 = /*#__PURE__*/ dual(2, (self, key) => uninterruptible$1(withFiber((fiber) => map$9(getImpl(self, key, fiber, false), isNotUndefined))));
/**
* Invalidates the entry associated with the specified key in the cache.
*
* @since 4.0.0
* @category Combinators
*/
var invalidate = /*#__PURE__*/ dual(2, (self, key) => uninterruptible$1(suspend$1(() => {
	if (self.state._tag === "Closed") return interrupt$2;
	const oentry = get$18(self.state.map, key);
	if (isNone(oentry)) return void_;
	remove$9(self.state.map, key);
	return close(oentry.value.scope, exitVoid);
})));
/**
* Conditionally invalidates the entry associated with the specified key in the cache
* if the predicate returns true for the cached value.
*
* @since 4.0.0
* @category Combinators
*/
var invalidateWhen = /*#__PURE__*/ dual(3, (self, key, f) => uninterruptibleMask$1((restore) => withFiber((fiber) => flatMap$3(getImpl(self, key, fiber, false), (entry) => {
	if (entry === void 0) return succeed$3(false);
	return restore(_await(entry.deferred)).pipe(flatMap$3((value) => {
		if (self.state._tag === "Closed") return succeed$3(false);
		else if (f(value)) {
			remove$9(self.state.map, key);
			return as(close(entry.scope, exitVoid), true);
		}
		return succeed$3(false);
	}), catch_$1(() => succeed$3(false)));
}))));
/**
* Forces a refresh of the value associated with the specified key in the cache.
*
* It will always invoke the lookup function to construct a new value,
* overwriting any existing value for that key.
*
* @since 4.0.0
* @category Combinators
*/
var refresh = /*#__PURE__*/ dual(2, (self, key) => uninterruptibleMask$1(fnUntraced$1(function* (restore) {
	if (self.state._tag === "Closed") return yield* interrupt$2;
	const fiber = getCurrent();
	const scope = makeUnsafe$9();
	const deferred = makeUnsafe$8();
	const entry = {
		scope,
		expiresAt: void 0,
		deferred
	};
	const newEntry = !has$12(self.state.map, key);
	if (newEntry) {
		set$13(self.state.map, key, entry);
		yield* checkCapacity(fiber, self.state.map, self.capacity);
	}
	const exit = yield* exit$1(restore(provide$2(self.lookup(key), scope)));
	doneUnsafe(deferred, exit);
	if (self.state._tag === "Closed") {
		if (!newEntry) yield* close(scope, exitVoid);
		return yield* interrupt$2;
	}
	const ttl = self.timeToLive(exit, key);
	entry.expiresAt = isFinite(ttl) ? fiber.getRef(ClockRef).currentTimeMillisUnsafe() + toMillis(ttl) : void 0;
	if (!newEntry) {
		const oentry = get$18(self.state.map, key);
		set$13(self.state.map, key, entry);
		if (isSome(oentry)) yield* close(oentry.value.scope, exitVoid);
	}
	return yield* exit;
})));
/**
* Invalidates all entries in the cache.
*
* @since 4.0.0
* @category Combinators
*/
var invalidateAll = (self) => withFiber((parent) => {
	if (self.state._tag === "Closed") return interrupt$2;
	return invalidateAllImpl(parent, self.state.map);
});
var invalidateAllImpl = (parent, map) => {
	const fibers = empty$8();
	for (const [, entry] of map) fibers.push(forkUnsafe(parent, close(entry.scope, exitVoid), true, true));
	clear$7(map);
	return fiberAwaitAll(fibers);
};
/**
* Retrieves the approximate number of entries in the cache.
*
* Note that expired entries are counted until they are accessed and removed.
* The size reflects the current number of entries stored, not the number
* of valid entries.
*
* @since 4.0.0
* @category Combinators
*/
var size$8 = (self) => sync(() => self.state._tag === "Closed" ? 0 : size$15(self.state.map));
/**
* Retrieves all active keys from the cache, automatically filtering out expired entries.
*
* @since 4.0.0
* @category Combinators
*/
var keys$3 = (self) => withFiber((fiber) => {
	if (self.state._tag === "Closed") return succeed$3([]);
	const state = self.state;
	const now = fiber.getRef(ClockRef).currentTimeMillisUnsafe();
	const fibers = empty$8();
	const keys = [];
	for (const [key, entry] of state.map) if (entry.expiresAt === void 0 || entry.expiresAt > now) keys.push(key);
	else {
		remove$9(state.map, key);
		fibers.push(forkUnsafe(fiber, close(entry.scope, exitVoid), true, true));
	}
	return fibers.length === 0 ? succeed$3(keys) : as(fiberAwaitAll(fibers), keys);
});
/**
* Retrieves all successfully cached values from the cache, excluding failed
* lookups and expired entries.
*
* @since 4.0.0
* @category Combinators
*/
var values$3 = (self) => map$9(entries$3(self), map$12(([, value]) => value));
/**
* Retrieves all key-value pairs from the cache as an iterable. This function
* only returns entries with successfully resolved values, filtering out any
* failed lookups or expired entries.
*
* @since 4.0.0
* @category Combinators
*/
var entries$3 = (self) => withFiber((fiber) => {
	if (self.state._tag === "Closed") return succeed$3([]);
	const state = self.state;
	const now = fiber.getRef(ClockRef).currentTimeMillisUnsafe();
	const fibers = empty$8();
	const arr = [];
	for (const [key, entry] of state.map) if (entry.expiresAt === void 0 || entry.expiresAt > now) {
		const exit = entry.deferred.effect;
		if (isExit(exit) && !exitIsFailure(exit)) arr.push([key, exit.value]);
	} else {
		remove$9(state.map, key);
		fibers.push(forkUnsafe(fiber, close(entry.scope, exitVoid), true, true));
	}
	return fibers.length === 0 ? succeed$3(arr) : as(fiberAwaitAll(fibers), arr);
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/SubscriptionRef.js
/**
* @since 2.0.0
*/
var SubscriptionRef_exports = /* @__PURE__ */ __exportAll({
	changes: () => changes$1,
	get: () => get$6,
	getAndSet: () => getAndSet$1,
	getAndUpdate: () => getAndUpdate$1,
	getAndUpdateEffect: () => getAndUpdateEffect,
	getAndUpdateSome: () => getAndUpdateSome,
	getAndUpdateSomeEffect: () => getAndUpdateSomeEffect,
	getUnsafe: () => getUnsafe$2,
	isSubscriptionRef: () => isSubscriptionRef,
	make: () => make$12,
	modify: () => modify$6,
	modifyEffect: () => modifyEffect,
	modifySome: () => modifySome,
	modifySomeEffect: () => modifySomeEffect,
	set: () => set$4,
	setAndGet: () => setAndGet,
	update: () => update$3,
	updateAndGet: () => updateAndGet$1,
	updateAndGetEffect: () => updateAndGetEffect,
	updateEffect: () => updateEffect,
	updateSome: () => updateSome,
	updateSomeAndGet: () => updateSomeAndGet,
	updateSomeAndGetEffect: () => updateSomeAndGetEffect,
	updateSomeEffect: () => updateSomeEffect
});
var TypeId$12 = "~effect/SubscriptionRef";
/**
* @since 4.0.0
* @category guards
*/
var isSubscriptionRef = (u) => typeof u === "object" && u != null && TypeId$12 in u;
var Proto = {
	...PipeInspectableProto,
	[TypeId$12]: { _A: identity },
	toJSON() {
		return {
			_id: "SubscriptionRef",
			value: this.backing.ref.current
		};
	}
};
/**
* Constructs a new `SubscriptionRef` from an initial value.
*
* @since 2.0.0
* @category constructors
*/
var make$12 = (value) => map$11(unbounded$2({ replay: 1 }), (pubsub) => {
	const self = Object.create(Proto);
	self.semaphore = makeUnsafe$10(1);
	self.backing = makeUnsafe$5(value);
	self.pubsub = pubsub;
	publishUnsafe(self.pubsub, value);
	return self;
});
/**
* Creates a stream that emits the current value and all subsequent changes to
* the `SubscriptionRef`.
*
* The stream will first emit the current value, then emit all future changes
* as they occur.
*
* @example
* ```ts
* import { Effect, Stream, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(0)
*
*   const stream = SubscriptionRef.changes(ref)
*
*   const fiber = yield* Stream.runForEach(
*     stream,
*     (value) => Effect.sync(() => console.log("Value:", value))
*   ).pipe(Effect.forkScoped)
*
*   yield* SubscriptionRef.set(ref, 1)
*   yield* SubscriptionRef.set(ref, 2)
* })
* ```
*
* @category changes
* @since 2.0.0
*/
var changes$1 = (self) => fromPubSub(self.pubsub);
/**
* Unsafely retrieves the current value of the `SubscriptionRef`.
*
* This function directly accesses the underlying reference without any
* synchronization. It should only be used when you're certain there are no
* concurrent modifications.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(42)
*
*   const value = SubscriptionRef.getUnsafe(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var getUnsafe$2 = (self) => self.backing.ref.current;
/**
* Retrieves the current value of the `SubscriptionRef`.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(42)
*
*   const value = yield* SubscriptionRef.get(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var get$6 = (self) => sync$1(() => getUnsafe$2(self));
/**
* Atomically retrieves the current value and sets a new value, notifying
* subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const oldValue = yield* SubscriptionRef.getAndSet(ref, 20)
*   console.log("Old value:", oldValue)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var getAndSet$1 = /*#__PURE__*/ dual(2, (self, value) => self.semaphore.withPermit(flatMap$2(getAndSet$3(self.backing, value), (oldValue) => as$1(publish$1(self.pubsub, value), oldValue))));
/**
* Atomically retrieves the current value and updates it with the result of
* applying a function, notifying subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const oldValue = yield* SubscriptionRef.getAndUpdate(ref, (n) => n * 2)
*   console.log("Old value:", oldValue)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var getAndUpdate$1 = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	const newValue = update(current);
	self.backing.ref.current = newValue;
	return as$1(publish$1(self.pubsub, newValue), current);
})));
/**
* Atomically retrieves the current value and updates it with the result of
* applying an effectful function, notifying subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const oldValue = yield* SubscriptionRef.getAndUpdateEffect(
*     ref,
*     (n) => Effect.succeed(n + 5)
*   )
*   console.log("Old value:", oldValue)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var getAndUpdateEffect = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(update(current), (newValue) => {
		self.backing.ref.current = newValue;
		return as$1(publish$1(self.pubsub, newValue), current);
	});
})));
/**
* Atomically retrieves the current value and optionally updates it with the
* result of applying a function that returns an `Option`, notifying
* subscribers only if the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const oldValue = yield* SubscriptionRef.getAndUpdateSome(
*     ref,
*     (n) => n > 5 ? Option.some(n * 2) : Option.none()
*   )
*   console.log("Old value:", oldValue)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var getAndUpdateSome = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	const option = update(current);
	if (isNone(option)) return succeed$4(current);
	self.backing.ref.current = option.value;
	return map$11(publish$1(self.pubsub, option.value), () => current);
})));
/**
* Atomically retrieves the current value and optionally updates it with the
* result of applying an effectful function that returns an `Option`,
* notifying subscribers only if the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const oldValue = yield* SubscriptionRef.getAndUpdateSomeEffect(
*     ref,
*     (n) => Effect.succeed(n > 5 ? Option.some(n + 3) : Option.none())
*   )
*   console.log("Old value:", oldValue)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var getAndUpdateSomeEffect = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(update(current), (option) => {
		if (isNone(option)) return succeed$4(current);
		self.backing.ref.current = option.value;
		return as$1(publish$1(self.pubsub, option.value), current);
	});
})));
/**
* Atomically modifies the `SubscriptionRef` with a function that computes a
* return value and a new value, notifying subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const result = yield* SubscriptionRef.modify(ref, (n) => [
*     `Old value was ${n}`,
*     n * 2
*   ])
*   console.log(result)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category modifications
*/
var modify$6 = /*#__PURE__*/ dual(2, (self, modify) => self.semaphore.withPermit(suspend(() => {
	const [b, newValue] = modify(self.backing.ref.current);
	self.backing.ref.current = newValue;
	return as$1(publish$1(self.pubsub, newValue), b);
})));
/**
* Atomically modifies the `SubscriptionRef` with an effectful function that
* computes a return value and a new value, notifying subscribers of the
* change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const result = yield* SubscriptionRef.modifyEffect(
*     ref,
*     (n) => Effect.succeed([`Doubled from ${n}`, n * 2] as const)
*   )
*   console.log(result)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category modifications
*/
var modifyEffect = /*#__PURE__*/ dual(2, (self, modify) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(modify(current), ([b, newValue]) => {
		self.backing.ref.current = newValue;
		return as$1(publish$1(self.pubsub, newValue), b);
	});
})));
/**
* Atomically modifies the `SubscriptionRef` with a function that computes a
* return value and optionally a new value, notifying subscribers only if the
* value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const result = yield* SubscriptionRef.modifySome(
*     ref,
*     (n) =>
*       n > 5 ? ["Updated", Option.some(n * 2)] : ["Not updated", Option.none()]
*   )
*   console.log(result)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category modifications
*/
var modifySome = /*#__PURE__*/ dual(2, (self, modify) => self.semaphore.withPermit(suspend(() => {
	const [b, option] = modify(self.backing.ref.current);
	if (isNone(option)) return succeed$4(b);
	self.backing.ref.current = option.value;
	return as$1(publish$1(self.pubsub, option.value), b);
})));
/**
* Atomically modifies the `SubscriptionRef` with an effectful function that
* computes a return value and optionally a new value, notifying subscribers
* only if the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const result = yield* SubscriptionRef.modifySomeEffect(
*     ref,
*     (n) =>
*       Effect.succeed(
*         n > 5
*           ? (["Updated", Option.some(n + 5)] as const)
*           : (["Not updated", Option.none()] as const)
*       )
*   )
*   console.log(result)
*
*   const newValue = yield* SubscriptionRef.get(ref)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category modifications
*/
var modifySomeEffect = /*#__PURE__*/ dual(2, (self, modify) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(modify(current), ([b, option]) => {
		if (isNone(option)) return succeed$4(b);
		self.backing.ref.current = option.value;
		return as$1(publish$1(self.pubsub, option.value), b);
	});
})));
/**
* Sets the value of the `SubscriptionRef`, notifying all subscribers of the
* change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(0)
*
*   yield* SubscriptionRef.set(ref, 42)
*
*   const value = yield* SubscriptionRef.get(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var set$4 = /*#__PURE__*/ dual(2, (self, value) => self.semaphore.withPermit(suspend(() => {
	self.backing.ref.current = value;
	return asVoid(publish$1(self.pubsub, value));
})));
/**
* Sets the value of the `SubscriptionRef` and returns the new value,
* notifying all subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(0)
*
*   const newValue = yield* SubscriptionRef.setAndGet(ref, 42)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category setters
*/
var setAndGet = /*#__PURE__*/ dual(2, (self, value) => self.semaphore.withPermit(suspend(() => {
	self.backing.ref.current = value;
	return map$11(publish$1(self.pubsub, value), () => value);
})));
/**
* Updates the value of the `SubscriptionRef` with the result of applying a
* function, notifying subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   yield* SubscriptionRef.update(ref, (n) => n * 2)
*
*   const value = yield* SubscriptionRef.get(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var update$3 = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const newValue = update(self.backing.ref.current);
	self.backing.ref.current = newValue;
	return asVoid(publish$1(self.pubsub, newValue));
})));
/**
* Updates the value of the `SubscriptionRef` with the result of applying an
* effectful function, notifying subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   yield* SubscriptionRef.updateEffect(ref, (n) => Effect.succeed(n + 5))
*
*   const value = yield* SubscriptionRef.get(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateEffect = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(update(current), (newValue) => {
		self.backing.ref.current = newValue;
		return asVoid(publish$1(self.pubsub, newValue));
	});
})));
/**
* Updates the value of the `SubscriptionRef` with the result of applying a
* function and returns the new value, notifying subscribers of the change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const newValue = yield* SubscriptionRef.updateAndGet(ref, (n) => n * 2)
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateAndGet$1 = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const newValue = update(self.backing.ref.current);
	self.backing.ref.current = newValue;
	return as$1(publish$1(self.pubsub, newValue), newValue);
})));
/**
* Updates the value of the `SubscriptionRef` with the result of applying an
* effectful function and returns the new value, notifying subscribers of the
* change.
*
* @example
* ```ts
* import { Effect, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const newValue = yield* SubscriptionRef.updateAndGetEffect(
*     ref,
*     (n) => Effect.succeed(n + 5)
*   )
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateAndGetEffect = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(update(current), (newValue) => {
		self.backing.ref.current = newValue;
		return as$1(publish$1(self.pubsub, newValue), newValue);
	});
})));
/**
* Optionally updates the value of the `SubscriptionRef` with the result of
* applying a function that returns an `Option`, notifying subscribers only if
* the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   yield* SubscriptionRef.updateSome(
*     ref,
*     (n) => n > 5 ? Option.some(n * 2) : Option.none()
*   )
*
*   const value = yield* SubscriptionRef.get(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateSome = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const option = update(self.backing.ref.current);
	if (isNone(option)) return void_$1;
	self.backing.ref.current = option.value;
	return asVoid(publish$1(self.pubsub, option.value));
})));
/**
* Optionally updates the value of the `SubscriptionRef` with the result of
* applying an effectful function that returns an `Option`, notifying
* subscribers only if the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   yield* SubscriptionRef.updateSomeEffect(
*     ref,
*     (n) => Effect.succeed(n > 5 ? Option.some(n + 3) : Option.none())
*   )
*
*   const value = yield* SubscriptionRef.get(ref)
*   console.log(value)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateSomeEffect = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(update(current), (option) => {
		if (isNone(option)) return void_$1;
		self.backing.ref.current = option.value;
		return asVoid(publish$1(self.pubsub, option.value));
	});
})));
/**
* Optionally updates the value of the `SubscriptionRef` with the result of
* applying a function that returns an `Option` and returns the new value,
* notifying subscribers only if the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const newValue = yield* SubscriptionRef.updateSomeAndGet(
*     ref,
*     (n) => n > 5 ? Option.some(n * 2) : Option.none()
*   )
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateSomeAndGet = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	const option = update(current);
	if (isNone(option)) return succeed$4(current);
	self.backing.ref.current = option.value;
	return as$1(publish$1(self.pubsub, option.value), option.value);
})));
/**
* Optionally updates the value of the `SubscriptionRef` with the result of
* applying an effectful function that returns an `Option` and returns the new
* value, notifying subscribers only if the value changes.
*
* @example
* ```ts
* import { Effect, Option, SubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* SubscriptionRef.make(10)
*
*   const newValue = yield* SubscriptionRef.updateSomeAndGetEffect(
*     ref,
*     (n) => Effect.succeed(n > 5 ? Option.some(n + 3) : Option.none())
*   )
*   console.log("New value:", newValue)
* })
* ```
*
* @since 2.0.0
* @category updating
*/
var updateSomeAndGetEffect = /*#__PURE__*/ dual(2, (self, update) => self.semaphore.withPermit(suspend(() => {
	const current = self.backing.ref.current;
	return flatMap$2(update(current), (option) => {
		if (isNone(option)) return succeed$4(current);
		self.backing.ref.current = option.value;
		return as$1(publish$1(self.pubsub, option.value), option.value);
	});
})));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Symbol.js
/**
* @since 2.0.0
*/
var Symbol_exports = /* @__PURE__ */ __exportAll({ isSymbol: () => isSymbol });
/**
* Tests if a value is a `symbol`.
*
* @example
* ```ts
* import * as Predicate from "effect/Predicate"
* import * as assert from "node:assert"
*
* assert.deepStrictEqual(Predicate.isSymbol(Symbol.for("a")), true)
* assert.deepStrictEqual(Predicate.isSymbol("a"), false)
* ```
*
* @category guards
* @since 2.0.0
*/
var isSymbol = isSymbol$1;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Terminal.js
var Terminal_exports = /* @__PURE__ */ __exportAll({
	QuitError: () => QuitError,
	Terminal: () => Terminal,
	isQuitError: () => isQuitError,
	make: () => make$11
});
var TypeId$11 = "~effect/platform/Terminal";
var QuitErrorTypeId = "effect/platform/Terminal/QuitError";
/**
* A `QuitError` represents an error that occurs when a user attempts to
* quit out of a `Terminal` prompt for input (usually by entering `ctrl`+`c`).
*
* @since 4.0.0
* @category QuitError
*/
var QuitError = class extends ErrorClass("QuitError")({ _tag: /*#__PURE__*/ tag$2("QuitError") }) {
	/**
	* @since 4.0.0
	*/
	[QuitErrorTypeId] = QuitErrorTypeId;
};
/**
* @since 4.0.0
* @category QuitError
*/
var isQuitError = (u) => hasProperty(u, QuitErrorTypeId);
/**
* @since 4.0.0
* @category Services
*/
var Terminal = /*#__PURE__*/ Service$1("effect/platform/Terminal");
/**
* Creates a Terminal implementation
*
* @since 4.0.0
* @category Constructors
*/
var make$11 = (impl) => Terminal.of({
	...impl,
	[TypeId$11]: TypeId$11
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/internal/trie.js
/** @internal */
var TrieTypeId = "~effect/collections/Trie";
var trieVariance = { 
/* c8 ignore next */
_Value: (_) => _ };
var TrieProto = {
	[TrieTypeId]: trieVariance,
	[Symbol.iterator]() {
		return new TrieIterator(this, (k, v) => [k, v], () => true);
	},
	[symbol$2]() {
		let hash$1 = hash(TrieTypeId);
		for (const item of this) hash$1 ^= pipe(hash(item[0]), combine(hash(item[1])));
		return hash$1;
	},
	[symbol$1](that) {
		if (isTrie(that)) {
			const entries = Array.from(that);
			return Array.from(this).every((itemSelf, i) => {
				const itemThat = entries[i];
				return equals(itemSelf[0], itemThat[0]) && equals(itemSelf[1], itemThat[1]);
			});
		}
		return false;
	},
	toString() {
		return `Trie(${format$1(Array.from(this))})`;
	},
	toJSON() {
		return {
			_id: "Trie",
			values: toJson(Array.from(this))
		};
	},
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeImpl = (root) => {
	const trie = Object.create(TrieProto);
	trie._root = root;
	trie._count = root?.count ?? 0;
	return trie;
};
var TrieIterator = class TrieIterator {
	stack = [];
	trie;
	f;
	filter;
	constructor(trie, f, filter) {
		this.trie = trie;
		this.f = f;
		this.filter = filter;
		const root = trie._root !== void 0 ? trie._root : void 0;
		if (root !== void 0) this.stack.push([
			root,
			"",
			false
		]);
	}
	next() {
		while (this.stack.length > 0) {
			const [node, keyString, isAdded] = this.stack.pop();
			if (isAdded) {
				const value = node.value;
				if (value !== void 0) {
					const key = keyString + node.key;
					if (this.filter(key, value)) return {
						done: false,
						value: this.f(key, value)
					};
				}
			} else this.addToStack(node, keyString);
		}
		return {
			done: true,
			value: void 0
		};
	}
	addToStack(node, keyString) {
		if (node.right !== void 0) this.stack.push([
			node.right,
			keyString,
			false
		]);
		if (node.mid !== void 0) this.stack.push([
			node.mid,
			keyString + node.key,
			false
		]);
		this.stack.push([
			node,
			keyString,
			true
		]);
		if (node.left !== void 0) this.stack.push([
			node.left,
			keyString,
			false
		]);
	}
	[Symbol.iterator]() {
		return new TrieIterator(this.trie, this.f, this.filter);
	}
};
/** @internal */
var isTrie = (u) => hasProperty(u, TrieTypeId);
/** @internal */
var empty$5 = () => makeImpl(void 0);
/** @internal */
var fromIterable$5 = (entries) => {
	let trie = empty$5();
	for (const [key, value] of entries) trie = insert$1(trie, key, value);
	return trie;
};
/** @internal */
var make$10 = (...entries) => {
	return fromIterable$5(entries);
};
/** @internal */
var insert$1 = /*#__PURE__*/ dual(3, (self, key, value) => {
	if (key.length === 0) return self;
	const dStack = [];
	const nStack = [];
	let n = self._root ?? {
		key: key[0],
		count: 0
	};
	const count = n.count + 1;
	let cIndex = 0;
	while (cIndex < key.length) {
		const c = key[cIndex];
		nStack.push(n);
		if (c > n.key) {
			dStack.push(1);
			if (n.right === void 0) n = {
				key: c,
				count
			};
			else n = n.right;
		} else if (c < n.key) {
			dStack.push(-1);
			if (n.left === void 0) n = {
				key: c,
				count
			};
			else n = n.left;
		} else {
			if (cIndex === key.length - 1) n.value = value;
			else if (n.mid === void 0) {
				dStack.push(0);
				n = {
					key: key[cIndex + 1],
					count
				};
			} else {
				dStack.push(0);
				n = n.mid;
			}
			cIndex += 1;
		}
	}
	for (let s = nStack.length - 2; s >= 0; --s) {
		const n2 = nStack[s];
		const d = dStack[s];
		if (d === -1) nStack[s] = {
			key: n2.key,
			count,
			value: n2.value,
			left: nStack[s + 1],
			mid: n2.mid,
			right: n2.right
		};
		else if (d === 1) nStack[s] = {
			key: n2.key,
			count,
			value: n2.value,
			left: n2.left,
			mid: n2.mid,
			right: nStack[s + 1]
		};
		else nStack[s] = {
			key: n2.key,
			count,
			value: n2.value,
			left: n2.left,
			mid: nStack[s + 1],
			right: n2.right
		};
	}
	nStack[0].count = count;
	return makeImpl(nStack[0]);
});
/** @internal */
var size$7 = (self) => self._root?.count ?? 0;
/** @internal */
var isEmpty$7 = (self) => size$7(self) === 0;
/** @internal */
var keys$2 = (self) => new TrieIterator(self, (key) => key, () => true);
/** @internal */
var values$2 = (self) => new TrieIterator(self, (_, value) => value, () => true);
/** @internal */
var entries$2 = (self) => new TrieIterator(self, (key, value) => [key, value], () => true);
/** @internal */
var reduce$3 = /*#__PURE__*/ dual(3, (self, zero, f) => {
	let accumulator = zero;
	for (const entry of self) accumulator = f(accumulator, entry[1], entry[0]);
	return accumulator;
});
/** @internal */
var map$4 = /*#__PURE__*/ dual(2, (self, f) => reduce$3(self, empty$5(), (trie, value, key) => insert$1(trie, key, f(value, key))));
/** @internal */
var filter$4 = /*#__PURE__*/ dual(2, (self, f) => reduce$3(self, empty$5(), (trie, value, key) => f(value, key) ? insert$1(trie, key, value) : trie));
/** @internal */
var filterMap$2 = /*#__PURE__*/ dual(2, (self, f) => reduce$3(self, empty$5(), (trie, value, key) => {
	const result = f(value, key);
	return isSuccess(result) ? insert$1(trie, key, result.success) : trie;
}));
/** @internal */
var compact$2 = (self) => reduce$3(self, empty$5(), (trie, option, key) => isSome(option) ? insert$1(trie, key, option.value) : trie);
/** @internal */
var forEach$2 = /*#__PURE__*/ dual(2, (self, f) => reduce$3(self, void 0, (_, value, key) => f(value, key)));
/** @internal */
var keysWithPrefix$1 = /*#__PURE__*/ dual(2, (self, prefix) => new TrieIterator(self, (key) => key, (key) => key.startsWith(prefix)));
/** @internal */
var valuesWithPrefix$1 = /*#__PURE__*/ dual(2, (self, prefix) => new TrieIterator(self, (_, value) => value, (key) => key.startsWith(prefix)));
/** @internal */
var entriesWithPrefix$1 = /*#__PURE__*/ dual(2, (self, prefix) => new TrieIterator(self, (key, value) => [key, value], (key) => key.startsWith(prefix)));
/** @internal */
var toEntriesWithPrefix$1 = /*#__PURE__*/ dual(2, (self, prefix) => Array.from(entriesWithPrefix$1(self, prefix)));
/** @internal */
var get$5 = /*#__PURE__*/ dual(2, (self, key) => {
	let n = self._root;
	if (n === void 0 || key.length === 0) return none();
	let cIndex = 0;
	while (cIndex < key.length) {
		const c = key[cIndex];
		if (c > n.key) if (n.right === void 0) return none();
		else n = n.right;
		else if (c < n.key) if (n.left === void 0) return none();
		else n = n.left;
		else if (cIndex === key.length - 1) return fromUndefinedOr(n.value);
		else if (n.mid === void 0) return none();
		else {
			n = n.mid;
			cIndex += 1;
		}
	}
	return none();
});
/** @internal */
var has$3 = /*#__PURE__*/ dual(2, (self, key) => isSome(get$5(self, key)));
/** @internal */
var getUnsafe$1 = /*#__PURE__*/ dual(2, (self, key) => {
	const element = get$5(self, key);
	if (isNone(element)) throw new Error("Expected trie to contain key");
	return element.value;
});
/** @internal */
var remove$3 = /*#__PURE__*/ dual(2, (self, key) => {
	let n = self._root;
	if (n === void 0 || key.length === 0) return self;
	const count = n.count - 1;
	const dStack = [];
	const nStack = [];
	let cIndex = 0;
	while (cIndex < key.length) {
		const c = key[cIndex];
		if (c > n.key) if (n.right === void 0) return self;
		else {
			nStack.push(n);
			dStack.push(1);
			n = n.right;
		}
		else if (c < n.key) if (n.left === void 0) return self;
		else {
			nStack.push(n);
			dStack.push(-1);
			n = n.left;
		}
		else if (cIndex === key.length - 1) if (n.value !== void 0) {
			nStack.push(n);
			dStack.push(0);
			cIndex += 1;
		} else return self;
		else if (n.mid === void 0) return self;
		else {
			nStack.push(n);
			dStack.push(0);
			n = n.mid;
			cIndex += 1;
		}
	}
	const removeNode = nStack[nStack.length - 1];
	nStack[nStack.length - 1] = {
		key: removeNode.key,
		count,
		left: removeNode.left,
		mid: removeNode.mid,
		right: removeNode.right
	};
	for (let s = nStack.length - 2; s >= 0; --s) {
		const n2 = nStack[s];
		const d = dStack[s];
		const child = nStack[s + 1];
		const nc = child.left === void 0 && child.mid === void 0 && child.right === void 0 ? void 0 : child;
		if (d === -1) nStack[s] = {
			key: n2.key,
			count,
			value: n2.value,
			left: nc,
			mid: n2.mid,
			right: n2.right
		};
		else if (d === 1) nStack[s] = {
			key: n2.key,
			count,
			value: n2.value,
			left: n2.left,
			mid: n2.mid,
			right: nc
		};
		else nStack[s] = {
			key: n2.key,
			count,
			value: n2.value,
			left: n2.left,
			mid: nc,
			right: n2.right
		};
	}
	nStack[0].count = count;
	return makeImpl(nStack[0]);
});
/** @internal */
var removeMany$2 = /*#__PURE__*/ dual(2, (self, keys) => {
	let trie = self;
	for (const key of keys) trie = remove$3(key)(trie);
	return trie;
});
/** @internal */
var insertMany$1 = /*#__PURE__*/ dual(2, (self, iter) => {
	let trie = self;
	for (const [key, value] of iter) trie = insert$1(key, value)(trie);
	return trie;
});
/** @internal */
var modify$5 = /*#__PURE__*/ dual(3, (self, key, f) => {
	let n = self._root;
	if (n === void 0 || key.length === 0) return self;
	const dStack = [];
	const nStack = [];
	let cIndex = 0;
	while (cIndex < key.length) {
		const c = key[cIndex];
		if (c > n.key) if (n.right === void 0) return self;
		else {
			nStack.push(n);
			dStack.push(1);
			n = n.right;
		}
		else if (c < n.key) if (n.left === void 0) return self;
		else {
			nStack.push(n);
			dStack.push(-1);
			n = n.left;
		}
		else if (cIndex === key.length - 1) if (n.value !== void 0) {
			nStack.push(n);
			dStack.push(0);
			cIndex += 1;
		} else return self;
		else if (n.mid === void 0) return self;
		else {
			nStack.push(n);
			dStack.push(0);
			n = n.mid;
			cIndex += 1;
		}
	}
	const updateNode = nStack[nStack.length - 1];
	if (updateNode.value === void 0) return self;
	nStack[nStack.length - 1] = {
		key: updateNode.key,
		count: updateNode.count,
		value: f(updateNode.value),
		left: updateNode.left,
		mid: updateNode.mid,
		right: updateNode.right
	};
	for (let s = nStack.length - 2; s >= 0; --s) {
		const n2 = nStack[s];
		const d = dStack[s];
		const child = nStack[s + 1];
		if (d === -1) nStack[s] = {
			key: n2.key,
			count: n2.count,
			value: n2.value,
			left: child,
			mid: n2.mid,
			right: n2.right
		};
		else if (d === 1) nStack[s] = {
			key: n2.key,
			count: n2.count,
			value: n2.value,
			left: n2.left,
			mid: n2.mid,
			right: child
		};
		else nStack[s] = {
			key: n2.key,
			count: n2.count,
			value: n2.value,
			left: n2.left,
			mid: child,
			right: n2.right
		};
	}
	return makeImpl(nStack[0]);
});
/** @internal */
var longestPrefixOf$1 = /*#__PURE__*/ dual(2, (self, key) => {
	let n = self._root;
	if (n === void 0 || key.length === 0) return void 0;
	let longestPrefixNode = void 0;
	let cIndex = 0;
	while (cIndex < key.length) {
		const c = key[cIndex];
		if (n.value !== void 0) longestPrefixNode = [key.slice(0, cIndex + 1), n.value];
		if (c > n.key) if (n.right === void 0) break;
		else n = n.right;
		else if (c < n.key) if (n.left === void 0) break;
		else n = n.left;
		else if (n.mid === void 0) break;
		else {
			n = n.mid;
			cIndex += 1;
		}
	}
	return longestPrefixNode;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Trie.js
var Trie_exports = /* @__PURE__ */ __exportAll({
	compact: () => compact$1,
	empty: () => empty$4,
	entries: () => entries$1,
	entriesWithPrefix: () => entriesWithPrefix,
	filter: () => filter$3,
	filterMap: () => filterMap$1,
	forEach: () => forEach$1,
	fromIterable: () => fromIterable$4,
	get: () => get$4,
	getUnsafe: () => getUnsafe,
	has: () => has$2,
	insert: () => insert,
	insertMany: () => insertMany,
	isEmpty: () => isEmpty$6,
	keys: () => keys$1,
	keysWithPrefix: () => keysWithPrefix,
	longestPrefixOf: () => longestPrefixOf,
	make: () => make$9,
	map: () => map$3,
	modify: () => modify$4,
	reduce: () => reduce$2,
	remove: () => remove$2,
	removeMany: () => removeMany$1,
	size: () => size$6,
	toEntries: () => toEntries$1,
	toEntriesWithPrefix: () => toEntriesWithPrefix,
	values: () => values$1,
	valuesWithPrefix: () => valuesWithPrefix
});
/**
* Creates an empty `Trie`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<string>()
*
* assert.equal(Trie.size(trie), 0)
* assert.deepStrictEqual(Array.from(trie), [])
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty$4 = empty$5;
/**
* Creates a new `Trie` from an iterable collection of key/value pairs (e.g. `Array<[string, V]>`).
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const iterable: Array<readonly [string, number]> = [["call", 0], ["me", 1], [
*   "mind",
*   2
* ], ["mid", 3]]
* const trie = Trie.fromIterable(iterable)
*
* // The entries in the `Trie` are extracted in alphabetical order, regardless of the insertion order
* assert.deepStrictEqual(Array.from(trie), [["call", 0], ["me", 1], ["mid", 3], [
*   "mind",
*   2
* ]])
* assert.equal(
*   Equal.equals(
*     Trie.make(["call", 0], ["me", 1], ["mind", 2], ["mid", 3]),
*     trie
*   ),
*   true
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromIterable$4 = fromIterable$5;
/**
* Constructs a new `Trie` from the specified entries (`[string, V]`).
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.make(["ca", 0], ["me", 1])
*
* assert.deepStrictEqual(Array.from(trie), [["ca", 0], ["me", 1]])
* assert.equal(
*   Equal.equals(Trie.fromIterable([["ca", 0], ["me", 1]]), trie),
*   true
* )
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$9 = make$10;
/**
* Insert a new entry in the `Trie`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie1 = Trie.empty<number>().pipe(
*   Trie.insert("call", 0)
* )
* const trie2 = trie1.pipe(Trie.insert("me", 1))
* const trie3 = trie2.pipe(Trie.insert("mind", 2))
* const trie4 = trie3.pipe(Trie.insert("mid", 3))
*
* assert.deepStrictEqual(Array.from(trie1), [["call", 0]])
* assert.deepStrictEqual(Array.from(trie2), [["call", 0], ["me", 1]])
* assert.deepStrictEqual(Array.from(trie3), [["call", 0], ["me", 1], ["mind", 2]])
* assert.deepStrictEqual(Array.from(trie4), [["call", 0], ["me", 1], ["mid", 3], [
*   "mind",
*   2
* ]])
* ```
*
* @since 2.0.0
* @category mutations
*/
var insert = insert$1;
/**
* Returns an `IterableIterator` of the keys within the `Trie`.
*
* The keys are returned in alphabetical order, regardless of insertion order.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("cab", 0),
*   Trie.insert("abc", 1),
*   Trie.insert("bca", 2)
* )
*
* const result = Array.from(Trie.keys(trie))
* assert.deepStrictEqual(result, ["abc", "bca", "cab"])
* ```
*
* @since 2.0.0
* @category getters
*/
var keys$1 = keys$2;
/**
* Returns an `IterableIterator` of the values within the `Trie`.
*
* Values are ordered based on their key in alphabetical order, regardless of insertion order.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1),
*   Trie.insert("and", 2)
* )
*
* const result = Array.from(Trie.values(trie))
* assert.deepStrictEqual(result, [2, 0, 1])
* ```
*
* @since 2.0.0
* @category getters
*/
var values$1 = values$2;
/**
* Returns an `IterableIterator` of the entries within the `Trie`.
*
* The entries are returned by keys in alphabetical order, regardless of insertion order.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1)
* )
*
* const result = Array.from(Trie.entries(trie))
* assert.deepStrictEqual(result, [["call", 0], ["me", 1]])
* ```
*
* @since 2.0.0
* @category getters
*/
var entries$1 = entries$2;
/**
* Returns an `Array<[K, V]>` of the entries within the `Trie`.
*
* Equivalent to `Array.from(Trie.entries(trie))`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1)
* )
* const result = Trie.toEntries(trie)
*
* assert.deepStrictEqual(result, [["call", 0], ["me", 1]])
* ```
*
* @since 2.0.0
* @category getters
*/
var toEntries$1 = (self) => Array.from(entries$1(self));
/**
* Returns an `IterableIterator` of the keys within the `Trie`
* that have `prefix` as prefix (`prefix` included if it exists).
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("she", 0),
*   Trie.insert("shells", 1),
*   Trie.insert("sea", 2),
*   Trie.insert("shore", 3)
* )
*
* const result = Array.from(Trie.keysWithPrefix(trie, "she"))
* assert.deepStrictEqual(result, ["she", "shells"])
* ```
*
* @since 2.0.0
* @category getters
*/
var keysWithPrefix = keysWithPrefix$1;
/**
* Returns an `IterableIterator` of the values within the `Trie`
* that have `prefix` as prefix (`prefix` included if it exists).
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("she", 0),
*   Trie.insert("shells", 1),
*   Trie.insert("sea", 2),
*   Trie.insert("shore", 3)
* )
*
* const result = Array.from(Trie.valuesWithPrefix(trie, "she"))
*
* // 0: "she", 1: "shells"
* assert.deepStrictEqual(result, [0, 1])
* ```
*
* @since 2.0.0
* @category getters
*/
var valuesWithPrefix = valuesWithPrefix$1;
/**
* Returns an `IterableIterator` of the entries within the `Trie`
* that have `prefix` as prefix (`prefix` included if it exists).
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("she", 0),
*   Trie.insert("shells", 1),
*   Trie.insert("sea", 2),
*   Trie.insert("shore", 3)
* )
*
* const result = Array.from(Trie.entriesWithPrefix(trie, "she"))
* assert.deepStrictEqual(result, [["she", 0], ["shells", 1]])
* ```
*
* @since 2.0.0
* @category getters
*/
var entriesWithPrefix = entriesWithPrefix$1;
/**
* Returns `Array<[K, V]>` of the entries within the `Trie`
* that have `prefix` as prefix (`prefix` included if it exists).
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("sea", 2),
*   Trie.insert("she", 3)
* )
*
* const result = Trie.toEntriesWithPrefix(trie, "she")
* assert.deepStrictEqual(result, [["she", 3], ["shells", 0]])
* ```
*
* @since 2.0.0
* @category getters
*/
var toEntriesWithPrefix = toEntriesWithPrefix$1;
/**
* Returns the longest key/value in the `Trie`
* that is a prefix of that `key` if it exists, `None` otherwise.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* assert.deepStrictEqual(Trie.longestPrefixOf(trie, "sell"), undefined)
* assert.deepStrictEqual(Trie.longestPrefixOf(trie, "sells"), ["sells", 1])
* assert.deepStrictEqual(Trie.longestPrefixOf(trie, "shell"), ["she", 2])
* assert.deepStrictEqual(Trie.longestPrefixOf(trie, "shellsort"), ["shells", 0])
* ```
*
* @since 2.0.0
* @category getters
*/
var longestPrefixOf = longestPrefixOf$1;
/**
* Returns the size of the `Trie` (number of entries in the `Trie`).
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("a", 0),
*   Trie.insert("b", 1)
* )
*
* assert.equal(Trie.size(trie), 2)
* ```
*
* @since 2.0.0
* @category getters
*/
var size$6 = size$7;
/**
* Safely lookup the value for the specified key in the `Trie`.
*
* @example
* ```ts
* import * as Option from "effect/Option"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1),
*   Trie.insert("mind", 2),
*   Trie.insert("mid", 3)
* )
*
* assert.deepStrictEqual(Trie.get(trie, "call"), Option.some(0))
* assert.deepStrictEqual(Trie.get(trie, "me"), Option.some(1))
* assert.deepStrictEqual(Trie.get(trie, "mind"), Option.some(2))
* assert.deepStrictEqual(Trie.get(trie, "mid"), Option.some(3))
* assert.deepStrictEqual(Trie.get(trie, "cale"), Option.none())
* assert.deepStrictEqual(Trie.get(trie, "ma"), Option.none())
* assert.deepStrictEqual(Trie.get(trie, "midn"), Option.none())
* assert.deepStrictEqual(Trie.get(trie, "mea"), Option.none())
* ```
*
* @since 2.0.0
* @category elements
*/
var get$4 = get$5;
/**
* Check if the given key exists in the `Trie`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1),
*   Trie.insert("mind", 2),
*   Trie.insert("mid", 3)
* )
*
* assert.equal(Trie.has(trie, "call"), true)
* assert.equal(Trie.has(trie, "me"), true)
* assert.equal(Trie.has(trie, "mind"), true)
* assert.equal(Trie.has(trie, "mid"), true)
* assert.equal(Trie.has(trie, "cale"), false)
* assert.equal(Trie.has(trie, "ma"), false)
* assert.equal(Trie.has(trie, "midn"), false)
* assert.equal(Trie.has(trie, "mea"), false)
* ```
*
* @since 2.0.0
* @category elements
*/
var has$2 = has$3;
/**
* Checks if the `Trie` contains any entries.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>()
* const trie1 = trie.pipe(Trie.insert("ma", 0))
*
* assert.equal(Trie.isEmpty(trie), true)
* assert.equal(Trie.isEmpty(trie1), false)
* ```
*
* @since 2.0.0
* @category elements
*/
var isEmpty$6 = isEmpty$7;
/**
* Unsafely lookup the value for the specified key in the `Trie`.
*
* `getUnsafe` will throw if the key is not found. Use `get` instead to safely
* get a value from the `Trie`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1)
* )
*
* assert.throws(() => Trie.getUnsafe(trie, "mae"))
* ```
*
* @since 2.0.0
* @category unsafe
*/
var getUnsafe = getUnsafe$1;
/**
* Remove the entry for the specified key in the `Trie`.
*
* @example
* ```ts
* import * as Option from "effect/Option"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("call", 0),
*   Trie.insert("me", 1),
*   Trie.insert("mind", 2),
*   Trie.insert("mid", 3)
* )
*
* const trie1 = trie.pipe(Trie.remove("call"))
* const trie2 = trie1.pipe(Trie.remove("mea"))
*
* assert.deepStrictEqual(Trie.get(trie, "call"), Option.some(0))
* assert.deepStrictEqual(Trie.get(trie1, "call"), Option.none())
* assert.deepStrictEqual(Trie.get(trie2, "call"), Option.none())
* ```
*
* @since 2.0.0
* @category mutations
*/
var remove$2 = remove$3;
/**
* Reduce a state over the entries of the `Trie`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* assert.equal(
*   trie.pipe(
*     Trie.reduce(0, (acc, n) => acc + n)
*   ),
*   3
* )
* assert.equal(
*   trie.pipe(
*     Trie.reduce(10, (acc, n) => acc + n)
*   ),
*   13
* )
* assert.equal(
*   trie.pipe(
*     Trie.reduce("", (acc, _, key) => acc + key)
*   ),
*   "sellssheshells"
* )
* ```
*
* @since 2.0.0
* @category folding
*/
var reduce$2 = reduce$3;
/**
* Maps over the entries of the `Trie` using the specified function.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* const trieMapV = Trie.empty<number>().pipe(
*   Trie.insert("shells", 1),
*   Trie.insert("sells", 2),
*   Trie.insert("she", 3)
* )
*
* const trieMapK = Trie.empty<number>().pipe(
*   Trie.insert("shells", 6),
*   Trie.insert("sells", 5),
*   Trie.insert("she", 3)
* )
*
* assert.equal(Equal.equals(Trie.map(trie, (v) => v + 1), trieMapV), true)
* assert.equal(Equal.equals(Trie.map(trie, (_, k) => k.length), trieMapK), true)
* ```
*
* @since 2.0.0
* @category folding
*/
var map$3 = map$4;
/**
* Filters entries out of a `Trie` using the specified predicate.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* const trieMapV = Trie.empty<number>().pipe(
*   Trie.insert("she", 2)
* )
*
* const trieMapK = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1)
* )
*
* assert.equal(Equal.equals(Trie.filter(trie, (v) => v > 1), trieMapV), true)
* assert.equal(
*   Equal.equals(Trie.filter(trie, (_, k) => k.length > 3), trieMapK),
*   true
* )
* ```
*
* @since 2.0.0
* @category filtering
*/
var filter$3 = filter$4;
/**
* Maps over the entries of the `Trie` using the specified filter and keeps
* only successful results.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Result from "effect/Result"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* const trieMapV = Trie.empty<number>().pipe(
*   Trie.insert("she", 2)
* )
*
* const trieMapK = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1)
* )
*
* assert.equal(
*   Equal.equals(
*     Trie.filterMap(trie, (v) => v > 1 ? Result.succeed(v) : Result.failVoid),
*     trieMapV
*   ),
*   true
* )
* assert.equal(
*   Equal.equals(
*     Trie.filterMap(
*       trie,
*       (v, k) => k.length > 3 ? Result.succeed(v) : Result.failVoid
*     ),
*     trieMapK
*   ),
*   true
* )
* ```
*
* @since 2.0.0
* @category filtering
*/
var filterMap$1 = filterMap$2;
/**
* Filters out `None` values from a `Trie` of `Options`s.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Option from "effect/Option"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<Option.Option<number>>().pipe(
*   Trie.insert("shells", Option.some(0)),
*   Trie.insert("sells", Option.none()),
*   Trie.insert("she", Option.some(2))
* )
*
* const trieMapV = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("she", 2)
* )
*
* assert.equal(Equal.equals(Trie.compact(trie), trieMapV), true)
* ```
*
* @since 2.0.0
* @category filtering
*/
var compact$1 = compact$2;
/**
* Applies the specified function to the entries of the `Trie`.
*
* @example
* ```ts
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* let value = 0
*
* Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2),
*   Trie.forEach((n, key) => {
*     value += n + key.length
*   })
* )
*
* assert.equal(value, 17)
* ```
*
* @since 2.0.0
* @category traversing
*/
var forEach$1 = forEach$2;
/**
* Updates the value of the specified key within the `Trie` if it exists.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Option from "effect/Option"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* assert.deepStrictEqual(
*   trie.pipe(Trie.modify("she", (v) => v + 10), Trie.get("she")),
*   Option.some(12)
* )
*
* assert.equal(Equal.equals(trie.pipe(Trie.modify("me", (v) => v)), trie), true)
* ```
*
* @since 2.0.0
* @category mutations
*/
var modify$4 = modify$5;
/**
* Removes all entries in the `Trie` which have the specified keys.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* assert.equal(
*   Equal.equals(
*     trie.pipe(Trie.removeMany(["she", "sells"])),
*     Trie.empty<number>().pipe(Trie.insert("shells", 0))
*   ),
*   true
* )
* ```
*
* @since 2.0.0
* @category mutations
*/
var removeMany$1 = removeMany$2;
/**
* Insert multiple entries in the `Trie` at once.
*
* @example
* ```ts
* import * as Equal from "effect/Equal"
* import * as Trie from "effect/Trie"
* import * as assert from "node:assert"
*
* const trie = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insert("sells", 1),
*   Trie.insert("she", 2)
* )
*
* const trieInsert = Trie.empty<number>().pipe(
*   Trie.insert("shells", 0),
*   Trie.insertMany(
*     [["sells", 1], ["she", 2]]
*   )
* )
*
* assert.equal(
*   Equal.equals(trie, trieInsert),
*   true
* )
* ```
*
* @since 2.0.0
* @category mutations
*/
var insertMany = insertMany$1;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxRef.js
/**
* TxRef is a transactional value, it can be read and modified within the body of a transaction.
*
* Accessed values are tracked by the transaction in order to detect conflicts and in order to
* track changes, a transaction will retry whenever a conflict is detected or whenever the
* transaction explicitely calls to `Effect.retryTransaction` and any of the accessed TxRef values
* change.
*
* @since 4.0.0
*/
var TxRef_exports = /* @__PURE__ */ __exportAll({
	get: () => get$3,
	make: () => make$8,
	makeUnsafe: () => makeUnsafe$1,
	modify: () => modify$3,
	set: () => set$3,
	update: () => update$2
});
var TypeId$10 = "~effect/transactions/TxRef";
/**
* Creates a new `TxRef` with the specified initial value.
*
* @since 4.0.0
* @category Constructors
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a transactional reference with initial value
*   const counter = yield* Effect.transaction(TxRef.make(0))
*   const name = yield* Effect.transaction(TxRef.make("Alice"))
*
*   // Use in transactions
*   yield* Effect.transaction(Effect.gen(function*() {
*     yield* TxRef.set(counter, 42)
*     yield* TxRef.set(name, "Bob")
*   }))
*
*   console.log(yield* Effect.transaction(TxRef.get(counter))) // 42
*   console.log(yield* Effect.transaction(TxRef.get(name))) // "Bob"
* })
* ```
*/
var make$8 = (initial) => withTxState((state) => sync$1(() => {
	const ref = makeUnsafe$1(initial);
	state.journal.set(ref, {
		version: ref.version,
		value: ref.value
	});
	return ref;
}));
/**
* Creates a new `TxRef` with the specified initial value.
*
* @since 4.0.0
* @category Constructors
* @example
* ```ts
* import { TxRef } from "effect"
*
* // Create a TxRef synchronously (unsafe - use make instead in Effect contexts)
* const counter = TxRef.makeUnsafe(0)
* const config = TxRef.makeUnsafe({ timeout: 5000, retries: 3 })
*
* // These are now ready to use in transactions
* console.log(counter.value) // 0
* console.log(config.value) // { timeout: 5000, retries: 3 }
* ```
*/
var makeUnsafe$1 = (initial) => ({
	[TypeId$10]: TypeId$10,
	pending: /* @__PURE__ */ new Map(),
	pipe() {
		return pipeArguments(this, arguments);
	},
	version: 0,
	value: initial
});
/**
* Modifies the value of the `TxRef` using the provided function.
*
* @since 4.0.0
* @category Combinators
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* TxRef.make(0)
*
*   // Modify and return both old and new value
*   const result = yield* Effect.transaction(
*     TxRef.modify(counter, (current) => [current * 2, current + 1])
*   )
*
*   console.log(result) // 0 (the return value: current * 2)
*   console.log(yield* Effect.transaction(TxRef.get(counter))) // 1 (the new value: current + 1)
* })
* ```
*/
var modify$3 = /*#__PURE__*/ dual(2, (self, f) => withTxState((state) => sync$1(() => {
	if (!state.journal.has(self)) state.journal.set(self, {
		version: self.version,
		value: self.value
	});
	const current = state.journal.get(self);
	const [returnValue, next] = f(current.value);
	current.value = next;
	return returnValue;
})));
/**
* Updates the value of the `TxRef` using the provided function.
*
* @since 4.0.0
* @category Combinators
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* TxRef.make(10)
*
*   // Update the value using a function
*   yield* Effect.transaction(
*     TxRef.update(counter, (current) => current * 2)
*   )
*
*   console.log(yield* Effect.transaction(TxRef.get(counter))) // 20
* })
* ```
*/
var update$2 = /*#__PURE__*/ dual(2, (self, f) => modify$3(self, (current) => [void 0, f(current)]));
/**
* Reads the current value of the `TxRef`.
*
* @since 4.0.0
* @category Combinators
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* TxRef.make(42)
*
*   // Read the value within a transaction
*   const value = yield* Effect.transaction(
*     TxRef.get(counter)
*   )
*
*   console.log(value) // 42
* })
* ```
*/
var get$3 = (self) => modify$3(self, (current) => [current, current]);
/**
* Sets the value of the `TxRef`.
*
* @since 4.0.0
* @category Combinators
* @example
* ```ts
* import { Effect, TxRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const counter = yield* TxRef.make(0)
*
*   // Set a new value within a transaction
*   yield* Effect.transaction(
*     TxRef.set(counter, 100)
*   )
*
*   console.log(yield* Effect.transaction(TxRef.get(counter))) // 100
* })
* ```
*/
var set$3 = /*#__PURE__*/ dual(2, (self, value) => update$2(self, () => value));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxChunk.js
/**
* TxChunk is a transactional chunk data structure that provides Software Transactional Memory (STM)
* semantics for chunk operations. It uses a `TxRef<Chunk<A>>` internally to ensure all operations
* are performed atomically within transactions.
*
* Accessed values are tracked by the transaction in order to detect conflicts and to track changes.
* A transaction will retry whenever a conflict is detected or whenever the transaction explicitly
* calls `Effect.retryTransaction` and any of the accessed TxChunk values change.
*
* @since 4.0.0
*/
var TxChunk_exports = /* @__PURE__ */ __exportAll({
	append: () => append,
	appendAll: () => appendAll,
	concat: () => concat,
	drop: () => drop,
	empty: () => empty$3,
	filter: () => filter$2,
	fromIterable: () => fromIterable$3,
	get: () => get$2,
	isEmpty: () => isEmpty$5,
	isNonEmpty: () => isNonEmpty$2,
	make: () => make$7,
	makeUnsafe: () => makeUnsafe,
	map: () => map$2,
	modify: () => modify$2,
	prepend: () => prepend,
	prependAll: () => prependAll,
	set: () => set$2,
	size: () => size$5,
	slice: () => slice,
	take: () => take$2,
	update: () => update$1
});
var TypeId$9 = "~effect/transactions/TxChunk";
var TxChunkProto = {
	[NodeInspectSymbol]() {
		return this.toJSON();
	},
	toString() {
		return `TxChunk(${format$1(toJson(this.ref))})`;
	},
	toJSON() {
		return {
			_id: "TxChunk",
			ref: toJson(this.ref)
		};
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Creates a new `TxChunk` with the specified initial chunk.
*
* **Return behavior**: This function returns a new TxChunk reference containing
* the provided initial chunk. No existing TxChunk instances are modified.
*
* @since 4.0.0
* @category Constructors
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a TxChunk with initial values
*   const initialChunk = Chunk.fromIterable([1, 2, 3])
*   const txChunk = yield* TxChunk.make(initialChunk)
*
*   // Read the value - automatically transactional
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3]
* })
* ```
*/
var make$7 = (initial) => map$11(make$8(initial), (ref) => makeUnsafe(ref));
/**
* Creates a new empty `TxChunk`.
*
* **Return behavior**: This function returns a new TxChunk reference that is
* initially empty. No existing TxChunk instances are modified.
*
* @since 4.0.0
* @category Constructors
* @example
* ```ts
* import { Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create an empty TxChunk
*   const txChunk = yield* TxChunk.empty<number>()
*
*   // Check if it's empty - automatically transactional
*   const isEmpty = yield* TxChunk.isEmpty(txChunk)
*   console.log(isEmpty) // true
*
*   // Add elements - automatically transactional
*   yield* TxChunk.append(txChunk, 42)
*
*   const isStillEmpty = yield* TxChunk.isEmpty(txChunk)
*   console.log(isStillEmpty) // false
* })
* ```
*/
var empty$3 = () => map$11(make$8(empty$9()), (ref) => makeUnsafe(ref));
/**
* Creates a new `TxChunk` from an iterable.
*
* **Return behavior**: This function returns a new TxChunk reference containing
* elements from the provided iterable. No existing TxChunk instances are modified.
*
* @since 4.0.0
* @category Constructors
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create TxChunk from array
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4, 5])
*
*   // Read the contents - automatically transactional
*   const chunk = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(chunk)) // [1, 2, 3, 4, 5]
*
*   // Multi-step atomic modification - use explicit transaction
*   yield* Effect.transaction(
*     Effect.gen(function*() {
*       yield* TxChunk.append(txChunk, 6)
*       yield* TxChunk.prepend(txChunk, 0)
*     })
*   )
*
*   const updated = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(updated)) // [0, 1, 2, 3, 4, 5, 6]
* })
* ```
*/
var fromIterable$3 = (iterable) => map$11(make$8(fromIterable$7(iterable)), (ref) => makeUnsafe(ref));
/**
* Creates a new `TxChunk` with the specified TxRef.
*
* **Return behavior**: This function returns a new TxChunk reference wrapping
* the provided TxRef. No existing TxChunk instances are modified.
*
* @example
* ```ts
* import { Chunk, TxChunk, TxRef } from "effect"
*
* // Create a TxChunk from an existing TxRef (advanced usage)
* const ref = TxRef.makeUnsafe(Chunk.fromIterable([1, 2, 3]))
* const txChunk = TxChunk.makeUnsafe(ref)
* ```
*
* @since 4.0.0
* @category constructors
*/
var makeUnsafe = (ref) => {
	const txChunk = Object.create(TxChunkProto);
	txChunk[TypeId$9] = TypeId$9;
	txChunk.ref = ref;
	return txChunk;
};
/**
* Modifies the value of the `TxChunk` using the provided function.
*
* **Mutation behavior**: This function mutates the original TxChunk by updating
* its internal state. It does not return a new TxChunk reference.
*
* @since 4.0.0
* @category Combinators
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Modify and return both old size and new chunk
*   const oldSize = yield* TxChunk.modify(txChunk, (chunk) => [
*     Chunk.size(chunk), // return value (old size)
*     Chunk.append(chunk, 4) // new value
*   ])
*
*   console.log(oldSize) // 3
*
*   const newChunk = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(newChunk)) // [1, 2, 3, 4]
* })
* ```
*/
var modify$2 = /*#__PURE__*/ dual(2, (self, f) => modify$3(self.ref, f));
/**
* Updates the value of the `TxChunk` using the provided function.
*
* **Mutation behavior**: This function mutates the original TxChunk by updating
* its internal state. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Update the chunk by reversing it
*   // Update the chunk by reversing it - automatically transactional
*   yield* TxChunk.update(txChunk, (chunk) => Chunk.reverse(chunk))
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [3, 2, 1]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var update$1 = /*#__PURE__*/ dual(2, (self, f) => update$2(self.ref, f));
/**
* Reads the current chunk from the `TxChunk`.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Read the current value within a transaction
*   const chunk = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(chunk)) // [1, 2, 3]
*
*   // The value is tracked for conflict detection
*   const size = Chunk.size(chunk)
*   console.log(size) // 3
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var get$2 = (self) => get$3(self.ref);
/**
* Sets the value of the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by replacing
* its internal state with the provided chunk. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Replace the entire chunk content
*   const newChunk = Chunk.fromIterable([10, 20, 30, 40])
*   yield* TxChunk.set(txChunk, newChunk)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [10, 20, 30, 40]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var set$2 = /*#__PURE__*/ dual(2, (self, chunk) => set$3(self.ref, chunk));
/**
* Appends an element to the end of the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by adding
* the element to the end. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Add element to the end atomically
*   yield* TxChunk.append(txChunk, 4)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3, 4]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var append = /*#__PURE__*/ dual(2, (self, element) => update$1(self, (current) => append$1(current, element)));
/**
* Prepends an element to the beginning of the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by adding
* the element to the beginning. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([2, 3, 4])
*
*   // Add element to the beginning atomically
*   yield* TxChunk.prepend(txChunk, 1)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3, 4]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var prepend = /*#__PURE__*/ dual(2, (self, element) => update$1(self, (current) => prepend$1(current, element)));
/**
* Gets the size of the `TxChunk`.
*
* @example
* ```ts
* import { Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4, 5])
*
*   // Get the current size - automatically transactional
*   const currentSize = yield* TxChunk.size(txChunk)
*   console.log(currentSize) // 5
*
*   // Size is tracked for conflict detection
*   yield* TxChunk.append(txChunk, 6)
*   const newSize = yield* TxChunk.size(txChunk)
*   console.log(newSize) // 6
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var size$5 = (self) => modify$2(self, (current) => [size$12(current), current]);
/**
* Checks if the `TxChunk` is empty.
*
* @example
* ```ts
* import { Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const emptyChunk = yield* TxChunk.empty<number>()
*   const nonEmptyChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Check if chunks are empty - automatically transactional
*   const isEmpty1 = yield* TxChunk.isEmpty(emptyChunk)
*   const isEmpty2 = yield* TxChunk.isEmpty(nonEmptyChunk)
*
*   console.log(isEmpty1) // true
*   console.log(isEmpty2) // false
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isEmpty$5 = (self) => modify$2(self, (current) => [isEmpty$8(current), current]);
/**
* Checks if the `TxChunk` is non-empty.
*
* @example
* ```ts
* import { Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const emptyChunk = yield* TxChunk.empty<number>()
*   const nonEmptyChunk = yield* TxChunk.fromIterable([1, 2, 3])
*
*   // Check if chunks are non-empty - automatically transactional
*   const isNonEmpty1 = yield* TxChunk.isNonEmpty(emptyChunk)
*   const isNonEmpty2 = yield* TxChunk.isNonEmpty(nonEmptyChunk)
*
*   console.log(isNonEmpty1) // false
*   console.log(isNonEmpty2) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isNonEmpty$2 = (self) => modify$2(self, (current) => [isNonEmpty$3(current), current]);
/**
* Takes the first `n` elements from the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by keeping
* only the first n elements. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4, 5])
*
*   // Take only the first 3 elements - automatically transactional
*   yield* TxChunk.take(txChunk, 3)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var take$2 = /*#__PURE__*/ dual(2, (self, n) => update$1(self, (current) => take$3(current, n)));
/**
* Drops the first `n` elements from the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by removing
* the first n elements. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4, 5])
*
*   // Drop the first 2 elements - automatically transactional
*   yield* TxChunk.drop(txChunk, 2)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [3, 4, 5]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var drop = /*#__PURE__*/ dual(2, (self, n) => update$1(self, (current) => drop$1(current, n)));
/**
* Takes a slice of the `TxChunk` from `start` to `end` (exclusive).
*
* **Mutation behavior**: This function mutates the original TxChunk by keeping
* only the elements in the specified range. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4, 5, 6, 7])
*
*   // Take elements from index 2 to 5 (exclusive) - automatically transactional
*   yield* TxChunk.slice(txChunk, 2, 5)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [3, 4, 5]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var slice = /*#__PURE__*/ dual(3, (self, start, end) => update$1(self, (current) => take$3(drop$1(current, start), end - start)));
/**
* Maps each element of the `TxChunk` using the provided function.
* Note: This only works when the mapped type B is assignable to A.
*
* **Mutation behavior**: This function mutates the original TxChunk by transforming
* each element in place. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4])
*
*   // Transform each element (must maintain same type)
*   // Transform each element (must maintain same type) - automatically transactional
*   yield* TxChunk.map(txChunk, (n) => n * 2)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [2, 4, 6, 8]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var map$2 = /*#__PURE__*/ dual(2, (self, f) => update$1(self, (current) => map$13(current, f)));
/**
* Filters the `TxChunk` keeping only elements that satisfy the predicate.
*
* **Mutation behavior**: This function mutates the original TxChunk by removing
* elements that don't match the predicate. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3, 4, 5, 6])
*
*   // Keep only even numbers
*   // Keep only even numbers - automatically transactional
*   yield* TxChunk.filter(txChunk, (n) => n % 2 === 0)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [2, 4, 6]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var filter$2 = /*#__PURE__*/ dual(2, (self, predicate) => update$1(self, (current) => filter$6(current, predicate)));
/**
* Concatenates another chunk to the end of the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by appending
* all elements from the other chunk. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([1, 2, 3])
*   const otherChunk = Chunk.fromIterable([4, 5, 6])
*
*   // Append all elements from another chunk
*   // Append all elements from another chunk - automatically transactional
*   yield* TxChunk.appendAll(txChunk, otherChunk)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3, 4, 5, 6]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var appendAll = /*#__PURE__*/ dual(2, (self, other) => update$1(self, (current) => appendAll$1(current, other)));
/**
* Concatenates another chunk to the beginning of the `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by prepending
* all elements from the other chunk. It does not return a new TxChunk reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk = yield* TxChunk.fromIterable([4, 5, 6])
*   const otherChunk = Chunk.fromIterable([1, 2, 3])
*
*   // Prepend all elements from another chunk
*   // Prepend all elements from another chunk - automatically transactional
*   yield* TxChunk.prependAll(txChunk, otherChunk)
*
*   const result = yield* TxChunk.get(txChunk)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3, 4, 5, 6]
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var prependAll = /*#__PURE__*/ dual(2, (self, other) => update$1(self, (current) => prependAll$1(current, other)));
/**
* Concatenates another `TxChunk` to the end of this `TxChunk`.
*
* **Mutation behavior**: This function mutates the original TxChunk by appending
* all elements from the other TxChunk. It does not return a new TxChunk reference.
*
* @since 4.0.0
* @category Combinators
* @example
* ```ts
* import { Chunk, Effect, TxChunk } from "effect"
*
* const program = Effect.gen(function*() {
*   const txChunk1 = yield* TxChunk.fromIterable([1, 2, 3])
*   const txChunk2 = yield* TxChunk.fromIterable([4, 5, 6])
*
*   // Concatenate atomically within a transaction
*   yield* TxChunk.concat(txChunk1, txChunk2)
*
*   const result = yield* TxChunk.get(txChunk1)
*   console.log(Chunk.toReadonlyArray(result)) // [1, 2, 3, 4, 5, 6]
*
*   // Original txChunk2 is unchanged
*   const original = yield* TxChunk.get(txChunk2)
*   console.log(Chunk.toReadonlyArray(original)) // [4, 5, 6]
* })
* ```
*/
var concat = /*#__PURE__*/ dual(2, (self, other) => gen(function* () {
	yield* appendAll(self, yield* get$2(other));
}));
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxDeferred.js
/**
* A transactional deferred value — a write-once cell that can be read within transactions.
* Readers retry until a value is set; once set, the value is immutable.
*
* @since 4.0.0
*/
var TxDeferred_exports = /* @__PURE__ */ __exportAll({
	await: () => await_,
	done: () => done,
	fail: () => fail$1,
	isTxDeferred: () => isTxDeferred,
	make: () => make$6,
	poll: () => poll$1,
	succeed: () => succeed
});
var TypeId$8 = "~effect/transactions/TxDeferred";
var TxDeferredProto = {
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toJSON() {
		return { _id: "TxDeferred" };
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeTxDeferred = (ref) => {
	const self = Object.create(TxDeferredProto);
	self[TypeId$8] = TypeId$8;
	self.ref = ref;
	return self;
};
/**
* Creates a new empty `TxDeferred`.
*
* @example
* ```ts
* import { Effect, Option, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<string, Error>()
*   const state = yield* TxDeferred.poll(deferred)
*   console.log(Option.isNone(state)) // true
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var make$6 = () => map$11(make$8(none()), makeTxDeferred);
/**
* Reads the deferred value. Retries the transaction if the deferred has not
* been completed yet.
*
* @example
* ```ts
* import { Effect, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<number>()
*   yield* TxDeferred.succeed(deferred, 42)
*   const value = yield* TxDeferred.await(deferred)
*   console.log(value) // 42
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var await_ = (self) => gen(function* () {
	const option = yield* get$3(self.ref);
	if (isNone(option)) return yield* retryTransaction;
	return isSuccess(option.value) ? option.value.success : yield* fail$4(option.value.failure);
});
/**
* Reads the current state of the deferred without retrying. Returns `None` if
* not yet completed.
*
* @example
* ```ts
* import { Effect, Option, Result, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<number>()
*   const before = yield* TxDeferred.poll(deferred)
*   console.log(Option.isNone(before)) // true
*
*   yield* TxDeferred.succeed(deferred, 42)
*   const after = yield* TxDeferred.poll(deferred)
*   console.log(after) // Some(Success(42))
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var poll$1 = (self) => get$3(self.ref);
/**
* Completes the deferred with a `Result`. Returns `true` if this was the first
* completion, `false` if already completed.
*
* @example
* ```ts
* import { Effect, Result, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<number, string>()
*   const first = yield* TxDeferred.done(deferred, Result.succeed(42))
*   console.log(first) // true
*   const second = yield* TxDeferred.done(deferred, Result.succeed(99))
*   console.log(second) // false
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var done = /*#__PURE__*/ dual(2, (self, result) => modify$3(self.ref, (current) => {
	if (isSome(current)) return [false, current];
	return [true, some$2(result)];
}));
/**
* Completes the deferred with a success value. Returns `true` if this was the
* first completion, `false` if already completed.
*
* @example
* ```ts
* import { Effect, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<number>()
*   const first = yield* TxDeferred.succeed(deferred, 42)
*   console.log(first) // true
*   const second = yield* TxDeferred.succeed(deferred, 99)
*   console.log(second) // false
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var succeed = /*#__PURE__*/ dual(2, (self, value) => done(self, succeed$2(value)));
/**
* Completes the deferred with a failure. Returns `true` if this was the first
* completion, `false` if already completed.
*
* @example
* ```ts
* import { Effect, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<number, string>()
*   const first = yield* TxDeferred.fail(deferred, "boom")
*   console.log(first) // true
*   const second = yield* TxDeferred.fail(deferred, "boom2")
*   console.log(second) // false
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var fail$1 = /*#__PURE__*/ dual(2, (self, error) => done(self, fail$3(error)));
/**
* Determines if the provided value is a `TxDeferred`.
*
* @example
* ```ts
* import { Effect, TxDeferred } from "effect"
*
* const program = Effect.gen(function*() {
*   const deferred = yield* TxDeferred.make<number>()
*   console.log(TxDeferred.isTxDeferred(deferred)) // true
*   console.log(TxDeferred.isTxDeferred("not a deferred")) // false
* })
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxDeferred = (u) => typeof u === "object" && u !== null && TypeId$8 in u;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxHashMap.js
/**
* @since 2.0.0
*/
var TxHashMap_exports = /* @__PURE__ */ __exportAll({
	clear: () => clear$2,
	compact: () => compact,
	empty: () => empty$2,
	entries: () => entries,
	every: () => every$1,
	filter: () => filter$1,
	filterMap: () => filterMap,
	findFirst: () => findFirst,
	flatMap: () => flatMap,
	forEach: () => forEach,
	fromIterable: () => fromIterable$2,
	get: () => get$1,
	getHash: () => getHash,
	has: () => has$1,
	hasBy: () => hasBy,
	hasHash: () => hasHash,
	isEmpty: () => isEmpty$4,
	isNonEmpty: () => isNonEmpty$1,
	isTxHashMap: () => isTxHashMap,
	keys: () => keys,
	make: () => make$5,
	map: () => map$1,
	modify: () => modify$1,
	modifyAt: () => modifyAt,
	reduce: () => reduce$1,
	remove: () => remove$1,
	removeMany: () => removeMany,
	set: () => set$1,
	setMany: () => setMany,
	size: () => size$4,
	snapshot: () => snapshot,
	some: () => some$1,
	toEntries: () => toEntries,
	toValues: () => toValues,
	union: () => union$1,
	values: () => values
});
var TypeId$7 = "~effect/transactions/TxHashMap";
var TxHashMapProto = {
	[TypeId$7]: TypeId$7,
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toString() {
		return `TxHashMap(${format$1(toJson(this.ref))})`;
	},
	toJSON() {
		return {
			_id: "TxHashMap",
			ref: toJson(this.ref)
		};
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Creates an empty TxHashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create an empty transactional hash map
*   const emptyMap = yield* TxHashMap.empty<string, number>()
*
*   // Verify it's empty
*   const isEmpty = yield* TxHashMap.isEmpty(emptyMap)
*   console.log(isEmpty) // true
*
*   const size = yield* TxHashMap.size(emptyMap)
*   console.log(size) // 0
*
*   // Start adding elements
*   yield* TxHashMap.set(emptyMap, "first", 1)
*   const newSize = yield* TxHashMap.size(emptyMap)
*   console.log(newSize) // 1
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty$2 = () => gen(function* () {
	const ref = yield* make$8(empty$10());
	return Object.assign(Object.create(TxHashMapProto), { ref });
});
/**
* Creates a TxHashMap from the provided key-value pairs.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a user directory
*   const userMap = yield* TxHashMap.make(
*     ["alice", { name: "Alice Smith", role: "admin" }],
*     ["bob", { name: "Bob Johnson", role: "user" }],
*     ["charlie", { name: "Charlie Brown", role: "user" }]
*   )
*
*   // Check the initial size
*   const size = yield* TxHashMap.size(userMap)
*   console.log(size) // 3
*
*   // Access users
*   const alice = yield* TxHashMap.get(userMap, "alice")
*   console.log(alice) // Option.some({ name: "Alice Smith", role: "admin" })
*
*   const nonExistent = yield* TxHashMap.get(userMap, "david")
*   console.log(nonExistent) // Option.none()
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$5 = (...entries) => gen(function* () {
	const ref = yield* make$8(make$30(...entries));
	return Object.assign(Object.create(TxHashMapProto), { ref });
});
/**
* Creates a TxHashMap from an iterable of key-value pairs.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create from various iterable sources
*   const configEntries = [
*     ["database.host", "localhost"],
*     ["database.port", "5432"],
*     ["cache.enabled", "true"],
*     ["logging.level", "info"]
*   ] as const
*
*   const configMap = yield* TxHashMap.fromIterable(configEntries)
*
*   // Verify the configuration was loaded
*   const size = yield* TxHashMap.size(configMap)
*   console.log(size) // 4
*
*   const dbHost = yield* TxHashMap.get(configMap, "database.host")
*   console.log(dbHost) // Option.some("localhost")
*
*   // Can also create from Map, Set of tuples, etc.
*   const jsMap = new Map([["key1", "value1"], ["key2", "value2"]])
*   const txMapFromJs = yield* TxHashMap.fromIterable(jsMap)
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromIterable$2 = (entries) => gen(function* () {
	const ref = yield* make$8(fromIterable$8(entries));
	return Object.assign(Object.create(TxHashMapProto), { ref });
});
/**
* Safely lookup the value for the specified key in the TxHashMap.
*
* @example
* ```ts
* import { Effect, Option, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const userMap = yield* TxHashMap.make(
*     ["alice", { name: "Alice", role: "admin" }],
*     ["bob", { name: "Bob", role: "user" }]
*   )
*
*   // Safe lookup - returns Option
*   const alice = yield* TxHashMap.get(userMap, "alice")
*   console.log(alice) // Option.some({ name: "Alice", role: "admin" })
*
*   const nonExistent = yield* TxHashMap.get(userMap, "charlie")
*   console.log(nonExistent) // Option.none()
*
*   // Use with pipe syntax for type-safe access
*   const bobRole = yield* TxHashMap.get(userMap, "bob")
*   if (Option.isSome(bobRole)) {
*     console.log(bobRole.value.role) // "user"
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var get$1 = /*#__PURE__*/ dual(2, (self, key) => gen(function* () {
	return get$17(yield* get$3(self.ref), key);
}));
/**
* Sets the value for the specified key in the TxHashMap.
*
* **Mutation behavior**: This function mutates the original TxHashMap by updating
* its internal state. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const inventory = yield* TxHashMap.make(
*     ["laptop", 5],
*     ["mouse", 20]
*   )
*
*   // Update existing item
*   yield* TxHashMap.set(inventory, "laptop", 3)
*   const laptopStock = yield* TxHashMap.get(inventory, "laptop")
*   console.log(laptopStock) // Option.some(3)
*
*   // Add new item
*   yield* TxHashMap.set(inventory, "keyboard", 15)
*   const keyboardStock = yield* TxHashMap.get(inventory, "keyboard")
*   console.log(keyboardStock) // Option.some(15)
*
*   // Use with pipe syntax
*   yield* TxHashMap.set("tablet", 8)(inventory)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var set$1 = /*#__PURE__*/ dual(3, (self, key, value) => update$2(self.ref, (map) => set$12(map, key, value)));
/**
* Checks if the specified key exists in the TxHashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const permissions = yield* TxHashMap.make(
*     ["alice", ["read", "write"]],
*     ["bob", ["read"]],
*     ["charlie", ["admin"]]
*   )
*
*   // Check if users exist
*   const hasAlice = yield* TxHashMap.has(permissions, "alice")
*   console.log(hasAlice) // true
*
*   const hasDavid = yield* TxHashMap.has(permissions, "david")
*   console.log(hasDavid) // false
*
*   // Use direct method call for type-safe access
*   const hasBob = yield* TxHashMap.has(permissions, "bob")
*   console.log(hasBob) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var has$1 = /*#__PURE__*/ dual(2, (self, key) => gen(function* () {
	return has$10(yield* get$3(self.ref), key);
}));
/**
* Removes the specified key from the TxHashMap.
*
* **Mutation behavior**: This function mutates the original TxHashMap by removing
* the specified key-value pair. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const cache = yield* TxHashMap.make(
*     ["user:1", { name: "Alice", lastSeen: "2024-01-01" }],
*     ["user:2", { name: "Bob", lastSeen: "2024-01-02" }],
*     ["user:3", { name: "Charlie", lastSeen: "2023-12-30" }]
*   )
*
*   // Remove expired user
*   const removed = yield* TxHashMap.remove(cache, "user:3")
*   console.log(removed) // true (key existed and was removed)
*
*   // Try to remove non-existent key
*   const notRemoved = yield* TxHashMap.remove(cache, "user:999")
*   console.log(notRemoved) // false (key didn't exist)
*
*   // Verify removal
*   const hasUser3 = yield* TxHashMap.has(cache, "user:3")
*   console.log(hasUser3) // false
*
*   const size = yield* TxHashMap.size(cache)
*   console.log(size) // 2
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var remove$1 = /*#__PURE__*/ dual(2, (self, key) => gen(function* () {
	const currentMap = yield* get$3(self.ref);
	const existed = has$10(currentMap, key);
	if (existed) yield* set$3(self.ref, remove$7(currentMap, key));
	return existed;
}));
/**
* Removes all entries from the TxHashMap.
*
* **Mutation behavior**: This function mutates the original TxHashMap by clearing
* all key-value pairs. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const sessionMap = yield* TxHashMap.make(
*     ["session1", { userId: "alice", expires: "2024-01-01T12:00:00Z" }],
*     ["session2", { userId: "bob", expires: "2024-01-01T13:00:00Z" }],
*     ["session3", { userId: "charlie", expires: "2024-01-01T14:00:00Z" }]
*   )
*
*   // Check initial state
*   const initialSize = yield* TxHashMap.size(sessionMap)
*   console.log(initialSize) // 3
*
*   // Clear all sessions (e.g., during maintenance)
*   yield* TxHashMap.clear(sessionMap)
*
*   // Verify cleared
*   const finalSize = yield* TxHashMap.size(sessionMap)
*   console.log(finalSize) // 0
*
*   const isEmpty = yield* TxHashMap.isEmpty(sessionMap)
*   console.log(isEmpty) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var clear$2 = (self) => set$3(self.ref, empty$10());
/**
* Returns the number of entries in the TxHashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const metrics = yield* TxHashMap.make(
*     ["requests", 1000],
*     ["errors", 5],
*     ["users", 50]
*   )
*
*   const count = yield* TxHashMap.size(metrics)
*   console.log(count) // 3
*
*   // Add more metrics
*   yield* TxHashMap.set(metrics, "response_time", 250)
*   const newCount = yield* TxHashMap.size(metrics)
*   console.log(newCount) // 4
*
*   // Remove a metric
*   yield* TxHashMap.remove(metrics, "errors")
*   const finalCount = yield* TxHashMap.size(metrics)
*   console.log(finalCount) // 3
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var size$4 = (self) => gen(function* () {
	return size$13(yield* get$3(self.ref));
});
/**
* Checks if the TxHashMap is empty.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Start with empty map
*   const cache = yield* TxHashMap.empty<string, any>()
*   const empty = yield* TxHashMap.isEmpty(cache)
*   console.log(empty) // true
*
*   // Add an item
*   yield* TxHashMap.set(cache, "key1", "value1")
*   const stillEmpty = yield* TxHashMap.isEmpty(cache)
*   console.log(stillEmpty) // false
*
*   // Clear and check again
*   yield* TxHashMap.clear(cache)
*   const emptyAgain = yield* TxHashMap.isEmpty(cache)
*   console.log(emptyAgain) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var isEmpty$4 = (self) => gen(function* () {
	return isEmpty$9(yield* get$3(self.ref));
});
/**
* Checks if the TxHashMap is non-empty.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const inventory = yield* TxHashMap.make(["laptop", 5])
*
*   const hasItems = yield* TxHashMap.isNonEmpty(inventory)
*   console.log(hasItems) // true
*
*   // Clear inventory
*   yield* TxHashMap.clear(inventory)
*   const stillHasItems = yield* TxHashMap.isNonEmpty(inventory)
*   console.log(stillHasItems) // false
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var isNonEmpty$1 = (self) => map$11(isEmpty$4(self), (empty) => !empty);
/**
* Updates the value for the specified key if it exists.
*
* **Mutation behavior**: This function mutates the original TxHashMap by updating
* the value at the specified key. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const counters = yield* TxHashMap.make(
*     ["downloads", 100],
*     ["views", 250]
*   )
*
*   // Increment existing counter
*   const oldDownloads = yield* TxHashMap.modify(
*     counters,
*     "downloads",
*     (count) => count + 1
*   )
*   console.log(oldDownloads) // Option.some(100)
*
*   const newDownloads = yield* TxHashMap.get(counters, "downloads")
*   console.log(newDownloads) // Option.some(101)
*
*   // Try to modify non-existent key
*   const nonExistent = yield* TxHashMap.modify(
*     counters,
*     "clicks",
*     (count) => count + 1
*   )
*   console.log(nonExistent) // Option.none()
*
*   // Update views counter with direct method call
*   yield* TxHashMap.modify(counters, "views", (views) => views * 2)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var modify$1 = /*#__PURE__*/ dual(3, (self, key, f) => gen(function* () {
	const currentMap = yield* get$3(self.ref);
	const currentValue = get$17(currentMap, key);
	if (isSome(currentValue)) {
		const newValue = f(currentValue.value);
		yield* set$3(self.ref, set$12(currentMap, key, newValue));
		return currentValue;
	}
	return none();
}));
/**
* Updates the value for the specified key using an Option-based update function.
*
* **Mutation behavior**: This function mutates the original TxHashMap by updating,
* adding, or removing the key-value pair based on the function result. It does not
* return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, Option, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const storage = yield* TxHashMap.make<string, string | number>([
*     "file1.txt",
*     "content1"
*   ], ["access_count", 0])
*
*   // Increment counter or initialize to 1
*   const updateFn = (opt: Option.Option<string | number>) =>
*     Option.isSome(opt) && typeof opt.value === "number"
*       ? Option.some(opt.value + 1)
*       : Option.some(1)
*
*   // Increment existing counter
*   yield* TxHashMap.modifyAt(storage, "access_count", updateFn)
*   const count1 = yield* TxHashMap.get(storage, "access_count")
*   console.log(count1) // Option.some(1)
*
*   // Increment existing counter again
*   yield* TxHashMap.modifyAt(storage, "access_count", updateFn)
*   const count2 = yield* TxHashMap.get(storage, "access_count")
*   console.log(count2) // Option.some(2)
*
*   // Remove by returning None
*   yield* TxHashMap.modifyAt(storage, "file1.txt", () => Option.none())
*   const hasFile = yield* TxHashMap.has(storage, "file1.txt")
*   console.log(hasFile) // false
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var modifyAt = /*#__PURE__*/ dual(3, (self, key, f) => gen(function* () {
	const currentMap = yield* get$3(self.ref);
	const currentValue = get$17(currentMap, key);
	const newValue = f(currentValue);
	if (isSome(newValue)) yield* set$3(self.ref, set$12(currentMap, key, newValue.value));
	else if (isSome(currentValue)) yield* set$3(self.ref, remove$7(currentMap, key));
}));
/**
* Returns an array of all keys in the TxHashMap.
*
* @example
* ```ts
* import { Effect, Option, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const userRoles = yield* TxHashMap.make(
*     ["alice", "admin"],
*     ["bob", "user"],
*     ["charlie", "moderator"]
*   )
*
*   const usernames = yield* TxHashMap.keys(userRoles)
*   console.log(usernames.sort()) // ["alice", "bob", "charlie"]
*
*   // Useful for iteration
*   for (const username of usernames) {
*     const role = yield* TxHashMap.get(userRoles, username)
*     if (Option.isSome(role)) {
*       console.log(`${username}: ${role.value}`)
*     }
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var keys = (self) => gen(function* () {
	const map = yield* get$3(self.ref);
	return Array.from(keys$5(map));
});
/**
* Returns an array of all values in the TxHashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const scores = yield* TxHashMap.make(
*     ["alice", 95],
*     ["bob", 87],
*     ["charlie", 92]
*   )
*
*   const allScores = yield* TxHashMap.values(scores)
*   console.log(allScores.sort()) // [87, 92, 95]
*
*   // Calculate average
*   const average = allScores.reduce((sum, score) => sum + score, 0) /
*     allScores.length
*   console.log(average) // 91.33
*
*   // Find maximum
*   const maxScore = Math.max(...allScores)
*   console.log(maxScore) // 95
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var values = (self) => gen(function* () {
	return toValues$1(yield* get$3(self.ref));
});
/**
* Returns an array of all key-value pairs in the TxHashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const config = yield* TxHashMap.make(
*     ["host", "localhost"],
*     ["port", "3000"],
*     ["ssl", "false"]
*   )
*
*   const allEntries = yield* TxHashMap.entries(config)
*   console.log(allEntries)
*   // [["host", "localhost"], ["port", "3000"], ["ssl", "false"]]
*
*   // Process configuration entries
*   for (const [key, value] of allEntries) {
*     console.log(`${key}=${value}`)
*   }
*   // host=localhost
*   // port=3000
*   // ssl=false
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var entries = (self) => gen(function* () {
	return toEntries$2(yield* get$3(self.ref));
});
/**
* Returns an immutable snapshot of the current TxHashMap state.
*
* @example
* ```ts
* import { Effect, HashMap, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const liveData = yield* TxHashMap.make(
*     ["temperature", 22.5],
*     ["humidity", 45.2],
*     ["pressure", 1013.25]
*   )
*
*   // Take snapshot for reporting
*   const snapshot = yield* TxHashMap.snapshot(liveData)
*
*   // Continue modifying live data
*   yield* TxHashMap.set(liveData, "temperature", 23.1)
*   yield* TxHashMap.set(liveData, "wind_speed", 5.3)
*
*   // Snapshot remains unchanged
*   console.log(HashMap.size(snapshot)) // 3
*   console.log(HashMap.get(snapshot, "temperature")) // Option.some(22.5)
*
*   // Can use regular HashMap operations on snapshot
*   const tempReading = HashMap.get(snapshot, "temperature")
*   const humidityReading = HashMap.get(snapshot, "humidity")
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var snapshot = (self) => get$3(self.ref);
/**
* Merges another HashMap into this TxHashMap. If both maps contain the same key,
* the value from the other map will be used.
*
* **Mutation behavior**: This function mutates the original TxHashMap by merging
* the provided HashMap into it. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, HashMap, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create initial user preferences
*   const userPrefs = yield* TxHashMap.make(
*     ["theme", "light"],
*     ["language", "en"],
*     ["notifications", "enabled"]
*   )
*
*   // New preferences to merge in
*   const newSettings = HashMap.make(
*     ["theme", "dark"], // will override existing
*     ["timezone", "UTC"], // new setting
*     ["sound", "enabled"] // new setting
*   )
*
*   // Merge the new settings
*   yield* TxHashMap.union(userPrefs, newSettings)
*
*   // Check the merged result
*   const theme = yield* TxHashMap.get(userPrefs, "theme")
*   console.log(theme) // Option.some("dark") - overridden
*
*   const language = yield* TxHashMap.get(userPrefs, "language")
*   console.log(language) // Option.some("en") - preserved
*
*   const timezone = yield* TxHashMap.get(userPrefs, "timezone")
*   console.log(timezone) // Option.some("UTC") - newly added
*
*   const size = yield* TxHashMap.size(userPrefs)
*   console.log(size) // 5 total settings
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var union$1 = /*#__PURE__*/ dual(2, (self, other) => update$2(self.ref, (map) => union$2(map, other)));
/**
* Removes multiple keys from the TxHashMap.
*
* **Mutation behavior**: This function mutates the original TxHashMap by removing
* all specified keys. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a cache with temporary data
*   const cache = yield* TxHashMap.make(
*     ["session_1", { user: "alice", expires: "2024-01-01" }],
*     ["session_2", { user: "bob", expires: "2024-01-01" }],
*     ["session_3", { user: "charlie", expires: "2024-12-31" }],
*     ["temp_data_1", { value: "temporary" }],
*     ["temp_data_2", { value: "also_temporary" }]
*   )
*
*   console.log(yield* TxHashMap.size(cache)) // 5
*
*   // Remove expired sessions and temporary data
*   const keysToRemove = ["session_1", "session_2", "temp_data_1", "temp_data_2"]
*   yield* TxHashMap.removeMany(cache, keysToRemove)
*
*   console.log(yield* TxHashMap.size(cache)) // 1
*
*   // Verify only the valid session remains
*   const remainingSession = yield* TxHashMap.get(cache, "session_3")
*   console.log(remainingSession) // Option.some({ user: "charlie", expires: "2024-12-31" })
*
*   // Can also remove from Set, Array, or any iterable
*   const moreKeysToRemove = new Set(["session_3"])
*   yield* TxHashMap.removeMany(cache, moreKeysToRemove)
*   console.log(yield* TxHashMap.isEmpty(cache)) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var removeMany = /*#__PURE__*/ dual(2, (self, keys) => update$2(self.ref, (map) => removeMany$3(map, keys)));
/**
* Sets multiple key-value pairs in the TxHashMap.
*
* **Mutation behavior**: This function mutates the original TxHashMap by setting
* all provided key-value pairs. It does not return a new TxHashMap reference.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create an empty product catalog
*   const catalog = yield* TxHashMap.empty<
*     string,
*     { price: number; stock: number }
*   >()
*
*   // Bulk load initial products
*   const initialProducts: Array<
*     readonly [string, { price: number; stock: number }]
*   > = [
*     ["laptop", { price: 999, stock: 5 }],
*     ["mouse", { price: 29, stock: 50 }],
*     ["keyboard", { price: 79, stock: 20 }],
*     ["monitor", { price: 299, stock: 8 }]
*   ]
*
*   yield* TxHashMap.setMany(catalog, initialProducts)
*
*   console.log(yield* TxHashMap.size(catalog)) // 4
*
*   // Update prices with a new batch
*   const priceUpdates: Array<
*     readonly [string, { price: number; stock: number }]
*   > = [
*     ["laptop", { price: 899, stock: 5 }], // sale price
*     ["mouse", { price: 25, stock: 50 }], // sale price
*     ["webcam", { price: 89, stock: 12 }] // new product
*   ]
*
*   yield* TxHashMap.setMany(catalog, priceUpdates)
*
*   console.log(yield* TxHashMap.size(catalog)) // 5 (4 original + 1 new)
*
*   // Verify the updates
*   const laptop = yield* TxHashMap.get(catalog, "laptop")
*   console.log(laptop) // Option.some({ price: 899, stock: 5 })
*
*   // Can also use Map, Set of tuples, or any iterable of entries
*   const jsMap = new Map([["tablet", { price: 399, stock: 3 }]])
*   yield* TxHashMap.setMany(catalog, jsMap)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var setMany = /*#__PURE__*/ dual(2, (self, entries) => update$2(self.ref, (map) => setMany$1(map, entries)));
/**
* Returns `true` if the specified value is a `TxHashMap`, `false` otherwise.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const txMap = yield* TxHashMap.make(["key", "value"])
*
*   console.log(TxHashMap.isTxHashMap(txMap)) // true
*   console.log(TxHashMap.isTxHashMap({})) // false
*   console.log(TxHashMap.isTxHashMap(null)) // false
*   console.log(TxHashMap.isTxHashMap("not a map")) // false
*
*   // Useful for type guards in runtime checks
*   const validateInput = (value: unknown) => {
*     if (TxHashMap.isTxHashMap(value)) {
*       // TypeScript now knows this is a TxHashMap
*       return Effect.succeed("Valid TxHashMap")
*     }
*     return Effect.fail("Invalid input")
*   }
* })
* ```
*
* @since 2.0.0
* @category guards
*/
var isTxHashMap = (value) => {
	return typeof value === "object" && value !== null && TypeId$7 in value;
};
/**
* Lookup the value for the specified key in the TxHashMap using a custom hash.
* This can provide performance benefits when the hash is precomputed.
*
* @example
* ```ts
* import { Effect, Hash, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a cache with user sessions
*   const cache = yield* TxHashMap.make(
*     ["session_abc123", { userId: "user1", lastActive: Date.now() }],
*     ["session_def456", { userId: "user2", lastActive: Date.now() }]
*   )
*
*   // When you have precomputed hash (e.g., from another lookup)
*   const sessionId = "session_abc123"
*   const precomputedHash = Hash.string(sessionId)
*
*   // Use hash-optimized lookup for performance in hot paths
*   const session = yield* TxHashMap.getHash(cache, sessionId, precomputedHash)
*   console.log(session) // Option.some({ userId: "user1", lastActive: ... })
*
*   // This avoids recomputing the hash when you already have it
*   const invalidSession = yield* TxHashMap.getHash(
*     cache,
*     "invalid",
*     Hash.string("invalid")
*   )
*   console.log(invalidSession) // Option.none()
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var getHash = /*#__PURE__*/ dual(3, (self, key, hash) => get$3(self.ref).pipe(map$11((map) => getHash$1(map, key, hash))));
/**
* Checks if the specified key has an entry in the TxHashMap using a custom hash.
* This can provide performance benefits when the hash is precomputed.
*
* @example
* ```ts
* import { Effect, Hash, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create an access control map
*   const permissions = yield* TxHashMap.make(
*     ["admin", { read: true, write: true, delete: true }],
*     ["user", { read: true, write: false, delete: false }]
*   )
*
*   // When checking permissions frequently with same roles
*   const role = "admin"
*   const roleHash = Hash.string(role)
*
*   // Use hash-optimized existence check
*   const hasAdminRole = yield* TxHashMap.hasHash(permissions, role, roleHash)
*   console.log(hasAdminRole) // true
*
*   // Check non-existent role
*   const hasGuestRole = yield* TxHashMap.hasHash(
*     permissions,
*     "guest",
*     Hash.string("guest")
*   )
*   console.log(hasGuestRole) // false
*
*   // Useful in hot paths where hash is computed once and reused
*   const roles = ["admin", "user", "moderator"]
*   const roleHashes = roles.map((role) => [role, Hash.string(role)] as const)
*
*   for (const [role, hash] of roleHashes) {
*     const exists = yield* TxHashMap.hasHash(permissions, role, hash)
*     console.log(`Role ${role}: ${exists}`)
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var hasHash = /*#__PURE__*/ dual(3, (self, key, hash) => get$3(self.ref).pipe(map$11((map) => hasHash$1(map, key, hash))));
/**
* Transforms all values in the TxHashMap using the provided function, preserving keys.
*
* **Return behavior**: This function returns a new TxHashMap reference with the
* transformed values. The original TxHashMap is not modified.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a user profile map
*   const profiles = yield* TxHashMap.make(
*     ["alice", { name: "Alice", age: 30, active: true }],
*     ["bob", { name: "Bob", age: 25, active: false }],
*     ["charlie", { name: "Charlie", age: 35, active: true }]
*   )
*
*   // Transform to extract just names with greeting
*   const greetings = yield* TxHashMap.map(
*     profiles,
*     (profile, userId) => `Hello, ${profile.name}! (User: ${userId})`
*   )
*
*   // Check the transformed values
*   const aliceGreeting = yield* TxHashMap.get(greetings, "alice")
*   console.log(aliceGreeting) // Option.some("Hello, Alice! (User: alice)")
*
*   // Data-last usage with pipe
*   const ages = yield* profiles.pipe(
*     TxHashMap.map((profile) => profile.age)
*   )
*
*   const aliceAge = yield* TxHashMap.get(ages, "alice")
*   console.log(aliceAge) // Option.some(30)
*
*   // Original map is unchanged
*   const originalAlice = yield* TxHashMap.get(profiles, "alice")
*   console.log(originalAlice) // Option.some({ name: "Alice", age: 30, active: true })
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var map$1 = /*#__PURE__*/ dual(2, (self, f) => gen(function* () {
	return yield* fromHashMap(map$14(yield* get$3(self.ref), f));
}));
/**
* Filters the TxHashMap to keep only entries that satisfy the provided predicate.
*
* **Return behavior**: This function returns a new TxHashMap reference containing
* only the entries that match the condition. The original TxHashMap is not modified.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a product inventory
*   const inventory = yield* TxHashMap.make(
*     ["laptop", { price: 999, stock: 5, category: "electronics" }],
*     ["mouse", { price: 29, stock: 50, category: "electronics" }],
*     ["book", { price: 15, stock: 100, category: "books" }],
*     ["phone", { price: 699, stock: 0, category: "electronics" }]
*   )
*
*   // Filter to get only electronics in stock
*   const electronicsInStock = yield* TxHashMap.filter(
*     inventory,
*     (product) => product.category === "electronics" && product.stock > 0
*   )
*
*   const size = yield* TxHashMap.size(electronicsInStock)
*   console.log(size) // 2 (laptop and mouse)
*
*   // Data-last usage with pipe
*   const expensiveItems = yield* inventory.pipe(
*     TxHashMap.filter((product) => product.price > 500)
*   )
*
*   const expensiveSize = yield* TxHashMap.size(expensiveItems)
*   console.log(expensiveSize) // 2 (laptop and phone)
*
*   // Type guard usage
*   const highValueItems = yield* TxHashMap.filter(
*     inventory,
*     (product): product is typeof product & { price: number } =>
*       product.price > 50
*   )
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var filter$1 = /*#__PURE__*/ dual(2, (self, predicate) => gen(function* () {
	return yield* fromHashMap(filter$7(yield* get$3(self.ref), predicate));
}));
/**
* Reduces the TxHashMap entries to a single value by applying a reducer function.
* Iterates over all key-value pairs and accumulates them into a final result.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a sales data map
*   const sales = yield* TxHashMap.make(
*     ["Q1", 15000],
*     ["Q2", 18000],
*     ["Q3", 22000],
*     ["Q4", 25000]
*   )
*
*   // Calculate total sales
*   const totalSales = yield* TxHashMap.reduce(
*     sales,
*     0,
*     (total, amount, quarter) => {
*       console.log(`Adding ${quarter}: ${amount}`)
*       return total + amount
*     }
*   )
*   console.log(`Total sales: ${totalSales}`) // 80000
*
*   // Data-last usage with pipe
*   const quarterlyReport = yield* sales.pipe(
*     TxHashMap.reduce(
*       { quarters: 0, total: 0, max: 0 },
*       (report, amount, quarter) => ({
*         quarters: report.quarters + 1,
*         total: report.total + amount,
*         max: Math.max(report.max, amount)
*       })
*     )
*   )
*   console.log(quarterlyReport) // { quarters: 4, total: 80000, max: 25000 }
*
*   // Build a summary string
*   const summary = yield* TxHashMap.reduce(
*     sales,
*     "",
*     (acc, amount, quarter) => acc + `${quarter}: $${amount.toLocaleString()}\n`
*   )
*   console.log(summary)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var reduce$1 = /*#__PURE__*/ dual(3, (self, zero, f) => get$3(self.ref).pipe(map$11((map) => reduce$4(map, zero, f))));
/**
* Combines filtering and mapping in a single operation. Applies a filter to each
* entry, keeping only successful results and transforming them.
*
* **Return behavior**: This function returns a new TxHashMap reference containing
* only the transformed entries that succeeded. The original TxHashMap is not modified.
*
* @example
* ```ts
* import { Effect, Option, Result, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a mixed data map
*   const userData = yield* TxHashMap.make(
*     ["alice", { age: "30", role: "admin", active: true }],
*     ["bob", { age: "invalid", role: "user", active: true }],
*     ["charlie", { age: "25", role: "admin", active: false }],
*     ["diana", { age: "28", role: "user", active: true }]
*   )
*
*   // Extract valid ages for active admin users only
*   const activeAdminAges = yield* TxHashMap.filterMap(
*     userData,
*     (user, username) => {
*       if (!user.active || user.role !== "admin") return Result.failVoid
*       const age = parseInt(user.age)
*       if (isNaN(age)) return Result.failVoid
*       return Result.succeed({
*         username,
*         age,
*         seniority: age > 27 ? "senior" : "junior"
*       })
*     }
*   )
*
*   const aliceData = yield* TxHashMap.get(activeAdminAges, "alice")
*   console.log(aliceData) // Option.some({ username: "alice", age: 30, seniority: "senior" })
*
*   const charlieData = yield* TxHashMap.get(activeAdminAges, "charlie")
*   console.log(charlieData) // Option.none() (not active)
*
*   // Data-last usage with pipe
*   const validAges = yield* userData.pipe(
*     TxHashMap.filterMap((user) => {
*       const age = parseInt(user.age)
*       return isNaN(age) ? Result.failVoid : Result.succeed(age)
*     })
*   )
*
*   const size = yield* TxHashMap.size(validAges)
*   console.log(size) // 3 (alice, charlie, diana have valid ages)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var filterMap = /*#__PURE__*/ dual(2, (self, f) => gen(function* () {
	return yield* fromHashMap(filterMap$4(yield* get$3(self.ref), f));
}));
/**
* Checks if any entry in the TxHashMap matches the given predicate.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a user status map
*   const userStatuses = yield* TxHashMap.make(
*     ["alice", { status: "online", lastSeen: Date.now() }],
*     ["bob", { status: "offline", lastSeen: Date.now() - 3600000 }],
*     ["charlie", { status: "online", lastSeen: Date.now() }]
*   )
*
*   // Check if any users are online
*   const hasOnlineUsers = yield* TxHashMap.hasBy(
*     userStatuses,
*     (user) => user.status === "online"
*   )
*   console.log(hasOnlineUsers) // true
*
*   // Check if any users have specific username pattern
*   const hasAdminUser = yield* TxHashMap.hasBy(
*     userStatuses,
*     (user, username) => username.startsWith("admin")
*   )
*   console.log(hasAdminUser) // false
*
*   // Data-last usage with pipe
*   const hasRecentActivity = yield* userStatuses.pipe(
*     TxHashMap.hasBy((user) => Date.now() - user.lastSeen < 1800000) // 30 minutes
*   )
*   console.log(hasRecentActivity) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var hasBy = /*#__PURE__*/ dual(2, (self, predicate) => get$3(self.ref).pipe(map$11((map) => hasBy$1(map, predicate))));
/**
* Finds the first entry in the TxHashMap that matches the given predicate.
* Returns the key-value pair as a tuple wrapped in an Option.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a task priority map
*   const tasks = yield* TxHashMap.make(
*     ["task1", { priority: 1, assignee: "alice", completed: false }],
*     ["task2", { priority: 3, assignee: "bob", completed: true }],
*     ["task3", { priority: 2, assignee: "alice", completed: false }]
*   )
*
*   // Find first high-priority incomplete task
*   const highPriorityTask = yield* TxHashMap.findFirst(
*     tasks,
*     (task) => task.priority >= 2 && !task.completed
*   )
*
*   if (highPriorityTask) {
*     const [taskId, task] = highPriorityTask
*     console.log(`Found task: ${taskId}, priority: ${task.priority}`)
*     // "Found task: task3, priority: 2"
*   }
*
*   // Find first task assigned to specific user
*   const aliceTask = yield* tasks.pipe(
*     TxHashMap.findFirst((task) => task.assignee === "alice")
*   )
*
*   if (aliceTask) {
*     console.log(`Alice's task: ${aliceTask[0]}`)
*   }
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var findFirst = /*#__PURE__*/ dual(2, (self, predicate) => get$3(self.ref).pipe(map$11((map) => findFirst$1(map, predicate))));
/**
* Checks if at least one entry in the TxHashMap satisfies the given predicate.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a product inventory
*   const inventory = yield* TxHashMap.make(
*     ["laptop", { price: 999, stock: 5 }],
*     ["mouse", { price: 29, stock: 50 }],
*     ["keyboard", { price: 79, stock: 0 }]
*   )
*
*   // Check if any products are expensive
*   const hasExpensiveProducts = yield* TxHashMap.some(
*     inventory,
*     (product) => product.price > 500
*   )
*   console.log(hasExpensiveProducts) // true
*
*   // Check if any products are out of stock
*   const hasOutOfStock = yield* TxHashMap.some(
*     inventory,
*     (product) => product.stock === 0
*   )
*   console.log(hasOutOfStock) // true
*
*   // Data-last usage with pipe
*   const hasAffordableItems = yield* inventory.pipe(
*     TxHashMap.some((product) => product.price < 50)
*   )
*   console.log(hasAffordableItems) // true (mouse is $29)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var some$1 = /*#__PURE__*/ dual(2, (self, predicate) => get$3(self.ref).pipe(map$11((map) => some$3(map, predicate))));
/**
* Checks if all entries in the TxHashMap satisfy the given predicate.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a user permissions map
*   const permissions = yield* TxHashMap.make(
*     ["alice", { canRead: true, canWrite: true, canDelete: false }],
*     ["bob", { canRead: true, canWrite: false, canDelete: false }],
*     ["charlie", { canRead: true, canWrite: true, canDelete: true }]
*   )
*
*   // Check if all users can read
*   const allCanRead = yield* TxHashMap.every(
*     permissions,
*     (perms) => perms.canRead
*   )
*   console.log(allCanRead) // true
*
*   // Check if all users can write
*   const allCanWrite = yield* TxHashMap.every(
*     permissions,
*     (perms) => perms.canWrite
*   )
*   console.log(allCanWrite) // false
*
*   // Data-last usage with pipe
*   const allHaveBasicAccess = yield* permissions.pipe(
*     TxHashMap.every((perms, username) => perms.canRead && username.length > 2)
*   )
*   console.log(allHaveBasicAccess) // true
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var every$1 = /*#__PURE__*/ dual(2, (self, predicate) => get$3(self.ref).pipe(map$11((map) => every$2(map, predicate))));
/**
* Executes a side-effect function for each entry in the TxHashMap.
* The function receives the value and key as parameters and can perform effects.
*
* @example
* ```ts
* import { Console, Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a log processing map
*   const logs = yield* TxHashMap.make(
*     ["error.log", { size: 1024, level: "error" }],
*     ["access.log", { size: 2048, level: "info" }],
*     ["debug.log", { size: 512, level: "debug" }]
*   )
*
*   // Process each log file with side effects
*   yield* TxHashMap.forEach(logs, (logInfo, filename) =>
*     Effect.gen(function*() {
*       yield* Console.log(
*         `Processing ${filename}: ${logInfo.size} bytes, level: ${logInfo.level}`
*       )
*       if (logInfo.level === "error") {
*         yield* Console.log(`⚠️  Error log detected: ${filename}`)
*       }
*     }))
*
*   // Data-last usage with pipe
*   yield* logs.pipe(
*     TxHashMap.forEach((logInfo) =>
*       logInfo.size > 1000
*         ? Console.log(`Large log file: ${logInfo.size} bytes`)
*         : Effect.void
*     )
*   )
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var forEach = /*#__PURE__*/ dual(2, (self, f) => gen(function* () {
	yield* forEach$3(toEntries$2(yield* get$3(self.ref)), ([key, value]) => f(value, key));
}));
/**
* Transforms the TxHashMap by applying a function that returns a TxHashMap to each entry,
* then flattening the results. Useful for complex transformations that require creating new maps.
*
* **Return behavior**: This function returns a new TxHashMap reference with the
* flattened results. The original TxHashMap is not modified.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a department-employee map
*   const departments = yield* TxHashMap.make(
*     ["engineering", ["alice", "bob"]],
*     ["marketing", ["charlie", "diana"]]
*   )
*
*   // Expand each department into individual employee entries with metadata
*   const employeeDetails = yield* TxHashMap.flatMap(
*     departments,
*     (employees, department) =>
*       Effect.gen(function*() {
*         const employeeMap = yield* TxHashMap.empty<
*           string,
*           { department: string; role: string }
*         >()
*         for (let i = 0; i < employees.length; i++) {
*           const employee = employees[i]
*           const role = i === 0 ? "lead" : "member"
*           yield* TxHashMap.set(employeeMap, employee, { department, role })
*         }
*         return employeeMap
*       })
*   )
*
*   // Check the flattened result
*   const alice = yield* TxHashMap.get(employeeDetails, "alice")
*   console.log(alice) // Option.some({ department: "engineering", role: "lead" })
*
*   const charlie = yield* TxHashMap.get(employeeDetails, "charlie")
*   console.log(charlie) // Option.some({ department: "marketing", role: "lead" })
*
*   const size = yield* TxHashMap.size(employeeDetails)
*   console.log(size) // 4 (all employees)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var flatMap = /*#__PURE__*/ dual(2, (self, f) => gen(function* () {
	const currentMap = yield* get$3(self.ref);
	const result = yield* empty$2();
	const mapEntries = toEntries$2(currentMap);
	for (const [key, value] of mapEntries) yield* setMany(result, yield* entries(yield* f(value, key)));
	return result;
}));
/**
* Removes all None values from a TxHashMap containing Option values.
*
* **Return behavior**: This function returns a new TxHashMap reference with only
* the Some values unwrapped. The original TxHashMap is not modified.
*
* @example
* ```ts
* import { Effect, Option, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a map with optional user data
*   const userData = yield* TxHashMap.make<
*     string,
*     Option.Option<{ age: number; email?: string }>
*   >(
*     ["alice", Option.some({ age: 30, email: "alice@example.com" })],
*     ["bob", Option.none()], // incomplete data
*     ["charlie", Option.some({ age: 25 })],
*     ["diana", Option.none()], // missing data
*     ["eve", Option.some({ age: 28, email: "eve@example.com" })]
*   )
*
*   // Remove all None values and unwrap Some values
*   const validUsers = yield* TxHashMap.compact(userData)
*
*   const size = yield* TxHashMap.size(validUsers)
*   console.log(size) // 3 (alice, charlie, eve)
*
*   const alice = yield* TxHashMap.get(validUsers, "alice")
*   console.log(alice) // Option.some({ age: 30, email: "alice@example.com" })
*
*   const bob = yield* TxHashMap.get(validUsers, "bob")
*   console.log(bob) // Option.none() (removed from map)
*
*   // Useful for cleaning up optional data processing results
*   const userAges = yield* TxHashMap.map(validUsers, (user) => user.age)
*   const ageEntries = yield* TxHashMap.entries(userAges)
*   console.log(ageEntries) // [["alice", 30], ["charlie", 25], ["eve", 28]]
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var compact = (self) => gen(function* () {
	return yield* fromHashMap(compact$3(yield* get$3(self.ref)));
});
/**
* Returns an array of all key-value pairs in the TxHashMap.
* This is an alias for the `entries` function, providing API consistency with HashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const settings = yield* TxHashMap.make(
*     ["theme", "dark"],
*     ["language", "en-US"],
*     ["timezone", "UTC"]
*   )
*
*   // Get all entries as an array
*   const allEntries = yield* TxHashMap.toEntries(settings)
*   console.log(allEntries)
*   // [["theme", "dark"], ["language", "en-US"], ["timezone", "UTC"]]
*
*   // Process entries
*   for (const [setting, value] of allEntries) {
*     console.log(`${setting}: ${value}`)
*   }
*
*   // Convert to object for JSON serialization
*   const settingsObj = Object.fromEntries(allEntries)
*   console.log(JSON.stringify(settingsObj))
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var toEntries = (self) => entries(self);
/**
* Returns an array of all values in the TxHashMap.
* This is an alias for the `values` function, providing API consistency with HashMap.
*
* @example
* ```ts
* import { Effect, TxHashMap } from "effect"
*
* const program = Effect.gen(function*() {
*   const inventory = yield* TxHashMap.make(
*     ["laptop", { price: 999, stock: 5 }],
*     ["mouse", { price: 29, stock: 50 }],
*     ["keyboard", { price: 79, stock: 20 }]
*   )
*
*   // Get all product information
*   const products = yield* TxHashMap.toValues(inventory)
*   console.log(products)
*   // [{ price: 999, stock: 5 }, { price: 29, stock: 50 }, { price: 79, stock: 20 }]
*
*   // Calculate total inventory value
*   const totalValue = products.reduce(
*     (sum, product) => sum + (product.price * product.stock),
*     0
*   )
*   console.log(`Total inventory value: $${totalValue}`) // $8,435
*
*   // Find products with low stock
*   const lowStockProducts = products.filter((product) => product.stock < 10)
*   console.log(`${lowStockProducts.length} products with low stock`)
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var toValues = (self) => values(self);
/**
* Helper function to create a TxHashMap from an existing HashMap
*/
var fromHashMap = (hashMap) => gen(function* () {
	const ref = yield* make$8(hashMap);
	return Object.assign(Object.create(TxHashMapProto), { ref });
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxHashSet.js
/**
* @since 2.0.0
*/
var TxHashSet_exports = /* @__PURE__ */ __exportAll({
	add: () => add,
	clear: () => clear$1,
	difference: () => difference,
	empty: () => empty$1,
	every: () => every,
	filter: () => filter,
	fromHashSet: () => fromHashSet,
	fromIterable: () => fromIterable$1,
	has: () => has,
	intersection: () => intersection,
	isEmpty: () => isEmpty$3,
	isSubset: () => isSubset,
	isTxHashSet: () => isTxHashSet,
	make: () => make$4,
	map: () => map,
	reduce: () => reduce,
	remove: () => remove,
	size: () => size$3,
	some: () => some,
	toHashSet: () => toHashSet,
	union: () => union
});
var TypeId$6 = "~effect/transactions/TxHashSet";
var TxHashSetProto = {
	[TypeId$6]: TypeId$6,
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toString() {
		return `TxHashSet(${format$1(toJson(this.ref))})`;
	},
	toJSON() {
		return {
			_id: "TxHashSet",
			ref: toJson(this.ref)
		};
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeTxHashSet = (ref) => {
	const self = Object.create(TxHashSetProto);
	self.ref = ref;
	return self;
};
/**
* Creates an empty TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.empty<string>()
*
*   console.log(yield* TxHashSet.size(txSet)) // 0
*   console.log(yield* TxHashSet.isEmpty(txSet)) // true
*
*   // Add some values
*   yield* TxHashSet.add(txSet, "hello")
*   yield* TxHashSet.add(txSet, "world")
*   console.log(yield* TxHashSet.size(txSet)) // 2
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var empty$1 = () => gen(function* () {
	return makeTxHashSet(yield* make$8(empty$11()));
});
/**
* Creates a TxHashSet from a variable number of values.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const fruits = yield* TxHashSet.make("apple", "banana", "cherry")
*   console.log(yield* TxHashSet.size(fruits)) // 3
*
*   const numbers = yield* TxHashSet.make(1, 2, 3, 2, 1) // Duplicates ignored
*   console.log(yield* TxHashSet.size(numbers)) // 3
*
*   const mixed = yield* TxHashSet.make("hello", 42, true)
*   console.log(yield* TxHashSet.size(mixed)) // 3
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var make$4 = (...values) => gen(function* () {
	return makeTxHashSet(yield* make$8(make$31(...values)));
});
/**
* Creates a TxHashSet from an iterable collection of values.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const fromArray = yield* TxHashSet.fromIterable(["a", "b", "c", "b", "a"])
*   console.log(yield* TxHashSet.size(fromArray)) // 3
*
*   const fromSet = yield* TxHashSet.fromIterable(new Set([1, 2, 3]))
*   console.log(yield* TxHashSet.size(fromSet)) // 3
*
*   const fromString = yield* TxHashSet.fromIterable("hello")
*   const values = yield* TxHashSet.toHashSet(fromString)
*   console.log(Array.from(values)) // ["h", "e", "l", "o"]
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromIterable$1 = (values) => gen(function* () {
	return makeTxHashSet(yield* make$8(fromIterable$9(values)));
});
/**
* Creates a TxHashSet from an existing HashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
* import * as HashSet from "effect/HashSet"
*
* const program = Effect.gen(function*() {
*   const hashSet = HashSet.make("x", "y", "z")
*   const txSet = yield* TxHashSet.fromHashSet(hashSet)
*
*   console.log(yield* TxHashSet.size(txSet)) // 3
*   console.log(yield* TxHashSet.has(txSet, "y")) // true
*
*   // Original hashSet is unchanged when txSet is modified
*   yield* TxHashSet.add(txSet, "w")
*   console.log(HashSet.size(hashSet)) // 3 (original unchanged)
*   console.log(yield* TxHashSet.size(txSet)) // 4
* })
* ```
*
* @since 2.0.0
* @category constructors
*/
var fromHashSet = (hashSet) => gen(function* () {
	return makeTxHashSet(yield* make$8(hashSet));
});
/**
* Checks if a value is a TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
* import * as HashSet from "effect/HashSet"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.make(1, 2, 3)
*   const hashSet = HashSet.make(1, 2, 3)
*   const array = [1, 2, 3]
*
*   console.log(TxHashSet.isTxHashSet(txSet)) // true
*   console.log(TxHashSet.isTxHashSet(hashSet)) // false
*   console.log(TxHashSet.isTxHashSet(array)) // false
*   console.log(TxHashSet.isTxHashSet(null)) // false
* })
* ```
*
* @since 2.0.0
* @category guards
*/
var isTxHashSet = (u) => typeof u === "object" && u !== null && TypeId$6 in u;
/**
* Adds a value to the TxHashSet. If the value already exists, the operation has no effect.
*
* **Mutation behavior**: This function mutates the original TxHashSet by adding
* the specified value. It does not return a new TxHashSet reference.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.make("a", "b")
*
*   yield* TxHashSet.add(txSet, "c")
*   console.log(yield* TxHashSet.size(txSet)) // 3
*   console.log(yield* TxHashSet.has(txSet, "c")) // true
*
*   // Adding existing value has no effect
*   yield* TxHashSet.add(txSet, "a")
*   console.log(yield* TxHashSet.size(txSet)) // 3 (unchanged)
* })
* ```
*
* @since 2.0.0
* @category mutations
*/
var add = /*#__PURE__*/ dual(2, (self, value) => update$2(self.ref, (set) => add$3(set, value)));
/**
* Removes a value from the TxHashSet.
*
* **Mutation behavior**: This function mutates the original TxHashSet by removing
* the specified value. It does not return a new TxHashSet reference.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.make("a", "b", "c")
*
*   const removed = yield* TxHashSet.remove(txSet, "b")
*   console.log(removed) // true (value existed and was removed)
*   console.log(yield* TxHashSet.size(txSet)) // 2
*   console.log(yield* TxHashSet.has(txSet, "b")) // false
*
*   // Removing non-existent value returns false
*   const notRemoved = yield* TxHashSet.remove(txSet, "d")
*   console.log(notRemoved) // false
* })
* ```
*
* @since 2.0.0
* @category mutations
*/
var remove = /*#__PURE__*/ dual(2, (self, value) => gen(function* () {
	const currentSet = yield* get$3(self.ref);
	const existed = has$11(currentSet, value);
	if (existed) yield* set$3(self.ref, remove$8(currentSet, value));
	return existed;
}));
/**
* Checks if the TxHashSet contains the specified value.
*
* @example
* ```ts
* import { Effect, Equal, Hash, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.make("apple", "banana", "cherry")
*
*   console.log(yield* TxHashSet.has(txSet, "apple")) // true
*   console.log(yield* TxHashSet.has(txSet, "grape")) // false
*
*   // Works with any type that implements Equal
*   class Person implements Equal.Equal {
*     constructor(readonly name: string) {}
*
*     [Equal.symbol](other: unknown) {
*       return other instanceof Person && this.name === other.name
*     }
*
*     [Hash.symbol](): number {
*       return Hash.string(this.name)
*     }
*   }
*
*   const people = yield* TxHashSet.make(new Person("Alice"), new Person("Bob"))
*   console.log(yield* TxHashSet.has(people, new Person("Alice"))) // true
* })
* ```
*
* @since 2.0.0
* @category elements
*/
var has = /*#__PURE__*/ dual(2, (self, value) => gen(function* () {
	return has$11(yield* get$3(self.ref), value);
}));
/**
* Returns the number of values in the TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const empty = yield* TxHashSet.empty<string>()
*   console.log(yield* TxHashSet.size(empty)) // 0
*
*   const small = yield* TxHashSet.make("a", "b")
*   console.log(yield* TxHashSet.size(small)) // 2
*
*   const fromIterable = yield* TxHashSet.fromIterable(["x", "y", "z", "x", "y"])
*   console.log(yield* TxHashSet.size(fromIterable)) // 3 (duplicates ignored)
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var size$3 = (self) => gen(function* () {
	return size$14(yield* get$3(self.ref));
});
/**
* Checks if the TxHashSet is empty.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const empty = yield* TxHashSet.empty<string>()
*   console.log(yield* TxHashSet.isEmpty(empty)) // true
*
*   const nonEmpty = yield* TxHashSet.make("a")
*   console.log(yield* TxHashSet.isEmpty(nonEmpty)) // false
* })
* ```
*
* @since 2.0.0
* @category getters
*/
var isEmpty$3 = (self) => gen(function* () {
	return isEmpty$10(yield* get$3(self.ref));
});
/**
* Removes all values from the TxHashSet.
*
* **Mutation behavior**: This function mutates the original TxHashSet by clearing
* all values. It does not return a new TxHashSet reference.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.make("a", "b", "c")
*   console.log(yield* TxHashSet.size(txSet)) // 3
*
*   yield* TxHashSet.clear(txSet)
*   console.log(yield* TxHashSet.size(txSet)) // 0
*   console.log(yield* TxHashSet.isEmpty(txSet)) // true
* })
* ```
*
* @since 2.0.0
* @category mutations
*/
var clear$1 = (self) => set$3(self.ref, empty$11());
/**
* Creates the union of two TxHashSets, returning a new TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const set1 = yield* TxHashSet.make("a", "b")
*   const set2 = yield* TxHashSet.make("b", "c")
*   const combined = yield* TxHashSet.union(set1, set2)
*
*   const values = yield* TxHashSet.toHashSet(combined)
*   console.log(Array.from(values).sort()) // ["a", "b", "c"]
*   console.log(yield* TxHashSet.size(combined)) // 3
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var union = /*#__PURE__*/ dual(2, (self, that) => gen(function* () {
	return yield* fromHashSet(union$3(yield* get$3(self.ref), yield* get$3(that.ref)));
}));
/**
* Creates the intersection of two TxHashSets, returning a new TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const set1 = yield* TxHashSet.make("a", "b", "c")
*   const set2 = yield* TxHashSet.make("b", "c", "d")
*   const common = yield* TxHashSet.intersection(set1, set2)
*
*   const values = yield* TxHashSet.toHashSet(common)
*   console.log(Array.from(values).sort()) // ["b", "c"]
*   console.log(yield* TxHashSet.size(common)) // 2
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var intersection = /*#__PURE__*/ dual(2, (self, that) => gen(function* () {
	return yield* fromHashSet(intersection$1(yield* get$3(self.ref), yield* get$3(that.ref)));
}));
/**
* Creates the difference of two TxHashSets (elements in the first set that are not in the second), returning a new TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const set1 = yield* TxHashSet.make("a", "b", "c")
*   const set2 = yield* TxHashSet.make("b", "d")
*   const diff = yield* TxHashSet.difference(set1, set2)
*
*   const values = yield* TxHashSet.toHashSet(diff)
*   console.log(Array.from(values).sort()) // ["a", "c"]
*   console.log(yield* TxHashSet.size(diff)) // 2
* })
* ```
*
* @since 2.0.0
* @category combinators
*/
var difference = /*#__PURE__*/ dual(2, (self, that) => gen(function* () {
	return yield* fromHashSet(difference$1(yield* get$3(self.ref), yield* get$3(that.ref)));
}));
/**
* Checks if a TxHashSet is a subset of another TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const small = yield* TxHashSet.make("a", "b")
*   const large = yield* TxHashSet.make("a", "b", "c", "d")
*   const other = yield* TxHashSet.make("x", "y")
*
*   console.log(yield* TxHashSet.isSubset(small, large)) // true
*   console.log(yield* TxHashSet.isSubset(large, small)) // false
*   console.log(yield* TxHashSet.isSubset(small, other)) // false
*   console.log(yield* TxHashSet.isSubset(small, small)) // true
* })
* ```
*
* @since 2.0.0
* @category elements
*/
var isSubset = /*#__PURE__*/ dual(2, (self, that) => gen(function* () {
	return isSubset$1(yield* get$3(self.ref), yield* get$3(that.ref));
}));
/**
* Tests whether at least one value in the TxHashSet satisfies the predicate.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const numbers = yield* TxHashSet.make(1, 2, 3, 4, 5)
*
*   console.log(yield* TxHashSet.some(numbers, (n) => n > 3)) // true
*   console.log(yield* TxHashSet.some(numbers, (n) => n > 10)) // false
*
*   const empty = yield* TxHashSet.empty<number>()
*   console.log(yield* TxHashSet.some(empty, (n) => n > 0)) // false
* })
* ```
*
* @since 2.0.0
* @category elements
*/
var some = /*#__PURE__*/ dual(2, (self, predicate) => gen(function* () {
	return some$4(yield* get$3(self.ref), predicate);
}));
/**
* Tests whether all values in the TxHashSet satisfy the predicate.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const numbers = yield* TxHashSet.make(2, 4, 6, 8)
*
*   console.log(yield* TxHashSet.every(numbers, (n) => n % 2 === 0)) // true
*   console.log(yield* TxHashSet.every(numbers, (n) => n > 5)) // false
*
*   const empty = yield* TxHashSet.empty<number>()
*   console.log(yield* TxHashSet.every(empty, (n) => n > 0)) // true (vacuously true)
* })
* ```
*
* @since 2.0.0
* @category elements
*/
var every = /*#__PURE__*/ dual(2, (self, predicate) => gen(function* () {
	return every$3(yield* get$3(self.ref), predicate);
}));
/**
* Maps each value in the TxHashSet using the provided function, returning a new TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const numbers = yield* TxHashSet.make(1, 2, 3)
*   const doubled = yield* TxHashSet.map(numbers, (n) => n * 2)
*
*   const values = yield* TxHashSet.toHashSet(doubled)
*   console.log(Array.from(values).sort()) // [2, 4, 6]
*   console.log(yield* TxHashSet.size(doubled)) // 3
*
*   // Mapping can reduce size if function produces duplicates
*   const strings = yield* TxHashSet.make("apple", "banana", "cherry")
*   const lengths = yield* TxHashSet.map(strings, (s) => s.length)
*   const lengthValues = yield* TxHashSet.toHashSet(lengths)
*   console.log(Array.from(lengthValues).sort()) // [5, 6] (apple=5, banana=6, cherry=6)
* })
* ```
*
* @since 2.0.0
* @category mapping
*/
var map = /*#__PURE__*/ dual(2, (self, f) => gen(function* () {
	return yield* fromHashSet(map$15(yield* get$3(self.ref), f));
}));
/**
* Filters the TxHashSet keeping only values that satisfy the predicate, returning a new TxHashSet.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const numbers = yield* TxHashSet.make(1, 2, 3, 4, 5, 6)
*   const evens = yield* TxHashSet.filter(numbers, (n) => n % 2 === 0)
*
*   const values = yield* TxHashSet.toHashSet(evens)
*   console.log(Array.from(values).sort()) // [2, 4, 6]
*   console.log(yield* TxHashSet.size(evens)) // 3
* })
* ```
*
* @since 2.0.0
* @category filtering
*/
var filter = /*#__PURE__*/ dual(2, (self, predicate) => gen(function* () {
	return yield* fromHashSet(filter$8(yield* get$3(self.ref), predicate));
}));
/**
* Reduces the TxHashSet to a single value by iterating through the values and applying an accumulator function.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
*
* const program = Effect.gen(function*() {
*   const numbers = yield* TxHashSet.make(1, 2, 3, 4, 5)
*   const sum = yield* TxHashSet.reduce(numbers, 0, (acc, n) => acc + n)
*
*   console.log(sum) // 15
*
*   const strings = yield* TxHashSet.make("a", "b", "c")
*   const concatenated = yield* TxHashSet.reduce(strings, "", (acc, s) => acc + s)
*   console.log(concatenated) // Order may vary: "abc", "bac", etc.
* })
* ```
*
* @since 2.0.0
* @category folding
*/
var reduce = /*#__PURE__*/ dual(3, (self, zero, f) => gen(function* () {
	return reduce$5(yield* get$3(self.ref), zero, f);
}));
/**
* Converts the TxHashSet to an immutable HashSet snapshot.
*
* @example
* ```ts
* import { Effect, TxHashSet } from "effect"
* import * as HashSet from "effect/HashSet"
*
* const program = Effect.gen(function*() {
*   const txSet = yield* TxHashSet.make("x", "y", "z")
*   const hashSet = yield* TxHashSet.toHashSet(txSet)
*
*   console.log(HashSet.size(hashSet)) // 3
*   console.log(HashSet.has(hashSet, "y")) // true
*
*   // hashSet is a snapshot - modifications to txSet don't affect it
*   yield* TxHashSet.add(txSet, "w")
*   console.log(HashSet.size(hashSet)) // 3 (unchanged)
*   console.log(yield* TxHashSet.size(txSet)) // 4
* })
* ```
*
* @since 2.0.0
* @category conversions
*/
var toHashSet = (self) => get$3(self.ref);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxPriorityQueue.js
/**
* A transactional priority queue. Elements are dequeued in order determined by the
* provided `Order` instance. All operations participate in the STM transaction system.
*
* @since 4.0.0
*/
var TxPriorityQueue_exports = /* @__PURE__ */ __exportAll({
	empty: () => empty,
	fromIterable: () => fromIterable,
	isEmpty: () => isEmpty$2,
	isNonEmpty: () => isNonEmpty,
	isTxPriorityQueue: () => isTxPriorityQueue,
	make: () => make$3,
	offer: () => offer$1,
	offerAll: () => offerAll$1,
	peek: () => peek$1,
	peekOption: () => peekOption,
	removeIf: () => removeIf,
	retainIf: () => retainIf,
	size: () => size$2,
	take: () => take$1,
	takeAll: () => takeAll$1,
	takeOption: () => takeOption,
	takeUpTo: () => takeUpTo,
	toArray: () => toArray
});
var TypeId$5 = "~effect/transactions/TxPriorityQueue";
var TxPriorityQueueProto = {
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toJSON() {
		return { _id: "TxPriorityQueue" };
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeTxPriorityQueue = (ref, ord) => {
	const self = Object.create(TxPriorityQueueProto);
	self[TypeId$5] = TypeId$5;
	self.ref = ref;
	self.ord = ord;
	return self;
};
var insertSorted = (chunk, value, ord) => {
	const arr = toArray$1(chunk);
	let lo = 0;
	let hi = arr.length;
	while (lo < hi) {
		const mid = lo + hi >>> 1;
		if (ord(arr[mid], value) <= 0) lo = mid + 1;
		else hi = mid;
	}
	const out = Array(arr.length + 1);
	for (let i = 0; i < lo; i++) out[i] = arr[i];
	out[lo] = value;
	for (let i = lo; i < arr.length; i++) out[i + 1] = arr[i];
	return fromIterable$7(out);
};
/**
* Creates an empty `TxPriorityQueue` with the given ordering.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   const empty = yield* TxPriorityQueue.isEmpty(pq)
*   console.log(empty) // true
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var empty = (order) => map$11(make$8(empty$9()), (ref) => makeTxPriorityQueue(ref, order));
/**
* Creates a `TxPriorityQueue` from an iterable of elements.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [3, 1, 2])
*   const first = yield* TxPriorityQueue.take(pq)
*   console.log(first) // 1
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var fromIterable = /*#__PURE__*/ dual(2, (order, iterable) => {
	return map$11(make$8(fromIterable$7(Array.from(iterable).sort((a, b) => order(a, b)))), (ref) => makeTxPriorityQueue(ref, order));
});
/**
* Creates a `TxPriorityQueue` from variadic elements.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.make(Order.Number)(3, 1, 2)
*   const first = yield* TxPriorityQueue.take(pq)
*   console.log(first) // 1
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var make$3 = (order) => (...elements) => fromIterable(order, elements);
/**
* Returns the number of elements in the queue.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [1, 2, 3])
*   const s = yield* TxPriorityQueue.size(pq)
*   console.log(s) // 3
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var size$2 = (self) => map$11(get$3(self.ref), size$12);
/**
* Returns `true` if the queue is empty.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   const empty = yield* TxPriorityQueue.isEmpty(pq)
*   console.log(empty) // true
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var isEmpty$2 = (self) => map$11(size$2(self), (n) => n === 0);
/**
* Returns `true` if the queue has at least one element.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [1])
*   const nonEmpty = yield* TxPriorityQueue.isNonEmpty(pq)
*   console.log(nonEmpty) // true
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var isNonEmpty = (self) => map$11(size$2(self), (n) => n > 0);
/**
* Observes the smallest element without removing it. Retries if the queue is
* empty.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [3, 1, 2])
*   const top = yield* TxPriorityQueue.peek(pq)
*   console.log(top) // 1
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var peek$1 = (self) => gen(function* () {
	const head$6 = head(yield* get$3(self.ref));
	if (isNone(head$6)) return yield* retryTransaction;
	return head$6.value;
});
/**
* Observes the smallest element without removing it. Returns `None` if the
* queue is empty.
*
* @example
* ```ts
* import { Effect, Option, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   const result = yield* TxPriorityQueue.peekOption(pq)
*   console.log(Option.isNone(result)) // true
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var peekOption = (self) => map$11(get$3(self.ref), head);
/**
* Inserts an element into the queue in sorted position.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   yield* TxPriorityQueue.offer(pq, 2)
*   yield* TxPriorityQueue.offer(pq, 1)
*   const first = yield* TxPriorityQueue.take(pq)
*   console.log(first) // 1
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var offer$1 = /*#__PURE__*/ dual(2, (self, value) => update$2(self.ref, (chunk) => insertSorted(chunk, value, self.ord)));
/**
* Inserts all elements from an iterable into the queue.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   yield* TxPriorityQueue.offerAll(pq, [3, 1, 2])
*   const first = yield* TxPriorityQueue.take(pq)
*   console.log(first) // 1
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var offerAll$1 = /*#__PURE__*/ dual(2, (self, values) => update$2(self.ref, (chunk) => {
	return fromIterable$7([...toArray$1(chunk), ...values].sort((a, b) => self.ord(a, b)));
}));
/**
* Takes the smallest element from the queue. Retries if the queue is empty.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [3, 1, 2])
*   const first = yield* TxPriorityQueue.take(pq)
*   console.log(first) // 1
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var take$1 = (self) => gen(function* () {
	const chunk = yield* get$3(self.ref);
	const head$5 = head(chunk);
	if (isNone(head$5)) return yield* retryTransaction;
	yield* set$3(self.ref, drop$1(chunk, 1));
	return head$5.value;
});
/**
* Takes all elements from the queue, returning them in priority order.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [3, 1, 2])
*   const all = yield* TxPriorityQueue.takeAll(pq)
*   console.log(all) // [1, 2, 3]
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var takeAll$1 = (self) => map$11(modify$3(self.ref, (chunk) => [chunk, empty$9()]), toArray$1);
/**
* Tries to take the smallest element. Returns `None` if the queue is empty.
*
* @example
* ```ts
* import { Effect, Option, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   const result = yield* TxPriorityQueue.takeOption(pq)
*   console.log(Option.isNone(result)) // true
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var takeOption = (self) => modify$3(self.ref, (chunk) => {
	const head$4 = head(chunk);
	if (isNone(head$4)) return [none(), chunk];
	return [some$2(head$4.value), drop$1(chunk, 1)];
});
/**
* Takes up to `n` elements from the queue in priority order.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [5, 3, 1, 4, 2])
*   const top2 = yield* TxPriorityQueue.takeUpTo(pq, 2)
*   console.log(top2) // [1, 2]
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var takeUpTo = /*#__PURE__*/ dual(2, (self, n) => map$11(modify$3(self.ref, (chunk) => {
	return [take$3(chunk, n), drop$1(chunk, n)];
}), toArray$1));
/**
* Removes elements matching the predicate.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [1, 2, 3, 4, 5])
*   yield* TxPriorityQueue.removeIf(pq, (n) => n % 2 === 0)
*   const all = yield* TxPriorityQueue.takeAll(pq)
*   console.log(all) // [1, 3, 5]
* })
* ```
*
* @since 4.0.0
* @category filtering
*/
var removeIf = /*#__PURE__*/ dual(2, (self, predicate) => update$2(self.ref, (chunk) => filter$6(chunk, (a) => !predicate(a))));
/**
* Retains only elements matching the predicate.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [1, 2, 3, 4, 5])
*   yield* TxPriorityQueue.retainIf(pq, (n) => n % 2 === 0)
*   const all = yield* TxPriorityQueue.takeAll(pq)
*   console.log(all) // [2, 4]
* })
* ```
*
* @since 4.0.0
* @category filtering
*/
var retainIf = /*#__PURE__*/ dual(2, (self, predicate) => update$2(self.ref, (chunk) => filter$6(chunk, predicate)));
/**
* Returns all elements in priority order without removing them.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.fromIterable(Order.Number, [3, 1, 2])
*   const all = yield* TxPriorityQueue.toArray(pq)
*   console.log(all) // [1, 2, 3]
* })
* ```
*
* @since 4.0.0
* @category conversions
*/
var toArray = (self) => map$11(get$3(self.ref), toArray$1);
/**
* Determines if the provided value is a `TxPriorityQueue`.
*
* @example
* ```ts
* import { Effect, Order, TxPriorityQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const pq = yield* TxPriorityQueue.empty<number>(Order.Number)
*   console.log(TxPriorityQueue.isTxPriorityQueue(pq)) // true
*   console.log(TxPriorityQueue.isTxPriorityQueue("nope")) // false
* })
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxPriorityQueue = (u) => typeof u === "object" && u !== null && TypeId$5 in u;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxQueue.js
var TxQueue_exports = /* @__PURE__ */ __exportAll({
	awaitCompletion: () => awaitCompletion,
	bounded: () => bounded$1,
	clear: () => clear,
	dropping: () => dropping$1,
	end: () => end,
	fail: () => fail,
	failCause: () => failCause,
	interrupt: () => interrupt,
	isClosing: () => isClosing,
	isDone: () => isDone,
	isEmpty: () => isEmpty$1,
	isFull: () => isFull$1,
	isOpen: () => isOpen,
	isShutdown: () => isShutdown$1,
	isTxDequeue: () => isTxDequeue,
	isTxEnqueue: () => isTxEnqueue,
	isTxQueue: () => isTxQueue,
	offer: () => offer,
	offerAll: () => offerAll,
	peek: () => peek,
	poll: () => poll,
	shutdown: () => shutdown$1,
	size: () => size$1,
	sliding: () => sliding$1,
	take: () => take,
	takeAll: () => takeAll,
	takeBetween: () => takeBetween,
	takeN: () => takeN,
	unbounded: () => unbounded$1
});
var EnqueueTypeId = "~effect/transactions/TxQueue/Enqueue";
var DequeueTypeId = "~effect/transactions/TxQueue/Dequeue";
var TypeId$4 = "~effect/transactions/TxQueue";
/**
* Checks if the given value is a TxEnqueue.
*
* @example
* ```ts
* import { TxQueue } from "effect"
*
* declare const someValue: unknown
*
* if (TxQueue.isTxEnqueue(someValue)) {
*   // someValue is now typed as TxEnqueue<unknown, unknown>
*   console.log("This is a TxEnqueue")
* }
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxEnqueue = (u) => hasProperty(u, EnqueueTypeId);
/**
* Checks if the given value is a TxDequeue.
*
* @example
* ```ts
* import { TxQueue } from "effect"
*
* declare const someValue: unknown
*
* if (TxQueue.isTxDequeue(someValue)) {
*   // someValue is now typed as TxDequeue<unknown, unknown>
*   console.log("This is a TxDequeue")
* }
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxDequeue = (u) => hasProperty(u, DequeueTypeId);
/**
* Checks if the given value is a TxQueue.
*
* @example
* ```ts
* import { TxQueue } from "effect"
*
* declare const someValue: unknown
*
* if (TxQueue.isTxQueue(someValue)) {
*   // someValue is now typed as TxQueue<unknown, unknown>
*   console.log("This is a TxQueue")
* }
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxQueue = (u) => hasProperty(u, TypeId$4);
var TxQueueProto = {
	[EnqueueTypeId]: {
		_A: (_) => _,
		_E: (_) => _
	},
	[DequeueTypeId]: {
		_A: (_) => _,
		_E: (_) => _
	},
	[TypeId$4]: {
		_A: (_) => _,
		_E: (_) => _
	},
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toString() {
		return `TxQueue(${this.strategy}, ${this.capacity})`;
	},
	toJSON() {
		return {
			_id: "TxQueue",
			strategy: this.strategy,
			capacity: this.capacity
		};
	}
};
/**
* Creates a new bounded `TxQueue` with the specified capacity.
*
* **Return behavior**: This function returns a new TxQueue reference with
* the specified capacity. No existing TxQueue instances are modified.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a bounded queue (E defaults to never)
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   // Create a bounded queue with error channel
*   const faultTolerantQueue = yield* TxQueue.bounded<number, string>(10)
*
*   // Offer items - will succeed until capacity is reached
*   yield* TxQueue.offer(queue, 1)
*   yield* TxQueue.offer(queue, 2)
*
*   const item = yield* TxQueue.take(queue)
*   console.log(item) // 1
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var bounded$1 = (capacity) => gen(function* () {
	const items = yield* empty$3();
	const stateRef = yield* make$8({ _tag: "Open" });
	const txQueue = Object.create(TxQueueProto);
	txQueue.strategy = "bounded";
	txQueue.capacity = capacity;
	txQueue.items = items;
	txQueue.stateRef = stateRef;
	return txQueue;
});
/**
* Creates a new unbounded `TxQueue` with unlimited capacity.
*
* **Return behavior**: This function returns a new TxQueue reference with
* unlimited capacity. No existing TxQueue instances are modified.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create an unbounded queue (E defaults to never)
*   const queue = yield* TxQueue.unbounded<string>()
*
*   // Create an unbounded queue with error channel
*   const faultTolerantQueue = yield* TxQueue.unbounded<string, Error>()
*
*   // Can offer unlimited items
*   yield* TxQueue.offer(queue, "hello")
*   yield* TxQueue.offer(queue, "world")
*
*   const size = yield* TxQueue.size(queue)
*   console.log(size) // 2
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var unbounded$1 = () => gen(function* () {
	const items = yield* empty$3();
	const stateRef = yield* make$8({ _tag: "Open" });
	const txQueue = Object.create(TxQueueProto);
	txQueue.strategy = "unbounded";
	txQueue.capacity = Number.POSITIVE_INFINITY;
	txQueue.items = items;
	txQueue.stateRef = stateRef;
	return txQueue;
});
/**
* Creates a new dropping `TxQueue` with the specified capacity that drops new items when full.
*
* **Return behavior**: This function returns a new TxQueue reference with
* dropping strategy. No existing TxQueue instances are modified.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a dropping queue with capacity 2
*   const queue = yield* TxQueue.dropping<number>(2)
*
*   // Fill to capacity
*   yield* TxQueue.offer(queue, 1)
*   yield* TxQueue.offer(queue, 2)
*
*   // This will be dropped (returns false)
*   const accepted = yield* TxQueue.offer(queue, 3)
*   console.log(accepted) // false
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var dropping$1 = (capacity) => gen(function* () {
	const items = yield* empty$3();
	const stateRef = yield* make$8({ _tag: "Open" });
	const txQueue = Object.create(TxQueueProto);
	txQueue.strategy = "dropping";
	txQueue.capacity = capacity;
	txQueue.items = items;
	txQueue.stateRef = stateRef;
	return txQueue;
});
/**
* Creates a new sliding `TxQueue` with the specified capacity that evicts old items when full.
*
* **Return behavior**: This function returns a new TxQueue reference with
* sliding strategy. No existing TxQueue instances are modified.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   // Create a sliding queue with capacity 2
*   const queue = yield* TxQueue.sliding<number>(2)
*
*   // Fill to capacity
*   yield* TxQueue.offer(queue, 1)
*   yield* TxQueue.offer(queue, 2)
*
*   // This will evict item 1 and add 3
*   yield* TxQueue.offer(queue, 3)
*
*   const item = yield* TxQueue.take(queue)
*   console.log(item) // 2 (item 1 was evicted)
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var sliding$1 = (capacity) => gen(function* () {
	const items = yield* empty$3();
	const stateRef = yield* make$8({ _tag: "Open" });
	const txQueue = Object.create(TxQueueProto);
	txQueue.strategy = "sliding";
	txQueue.capacity = capacity;
	txQueue.items = items;
	txQueue.stateRef = stateRef;
	return txQueue;
});
/**
* Offers an item to the queue.
*
* **Mutation behavior**: This function mutates the original TxQueue by adding
* the item according to the queue's strategy. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   // Offer an item - returns true if accepted
*   const accepted = yield* TxQueue.offer(queue, 42)
*   console.log(accepted) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var offer = /*#__PURE__*/ dual(2, (self, value) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done" || state._tag === "Closing") return false;
	const currentSize = yield* size$1(self);
	if (self.strategy === "unbounded") {
		yield* append(self.items, value);
		return true;
	}
	if (currentSize < self.capacity) {
		yield* append(self.items, value);
		return true;
	}
	if (self.strategy === "dropping") return false;
	if (self.strategy === "sliding") {
		yield* drop(self.items, 1);
		yield* append(self.items, value);
		return true;
	}
	return yield* retryTransaction;
}));
/**
* Offers multiple items to the queue.
*
* Returns an array of items that were rejected (not added to the queue).
*
* **Mutation behavior**: This function mutates the original TxQueue by adding
* items according to the queue's strategy. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Chunk, Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   // Offer multiple items - returns rejected items as array
*   const rejected = yield* TxQueue.offerAll(queue, [1, 2, 3, 4, 5])
*   console.log(rejected) // [] if all accepted
*   console.log(rejected.length) // 0
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var offerAll = /*#__PURE__*/ dual(2, (self, values) => gen(function* () {
	const rejected = [];
	for (const value of values) if (!(yield* offer(self, value))) rejected.push(value);
	return rejected;
}));
/**
* Takes an item from the queue.
*
* **Mutation behavior**: This function mutates the original TxQueue by removing
* the first item. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(10)
*   yield* TxQueue.offer(queue, 42)
*
*   // Take an item - blocks if empty
*   const item = yield* TxQueue.take(queue)
*   console.log(item) // 42
*
*   // When queue fails, take fails with the same error
*   yield* TxQueue.fail(queue, "queue error")
*   const result = yield* Effect.flip(TxQueue.take(queue))
*   console.log(result) // "queue error"
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var take = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done") return yield* failCause$2(state.cause);
	if (yield* isEmpty$1(self)) return yield* retryTransaction;
	const head$1 = head(yield* get$2(self.items));
	if (isNone(head$1)) return yield* retryTransaction;
	yield* drop(self.items, 1);
	if (state._tag === "Closing" && (yield* isEmpty$1(self))) yield* set$3(self.stateRef, {
		_tag: "Done",
		cause: state.cause
	});
	return head$1.value;
});
/**
* Tries to take an item from the queue without blocking.
*
* @example
* ```ts
* import { Effect, Option, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   // Poll returns Option.none if empty
*   const maybe = yield* TxQueue.poll(queue)
*   console.log(Option.isNone(maybe)) // true
*
*   yield* TxQueue.offer(queue, 42)
*   const item = yield* TxQueue.poll(queue)
*   console.log(Option.getOrNull(item)) // 42
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var poll = (self) => gen(function* () {
	if ((yield* get$3(self.stateRef))._tag === "Done") return none();
	const head$3 = head(yield* get$2(self.items));
	if (isNone(head$3)) return none();
	yield* drop(self.items, 1);
	return some$2(head$3.value);
});
/**
* Takes all items from the queue. Blocks if the queue is empty.
*
* If the queue is already in a failed state, the error is propagated through the E-channel.
* Follows the same patterns as `take` - waits when there are no elements.
*
* Returns a non-empty array since it blocks until at least one item is available.
*
* **Mutation behavior**: This function mutates the original TxQueue by removing
* all items. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Array, Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(10)
*   yield* TxQueue.offerAll(queue, [1, 2, 3, 4, 5])
*
*   // Take all items atomically - returns NonEmptyArray
*   const items = yield* TxQueue.takeAll(queue)
*   console.log(items) // [1, 2, 3, 4, 5]
*   console.log(Array.isArrayNonEmpty(items)) // true
* })
*
* // Error propagation example
* const errorExample = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(5)
*   yield* TxQueue.offerAll(queue, [1, 2])
*   yield* TxQueue.fail(queue, "processing error")
*
*   // takeAll() propagates the queue error through E-channel
*   const result = yield* Effect.flip(TxQueue.takeAll(queue))
*   console.log(result) // "processing error"
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var takeAll = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done") return yield* failCause$2(state.cause);
	if (yield* isEmpty$1(self)) return yield* retryTransaction;
	const items = toArray$1(yield* get$2(self.items));
	yield* set$2(self.items, empty$9());
	if (state._tag === "Closing") yield* set$3(self.stateRef, {
		_tag: "Done",
		cause: state.cause
	});
	return items;
});
/**
* Takes exactly N items from the queue in a single atomic transaction.
*
* This function waits (retries the transaction) until N items are available, then takes
* exactly N items. The only exception is when N exceeds the queue's capacity - in that
* case, it takes up to the queue's capacity and returns immediately.
*
* **Behavior**:
* - **Normal case**: Waits for exactly N items to be available
* - **Bounded queue with N > capacity**: Takes up to capacity items immediately
* - **Closing queue**: Takes available items and transitions to Done state
*
* **Mutation behavior**: This function mutates the original TxQueue by removing
* the taken items. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(5)
*   yield* TxQueue.offerAll(queue, [1, 2, 3])
*
*   // This will wait until 4 items are available
*   // (will retry transaction until more items are offered)
*   const items = yield* TxQueue.takeN(queue, 4)
*
*   // This requests more than capacity (5), so takes all available (up to 5)
*   const all = yield* TxQueue.takeN(queue, 10) // Takes at most 5 items
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var takeN = /*#__PURE__*/ dual(2, (self, n) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done") return yield* failCause$2(state.cause);
	const currentSize = yield* size$1(self);
	const requestedCount = n;
	const maxPossible = Math.min(requestedCount, self.capacity);
	const minimumRequired = requestedCount <= self.capacity ? requestedCount : maxPossible;
	if (currentSize < minimumRequired) {
		if (state._tag === "Closing") {
			if (yield* isEmpty$1(self)) {
				yield* set$3(self.stateRef, {
					_tag: "Done",
					cause: state.cause
				});
				return [];
			}
			const taken = toArray$1(yield* get$2(self.items));
			yield* set$2(self.items, empty$9());
			yield* set$3(self.stateRef, {
				_tag: "Done",
				cause: state.cause
			});
			return taken;
		}
		return yield* retryTransaction;
	}
	const toTake = minimumRequired;
	const taken = take$3(yield* get$2(self.items), toTake);
	yield* drop(self.items, toTake);
	if (state._tag === "Closing" && (yield* isEmpty$1(self))) yield* set$3(self.stateRef, {
		_tag: "Done",
		cause: state.cause
	});
	return toArray$1(taken);
}));
/**
* Takes a variable number of items between a specified minimum and maximum from the queue.
* Waits for at least the minimum number of items to be available.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*   yield* TxQueue.offerAll(queue, [1, 2, 3, 4, 5, 6, 7, 8])
*
*   // Take between 2 and 5 items
*   const batch1 = yield* TxQueue.takeBetween(queue, 2, 5)
*   console.log(batch1) // [1, 2, 3, 4, 5] - took 5 (up to max)
*
*   // Take between 1 and 10 items (but only 3 remain)
*   const batch2 = yield* TxQueue.takeBetween(queue, 1, 10)
*   console.log(batch2) // [6, 7, 8] - took 3 (all remaining)
*
*   // Would wait for at least 1 item to be available
*   // const batch3 = yield* TxQueue.takeBetween(queue, 1, 3)
* })
* ```
*
* @since 4.0.0
* @category taking
*/
var takeBetween = /*#__PURE__*/ dual(3, (self, min, max) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done") return yield* failCause$2(state.cause);
	if (min <= 0 || max <= 0 || min > max) return [];
	const currentSize = yield* size$1(self);
	if (currentSize < min) {
		if (state._tag === "Closing") {
			if (yield* isEmpty$1(self)) {
				yield* set$3(self.stateRef, {
					_tag: "Done",
					cause: state.cause
				});
				return [];
			}
			const taken = toArray$1(yield* get$2(self.items));
			yield* set$2(self.items, empty$9());
			yield* set$3(self.stateRef, {
				_tag: "Done",
				cause: state.cause
			});
			return taken;
		}
		return yield* retryTransaction;
	}
	const toTake = Math.min(currentSize, max);
	const taken = take$3(yield* get$2(self.items), toTake);
	yield* drop(self.items, toTake);
	if (state._tag === "Closing" && (yield* isEmpty$1(self))) yield* set$3(self.stateRef, {
		_tag: "Done",
		cause: state.cause
	});
	return toArray$1(taken);
}));
/**
* Views the next item without removing it. If the queue is in a failed state,
* the error is propagated through the E-channel.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(10)
*   yield* TxQueue.offer(queue, 42)
*
*   // Peek at the next item without removing it
*   const item = yield* TxQueue.peek(queue)
*   console.log(item) // 42
*
*   // Item is still in the queue
*   const size = yield* TxQueue.size(queue)
*   console.log(size) // 1
* })
*
* // Error handling example
* const errorExample = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(5)
*   yield* TxQueue.fail(queue, "queue failed")
*
*   // peek() propagates the queue error through E-channel
*   const result = yield* Effect.flip(TxQueue.peek(queue))
*   console.log(result) // "queue failed"
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var peek = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done") return yield* failCause$2(state.cause);
	const head$2 = head(yield* get$2(self.items));
	if (isNone(head$2)) return yield* retryTransaction;
	return head$2.value;
});
/**
* Gets the current size of the queue.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*   yield* TxQueue.offerAll(queue, [1, 2, 3])
*
*   const size = yield* TxQueue.size(queue)
*   console.log(size) // 3
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var size$1 = (self) => size$5(self.items);
/**
* Checks if the queue is empty.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   const empty = yield* TxQueue.isEmpty(queue)
*   console.log(empty) // true
*
*   yield* TxQueue.offer(queue, 42)
*   const stillEmpty = yield* TxQueue.isEmpty(queue)
*   console.log(stillEmpty) // false
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isEmpty$1 = (self) => isEmpty$5(self.items);
/**
* Checks if the queue is at capacity.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(2)
*
*   const full = yield* TxQueue.isFull(queue)
*   console.log(full) // false
*
*   yield* TxQueue.offerAll(queue, [1, 2])
*   const nowFull = yield* TxQueue.isFull(queue)
*   console.log(nowFull) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isFull$1 = (self) => gen(function* () {
	if (self.capacity === Number.POSITIVE_INFINITY) return false;
	return (yield* size$1(self)) >= self.capacity;
});
/**
* Interrupts the queue, transitioning it to a closing state.
*
* **Mutation behavior**: This function mutates the original TxQueue by marking
* it for graceful closure. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*   yield* TxQueue.offer(queue, 42)
*
*   // Interrupt gracefully - allows remaining items to be consumed
*   const result = yield* TxQueue.interrupt(queue)
*   console.log(result) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var interrupt = (self) => withFiber$1((fiber) => failCause(self, interrupt$3(fiber.id)));
/**
* Fails the queue with the specified error.
*
* **Mutation behavior**: This function mutates the original TxQueue by marking
* it as failed. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(10)
*
*   // Fail the queue with an error
*   const result = yield* TxQueue.fail(queue, "connection lost")
*   console.log(result) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var fail = /*#__PURE__*/ dual(2, (self, error) => gen(function* () {
	if ((yield* get$3(self.stateRef))._tag !== "Open") return false;
	yield* set$2(self.items, empty$9());
	yield* set$3(self.stateRef, {
		_tag: "Done",
		cause: fail$5(error)
	});
	return true;
}));
/**
* Completes the queue with the specified exit value.
*
* **Mutation behavior**: This function mutates the original TxQueue by marking
* it as completed. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Cause, Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   // Complete with specific cause
*   const cause = Cause.interrupt()
*   const result = yield* TxQueue.failCause(queue, cause)
*   console.log(result) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var failCause = /*#__PURE__*/ dual(2, (self, cause) => gen(function* () {
	if ((yield* get$3(self.stateRef))._tag !== "Open") return false;
	if (yield* isEmpty$1(self)) yield* set$3(self.stateRef, {
		_tag: "Done",
		cause
	});
	else yield* set$3(self.stateRef, {
		_tag: "Closing",
		cause
	});
	return true;
}));
/**
* Ends a queue by signaling completion with a Done error.
*
* This function provides a clean way to signal the end of a queue by calling
* `failCause` with `Cause.Done`. This is a convenience function for
* queues that are typed to accept `Cause.Done` in their error channel.
* When a queue is ended, all subsequent operations (take, peek, etc.) will fail with
* `Cause.Done`, propagating through the E-channel.
*
* @example
* ```ts
* import { Cause, Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, Cause.Done>(10)
*   yield* TxQueue.offer(queue, 1)
*   yield* TxQueue.offer(queue, 2)
*
*   // Signal the end of the queue
*   const result = yield* TxQueue.end(queue)
*   console.log(result) // true
*
*   // All operations will now fail with Done
*   const takeResult = yield* Effect.flip(TxQueue.take(queue))
*   console.log(Cause.isDone(takeResult)) // true
*
*   const peekResult = yield* Effect.flip(TxQueue.peek(queue))
*   console.log(Cause.isDone(peekResult)) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var end = (self) => failCause(self, fail$5(Done()));
/**
* Clears all elements from the queue without affecting its state.
* Returns the cleared elements, or an empty array if the queue is done with Done or interrupt.
*
* **Mutation behavior**: This function mutates the original TxQueue by removing
* all elements. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*   yield* TxQueue.offerAll(queue, [1, 2, 3, 4, 5])
*
*   const sizeBefore = yield* TxQueue.size(queue)
*   console.log(sizeBefore) // 5
*
*   const cleared = yield* TxQueue.clear(queue)
*   console.log(cleared) // [1, 2, 3, 4, 5]
*
*   const sizeAfter = yield* TxQueue.size(queue)
*   console.log(sizeAfter) // 0
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var clear = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	if (state._tag === "Done") {
		if (isDoneCause(state.cause)) return [];
		return yield* failCause$2(state.cause);
	}
	const chunk = yield* get$2(self.items);
	yield* set$2(self.items, empty$9());
	return toArray$1(chunk);
});
/**
* Shuts down the queue immediately by clearing all items and interrupting it (legacy compatibility).
*
* This operation performs two atomic steps:
* 1. **Clears** all items from the queue using `clear()`
* 2. **Interrupts** the queue using `interrupt()`
*
* **Mutation behavior**: This function mutates the original TxQueue by clearing
* its contents and marking it as shutdown. It does not return a new TxQueue reference.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*   yield* TxQueue.offerAll(queue, [1, 2, 3, 4, 5])
*
*   const sizeBefore = yield* TxQueue.size(queue)
*   console.log(sizeBefore) // 5
*
*   yield* TxQueue.shutdown(queue)
*
*   const sizeAfter = yield* TxQueue.size(queue)
*   console.log(sizeAfter) // 0 (cleared)
*
*   const isShutdown = yield* TxQueue.isShutdown(queue)
*   console.log(isShutdown) // true (interrupted)
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var shutdown$1 = (self) => gen(function* () {
	yield* ignore$1(clear(self));
	return yield* interrupt(self);
});
/**
* Checks if the queue is in the open state.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   const open = yield* TxQueue.isOpen(queue)
*   console.log(open) // true
*
*   yield* TxQueue.interrupt(queue)
*   const stillOpen = yield* TxQueue.isOpen(queue)
*   console.log(stillOpen) // false
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isOpen = (self) => gen(function* () {
	return (yield* get$3(self.stateRef))._tag === "Open";
});
/**
* Checks if the queue is in the closing state.
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*   yield* TxQueue.offer(queue, 42)
*
*   const closing = yield* TxQueue.isClosing(queue)
*   console.log(closing) // false
*
*   yield* TxQueue.interrupt(queue)
*   const nowClosing = yield* TxQueue.isClosing(queue)
*   console.log(nowClosing) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isClosing = (self) => gen(function* () {
	return (yield* get$3(self.stateRef))._tag === "Closing";
});
/**
* Checks if the queue is done (completed or failed).
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   const done = yield* TxQueue.isDone(queue)
*   console.log(done) // false
*
*   yield* TxQueue.interrupt(queue)
*   const nowDone = yield* TxQueue.isDone(queue)
*   console.log(nowDone) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isDone = (self) => gen(function* () {
	return (yield* get$3(self.stateRef))._tag === "Done";
});
/**
* Checks if the queue is shutdown (legacy compatibility).
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number>(10)
*
*   const isShutdown = yield* TxQueue.isShutdown(queue)
*   console.log(isShutdown) // false
*
*   yield* TxQueue.shutdown(queue)
*   const nowShutdown = yield* TxQueue.isShutdown(queue)
*   console.log(nowShutdown) // true
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var isShutdown$1 = (self) => isDone(self);
/**
* Waits for the queue to complete (either successfully or with failure).
*
* @example
* ```ts
* import { Effect, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const queue = yield* TxQueue.bounded<number, string>(10)
*
*   // In another fiber, end the queue
*   yield* Effect.forkChild(Effect.delay(TxQueue.interrupt(queue), "100 millis"))
*
*   // Wait for completion - succeeds when queue ends
*   yield* TxQueue.awaitCompletion(queue)
*   console.log("Queue completed successfully")
* })
* ```
*
* @since 4.0.0
* @category combinators
*/
var awaitCompletion = (self) => gen(function* () {
	if ((yield* get$3(self.stateRef))._tag === "Done") return;
	return yield* retryTransaction;
});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxPubSub.js
/**
* TxPubSub is a transactional publish/subscribe hub that provides Software Transactional Memory
* (STM) semantics for message broadcasting. Publishers broadcast messages to all current
* subscribers, with each subscriber receiving its own copy of every published message.
*
* Supports multiple queue strategies: bounded, unbounded, dropping, and sliding.
*
* @since 4.0.0
*/
var TxPubSub_exports = /* @__PURE__ */ __exportAll({
	acquireSubscriber: () => acquireSubscriber,
	awaitShutdown: () => awaitShutdown,
	bounded: () => bounded,
	capacity: () => capacity$1,
	dropping: () => dropping,
	isEmpty: () => isEmpty,
	isFull: () => isFull,
	isShutdown: () => isShutdown,
	isTxPubSub: () => isTxPubSub,
	publish: () => publish,
	publishAll: () => publishAll,
	releaseSubscriber: () => releaseSubscriber,
	shutdown: () => shutdown,
	size: () => size,
	sliding: () => sliding,
	subscribe: () => subscribe,
	unbounded: () => unbounded
});
var TypeId$3 = "~effect/transactions/TxPubSub";
var TxPubSubProto = {
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toJSON() {
		return {
			_id: "TxPubSub",
			strategy: this.strategy,
			capacity: this.capacity
		};
	},
	toString() {
		return `TxPubSub(${this.strategy}, ${this.capacity})`;
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeTxPubSub = (subscribersRef, shutdownRef, strategy, cap) => {
	const self = Object.create(TxPubSubProto);
	self[TypeId$3] = TypeId$3;
	self.subscribersRef = subscribersRef;
	self.shutdownRef = shutdownRef;
	self.strategy = strategy;
	self.capacity = cap;
	return self;
};
/**
* Creates a bounded TxPubSub with the specified capacity. When a subscriber's
* queue is full, the publisher will retry the transaction until space is available.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.bounded<number>(16)
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publish(hub, 42)
*       const value = yield* TxQueue.take(sub)
*       console.log(value) // 42
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var bounded = (capacity) => gen(function* () {
	return makeTxPubSub(yield* make$8([]), yield* make$8(false), "bounded", capacity);
});
/**
* Creates a dropping TxPubSub with the specified capacity. When a subscriber's
* queue is full, the message is dropped for that subscriber.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.dropping<number>(2)
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publish(hub, 1)
*       yield* TxPubSub.publish(hub, 2)
*       yield* TxPubSub.publish(hub, 3) // dropped
*       const v1 = yield* TxQueue.take(sub)
*       const v2 = yield* TxQueue.take(sub)
*       console.log(v1, v2) // 1 2
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var dropping = (capacity) => gen(function* () {
	return makeTxPubSub(yield* make$8([]), yield* make$8(false), "dropping", capacity);
});
/**
* Creates a sliding TxPubSub with the specified capacity. When a subscriber's
* queue is full, the oldest message in that subscriber's queue is dropped.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.sliding<number>(2)
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publish(hub, 1)
*       yield* TxPubSub.publish(hub, 2)
*       yield* TxPubSub.publish(hub, 3) // evicts 1
*       const v1 = yield* TxQueue.take(sub)
*       console.log(v1) // 2
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var sliding = (capacity) => gen(function* () {
	return makeTxPubSub(yield* make$8([]), yield* make$8(false), "sliding", capacity);
});
/**
* Creates an unbounded TxPubSub with unlimited capacity. Messages are always accepted.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<string>()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publish(hub, "msg")
*       const msg = yield* TxQueue.take(sub)
*       console.log(msg) // "msg"
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var unbounded = () => gen(function* () {
	return makeTxPubSub(yield* make$8([]), yield* make$8(false), "unbounded", Number.POSITIVE_INFINITY);
});
/**
* Returns the capacity of the TxPubSub.
*
* @example
* ```ts
* import { Effect, TxPubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.bounded<number>(16)
*   console.log(TxPubSub.capacity(hub)) // 16
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var capacity$1 = (self) => self.capacity;
/**
* Returns the current number of messages across all subscriber queues (the max).
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<number>()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publish(hub, 1)
*       yield* TxPubSub.publish(hub, 2)
*       const s = yield* TxPubSub.size(hub)
*       console.log(s) // 2
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var size = (self) => gen(function* () {
	const subscribers = yield* get$3(self.subscribersRef);
	let maxSize = 0;
	for (const queue of subscribers) {
		const s = yield* size$1(queue);
		if (s > maxSize) maxSize = s;
	}
	return maxSize;
});
/**
* Checks if the TxPubSub has no pending messages (all subscriber queues are empty).
*
* @example
* ```ts
* import { Effect, TxPubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<number>()
*   const empty = yield* TxPubSub.isEmpty(hub)
*   console.log(empty) // true
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var isEmpty = (self) => map$11(size(self), (s) => s === 0);
/**
* Checks if any subscriber queue is at capacity.
*
* @example
* ```ts
* import { Effect, TxPubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.bounded<number>(2)
*   const full = yield* TxPubSub.isFull(hub)
*   console.log(full) // false
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var isFull = (self) => gen(function* () {
	if (self.capacity === Number.POSITIVE_INFINITY) return false;
	const subscribers = yield* get$3(self.subscribersRef);
	for (const queue of subscribers) if (yield* isFull$1(queue)) return true;
	return false;
});
/**
* Checks if the TxPubSub has been shut down.
*
* @example
* ```ts
* import { Effect, TxPubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<number>()
*   console.log(yield* TxPubSub.isShutdown(hub)) // false
*   yield* TxPubSub.shutdown(hub)
*   console.log(yield* TxPubSub.isShutdown(hub)) // true
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var isShutdown = (self) => get$3(self.shutdownRef);
/**
* Publishes a message to all current subscribers.
*
* Returns `true` if the message was delivered to all subscribers, or `false` if
* the hub is shut down or the message was dropped for any subscriber (dropping strategy).
*
* For bounded strategy, retries the transaction if any subscriber queue is full.
* For sliding strategy, drops oldest messages in full subscriber queues.
* For dropping strategy, drops the message for full subscriber queues and returns `false`.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<string>()
*
*   // No subscribers - publish is a no-op
*   const r1 = yield* TxPubSub.publish(hub, "no one listening")
*   console.log(r1) // true
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publish(hub, "hello")
*       const msg = yield* TxQueue.take(sub)
*       console.log(msg) // "hello"
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var publish = /*#__PURE__*/ dual(2, (self, value) => gen(function* () {
	if (yield* get$3(self.shutdownRef)) return false;
	const subscribers = yield* get$3(self.subscribersRef);
	let allAccepted = true;
	for (const queue of subscribers) if (!(yield* offer(queue, value))) allAccepted = false;
	return allAccepted;
}));
/**
* Publishes all messages from an iterable to all current subscribers.
*
* Returns `true` if all messages were delivered to all subscribers.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<number>()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxPubSub.subscribe(hub)
*       yield* TxPubSub.publishAll(hub, [1, 2, 3])
*       const v1 = yield* TxQueue.take(sub)
*       const v2 = yield* TxQueue.take(sub)
*       const v3 = yield* TxQueue.take(sub)
*       console.log(v1, v2, v3) // 1 2 3
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var publishAll = /*#__PURE__*/ dual(2, (self, values) => gen(function* () {
	if (yield* get$3(self.shutdownRef)) return false;
	let allAccepted = true;
	for (const value of values) if (!(yield* publish(self, value))) allAccepted = false;
	return allAccepted;
}));
/**
* Subscribes to the TxPubSub, returning a TxQueue that receives all messages
* published after subscription. The subscription is automatically removed when
* the scope is closed.
*
* @example
* ```ts
* import { Effect, TxPubSub, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<string>()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub1 = yield* TxPubSub.subscribe(hub)
*       const sub2 = yield* TxPubSub.subscribe(hub)
*
*       yield* TxPubSub.publish(hub, "broadcast")
*
*       const msg1 = yield* TxQueue.take(sub1)
*       const msg2 = yield* TxQueue.take(sub2)
*       console.log(msg1, msg2) // "broadcast" "broadcast"
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var subscribe = (self) => acquireRelease$1(transaction(acquireSubscriber(self)), (queue) => transaction(releaseSubscriber(self, queue)));
/**
* Creates a subscriber queue and registers it with the pub/sub.
*
* This is the transactional acquire step of `subscribe`, exposed so that
* callers can compose it with other Tx operations in a single transaction
* (e.g. `TxSubscriptionRef.changes`).
*
* @since 4.0.0
* @category mutations
*/
var acquireSubscriber = (self) => gen(function* () {
	const queue = yield* makeSubscriberQueue(self.strategy, self.capacity);
	yield* update$2(self.subscribersRef, (subs) => [...subs, queue]);
	return queue;
});
/**
* Removes a subscriber queue from the pub/sub and shuts it down.
*
* This is the transactional release step of `subscribe`, exposed so that
* callers can compose it with other Tx operations in a single transaction.
*
* @since 4.0.0
* @category mutations
*/
var releaseSubscriber = /*#__PURE__*/ dual(2, (self, queue) => gen(function* () {
	yield* update$2(self.subscribersRef, (subs) => subs.filter((q) => q !== queue));
	yield* shutdown$1(queue);
}));
var makeSubscriberQueue = (strategy, cap) => {
	switch (strategy) {
		case "bounded": return bounded$1(cap);
		case "dropping": return dropping$1(cap);
		case "sliding": return sliding$1(cap);
		case "unbounded": return unbounded$1();
	}
};
/**
* Shuts down the TxPubSub and all subscriber queues. Subsequent publish operations
* will return `false`. Subsequent subscribe operations will receive an already-shutdown queue.
*
* @example
* ```ts
* import { Effect, TxPubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<number>()
*   yield* TxPubSub.shutdown(hub)
*
*   const shut = yield* TxPubSub.isShutdown(hub)
*   console.log(shut) // true
*
*   const accepted = yield* TxPubSub.publish(hub, 1)
*   console.log(accepted) // false
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var shutdown = (self) => gen(function* () {
	if (yield* get$3(self.shutdownRef)) return;
	yield* set$3(self.shutdownRef, true);
	const subscribers = yield* get$3(self.subscribersRef);
	for (const queue of subscribers) yield* shutdown$1(queue);
});
/**
* Waits for the TxPubSub to be shut down.
*
* @example
* ```ts
* import { Effect, TxPubSub } from "effect"
*
* const program = Effect.gen(function*() {
*   const hub = yield* TxPubSub.unbounded<number>()
*
*   const fiber = yield* Effect.forkChild(TxPubSub.awaitShutdown(hub))
*   yield* TxPubSub.shutdown(hub)
*   yield* fiber.await
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var awaitShutdown = (self) => gen(function* () {
	if (yield* get$3(self.shutdownRef)) return;
	return yield* retryTransaction;
});
/**
* Checks if the given value is a TxPubSub.
*
* @example
* ```ts
* import { TxPubSub } from "effect"
*
* declare const someValue: unknown
*
* if (TxPubSub.isTxPubSub(someValue)) {
*   console.log("This is a TxPubSub")
* }
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxPubSub = (u) => hasProperty(u, TypeId$3);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxReentrantLock.js
/**
* TxReentrantLock is a transactional read/write lock with reentrant semantics using Software
* Transactional Memory (STM). Multiple readers can hold the lock concurrently, OR a single
* writer can hold exclusive access. A fiber holding a write lock may acquire additional
* read or write locks (reentrancy).
*
* @since 4.0.0
*/
var TxReentrantLock_exports = /* @__PURE__ */ __exportAll({
	acquireRead: () => acquireRead,
	acquireWrite: () => acquireWrite,
	isTxReentrantLock: () => isTxReentrantLock,
	lock: () => lock,
	locked: () => locked,
	make: () => make$2,
	readLock: () => readLock,
	readLocked: () => readLocked,
	readLocks: () => readLocks,
	releaseRead: () => releaseRead,
	releaseWrite: () => releaseWrite,
	withLock: () => withLock,
	withReadLock: () => withReadLock,
	withWriteLock: () => withWriteLock,
	writeLock: () => writeLock,
	writeLocked: () => writeLocked,
	writeLocks: () => writeLocks
});
var TypeId$2 = "~effect/transactions/TxReentrantLock";
var emptyState = {
	readers: /*#__PURE__*/ empty$10(),
	writer: /*#__PURE__*/ none()
};
var TxReentrantLockProto = {
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toJSON() {
		return { _id: "TxReentrantLock" };
	},
	toString() {
		return "TxReentrantLock";
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Creates a new TxReentrantLock.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const isLocked = yield* TxReentrantLock.locked(lock)
*   console.log(isLocked) // false
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var make$2 = () => gen(function* () {
	const stateRef = yield* make$8(emptyState);
	const self = Object.create(TxReentrantLockProto);
	self[TypeId$2] = TypeId$2;
	self.stateRef = stateRef;
	return self;
});
/**
* Acquires a read lock. Blocks if another fiber holds the write lock.
* If the current fiber already holds the write lock, the read lock is granted (reentrancy).
* Returns the current number of read locks held by this fiber.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const count = yield* TxReentrantLock.acquireRead(lock)
*   console.log(count) // 1
*   yield* TxReentrantLock.releaseRead(lock)
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var acquireRead = (self) => withFiber$1((fiber) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	const fiberId = fiber.id;
	if (isSome(state.writer) && state.writer.value[0] !== fiberId) return yield* retryTransaction;
	const newCount = getOrElse(get$17(state.readers, fiberId), () => 0) + 1;
	yield* set$3(self.stateRef, {
		...state,
		readers: set$12(state.readers, fiberId, newCount)
	});
	return newCount;
}));
/**
* Acquires a write lock. Blocks if any other fiber holds any lock.
* If the current fiber already holds the write lock, the count is incremented (reentrancy).
* If the current fiber holds a read lock, the write lock is granted (upgrade).
* Returns the current number of write locks held by this fiber.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const count = yield* TxReentrantLock.acquireWrite(lock)
*   console.log(count) // 1
*   yield* TxReentrantLock.releaseWrite(lock)
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var acquireWrite = (self) => withFiber$1((fiber) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	const fiberId = fiber.id;
	if (isSome(state.writer) && state.writer.value[0] !== fiberId) return yield* retryTransaction;
	for (const [readerId] of state.readers) if (readerId !== fiberId && getOrElse(get$17(state.readers, readerId), () => 0) > 0) return yield* retryTransaction;
	if (isSome(state.writer)) {
		const newCount = state.writer.value[1] + 1;
		yield* set$3(self.stateRef, {
			...state,
			writer: some$2([fiberId, newCount])
		});
		return newCount;
	}
	yield* set$3(self.stateRef, {
		...state,
		writer: some$2([fiberId, 1])
	});
	return 1;
}));
/**
* Releases a read lock held by the current fiber.
* Returns the remaining number of read locks held by this fiber.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   yield* TxReentrantLock.acquireRead(lock)
*   const remaining = yield* TxReentrantLock.releaseRead(lock)
*   console.log(remaining) // 0
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var releaseRead = (self) => withFiber$1((fiber) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	const fiberId = fiber.id;
	const currentCount = getOrElse(get$17(state.readers, fiberId), () => 0);
	if (currentCount <= 0) return 0;
	const newCount = currentCount - 1;
	const newReaders = newCount === 0 ? remove$7(state.readers, fiberId) : set$12(state.readers, fiberId, newCount);
	yield* set$3(self.stateRef, {
		...state,
		readers: newReaders
	});
	return newCount;
}));
/**
* Releases a write lock held by the current fiber.
* Returns the remaining number of write locks held by this fiber.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   yield* TxReentrantLock.acquireWrite(lock)
*   const remaining = yield* TxReentrantLock.releaseWrite(lock)
*   console.log(remaining) // 0
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var releaseWrite = (self) => withFiber$1((fiber) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	const fiberId = fiber.id;
	if (isNone(state.writer) || state.writer.value[0] !== fiberId) return 0;
	const newCount = state.writer.value[1] - 1;
	const newWriter = newCount <= 0 ? none() : some$2([fiberId, newCount]);
	yield* set$3(self.stateRef, {
		...state,
		writer: newWriter
	});
	return newCount;
}));
/**
* Acquires a read lock for the duration of the scope.
* The lock is automatically released when the scope closes.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       yield* TxReentrantLock.readLock(lock)
*       // read lock is held for the duration of the scope
*     })
*   )
*   // read lock is released
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var readLock = (self) => acquireRelease$1(transaction(acquireRead(self)), () => transaction(releaseRead(self)));
/**
* Acquires a write lock for the duration of the scope.
* The lock is automatically released when the scope closes.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       yield* TxReentrantLock.writeLock(lock)
*       // write lock is held for the duration of the scope
*     })
*   )
*   // write lock is released
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var writeLock = (self) => acquireRelease$1(transaction(acquireWrite(self)), () => transaction(releaseWrite(self)));
/**
* Alias for `writeLock`. Acquires a write lock for the duration of the scope.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       yield* TxReentrantLock.lock(lock)
*       // exclusive lock is held
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var lock = writeLock;
/**
* Runs the provided effect while holding a read lock. The lock is automatically
* released after the effect completes, fails, or is interrupted.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const result = yield* TxReentrantLock.withReadLock(
*     lock,
*     Effect.succeed("read data")
*   )
*   console.log(result) // "read data"
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var withReadLock = (...args) => {
	if (args.length === 1) {
		const [effect] = args;
		return (self) => acquireUseRelease$1(transaction(acquireRead(self)), () => effect, () => transaction(releaseRead(self)));
	}
	const [self, effect] = args;
	return acquireUseRelease$1(transaction(acquireRead(self)), () => effect, () => transaction(releaseRead(self)));
};
/**
* Runs the provided effect while holding a write lock. The lock is automatically
* released after the effect completes, fails, or is interrupted.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const result = yield* TxReentrantLock.withWriteLock(
*     lock,
*     Effect.succeed("wrote data")
*   )
*   console.log(result) // "wrote data"
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var withWriteLock = (...args) => {
	if (args.length === 1) {
		const [effect] = args;
		return (self) => acquireUseRelease$1(transaction(acquireWrite(self)), () => effect, () => transaction(releaseWrite(self)));
	}
	const [self, effect] = args;
	return acquireUseRelease$1(transaction(acquireWrite(self)), () => effect, () => transaction(releaseWrite(self)));
};
/**
* Alias for `withWriteLock`. Runs the provided effect while holding a write lock.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const result = yield* TxReentrantLock.withLock(
*     lock,
*     Effect.succeed("exclusive operation")
*   )
*   console.log(result) // "exclusive operation"
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var withLock = withWriteLock;
/**
* Returns the total number of read locks held across all fibers.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   yield* TxReentrantLock.acquireRead(lock)
*   const count = yield* TxReentrantLock.readLocks(lock)
*   console.log(count) // 1
*   yield* TxReentrantLock.releaseRead(lock)
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var readLocks = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	let total = 0;
	for (const [, count] of state.readers) total += count;
	return total;
});
/**
* Returns the number of write locks held (0 or the reentrant count).
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const count = yield* TxReentrantLock.writeLocks(lock)
*   console.log(count) // 0
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var writeLocks = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	return isSome(state.writer) ? state.writer.value[1] : 0;
});
/**
* Checks if the lock is held by any fiber (read or write).
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const isLocked = yield* TxReentrantLock.locked(lock)
*   console.log(isLocked) // false
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var locked = (self) => gen(function* () {
	const state = yield* get$3(self.stateRef);
	return size$13(state.readers) > 0 || isSome(state.writer);
});
/**
* Checks if any fiber holds a read lock.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const isReadLocked = yield* TxReentrantLock.readLocked(lock)
*   console.log(isReadLocked) // false
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var readLocked = (self) => gen(function* () {
	return size$13((yield* get$3(self.stateRef)).readers) > 0;
});
/**
* Checks if any fiber holds a write lock.
*
* @example
* ```ts
* import { Effect, TxReentrantLock } from "effect"
*
* const program = Effect.gen(function*() {
*   const lock = yield* TxReentrantLock.make()
*   const isWriteLocked = yield* TxReentrantLock.writeLocked(lock)
*   console.log(isWriteLocked) // false
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var writeLocked = (self) => gen(function* () {
	return isSome((yield* get$3(self.stateRef)).writer);
});
/**
* Checks if the given value is a TxReentrantLock.
*
* @example
* ```ts
* import { TxReentrantLock } from "effect"
*
* declare const someValue: unknown
*
* if (TxReentrantLock.isTxReentrantLock(someValue)) {
*   console.log("This is a TxReentrantLock")
* }
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxReentrantLock = (u) => hasProperty(u, TypeId$2);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxSemaphore.js
/**
* @since 4.0.0
*/
var TxSemaphore_exports = /* @__PURE__ */ __exportAll({
	acquire: () => acquire,
	acquireN: () => acquireN,
	available: () => available,
	capacity: () => capacity,
	isTxSemaphore: () => isTxSemaphore,
	make: () => make$1,
	release: () => release,
	releaseN: () => releaseN,
	tryAcquire: () => tryAcquire,
	tryAcquireN: () => tryAcquireN,
	withPermit: () => withPermit,
	withPermitScoped: () => withPermitScoped,
	withPermits: () => withPermits
});
var TypeId$1 = "~effect/transactions/TxSemaphore";
var TxSemaphoreProto = {
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toJSON() {
		return {
			_id: "TxSemaphore",
			capacity: this.capacity
		};
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
var makeTxSemaphore = (permitsRef, capacity) => {
	const self = Object.create(TxSemaphoreProto);
	self[TypeId$1] = TypeId$1;
	self.permitsRef = permitsRef;
	self.capacity = capacity;
	return self;
};
/**
* Creates a new TxSemaphore with the specified number of permits.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* // Create a semaphore for managing concurrent access to a resource pool
* const program = Effect.gen(function*() {
*   // Create a semaphore with 3 permits for a connection pool
*   const connectionSemaphore = yield* TxSemaphore.make(3)
*
*   // Check initial state
*   const available = yield* TxSemaphore.available(connectionSemaphore)
*   const capacity = yield* TxSemaphore.capacity(connectionSemaphore)
*
*   yield* Console.log(
*     `Created semaphore with ${capacity} permits, ${available} available`
*   )
*   // Output: "Created semaphore with 3 permits, 3 available"
* })
* ```
*
* @param permits - The initial number of permits (must be non-negative)
* @returns Effect that succeeds with a new TxSemaphore
* @throws Defect if permits is negative
*
* @since 4.0.0
* @category constructors
*/
var make$1 = (permits) => gen(function* () {
	if (permits < 0) return yield* die(/* @__PURE__ */ new Error("Permits must be non-negative"));
	return makeTxSemaphore(yield* make$8(permits), permits);
});
/**
* Gets the current number of available permits in the semaphore.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(5)
*
*   // Check available permits before acquiring
*   const before = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`Available permits: ${before}`) // 5
*
*   // Acquire some permits
*   yield* TxSemaphore.acquire(semaphore)
*   yield* TxSemaphore.acquire(semaphore)
*
*   // Check available permits after acquiring
*   const after = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`Available permits: ${after}`) // 3
* })
* ```
*
* @param self - The TxSemaphore to inspect
* @returns Effect that succeeds with the current number of available permits
*
* @since 4.0.0
* @category combinators
*/
var available = (self) => get$3(self.permitsRef);
/**
* Gets the maximum capacity (total permits) of the semaphore.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(10)
*
*   const capacity = yield* TxSemaphore.capacity(semaphore)
*   yield* Console.log(`Semaphore capacity: ${capacity}`) // 10
*
*   // Capacity remains constant regardless of current permits
*   yield* TxSemaphore.acquire(semaphore)
*   const stillSame = yield* TxSemaphore.capacity(semaphore)
*   yield* Console.log(`Capacity after acquire: ${stillSame}`) // 10
* })
* ```
*
* @param self - The TxSemaphore to inspect
* @returns Effect that succeeds with the semaphore's maximum capacity
*
* @since 4.0.0
* @category combinators
*/
var capacity = (self) => succeed$4(self.capacity);
/**
* Acquires a single permit from the semaphore. If no permits are available,
* the effect will block until one becomes available.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(2)
*
*   yield* Console.log("Acquiring first permit...")
*   yield* TxSemaphore.acquire(semaphore)
*   yield* Console.log("First permit acquired")
*
*   yield* Console.log("Acquiring second permit...")
*   yield* TxSemaphore.acquire(semaphore)
*   yield* Console.log("Second permit acquired")
*
*   const available = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`Available permits: ${available}`) // 0
* })
* ```
*
* @param self - The TxSemaphore from which to acquire a permit
* @returns Effect that succeeds when a permit is acquired
*
* @since 4.0.0
* @category combinators
*/
var acquire = (self) => gen(function* () {
	const permits = yield* get$3(self.permitsRef);
	if (permits <= 0) return yield* retryTransaction;
	yield* set$3(self.permitsRef, permits - 1);
});
/**
* Acquires the specified number of permits from the semaphore. If not enough
* permits are available, the effect will block until they become available.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(5)
*
*   yield* Console.log("Acquiring 3 permits...")
*   yield* TxSemaphore.acquireN(semaphore, 3)
*   yield* Console.log("3 permits acquired")
*
*   const available = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`Available permits: ${available}`) // 2
* })
* ```
*
* @param self - The TxSemaphore from which to acquire permits
* @param n - The number of permits to acquire (must be positive)
* @returns Effect that succeeds when the permits are acquired
*
* @since 4.0.0
* @category combinators
*/
var acquireN = (self, n) => {
	if (n <= 0) return die(/* @__PURE__ */ new Error("Number of permits must be positive"));
	return gen(function* () {
		const permits = yield* get$3(self.permitsRef);
		if (permits < n) return yield* retryTransaction;
		yield* set$3(self.permitsRef, permits - n);
	});
};
/**
* Tries to acquire a single permit from the semaphore without blocking.
* Returns true if successful, false if no permits are available.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(1)
*
*   // First try should succeed
*   const first = yield* TxSemaphore.tryAcquire(semaphore)
*   yield* Console.log(`First try: ${first}`) // true
*
*   // Second try should fail (no permits left)
*   const second = yield* TxSemaphore.tryAcquire(semaphore)
*   yield* Console.log(`Second try: ${second}`) // false
* })
* ```
*
* @param self - The TxSemaphore from which to try acquiring a permit
* @returns Effect that succeeds with true if permit acquired, false otherwise
*
* @since 4.0.0
* @category combinators
*/
var tryAcquire = (self) => modify$3(self.permitsRef, (permits) => {
	if (permits > 0) return [true, permits - 1];
	return [false, permits];
});
/**
* Tries to acquire the specified number of permits from the semaphore without blocking.
* Returns true if successful, false if not enough permits are available.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(3)
*
*   // Try to acquire 2 permits (should succeed)
*   const first = yield* TxSemaphore.tryAcquireN(semaphore, 2)
*   yield* Console.log(`First try (2 permits): ${first}`) // true
*
*   // Try to acquire 2 more permits (should fail, only 1 left)
*   const second = yield* TxSemaphore.tryAcquireN(semaphore, 2)
*   yield* Console.log(`Second try (2 permits): ${second}`) // false
* })
* ```
*
* @param self - The TxSemaphore from which to try acquiring permits
* @param n - The number of permits to try acquiring (must be positive)
* @returns Effect that succeeds with true if permits acquired, false otherwise
*
* @since 4.0.0
* @category combinators
*/
var tryAcquireN = (self, n) => {
	if (n <= 0) return die(/* @__PURE__ */ new Error("Number of permits must be positive"));
	return modify$3(self.permitsRef, (permits) => {
		if (permits >= n) return [true, permits - n];
		return [false, permits];
	});
};
/**
* Releases a single permit back to the semaphore, making it available for acquisition.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(2)
*
*   // Acquire a permit
*   yield* TxSemaphore.acquire(semaphore)
*   let available = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`After acquire: ${available}`) // 1
*
*   // Release the permit
*   yield* TxSemaphore.release(semaphore)
*   available = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`After release: ${available}`) // 2
* })
* ```
*
* @param self - The TxSemaphore to which to release a permit
* @returns Effect that succeeds when the permit is released
*
* @since 4.0.0
* @category combinators
*/
var release = (self) => update$2(self.permitsRef, (permits) => permits >= self.capacity ? permits : permits + 1);
/**
* Releases the specified number of permits back to the semaphore.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(5)
*
*   // Acquire 3 permits
*   yield* TxSemaphore.acquireN(semaphore, 3)
*   let available = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`After acquire: ${available}`) // 2
*
*   // Release 2 permits
*   yield* TxSemaphore.releaseN(semaphore, 2)
*   available = yield* TxSemaphore.available(semaphore)
*   yield* Console.log(`After release: ${available}`) // 4
* })
* ```
*
* @param self - The TxSemaphore to which to release permits
* @param n - The number of permits to release (must be positive)
* @returns Effect that succeeds when the permits are released
*
* @since 4.0.0
* @category combinators
*/
var releaseN = (self, n) => {
	if (n <= 0) return die(/* @__PURE__ */ new Error("Number of permits must be positive"));
	return update$2(self.permitsRef, (permits) => {
		const newPermits = permits + n;
		return newPermits > self.capacity ? self.capacity : newPermits;
	});
};
/**
* Executes an effect with a single permit from the semaphore. The permit is
* automatically acquired before execution and released afterwards, even if the
* effect fails or is interrupted.
*
* **Note**: The permit acquisition and release operations use atomic semantics
* to ensure proper resource management with Effect's scoped operations.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(2)
*
*   // Execute database operation with automatic permit management
*   const result = yield* TxSemaphore.withPermit(
*     semaphore,
*     Effect.gen(function*() {
*       yield* Console.log("Permit acquired, accessing database...")
*       yield* Effect.sleep("100 millis") // Simulate database work
*       yield* Console.log("Database operation complete")
*       return "query result"
*     })
*   )
*
*   yield* Console.log(`Result: ${result}`)
*   // Permit is automatically released here
* })
* ```
*
* @param self - The TxSemaphore to acquire a permit from
* @param effect - The effect to execute with the permit
* @returns Effect that succeeds with the result of the provided effect
*
* @since 4.0.0
* @category combinators
*/
var withPermit = (self, effect) => acquireUseRelease$1(transaction(acquire(self)), () => effect, () => transaction(release(self)));
/**
* Executes an effect with the specified number of permits from the semaphore.
* The permits are automatically acquired before execution and released afterwards,
* even if the effect fails or is interrupted.
*
* **Note**: The permit acquisition and release operations use atomic semantics
* to ensure proper resource management with Effect's scoped operations.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(5)
*
*   // Execute batch operation with 3 permits
*   const results = yield* TxSemaphore.withPermits(
*     semaphore,
*     3,
*     Effect.gen(function*() {
*       yield* Console.log("3 permits acquired, processing batch...")
*       yield* Effect.sleep("200 millis") // Simulate batch processing
*       return ["result1", "result2", "result3"]
*     })
*   )
*
*   yield* Console.log(`Batch results: ${results.join(", ")}`)
*   // All 3 permits are automatically released here
* })
* ```
*
* @param self - The TxSemaphore to acquire permits from
* @param n - The number of permits to acquire (must be positive)
* @param effect - The effect to execute with the permits
* @returns Effect that succeeds with the result of the provided effect
*
* @since 4.0.0
* @category combinators
*/
var withPermits = (self, n, effect) => acquireUseRelease$1(transaction(acquireN(self, n)), () => effect, () => transaction(releaseN(self, n)));
/**
* Acquires a single permit from the semaphore in a scoped manner. The permit
* will be automatically released when the scope is closed, even if effects
* within the scope fail or are interrupted.
*
* **Note**: The permit acquisition and release operations use atomic semantics
* to ensure proper resource management with Effect's scoped operations.
*
* @example
* ```ts
* import { Console, Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(3)
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       // Acquire permit for the duration of this scope
*       yield* TxSemaphore.withPermitScoped(semaphore)
*       yield* Console.log("Permit acquired for scope")
*
*       // Do work within the scope
*       yield* Effect.sleep("500 millis")
*       yield* Console.log("Work completed")
*
*       // Permit will be automatically released when scope closes
*     })
*   )
*
*   yield* Console.log("Scope closed, permit released")
* })
* ```
*
* @param self - The TxSemaphore to acquire a permit from
* @returns Effect that succeeds when the permit is acquired (within scope)
*
* @since 4.0.0
* @category combinators
*/
var withPermitScoped = (self) => acquireRelease$1(transaction(acquire(self)), () => transaction(release(self)));
/**
* Determines if the provided value is a TxSemaphore.
*
* @example
* ```ts
* import { Effect, TxSemaphore } from "effect"
*
* const program = Effect.gen(function*() {
*   const semaphore = yield* TxSemaphore.make(5)
*   const notSemaphore = { some: "object" }
*
*   console.log(TxSemaphore.isTxSemaphore(semaphore)) // true
*   console.log(TxSemaphore.isTxSemaphore(notSemaphore)) // false
*
*   // Useful for runtime type checking in generic functions
*   if (TxSemaphore.isTxSemaphore(semaphore)) {
*     const available = yield* TxSemaphore.available(semaphore)
*     console.log(`Available permits: ${available}`)
*   }
* })
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxSemaphore = (u) => typeof u === "object" && u !== null && TypeId$1 in u;
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/TxSubscriptionRef.js
/**
* TxSubscriptionRef is a TxRef that allows subscribing to all committed changes. Subscribers
* receive the current value followed by every subsequent update via a transactional queue.
*
* @since 4.0.0
*/
var TxSubscriptionRef_exports = /* @__PURE__ */ __exportAll({
	changes: () => changes,
	changesStream: () => changesStream,
	get: () => get,
	getAndSet: () => getAndSet,
	getAndUpdate: () => getAndUpdate,
	isTxSubscriptionRef: () => isTxSubscriptionRef,
	make: () => make,
	modify: () => modify,
	set: () => set,
	update: () => update,
	updateAndGet: () => updateAndGet
});
var TypeId = "~effect/transactions/TxSubscriptionRef";
var TxSubscriptionRefProto = {
	[NodeInspectSymbol]() {
		return toJson(this);
	},
	toJSON() {
		return { _id: "TxSubscriptionRef" };
	},
	toString() {
		return "TxSubscriptionRef";
	},
	pipe() {
		return pipeArguments(this, arguments);
	}
};
/**
* Creates a new TxSubscriptionRef with the specified initial value.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(42)
*   const value = yield* TxSubscriptionRef.get(ref)
*   console.log(value) // 42
* })
* ```
*
* @since 4.0.0
* @category constructors
*/
var make = (value) => gen(function* () {
	const ref = yield* make$8(value);
	const pubsub = yield* unbounded();
	const self = Object.create(TxSubscriptionRefProto);
	self[TypeId] = TypeId;
	self.ref = ref;
	self.pubsub = pubsub;
	return self;
});
/**
* Reads the current value of the TxSubscriptionRef.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make("hello")
*   const value = yield* TxSubscriptionRef.get(ref)
*   console.log(value) // "hello"
* })
* ```
*
* @since 4.0.0
* @category getters
*/
var get = (self) => get$3(self.ref);
/**
* Modifies the value of the TxSubscriptionRef using a function that returns both a
* result and the new value. The new value is published to all subscribers atomically.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(10)
*   const result = yield* TxSubscriptionRef.modify(ref, (n) => [`was ${n}`, n + 1])
*   console.log(result) // "was 10"
*   console.log(yield* TxSubscriptionRef.get(ref)) // 11
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var modify = /*#__PURE__*/ dual(2, (self, f) => gen(function* () {
	const [returnValue, newValue] = f(yield* get$3(self.ref));
	yield* set$3(self.ref, newValue);
	yield* publish(self.pubsub, newValue);
	return returnValue;
}));
/**
* Sets the value of the TxSubscriptionRef and publishes the new value to all subscribers.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(0)
*   yield* TxSubscriptionRef.set(ref, 42)
*   console.log(yield* TxSubscriptionRef.get(ref)) // 42
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var set = /*#__PURE__*/ dual(2, (self, value) => modify(self, () => [void 0, value]));
/**
* Updates the value of the TxSubscriptionRef using a function and publishes the new
* value to all subscribers.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(5)
*   yield* TxSubscriptionRef.update(ref, (n) => n * 2)
*   console.log(yield* TxSubscriptionRef.get(ref)) // 10
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var update = /*#__PURE__*/ dual(2, (self, f) => modify(self, (current) => [void 0, f(current)]));
/**
* Gets the current value and sets a new value atomically. Publishes the new value
* to all subscribers.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make("a")
*   const old = yield* TxSubscriptionRef.getAndSet(ref, "b")
*   console.log(old) // "a"
*   console.log(yield* TxSubscriptionRef.get(ref)) // "b"
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var getAndSet = /*#__PURE__*/ dual(2, (self, value) => modify(self, (current) => [current, value]));
/**
* Gets the current value and updates it using a function atomically. Publishes
* the new value to all subscribers.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(1)
*   const old = yield* TxSubscriptionRef.getAndUpdate(ref, (n) => n + 10)
*   console.log(old) // 1
*   console.log(yield* TxSubscriptionRef.get(ref)) // 11
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var getAndUpdate = /*#__PURE__*/ dual(2, (self, f) => modify(self, (current) => [current, f(current)]));
/**
* Updates the value using a function and returns the new value. Publishes the
* new value to all subscribers.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(3)
*   const result = yield* TxSubscriptionRef.updateAndGet(ref, (n) => n * 3)
*   console.log(result) // 9
* })
* ```
*
* @since 4.0.0
* @category mutations
*/
var updateAndGet = /*#__PURE__*/ dual(2, (self, f) => modify(self, (current) => {
	const newValue = f(current);
	return [newValue, newValue];
}));
/**
* Subscribes to all changes of the TxSubscriptionRef. Returns a scoped TxDequeue
* that first yields the current value, then every subsequent update.
*
* @example
* ```ts
* import { Effect, TxSubscriptionRef, TxQueue } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(0)
*
*   yield* Effect.scoped(
*     Effect.gen(function*() {
*       const sub = yield* TxSubscriptionRef.changes(ref)
*       const initial = yield* TxQueue.take(sub)
*       console.log(initial) // 0
*
*       yield* TxSubscriptionRef.set(ref, 1)
*       const next = yield* TxQueue.take(sub)
*       console.log(next) // 1
*     })
*   )
* })
* ```
*
* @since 4.0.0
* @category subscriptions
*/
var changes = (self) => acquireRelease$1(transaction(gen(function* () {
	const sub = yield* acquireSubscriber(self.pubsub);
	yield* offer(sub, yield* get$3(self.ref));
	return sub;
})), (queue) => transaction(releaseSubscriber(self.pubsub, queue)));
/**
* Returns a Stream of all changes to the TxSubscriptionRef, starting with the
* current value followed by every subsequent update.
*
* @example
* ```ts
* import { Effect, Stream, TxSubscriptionRef } from "effect"
*
* const program = Effect.gen(function*() {
*   const ref = yield* TxSubscriptionRef.make(0)
*   yield* TxSubscriptionRef.set(ref, 1)
*   yield* TxSubscriptionRef.set(ref, 2)
*
*   const values = yield* Stream.runCollect(
*     TxSubscriptionRef.changesStream(ref).pipe(Stream.take(1))
*   )
*   console.log(values) // [2]
* })
* ```
*
* @since 4.0.0
* @category subscriptions
*/
var changesStream = (self) => unwrap$2(map$11(changes(self), (sub) => fromEffectRepeat(transaction(take(sub)))));
/**
* Checks if the given value is a TxSubscriptionRef.
*
* @example
* ```ts
* import { TxSubscriptionRef } from "effect"
*
* declare const someValue: unknown
*
* if (TxSubscriptionRef.isTxSubscriptionRef(someValue)) {
*   console.log("This is a TxSubscriptionRef")
* }
* ```
*
* @since 4.0.0
* @category guards
*/
var isTxSubscriptionRef = (u) => hasProperty(u, TypeId);
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Types.js
var Types_exports = /* @__PURE__ */ __exportAll({});
//#endregion
//#region node_modules/.bun/effect@https+++pkg.pr.new+Effect-TS+effect-smol+effect@8881a9b/node_modules/effect/dist/Unify.js
/**
* @since 2.0.0
*/
var Unify_exports = /* @__PURE__ */ __exportAll({ unify: () => unify });
/**
* Unifies the return type of a function or value.
*
* This function applies type unification to the result of a function or to a value directly.
* It's useful when you need to ensure that complex type unions are properly unified according
* to the Effect type system's unification protocol.
*
* @example
* ```ts
* import { Unify } from "effect"
*
* // Unify a simple value
* const unifiedValue = Unify.unify("hello")
* // Type: string
*
* // Unify a function result
* const createUnifiableValue = () => ({
*   value: "test",
*   [Unify.typeSymbol]: "string" as const,
*   [Unify.unifySymbol]: { String: () => "test" as const }
* })
*
* const unifiedFunction = Unify.unify(createUnifiableValue)
* // The result will be properly unified
*
* // Unify with curried functions
* const curriedFunction = (a: string) => (b: number) => ({ result: a + b })
* const unifiedCurried = Unify.unify(curriedFunction)
* // Type: (a: string) => (b: number) => Unify<{ result: string }>
* ```
*
* @since 2.0.0
* @category utilities
*/
var unify = identity;
//#endregion
export { Array_exports as Array, BigDecimal_exports as BigDecimal, BigInt_exports as BigInt, Boolean_exports as Boolean, Brand_exports as Brand, Cache_exports as Cache, Cause_exports as Cause, Channel_exports as Channel, ChannelSchema_exports as ChannelSchema, Chunk_exports as Chunk, Clock_exports as Clock, Combiner_exports as Combiner, Config_exports as Config, ConfigProvider_exports as ConfigProvider, Console_exports as Console, Cron_exports as Cron, Data_exports as Data, DateTime_exports as DateTime, Deferred_exports as Deferred, Differ_exports as Differ, Duration_exports as Duration, Effect_exports as Effect, Encoding_exports as Encoding, Equal_exports as Equal, Equivalence_exports as Equivalence, ErrorReporter_exports as ErrorReporter, ExecutionPlan_exports as ExecutionPlan, Exit_exports as Exit, Fiber_exports as Fiber, FiberHandle_exports as FiberHandle, FiberMap_exports as FiberMap, FiberSet_exports as FiberSet, FileSystem_exports as FileSystem, Filter_exports as Filter, Formatter_exports as Formatter, Function_exports as Function, Graph_exports as Graph, HKT_exports as HKT, Hash_exports as Hash, HashMap_exports as HashMap, HashRing_exports as HashRing, HashSet_exports as HashSet, Inspectable_exports as Inspectable, Iterable_exports as Iterable, JsonPatch_exports as JsonPatch, JsonPointer_exports as JsonPointer, JsonSchema_exports as JsonSchema, Latch_exports as Latch, Layer_exports as Layer, LayerMap_exports as LayerMap, LogLevel_exports as LogLevel, Logger_exports as Logger, ManagedRuntime_exports as ManagedRuntime, Match_exports as Match, Metric_exports as Metric, MutableHashMap_exports as MutableHashMap, MutableHashSet_exports as MutableHashSet, MutableList_exports as MutableList, MutableRef_exports as MutableRef, NonEmptyIterable_exports as NonEmptyIterable, NullOr_exports as NullOr, Number_exports as Number, Optic_exports as Optic, Option_exports as Option, Order_exports as Order, Ordering_exports as Ordering, Path_exports as Path, Pipeable_exports as Pipeable, PlatformError_exports as PlatformError, Pool_exports as Pool, Predicate_exports as Predicate, PrimaryKey_exports as PrimaryKey, PubSub_exports as PubSub, Pull_exports as Pull, Queue_exports as Queue, Random_exports as Random, RcMap_exports as RcMap, RcRef_exports as RcRef, Record_exports as Record, Redactable_exports as Redactable, Redacted_exports as Redacted, Reducer_exports as Reducer, Ref_exports as Ref, References_exports as References, RegExp_exports as RegExp, Request_exports as Request, RequestResolver_exports as RequestResolver, Resource_exports as Resource, Result_exports as Result, Runtime_exports as Runtime, Schedule_exports as Schedule, Scheduler_exports as Scheduler, Schema_exports as Schema, SchemaAST_exports as SchemaAST, SchemaGetter_exports as SchemaGetter, SchemaIssue_exports as SchemaIssue, SchemaParser_exports as SchemaParser, SchemaRepresentation_exports as SchemaRepresentation, SchemaTransformation_exports as SchemaTransformation, SchemaUtils_exports as SchemaUtils, Scope_exports as Scope, ScopedCache_exports as ScopedCache, ScopedRef_exports as ScopedRef, Semaphore_exports as Semaphore, ServiceMap_exports as ServiceMap, Sink_exports as Sink, Stdio_exports as Stdio, Stream_exports as Stream, String_exports as String, Struct_exports as Struct, SubscriptionRef_exports as SubscriptionRef, Symbol_exports as Symbol, SynchronizedRef_exports as SynchronizedRef, Take_exports as Take, Terminal_exports as Terminal, Tracer_exports as Tracer, Trie_exports as Trie, Tuple_exports as Tuple, TxChunk_exports as TxChunk, TxDeferred_exports as TxDeferred, TxHashMap_exports as TxHashMap, TxHashSet_exports as TxHashSet, TxPriorityQueue_exports as TxPriorityQueue, TxPubSub_exports as TxPubSub, TxQueue_exports as TxQueue, TxReentrantLock_exports as TxReentrantLock, TxRef_exports as TxRef, TxSemaphore_exports as TxSemaphore, TxSubscriptionRef_exports as TxSubscriptionRef, Types_exports as Types, UndefinedOr_exports as UndefinedOr, Unify_exports as Unify, Utils_exports as Utils, absurd, coerceUnsafe, flow, hole, identity, pipe };
