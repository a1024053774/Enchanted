import { i as __toESM, n as __exportAll } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
import { t as require_jsx_runtime } from "./react_jsx-runtime.js";
import { C as useIsoLayoutEffect, f as getWindow, h as isHTMLElement, m as isElement, n as useStableCallback } from "./useId-Cfrl5XdH.js";
import { t as addEventListener } from "./addEventListener-BcJLlhNA.js";
import { c as matchesFocusVisible } from "./element-du8in3y-.js";
import { t as ownerDocument } from "./owner-BmKt4Bpq.js";
import { a as useMergedRefs, c as NOOP, r as warn, t as useRenderElement } from "./useRenderElement-CvLulVDb.js";
import { n as useAnimationFrame } from "./useAnimationFrame-CNfBoYED.js";
import { n as contains, r as getTarget, t as activeElement } from "./shadowDom-CQZHMuh3.js";
import { S as trackPress, c as drag, f as inputChange, g as keyboard, n as createGenericEventDetails, t as createChangeEventDetails, v as none } from "./createBaseUIEventDetails-CVD4a1Ya.js";
import { t as useValueAsRef } from "./useValueAsRef-B26tI_FQ.js";
import { t as visuallyHidden } from "./visuallyHidden-Xbj0ZvZT.js";
import { r as mergeProps } from "./merge-props-BSY6QP_a.js";
import { t as require_shim } from "./shim-DgmQmt-v.js";
import { t as useBaseUiId } from "./useBaseUiId-BBG3KkG2.js";
import { a as COMPOSITE_KEYS, c as PAGE_UP, i as ARROW_UP, n as ARROW_LEFT, o as HOME, r as ARROW_RIGHT, s as PAGE_DOWN, t as ARROW_DOWN } from "./composite-MRVSAvlp.js";
import { t as useValueChanged } from "./useValueChanged-D0QUycMP.js";
import { t as useControlled } from "./useControlled-tPZe1TD5.js";
import { i as useRegisterFieldControl, n as useLabelableContext, r as useFormContext, s as useFieldRootContext, u as fieldValidityMapping } from "./LabelableContext-CdYnDOEr.js";
import { t as useLabelableId } from "./useLabelableId-DmWnMHl6.js";
import { t as stringifyLocale } from "./stringifyLocale-DrRqoF2T.js";
import { n as resolveAriaLabelledBy, r as areArraysEqual, t as getDefaultLabelId } from "./resolveAriaLabelledBy-D9b8XvNL.js";
import { t as useDirection } from "./DirectionContext-DRel_lZA.js";
import { t as useCompositeListItem } from "./useCompositeListItem-BYy-x-0E.js";
import { t as CompositeList } from "./CompositeList-BS4gmjlB.js";
import { n as useLabel, t as focusElementWithVisible } from "./useLabel-C0H9kumO.js";
import { n as useCSPContext, t as clamp } from "./clamp-D_1BKi7j.js";
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/asc.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function asc(a, b) {
	return a - b;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/getSliderValue.mjs
function getSliderValue(valueInput, index, min, max, range, values) {
	const clamped = clamp(valueInput, min, max);
	if (!range) return clamped;
	const output = values.slice();
	output[index] = clamp(clamped, values[index - 1] ?? -Infinity, values[index + 1] ?? Infinity);
	return output.sort(asc);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/validateMinimumDistance.mjs
function validateMinimumDistance(values, step, minStepsBetweenValues) {
	if (!Array.isArray(values)) return true;
	const minDistance = step * minStepsBetweenValues;
	for (let i = 0; i < values.length - 1; i += 1) if (!(Math.abs(values[i] - values[i + 1]) >= minDistance)) return false;
	return true;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/root/stateAttributesMapping.mjs
var nullMapping = () => null;
var sliderStateAttributesMapping = {
	activeThumbIndex: nullMapping,
	max: nullMapping,
	min: nullMapping,
	minStepsBetweenValues: nullMapping,
	step: nullMapping,
	values: nullMapping,
	...fieldValidityMapping
};
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/root/SliderRootContext.mjs
var SliderRootContext = /*#__PURE__*/ import_react.createContext(void 0);
SliderRootContext.displayName = "SliderRootContext";
function useSliderRootContext() {
	const context = import_react.useContext(SliderRootContext);
	if (context === void 0) throw new Error("Base UI: SliderRootContext is missing. Slider parts must be placed within <Slider.Root>.");
	return context;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/root/SliderRoot.mjs
var import_jsx_runtime = require_jsx_runtime();
function areValuesEqual(newValue, oldValue) {
	return newValue === oldValue || Array.isArray(newValue) && Array.isArray(oldValue) && areArraysEqual(newValue, oldValue);
}
/**
* Groups all parts of the slider.
* Renders a `<div>` element.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderRoot = /*#__PURE__*/ import_react.forwardRef(function SliderRoot(componentProps, forwardedRef) {
	const { "aria-labelledby": ariaLabelledByProp, className, defaultValue, disabled: disabledProp = false, id: idProp, format, largeStep = 10, locale, render, max = 100, min = 0, minStepsBetweenValues = 0, form, name: nameProp, onValueChange: onValueChangeProp, onValueCommitted: onValueCommittedProp, orientation = "horizontal", step = 1, thumbCollisionBehavior = "push", thumbAlignment = "center", value: valueProp, style, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const defaultLabelId = getDefaultLabelId(id);
	const onValueChange = useStableCallback(onValueChangeProp);
	const onValueCommitted = useStableCallback(onValueCommittedProp);
	const { clearErrors } = useFormContext();
	const { state: fieldState, disabled: fieldDisabled, name: fieldName, setTouched, setDirty, validityData, validation } = useFieldRootContext();
	const { labelId: fieldLabelId } = useLabelableContext();
	const [labelId, setLabelId] = import_react.useState();
	const ariaLabelledby = ariaLabelledByProp ?? resolveAriaLabelledBy(fieldLabelId, labelId);
	const disabled = fieldDisabled || disabledProp;
	const name = fieldName ?? nameProp;
	const [valueUnwrapped, setValueUnwrapped] = useControlled({
		controlled: valueProp,
		default: defaultValue ?? min,
		name: "Slider"
	});
	const sliderRef = import_react.useRef(null);
	const controlRef = import_react.useRef(null);
	const thumbRefs = import_react.useRef([]);
	const pressedThumbCenterOffsetRef = import_react.useRef(null);
	const pressedThumbIndexRef = import_react.useRef(-1);
	const pressedValuesRef = import_react.useRef(null);
	const lastChangeReasonRef = import_react.useRef(none);
	const [active, setActiveState] = import_react.useState(-1);
	const [lastUsedThumbIndex, setLastUsedThumbIndex] = import_react.useState(-1);
	const [dragging, setDragging] = import_react.useState(false);
	const [thumbMap, setThumbMap] = import_react.useState(() => /* @__PURE__ */ new Map());
	const [indicatorPosition, setIndicatorPosition] = import_react.useState([void 0, void 0]);
	const setActive = useStableCallback((value) => {
		setActiveState(value);
		if (value !== -1) setLastUsedThumbIndex(value);
	});
	const registerFieldControlRef = useStableCallback((element) => {
		if (element) controlRef.current = element;
	});
	const range = Array.isArray(valueUnwrapped);
	const values = import_react.useMemo(() => {
		if (!range) return [clamp(valueUnwrapped, min, max)];
		return valueUnwrapped.map((value) => clamp(value, min, max)).sort(asc);
	}, [
		max,
		min,
		range,
		valueUnwrapped
	]);
	const fieldValue = range ? values : values[0];
	useRegisterFieldControl(validation.inputRef, id, fieldValue, void 0, !disabled, nameProp);
	useValueChanged(fieldValue, () => {
		clearErrors(name);
		validation.change(fieldValue);
		const initialValue = validityData.initialValue;
		let isDirty;
		if (Array.isArray(fieldValue) && Array.isArray(initialValue)) isDirty = !areArraysEqual(fieldValue, initialValue);
		else isDirty = fieldValue !== initialValue;
		setDirty(isDirty);
	});
	const setValue = useStableCallback((newValue, details) => {
		if (Number.isNaN(newValue) || areValuesEqual(newValue, valueUnwrapped)) return false;
		const nativeEvent = details.event;
		const EventConstructor = nativeEvent.constructor;
		const clonedEvent = new EventConstructor(nativeEvent.type, nativeEvent);
		Object.defineProperty(clonedEvent, "target", {
			writable: true,
			value: {
				value: newValue,
				name
			}
		});
		details.event = clonedEvent;
		onValueChange(newValue, details);
		if (details.isCanceled) return false;
		lastChangeReasonRef.current = details.reason;
		setValueUnwrapped(newValue);
		return true;
	});
	const handleInputChange = useStableCallback((valueInput, index, event) => {
		const newValue = getSliderValue(valueInput, index, min, max, range, values);
		if (validateMinimumDistance(newValue, step, minStepsBetweenValues)) {
			const reason = "key" in event ? keyboard : inputChange;
			const applied = setValue(newValue, createChangeEventDetails(reason, event.nativeEvent, void 0, { activeThumbIndex: index }));
			setTouched(true);
			if (applied) onValueCommitted(newValue, createGenericEventDetails(reason, event.nativeEvent));
		}
	});
	if (min >= max) warn("Slider `max` must be greater than `min`.");
	useIsoLayoutEffect(() => {
		if (!disabled) return;
		const activeEl = activeElement(ownerDocument(sliderRef.current));
		if (contains(sliderRef.current, activeEl)) activeEl.blur();
		if (active !== -1) setActive(-1);
	}, [
		active,
		disabled,
		setActive
	]);
	const state = import_react.useMemo(() => ({
		...fieldState,
		activeThumbIndex: active,
		disabled,
		dragging,
		orientation,
		max,
		min,
		minStepsBetweenValues,
		step,
		values
	}), [
		fieldState,
		active,
		disabled,
		dragging,
		max,
		min,
		minStepsBetweenValues,
		orientation,
		step,
		values
	]);
	const contextValue = import_react.useMemo(() => ({
		active,
		controlRef,
		disabled,
		dragging,
		validation,
		format,
		handleInputChange,
		indicatorPosition,
		inset: thumbAlignment !== "center",
		labelId: ariaLabelledby,
		rootLabelId: defaultLabelId,
		largeStep,
		lastUsedThumbIndex,
		lastChangeReasonRef,
		form,
		locale,
		max,
		min,
		minStepsBetweenValues,
		name,
		onValueCommitted,
		orientation,
		pressedThumbCenterOffsetRef,
		pressedThumbIndexRef,
		pressedValuesRef,
		registerFieldControlRef,
		renderBeforeHydration: thumbAlignment === "edge",
		setActive,
		setDragging,
		setIndicatorPosition,
		setLabelId,
		setValue,
		state,
		step,
		thumbCollisionBehavior,
		thumbMap,
		thumbRefs,
		values
	}), [
		active,
		ariaLabelledby,
		defaultLabelId,
		disabled,
		dragging,
		validation,
		format,
		handleInputChange,
		indicatorPosition,
		largeStep,
		lastUsedThumbIndex,
		form,
		locale,
		max,
		min,
		minStepsBetweenValues,
		name,
		onValueCommitted,
		orientation,
		registerFieldControlRef,
		setActive,
		setValue,
		state,
		step,
		thumbCollisionBehavior,
		thumbAlignment,
		thumbMap,
		values
	]);
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [forwardedRef, sliderRef],
		props: [
			{
				"aria-labelledby": ariaLabelledby,
				id,
				role: "group"
			},
			elementProps,
			(props) => validation.getValidationProps(disabled, props)
		],
		stateAttributesMapping: sliderStateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(SliderRootContext.Provider, {
		value: contextValue,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
			elementsRef: thumbRefs,
			onMapChange: setThumbMap,
			children: element
		})
	});
});
SliderRoot.displayName = "SliderRoot";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/label/SliderLabel.mjs
/**
* An accessible label that is automatically associated with the slider thumbs.
* Renders a `<div>` element.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderLabel = /*#__PURE__*/ import_react.forwardRef(function SliderLabel(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const elementPropsWithoutId = elementProps;
	delete elementPropsWithoutId.id;
	const { state, setLabelId, controlRef, rootLabelId } = useSliderRootContext();
	function focusControl(event, controlId) {
		if (controlId) {
			const controlElement = ownerDocument(event.currentTarget).getElementById(controlId);
			if (isHTMLElement(controlElement)) {
				focusElementWithVisible(controlElement);
				return;
			}
		}
		const fallbackInputs = controlRef.current?.querySelectorAll("input[type=\"range\"]");
		const fallbackInput = fallbackInputs?.length === 1 ? fallbackInputs[0] : null;
		if (isHTMLElement(fallbackInput)) focusElementWithVisible(fallbackInput);
	}
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		state,
		props: [useLabel({
			id: rootLabelId,
			setLabelId,
			focusControl
		}), elementProps],
		stateAttributesMapping: sliderStateAttributesMapping
	});
});
SliderLabel.displayName = "SliderLabel";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/formatNumber.mjs
var cache = /* @__PURE__ */ new Map();
function getFormatter(locale, options) {
	const optionsString = JSON.stringify({
		locale: stringifyLocale(locale),
		options
	});
	const cachedFormatter = cache.get(optionsString);
	if (cachedFormatter) return cachedFormatter;
	const formatter = new Intl.NumberFormat(locale, options);
	cache.set(optionsString, formatter);
	return formatter;
}
function formatNumber(value, locale, options) {
	if (value == null) return "";
	return getFormatter(locale, options).format(value);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/value/SliderValue.mjs
/**
* Displays the current value of the slider as text.
* Renders an `<output>` element.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderValue = /*#__PURE__*/ import_react.forwardRef(function SliderValue(componentProps, forwardedRef) {
	const { "aria-live": ariaLive = "off", render, className, children, style, ...elementProps } = componentProps;
	const { thumbMap, state, values, format, locale } = useSliderRootContext();
	const outputFor = Array.from(thumbMap.values(), ({ inputId }) => inputId).join(" ").trim() || void 0;
	const formattedValues = import_react.useMemo(() => values.map((v) => formatNumber(v, locale, format)), [
		format,
		locale,
		values
	]);
	const defaultDisplayValue = formattedValues.join(" – ");
	return useRenderElement("output", componentProps, {
		state,
		ref: forwardedRef,
		props: [{
			"aria-live": ariaLive,
			children: typeof children === "function" ? children(formattedValues, values) : defaultDisplayValue,
			htmlFor: outputFor
		}, elementProps],
		stateAttributesMapping: sliderStateAttributesMapping
	});
});
SliderValue.displayName = "SliderValue";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/getMidpoint.mjs
function getMidpoint(element, vertical) {
	const rect = element.getBoundingClientRect();
	return vertical ? (rect.top + rect.bottom) / 2 : (rect.left + rect.right) / 2;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/roundValueToStep.mjs
function getDecimalPrecision(num) {
	if (num === 0) return 0;
	if (Math.abs(num) < 1) {
		const parts = num.toExponential().split("e-");
		const matissaDecimalPart = parts[0].split(".")[1];
		return (matissaDecimalPart ? matissaDecimalPart.length : 0) + parseInt(parts[1], 10);
	}
	const decimalPart = num.toString().split(".")[1];
	return decimalPart ? decimalPart.length : 0;
}
function roundValueToStep(value, step, min) {
	const nearest = Math.round((value - min) / step) * step + min;
	return Number(nearest.toFixed(Math.max(getDecimalPrecision(step), getDecimalPrecision(min))));
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/getPushedThumbValues.mjs
/**
* Returns a new array of slider values where attempting to move the thumb at `index`
* beyond its neighbours "pushes" them while respecting `minStepsBetweenValues`.
*
* Positional arguments are deliberate: property names of an options object don't
* minify, so passing them positionally keeps this internal helper smaller in the bundle.
*/
function getPushedThumbValues(values, index, nextValue, min, max, step, minStepsBetweenValues, initialValues) {
	const nextValues = values.slice();
	const minValueDifference = step * minStepsBetweenValues;
	const lastIndex = nextValues.length - 1;
	const baseInitialValues = initialValues ?? values;
	nextValues[index] = clamp(nextValue, min + index * minValueDifference, max - (lastIndex - index) * minValueDifference);
	for (let i = index + 1; i <= lastIndex; i += 1) {
		const minAllowed = nextValues[i - 1] + minValueDifference;
		const maxAllowed = max - (lastIndex - i) * minValueDifference;
		const initialValue = baseInitialValues[i];
		let candidate = Math.max(nextValues[i], minAllowed);
		if (initialValue < candidate) candidate = Math.max(initialValue, minAllowed);
		nextValues[i] = clamp(candidate, minAllowed, maxAllowed);
	}
	for (let i = index - 1; i >= 0; i -= 1) {
		const maxAllowed = nextValues[i + 1] - minValueDifference;
		const minAllowed = min + i * minValueDifference;
		const initialValue = baseInitialValues[i];
		let candidate = Math.min(nextValues[i], maxAllowed);
		if (initialValue > candidate) candidate = Math.min(initialValue, maxAllowed);
		nextValues[i] = clamp(candidate, minAllowed, maxAllowed);
	}
	for (let i = 0; i <= lastIndex; i += 1) nextValues[i] = Number(nextValues[i].toFixed(12));
	return nextValues;
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/utils/resolveThumbCollision.mjs
/**
* Positional arguments are deliberate: property names of an options object don't
* minify, so passing them positionally keeps this internal helper smaller in the bundle.
*/
function resolveThumbCollision(behavior, values, currentValues, initialValues, pressedIndex, nextValue, min, max, step, minStepsBetweenValues) {
	const activeValues = currentValues ?? values;
	const baselineValues = initialValues ?? values;
	if (!(activeValues.length > 1)) return {
		value: nextValue,
		thumbIndex: 0,
		didSwap: false
	};
	const minValueDifference = step * minStepsBetweenValues;
	if (behavior === "push") return {
		value: getPushedThumbValues(activeValues, pressedIndex, nextValue, min, max, step, minStepsBetweenValues),
		thumbIndex: pressedIndex,
		didSwap: false
	};
	const candidateValues = activeValues.slice();
	const previousNeighbor = candidateValues[pressedIndex - 1];
	const nextNeighbor = candidateValues[pressedIndex + 1];
	const lowerBound = previousNeighbor != null ? previousNeighbor + minValueDifference : min;
	const upperBound = nextNeighbor != null ? nextNeighbor - minValueDifference : max;
	const pressedValueAfterClamp = Number(clamp(nextValue, lowerBound, upperBound).toFixed(12));
	candidateValues[pressedIndex] = pressedValueAfterClamp;
	switch (behavior) {
		case "swap": {
			const pressedInitialValue = activeValues[pressedIndex];
			const epsilon = 1e-7;
			const movingForward = nextValue > pressedInitialValue;
			const movingBackward = nextValue < pressedInitialValue;
			const shouldSwapForward = movingForward && nextNeighbor != null && nextValue >= nextNeighbor - epsilon;
			const shouldSwapBackward = movingBackward && previousNeighbor != null && nextValue <= previousNeighbor + epsilon;
			if (!shouldSwapForward && !shouldSwapBackward) return {
				value: candidateValues,
				thumbIndex: pressedIndex,
				didSwap: false
			};
			const targetIndex = shouldSwapForward ? pressedIndex + 1 : pressedIndex - 1;
			const initialValuesForPush = candidateValues.map((_, index) => {
				if (index === pressedIndex) return pressedValueAfterClamp;
				const baseline = baselineValues[index];
				if (baseline != null) return baseline;
				return activeValues[index];
			});
			let nextValueForTarget = nextValue;
			if (shouldSwapForward) nextValueForTarget = Math.max(nextValue, candidateValues[targetIndex]);
			else nextValueForTarget = Math.min(nextValue, candidateValues[targetIndex]);
			const adjustedValues = getPushedThumbValues(candidateValues, targetIndex, nextValueForTarget, min, max, step, minStepsBetweenValues, initialValuesForPush);
			const neighborIndex = shouldSwapForward ? targetIndex - 1 : targetIndex + 1;
			const previousValue = adjustedValues[neighborIndex - 1];
			const nextValueAfter = adjustedValues[neighborIndex + 1];
			let neighborLowerBound = previousValue != null ? previousValue + minValueDifference : min;
			neighborLowerBound = Math.max(neighborLowerBound, min + neighborIndex * minValueDifference);
			let neighborUpperBound = nextValueAfter != null ? nextValueAfter - minValueDifference : max;
			neighborUpperBound = Math.min(neighborUpperBound, max - (adjustedValues.length - 1 - neighborIndex) * minValueDifference);
			const restoredValue = clamp(pressedValueAfterClamp, neighborLowerBound, neighborUpperBound);
			adjustedValues[neighborIndex] = Number(restoredValue.toFixed(12));
			return {
				value: adjustedValues,
				thumbIndex: targetIndex,
				didSwap: true
			};
		}
		default: return {
			value: candidateValues,
			thumbIndex: pressedIndex,
			didSwap: false
		};
	}
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/control/SliderControl.mjs
var INTENTIONAL_DRAG_COUNT_THRESHOLD = 2;
function getControlOffset(styles, vertical) {
	if (!styles) return {
		start: 0,
		end: 0
	};
	function parseSize(value) {
		const parsed = value != null ? parseFloat(value) : 0;
		return Number.isNaN(parsed) ? 0 : parsed;
	}
	const start = !vertical ? "InlineStart" : "Top";
	const end = !vertical ? "InlineEnd" : "Bottom";
	return {
		start: parseSize(styles[`border${start}Width`]) + parseSize(styles[`padding${start}`]),
		end: parseSize(styles[`border${end}Width`]) + parseSize(styles[`padding${end}`])
	};
}
function getFingerCoords(event, touchIdRef) {
	if (touchIdRef.current != null && event.changedTouches) {
		const touchEvent = event;
		for (let i = 0; i < touchEvent.changedTouches.length; i += 1) {
			const touch = touchEvent.changedTouches[i];
			if (touch.identifier === touchIdRef.current) return {
				x: touch.clientX,
				y: touch.clientY
			};
		}
		return null;
	}
	return {
		x: event.clientX,
		y: event.clientY
	};
}
/**
* The clickable, interactive part of the slider.
* Renders a `<div>` element.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderControl = /*#__PURE__*/ import_react.forwardRef(function SliderControl(componentProps, forwardedRef) {
	const { render: renderProp, className, style, ...elementProps } = componentProps;
	const { disabled, dragging, inset, lastChangeReasonRef, max, min, minStepsBetweenValues, onValueCommitted, orientation, pressedThumbCenterOffsetRef, pressedThumbIndexRef, pressedValuesRef, registerFieldControlRef, renderBeforeHydration, setActive, setDragging, setValue, state, step, thumbCollisionBehavior, thumbRefs, values } = useSliderRootContext();
	const direction = useDirection();
	const range = values.length > 1;
	const vertical = orientation === "vertical";
	const controlRef = import_react.useRef(null);
	const stylesRef = import_react.useRef(null);
	const setStylesRef = useStableCallback((element) => {
		if (element && stylesRef.current == null) stylesRef.current = getWindow(element).getComputedStyle(element);
	});
	const touchIdRef = import_react.useRef(null);
	const moveCountRef = import_react.useRef(0);
	const insetThumbOffsetRef = import_react.useRef(0);
	const currentInteractionValueRef = import_react.useRef(null);
	const latestValuesRef = useValueAsRef(values);
	function getThumbInput(el) {
		return el?.querySelector("input[type=\"range\"]");
	}
	function updatePressedThumb(nextIndex) {
		pressedThumbIndexRef.current = nextIndex;
		if (!thumbRefs.current[nextIndex]) pressedThumbCenterOffsetRef.current = null;
	}
	function resetPressedThumb() {
		pressedThumbIndexRef.current = -1;
		pressedThumbCenterOffsetRef.current = null;
	}
	function isTargetDisabledThumb(target) {
		if (!isElement(target)) return false;
		return thumbRefs.current.some((thumbEl) => {
			if (!isElement(thumbEl) || !contains(thumbEl, target)) return false;
			return getThumbInput(thumbEl)?.disabled === true;
		});
	}
	function getFingerState(fingerCoords) {
		const control = controlRef.current;
		const thumbIndex = pressedThumbIndexRef.current;
		if (!control || thumbIndex < 0 || thumbIndex >= values.length) {
			if (thumbIndex >= values.length) currentInteractionValueRef.current = null;
			return null;
		}
		const { width, height, bottom, left, right } = control.getBoundingClientRect();
		const controlOffset = getControlOffset(stylesRef.current, vertical);
		const insetThumbOffset = insetThumbOffsetRef.current;
		const controlSize = (vertical ? height : width) - controlOffset.start - controlOffset.end - insetThumbOffset * 2;
		const thumbCenterOffset = pressedThumbCenterOffsetRef.current ?? 0;
		const fingerX = fingerCoords.x - thumbCenterOffset;
		const fingerY = fingerCoords.y - thumbCenterOffset;
		const valueRescaled = clamp(((vertical ? bottom - fingerY - controlOffset.end : (direction === "rtl" ? right - fingerX : fingerX - left) - controlOffset.start) - insetThumbOffset) / controlSize, 0, 1);
		let newValue = (max - min) * valueRescaled + min;
		newValue = roundValueToStep(newValue, step, min);
		newValue = clamp(newValue, min, max);
		if (!range) return {
			value: newValue,
			thumbIndex,
			didSwap: false
		};
		return resolveThumbCollision(thumbCollisionBehavior, values, latestValuesRef.current, pressedValuesRef.current, thumbIndex, newValue, min, max, step, minStepsBetweenValues);
	}
	function startPressing(fingerCoords) {
		pressedValuesRef.current = range ? values.slice() : null;
		currentInteractionValueRef.current = null;
		latestValuesRef.current = values;
		const pressedThumbIndex = pressedThumbIndexRef.current;
		let closestThumbIndex = pressedThumbIndex;
		if (pressedThumbIndex > -1 && pressedThumbIndex < values.length) {
			if (values[pressedThumbIndex] === max) {
				let candidateIndex = pressedThumbIndex;
				while (candidateIndex > 0 && values[candidateIndex - 1] === max) candidateIndex -= 1;
				closestThumbIndex = candidateIndex;
			}
		} else {
			const axis = !vertical ? "x" : "y";
			let minDistance;
			closestThumbIndex = -1;
			for (let i = 0; i < thumbRefs.current.length; i += 1) {
				const thumbEl = thumbRefs.current[i];
				if (isElement(thumbEl) && !getThumbInput(thumbEl)?.disabled) {
					const midpoint = getMidpoint(thumbEl, vertical);
					const distance = Math.abs(fingerCoords[axis] - midpoint);
					if (minDistance === void 0 || distance <= minDistance) {
						closestThumbIndex = i;
						minDistance = distance;
					}
				}
			}
		}
		if (closestThumbIndex > -1 && closestThumbIndex !== pressedThumbIndex) updatePressedThumb(closestThumbIndex);
		if (inset) {
			const thumbEl = thumbRefs.current[closestThumbIndex];
			if (isElement(thumbEl)) {
				const thumbRect = thumbEl.getBoundingClientRect();
				insetThumbOffsetRef.current = thumbRect[!vertical ? "width" : "height"] / 2;
			}
		}
	}
	function focusThumb(thumbIndex) {
		const input = getThumbInput(thumbRefs.current?.[thumbIndex]);
		if (!input) return;
		input.focus({
			preventScroll: true,
			focusVisible: false
		});
	}
	function setValueFromPointer(finger, reason, nativeEvent) {
		const applied = setValue(finger.value, createChangeEventDetails(reason, nativeEvent, void 0, { activeThumbIndex: finger.thumbIndex }));
		if (applied) {
			currentInteractionValueRef.current = finger.value;
			latestValuesRef.current = Array.isArray(finger.value) ? finger.value : [finger.value];
			if (finger.didSwap) {
				updatePressedThumb(finger.thumbIndex);
				focusThumb(finger.thumbIndex);
			}
		}
		return applied;
	}
	const handleTouchMove = useStableCallback((nativeEvent) => {
		const fingerCoords = getFingerCoords(nativeEvent, touchIdRef);
		if (fingerCoords == null) return;
		moveCountRef.current += 1;
		if (nativeEvent.type === "pointermove" && nativeEvent.buttons === 0) {
			handleTouchEnd(nativeEvent);
			return;
		}
		const finger = getFingerState(fingerCoords);
		if (finger == null) return;
		if (validateMinimumDistance(finger.value, step, minStepsBetweenValues)) {
			if (!dragging && moveCountRef.current > INTENTIONAL_DRAG_COUNT_THRESHOLD) setDragging(true);
			setValueFromPointer(finger, drag, nativeEvent);
		}
	});
	const handleTouchEnd = useStableCallback((nativeEvent) => {
		setActive(-1);
		setDragging(false);
		pressedThumbCenterOffsetRef.current = null;
		const interactionValue = currentInteractionValueRef.current;
		if (Array.isArray(interactionValue) && interactionValue.length !== values.length) currentInteractionValueRef.current = null;
		if (currentInteractionValueRef.current != null) {
			const commitReason = lastChangeReasonRef.current;
			onValueCommitted(currentInteractionValueRef.current, createGenericEventDetails(commitReason, nativeEvent));
		}
		if ("pointerType" in nativeEvent && controlRef.current?.hasPointerCapture(nativeEvent.pointerId)) controlRef.current?.releasePointerCapture(nativeEvent.pointerId);
		pressedThumbIndexRef.current = -1;
		touchIdRef.current = null;
		stopListening();
	});
	const handleTouchStart = useStableCallback((nativeEvent) => {
		if (disabled) return;
		if (isTargetDisabledThumb(getTarget(nativeEvent))) {
			resetPressedThumb();
			return;
		}
		const touch = nativeEvent.changedTouches[0];
		if (touch == null) return;
		touchIdRef.current = touch.identifier;
		const fingerCoords = {
			x: touch.clientX,
			y: touch.clientY
		};
		startPressing(fingerCoords);
		const finger = getFingerState(fingerCoords);
		if (finger == null) return;
		focusThumb(finger.thumbIndex);
		setValueFromPointer(finger, trackPress, nativeEvent);
		moveCountRef.current = 0;
		const doc = ownerDocument(controlRef.current);
		doc.addEventListener("touchmove", handleTouchMove, { passive: true });
		doc.addEventListener("touchend", handleTouchEnd, { passive: true });
	});
	const stopListening = useStableCallback(() => {
		const doc = ownerDocument(controlRef.current);
		doc.removeEventListener("pointermove", handleTouchMove);
		doc.removeEventListener("pointerup", handleTouchEnd);
		doc.removeEventListener("touchmove", handleTouchMove);
		doc.removeEventListener("touchend", handleTouchEnd);
		pressedValuesRef.current = null;
		currentInteractionValueRef.current = null;
	});
	const focusFrame = useAnimationFrame();
	import_react.useEffect(() => {
		const control = controlRef.current;
		if (!control) return () => stopListening();
		const unsubscribeTouchStart = addEventListener(control, "touchstart", handleTouchStart, { passive: true });
		return () => {
			unsubscribeTouchStart();
			focusFrame.cancel();
			stopListening();
		};
	}, [
		stopListening,
		handleTouchStart,
		controlRef,
		focusFrame
	]);
	import_react.useEffect(() => {
		if (disabled) stopListening();
	}, [disabled, stopListening]);
	return useRenderElement("div", componentProps, {
		state,
		ref: [
			forwardedRef,
			registerFieldControlRef,
			controlRef,
			setStylesRef
		],
		props: [{
			["data-base-ui-slider-control"]: renderBeforeHydration ? "" : void 0,
			onPointerDown(event) {
				const control = controlRef.current;
				const target = getTarget(event.nativeEvent);
				if (!control || disabled || event.defaultPrevented || !isElement(target) || event.button !== 0) return;
				if (isTargetDisabledThumb(target)) {
					resetPressedThumb();
					return;
				}
				const fingerCoords = {
					x: event.clientX,
					y: event.clientY
				};
				startPressing(fingerCoords);
				const finger = getFingerState(fingerCoords);
				if (finger == null) return;
				if (contains(thumbRefs.current[finger.thumbIndex], activeElement(ownerDocument(control)))) event.preventDefault();
				else focusFrame.request(() => {
					focusThumb(finger.thumbIndex);
				});
				setDragging(true);
				if (!(pressedThumbCenterOffsetRef.current != null)) setValueFromPointer(finger, trackPress, event.nativeEvent);
				if (event.nativeEvent.pointerId) control.setPointerCapture(event.nativeEvent.pointerId);
				moveCountRef.current = 0;
				const doc = ownerDocument(control);
				doc.addEventListener("pointermove", handleTouchMove, { passive: true });
				doc.addEventListener("pointerup", handleTouchEnd, { once: true });
			}
		}, elementProps],
		stateAttributesMapping: sliderStateAttributesMapping
	});
});
SliderControl.displayName = "SliderControl";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/track/SliderTrack.mjs
/**
* Contains the slider indicator and represents the entire range of the slider.
* Renders a `<div>` element.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderTrack = /*#__PURE__*/ import_react.forwardRef(function SliderTrack(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { state } = useSliderRootContext();
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [{ style: { position: "relative" } }, elementProps],
		stateAttributesMapping: sliderStateAttributesMapping
	});
});
SliderTrack.displayName = "SliderTrack";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/useIsHydrating.mjs
var import_shim = require_shim();
function subscribe() {
	return NOOP;
}
function getSnapshot() {
	return false;
}
function getServerSnapshot() {
	return true;
}
/**
* Returns `true` while React is hydrating server-rendered markup and `false`
* for fresh client-only mounts.
*/
function useIsHydrating() {
	return (0, import_shim.useSyncExternalStore)(subscribe, getSnapshot, getServerSnapshot);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/utils/valueToPercent.mjs
function valueToPercent(value, min, max) {
	return (value - min) * 100 / (max - min);
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/internals/PrehydrationScript.mjs
/**
* Renders an inline script that runs before React hydrates, used by components that need
* to position server-rendered content ahead of hydration (e.g. `Tabs.Indicator`,
* `Slider.Thumb`).
*
* The `script` source is imported by the caller through the package's `#prehydration/*`
* subpath import, whose `browser` condition resolves to a stub module exporting an empty
* string — so the script body is excluded from client bundles. It only ever executes from
* server-rendered HTML.
*
* Render this only when the script should be emitted (i.e. gate `renderBeforeHydration`
* and any structural conditions at the call site). The element is still rendered (with
* empty content) on the client during the hydration pass so the React tree matches the
* server markup; `suppressHydrationWarning` bridges the content difference and React keeps
* the already-executed server script. Once `isHydrating` flips to `false` the element
* unmounts.
*
* The component must stay in client bundles: returning `null` on the client (e.g. by
* stubbing the whole component) would drop an element the server emitted and trigger a
* recoverable hydration error (React #418) in consumers' apps. Only the script body is
* excluded from client bundles, via the `#prehydration/*` `browser` condition.
*
* When adding a new consumer, register a matching `#prehydration/*` entry (with `browser`
* and `default` conditions) in `packages/react/package.json` `imports`; the `browser`
* condition reuses the shared `internals/prehydrationScript.stub.ts`.
*/
function PrehydrationScript(props) {
	const { script } = props;
	const { nonce } = useCSPContext();
	if (!useIsHydrating()) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("script", {
		nonce,
		dangerouslySetInnerHTML: { __html: script },
		suppressHydrationWarning: true
	});
}
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/thumb/SliderThumb.mjs
var _PrehydrationScript;
var ALL_KEYS = /* @__PURE__ */ new Set([
	...COMPOSITE_KEYS,
	PAGE_UP,
	PAGE_DOWN
]);
function getDefaultAriaValueText(values, index, format, locale) {
	if (index < 0) return;
	if (values.length === 2) return `${formatNumber(values[index], locale, format)} ${index === 0 ? "start" : "end"} range`;
	return format ? formatNumber(values[index], locale, format) : void 0;
}
function getNewValue(thumbValue, increment, direction, min, max) {
	const value = thumbValue + increment * direction;
	return clamp(Number(value.toFixed(Math.max(getDecimalPrecision(thumbValue), getDecimalPrecision(increment), getDecimalPrecision(min)))), min, max);
}
/**
* The draggable part of the slider at the tip of the indicator.
* Renders a `<div>` element and a nested `<input type="range">`.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderThumb = /*#__PURE__*/ import_react.forwardRef(function SliderThumb(componentProps, forwardedRef) {
	const { render, children: childrenProp, className, "aria-describedby": ariaDescribedByProp, "aria-label": ariaLabelProp, "aria-labelledby": ariaLabelledByProp, "aria-valuetext": ariaValueTextProp, disabled: disabledProp = false, getAriaLabel: getAriaLabelProp, getAriaValueText: getAriaValueTextProp, id: idProp, index: indexProp, inputRef: inputRefProp, onBlur: onBlurProp, onFocus: onFocusProp, onKeyDown: onKeyDownProp, tabIndex: tabIndexProp, style, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const { active: activeIndex, lastUsedThumbIndex, controlRef, disabled: contextDisabled, validation, format, handleInputChange, inset, labelId, largeStep, locale, max, min, minStepsBetweenValues, form, name, orientation, pressedThumbCenterOffsetRef, pressedThumbIndexRef, renderBeforeHydration, setActive, setIndicatorPosition, state, step, thumbRefs, values: sliderValues } = useSliderRootContext();
	const direction = useDirection();
	const disabled = disabledProp || contextDisabled;
	const range = sliderValues.length > 1;
	const vertical = orientation === "vertical";
	const rtl = direction === "rtl";
	const { setTouched, setFocused, validationMode } = useFieldRootContext();
	const thumbRef = import_react.useRef(null);
	const inputRef = import_react.useRef(null);
	const restoringFocusVisibleRef = import_react.useRef(false);
	const handleFocusProp = useStableCallback((event) => {
		if (restoringFocusVisibleRef.current) return;
		onFocusProp?.(event);
	});
	const handleBlurProp = useStableCallback((event) => {
		if (restoringFocusVisibleRef.current) return;
		onBlurProp?.(event);
	});
	const defaultInputId = useBaseUiId();
	const labelableId = useLabelableId();
	const inputId = range ? defaultInputId : labelableId;
	const { ref: listItemRef, index: compositeIndex } = useCompositeListItem({ metadata: import_react.useMemo(() => ({ inputId }), [inputId]) });
	const index = !range ? 0 : indexProp ?? compositeIndex;
	const last = index === sliderValues.length - 1;
	const thumbValue = sliderValues[index];
	const thumbValuePercent = valueToPercent(thumbValue, min, max);
	const [positionPercent, setPositionPercent] = import_react.useState();
	const isHydrating = useIsHydrating();
	const safeLastUsedThumbIndex = lastUsedThumbIndex >= 0 && lastUsedThumbIndex < sliderValues.length ? lastUsedThumbIndex : -1;
	const getInsetPosition = useStableCallback(() => {
		const control = controlRef.current;
		const thumb = thumbRef.current;
		if (!control || !thumb) return;
		const thumbRect = thumb.getBoundingClientRect();
		const controlRect = control.getBoundingClientRect();
		const side = vertical ? "height" : "width";
		const controlSize = controlRect[side] - thumbRect[side];
		const nextPositionPercent = (thumbRect[side] / 2 + controlSize * thumbValuePercent / 100) / controlRect[side] * 100;
		const nextInsetPosition = Number.isFinite(nextPositionPercent) ? nextPositionPercent : void 0;
		setPositionPercent(nextInsetPosition);
		if (index === 0) setIndicatorPosition((prevPosition) => [nextInsetPosition, prevPosition[1]]);
		else if (last) setIndicatorPosition((prevPosition) => [prevPosition[0], nextInsetPosition]);
	});
	useIsoLayoutEffect(() => {
		if (inset) queueMicrotask(getInsetPosition);
	}, [getInsetPosition, inset]);
	useIsoLayoutEffect(() => {
		if (inset) getInsetPosition();
	}, [
		getInsetPosition,
		inset,
		thumbValuePercent
	]);
	useIsoLayoutEffect(() => {
		if (!inset) return;
		const control = controlRef.current;
		const thumb = thumbRef.current;
		if (!control || !thumb) return;
		const ResizeObserverCtor = getWindow(control).ResizeObserver;
		if (typeof ResizeObserverCtor !== "function") return;
		const resizeObserver = new ResizeObserverCtor(getInsetPosition);
		resizeObserver.observe(control);
		resizeObserver.observe(thumb);
		return () => {
			resizeObserver.disconnect();
		};
	}, [
		controlRef,
		getInsetPosition,
		inset
	]);
	const startEdge = vertical ? "bottom" : "insetInlineStart";
	const crossOffsetProperty = vertical ? "left" : "top";
	let zIndex;
	if (range) {
		if (activeIndex === index) zIndex = 2;
		else if (safeLastUsedThumbIndex === index) zIndex = 1;
	} else if (activeIndex === index) zIndex = 1;
	let thumbStyle;
	if (!inset && !Number.isFinite(thumbValuePercent)) thumbStyle = visuallyHidden;
	else thumbStyle = {
		position: "absolute",
		[startEdge]: inset ? "var(--position)" : `${thumbValuePercent}%`,
		[crossOffsetProperty]: "50%",
		translate: `${(vertical || !rtl ? -1 : 1) * 50}% ${(vertical ? 1 : -1) * 50}%`,
		zIndex,
		...inset && {
			["--position"]: `${positionPercent ?? 0}%`,
			visibility: renderBeforeHydration && isHydrating || positionPercent === void 0 ? "hidden" : void 0
		}
	};
	let cssWritingMode;
	if (vertical) cssWritingMode = rtl ? "vertical-rl" : "vertical-lr";
	const ariaLabel = typeof getAriaLabelProp === "function" ? getAriaLabelProp(index) : ariaLabelProp;
	const inputProps = mergeProps({
		"aria-label": ariaLabel,
		"aria-labelledby": ariaLabelledByProp ?? (ariaLabel == null ? labelId : void 0),
		"aria-describedby": ariaDescribedByProp,
		"aria-orientation": orientation,
		"aria-valuenow": thumbValue,
		"aria-valuetext": typeof getAriaValueTextProp === "function" ? getAriaValueTextProp(formatNumber(thumbValue, locale, format), thumbValue, index) : ariaValueTextProp ?? getDefaultAriaValueText(sliderValues, index, format, locale),
		disabled,
		form,
		id: inputId,
		max,
		min,
		name,
		onChange(event) {
			handleInputChange(event.currentTarget.valueAsNumber, index, event);
		},
		onFocus(event) {
			const isRestoringFocusVisible = restoringFocusVisibleRef.current;
			restoringFocusVisibleRef.current = false;
			setActive(index);
			setFocused(true);
			if (isRestoringFocusVisible) event.stopPropagation();
		},
		onBlur(event) {
			if (restoringFocusVisibleRef.current) {
				event.stopPropagation();
				return;
			}
			setActive(-1);
			if (thumbRefs.current.some((thumb) => contains(thumb, event.relatedTarget))) return;
			setTouched(true);
			setFocused(false);
			if (validationMode === "onBlur") validation.commit(getSliderValue(thumbValue, index, min, max, range, sliderValues));
		},
		onKeyDown(event) {
			if (event.defaultPrevented) return;
			if (!ALL_KEYS.has(event.key)) return;
			if (COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
			let newValue = null;
			let direction = 0;
			let increment = event.shiftKey ? largeStep : step;
			const roundedValue = roundValueToStep(thumbValue, step, min);
			switch (event.key) {
				case ARROW_UP:
					direction = 1;
					break;
				case ARROW_RIGHT:
					direction = rtl ? -1 : 1;
					break;
				case ARROW_DOWN:
					direction = -1;
					break;
				case ARROW_LEFT:
					direction = rtl ? 1 : -1;
					break;
				case PAGE_UP:
					increment = largeStep;
					direction = 1;
					break;
				case PAGE_DOWN:
					increment = largeStep;
					direction = -1;
					break;
				case "End":
					newValue = range && Number.isFinite(sliderValues[index + 1]) ? sliderValues[index + 1] - step * minStepsBetweenValues : max;
					break;
				case HOME:
					newValue = range && Number.isFinite(sliderValues[index - 1]) ? sliderValues[index - 1] + step * minStepsBetweenValues : min;
					break;
				default: break;
			}
			if (direction !== 0) newValue = getNewValue(roundedValue, increment, direction, min, max);
			if (newValue !== null) {
				const input = event.currentTarget;
				if (!matchesFocusVisible(input)) {
					restoringFocusVisibleRef.current = true;
					input.blur();
					input.focus({
						preventScroll: true,
						focusVisible: true
					});
				}
				handleInputChange(newValue, index, event);
				event.preventDefault();
			}
		},
		step,
		style: {
			...visuallyHidden,
			width: "100%",
			height: "100%",
			writingMode: cssWritingMode
		},
		tabIndex: tabIndexProp,
		type: "range",
		value: thumbValue ?? ""
	}, (props) => validation.getValidationProps(disabled, props), {
		onFocus: handleFocusProp,
		onBlur: handleBlurProp,
		onKeyDown: onKeyDownProp
	});
	const mergedInputRef = useMergedRefs(inputRef, validation.inputRef, inputRefProp);
	return useRenderElement("div", componentProps, {
		state,
		ref: [
			forwardedRef,
			listItemRef,
			thumbRef
		],
		props: [{
			["data-index"]: index,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
				childrenProp,
				/*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
					ref: mergedInputRef,
					...inputProps,
					suppressHydrationWarning: true
				}),
				inset && last && renderBeforeHydration && (_PrehydrationScript || (_PrehydrationScript = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PrehydrationScript, { script: "" })))
			] }),
			id,
			onPointerDown(event) {
				if (disabled) return;
				pressedThumbIndexRef.current = index;
				const midpoint = getMidpoint(event.currentTarget, vertical);
				pressedThumbCenterOffsetRef.current = (vertical ? event.clientY : event.clientX) - midpoint;
			},
			style: thumbStyle,
			suppressHydrationWarning: renderBeforeHydration || void 0
		}, elementProps],
		stateAttributesMapping: sliderStateAttributesMapping
	});
});
SliderThumb.displayName = "SliderThumb";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/indicator/SliderIndicator.mjs
function getIndicatorStyles(vertical, range, inset, start, end, forceHidden) {
	const styles = {
		visibility: forceHidden || inset && (start === void 0 || range && end === void 0) ? "hidden" : void 0,
		position: vertical ? "absolute" : "relative",
		[vertical ? "width" : "height"]: "inherit"
	};
	let startValue = `${start ?? 0}%`;
	let sizeValue = `${(end ?? 0) - (start ?? 0)}%`;
	if (inset) {
		styles["--start-position"] = startValue;
		startValue = "var(--start-position)";
		if (range) {
			styles["--relative-size"] = sizeValue;
			sizeValue = "var(--relative-size)";
		}
	}
	styles[vertical ? "bottom" : "insetInlineStart"] = range ? startValue : 0;
	styles[vertical ? "height" : "width"] = range ? sizeValue : startValue;
	return styles;
}
/**
* Visualizes the current value of the slider.
* Renders a `<div>` element.
*
* Documentation: [Base UI Slider](https://base-ui.com/react/components/slider)
*/
var SliderIndicator = /*#__PURE__*/ import_react.forwardRef(function SliderIndicator(componentProps, forwardedRef) {
	const { render, className, style: styleProp, ...elementProps } = componentProps;
	const { indicatorPosition, inset, max, min, orientation, renderBeforeHydration, state, values } = useSliderRootContext();
	const isHydrating = useIsHydrating();
	const style = getIndicatorStyles(orientation === "vertical", values.length > 1, inset, inset ? indicatorPosition[0] : valueToPercent(values[0], min, max), inset ? indicatorPosition[1] : valueToPercent(values[values.length - 1], min, max), inset && renderBeforeHydration && isHydrating);
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [{
			["data-base-ui-slider-indicator"]: renderBeforeHydration ? "" : void 0,
			style,
			suppressHydrationWarning: renderBeforeHydration || void 0
		}, elementProps],
		stateAttributesMapping: sliderStateAttributesMapping
	});
});
SliderIndicator.displayName = "SliderIndicator";
//#endregion
//#region node_modules/.bun/@base-ui+react@1.7.0+0ea9ec2a211d4613/node_modules/@base-ui/react/slider/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Control: () => SliderControl,
	Indicator: () => SliderIndicator,
	Label: () => SliderLabel,
	Root: () => SliderRoot,
	Thumb: () => SliderThumb,
	Track: () => SliderTrack,
	Value: () => SliderValue
});
//#endregion
export { index_parts_exports as Slider };
