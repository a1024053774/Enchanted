import { i as __toESM } from "./rolldown-runtime-B4lejLz5.js";
import { t as require_react } from "./react.js";
//#region node_modules/.bun/react-colorful@5.6.1+bf16f8eded5e12ee/node_modules/react-colorful/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function u() {
	return (u = Object.assign || function(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = arguments[r];
			for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
		}
		return e;
	}).apply(this, arguments);
}
function c(e, r) {
	if (null == e) return {};
	var t, n, o = {}, a = Object.keys(e);
	for (n = 0; n < a.length; n++) r.indexOf(t = a[n]) >= 0 || (o[t] = e[t]);
	return o;
}
function i(e) {
	var t = (0, import_react.useRef)(e), n = (0, import_react.useRef)(function(e) {
		t.current && t.current(e);
	});
	return t.current = e, n.current;
}
var s = function(e, r, t) {
	return void 0 === r && (r = 0), void 0 === t && (t = 1), e > t ? t : e < r ? r : e;
};
var f = function(e) {
	return "touches" in e;
};
var v = function(e) {
	return e && e.ownerDocument.defaultView || self;
};
var d = function(e, r, t) {
	var n = e.getBoundingClientRect(), o = f(r) ? function(e, r) {
		for (var t = 0; t < e.length; t++) if (e[t].identifier === r) return e[t];
		return e[0];
	}(r.touches, t) : r;
	return {
		left: s((o.pageX - (n.left + v(e).pageXOffset)) / n.width),
		top: s((o.pageY - (n.top + v(e).pageYOffset)) / n.height)
	};
};
var h = function(e) {
	!f(e) && e.preventDefault();
};
var m = import_react.memo(function(o) {
	var a = o.onMove, l = o.onKey, s = c(o, ["onMove", "onKey"]), m = (0, import_react.useRef)(null), g = i(a), p = i(l), b = (0, import_react.useRef)(null), _ = (0, import_react.useRef)(!1), x = (0, import_react.useMemo)(function() {
		var e = function(e) {
			h(e), (f(e) ? e.touches.length > 0 : e.buttons > 0) && m.current ? g(d(m.current, e, b.current)) : t(!1);
		}, r = function() {
			return t(!1);
		};
		function t(t) {
			var n = _.current, o = v(m.current), a = t ? o.addEventListener : o.removeEventListener;
			a(n ? "touchmove" : "mousemove", e), a(n ? "touchend" : "mouseup", r);
		}
		return [
			function(e) {
				var r = e.nativeEvent, n = m.current;
				if (n && (h(r), !function(e, r) {
					return r && !f(e);
				}(r, _.current) && n)) {
					if (f(r)) {
						_.current = !0;
						var o = r.changedTouches || [];
						o.length && (b.current = o[0].identifier);
					}
					n.focus(), g(d(n, r, b.current)), t(!0);
				}
			},
			function(e) {
				var r = e.which || e.keyCode;
				r < 37 || r > 40 || (e.preventDefault(), p({
					left: 39 === r ? .05 : 37 === r ? -.05 : 0,
					top: 40 === r ? .05 : 38 === r ? -.05 : 0
				}));
			},
			t
		];
	}, [p, g]), C = x[0], E = x[1], H = x[2];
	return (0, import_react.useEffect)(function() {
		return H;
	}, [H]), import_react.createElement("div", u({}, s, {
		onTouchStart: C,
		onMouseDown: C,
		className: "react-colorful__interactive",
		ref: m,
		onKeyDown: E,
		tabIndex: 0,
		role: "slider"
	}));
});
var g = function(e) {
	return e.filter(Boolean).join(" ");
};
var p = function(r) {
	var t = r.color, n = r.left, o = r.top, a = void 0 === o ? .5 : o, l = g(["react-colorful__pointer", r.className]);
	return import_react.createElement("div", {
		className: l,
		style: {
			top: 100 * a + "%",
			left: 100 * n + "%"
		}
	}, import_react.createElement("div", {
		className: "react-colorful__pointer-fill",
		style: { backgroundColor: t }
	}));
};
var b = function(e, r, t) {
	return void 0 === r && (r = 0), void 0 === t && (t = Math.pow(10, r)), Math.round(t * e) / t;
};
var _ = {
	grad: .9,
	turn: 360,
	rad: 360 / (2 * Math.PI)
};
var x = function(e) {
	return L(C(e));
};
var C = function(e) {
	return "#" === e[0] && (e = e.substring(1)), e.length < 6 ? {
		r: parseInt(e[0] + e[0], 16),
		g: parseInt(e[1] + e[1], 16),
		b: parseInt(e[2] + e[2], 16),
		a: 4 === e.length ? b(parseInt(e[3] + e[3], 16) / 255, 2) : 1
	} : {
		r: parseInt(e.substring(0, 2), 16),
		g: parseInt(e.substring(2, 4), 16),
		b: parseInt(e.substring(4, 6), 16),
		a: 8 === e.length ? b(parseInt(e.substring(6, 8), 16) / 255, 2) : 1
	};
};
var E = function(e, r) {
	return void 0 === r && (r = "deg"), Number(e) * (_[r] || 1);
};
var H = function(e) {
	var r = /hsla?\(?\s*(-?\d*\.?\d+)(deg|rad|grad|turn)?[,\s]+(-?\d*\.?\d+)%?[,\s]+(-?\d*\.?\d+)%?,?\s*[/\s]*(-?\d*\.?\d+)?(%)?\s*\)?/i.exec(e);
	return r ? N({
		h: E(r[1], r[2]),
		s: Number(r[3]),
		l: Number(r[4]),
		a: void 0 === r[5] ? 1 : Number(r[5]) / (r[6] ? 100 : 1)
	}) : {
		h: 0,
		s: 0,
		v: 0,
		a: 1
	};
};
var M = H;
var N = function(e) {
	var r = e.s, t = e.l;
	return {
		h: e.h,
		s: (r *= (t < 50 ? t : 100 - t) / 100) > 0 ? 2 * r / (t + r) * 100 : 0,
		v: t + r,
		a: e.a
	};
};
var w = function(e) {
	return K(I(e));
};
var y = function(e) {
	var r = e.s, t = e.v, n = e.a, o = (200 - r) * t / 100;
	return {
		h: b(e.h),
		s: b(o > 0 && o < 200 ? r * t / 100 / (o <= 100 ? o : 200 - o) * 100 : 0),
		l: b(o / 2),
		a: b(n, 2)
	};
};
var q = function(e) {
	var r = y(e);
	return "hsl(" + r.h + ", " + r.s + "%, " + r.l + "%)";
};
var k = function(e) {
	var r = y(e);
	return "hsla(" + r.h + ", " + r.s + "%, " + r.l + "%, " + r.a + ")";
};
var I = function(e) {
	var r = e.h, t = e.s, n = e.v, o = e.a;
	r = r / 360 * 6, t /= 100, n /= 100;
	var a = Math.floor(r), l = n * (1 - t), u = n * (1 - (r - a) * t), c = n * (1 - (1 - r + a) * t), i = a % 6;
	return {
		r: b(255 * [
			n,
			u,
			l,
			l,
			c,
			n
		][i]),
		g: b(255 * [
			c,
			n,
			n,
			u,
			l,
			l
		][i]),
		b: b(255 * [
			l,
			l,
			c,
			n,
			n,
			u
		][i]),
		a: b(o, 2)
	};
};
var O = function(e) {
	var r = /hsva?\(?\s*(-?\d*\.?\d+)(deg|rad|grad|turn)?[,\s]+(-?\d*\.?\d+)%?[,\s]+(-?\d*\.?\d+)%?,?\s*[/\s]*(-?\d*\.?\d+)?(%)?\s*\)?/i.exec(e);
	return r ? A({
		h: E(r[1], r[2]),
		s: Number(r[3]),
		v: Number(r[4]),
		a: void 0 === r[5] ? 1 : Number(r[5]) / (r[6] ? 100 : 1)
	}) : {
		h: 0,
		s: 0,
		v: 0,
		a: 1
	};
};
var j = O;
var z = function(e) {
	var r = /rgba?\(?\s*(-?\d*\.?\d+)(%)?[,\s]+(-?\d*\.?\d+)(%)?[,\s]+(-?\d*\.?\d+)(%)?,?\s*[/\s]*(-?\d*\.?\d+)?(%)?\s*\)?/i.exec(e);
	return r ? L({
		r: Number(r[1]) / (r[2] ? 100 / 255 : 1),
		g: Number(r[3]) / (r[4] ? 100 / 255 : 1),
		b: Number(r[5]) / (r[6] ? 100 / 255 : 1),
		a: void 0 === r[7] ? 1 : Number(r[7]) / (r[8] ? 100 : 1)
	}) : {
		h: 0,
		s: 0,
		v: 0,
		a: 1
	};
};
var B = z;
var D = function(e) {
	var r = e.toString(16);
	return r.length < 2 ? "0" + r : r;
};
var K = function(e) {
	var r = e.r, t = e.g, n = e.b, o = e.a, a = o < 1 ? D(b(255 * o)) : "";
	return "#" + D(r) + D(t) + D(n) + a;
};
var L = function(e) {
	var r = e.r, t = e.g, n = e.b, o = e.a, a = Math.max(r, t, n), l = a - Math.min(r, t, n), u = l ? a === r ? (t - n) / l : a === t ? 2 + (n - r) / l : 4 + (r - t) / l : 0;
	return {
		h: b(60 * (u < 0 ? u + 6 : u)),
		s: b(a ? l / a * 100 : 0),
		v: b(a / 255 * 100),
		a: o
	};
};
var A = function(e) {
	return {
		h: b(e.h),
		s: b(e.s),
		v: b(e.v),
		a: b(e.a, 2)
	};
};
var S = import_react.memo(function(r) {
	var t = r.hue, n = r.onChange, o = g(["react-colorful__hue", r.className]);
	return import_react.createElement("div", { className: o }, import_react.createElement(m, {
		onMove: function(e) {
			n({ h: 360 * e.left });
		},
		onKey: function(e) {
			n({ h: s(t + 360 * e.left, 0, 360) });
		},
		"aria-label": "Hue",
		"aria-valuenow": b(t),
		"aria-valuemax": "360",
		"aria-valuemin": "0"
	}, import_react.createElement(p, {
		className: "react-colorful__hue-pointer",
		left: t / 360,
		color: q({
			h: t,
			s: 100,
			v: 100,
			a: 1
		})
	})));
});
var T = import_react.memo(function(r) {
	var t = r.hsva, n = r.onChange, o = { backgroundColor: q({
		h: t.h,
		s: 100,
		v: 100,
		a: 1
	}) };
	return import_react.createElement("div", {
		className: "react-colorful__saturation",
		style: o
	}, import_react.createElement(m, {
		onMove: function(e) {
			n({
				s: 100 * e.left,
				v: 100 - 100 * e.top
			});
		},
		onKey: function(e) {
			n({
				s: s(t.s + 100 * e.left, 0, 100),
				v: s(t.v - 100 * e.top, 0, 100)
			});
		},
		"aria-label": "Color",
		"aria-valuetext": "Saturation " + b(t.s) + "%, Brightness " + b(t.v) + "%"
	}, import_react.createElement(p, {
		className: "react-colorful__saturation-pointer",
		top: 1 - t.v / 100,
		left: t.s / 100,
		color: q(t)
	})));
});
var F = function(e, r) {
	if (e === r) return !0;
	for (var t in e) if (e[t] !== r[t]) return !1;
	return !0;
};
var P = function(e, r) {
	return e.replace(/\s/g, "") === r.replace(/\s/g, "");
};
var X = function(e, r) {
	return e.toLowerCase() === r.toLowerCase() || F(C(e), C(r));
};
function Y(e, t, l) {
	var u = i(l), c = (0, import_react.useState)(function() {
		return e.toHsva(t);
	}), s = c[0], f = c[1], v = (0, import_react.useRef)({
		color: t,
		hsva: s
	});
	(0, import_react.useEffect)(function() {
		if (!e.equal(t, v.current.color)) {
			var r = e.toHsva(t);
			v.current = {
				hsva: r,
				color: t
			}, f(r);
		}
	}, [t, e]), (0, import_react.useEffect)(function() {
		var r;
		F(s, v.current.hsva) || e.equal(r = e.fromHsva(s), v.current.color) || (v.current = {
			hsva: s,
			color: r
		}, u(r));
	}, [
		s,
		e,
		u
	]);
	return [s, (0, import_react.useCallback)(function(e) {
		f(function(r) {
			return Object.assign({}, r, e);
		});
	}, [])];
}
var R;
var V = "undefined" != typeof window ? import_react.useLayoutEffect : import_react.useEffect;
var $ = function() {
	return R || ("undefined" != typeof __webpack_nonce__ ? __webpack_nonce__ : void 0);
};
var G = function(e) {
	R = e;
};
var J = /* @__PURE__ */ new Map();
var Q = function(e) {
	V(function() {
		var r = e.current ? e.current.ownerDocument : document;
		if (void 0 !== r && !J.has(r)) {
			var t = r.createElement("style");
			t.innerHTML = ".react-colorful{position:relative;display:flex;flex-direction:column;width:200px;height:200px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:default}.react-colorful__saturation{position:relative;flex-grow:1;border-color:transparent;border-bottom:12px solid #000;border-radius:8px 8px 0 0;background-image:linear-gradient(0deg,#000,transparent),linear-gradient(90deg,#fff,hsla(0,0%,100%,0))}.react-colorful__alpha-gradient,.react-colorful__pointer-fill{content:\"\";position:absolute;left:0;top:0;right:0;bottom:0;pointer-events:none;border-radius:inherit}.react-colorful__alpha-gradient,.react-colorful__saturation{box-shadow:inset 0 0 0 1px rgba(0,0,0,.05)}.react-colorful__alpha,.react-colorful__hue{position:relative;height:24px}.react-colorful__hue{background:linear-gradient(90deg,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red)}.react-colorful__last-control{border-radius:0 0 8px 8px}.react-colorful__interactive{position:absolute;left:0;top:0;right:0;bottom:0;border-radius:inherit;outline:none;touch-action:none}.react-colorful__pointer{position:absolute;z-index:1;box-sizing:border-box;width:28px;height:28px;transform:translate(-50%,-50%);background-color:#fff;border:2px solid #fff;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.2)}.react-colorful__interactive:focus .react-colorful__pointer{transform:translate(-50%,-50%) scale(1.1)}.react-colorful__alpha,.react-colorful__alpha-pointer{background-color:#fff;background-image:url('data:image/svg+xml;charset=utf-8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill-opacity=\".05\"><path d=\"M8 0h8v8H8zM0 8h8v8H0z\"/></svg>')}.react-colorful__saturation-pointer{z-index:3}.react-colorful__hue-pointer{z-index:2}", J.set(r, t);
			var n = $();
			n && t.setAttribute("nonce", n), r.head.appendChild(t);
		}
	}, []);
};
var U = function(t) {
	var n = t.className, o = t.colorModel, a = t.color, l = void 0 === a ? o.defaultColor : a, i = t.onChange, s = c(t, [
		"className",
		"colorModel",
		"color",
		"onChange"
	]), f = (0, import_react.useRef)(null);
	Q(f);
	var v = Y(o, l, i), d = v[0], h = v[1], m = g(["react-colorful", n]);
	return import_react.createElement("div", u({}, s, {
		ref: f,
		className: m
	}), import_react.createElement(T, {
		hsva: d,
		onChange: h
	}), import_react.createElement(S, {
		hue: d.h,
		onChange: h,
		className: "react-colorful__last-control"
	}));
};
var W = {
	defaultColor: "000",
	toHsva: x,
	fromHsva: function(e) {
		return w({
			h: e.h,
			s: e.s,
			v: e.v,
			a: 1
		});
	},
	equal: X
};
var Z = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: W }));
};
var ee = function(r) {
	var t = r.className, n = r.hsva, o = r.onChange, a = { backgroundImage: "linear-gradient(90deg, " + k(Object.assign({}, n, { a: 0 })) + ", " + k(Object.assign({}, n, { a: 1 })) + ")" }, l = g(["react-colorful__alpha", t]), u = b(100 * n.a);
	return import_react.createElement("div", { className: l }, import_react.createElement("div", {
		className: "react-colorful__alpha-gradient",
		style: a
	}), import_react.createElement(m, {
		onMove: function(e) {
			o({ a: e.left });
		},
		onKey: function(e) {
			o({ a: s(n.a + e.left) });
		},
		"aria-label": "Alpha",
		"aria-valuetext": u + "%",
		"aria-valuenow": u,
		"aria-valuemin": "0",
		"aria-valuemax": "100"
	}, import_react.createElement(p, {
		className: "react-colorful__alpha-pointer",
		left: n.a,
		color: k(n)
	})));
};
var re = function(t) {
	var n = t.className, o = t.colorModel, a = t.color, l = void 0 === a ? o.defaultColor : a, i = t.onChange, s = c(t, [
		"className",
		"colorModel",
		"color",
		"onChange"
	]), f = (0, import_react.useRef)(null);
	Q(f);
	var v = Y(o, l, i), d = v[0], h = v[1], m = g(["react-colorful", n]);
	return import_react.createElement("div", u({}, s, {
		ref: f,
		className: m
	}), import_react.createElement(T, {
		hsva: d,
		onChange: h
	}), import_react.createElement(S, {
		hue: d.h,
		onChange: h
	}), import_react.createElement(ee, {
		hsva: d,
		onChange: h,
		className: "react-colorful__last-control"
	}));
};
var te = {
	defaultColor: "0001",
	toHsva: x,
	fromHsva: w,
	equal: X
};
var ne = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: te }));
};
var oe = {
	defaultColor: {
		h: 0,
		s: 0,
		l: 0,
		a: 1
	},
	toHsva: N,
	fromHsva: y,
	equal: F
};
var ae = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: oe }));
};
var le = {
	defaultColor: "hsla(0, 0%, 0%, 1)",
	toHsva: H,
	fromHsva: k,
	equal: P
};
var ue = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: le }));
};
var ce = {
	defaultColor: {
		h: 0,
		s: 0,
		l: 0
	},
	toHsva: function(e) {
		return N({
			h: e.h,
			s: e.s,
			l: e.l,
			a: 1
		});
	},
	fromHsva: function(e) {
		return {
			h: (r = y(e)).h,
			s: r.s,
			l: r.l
		};
		var r;
	},
	equal: F
};
var ie = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: ce }));
};
var se = {
	defaultColor: "hsl(0, 0%, 0%)",
	toHsva: M,
	fromHsva: q,
	equal: P
};
var fe = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: se }));
};
var ve = {
	defaultColor: {
		h: 0,
		s: 0,
		v: 0,
		a: 1
	},
	toHsva: function(e) {
		return e;
	},
	fromHsva: A,
	equal: F
};
var de = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: ve }));
};
var he = {
	defaultColor: "hsva(0, 0%, 0%, 1)",
	toHsva: O,
	fromHsva: function(e) {
		var r = A(e);
		return "hsva(" + r.h + ", " + r.s + "%, " + r.v + "%, " + r.a + ")";
	},
	equal: P
};
var me = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: he }));
};
var ge = {
	defaultColor: {
		h: 0,
		s: 0,
		v: 0
	},
	toHsva: function(e) {
		return {
			h: e.h,
			s: e.s,
			v: e.v,
			a: 1
		};
	},
	fromHsva: function(e) {
		var r = A(e);
		return {
			h: r.h,
			s: r.s,
			v: r.v
		};
	},
	equal: F
};
var pe = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: ge }));
};
var be = {
	defaultColor: "hsv(0, 0%, 0%)",
	toHsva: j,
	fromHsva: function(e) {
		var r = A(e);
		return "hsv(" + r.h + ", " + r.s + "%, " + r.v + "%)";
	},
	equal: P
};
var _e = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: be }));
};
var xe = {
	defaultColor: {
		r: 0,
		g: 0,
		b: 0,
		a: 1
	},
	toHsva: L,
	fromHsva: I,
	equal: F
};
var Ce = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: xe }));
};
var Ee = {
	defaultColor: "rgba(0, 0, 0, 1)",
	toHsva: z,
	fromHsva: function(e) {
		var r = I(e);
		return "rgba(" + r.r + ", " + r.g + ", " + r.b + ", " + r.a + ")";
	},
	equal: P
};
var He = function(r) {
	return import_react.createElement(re, u({}, r, { colorModel: Ee }));
};
var Me = {
	defaultColor: {
		r: 0,
		g: 0,
		b: 0
	},
	toHsva: function(e) {
		return L({
			r: e.r,
			g: e.g,
			b: e.b,
			a: 1
		});
	},
	fromHsva: function(e) {
		return {
			r: (r = I(e)).r,
			g: r.g,
			b: r.b
		};
		var r;
	},
	equal: F
};
var Ne = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: Me }));
};
var we = {
	defaultColor: "rgb(0, 0, 0)",
	toHsva: B,
	fromHsva: function(e) {
		var r = I(e);
		return "rgb(" + r.r + ", " + r.g + ", " + r.b + ")";
	},
	equal: P
};
var ye = function(r) {
	return import_react.createElement(U, u({}, r, { colorModel: we }));
};
var qe = /^#?([0-9A-F]{3,8})$/i;
var ke = function(r) {
	var t = r.color, l = void 0 === t ? "" : t, s = r.onChange, f = r.onBlur, v = r.escape, d = r.validate, h = r.format, m = r.process, g = c(r, [
		"color",
		"onChange",
		"onBlur",
		"escape",
		"validate",
		"format",
		"process"
	]), p = (0, import_react.useState)(function() {
		return v(l);
	}), b = p[0], _ = p[1], x = i(s), C = i(f), E = (0, import_react.useCallback)(function(e) {
		var r = v(e.target.value);
		_(r), d(r) && x(m ? m(r) : r);
	}, [
		v,
		m,
		d,
		x
	]), H = (0, import_react.useCallback)(function(e) {
		d(e.target.value) || _(v(l)), C(e);
	}, [
		l,
		v,
		d,
		C
	]);
	return (0, import_react.useEffect)(function() {
		_(v(l));
	}, [l, v]), import_react.createElement("input", u({}, g, {
		value: h ? h(b) : b,
		spellCheck: "false",
		onChange: E,
		onBlur: H
	}));
};
var Ie = function(e) {
	return "#" + e;
};
var Oe = function(r) {
	var t = r.prefixed, n = r.alpha, o = c(r, ["prefixed", "alpha"]), l = (0, import_react.useCallback)(function(e) {
		return e.replace(/([^0-9A-F]+)/gi, "").substring(0, n ? 8 : 6);
	}, [n]), i = (0, import_react.useCallback)(function(e) {
		return function(e, r) {
			var t = qe.exec(e), n = t ? t[1].length : 0;
			return 3 === n || 6 === n || !!r && 4 === n || !!r && 8 === n;
		}(e, n);
	}, [n]);
	return import_react.createElement(ke, u({}, o, {
		escape: l,
		format: t ? Ie : void 0,
		process: Ie,
		validate: i
	}));
};
//#endregion
export { ne as HexAlphaColorPicker, Oe as HexColorInput, Z as HexColorPicker, ie as HslColorPicker, fe as HslStringColorPicker, ae as HslaColorPicker, ue as HslaStringColorPicker, pe as HsvColorPicker, _e as HsvStringColorPicker, de as HsvaColorPicker, me as HsvaStringColorPicker, Ne as RgbColorPicker, ye as RgbStringColorPicker, Ce as RgbaColorPicker, He as RgbaStringColorPicker, G as setNonce };
