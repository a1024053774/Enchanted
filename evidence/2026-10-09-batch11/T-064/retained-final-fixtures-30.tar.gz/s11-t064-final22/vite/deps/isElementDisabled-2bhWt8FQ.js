//#region node_modules/.bun/@base-ui+utils@0.3.2+0ea9ec2a211d4613/node_modules/@base-ui/utils/isElementDisabled.mjs
function isElementDisabled(element) {
	return element == null || element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true";
}
//#endregion
export { isElementDisabled as t };
