# Synara zsh profile wrapper
_synara_home="${SYNARA_ORIGINAL_ZDOTDIR:-$HOME}"
export ZDOTDIR="$_synara_home"
[[ -f "$_synara_home/.zprofile" ]] && source "$_synara_home/.zprofile"
export ZDOTDIR='/Volumes/WD-Elements/dev-cache/synara/instances/s11-t064-claude-good40/userdata/logs/terminals/_managed-zsh'
