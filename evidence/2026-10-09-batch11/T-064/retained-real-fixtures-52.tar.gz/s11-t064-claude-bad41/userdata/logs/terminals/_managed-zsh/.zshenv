# Synara zsh env wrapper
_synara_home="${SYNARA_ORIGINAL_ZDOTDIR:-$HOME}"
export ZDOTDIR="$_synara_home"
[[ -f "$_synara_home/.zshenv" ]] && source "$_synara_home/.zshenv"
export ZDOTDIR='/Volumes/WD-Elements/dev-cache/synara/instances/s11-t064-claude-bad41/userdata/logs/terminals/_managed-zsh'
